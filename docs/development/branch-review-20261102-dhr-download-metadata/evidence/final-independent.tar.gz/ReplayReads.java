import java.nio.file.Path;
import jdk.jfr.consumer.RecordingFile;

public class ReplayReads {
    public static void main(String[] args) throws Exception {
        long allEvents=0, targetEvents=0, bytes=0;
        try (var recording=new RecordingFile(Path.of(args[0]))) {
            while (recording.hasMoreEvents()) {
                var event=recording.readEvent();
                if (!event.getEventType().getName().equals("jdk.FileRead")) continue;
                allEvents++;
                String path=event.getString("path");
                if (path!=null && path.endsWith("/capacity.png")) {
                    targetEvents++;
                    bytes+=event.getLong("bytesRead");
                }
            }
        }
        System.out.println("{\"fileReadEvents\":"+allEvents+",\"targetEvents\":"+targetEvents+",\"targetBytes\":"+bytes+"}");
    }
}
