import pathlib,json,subprocess,hashlib
OUT=pathlib.Path('/tmp/edhr-dhr-metadata-final-qa-20261102');JAVA=pathlib.Path('/workspace/.edhr-cloud-tools/jdk-21.0.12.1+1/bin')
def write(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
command=[str(JAVA/'javac'),'-d',str(OUT),str(OUT/'ReplayReads.java')]
compiled=subprocess.run(command,text=True,capture_output=True);assert compiled.returncode==0,compiled.stderr
commands=[{'command':command,'exitCode':compiled.returncode,'stdout':compiled.stdout,'stderr':compiled.stderr}]
downloads=[]
for frozen in (False,True):
    d=json.loads((OUT/'download-observations'/('valid-'+str(frozen).lower()+'.json')).read_text());sql=d['sql']
    assert len(sql)==(5 if frozen else 4) and d['fullBytesAndHeadersPreserved']
    assert sum(x.startswith('SELECT status,summary_status FROM dhr_instance ') for x in sql)==2
    assert all(x!='<unknown>' and not x.startswith('SELECT original_name FROM ') for x in sql)
    assert 'SELECT stored_path,sha256,original_name FROM dhr_attachment' in sql[-1]
    downloads.append({'frozen':frozen,'queries':len(sql),'bothDhrReads':True,'noStandaloneNameQuery':True})
prefix=json.loads((OUT/'query-observations/summary-prefix.json').read_text());pairs=[(r['attachments'],r['queries']) for r in prefix['observations']]
assert pairs==[(0,5),(1,7),(10,25),(100,205),(300,605)]
lock=json.loads((OUT/'query-observations/parent-lock.json').read_text());assert lock['actualPgLockWaitObserved'] and lock['activeWhileParentLocked'] and lock['unlinkCommittedAfterRelease'] and lock['historicalOriginalRetained']
cap=json.loads((OUT/'capacity-observations/capacity.json').read_text());assert cap['completed'] and cap['bytesPerFile']==52428800 and len(cap['cases'])==12
good=bad=0;cases=[]
for c in cap['cases']:
    expectedQueries=5 if c['frozen'] else 4
    for r in c['requests']:
        assert len(r['jdbcQueries'])==expectedQueries
        assert all(s!='<unknown>' and not s.startswith('SELECT original_name FROM ') for s in r['jdbcQueries'])
        if c['corrupt']:assert r['rejectedBeforeBody'] and r['bodyBytes']==0;bad+=1
        else:assert not r['rejectedBeforeBody'] and r['bodyBytes']==52428800;good+=1
    recording=OUT/'capacity-observations'/(c['label']+'.jfr')
    command=[str(JAVA/'java'),'-cp',str(OUT),'ReplayReads',str(recording)]
    process=subprocess.run(command,text=True,capture_output=True);assert process.returncode==0,process.stderr
    commands.append({'command':command,'exitCode':process.returncode,'stdout':process.stdout,'stderr':process.stderr})
    replay=json.loads(process.stdout);expected=52428800*len(c['requests'])*(1 if c['corrupt'] else 2)
    assert replay['targetBytes']==expected
    generated=json.loads((OUT/'capacity-observations'/(c['label']+'-reads.json')).read_text())
    assert generated['measurementAvailable'] and generated['targetFileReadBytes']==expected
    cases.append({'label':c['label'],'requests':len(c['requests']),'queriesPerRequest':expectedQueries,'replayedLogicalReadBytes':replay['targetBytes'],'rawJfrSha256':hashlib.sha256(recording.read_bytes()).hexdigest()})
assert (good,bad)==(42,42)
write('observation-check.json',{'result':'passed','currentAndFrozenDownload':downloads,'summaryPrefixPairs':pairs,'actualParentLock':lock,'capacityGroups':cases,'validComplete50MiBResponses':good,'corruptRejectedBeforeResponse':bad,'independentlyReparsedRawJfrFiles':len(cases),'note':'Actual current-candidate fresh run and independent raw JFR replay; not production SLA/physical IO/RSS/full HTTP/JWT/freeze/migration/all-account certification.'})
write('reparse-commands.json',commands)
print(json.dumps({'result':'passed','downloads':downloads,'valid':good,'corrupt':bad,'rawJfrReplayed':len(cases)},ensure_ascii=False))
