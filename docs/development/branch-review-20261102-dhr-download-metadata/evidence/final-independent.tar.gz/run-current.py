import datetime, hashlib, json, os, pathlib, shutil, subprocess, time, traceback, xml.etree.ElementTree as ET

ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
WORK=pathlib.Path('/tmp/edhr-dhr-metadata-final-main-worktree-20261102')
OUT=pathlib.Path('/tmp/edhr-dhr-metadata-final-qa-20261102')
HEAD='b5cbdf076dbb55e57ba1ae93837d721da4940778'
BASE='8ec8391721858a7f96d73a5d293d93f43679118a'
NAME='edhr-dhr-metadata-final-main-20261102'
OUT.mkdir(exist_ok=True,parents=True)
COMMANDS=[]
def call(args,cwd=ROOT):
    p=subprocess.run(args,cwd=cwd,text=True,capture_output=True)
    COMMANDS.append({'command':args,'cwd':str(cwd),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    if p.returncode:raise RuntimeError(f'command failed: {args}: {p.stderr[-1500:]}')
    return p.stdout.strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def snapshot_reports(tests,label,started):
    folder=OUT/(label+'-surefire');folder.mkdir(exist_ok=True)
    totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[]
    reports=WORK/('tools/knowledge-model/target/surefire-reports' if label=='knowledge' else 'gmp-platform/backend/target/surefire-reports')
    found=list(reports.glob('TEST-*.xml'))
    if tests:found=[p for p in found if any(p.name.endswith('.'+n+'.xml') for n in tests)]
    found=[p for p in found if p.stat().st_mtime>=started.timestamp()]
    for p in sorted(found):
        shutil.copy2(p,folder/p.name);doc=ET.parse(p).getroot();counts={k:int(doc.attrib.get(k,0)) for k in totals}
        classes.append({'class':doc.attrib['name'],**counts})
        for k in totals:totals[k]+=counts[k]
    return {'totals':totals,'classes':classes,'freshReports':len(found)}
def maven(label,args,env,tests=None):
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr']+args
    started=datetime.datetime.now(datetime.timezone.utc)
    with (OUT/(label+'.log')).open('w') as log:res=subprocess.run(command,cwd=WORK,env=env,stdout=log,stderr=subprocess.STDOUT)
    COMMANDS.append({'command':command,'cwd':str(WORK),'started':started.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':res.returncode,'log':label+'.log'})
    summary=snapshot_reports(tests,label,started);summary['exitCode']=res.returncode
    return summary
created_work=False;created_db=False;summary={};error=None
try:
    assert not WORK.exists(),'own worktree path already exists'
    call(['git','worktree','add','--detach',str(WORK),HEAD]);created_work=True
    assert call(['git','rev-parse','HEAD'],WORK)==HEAD
    assert not call(['git','status','--porcelain=v1'],WORK)
    files=[p for p in subprocess.check_output(['git','ls-files','-z'],cwd=WORK,text=True).split('\0') if p and p!='docs/development/branch-review-20261015/NEXT.md']
    protected=[]
    for p in files:
        b=(WORK/p).read_bytes();protected.append({'path':p,'bytes':len(b),'sha256':sha(b)})
    write('protected-manifest.json',{'candidate':HEAD,'excludedPaths':['docs/development/branch-review-20261015/NEXT.md (L0 progress only)'],'files':protected})
    (WORK/'gmp-platform/frontend/node_modules').symlink_to(ROOT/'gmp-platform/frontend/node_modules',target_is_directory=True)
    cid=call(['docker','run','--rm','-d','--name',NAME,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']);created_db=True
    for _ in range(120):
        if subprocess.run(['docker','exec',NAME,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('own PG did not become TCP-ready')
    port=call(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',NAME])
    db=f'jdbc:postgresql://127.0.0.1:{port}/edhr_dhr_attachment_transaction_test'
    write('database.json',{'containerName':NAME,'containerId':cid,'jdbcUrl':db,'version':call(['docker','exec',NAME,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT version()']),'collation':call(['docker','exec',NAME,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT datcollate FROM pg_database WHERE datname=current_database()'])})
    env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=db,EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',EDHR_DOWNLOAD_METADATA_OUTPUT=str(OUT/'download-observations'),EDHR_ATTACHMENT_QUERY_OUTPUT=str(OUT/'query-observations'))
    tests='DhrAttachmentDownloadMetadataPostgresTest,DhrWorkbenchPermissionsTest,DhrAttachmentAndArchiveTest,DhrAttachmentTransactionPostgresTest,DhrSummaryServiceTest,DhrAttachmentQueryObservationPostgresTest,DhrAttachmentWriteFailureTest,DhrReviewLifecycleIntegrationTest,DhrFormFilesTest,ExecutionAccessTest'.split(',')
    summary['backend']=maven('backend',['-f','gmp-platform/backend/pom.xml','-Dtest='+','.join(tests),'test'],env,tests)
    assert summary['backend']['totals']=={'tests':80,'failures':0,'errors':0,'skipped':0} and summary['backend']['exitCode']==0,summary['backend']
    env['EDHR_ATTACHMENT_CAPACITY_OUTPUT']=str(OUT/'capacity-observations')
    summary['capacity']=maven('capacity',['-f','gmp-platform/backend/pom.xml','-Dtest=DhrAttachmentDownloadCapacityPostgresTest','-DargLine=-Xmx2g','test'],env,['DhrAttachmentDownloadCapacityPostgresTest'])
    assert summary['capacity']['totals']=={'tests':1,'failures':0,'errors':0,'skipped':0} and summary['capacity']['exitCode']==0,summary['capacity']
    summary['knowledge']=maven('knowledge',['-f','tools/knowledge-model/pom.xml','test'],env)
    assert summary['knowledge']['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0} and summary['knowledge']['exitCode']==0,summary['knowledge']
    preserved=[]
    for item in protected:
        b=(WORK/item['path']).read_bytes()
        if len(b)!=item['bytes'] or sha(b)!=item['sha256']:preserved.append(item['path'])
    write('source-preservation.json',{'protectedPaths':len(protected),'changedPaths':preserved,'allEqual':not preserved})
    assert not preserved
except Exception as e:
    error={'type':type(e).__name__,'message':str(e),'traceback':traceback.format_exc()};write('runner-error.json',error)
finally:
    cleanup={'ownedContainerName':NAME,'ownedWorktree':str(WORK)}
    if created_db:
        try:
            cleanup['dockerStop']=call(['docker','stop',NAME]);removed=False
            for _ in range(50):
                if subprocess.run(['docker','inspect',NAME],capture_output=True).returncode!=0:removed=True;break
                time.sleep(.1)
            cleanup['containerRemoved']=removed
        except Exception as e:cleanup['containerCleanupError']=str(e)
    if created_work:
        try:
            link=WORK/'gmp-platform/frontend/node_modules'
            if link.is_symlink():link.unlink()
            cleanup['statusBeforeRemove']=call(['git','status','--porcelain=v1'],WORK)
            assert not cleanup['statusBeforeRemove']
            call(['git','worktree','remove',str(WORK)]);cleanup['worktreeRemovedNormally']=not WORK.exists()
        except Exception as e:cleanup['worktreeCleanupError']=str(e)
    write('cleanup.json',cleanup);write('commands.json',COMMANDS);write('test-summary.json',summary)
print(json.dumps({'summary':summary,'error':error,'cleanup':cleanup},ensure_ascii=False))
if error:raise SystemExit(1)
