FINAL: passed

Old source eb9faf1202fa6cda23264efbe8b3fcb493b471b3 with exact candidate controller-level test from b5cbdf076dbb55e57ba1ae93837d721da4940778.
Actual expected control: True. Two SQL-count assertion reds (4 expected vs5;5 expected vs6), nine positive cases, zero errors/skips are required.
No fixes performed. Test output/log/XML/SQL/old source snapshots and cleanup retained. This result does not claim old tests all pass or current implementation is accepted.
