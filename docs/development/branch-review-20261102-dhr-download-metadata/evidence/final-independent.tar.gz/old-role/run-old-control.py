import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import traceback
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-dhr-metadata-final-qa-20261102/old-role')
WORKTREE = Path('/tmp/edhr-dhr-metadata-final-old-worktree-20261102')
CONTAINER = 'edhr-dhr-metadata-final-old-20261102'
OLD = 'eb9faf1202fa6cda23264efbe8b3fcb493b471b3'
CANDIDATE = 'b5cbdf076dbb55e57ba1ae93837d721da4940778'
TARGET = '8ec8391721858a7f96d73a5d293d93f43679118a'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadMetadataPostgresTest.java'
OUT.mkdir(parents=True, exist_ok=True)
commands = []
created_worktree = created_container = False
expected = False
failure = None
cleanup = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def run(args, cwd=ROOT, check=True):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(args, cwd=cwd, text=True, capture_output=True)
    commands.append({'command':args, 'cwd':str(cwd), 'started':started, 'exitCode':result.returncode,
                     'stdout':result.stdout, 'stderr':result.stderr})
    if check and result.returncode:
        raise RuntimeError('Command failed: '+repr(args)+'\n'+result.stderr)
    return result

def write(name, data):
    (OUT/name).write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')

try:
    assert not WORKTREE.exists(), 'Owned old worktree path unexpectedly exists'
    run(['git', 'fetch', 'origin', 'edhr-dev'])
    assert run(['git','rev-parse','origin/edhr-dev']).stdout.strip() == TARGET
    assert run(['git','rev-parse','HEAD']).stdout.strip() == CANDIDATE
    assert not run(['git','status','--porcelain=v1']).stdout.strip()
    contract_paths = ['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md']
    assert not run(['git','diff','--name-only',OLD,CANDIDATE,'--']+contract_paths).stdout.strip()
    test_bytes = subprocess.check_output(['git','show',CANDIDATE+':'+TEST], cwd=ROOT)
    run(['git','worktree','add','--detach',str(WORKTREE),OLD]); created_worktree = True
    (WORKTREE/TEST).write_bytes(test_bytes)
    link = WORKTREE/'gmp-platform/frontend/node_modules'
    assert not link.exists() and not link.is_symlink()
    link.symlink_to(ROOT/'gmp-platform/frontend/node_modules', target_is_directory=True)
    assert run(['git','rev-parse','HEAD'],cwd=WORKTREE).stdout.strip() == OLD
    assert not run(['git','diff','--name-only'],cwd=WORKTREE).stdout.strip()
    paths = contract_paths + [
        'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
        'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentAndArchiveTest.java',
        'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrWorkbenchPermissionsTest.java',
        'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']
    fingerprints = []
    for path in paths:
        data = (WORKTREE/path).read_bytes()
        baseline = subprocess.check_output(['git','show',OLD+':'+path], cwd=ROOT)
        assert data == baseline, path
        fingerprints.append({'path':path,'bytes':len(data),'sha256':sha(data),'equalOldGitBlob':True})
        dest=OUT/'source-snapshot'/path; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    dest=OUT/'source-snapshot'/TEST; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(test_bytes)
    write('baseline.json',{'oldSource':OLD,'candidateTestSource':CANDIDATE,'target':TARGET,'contractReadCommit':CANDIDATE,
        'oldTree':run(['git','rev-parse','HEAD^{tree}'],cwd=WORKTREE).stdout.strip(),
        'oldTrackedChanges':[],'initialWorktreeStatus':run(['git','status','--porcelain=v1'],cwd=WORKTREE).stdout,
        'portedTest':{'path':TEST,'bytes':len(test_bytes),'sha256':sha(test_bytes),'exactCandidateBytes':True},
        'sourceFingerprints':fingerprints,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0'})
    cid = run(['docker','run','--rm','-d','--name',CONTAINER,'-e','POSTGRES_HOST_AUTH_METHOD=trust',
        '-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']).stdout.strip()
    created_container = True
    for _ in range(120):
        ready = subprocess.run(['docker','exec',CONTAINER,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True)
        if ready.returncode == 0: break
        time.sleep(.5)
    else: raise RuntimeError('Own PG TCP did not become ready')
    port = run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',CONTAINER]).stdout.strip()
    url='jdbc:postgresql://127.0.0.1:'+port+'/edhr_dhr_attachment_transaction_test'
    pg_version=run(['docker','exec',CONTAINER,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT version()']).stdout.strip()
    env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=url,
        EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',
        EDHR_DOWNLOAD_METADATA_OUTPUT=str(OUT/'observations'))
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml',
        '-Dtest=DhrAttachmentDownloadMetadataPostgresTest','test']
    started=datetime.datetime.now(datetime.timezone.utc)
    with (OUT/'maven.log').open('w') as log:
        result=subprocess.run(command,cwd=WORKTREE,env=env,stdout=log,stderr=subprocess.STDOUT)
    finished=datetime.datetime.now(datetime.timezone.utc)
    write('run.json',{'command':command,'workingDirectory':str(WORKTREE),'oldSource':OLD,'candidateTestSource':CANDIDATE,
        'started':started.isoformat(),'finished':finished.isoformat(),'exitCode':result.returncode,
        'databaseUrl':url,'postgresVersion':pg_version,'containerId':cid})
    xml_path=WORKTREE/'gmp-platform/backend/target/surefire-reports/TEST-com.zencas.edhr.production.service.DhrAttachmentDownloadMetadataPostgresTest.xml'
    assert xml_path.exists() and xml_path.stat().st_mtime >= started.timestamp(), 'No fresh actual XML'
    shutil.copy2(xml_path,OUT/xml_path.name)
    suite=ET.parse(xml_path).getroot()
    counts={k:int(suite.attrib.get(k,0)) for k in ['tests','failures','errors','skipped']}
    red=[];positive=[]
    for case in suite.findall('testcase'):
        f=case.find('failure')
        if f is None:positive.append(case.attrib['name'])
        else:red.append({'name':case.attrib['name'],'type':f.attrib.get('type'),'text':f.text or ''})
    expected = (result.returncode==1 and counts=={'tests':11,'failures':2,'errors':0,'skipped':0}
        and len(red)==2 and len(positive)==9
        and all('validResponseReusesNameAndRetainsBothDhrReads' in c['name'] for c in red)
        and any('Expected size: 4 but was: 5' in c['text'] for c in red)
        and any('Expected size: 5 but was: 6' in c['text'] for c in red))
    write('test-summary.json',{'counts':counts,'expectedNegativeControlObserved':expected,
        'assertionFailures':red,'positiveCases':positive,'meaning':'Passed control means two genuine SQL-count assertion reds and nine positives; old product tests are not all passing.'})
    assert not run(['git','diff','--name-only'],cwd=WORKTREE).stdout.strip()
    assert (WORKTREE/TEST).read_bytes()==test_bytes
    write('source-preservation.json',{'trackedFilesStillEqualOld':True,'oldHead':OLD,'portedTestStillExactCandidate':True,
        'statusBeforeCleanup':run(['git','status','--porcelain=v1'],cwd=WORKTREE).stdout})
except Exception:
    failure=traceback.format_exc();(OUT/'orchestration-error.txt').write_text(failure)
finally:
    if created_container:
        stop=run(['docker','stop',CONTAINER],check=False)
        removed=False
        for _ in range(40):
            if subprocess.run(['docker','inspect',CONTAINER],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode != 0:
                removed=True;break
            time.sleep(.1)
        cleanup.update(ownedContainer=CONTAINER,stopExit=stop.returncode,containerRemoved=removed)
    if created_worktree:
        link=WORKTREE/'gmp-platform/frontend/node_modules'
        if link.is_symlink():link.unlink()
        p=WORKTREE/TEST
        if p.exists() and p.read_bytes()==test_bytes:p.unlink()
        status=run(['git','status','--porcelain=v1'],cwd=WORKTREE).stdout
        cleanup['statusAfterOwnPortAndLinkRemoved']=status
        if not status.strip():
            removal=run(['git','worktree','remove',str(WORKTREE)],check=False)
            cleanup.update(worktreeRemoved=not WORKTREE.exists(),normalRemovalExit=removal.returncode)
        else:cleanup.update(worktreeRemoved=False,reason='Unexpected changes retained; no force cleanup')
    write('cleanup.json',cleanup)
    write('commands.json',commands)
    final={'result':'passed' if expected and not failure and cleanup.get('containerRemoved') and cleanup.get('worktreeRemoved') else 'failed',
        'status':'FINAL','scope':'Independent exact old-source SQL-count negative control only','oldSource':OLD,'candidateTestSource':CANDIDATE,
        'contractBaseline':{'sourceCommit':OLD,'targetBranch':'edhr-dev','targetCommit':TARGET,'contractReadCommit':CANDIDATE,'uncommittedContractPaths':[]},
        'expectedTwoAssertionRedsNinePositives':expected,'orchestrationError':bool(failure),'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0',
        'limitations':['Not current-candidate validation, full HTTP/RBAC, full successful freeze, full migrations, production SLA, whole audit or knowledge semantics.',
            'No product/test/fixture/config repairs or repository writes; exactly one unchanged test port into owned old tree.'],
        'findings':[],'cleanup':cleanup}
    write('result.json',final)
    report='FINAL: '+final['result']+'\n\nOld source '+OLD+' with exact candidate controller-level test from '+CANDIDATE+'.\n'
    report+='Actual expected control: '+str(expected)+'. Two SQL-count assertion reds (4 expected vs5;5 expected vs6), nine positive cases, zero errors/skips are required.\n'
    report+='No fixes performed. Test output/log/XML/SQL/old source snapshots and cleanup retained. This result does not claim old tests all pass or current implementation is accepted.\n'
    (OUT/'FINAL.md').write_text(report)
    items=[]
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and p.name!='manifest.json':
            b=p.read_bytes();items.append({'path':str(p.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
    write('manifest.json',{'status':'FINAL','result':final['result'],'artifactCount':len(items),'artifacts':items})
    print(json.dumps({'result':final['result'],'expectedControl':expected,'manifestSha256':sha((OUT/'manifest.json').read_bytes()),'artifacts':len(items)},ensure_ascii=False))
    if failure:print(failure)
