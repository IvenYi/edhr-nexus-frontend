from pathlib import Path
import json, hashlib, re, yaml

OUT=Path('/tmp/edhr-dhr-metadata-final-qa-20261102/old-role')
result=json.loads((OUT/'result.json').read_text())
summary=json.loads((OUT/'test-summary.json').read_text())
baseline=json.loads((OUT/'baseline.json').read_text())
cleanup=json.loads((OUT/'cleanup.json').read_text())
assert result['result']=='passed' and result['expectedTwoAssertionRedsNinePositives']
assert summary['counts']=={'tests':11,'failures':2,'errors':0,'skipped':0}
observations=[]
for item in summary['assertionFailures']:
    sql=re.findall(r'"(SELECT[^\"]+)"',item['text'])
    frozen=any('FROM dhr_summary_version ' in query for query in sql)
    assert len(sql)==(6 if frozen else 5),sql
    assert sum(query.startswith('SELECT status,summary_status FROM dhr_instance ') for query in sql)==2
    assert sql[-1].startswith('SELECT original_name FROM dhr_attachment ')
    assert sql[-2].startswith('SELECT stored_path,sha256 FROM dhr_attachment ')
    assert sql[1].startswith('SELECT active,sha256 FROM dhr_attachment ')
    observations.append({'test':item['name'],'frozen':frozen,'oldObservedQueries':len(sql),
        'newExpectedQueries':5 if frozen else 4,'sql':sql,'readContext':'Actual old proxy/controller/nativePG/resource path before SQL-count assertion failure.'})
assert {item['frozen'] for item in observations}=={False,True}
(OUT/'sql-evidence.json').write_text(json.dumps({'observations':observations,'unknownSqlObserved':False,'negativeControlOnly':True},ensure_ascii=False,indent=2)+'\n')

checks=[]
def check(id,category,description,method,command,evidence):
    checks.append({'id':id,'required':True,'category':category,'description':description,
        'method':method,'command':command,'outcome':'passed','evidence':evidence})
check('check.old-source-baseline','documentation','Independent old eb9 tree and unchanged tracked files; contract bytes equal actual read b5 baseline.',
      'command','git rev-parse/diff/status; raw SHA checks',['baseline.json','source-preservation.json','commands.json'])
check('check.exact-candidate-test-port','regression','Exactly one controller-level test port has candidate raw bytes; old API tests and all tracked product files unchanged.',
      'inspection','Exact raw Git blob/test comparison',['baseline.json','source-snapshot/','source-preservation.json'])
check('check.actual-old-native-negative-control','database','Actual Maven/PG runs11: two intended query-count assertion reds and nine positives, zero errors/skips. This is not an all-passing old suite.',
      'automated-test','bash /workspace/.edhr-cloud-tools/mvn-edhr -f gmp-platform/backend/pom.xml -Dtest=DhrAttachmentDownloadMetadataPostgresTest test',
      ['run.json','maven.log','TEST-com.zencas.edhr.production.service.DhrAttachmentDownloadMetadataPostgresTest.xml','test-summary.json'])
check('check.old-actual-query-sequence','database','Failure raw SQL proves current5/frozen6, each with two DHR reads and final separate filename query; no unknown SQL used.',
      'inspection','Parse original AssertJ failure SQL; compare expected sequence',['sql-evidence.json','test-summary.json'])
check('check.owned-resources-cleanup','documentation','Only copied test and tooling link removed; own old tree removed normally and own PG stopped/removed without force.',
      'command','git status; normal git worktree remove; own docker stop/inspect',['cleanup.json','commands.json'])
quality={'qualityResult':{'result':'passed','baseCommit':baseline['target'],'headCommit':baseline['oldSource'],
    'contractBaseline':result['contractBaseline'],
    'workingTreeState':{'status':'dirty','includedPaths':[baseline['portedTest']['path']],
        'excludedPaths':['gmp-platform/frontend/node_modules (temporary untracked tooling symlink)'],
        'untrackedPaths':[baseline['portedTest']['path'],'gmp-platform/frontend/node_modules']},
    'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],
    'residualRisks':[{'id':'risk.negative-control-only','description':'Validation solely demonstrates intended old-source query-count failure; candidate80/capacity/knowledge run by parent, not this subrole.',
        'impact':'Cannot treat this passed control as old all-tests passing, current implementation acceptance, complete HTTP/RBAC/freeze/migration/production SLA or full audit.',
        'mitigation':'Parent combines this finite old-control evidence with fresh actual current-candidate validation and read-only source/ontology/artifact checks.'}],
    'blockingConditions':[]}}
(OUT/'quality-result.yaml').write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False))
items=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='manifest.json':
        data=path.read_bytes();items.append({'path':str(path.relative_to(OUT)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(OUT/'manifest.json').write_text(json.dumps({'status':'FINAL','result':'passed','oldSource':baseline['oldSource'],
    'candidateTestSource':baseline['candidateTestSource'],'artifactCount':len(items),'artifacts':items,
    'meaning':'Exact independent old-source negative control; original failure evidence preserved without test/fixture edits.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':'passed','counts':summary['counts'],'requiredChecks':len(checks),'artifacts':len(items),
    'manifestSha256':hashlib.sha256((OUT/'manifest.json').read_bytes()).hexdigest()},ensure_ascii=False))
