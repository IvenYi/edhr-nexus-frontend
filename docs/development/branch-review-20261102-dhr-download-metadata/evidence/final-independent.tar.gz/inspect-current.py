import pathlib,subprocess,json,hashlib,re,datetime,yaml
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend');OUT=pathlib.Path('/tmp/edhr-dhr-metadata-final-qa-20261102')
BASE='8ec8391721858a7f96d73a5d293d93f43679118a';HEAD='b5cbdf076dbb55e57ba1ae93837d721da4940778';OLD='eb9faf1202fa6cda23264efbe8b3fcb493b471b3'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def paths(*args):return [p for p in git(*args).decode().split('\0') if p]
def write(n,d):(OUT/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert not git('status','--porcelain=v1').decode().strip()
assert git('rev-parse','origin/edhr-dev').decode().strip()==BASE
contract_paths=['AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture/business-knowledge-model.md']
contract_delta=paths('diff','--name-only','-z',BASE,HEAD,'--',*contract_paths);assert not contract_delta
changed=paths('diff','--name-only','-z',OLD,HEAD)
product=[p for p in changed if p.startswith('gmp-platform/backend/src/main/')]
assert len(product)==3 and all(p.endswith(n) for p,n in zip(sorted(product),['controller/DhrAttachmentController.java','controller/DhrReviewController.java','service/DhrAttachmentService.java']))
src='gmp-platform/backend/src/main/java/com/zencas/edhr/production/'
service=(ROOT/(src+'service/DhrAttachmentService.java')).read_text()
old=git('show',OLD+':'+src+'service/DhrAttachmentService.java').decode()
file_body=service.split('public Path file(')[1].split('@Transactional')[0]
download=service.split('public Download downloadableFile(')[1].split('public record Download')[0]
helper=service.split('private Path verifiedFile(')[1].split('private void ensureDhr')[0]
assert 'SELECT stored_path,sha256 FROM dhr_attachment' in file_body and 'original_name' not in file_body
assert 'return verifiedFile(rows.getFirst())' in file_body
assert download.count('ensureDhr(dhrId, false)')==2
assert download.index('SELECT active,sha256')<download.index('if (versionId != null)')<download.rindex('ensureDhr(dhrId, false)')<download.index('SELECT stored_path,sha256,original_name')<download.index('new Download(verifiedFile(original)')
assert 'attachmentId.toString().equals(attachment.path("id").asText())' in download and 'rows.getFirst().get("sha256").equals(attachment.path("sha256").asText())' in download
assert 'else if (!Boolean.TRUE.equals(rows.getFirst().get("active")))' in download
assert 'Files.isRegularFile(file)' in helper and '!sha256(file).equals(original.get("sha256"))' in helper
assert 'catch (IOException ex) { throw invalid("附件无法读取"); }' in helper
for text in ['附件丢失或摘要不一致','附件无法读取']:
    assert text in old and text in helper
assert 'public String originalName(' not in service
consumers=[];updates=[]
for p in (ROOT/'gmp-platform/backend/src/main').rglob('*.java'):
    s=p.read_text()
    for i,line in enumerate(s.splitlines(),1):
        if '.downloadableFile(' in line:consumers.append({'path':str(p.relative_to(ROOT)),'line':i,'text':line.strip()})
        if re.search(r'UPDATE\s+dhr_attachment',line,re.I):updates.append({'path':str(p.relative_to(ROOT)),'line':i,'text':line.strip()})
assert len(consumers)==2 and len(updates)==2
review=(ROOT/(src+'controller/DhrReviewController.java')).read_text().split('public ResponseEntity<FileSystemResource> attachment(')[1].split('@PostMapping')[0]
assert review.index('service.detail(id)')<review.index('attachments.downloadableFile(')<review.index('ResponseEntity.ok()')
for ctl in ['DhrAttachmentController.java','DhrReviewController.java']:
    text=(ROOT/(src+'controller/'+ctl)).read_text()
    assert '.filename(file.originalName(), java.nio.charset.StandardCharsets.UTF_8)' in text and '.body(new FileSystemResource(file.path()))' in text
    assert '"X-Content-Type-Options", "nosniff"' in text and 'MediaType.APPLICATION_OCTET_STREAM' in text
for unchanged in ['service/DhrSummaryService.java','service/DhrArchiveService.java','service/DhrReviewService.java']:
    assert (ROOT/(src+unchanged)).read_bytes()==git('show',OLD+':'+src+unchanged)
questions=yaml.safe_load((ROOT/'docs/knowledge/open-questions.yaml').read_text());question_rows=[]
def collect(value):
    if isinstance(value,dict):
        if isinstance(value.get('id'),str) and value['id'].startswith('question.'):question_rows.append(value)
        for v in value.values():collect(v)
    elif isinstance(value,list):
        for v in value:collect(v)
collect(questions)
relevant=[q for q in question_rows if any(w in q['id'] for w in ['dhr','record-control','multi-tenant'])]
write('open-question-scope.json',{'fileSha256':sha((ROOT/'docs/knowledge/open-questions.yaml').read_bytes()),'allQuestionIds':[q['id'] for q in question_rows],'affectedContextReviewed':relevant,'note':'Parsed full asset and reviewed affected DHR/record-control/tenant unresolved scope. No claim all question semantics closed.'})
package=yaml.safe_load((ROOT/'docs/development/branch-review-20261102-dhr-download-metadata/decision-package.yaml').read_text())['decisionPackage']
assert package['impactAnalysis']['level']=='L2' and not package['unresolved'] and not package['replacementScopes']
write('baseline-inspection.json',{'baseCommit':BASE,'headCommit':HEAD,'contractReadCommit':HEAD,'contractDelta':contract_delta,'workingTreeStatus':'clean','incrementBase':OLD,'incrementChangedPaths':changed,'testedIncludesEarlierQueryDiagnostic':True,'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','observationAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
write('source-inspection.json',{'result':'passed','candidate':HEAD,'downloadConsumers':consumers,'currentAttachmentUpdateLines':updates,'checks':[
    'Only3 runtime files changed; no UI/schema/permission/knowledge/contract changes.',
    'Two DHR existence read moments retained around active/frozen membership; task detail resolves/authorizes before attachment lookup.',
    'Frozen id+SHA and current active checks retained; file existence and full streaming SHA precede response construction.',
    'Name read intentionally moved from standalone query after SHA into last metadata query before SHA; not all field read timing is identical.',
    'file Path contract/two-column SQL retained; private helper preserves old checks/errors; no original-name fixture fallback.',
    'Controller URL/parameters/type/content disposition/nosniff/body are preserved; internal Download is not a JSON response.',
    'Old assertion changes adapt internal Path only; method-security negative case adds task-first refusal, no weakened assertion.',
    'Summary/Archive/ReviewService bytes unchanged; Summary5+2N and archive array/PDF memory remain separate.',
    'Finite A23: needed guards retained, single filename query folded, no caching/framework/wrapper/index added; no global audit closure.'
],'limits':['Current production interfaces do not rename attachment originals, not a permanent policy.','Native tests and method-security proxy tests do not certify full HTTP/JWT/browser/all-account matrix.','Old high/A12/four gaps/W6 old-reviewed/W7/user pauses remain.'],'requiredPriorPolicy':['DEC-0063-10','DEC-0063-11','rule.dhr-review-task-frozen-attachment-download','fact.dhr-summary.review-task-attachment-authorized']})
whitespace=subprocess.run(['git','-c','core.whitespace=cr-at-eol','diff','--check',BASE,HEAD],cwd=ROOT,text=True,capture_output=True)
write('whitespace.json',{'command':['git','-c','core.whitespace=cr-at-eol','diff','--check',BASE,HEAD],'exitCode':whitespace.returncode,'stdout':whitespace.stdout,'stderr':whitespace.stderr});assert whitespace.returncode==0
print(json.dumps({'sourceResult':'passed','productPaths':len(product),'consumers':len(consumers),'questionsParsed':len(question_rows),'relevantUnresolved':len(relevant)},ensure_ascii=False))
