import pathlib, subprocess, hashlib, json, tarfile, io, csv, re, collections, xml.etree.ElementTree as ET, yaml

ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-dhr-metadata-final-qa-20261102/artifact-role')
HEAD='b5cbdf076dbb55e57ba1ae93837d721da4940778'
BASE='8ec8391721858a7f96d73a5d293d93f43679118a'
OLD='eb9faf1202fa6cda23264efbe8b3fcb493b471b3'
EC='ec72883796766eba1c693b2d023bf8d112d86564'
NEW=ROOT/'docs/development/branch-review-20261102-dhr-download-metadata'
QUERY=ROOT/'docs/development/branch-review-20261102-dhr-attachment-query'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def digest(b):return hashlib.sha256(b).hexdigest()
def write(name,data):(OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def tree(ref):
    result={}
    for row in git('ls-tree','-r','-z',ref).split(b'\0'):
        if row:
            meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split()
            assert kind=='blob';result[path.decode()]={'mode':mode,'oid':oid}
    return result
def bloboid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
trees={ref:tree(ref) for ref in (HEAD,BASE,OLD,EC)}
cache={}
def original(ref,path):
    key=(ref,path)
    if key not in cache:
        current=ROOT/path
        if path in trees[HEAD] and trees[HEAD][path]['oid']==trees[ref][path]['oid']:
            b=current.read_bytes();assert bloboid(b)==trees[ref][path]['oid'];cache[key]=b
        else:cache[key]=git('show',ref+':'+path)
    return cache[key]
def checked_archive(folder,manifest_name,key):
    manifest=json.loads((folder/manifest_name).read_bytes())
    archive=folder/manifest['archive']['path'];data=archive.read_bytes()
    assert len(data)==manifest['archive']['bytes'] and digest(data)==manifest['archive']['sha256']
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        names=tar.getnames();assert len(names)==len(set(names))
        assert all(x.isfile() and not pathlib.PurePosixPath(x.name).is_absolute() and '..' not in pathlib.PurePosixPath(x.name).parts for x in tar.getmembers())
        members={x.name:tar.extractfile(x).read() for x in tar.getmembers()}
    for item in manifest[key]:
        b=members[item['member']];assert len(b)==item['bytes'] and digest(b)==item['sha256'],item['member']
    assert set(members)=={x['member'] for x in manifest[key]}|{'manifest.json'}
    return manifest,members
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','origin/edhr-dev').decode().strip()==BASE
assert not git('status','--porcelain=v1').strip()
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md']
assert not git('diff','--name-only',BASE,HEAD,'--',*contracts,'docs/knowledge').strip()
baseline={'contractBaseline':{'sourceCommit':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':HEAD,'uncommittedContractPaths':[]},'clean':True,'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','noContractOrKnowledgeDiff':True}
write('baseline.json',baseline)

manifest,m=checked_archive(NEW,'evidence-manifest.json','rawArtifacts')
assert len(manifest['rawArtifacts'])==96 and len(m)==97
inner=json.loads(m['manifest.json']);assert inner=={k:v for k,v in manifest.items() if k!='archive'}
ontmanifest=json.loads(m['ontology/manifest.json']);assert ontmanifest['artifactCount']==21 and ontmanifest['allSubrolesFinal']
for item in ontmanifest['artifacts']:
    b=m['ontology/'+item['path']];assert len(b)==item['rawBytes'] and digest(b)==item['sha256']
boundary=json.loads(m['ontology/boundary-role/manifest.json'])
for item in boundary['artifacts']:
    b=m['ontology/boundary-role/'+item['path']];assert len(b)==item['bytes'] and digest(b)==item['sha256']
subroles=json.loads(m['ontology/subroles.json']);assert subroles['allSubrolesFinal']
for role in subroles['roles']:
    assert role['status']=='FINAL'
    assert digest(m['ontology/'+role['evidenceDirectory']+'/manifest.json'])==role['originalManifestSha256']
write('artifact-byte-check.json',{'rawArtifactCount':96,'safeUniqueTarMembers':97,'archiveStoredBytes':manifest['archive']['bytes'],'archiveStoredSha256':digest((NEW/manifest['archive']['path']).read_bytes()),'innerManifestMatches':True,'ontologyRawArtifacts':21,'ontologyChildArtifacts':boundary['artifactCount'],'allHashChecksPassed':True,'noRuntimeExecutedByThisRole':True})

source=json.loads((NEW/'source-review.json').read_bytes())
assert len(source['sourceFingerprints'])==11 and source['wholeFileCompletion']==0 and source['historicalUniqueIncrement'] is None
for item in source['sourceFingerprints']:
    b=original(HEAD,item['path']);assert len(b)==item['bytes'] and digest(b)==item['sha256']
    assert m['source-snapshot/'+item['path']]==b
ontsource=json.loads(m['ontology/source-manifest.json']);assert len(ontsource['files'])==25
for item in ontsource['files']:
    b=original(HEAD,item['path']);assert len(b)==item['rawBytes'] and digest(b)==item['sha256']
for label in ('main','capacity','old'):
    run=json.loads(m[label+'/run.json']);assert run['sourceCommit']==OLD and run['targetCommit']==BASE
    for item in run['sourceFingerprints']:
        is_port=item['path'].endswith('/DhrAttachmentDownloadMetadataPostgresTest.java')
        ref=OLD if label=='old' and not is_port else HEAD
        b=original(ref,item['path']);assert len(b)==item['bytes'] and digest(b)==item['sha256']
        if label=='old':assert m['old/source-snapshot/'+item['path']]==b
write('source-fingerprint-check.json',{'currentSourceSnapshots':11,'ontologySourceFingerprints':25,'mainCapacityAndOldRunFingerprintsChecked':True,'oldProductReference':OLD,'portedOldTestReference':HEAD,'allMatched':True,'oldTestWasByteIdenticalControllerLevelPortNotInternalTypeAdaptation':True})

knowledge=json.loads(m['ontology/knowledge-file-manifest.json']);assert knowledge['count']==330 and knowledge['knowledgeModelVersion']=='0.3.25' and knowledge['schemaVersion']=='1.2.0'
actual_knowledge={p for p in trees[HEAD] if p.startswith('docs/knowledge/')}
assert actual_knowledge=={x['path'] for x in knowledge['files']}
for item in knowledge['files']:
    b=original(HEAD,item['path']);assert len(b)==item['rawBytes'] and digest(b)==item['sha256']
    assert item['gitBlob']==trees[HEAD][item['path']]['oid']==trees[BASE][item['path']]['oid']==trees[OLD][item['path']]['oid']
    assert item['bytesEqualStartCommit']
ontology=yaml.safe_load(m['ontology/ontology-result.yaml'])['ontologyResult'];assert ontology['result']=='not-applicable'
assert ontology['baselineBefore']==ontology['baselineAfter']=='0.3.25'
assert ontology['changedArtifacts']==ontology['knowledgeSync']==ontology['conflicts']==ontology['questions']==[]
assert ontology['roadmapProgress']['stage']=='P0' and ontology['roadmapProgress']['status']=='in-progress'
selected=yaml.safe_load(m['ontology/selected-original-records.yaml'])['records'];ids=[json.loads(x) for x in m['ontology/id-disposition.jsonl'].decode().splitlines()]
assert len(selected)==len(ids)==14 and {x['id'] for x in selected}=={x['id'] for x in ids}
parsed={}
for item in selected:
    path=item['sourcePath']
    if path not in parsed:parsed[path]=yaml.safe_load(original(HEAD,path))
    node=parsed[path]
    for key,index in re.findall(r'\.([A-Za-z0-9_-]+)|\[([0-9]+)\]',item['sourceLocator']):node=node[key] if key else node[int(index)]
    assert node==item['originalRecord'] and node['id']==item['id']
    assert node['status']==item['originalMaturity'] and item['disposition']=='retained' and item['auditScopeClass']=='finite-current-download-contract-only'
write('knowledge-byte-check.json',{'knowledgeFiles':330,'knowledgeBytesEqualHeadBaseAndOld':True,'modelVersion':'0.3.25','schemaVersion':'1.2.0','ontologyResult':'not-applicable','ontologyRoadmap':'P0/in-progress','finiteSelectedIds':14,'originalRecordLocatorsAndMaturityMatched':True,'wholeLibrarySemanticClosureClaimed':False})

def summary(prefix):
    suites=[ET.fromstring(v) for k,v in m.items() if k.startswith(prefix+'/') and k.endswith('.xml')]
    totals={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ('tests','failures','errors','skipped')}
    return suites,totals
runs={}
for label,expected in [('main',(80,0,0,0)),('capacity',(1,0,0,0)),('old',(11,2,0,0)),('ontology',(89,0,0,0))]:
    suites,totals=summary(label);assert tuple(totals[k] for k in ('tests','failures','errors','skipped'))==expected
    runs[label]={'classes':len(suites),**totals}
old_suite=summary('old')[0][0];fails=[(c.attrib['name'],c.find('failure').text) for c in old_suite.findall('testcase') if c.find('failure') is not None]
assert len(fails)==2 and all('validResponseReusesNameAndRetainsBothDhrReads' in name for name,_ in fails)
assert any('Expected size: 4 but was: 5' in text for _,text in fails) and any('Expected size: 5 but was: 6' in text for _,text in fails)
cap=json.loads(m['capacity/capacity/capacity.json']);assert cap['completed'] and len(cap['cases'])==12
good=bad=0
for case in cap['cases']:
    for req in case['requests']:
        assert len(req['jdbcQueries'])==(5 if case['frozen'] else 4)
        assert all(s!='<unknown>' and not s.startswith('SELECT original_name FROM ') for s in req['jdbcQueries'])
        if case['corrupt']:assert req['bodyBytes']==0 and req['rejectedBeforeBody'];bad+=1
        else:assert req['bodyBytes']==52428800 and not req['rejectedBeforeBody'];good+=1
    reads=json.loads(m['capacity/capacity/'+case['label']+'-reads.json'])
    assert reads['measurementAvailable'] and reads['targetFileReadBytes']==52428800*len(case['requests'])*(1 if case['corrupt'] else 2)
assert (good,bad)==(42,42)
for frozen,name,expected in [(False,'valid-false.json',4),(True,'valid-true.json',5)]:
    obs=json.loads(m['main/observations/'+name]);assert obs['frozen']==frozen and obs['fullBytesAndHeadersPreserved'] and len(obs['sql'])==expected
    assert len([s for s in obs['sql'] if s.startswith('SELECT status,summary_status FROM dhr_instance ')])==2
prefix=json.loads(m['main/query-observations/summary-prefix.json'])['observations'];assert [(x['attachments'],x['queries']) for x in prefix]==[(0,5),(1,7),(10,25),(100,205),(300,605)]
lock=json.loads(m['main/query-observations/parent-lock.json']);assert lock['actualPgLockWaitObserved'] and lock['unlinkCommittedAfterRelease'] and lock['historicalOriginalRetained']
write('archived-runs-check.json',{'archivedXmlTotals':runs,'oldFailuresAreTwoActualQueryCountAssertions':True,'oldPositiveControls':9,'capacityCases':12,'validComplete50MiB':42,'corruptRejected':42,'currentFrozenExplicitQueries':[4,5],'producerReadJsonCoherentWith100And50MiBLogicalRead':True,'jfrFilesHashCheckedNotReparsedByThisRole':12,'summaryPrefixStill5Plus2N':True,'parentLockObservationArchived':True,'runtimeExecutedByThisRole':[],'limits':'Inspection of original archived XML/SQL/JSON and source; not an independent Maven/PG/JFR runtime execution or complete HTTP/full freeze/full migration/production SLA validation.'})

inventory=QUERY/'inventory';data=json.loads((inventory/'inventory-summary.json').read_bytes());coverage=list(csv.DictReader(io.StringIO((inventory/'coverage.csv').read_text(newline=''))))
assert data['sourceCommit']==BASE and len(coverage)==data['trackedPaths']==data['scopeCount']==6785 and not data['semanticReviewComplete']
assert {x['path'] for x in coverage}==set(trees[BASE]) and len({x['path'] for x in coverage})==6785
for row in coverage:
    assert row['baseline_commit']==BASE and row['source_evidence']==trees[BASE][row['path']]['oid']
    assert row['in_scope']=='true' and row['review_depth']=='inventory-only' and row['review_status']=='pending'
assert digest((inventory/'coverage.csv').read_bytes())==data['coverageSha256']
migrations=list(csv.DictReader(io.StringIO((inventory/'migrations.csv').read_text(newline=''))));assert len(migrations)==data['migrationFiles']==135
for row in migrations:assert row['baseline_commit']==BASE and row['blob']==trees[BASE][row['path']]['oid'] and row['status']=='inventory-only'
entrypoints=list(csv.DictReader(io.StringIO((inventory/'entrypoints.csv').read_text(newline=''))));counts=collections.Counter(x['kind'] for x in entrypoints)
assert dict(counts)==data['entrypointCandidates'] and len(entrypoints)==689
for row in entrypoints:
    assert row['baseline_commit']==BASE and row['status']=='candidate-needs-call-chain-review'
    lines=original(BASE,row['path']).decode().splitlines();assert row['source']==lines[int(row['line'])-1].strip()
write('inventory-check.json',{'referenceCommit':BASE,'trackedPathsAndBlobs':6785,'migrationFilesAndBlobs':135,'entrypointSourceRows':689,'entrypointKinds':dict(counts),'coverageAllInventoryOnlyPending':True,'coverageRawSha256':data['coverageSha256'],'reusedSameTargetInventoryNotNewWholeSemanticCoverage':True})

q1,q1m=checked_archive(QUERY,'evidence-manifest.json','artifacts');q2,q2m=checked_archive(QUERY,'final-quality-manifest.json','rawArtifacts')
assert len(q1m)==33 and len(q2m)==38
assert q1['baseCommit']==BASE and q2['testedCandidate']==EC
old_quality=yaml.safe_load((QUERY/'quality-result.yaml').read_bytes())['qualityResult'];assert old_quality['headCommit']==EC and old_quality['baseCommit']==BASE and old_quality['result']=='passed'
old_protected=json.loads((QUERY/'evidence/tested-candidate-protected.json').read_bytes());assert old_protected['candidate']==EC and len(old_protected['files'])==6796
changed_now=[]
for item in old_protected['files']:
    b=original(EC,item['path']);assert len(b)==item['bytes'] and digest(b)==item['sha256']
    if trees[HEAD][item['path']]['oid']!=trees[EC][item['path']]['oid']:changed_now.append(item['path'])
for name,b in q1m.items():
    if name.startswith('source-snapshot/'):
        path=name.removeprefix('source-snapshot/');assert b==original(EC,path)
write('old-stage-check.json',{'queryPrimaryMembers':33,'queryFinalQaMembers':38,'oldQualityReference':EC,'oldQualityNotUsedAsCurrentPass':True,'oldProtectedRawEntriesAgainstOwnCommit':6796,'intendedPathsNowChanged':changed_now,'oldSourceSnapshotsMatchedOwnCommit':True,'oldNestedJfrRuntimeNotReplayed':True})

assert git('rev-parse','HEAD').decode().strip()==HEAD and not git('status','--porcelain=v1').strip()
result={'artifactVerificationResult':{'result':'passed','contractBaseline':baseline['contractBaseline'],'knowledgeBaselineVersion':'0.3.25','scope':'Read-only original artifact, source fingerprint, archived run coherence and fixed inventory verification for final metadata candidate','findings':[],'blockingConditions':[],'repositoryWrites':[],'runtimeTestsExecuted':[],'checks':['97 current tar members/96 artifact hashes plus ontology parent/child manifests','11 current source snapshots,25 ontology source fingerprints,330 knowledge bytes and14 original record locators','Archived XML80/capacity1/knowledge89/old11 with two real query failures and9 positive controls','12 capacity groups/84 request SQL and body/read JSON coherence; raw JFR hashes only','6785 base inventory path/blob,135 migrations and689 candidate source rows','33 old primary/38 old final raw members and6796 old protected entries checked against ec728837 only'],'limitations':['No Maven, PostgreSQL, HTTP, browser or JFR reparse execution by this role','Archive/schema/inventory verification does not imply all-library semantic audit, whole-file A23 closure, production SLA, complete successful freeze, full migration or full authentication matrix','Final combined quality judgement belongs to parent fresh QA with actual independent runtime checks']}}
write('result.json',result)
print(json.dumps({'status':'passed','currentMembers':97,'currentRawArtifacts':96,'currentSnapshots':11,'ontologyFingerprints':25,'knowledgeFiles':330,'finiteIds':14,'inventoryPaths':6785,'migrations':135,'entrypointRows':689,'oldProtected':6796,'oldIntentionallyChanged':len(changed_now)},ensure_ascii=False))
