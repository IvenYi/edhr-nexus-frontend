import pathlib,json,hashlib,shutil,xml.etree.ElementTree as ET,yaml,datetime,subprocess

ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-dhr-metadata-ontology-20261102')
CHILD=pathlib.Path('/tmp/edhr-dhr-metadata-ontology-boundary-20261102')
def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
expected_child='4c94c36c0c9726640a1bf43260140e4fe81c0c91f5659b26c8ec16e26d55ae68'
assert sha((CHILD/'manifest.json').read_bytes())==expected_child
child_manifest=json.loads((CHILD/'manifest.json').read_text())
for file in child_manifest['artifacts']:
    data=(CHILD/file['path']).read_bytes();assert len(data)==file['bytes'] and sha(data)==file['sha256']
shutil.copytree(CHILD,OUT/'boundary-role',dirs_exist_ok=True)
assert 'BUILD SUCCESS' in (OUT/'knowledge-maven.log').read_text()
reports=OUT/'surefire';reports.mkdir(exist_ok=True)
xml=ROOT/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
shutil.copy2(xml,reports/xml.name)
tree=ET.parse(xml).getroot();counts={key:int(tree.attrib.get(key,0)) for key in ['tests','failures','errors','skipped']}
assert counts=={'tests':89,'failures':0,'errors':0,'skipped':0},counts
save('test-summary.json',{'command':['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test'],'exitCode':0,'counts':counts,'scope':'Formal knowledge structure/reference/type/projection suite only; not full semantic or runtime business/HTTP certification.','freshClassTimestamp':tree.attrib.get('timestamp'),'xml':'surefire/'+xml.name})
source=json.loads((OUT/'source-manifest.json').read_text())
changes=[]
for file in source['files']:
    data=(ROOT/file['path']).read_bytes()
    if len(data)!=file['rawBytes'] or sha(data)!=file['sha256']:changes.append(file['path'])
assert not changes,changes
knowledge=json.loads((OUT/'knowledge-file-manifest.json').read_text())
for file in knowledge['files']:
    data=(ROOT/file['path']).read_bytes();assert len(data)==file['rawBytes'] and sha(data)==file['sha256']
save('source-preservation.json',{'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actualHeadNow':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'sourceFingerprintCount':len(source['files']),'sourceChangesSinceCapture':changes,'knowledgeFilesChecked':len(knowledge['files']),'ontologyRepositoryWrites':[],'contractReadCommit':source['contractReadCommit']})
save('subroles.json',{'allSubrolesFinal':True,'roles':[{'task':'/root/dhr_download_metadata_ontology_20261102/metadata_semantic_boundary','status':'FINAL','outcome':'consistent-for-reviewed-scope','runtimeTestsExecuted':[],'originalManifestSha256':expected_child,'evidenceDirectory':'boundary-role'}]})
result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':'eb9faf1202fa6cda23264efbe8b3fcb493b471b3','targetBranch':'edhr-dev','targetCommit':'8ec8391721858a7f96d73a5d293d93f43679118a','contractReadCommit':'eb9faf1202fa6cda23264efbe8b3fcb493b471b3','uncommittedContractPaths':[]},
 'reason':'用户明确确认的工程优化把original_name合并到最后一次路径/SHA元数据读取并经内部Download载体给两个Controller，省掉单独名字查询；读取名字的时点有意提前，不能声称所有字段读取时点完全相同。两次DHR存在检查、当前active或任务绑定冻结版本id+SHA、完整流式SHA完成后返回、原错误、文件名/头构造及任务detail先授权的业务边界保留。file()的Path接口/原SQL及Summary/Archive调用语义保持；未更改七格式/50MiB、来源、核验、解除历史、冻结/审批/审计/归档/放行政策。本批有限核对14个相关既有ID，无新声明或替代；当前实现没有改名入口只是源码事实，不是永久禁止改名政策。知识330文件字节不变，0.3.25/schema1.2.0/P0进行中不提升；原high/A12/全审队列保留。本体结果不替代主审及fresh最终QA的实际4/5查询、原字节/负例与完整组合验收。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.metadata-knowledge-formal','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test','outcome':'passed','evidence':['knowledge-maven.log','test-summary.json','surefire/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','89 tests, 0 failures/errors/skips; formal schema/reference/type/projection suite, not all-library semantic closure.']},
  {'id':'validation.metadata-policy-boundaries','checkType':'evidence-path','command':'Read original selected knowledge records, current product diff and read-only semantic boundary subrole','outcome':'passed','evidence':['id-disposition.jsonl','selected-original-records.yaml','product-working-tree.diff','boundary-role/result.json','boundary-role/review.md','14 finite IDs retained without maturity or policy replacement.']},
  {'id':'validation.metadata-byte-baseline','checkType':'reference','command':'NUL-delimited git tree/raw SHA-256 inventory and unchanged-blob comparison; final source preservation','outcome':'passed','evidence':['baseline-check.json','knowledge-file-manifest.json','source-manifest.json','source-preservation.json','330 knowledge paths unchanged; 25 actual source fingerprints; inventory does not imply global semantics.']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
(OUT/'FINAL.md').write_text('FINAL: ontologyResult not-applicable. No repository writes or new business policy; 14 existing IDs reviewed only within metadata-download preservation scope. Knowledge0.3.25/schema1.2.0/P0 in-progress;330 file bytes unchanged. Formal knowledge89/89 passed. Read-only child FINAL, no runtime tests claimed by that child. Actual working-tree source25 fingerprints unchanged at final check. Source HEAD at read is eb9faf12; product edits are explicitly represented by source manifests and working-tree diff, not an invented commit. This is not final independent quality, full library semantics, whole-audit closure, production SLA, merge/deploy or lifecycle archive implementation.\n')
artifacts=[]
for file in sorted(OUT.rglob('*')):
    if file.is_file() and file!=OUT/'manifest.json':
        data=file.read_bytes();artifacts.append({'path':str(file.relative_to(OUT)),'rawBytes':len(data),'sha256':sha(data)})
manifest={'status':'FINAL','ontologyResult':'not-applicable','sourceCommitAtRead':source['sourceCommit'],'allSubrolesFinal':True,'artifactCount':len(artifacts),'artifacts':artifacts}
save('manifest.json',manifest)
print(json.dumps({'result':'not-applicable','finiteIds':14,'knowledgeFiles':330,'sourceFiles':25,'knowledgeTests':counts,'rawArtifacts':len(artifacts),'manifestSha256':sha((OUT/'manifest.json').read_bytes())},ensure_ascii=False))
