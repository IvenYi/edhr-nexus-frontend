import pathlib,json,yaml,hashlib,subprocess,datetime

ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-dhr-metadata-ontology-20261102')
START='eb9faf1202fa6cda23264efbe8b3fcb493b471b3'
TARGET='8ec8391721858a7f96d73a5d293d93f43679118a'
def command(args):return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def save(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

checks={
 'term.dhr-controlled-attachment':('保留受控附件术语与来源、摘要、核验及关联历史；内部路径/名字载体不形成新业务来源。',['DhrAttachmentService.file/downloadableFile/verifiedFile']),
 'concept.dhr-controlled-attachment':('受控原件身份不变，不虚构为第四种表单；名字元数据复用不修改资产成熟度。',['DhrAttachmentService.downloadableFile']),
 'relation.dhr-summary-version-contains-controlled-attachments':('冻结版本零到多附件引用关系不变，下载不新增或重写成员。',['DhrAttachmentService.downloadableFile']),
 'DEC-0063-05':('完整冻结证据基准及后续不改写仍保留；本轮不触碰提交、版本目录或source_scope_hash。',['DhrAttachmentService.downloadableFile','DhrSummaryService.submit']),
 'DEC-0063-10':('原字节/SHA、现有权限与冻结引用保持；原件名随最后一次合法原件查询返回仅是用户已确认工程优化。',['DhrAttachmentService.file/downloadableFile/verifiedFile','DhrAttachmentController.download','DhrReviewController.attachment']),
 'DEC-0063-11':('ZIP仍基于冻结成员和原件size/SHA校验；file接口/SQL保留，未套用新的Download载体或移除导出防护。',['DhrArchiveService.export','DhrAttachmentService.file']),
 'DEC-0063-12':('查看/整理/审批授权与原审计语义保持；读取元数据不新增或改变LINK/VERIFY/UNLINK/审批事件。',['DhrAttachmentController.download','DhrReviewController.attachment']),
 'rule.dhr-summary-controlled-attachment-upload':('七格式、52428800字节含边界、原件字节/SHA、解除不删及冻结引用规范未改，upload/verify/unlink无差异。',['DhrAttachmentService.upload/verify/unlink']),
 'rule.dhr-review-task-frozen-attachment-download':('任务detail先授权，服务再核同DHR/版本id+SHA；名字复用不以宽泛DHR查看权替换任务资格。',['DhrReviewController.attachment','DhrReviewService.detail','DhrAttachmentService.downloadableFile']),
 'rule.dhr-summary-freeze-version':('正常冻结不可变与显式版本读取保持，本轮没有版本/目录写入。',['DhrAttachmentService.downloadableFile','DhrSummaryService.submit']),
 'fact.dhr-summary.review-task-attachment-authorized':('事实取值仍由任务detail及绑定冻结版成员校验得出，不根据内部Path载体推定任何额外授权。',['DhrReviewController.attachment','DhrReviewService.detail']),
 'fact.dhr-summary.version-frozen':('冻结行、版本号和检查记录没有本轮改写，下载优化不提升合规/冻结成熟度。',['DhrSummaryService.submit','DhrAttachmentService.downloadableFile']),
 'DEC-0090-01':('下载/ZIP生成副本、汇总冻结与生命周期DHR归档仍为不同概念，本轮不实现归档。',['DhrArchiveService.export']),
 'DEC-0090-04':('归档/解封/放行与受控变更后续边界保持；没有借查询优化关闭旧high/A12或归档TODO。',['DhrArchiveService.export']),
}
schema=yaml.safe_load((ROOT/'docs/knowledge/schema.yaml').read_text())
types={**schema.get('collectionTypes',{}),**schema.get('nestedCollectionTypes',{})}
selected=[]
def walk(value,path,locator='$',record_type=None):
    if isinstance(value,dict):
        if value.get('id') in checks:
            identity=value['id'];note,symbols=checks[identity]
            selected.append({'id':identity,'recordType':record_type,'sourcePath':path,'sourceLocator':locator,'originalMaturity':value.get('status'),'visibility':value.get('visibility'),'auditScopeClass':'finite-current-download-contract-only','reviewStatus':'reviewed','conclusion':'consistent','disposition':'retained','scope':note,'sourceSymbols':symbols,'originalRecord':value,'limit':'Only scoped preservation review; not complete rule execution/full-library semantics, whole-file closure or final independent QA.'})
        for key,item in value.items():walk(item,path,locator+'.'+key,types.get(key,record_type))
    elif isinstance(value,list):
        for i,item in enumerate(value):walk(item,path,f'{locator}[{i}]',record_type)
tree=command(['git','ls-tree','-r','-z',START,'--','docs/knowledge']).split('\0')
knowledge=[]
for entry in tree:
    if not entry:continue
    meta,path=entry.split('\t',1);mode,kind,git_sha=meta.split()
    data=(ROOT/path).read_bytes();actual_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    knowledge.append({'path':path,'rawBytes':len(data),'sha256':sha(data),'gitBlob':git_sha,'bytesEqualStartCommit':actual_blob==git_sha})
    if path.endswith('.yaml'):walk(yaml.safe_load(data),path)
assert len(knowledge)==330 and all(x['bytesEqualStartCommit'] for x in knowledge)
assert {x['id'] for x in selected}==set(checks),set(checks)-{x['id'] for x in selected}
selected.sort(key=lambda x:x['id'])
(OUT/'id-disposition.jsonl').write_text(''.join(json.dumps({k:v for k,v in x.items() if k!='originalRecord'},ensure_ascii=False)+'\n' for x in selected))
(OUT/'selected-original-records.yaml').write_text(yaml.safe_dump({'scope':'finite-current-download-contract-only','records':selected},allow_unicode=True,sort_keys=False))
save('knowledge-file-manifest.json',{'sourceCommit':START,'knowledgeModelVersion':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion'],'count':len(knowledge),'files':knowledge,'limit':'Raw inventory and unchanged-byte check, not full semantic coverage.'})
source_paths={x['sourcePath'] for x in selected}|{
 'AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
 'docs/development/branch-review-20261102-dhr-download-metadata/decision-package.yaml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
 'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadMetadataPostgresTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentAndArchiveTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrWorkbenchPermissionsTest.java'}
fingerprints=[]
for path in sorted(source_paths):
    data=(ROOT/path).read_bytes();fingerprints.append({'path':path,'rawBytes':len(data),'sha256':sha(data)})
save('source-manifest.json',{'sourceCommit':START,'targetCommit':TARGET,'contractReadCommit':START,'uncommittedContractPaths':[],'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':fingerprints,'note':'Actual working-tree source bytes after the explicit metadata-reuse edit; sourceCommit identifies the HEAD at role start, not a fabricated commit for uncommitted edits.'})
diff=subprocess.check_output(['git','diff',START,'--','gmp-platform/backend/src/main/java/com/zencas/edhr/production'],cwd=ROOT)
(OUT/'product-working-tree.diff').write_bytes(diff)
contract_diff=subprocess.check_output(['git','diff',TARGET,START,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture/business-knowledge-model.md','docs/knowledge'],cwd=ROOT)
save('baseline-check.json',{'sourceCommitAtStart':START,'actualHeadAtCapture':command(['git','rev-parse','HEAD']),'targetCommit':TARGET,'contractReadCommit':START,'targetToSourceContractKnowledgeDiffBytes':len(contract_diff),'knowledgeFiles':len(knowledge),'knowledgeBytesEqualStartCommit':True,'knowledgeModelVersion':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion'],'phase':'P0 in-progress; no exit claim','finiteIdChecks':len(selected),'sourceFingerprintCount':len(fingerprints),'ontologyRepositoryWrites':[],'wholeFileCompleteClaims':0,'wholeLibrarySemanticComplete':False,'productDiffSha256':sha(diff)})
assert not contract_diff
print(json.dumps({'finiteIds':len(selected),'sourceFiles':len(fingerprints),'knowledgeFiles':len(knowledge)},ensure_ascii=False))
