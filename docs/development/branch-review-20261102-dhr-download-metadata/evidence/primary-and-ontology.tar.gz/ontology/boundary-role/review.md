# 下载名元数据复用：只读语义边界复核

结论：在本次实际读取的方法范围内，未发现新增业务语义差异。此次为本体角色的只读实现支持，不是最终独立质量门禁；未运行测试，也未修改仓库。

基线为 HEAD `eb9faf1202fa6cda23264efbe8b3fcb493b471b3`、目标 `8ec8391721858a7f96d73a5d293d93f43679118a`，含主审尚未提交的三份产品文件差异。知识仍为 `0.3.25`，本支持不修改任何知识状态或全审覆盖结论。

| 范围 | 实际核对结论 |
| --- | --- |
| `DhrAttachmentService.downloadableFile` | 先查DHR，再读当前附件active/SHA，再分当前active或显式版本id+SHA成员资格，之后仍第二次查DHR、读取原件路径/SHA并完整验证。第二次DHR检查从原file内移到相同调用顺序位置，未删除。 |
| 冻结成员与错误 | tenant、DHR、附件、版本查询谓词及冻结id与SHA同时匹配保持；缺DHR、缺附件、缺版本、非法快照、非成员、当前已解除和原件丢失/摘要不一致的错误字符串保持。 |
| `verifiedFile` / `sha256(Path)` | 文件存在与完整SHA检查被局部抽入私有方法；8KiB读取到EOF并比较完成后才返回Path。`new Download(verifiedFile(original),...)`的第一个实参先完成验证；Controller随后才构造原响应，无提前输出。 |
| `DhrAttachmentService.file` | 仍返回Path，仍保留自身DHR检查及只取stored_path/SHA的原SQL，不因下载名复用给Summary/Archive读取附加original_name要求。仍允许受控历史原件在解除后被既有冻结读者读取。 |
| `DhrAttachmentController.download` | 路由、请求参数、注解授权、octet-stream、attachment disposition及UTF-8文件名、nosniff、FileSystemResource保持；只从内部Download取名字和Path，不将载体或服务器路径作为JSON返回。 |
| `DhrReviewController.attachment` | 仍先`service.detail(id)`，从服务返回的DHR/版本取id，再读原件；菜单注解仍在类级。 |
| `DhrReviewService.detail` | 方法未改；仍通过`pending && eligible`或本人`handled`授权，之后读取绑定版本。eligible使用候选快照/assignee；handled限本人且COMPLETED/REJECTED。未改为普通DHR查看权替代。 |
| `snapshot` | 仍显式投影id/name/MIME/size/SHA/来源/核验/关联元数据，未把stored_path或Download加入JSON。 |

有意变化：`original_name`从验证结束后的独立查询合并到最后一次路径/SHA元数据读取。不能说所有字段的读取时点完全相同；这一变化正是用户确认的工程方案。当前生产接口无改名入口只是当前源码事实，不应提升成永久禁止改名业务政策；未来新增相关写者应增量重审。

本次原始业务依据为`DEC-0063-10`及`rule.dhr-review-task-frozen-attachment-download`，均保留其现行规范含义与成熟度。查询次数4/5可从源码路径推导，但本支持没有执行SQL计数、HTTP、浏览器、容量、并发或全库审计；这些须由主审及最终fresh QA另行验证。没有关闭旧DHR high、A12、W6/W7或用户暂缓项。
