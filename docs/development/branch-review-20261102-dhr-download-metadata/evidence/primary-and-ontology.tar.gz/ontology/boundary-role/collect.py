import pathlib,hashlib,json,subprocess,datetime,yaml
root=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-dhr-metadata-ontology-boundary-20261102')
paths=[
 'AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/rules/dhr-summary.yaml',
 'docs/development/branch-review-20261102-dhr-download-metadata/decision-package.yaml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
rows=[]
for path in paths:
 b=(root/path).read_bytes(); old=subprocess.run(['git','show',head+':'+path],cwd=root,capture_output=True)
 rows.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),
              'headSha256':hashlib.sha256(old.stdout).hexdigest() if old.returncode==0 else None,
              'changedFromHead':old.returncode!=0 or b!=old.stdout})
base={'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':subprocess.check_output(['git','rev-parse','origin/edhr-dev'],cwd=root,text=True).strip(),'contractReadCommit':'eb9faf1202fa6cda23264efbe8b3fcb493b471b3','uncommittedContractPaths':[]}
(out/'source-fingerprints.json').write_text(json.dumps({'contractBaseline':base,'files':rows,'limit':'Raw file fingerprints do not mean whole-file semantic review; reviewed symbols are listed in review.md.'},ensure_ascii=False,indent=2)+'\n')
selected=[]
for path in ['docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/rules/dhr-summary.yaml']:
 d=yaml.safe_load((root/path).read_text()); records=[r for dec in d['decisions'] for r in dec['decisionStatements']] if 'decisions' in d else d['rules']
 selected.extend({'sourcePath':path,'record':r} for r in records if r['id'] in ['DEC-0063-10','rule.dhr-review-task-frozen-attachment-download'])
(out/'selected-knowledge.json').write_text(json.dumps(selected,ensure_ascii=False,indent=2)+'\n')
result={'ontologySupportResult':{'status':'consistent-for-reviewed-scope','contractBaseline':base,'knowledgeBaselineVersion':'0.3.25','scope':'Read-only metadata download source boundary, not final independent QA or all-library ontology audit','reviewedSourceSymbols':['DhrAttachmentService.file','DhrAttachmentService.downloadableFile','DhrAttachmentService.verifiedFile','DhrAttachmentService.sha256(Path)','DhrAttachmentService.snapshot','DhrAttachmentController.download','DhrReviewController.attachment','DhrReviewService.detail/pending/eligible/handled'],'semanticDifferencesFound':[],'explicitEngineeringChange':'original_name is now read with the final path/SHA row; it no longer has a separate post-validation name query. Authorization and digest check moments/order remain.','repositoryWrites':[],'runtimeTestsExecuted':[],'wholeFilesClaimedComplete':0,'report':'review.md','completedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for row in rows: assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
artifacts=[]
for file in sorted(out.iterdir()):
 if file.is_file() and file.name!='manifest.json':
  b=file.read_bytes();artifacts.append({'path':file.name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'status':'FINAL','artifactCount':len(artifacts),'artifacts':artifacts},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':'consistent-for-reviewed-scope','files':len(rows),'artifacts':len(artifacts),'manifestSha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}))
