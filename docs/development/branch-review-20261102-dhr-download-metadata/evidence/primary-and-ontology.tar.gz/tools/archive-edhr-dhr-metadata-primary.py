import pathlib,json,hashlib,tarfile,shutil,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=root/'docs/development/branch-review-20261102-dhr-download-metadata'
stage=pathlib.Path('/tmp/edhr-dhr-metadata-primary-archive-20261102');stage.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
groups={'main':'/tmp/edhr-dhr-metadata-main-20261102','capacity':'/tmp/edhr-dhr-metadata-capacity-20261102','old':'/tmp/edhr-dhr-metadata-old-evidence-20261102','ontology':'/tmp/edhr-dhr-metadata-ontology-20261102'}
for label,folder in groups.items():shutil.copytree(folder,stage/label,dirs_exist_ok=True)
for label,expected in [('main',(80,0,0,0)),('capacity',(1,0,0,0)),('old',(11,2,0,0))]:
 s=json.loads((stage/label/'test-summary.json').read_text());assert tuple(s['totals'][k] for k in ['tests','failures','errors','skipped'])==expected and not s['missingFreshReports']
 assert json.loads((stage/label/'cleanup.json').read_text())['removed']
old=ET.parse(stage/'old/TEST-com.zencas.edhr.production.service.DhrAttachmentDownloadMetadataPostgresTest.xml').getroot()
failures=[(c.attrib['name'],c.find('failure').text) for c in old.findall('testcase') if c.find('failure') is not None]
assert len(failures)==2 and all('validResponseReusesNameAndRetainsBothDhrReads' in name for name,_ in failures)
assert any('Expected size: 4 but was: 5' in text for _,text in failures) and any('Expected size: 5 but was: 6' in text for _,text in failures)
cap=json.loads((stage/'capacity/capacity/capacity.json').read_text());assert cap['completed'] and len(cap['cases'])==12
report=[];good=bad=0
for c in cap['cases']:
 expect=5 if c['frozen'] else 4
 for r in c['requests']:
  assert len(r['jdbcQueries'])==expect and not any(s=='<unknown>' or s.startswith('SELECT original_name FROM ') for s in r['jdbcQueries'])
  if c['corrupt']:assert r['bodyBytes']==0 and r['rejectedBeforeBody'];bad+=1
  else:assert r['bodyBytes']==52428800 and not r['rejectedBeforeBody'];good+=1
 reads=json.loads((stage/'capacity/capacity'/(c['label']+'-reads.json')).read_text())
 assert reads['measurementAvailable'] and reads['targetFileReadBytes']==52428800*len(c['requests'])*(1 if c['corrupt'] else 2)
 report.append({'label':c['label'],'requests':len(c['requests']),'jdbcQueriesPerRequest':expect,'logicalFileReadBytes':reads['targetFileReadBytes']})
assert (good,bad)==(42,42)
tools=stage/'tools';tools.mkdir(exist_ok=True)
for name in ['run-edhr-dhr-metadata.py','build-edhr-dhr-metadata-source.py','archive-edhr-dhr-metadata-primary.py']:shutil.copy2('/tmp/'+name,tools/name)
for item in json.loads((out/'source-review.json').read_text())['sourceFingerprints']:
 p=item['path'];b=(root/p).read_bytes();assert sha(b)==item['sha256'];dest=stage/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
summary={'mainTests':80,'capacityTests':1,'capacityGroups':12,'validComplete50MiBResponses':good,'corruptRejectedBeforeResponse':bad,'oldSame11':{'assertionFailures':2,'positiveControls':9,'errors':0,'skipped':0},'capacity':report,'limits':'In-process actual proxy/controller/PG/resource; four canonical tables/PK, manually seeded frozen version, warm padded PNG and2GiBJVM. JFR logical reads not physical IO; heap not RSS. No complete HTTP/auth/full freeze/full migration/production SLA.'}
(stage/'primary-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
items=[]
for file in sorted(stage.rglob('*')):
 if file.is_file():b=file.read_bytes();items.append({'member':str(file.relative_to(stage)),'bytes':len(b),'sha256':sha(b)})
manifest={'sourceHeadDuringRuns':'eb9faf1202fa6cda23264efbe8b3fcb493b471b3','workingTreeEvidence':'Source/test snapshots identify actual uncommitted implementation used in main/capacity; old source is unchanged eb9 with identical new controller-level test ported.','rawArtifacts':items,'note':'Old run artifacts initially shared own old worktree root; exact files moved by raw-byte copy before normal cleanup. No product/test failure caused. Original output runner retained.'}
(stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
evidence=out/'evidence';evidence.mkdir(exist_ok=True);archive=evidence/'primary-and-ontology.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for file in sorted(stage.rglob('*')):
  if file.is_file():tar.add(file,arcname=str(file.relative_to(stage)),recursive=False)
manifest['archive']={'path':str(archive.relative_to(out)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'rawArtifacts':len(items),'archive':manifest['archive'],'summary':summary},ensure_ascii=False))
