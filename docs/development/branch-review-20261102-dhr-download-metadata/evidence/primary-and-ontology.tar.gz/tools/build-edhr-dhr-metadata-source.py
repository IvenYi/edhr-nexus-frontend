import pathlib,json,hashlib,subprocess
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=root/'docs/development/branch-review-20261102-dhr-download-metadata'
prefix='gmp-platform/backend/src/main/java/com/zencas/edhr/production/'
records=[
 ('service/DhrAttachmentService.java','downloadableFile/Download','Last original query includes name; two DHR reads and activity/frozen id+SHA checks remain; full integrity check precedes return.','Internal value carrier only; no cache/new global guard/compatibility wrapper. Name read intentionally moves before SHA with same final metadata.'),
 ('service/DhrAttachmentService.java','file/verifiedFile','Path result and two-column SQL retained for Summary/Archive; private helper contains original regular-file/SHA/IOException mapping.','No new active restriction on historical file; no extra name column required by unrelated fixture/readers.'),
 ('controller/DhrAttachmentController.java','download','Consume verified path/name; no standalone filename read; original headers and full response bytes protected.','No duplicate validation/controller fallback or public stored-path JSON.'),
 ('controller/DhrReviewController.java','attachment','Task detail still resolves/authorizes DHR+version before downloadableFile.','Menu access cannot replace task qualification; new method-security proxy negative case verifies no original read on task refusal.'),
 ('service/DhrSummaryService.java','submit/parent locks/attachment loop','Unmodified; actual public prefix still5+2N and legitimate unlink waits on parent lock in main regression.','Keep VERIFIED/source hash/manual guard/locks; no batching in this authorization.'),
 ('service/DhrArchiveService.java','export/file call','Unmodified; shared file SQL/type/check unchanged, frozen size/SHA remains separate.','Arrays/PDF accumulation and no equivalent outer lock remain pending, not resolved by filename reuse.'),
]
paths=sorted({prefix+x[0] for x in records}|{
'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadMetadataPostgresTest.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentAndArchiveTest.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrWorkbenchPermissionsTest.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadCapacityPostgresTest.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentQueryObservationPostgresTest.java',
'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql'})
fps=[]
for p in paths:
 b=(root/p).read_bytes();fps.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
obs={p.name:json.loads(p.read_text()) for p in pathlib.Path('/tmp/edhr-dhr-metadata-main-20261102/observations').glob('*.json')}
assert {k:len(v['sql']) for k,v in obs.items()}=={'valid-false.json':4,'valid-true.json':5}
result={'sourceHeadAtDevelopment':'eb9faf1202fa6cda23264efbe8b3fcb493b471b3','targetCommit':'8ec8391721858a7f96d73a5d293d93f43679118a','wholeFileCompletion':0,'historicalUniqueIncrement':None,'records':[{'path':prefix+p,'locator':l,'result':r,'a23':a} for p,l,r,a in records],'sourceFingerprints':fps,'mainActualQueries':obs,'changedProductPaths':3,'changedTestPaths':2,'addedTestPaths':1,'newSqlFiles':0,'performanceImplementation':'User explicitly authorized only last filename metadata reuse; Summary/Archive batching untouched.','inventoryReference':'../branch-review-20261102-dhr-attachment-query/inventory/inventory-summary.json fixed8ec; inventory only, not semantic coverage','a23Followup':'W6 includes all old-reviewed files and all batch increments; W7 fresh remote changes; current finite methods not whole-file completion.'}
(out/'source-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
