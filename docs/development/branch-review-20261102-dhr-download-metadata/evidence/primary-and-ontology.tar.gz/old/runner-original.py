import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,sys,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend');mode=sys.argv[1];assert mode in ('main','capacity','old')
repo=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else root
out=pathlib.Path('/tmp/edhr-dhr-metadata-'+mode+'-20261102');out.mkdir(exist_ok=True)
name='edhr-dhr-metadata-'+mode+'-20261102';created=False
tests='DhrAttachmentDownloadMetadataPostgresTest,DhrWorkbenchPermissionsTest,DhrAttachmentAndArchiveTest,DhrAttachmentTransactionPostgresTest,DhrSummaryServiceTest,DhrAttachmentQueryObservationPostgresTest,DhrAttachmentWriteFailureTest,DhrReviewLifecycleIntegrationTest,DhrFormFilesTest,ExecutionAccessTest'
if mode=='capacity':tests='DhrAttachmentDownloadCapacityPostgresTest'
if mode=='old':tests='DhrAttachmentDownloadMetadataPostgresTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
result_code=99
try:
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own native PG not ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_dhr_attachment_transaction_test',EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',EDHR_DOWNLOAD_METADATA_OUTPUT=str(out/'observations'),EDHR_ATTACHMENT_QUERY_OUTPUT=str(out/'query-observations'))
 if mode=='capacity':env['EDHR_ATTACHMENT_CAPACITY_OUTPUT']=str(out/'capacity')
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+tests]
 if mode=='capacity':command.append('-DargLine=-Xmx2g')
 command.append('test');start=datetime.datetime.now(datetime.timezone.utc)
 fps=[]
 for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadMetadataPostgresTest.java']:
  b=(repo/path).read_bytes();fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 with (out/'maven.log').open('w') as log:result=subprocess.run(command,cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT)
 metadata={'command':command,'workingDirectory':str(repo),'sourceCommit':run(['git','rev-parse','HEAD'],cwd=repo),'targetCommit':run(['git','rev-parse','origin/edhr-dev'],cwd=root),'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fps,'database':env['EDHR_DHR_ATTACHMENT_TX_DATABASE_URL'],'postgres':run(['docker','exec',name,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT version()']),'containerId':cid}
 (out/'run.json').write_text(json.dumps(metadata,indent=2)+'\n')
 totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[];missing=[]
 for test in tests.split(','):
  found=list((repo/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml'))
  fresh=[p for p in found if p.stat().st_mtime>=start.timestamp()]
  if not fresh:missing.append(test)
  for p in fresh:
   shutil.copy2(p,out/p.name);doc=ET.parse(p).getroot();counts={k:int(doc.attrib.get(k,0)) for k in totals}
   classes.append({'class':doc.attrib['name'],**counts})
   for k in totals:totals[k]+=counts[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps({'metadata':metadata,'summary':summary},ensure_ascii=False))
 print((out/'maven.log').read_text()[-3500:])
 result_code=0 if mode=='old' and result.returncode==1 and totals=={'tests':11,'failures':2,'errors':0,'skipped':0} and not missing else result.returncode
finally:
 if created:
  stop=run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedName':name,'stopOutput':stop,'removed':removed},indent=2)+'\n');print('own container removed:',removed)
sys.exit(result_code)
