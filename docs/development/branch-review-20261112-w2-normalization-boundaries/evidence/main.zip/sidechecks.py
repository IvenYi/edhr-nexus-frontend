from pathlib import Path
import collections,datetime,hashlib,json,os,re,subprocess
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='fc2f21aa5e58c2d9a3a39270f1f624bef39da652';candidate='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7'
def run(name,args,cwd=root,env=None):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with(raw/(name+'.log')).open('w')as f:r=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 d={'name':name,'command':args,'cwd':str(cwd),'exitCode':r.returncode,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (raw/(name+'-command.json')).write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d),flush=True);return d
env=os.environ.copy();env.update(NODE_PATH='/workspace/.edhr-browser-tools/node_modules',CHROME_PATH='/usr/bin/chromium',DOCUMENT_READ_BASELINE_COMMIT=base,DOCUMENT_READ_ARTIFACTS=str(raw/'negative-browser'),DOCUMENT_READ_WIDTH='1440')
assert run('negative-node',['node','--test','--test-reporter=tap','scripts/test-designer-document-read.mjs'],root/'gmp-platform/frontend',env)['exitCode']==1
tap=(raw/'negative-node.log').read_text();assert re.search(r'^# pass 30$',tap,re.M)and re.search(r'^# fail 7$',tap,re.M)
assert run('negative-browser',['node','scripts/test-designer-document-read-browser.mjs'],root/'gmp-platform/frontend',env)['exitCode']==1
d=json.loads((raw/'negative-browser/result.json').read_text());bad=[r for r in d['results']if r['outcome']=='failed'];assert len(bad)==1 and bad[0]['case']=='unsupported-field-type'
writes=bad[0]['writes'];assert len(writes)==1 and json.loads(writes[0]['payload']['modelDesignJson'])['payload']['fields'][0]['type']=='text'
(raw/'negative-summary.json').write_text(json.dumps({'base':base,'scriptCandidate':candidate,'node':{'passed':30,'failed':7},'browser':{'passed':8,'failed':1},'savedUnknownTypeAsText':True,'scope':'Same final tests select original product source;expected negative failures only'},indent=2)+'\n')
old=raw/'baseline-worktree'
assert run('baseline-worktree',['git','worktree','add','--detach',str(old),base])['exitCode']==0
(old/'gmp-platform/frontend/node_modules').symlink_to(root/'gmp-platform/frontend/node_modules',target_is_directory=True)
script=raw/'skill/audit_project.py';assert hashlib.sha256(script.read_bytes()).hexdigest()=='67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68'
summary=[]
def findings(d):return collections.Counter(json.dumps({k:v for k,v in f.items()if k not in ['line','column']},sort_keys=True)for f in d['findings'])
for scope,suffix in [('repo',''),('frontend','gmp-platform/frontend')]:
 reports=[]
 for label,tree in [('baseline',old),('candidate',root)]:
  path=raw/(label+'-'+scope+'-premium.json');r=run(label+'-'+scope+'-premium',['python3',str(script),str(tree/suffix),'--mode','strict','--output',str(path)]);assert r['exitCode']==2
  reports.append(json.loads(path.read_text()))
 assert findings(reports[0])==findings(reports[1])
 summary.append({'scope':scope,'baseline':reports[0]['summary'],'candidate':reports[1]['summary'],'fullFindingMultisetsEqualIgnoringLineOnly':True})
(raw/'premium-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for label,tree in [('baseline',old),('candidate',root)]:assert run(label+'-lint',['npm','run','lint'],tree/'gmp-platform/frontend')['exitCode']==2
