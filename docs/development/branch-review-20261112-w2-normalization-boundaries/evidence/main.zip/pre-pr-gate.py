from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,subprocess,zipfile,yaml
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;report=repo/'docs/development/branch-review-20261112-w2-normalization-boundaries'
candidate='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7';target='fc2f21aa5e58c2d9a3a39270f1f624bef39da652'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
with(report/'evidence/target-refresh.log').open('w')as log:r=subprocess.run(['git','fetch','--prune','origin'],cwd=repo,stdout=log,stderr=subprocess.STDOUT)
assert r.returncode==0
assert git('rev-parse','origin/edhr-dev').decode().strip()==target
assert git('rev-parse','HEAD').decode().strip()==candidate
assert not git('diff','--name-only',target,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture')
inputs=json.loads((raw/'final/run.json').read_text())['sourceFingerprints']+json.loads((raw/'review-inputs.json').read_text())
for item in inputs:assert sha((repo/item['path']).read_bytes())==item['sha256']==sha(git('show',candidate+':'+item['path']))
knowledge=json.loads((raw/'final/knowledge-inputs.json').read_text())
for item in knowledge:assert sha((repo/item['path']).read_bytes())==item['sha256']==sha(git('show',candidate+':'+item['path']))
quality=yaml.safe_load((report/'quality-result.yaml').read_text())['qualityResult'];ontology=yaml.safe_load((report/'ontology-result.yaml').read_text())['ontologyResult']
assert quality['result']=='passed'and not quality['findings']and not quality['blockingConditions']and quality['headCommit']==candidate
assert ontology['result']=='not-applicable'and not ontology['conflicts']and not ontology['questions']
assert all(not c['required']or c['outcome']=='passed'for c in quality['checks'])
index=json.loads((report/'evidence-packages.json').read_text());count=0
for package in index['packages']:
 archive=report/package['path'];manifest=report/package['manifest'];assert sha(archive.read_bytes())==package['sha256']and archive.stat().st_size==package['bytes']and sha(manifest.read_bytes())==package['manifestSha256']
 members=json.loads(manifest.read_text())['files']
 with zipfile.ZipFile(archive)as z:
  assert set(z.namelist())=={m['path']for m in members}
  for item in members:
   data=z.read(item['path']);assert len(data)==item['bytes']and sha(data)==item['sha256'];count+=1
  if package['name']!='main':
   assert sha(z.read('manifest.json'))==index['roleFinalManifestSha256'][package['name']]
   for item in json.loads(z.read('manifest.json'))['files']:assert sha(z.read(item['path']))==item['sha256']
for line in git('status','--porcelain=v1','--untracked-files=all').decode().splitlines():
 path=line[3:];assert path.startswith('docs/development/branch-review-20261112-w2-normalization-boundaries/')or path=='docs/development/branch-review-20261015/NEXT.md',line
cleanup=json.loads((raw/'branch-cleanup/verification.json').read_text());branches=json.loads(subprocess.check_output(['gh','api','repos/IvenYi/edhr-nexus-frontend/branches?per_page=100'],cwd=repo))
live={b['name']:b['commit']['sha']for b in branches};assert all(n not in live for n in cleanup['deleted'])and all(n in live for n in cleanup['retainedPlannedBranches'])
assert all(live[n]==s for n,s in cleanup['stableHeadsAfter'].items())
result={'verifiedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'testedCandidate':candidate,'liveTarget':target,'sourceInputs':len(inputs),'knowledgeInputs':len(knowledge),'inputsCurrentGitAndTestedEqual':True,'contractAndKnowledgeDiff':[],'qualityResult':quality['result'],'ontologyResult':ontology['result'],'requiredQualityChecksPassed':sum(c['required']for c in quality['checks']),'archiveMembersVerified':count,'roleFinalManifestsVerified':index['roleFinalManifestSha256'],'completedRolesObservation':'Actual collaboration.list_agents observed both current-round tasks completed after their structured FINAL responses;root recorded this before executing gate','mergedAuditBranchesAbsent':88,'retainedBranchesPresent':cleanup['retainedPlannedBranches'],'stableHeadsUnchanged':True,'taskDrift':False,'scope':'W2 finite normalization leaf fix and PR87+88 combined regression plus user-authorized merged audit ref cleanup;whole audit remains pending;no newpolicy/refactor/merge/deploy/restore/CI query'}
(report/'evidence/pre-pr-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
