from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;final=raw/'final'
candidate='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7';base='fc2f21aa5e58c2d9a3a39270f1f624bef39da652'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((final/'run.json').read_text());assert run['head']==candidate and run['result']=='passed'and not run['workingTreeState']
for item in run['sourceFingerprints']:
 b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']==sha((final/'source'/item['path']).read_bytes())and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
adjacent=json.loads((raw/'review-inputs.json').read_text())
for item in adjacent:
 b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']==sha((raw/'review-source'/item['path']).read_bytes())and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for item in after:
 b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
node=json.loads((final/'node-summary.json').read_text());assert node['pass']==111 and node['fail']==node['skipped']==node['cancelled']==0
browsers=[]
for width in [1440,390]:
 for group,count in [('word',3),('document',9),('save',13),('import',15),('excel',4)]:
  d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count and all(x.get('outcome',x.get('status'))=='passed'for x in d['results']);browsers.append({'group':group,'width':width,'passed':count,'failed':0})
parser=json.loads((final/'word-parser/result.json').read_text());assert len(parser['results'])==8 and all(x['outcome']=='passed'for x in parser['results'])
java=json.loads((final/'java-summary.json').read_text());assert [x['tests']for x in java]==[41,89]and all(x['failures']==x['errors']==x['skipped']==0 for x in java)
negative=json.loads((raw/'negative-summary.json').read_text());assert negative['savedUnknownTypeAsText']
premium=json.loads((raw/'premium-summary.json').read_text());assert all(x['fullFindingMultisetsEqualIgnoringLineOnly']for x in premium)
cleanup=json.loads((raw/'branch-cleanup/verification.json').read_text());assert cleanup['deletedCount']==88 and cleanup['allSelectedRefsAbsent']and cleanup['allRetainedPlannedRefsPresent']and cleanup['stableHeadsAfter']['edhr-dev']==base
for ref in json.loads((raw/'branch-cleanup/deletion-result.json').read_text())['backupRefs']:
 assert subprocess.check_output(['git','rev-parse',ref['localBackupRef']],cwd=root,text=True).strip()==ref['sha']
result={'analysedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':candidate,'target':base,'result':'passed','protectedSourceInputs':len(run['sourceFingerprints']),'reviewAdjacencyInputs':len(adjacent),'protectedSourceCurrentGitAndSnapshotEqual':True,'knowledgeInputs':len(after),'knowledgeBeforeAfterCurrentGitEqual':True,'node':node,'pureParserCases':8,'browserExecutions':browsers,'componentBrowserExecutions':88,'functionalExecutions':248,'knowledgeChecksSeparate':89,'java':java,'negativeSameFinalScripts':negative,'resolution':{'id':'BUG-W2-UNSUPPORTED-FIELD-TYPE-001','status':'resolved','severity':'medium','trigger':'Current envelope includes explicit nonempty type unsupported by current editor','rootCause':'normalizeFieldType fallback silently changes explicit type to text before manual save','scope':'Top-level model fields strict editing only;not complete leaf/nested schema validation'},'premium':premium,'lint':{'baselineExit':2,'candidateExit':2,'reason':'Existing missing configuration;not passed'},'branchCleanup':{'deletedCount':88,'retained':cleanup['retainedPlannedBranches'],'stableHeadsUnchanged':True,'localRecoveryRefsVerified':88},'limits':['Controlled component API/savecallbacks and direct mockcontroller are not fullHTTP/PG E2E','Unknown field type input proven;normal current UI does not create such input','Top-level discriminator only;other leaves/nested columns/Office allformat and capacity remain','Strict86/frontend28 and missinglint configuration remain','WholeW2/W3-W7/allknowledge semantics/A23 alreadyreviewed revisit/other deferred scope remain']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['testedCandidate','result','protectedSourceInputs','reviewAdjacencyInputs','knowledgeInputs','functionalExecutions','knowledgeChecksSeparate','branchCleanup']},ensure_ascii=False))
