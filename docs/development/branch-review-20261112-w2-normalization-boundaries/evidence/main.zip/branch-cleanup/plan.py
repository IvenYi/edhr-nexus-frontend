from pathlib import Path
from zoneinfo import ZoneInfo
import subprocess,json,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path(__file__).parent
def gh(endpoint):
    data=subprocess.check_output(['gh','api','--paginate',endpoint],cwd=root,text=True).strip();decoder=json.JSONDecoder();rows=[]
    while data:
        page,index=decoder.raw_decode(data);rows.extend(page);data=data[index:].lstrip()
    return rows
branches=gh('repos/IvenYi/edhr-nexus-frontend/branches?per_page=100');prs=gh('repos/IvenYi/edhr-nexus-frontend/pulls?state=all&per_page=100')
repo=json.loads(subprocess.check_output(['gh','repo','view','IvenYi/edhr-nexus-frontend','--json','defaultBranchRef'],cwd=root,text=True));default=repo['defaultBranchRef']['name']
stable={name:subprocess.check_output(['git','rev-parse','origin/'+name],cwd=root,text=True).strip()for name in ['edhr-dev','main']}
historic={'fix/ontology-guided-audit','fix/ontology-foundation-contracts'};records=[]
for b in branches:
    name=b['name'];sha=b['commit']['sha'];related=[{'number':p['number'],'title':p['title'],'state':p['state'],'mergedAt':p['merged_at'],'headSha':p['head']['sha'],'mergeCommit':p['merge_commit_sha'],'base':p['base']['ref'],'url':p['html_url']}for p in prs if p['head']['ref']==name and (p['head'].get('repo')or{}).get('full_name')=='IvenYi/edhr-nexus-frontend']
    reasons=[];ancestors=[]
    for target,tip in stable.items():
        if subprocess.run(['git','merge-base','--is-ancestor',sha,tip],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:ancestors.append(target)
    openprs=[p for p in related if p['state']=='open'];merged=[p for p in related if p['mergedAt']and p['headSha']==sha];mergeproof=[]
    for p in merged:
        for target,tip in stable.items():
            if p['mergeCommit']and subprocess.run(['git','merge-base','--is-ancestor',p['mergeCommit'],tip],cwd=root,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:mergeproof.append({'pr':p['number'],'mergeCommit':p['mergeCommit'],'reachableFrom':target})
    auditScope=name.startswith('audit/')or name.startswith('fix/review-')or(name in historic and any(p['mergedAt']for p in related))
    if not auditScope:reasons.append('outside verified audit/review scope')
    if b['protected']or name in [default,'edhr-dev','main']:reasons.append('protected/default/stable branch')
    if openprs:reasons.append('open PR exists')
    if not ancestors and not mergeproof:reasons.append('no verified merged head or exact merged PR proof')
    records.append({'name':name,'sha':sha,'protected':b['protected'],'auditScope':auditScope,'pullRequests':related,'headReachableFrom':ancestors,'exactMergedPrProof':mergeproof,'eligible':not reasons,'retainReasons':reasons})
result={'observedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'repository':'IvenYi/edhr-nexus-frontend','defaultBranch':default,'stableHeads':stable,'authorization':'User requested merged audit branch cleanup;only audit/review refs and explicitly identified historic merged ontology-audit refs. Stable/default/protected/open/unproven branches retained.','branches':records}
(out/'plan.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'total':len(records),'auditScope':sum(b['auditScope']for b in records),'eligible':sum(b['eligible']for b in records),'retainedAudit':[{'name':b['name'],'reasons':b['retainReasons']}for b in records if b['auditScope']and not b['eligible']],'nonNamespaceEligible':[{'name':b['name'],'prs':b['pullRequests']}for b in records if b['eligible']and not b['name'].startswith('audit/')]},ensure_ascii=False,indent=2))
