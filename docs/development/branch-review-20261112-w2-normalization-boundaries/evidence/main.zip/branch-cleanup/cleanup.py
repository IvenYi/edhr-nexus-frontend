from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,subprocess,sys
root=Path('/workspace/edhr-nexus-frontend');out=Path(__file__).parent;repo='IvenYi/edhr-nexus-frontend'
planBytes=(out/'plan.json').read_bytes();plan=json.loads(planBytes);selected=[b for b in plan['branches']if b['eligible']]
def gh(endpoint):
    s=subprocess.check_output(['gh','api','--paginate',endpoint],cwd=root,text=True).strip();decoder=json.JSONDecoder();rows=[]
    while s:
        page,index=decoder.raw_decode(s);rows.extend(page);s=s[index:].lstrip()
    return rows
def now():return datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat()
def recheck():
    branches={b['name']:b for b in gh('repos/'+repo+'/branches?per_page=100')};openprs=gh('repos/'+repo+'/pulls?state=open&per_page=100')
    default=json.loads(subprocess.check_output(['gh','repo','view',repo,'--json','defaultBranchRef'],cwd=root,text=True))['defaultBranchRef']['name']
    for b in selected:
        live=branches.get(b['name']);assert live and live['commit']['sha']==b['sha'],'Head changed or absent:'+b['name']
        assert not live['protected']and b['name']not in [default,'main','edhr-dev']
        assert not any(p['head']['ref']==b['name']for p in openprs),'New open PR:'+b['name']
    return branches
assert selected and all(b['headReachableFrom']or b['exactMergedPrProof']for b in selected)
before=recheck();expected=[f"--force-with-lease=refs/heads/{b['name']}:{b['sha']}"for b in selected];deletions=[':refs/heads/'+b['name']for b in selected]
if '--prepare'in sys.argv:
    namespace='refs/archive/merged-audit-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ');backup=[{'name':b['name'],'sha':b['sha'],'localBackupRef':namespace+'/'+b['name']}for b in selected]
    text='start\n'+''.join('create '+b['localBackupRef']+' '+b['sha']+'\n'for b in backup)+'prepare\ncommit\n'
    r=subprocess.run(['git','update-ref','--stdin'],input=text,cwd=root,text=True,capture_output=True);assert r.returncode==0,r.stderr
    for b in backup:assert subprocess.check_output(['git','rev-parse',b['localBackupRef']],cwd=root,text=True).strip()==b['sha']
    args=['git','push','--dry-run','--atomic',*expected,'origin',*deletions];started=now()
    with(out/'dry-run.log').open('w')as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
    result={'startedAt':started,'finishedAt':now(),'planSha256':hashlib.sha256(planBytes).hexdigest(),'count':len(selected),'exitCode':r.returncode,'command':args,'backupRefs':backup,'mutation':'Local backup refs only;remote deletion is dry-run'}
    (out/'prepared.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['count','exitCode','mutation']}));assert r.returncode==0
elif '--apply'in sys.argv:
    prepared=json.loads((out/'prepared.json').read_text());assert prepared['exitCode']==0 and prepared['planSha256']==hashlib.sha256(planBytes).hexdigest()
    for b in prepared['backupRefs']:assert subprocess.check_output(['git','rev-parse',b['localBackupRef']],cwd=root,text=True).strip()==b['sha']
    args=['git','push','--atomic',*expected,'origin',*deletions];started=now()
    with(out/'delete.log').open('w')as f:r=subprocess.run(args,cwd=root,stdout=f,stderr=subprocess.STDOUT)
    result={'startedAt':started,'finishedAt':now(),'planSha256':prepared['planSha256'],'selectedCount':len(selected),'exitCode':r.returncode,'command':args,'expectedHeadShaLeases':True,'atomic':True,'backupRefs':prepared['backupRefs']}
    (out/'deletion-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');assert r.returncode==0,'Atomic deletion failed;inspect delete.log;no success claimed'
    after={b['name']:b for b in gh('repos/'+repo+'/branches?per_page=100')};deleted=[b['name']for b in selected];assert all(n not in after for n in deleted)
    retained=[b['name']for b in plan['branches']if not b['eligible']];assert all(n in after for n in retained),'An unrelated branch disappeared;inspect external concurrent activity'
    verification={'verifiedAt':now(),'deletedCount':len(deleted),'deleted':deleted,'retainedPlannedBranches':retained,'remainingBranches':[{'name':n,'sha':b['commit']['sha'],'protected':b['protected']}for n,b in after.items()],'allSelectedRefsAbsent':True,'allRetainedPlannedRefsPresent':True,'stableHeadsAfter':{n:after[n]['commit']['sha']for n in ['main','edhr-dev']},'scope':'Only listed remote branch refs;no commits removed from stable history;local recovery refs retained;no local worktree deletion/merge/deploy'}
    (out/'verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'deletedCount':len(deleted),'remaining':list(after),'stableHeadsAfter':verification['stableHeadsAfter']},ensure_ascii=False))
else:raise SystemExit('Use --prepare or --apply')
