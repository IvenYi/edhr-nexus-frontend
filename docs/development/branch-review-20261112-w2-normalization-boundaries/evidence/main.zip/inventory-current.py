from pathlib import Path
import collections,csv,datetime,json,subprocess
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
candidate='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7';target='fc2f21aa5e58c2d9a3a39270f1f624bef39da652'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
rows=[]
for entry in git('ls-tree','-r','-l','-z',candidate).split(b'\0'):
 if not entry:continue
 meta,p=entry.split(b'\t',1);mode,kind,blob,size=meta.decode().split();name=p.decode()
 if name.startswith('docs/knowledge/'):asset='knowledge'
 elif name.startswith('docs/development/branch-review-')or'/evidence/'in name:asset='audit-evidence'
 elif name.endswith('.sql'):asset='sql'
 elif '/src/test/'in name or '/scripts/test-'in name:asset='test'
 elif name.endswith(('.java','.ts','.tsx','.js','.mjs','.cjs','.css','.py','.sh')):asset='source'if'/src/'in name else'tool-code'
 elif name.endswith(('.yaml','.yml','.json','.xml','.toml')):asset='configuration'
 elif name.endswith('.md'):asset='documentation'
 else:asset='other'
 rows.append({'path':name,'gitBlob':blob,'bytes':int(size)if size!='-'else None,'assetType':asset,'scope':'inventory-only','reviewConclusion':'no-new-whole-file-conclusion'})
with(raw/'baseline-tree-inventory.csv').open('w',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
assert not git('diff','--name-only',target,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture')
increment=git('diff','--name-status','2259b8aeffada0281ab2f250620888d71314e48f',target).decode()
(raw/'pr87-integration-increment.txt').write_text(increment)
prs=[]
for number in [87,88]:
 d=json.loads(subprocess.check_output(['gh','pr','view',str(number),'--repo','IvenYi/edhr-nexus-frontend','--json','number,state,mergedAt,mergeCommit,headRefOid,url'],cwd=repo));assert d['state']=='MERGED';prs.append(d)
obs={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'mergedPRs':prs,'targetContractAndKnowledgeIncrement':[],'incrementScope':'PR87 exact integration on top of mergedPR88;new candidate includes both;no external increment observed'}
(raw/'baseline-observation.json').write_text(json.dumps(obs,indent=2)+'\n')
result={'observedAt':obs['observedAt'],'candidate':candidate,'target':target,'trackedPaths':len(rows),'byAssetType':dict(collections.Counter(r['assetType']for r in rows)),'externalIncrement':[],'qualification':'Fixed-tree mechanical inventory only;history preserved;finite method review below;no whole-file completion or global percent'}
(raw/'inventory-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
prefix='gmp-platform/frontend/src/pages/master-data/template-designer-react/'
methods=[('M-W2-EXPLICIT-FIELD-TYPE-20261112',[prefix+'utils/document.ts',prefix+'registry/fieldRegistry.ts'],['parsePersistedSlice','normalizeModelField','normalizeFieldType','getFieldTypeDefinition'],'Strict editing vs default reading;registered+explicitlegacy types;incomplete draft;no schema-wide validation'),('M-W2-TYPE-FAILURE-WRITE-20261112',[prefix+'TemplateDesignerReactShell.tsx',prefix+'store/useTemplateDesignerStore.ts'],['load effect','handleSave','handleFieldConfirmPersist','setDocument','markSavedSnapshot'],'Actual unknown-type manual-save negative and final no-write/storepreservation;unchanged owners'),('M-W2-PR87-88-INTEGRATION-20261112',[prefix+'utils/importExcel.ts',prefix+'utils/importWord.ts',prefix+'utils/document.ts'],['importExcelToCanvasPage','importDocxToCanvasPage','serializeTemplateDesignerDocument','parseReactTemplateDesignerDocument'],'Combined image extent+table reuse+read/save regression;not full Office layout/capacity certification')]
with(raw/'method-review-records.jsonl').open('w')as f:
 for id,paths,names,scope in methods:f.write(json.dumps({'id':id,'candidate':candidate,'paths':paths,'methods':names,'scope':scope,'evidenceKind':'original-source-and-focused-runtime','wholeFileCompleted':False,'wholeSystemCompleted':False},ensure_ascii=False)+'\n')
print(json.dumps(result,ensure_ascii=False))
