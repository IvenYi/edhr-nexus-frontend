from pathlib import Path
import datetime,hashlib,json,os,subprocess,yaml

root=Path('/workspace/edhr-nexus-frontend')
out=Path(__file__).parent
base='fc2f21aa5e58c2d9a3a39270f1f624bef39da652'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert head=='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7'
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/ontology.yaml','docs/knowledge/decisions/DEC-0009-production-work-flow-publish-validation.yaml','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml','docs/development/branch-review-20261112-w2-normalization-boundaries/decision-package.yaml','gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts','gmp-platform/frontend/src/pages/master-data/template-designer-react/registry/fieldRegistry.ts','gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx','gmp-platform/frontend/scripts/test-designer-document-read.mjs','gmp-platform/frontend/scripts/test-designer-document-read-browser.mjs']
inputs=[]
for name in paths:
 data=(root/name).read_bytes();assert data==subprocess.check_output(['git','show',head+':'+name],cwd=root)
 f=out/'source'/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 inputs.append({'path':name,'bytes':len(data),'sha256':sha(data)})
commands=[]
def run(label,cmd,cwd=root,env=None):
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (out/(label+'.log')).write_bytes(p.stdout)
 commands.append({'name':label,'command':cmd,'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'log':label+'.log'})
 return p
assert run('target-live',['git','ls-remote','--heads','origin','edhr-dev']).stdout.decode().split()[0]==base
assert not run('contract-and-knowledge-delta',['git','diff','--name-only',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture/business-knowledge-model.md']).stdout
current=run('current-read-tests',['node','--test','--test-reporter=tap','scripts/test-designer-document-read.mjs'],root/'gmp-platform/frontend')
assert current.returncode==0
env=os.environ.copy();env['DOCUMENT_READ_BASELINE_COMMIT']=base
previous=run('baseline-read-tests',['node','--test','--test-reporter=tap','scripts/test-designer-document-read.mjs'],root/'gmp-platform/frontend',env)
assert previous.returncode==1 and b'# pass 30' in previous.stdout and b'# fail 7' in previous.stdout
assert b'# pass 37' in current.stdout and b'# fail 0' in current.stdout
baseline=Path('/tmp/edhr-w2-normalization-boundaries-20261112/baseline-browser/result.json')
data=baseline.read_bytes();(out/'baseline-browser-original-result.json').write_bytes(data)
d=json.loads(data);case=next(x for x in d['results'] if x['case']=='unsupported-field-type')
assert case['errorVisible']==False and len(case['writes'])==1
assert json.loads(case['writes'][0]['payload']['modelDesignJson'])['payload']['fields'][0]['type']=='text'
checks=[]
for name in paths:
 if name.startswith('docs/knowledge/')and name.endswith('.yaml'):
  content=yaml.safe_load((root/name).read_text());assert content['knowledgeModelVersion']=='0.3.25';checks.append({'path':name,'yamlParsed':True,'version':'0.3.25'})
dp=yaml.safe_load((root/paths[11]).read_text())['decisionPackage']
assert set(['confirmed','inferred','unresolved','replacementScopes','impactAnalysis','extensionStrategy','affectedFiles','acceptanceScenarios']).issubset(dp)
assert all(not v for v in dp['confirmed'].values()) and not dp['unresolved'] and not dp['replacementScopes']
assert dp['impactAnalysis']['level']=='L2' and dp['extensionStrategy']['selectedPaths']==['product-core']
assert all((root/x['path']).exists() for x in dp['affectedFiles'])
for item in inputs:assert sha((root/item['path']).read_bytes())==item['sha256']
(out/'input-receipt.json').write_text(json.dumps({'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':head,'target':base,'contractReadCommit':base,'sourceInputsEqualTestedGit':True,'sourceInputsUnchangedAfter':True,'inputs':inputs,'yamlSyntaxAndVersionChecks':checks,'yamlScope':'Only relevant YAML syntax/version and DP shape;not formal knowledge schema or whole-knowledge semantic validation','baselineBrowserEvidenceOrigin':{'path':str(baseline),'sha256':sha(data),'evidenceType':'original-evidence copied from main real-browser run;not rerun by ontology role'},'focusedCurrentTests':37,'focusedOldPass':30,'focusedOldFail':7,'commands':commands},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'head':head,'inputCount':len(inputs),'focusedCurrentPass':37,'focusedOldPass':30,'focusedOldFail':7,'knowledgeChanges':0},ensure_ascii=False))
