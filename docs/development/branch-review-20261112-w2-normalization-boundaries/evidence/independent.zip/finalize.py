from pathlib import Path
import datetime,hashlib,json,subprocess
import yaml
repo=Path('/workspace/edhr-nexus-frontend');work=Path('/tmp/edhr-w2-normalization-boundaries-qa-worktree-20261112');raw=Path(__file__).parent;final=raw/'final'
candidate='1ae712ef9f35d8d0b0eb9022e1d7acfc85d14cd7';base='fc2f21aa5e58c2d9a3a39270f1f624bef39da652'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args,cwd=work):return subprocess.check_output(['git',*args],cwd=cwd)
run=json.loads((final/'run.json').read_text());assert run['head']==candidate and run['result']=='passed'and run['workingTreeState']=='?? gmp-platform/frontend/node_modules\n'
link=work/'gmp-platform/frontend/node_modules'
if link.is_symlink():
 assert link.resolve()==repo/'gmp-platform/frontend/node_modules';link.unlink()
assert git('rev-parse','HEAD').decode().strip()==candidate and not git('status','--porcelain=v1')
for i in run['sourceFingerprints']:
 b=(work/i['path']).read_bytes();assert sha(b)==i['sha256']==sha((repo/i['path']).read_bytes())==sha((final/'source'/i['path']).read_bytes())and b==git('show',candidate+':'+i['path'])
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for i in after:assert sha((work/i['path']).read_bytes())==i['sha256']==sha((repo/i['path']).read_bytes())and (work/i['path']).read_bytes()==git('show',candidate+':'+i['path'])
for i in json.loads((raw/'review-inputs.json').read_text())['files']:assert sha((work/i['path']).read_bytes())==i['sha256']==sha((repo/i['path']).read_bytes())
node=json.loads((final/'node-summary.json').read_text());assert node==dict(tests=111,**{'pass':111,'fail':0,'skipped':0,'cancelled':0})
groups=[]
for width in [1440,390]:
 for group,count in [('word',3),('document',9),('save',13),('import',15),('excel',4)]:
  d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count and all(x.get('outcome',x.get('status'))=='passed'for x in d['results']);groups.append({'group':group,'width':width,'passed':count,'failed':0})
parser=json.loads((final/'word-parser/result.json').read_text());assert len(parser['results'])==8 and all(x['outcome']=='passed'for x in parser['results'])
java=json.loads((final/'java-summary.json').read_text());assert [x['tests']for x in java]==[41,89]and all(x['failures']==x['errors']==x['skipped']==0 for x in java)
for n in ['negative-summary.json','premium-summary.json','independent-branch-cleanup-verification.json']:assert(raw/n).is_file()
remote=git('ls-remote','origin','refs/heads/edhr-dev','refs/heads/main').decode();assert base+'\trefs/heads/edhr-dev'in remote
(raw/'remote-final.txt').write_text(remote)
docs=['docs/development/branch-review-20261112-w2-normalization-boundaries/README.md','docs/development/branch-review-20261112-w2-normalization-boundaries/review.md']
docRows=[]
for name in docs:
 b=(repo/name).read_bytes();out=raw/'review-l0'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b);docRows.append({'path':name,'sha256':sha(b),'bytes':len(b)})
(raw/'review-l0-inputs.json').write_text(json.dumps(docRows,indent=2)+'\n')
rootState=git('status','--porcelain=v1',cwd=repo).decode();assert all(line=='?? '+name for line,name in zip(rootState.splitlines(),docs))and len(rootState.splitlines())==2
ontology=Path('/tmp/edhr-w2-normalization-boundaries-ontology-20261112');assert sha((ontology/'manifest.json').read_bytes())=='7ff2d0667ec9719bcad6a0424b66295f4c38d80d1b0d5e9652f2451e8007a3a4'
assert yaml.safe_load((ontology/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
summary={'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':base,'testedTrackedWorktreeClean':True,'testStartUntrackedDependencySymlink':run['workingTreeState'],'testFinishCleanAfterRemovingDependencySymlink':True,'mainWorktreeL0Only':rootState,'functionalExecutions':248,'knowledgeChecksSeparate':89,'node':node,'componentBrowserExecutions':88,'wordParserCases':8,'groups':groups,'java':java,'protectedSourceInputs':len(run['sourceFingerprints']),'knowledgeInputs':len(after),'protectedSourceGitWorktreePrimarySnapshotEqual':True,'visualInspected':['final/document-1440/unsupported-field-type.png','final/document-390/unsupported-field-type.png'],'sourceAndPolicyReview':'No new finding;finite top-level type format boundary and unchanged save owner,not full leaf schema or allknowledge audit'}
(raw/'independent-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
checks=[]
def check(id,category,description,method,command,evidence,required=True,outcome='passed'):
 checks.append(dict(id=id,required=required,category=category,description=description,method=method,command=command,outcome=outcome,evidence=evidence))
check('check.baseline-contract','documentation','核对实际目标、候选、契约与知识增量','command','git diff base candidate -- AGENTS.md codeplzreadme.md docs/agents docs/knowledge docs/architecture;git ls-remote origin refs/heads/edhr-dev',['base='+base,'head/testedCandidate='+candidate,'契约/知识/架构差异为空；remote-final.txt实时目标仍为base，PR87/88均MERGED。'])
check('check.knowledge-policy-boundary','ontology','草稿与请求格式边界及有限本体结果','inspection','读取DEC-0077-30、DEC-0009-01/05和ontologyResult',['缺省/null/空白可编辑，不增加必填/发布完整性；不认识类型仅代表当前编辑器无法安全解释，不声明全局业务非法。','本体原manifest摘要已重算一致且正式not-applicable；知识0.3.25/schema1.2.0不变。'])
check('check.scope-and-owner','requirements','最小修复、扩展归属与L2影响分析','inspection','git diff base candidate;原解析/注册表/Shell/后端写入源码核对',['产品仅document.ts+9行，两个维护测试和DP；沿原forEditing边界及Shell错误/禁写所有者；无第二套UI、后台规则或历史迁移。','DP直接/传递/潜在/不受影响/兼容/快照/审计/权限/测试/缺口与实际范围一致。'])
check('check.old-parser-negative','unit','相同最终测试选旧产品源码的真实负例','automated-test','DOCUMENT_READ_BASELINE_COMMIT='+base+' node --test scripts/test-designer-document-read.mjs',['negative-node.log/negative-summary.json：30通过、7预期失败；显式未知/错误类型被旧读取接受，不把边界输入计成七个独立业务缺陷。'])
check('check.old-shell-write-negative','e2e','旧Shell真实保存回调证明类型改写','browser','DOCUMENT_READ_BASELINE_COMMIT='+base+' node scripts/test-designer-document-read-browser.mjs',['negative-browser/result.json：8通过/1预期失败，仅unsupported-field-type；手动保存目标version-E，原future-number变为text。','真实Shell/Canvas/store、受控GET及保存回调；不冒称完整HTTP或数据库持久化E2E。'])
check('check.current-node','unit','当前兼容边界及相邻纯逻辑回归','automated-test','node --test --test-reporter=tap scripts/test-designer-*.mjs（精确七脚本见final/run.json）',['final/node.log和node-summary.json：111/111，0fail/skipped/cancelled。','其中读取37项覆盖十当前类型/十六旧别名（循环子断言）、缺省/null/空白、原件不变及默认只读兼容；未将循环子断言额外计数。'])
check('check.current-read-browser','e2e','未知类型错误可见、禁写、历史状态与恢复','browser','node scripts/test-designer-document-read-browser.mjs at1440/390',['final/document-1440/result.json和document-390/result.json：各9/9。','未知类型零写入且store/document/saved/undo/redo哈希不变；错误路径关闭重开/旧回调压力及正常草稿保存邻接通过。'])
check('check.current-save-browser','regression','保存异步身份和失败恢复回归','browser','node scripts/test-designer-save-context-browser.mjs at1440/390',['final/save-1440/result.json和save-390/result.json：各13/13。'])
check('check.current-import-browser','regression','既有导入异步、历史和错误恢复','browser','node scripts/test-designer-import-browser.mjs at1440/390',['final/import-1440/result.json和import-390/result.json：各15/15。'])
check('check.merged-excel-integration','integration','PR87已合入图片尺寸与保存重读组合','browser','node scripts/test-designer-excel-images-browser.mjs at1440/390',['final/excel-1440/result.json和excel-390/result.json：各4/4；NodeExcel夹具也纳入111。'])
check('check.merged-word-integration','integration','PR88已合入表格复用与真实宿主组合','browser','node scripts/test-designer-word-table-reuse.mjs;node scripts/test-designer-word-table-reuse-browser.mjs at1440/390',['final/word-parser/result.json：8/8；两屏宿主各3/3，完整页JSON等价和当前每表一次解析预算保持。','性能样本不变为生产SLA或新上限。'])
check('check.build-and-guards','regression','正式前端构建及原有三项维护guard','command','npm run build;node scripts/verify-template-designer-react.mjs;node scripts/verify-list-table-style-contract.mjs;node scripts/verify-no-external-fonts.mjs',['final/run.json记录四命令实际exit0；build包含TypeScript检查。'])
check('check.controller','api','持久化/版本/审计邻接直接控制器回归','automated-test','mvn-edhr -Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest test',['final/TEST-com.zencas.edhr.template.controller.TemplateModelingControllerTest.xml：41，0fail/errors/skipped。','直接mock控制器测试，非真实HTTP/原生PG验收。'])
check('check.knowledge-regression','ontology','正式知识校验与输入不变','automated-test','mvn-edhr -Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest test',['final/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml：89，0fail/errors/skipped；359知识/知识测试/pom前后和当前Git/主工作树一致。','这是结构/引用等正式测试，不冒称全部知识逐条语义已通过。'])
check('check.visual-and-shared-ui','visual','真实观察两屏错误状态及动作可达','inspection','查看1440及390 unsupported-field-type.png；读取DESIGN和共享UI规范',['错误文案完整且能换行，保存明显禁用，关闭位于视口内；沿原MUI提示及现有工具栏，没有样式或暂停弹窗修改。','只覆盖本轮页面状态；不声明全UI/全部键盘/所有设备验收。'])
check('check.a23-and-runtime-cost','regression','有限健壮性与过度防御复查','inspection','源码核对parsePersistedSlice/normalizeFieldType/注册表及Shell写入入口',['未知类型有实际有损保存负例，保护必要；保留不完整草稿和旧别名，自身属性检查防原型键被当作旧别名；无新增重试/兜底写入/通用校验框架。','新增线性字段遍历、固定小注册表，无额外JSON.parse/整表复制/SQL/N+1/内存分页或全局缓存；不外推整个系统性能。'])
check('check.static-no-regression','regression','精确官方静态审查完整finding差异','command','python3 audit_project.py baseline|candidate --mode strict',['premium-summary.json：仓库86/前端28，两边完整多重集相同，仅忽略行列号；scriptSHA=67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68。','四次扫描均exit2，本项通过只表示本轮无新增，未报告全局strict通过。'])
check('check.branch-cleanup','audit','只读复核已合并审计分支清理和恢复依据','command','independent-branch-cleanup-verification.json对应实际git/gh只读命令',['88项审计头均在稳定分支历史可达；88精确头lease/原子删除参数、结果exit0及本地备份引用逐项相符。','实时远端仅五个原保留分支，88已删引用全不存在；main/edhr-dev头不变；PR87/88均MERGED。'])
check('check.final-input-and-l0-docs','documentation','验收原件、输入、阶段覆盖及L0说明','command','python3 finalize.py;源码/知识摘要和git show交叉核对',['51运行输入、14审读输入与候选Git/隔离及主工作树一致，359知识输入前后不变。','隔离候选仅运行环境依赖软链未跟踪，已移除后clean；受保护源码全程不变；主工作树只有README/review两份未跟踪L0文件，副本及摘要在review-l0-inputs.json，已只读核对其有限范围/不夸大全量覆盖和后续拆分建议。','不提前声称全角色门禁/PR前漂移已执行，后续由主审在正式FINAL后实际执行。'])
check('check.existing-lint-limit','documentation','既存缺配置的ESLint未执行成功','command','npm run lint（baseline及candidate）',['baseline-lint.log及candidate-lint.log均exit2，缺配置；未新增或降低配置/断言以换绿。'],required=False,outcome='blocked')
quality={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':candidate,'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':candidate,'uncommittedContractPaths':[]},'workingTreeState':{'status':'dirty','includedPaths':docs,'excludedPaths':[],'untrackedPaths':docs},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[{'id':'risk.controlled-e2e','description':'真实组件受控GET/保存回调及直接mock控制器不等同完整认证HTTP/原生PG E2E。','impact':'不认证全部权限、账号及生产集成行为。','mitigation':'当前仅前端格式边界，保留全系统后续矩阵。'},{'id':'risk.remaining-leaves-and-capacity','description':'主字段类型一项不等同全部模型/子表叶子、Office格式或大输入容量审查完成。','impact':'父容量/其他未审范围仍开放。','mitigation':'按W2后续及W5/W6分批取证；性能先量化讨论，不默增上限。'},{'id':'risk.static-and-lint-debt','description':'strict仓库86/前端28及ESLint缺配置仍存在；无本轮新增。','impact':'未达到全局UI规范和lint绿色。','mitigation':'保留原件及精确差异；不降低标准或冒称全局通过。'},{'id':'risk.whole-audit-pending','description':'全知识逐条语义、W2余项/W3-W7、A23已审补查、原high/A12/完整UI与多租户等未由本批关闭。','impact':'不能宣布整体审计或发布验收完成。','mitigation':'固定树盘点与三条有限方法清单分列，继续按最新提交增量审计。'}],'blockingConditions':[]}}
(raw/'quality-result.yaml').write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False,width=120))
(raw/'review.md').write_text(f'''# 独立质量复验 FINAL

本实例未参与修复，未修改产品、测试、DP、知识或主报告。在隔离工作树实际验收 `{candidate}`，base/实时目标为 `{base}`，包含已合入PR87和PR88。运行开始只有未跟踪node_modules依赖软链、已跟踪源码clean；运行结束移除该环境软链后隔离候选clean；主工作树收尾另有两份未提交L0 README/review，仅只读核对并留副本，qualityResult以dirty+精确路径明示，不把它们伪称受测提交。

结论：qualityResult.result **passed**；19项必需检查通过，无findings/blocking。旧lint缺配置作为非必需blocked披露；strict原86/28完整finding多重集未新增，四次exit2均未当作全局通过。

独立实际运行111 Node、8 Word纯浏览器解析、88真实组件两屏、41直接控制器，共248功能执行；另知识89，无失败/错误/跳过。构建与三guard通过。同最终测试选旧产品源码，Node30通过/7预期失败；浏览器8通过/1预期失败，确切保存载荷将future-number写为text。新实现沿原编辑读取失败与禁写保护，当前十类/十六旧别名、缺省/null/空白草稿及默认只读行为保持。两屏错误截图已实际观察，关闭可达、禁写明确、文案完整。

源码与DEC-0077-30、DEC-0009-01/05对照：未知类型保护属于无法安全解释输入时的读取格式边界，不是字段必填或发布业务完整性；不把未来类型宣告为全局非法。中央注册表和显式旧别名仍是解释来源，自身属性检查防止原型键混入别名；无新通用校验框架、重试或保存旁路。新增只遍历当前字段，未重复JSON解析、整表复制、SQL、N+1或内存分页。A23仅对本次解析/Shell邻接有限复查，其他已审模块继续待复查。

只读复核用户授权的88个已合并审计分支清理：头提交均可由稳定历史到达，精确lease/原子删除结果和88本地恢复引用逐项一致；实时远端五个保留分支及稳定头不变。未执行任何远端写入、merge、部署、恢复或CI查询触发。

51运行输入及14审读输入与候选Git/隔离/主工作树一致，359知识和测试输入前后不变；正式本体NA原manifest已核。控制API/保存回调、直接mock控制器不冒称完整HTTP/原生PG；不认证所有叶子/Office版式/容量或全部知识、W0-W7、A23完成。主报告有限覆盖、未知/暂缓范围、下一步拆分边界经核对，没有把8332路径盘点或本批测试计作全盘一致。两角色正式FINAL之后的实际fetch/输入/证据封包/PR前漂移门禁仍由主审执行。
''')
assert sum(c['required']for c in checks)==19 and all(c['outcome']=='passed'for c in checks if c['required'])
files=[]
for path in sorted(raw.rglob('*')):
 if path.is_file()and path.name not in ['manifest.json','SHA256SUMS']:
  b=path.read_bytes();files.append({'path':str(path.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
(raw/'manifest.json').write_text(json.dumps({'role':'independent-quality','result':'passed','candidate':candidate,'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},ensure_ascii=False,indent=2)+'\n')
(raw/'SHA256SUMS').write_text(''.join(i['sha256']+'  '+i['path']+'\n'for i in files))
print(json.dumps({'result':'passed','requiredChecks':19,'functionalExecutions':248,'knowledgeChecksSeparate':89,'files':len(files),'manifestSha256':sha((raw/'manifest.json').read_bytes())},ensure_ascii=False))
