from pathlib import Path
import subprocess, hashlib, json, datetime, shutil
import yaml

repo = Path('/workspace/edhr-nexus-frontend')
out = Path('/tmp/edhr-personnel-count-ontology-20261105')
out.mkdir(exist_ok=True)
base = '00f864cdaf0796c9410173c835a477c7a3068d06'
prior = '90cca1c08155a01cb0a51efe6d7fc31f19eda777'
backend = 'gmp-platform/backend/src/main/java/com/zencas/edhr/'
helper = backend + 'identity/service/TenantTransferTargets.java'
test = 'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
contracts = ['AGENTS.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/business-knowledge-modeler.md']
decisions = ['docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml', 'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml', 'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml']
evidences = ['docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md', 'docs/knowledge/evidence/workflow-operations-20261030.md', 'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md', 'docs/development/workflow-central-entry-extension-20261102/user-confirmed.md']
protected = [backend + x for x in ['workflow/service/WorkflowResponsibilityService.java', 'production/service/FormWorkflowOperations.java', 'workflow/engine/WorkflowEngine.java', 'production/service/ExecutionAccess.java', 'workflow/service/WorkflowOperationsQuery.java', 'workflow/controller/WorkflowTaskController.java', 'workflow/controller/WorkflowOperationsController.java', 'production/controller/ProductionExecutionController.java', 'identity/repository/UserAccountRepository.java']]
package = 'docs/development/branch-review-20261105-personnel-count/decision-package.yaml'
files = contracts + ['docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/schema.yaml', 'docs/knowledge/open-questions.yaml'] + decisions + evidences + protected + [helper, test, package]

commands = []
def git(*args):
    command = ['git', *args]
    proc = subprocess.run(command, cwd=repo, check=True, capture_output=True)
    commands.append({'argv': command, 'cwd': str(repo), 'exitCode': proc.returncode, 'stdoutSha256': hashlib.sha256(proc.stdout).hexdigest()})
    return proc.stdout
def sha(data):
    return hashlib.sha256(data).hexdigest()
def write(name, obj):
    (out / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

head = git('rev-parse', 'HEAD').decode().strip()
target = git('rev-parse', 'origin/edhr-dev').decode().strip()
branch = git('branch', '--show-current').decode().strip()
assert head == base and target == base
dirty = git('status', '--short').decode()
tree_equal = git('rev-parse', prior + '^{tree}').strip() == git('rev-parse', base + '^{tree}').strip()
assert tree_equal
baseline = {'capturedAtUtc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sourceCommit': head, 'targetBranch': 'edhr-dev', 'targetCommit': target, 'contractReadCommit': head, 'uncommittedContractPaths': [], 'workingBranch': branch, 'workingTreeStatus': dirty, 'productIsUncommittedWorkingTree': True, 'priorDeliveryCommit': prior, 'priorAndSourceTreeEqual': tree_equal, 'targetNetworkRefreshPerformedByThisRole': False}
write('baseline.json', baseline)

fingerprints = []
for name in files:
    data = (repo / name).read_bytes()
    dest = out / 'inputs' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    fingerprints.append({'path': name, 'bytes': len(data), 'sha256': sha(data), 'snapshot': str(dest.relative_to(out))})
write('source-fingerprints.json', {'status': 'FINAL', 'sourceCommit': head, 'targetCommit': target, 'fileCount': len(fingerprints), 'files': fingerprints})

contract_checks = []
for name in contracts:
    source = git('show', base + ':' + name)
    old = git('show', prior + ':' + name)
    current = (repo / name).read_bytes()
    contract_checks.append({'path': name, 'priorEqualsSource': old == source, 'sourceEqualsWorkingTree': source == current, 'sourceSha256': sha(source), 'workingTreeSha256': sha(current)})
assert all(x['priorEqualsSource'] and x['sourceEqualsWorkingTree'] for x in contract_checks)
write('contract-byte-check.json', {'checks': contract_checks})

knowledge = []
for name in git('ls-files', 'docs/knowledge/**').decode().splitlines():
    data = (repo / name).read_bytes()
    source = git('show', base + ':' + name)
    knowledge.append({'path': name, 'bytes': len(data), 'workingTreeSha256': sha(data), 'sourceSha256': sha(source), 'equal': data == source})
assert len(knowledge) == 345 and all(x['equal'] for x in knowledge)
schema = yaml.safe_load((repo / 'docs/knowledge/schema.yaml').read_text())
assert schema['knowledgeModelVersion'] == '0.3.25' and schema['schemaVersion'] == '1.2.0'
write('knowledge-byte-check.json', {'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0', 'knowledgeFileCount': len(knowledge), 'allUnchanged': True, 'semanticFullLibraryReviewPerformed': False, 'files': knowledge})

guard_checks = []
for name in protected:
    old = git('show', base + ':' + name)
    current = (repo / name).read_bytes()
    guard_checks.append({'path': name, 'check': 'whole-file-equality', 'equal': old == current, 'sourceSha256': sha(old), 'workingTreeSha256': sha(current)})
old = git('show', base + ':' + helper).decode()
current = (repo / helper).read_text()
sections = [
    ('search-overloads-and-qualification-predicates', lambda s: s[s.index('    public List<Map<String, String>> search('):s.index('        return users.find')]),
    ('post-query-filter-projection-and-final-require-available', lambda s: s[s.index('                .filter(user -> available'):]),
]
for label, select in sections:
    a, b = select(old).encode(), select(current).encode()
    guard_checks.append({'path': helper, 'check': label, 'equal': a == b, 'sourceSha256': sha(a), 'workingTreeSha256': sha(b)})
assert all(x['equal'] for x in guard_checks)
assert '.limit(100).all()' in current and 'specification.and(scope)' in current
assert '.stream().limit(' not in current
write('guard-byte-equivalence.json', {'baseline': base, 'protectedCheckCount': len(guard_checks), 'allUnchanged': True, 'checks': guard_checks, 'qualificationConjoinedBeforeBoundedRead': True, 'javaStreamFullLoadThenLimitIntroduced': False, 'runtimeSqlExecutionPerformedByRole': False})
(out / 'product.diff').write_bytes(git('diff', base, '--', helper))
(out / 'test.diff').write_bytes(git('diff', base, '--', test))

scopes = [
('DEC-0081-01', decisions[0], 'specified', 'consistent', '同租户正常可用、非当前处理人目标读取保持；通用及普通生产表单原处理人委托范围不改。', [helper, protected[2], protected[3], evidences[0]]),
('DEC-0081-02', decisions[0], 'specified', 'consistent', '只读目录不写原候选依据或当前责任；当前目标、原始候选和冻结证据的分离保持。', [protected[0], protected[1], protected[2], evidences[0]]),
('DEC-0081-03', decisions[0], 'specified', 'consistent', '去除未消费COUNT不改转办原因、实际操作者、时间、签署或同事务历史审计；本轮只核调用链与字节不变。', [protected[0], protected[1], protected[2], evidences[0]]),
('DEC-0092-02', decisions[1], 'specified', 'consistent', 'CHANGE/OBSOLETE目标SQL仍叠加原候选scope并回避申请人，不能套用通用表单租户委托范围。', [protected[0], helper, evidences[1]]),
('DEC-0092-03', decisions[1], 'specified', 'consistent', '管理员权限、真实签署人、有效签名及目标执行时复核代码整文件未变；列表不授予最终写入资格。', [protected[0], protected[1], evidences[1]]),
('DEC-0093-02', decisions[2], 'specified', 'consistent', '普通表单原转办及管理员签名改派、DHR仅管理员签名改派的当前边界保持；不恢复本人DHR转办或通用批准旁路。', [protected[0], protected[1], evidences[2], evidences[3]]),
('DEC-0093-03', decisions[2], 'specified', 'consistent', '本次目录只读查询不写责任、签名、集中历史或领域审计；原同事务证据代码字节保持，不冒称重跑全审计矩阵。', [protected[0], protected[1], evidences[2]]),
('DEC-0093-04', decisions[2], 'specified', 'consistent', 'DHR records.dhr-review与dhr.reviews.act、普通表单production.execution与form-management.review双权限AND及SQL先过滤后限量保持；具体权限码、100条目录上限和去COUNT为工程契约，非用户新增政策。', [helper, protected[0], protected[1], evidences[2]]),
('question.multi-tenant-workflow-isolation', 'docs/knowledge/open-questions.yaml', 'open-question', 'evidence-gap', '保留非MVP完整多租户隔离开放项；局部目录tenant过滤不关闭认证、所有ID路径或全工作流隔离问题，本轮不阻塞该窄读取优化。', ['docs/knowledge/open-questions.yaml', evidences[0], evidences[2]]),
]
entries = [{'id': identity, 'recordType': 'question' if identity.startswith('question.') else 'decision-statement', 'sourcePath': path, 'sourceLocator': 'id: ' + identity, 'sourceCommit': head, 'contractReadCommit': head, 'originalStatus': status, 'reviewStatus': 'reviewed', 'conclusion': conclusion, 'scope': meaning, 'evidenceReferences': refs, 'historicalUniqueCoverageClaim': False} for identity, path, status, conclusion, meaning, refs in scopes]
write('finite-id-review.json', {'finiteReviewedIdCount': len(entries), 'consistentCount': 8, 'evidenceGapCount': 1, 'entries': entries, 'historicalUniqueCoverageAdded': None, 'full931Claim': False, 'note': '本轮9个相关ID含既审政策重叠，不增记历史唯一已审数；开放问题evidence-gap表示仍保留，非本批新增阻断。'})

read_scope = {'status': 'FINAL', 'requiredDocumentsRead': contracts, 'requiredLongDocumentScope': {'docs/architecture/business-knowledge-model.md': ['current responsibility and maintenance/agent collaboration', 'ordinary-form/record-control/DHR projection boundaries'], 'docs/knowledge/README.md': ['current 0.3.25/schema 1.2.0 baseline', 'source versus policy and statement-level supersession', 'finite review versus full audit accounting', 'maintenance, P0 roadmap and formal validation boundary']}, 'completeRelevantDecisionFilesRead': decisions, 'originalEvidenceSourcesRead': evidences, 'relevantCodeMethodsRead': {'TenantTransferTargets': ['search overloads and all qualification predicate construction', 'bounded query/filter/projection', 'require', 'available'], 'WorkflowResponsibilityService': ['transferTargets', 'reassignmentTargets', 'change', 'targets', 'eligible', 'requireOperator', 'requireActive'], 'FormWorkflowOperations': ['targets', 'reassign', 'load'], 'ExecutionAccess': ['transferTargets', 'requireTransferTarget', 'transferTenantId'], 'WorkflowEngine': ['transferTargets', 'transferTask'], 'controllers': ['List<Map<String,String>> target endpoints and central prefixed-domain routing'], 'WorkflowReadObservationPostgresTest': ['personnelDirectoryObservesFullPageCount', 'personnelDirectoryKeepsEligibilityAndTieOrder']}, 'allInputSnapshotsDoNotImplyFullSemanticReadingOfEveryLine': True, 'runtimeTestsExecuted': [], 'reportsReusedAsCurrentExecutionEvidence': [], 'failedExploratoryRead': {'path': 'docs/agents/coordination/ai-handoff-contract.md', 'exitCode': 2, 'resolution': 'Recovered canonical docs/agents/agent-handoff-contract.md; no conclusion depended on failed path.'}}
write('read-scope.json', read_scope)

knowledge_sync = [{'id': x['id'], 'disposition': 'deferred' if x['recordType'] == 'question' else 'retained', 'scope': x['scope'], 'sourceReferences': [x['sourcePath'], *x['evidenceReferences']]} for x in entries]
result = {'ontologyResult': {'result': 'not-applicable', 'baselineBefore': '0.3.25', 'baselineAfter': '0.3.25', 'contractBaseline': {k: baseline[k] for k in ['sourceCommit', 'targetBranch', 'targetCommit', 'contractReadCommit', 'uncommittedContractPaths']}, 'reason': '本轮仅将未消费总数的Page内容读取改为同一Specification/scope、displayName/id排序及数据库100条上限的List读取。有限9ID核对及保护段字节对比未发现业务语义变化；名单查询不是最终写入授权。100上限/SQL/API为既有工程契约，不将本次持续审计伪记为用户新确认政策；无权威知识需要修改。', 'changedArtifacts': [], 'knowledgeSync': knowledge_sync, 'conflicts': [], 'questions': [], 'validationEvidence': [
{'id': 'validation.current-contract-and-source-fingerprints', 'checkType': 'evidence-path', 'command': 'python /tmp/build-personnel-count-ontology-20261105.py (Git read and input snapshot capture)', 'outcome': 'passed', 'evidence': ['baseline.json', 'source-fingerprints.json', 'contract-byte-check.json', 'command-log.json']},
{'id': 'validation.finite-policy-source-mapping', 'checkType': 'reference', 'command': 'Read current DEC-0081/0092/0093, original confirmation evidence and directory consumer methods; finite scope recorded in read-scope.json', 'outcome': 'passed', 'evidence': ['finite-id-review.json', 'read-scope.json', 'semantic-review.md']},
{'id': 'validation.qualification-and-write-guard-byte-equivalence', 'checkType': 'projection', 'command': 'python /tmp/build-personnel-count-ontology-20261105.py (compare protected source bytes with Git source baseline)', 'outcome': 'passed', 'evidence': ['guard-byte-equivalence.json', 'product.diff']},
{'id': 'validation.knowledge-unchanged', 'checkType': 'status-transition', 'command': 'python /tmp/build-personnel-count-ontology-20261105.py (git ls-files docs/knowledge/**; compare each Git blob with working tree)', 'outcome': 'passed', 'evidence': ['knowledge-byte-check.json']},
], 'roadmapProgress': {'stage': 'P0', 'status': 'in-progress', 'exitCriteriaEvidence': [], 'deferredStages': ['P1', 'P2', 'P3']}}, 'verificationScope': {'status': 'FINAL', 'formalKnowledgeTestsExecuted': False, 'nativeTestsExecuted': False, 'browserExecuted': False, 'semanticScope': '本批目录去除未消费COUNT的9个相关ID有限核对，8 consistent/1保留既有evidence-gap；不构成931知识候选全审或历史unique新增。', 'inputFingerprintFileCount': len(fingerprints), 'knowledgeUnchangedFileCount': 345, 'productOrTestChangesByThisRole': [], 'stageAdvanced': False, 'remainingBoundaries': ['正式89及152原生测试由主侧/全新独立QA运行，本角色未执行或宣称其通过', '完整多租户认证上下文及按ID运行操作矩阵未收口', '931知识候选、86 UI、W2-W7高风险/A12、其余全审及暂停范围保持', '巨大候选集合参数/文本ID查询计划/全账号矩阵另审', '非生产吞吐延迟/全数据分布EXPLAIN及完整HTTP/JWT/浏览器签署链未由本角色验证']}}
(out / 'ontology-result.yaml').write_text(yaml.safe_dump(result, allow_unicode=True, sort_keys=False, width=120))
(out / 'semantic-review.md').write_text('''# 人员目录去除未消费COUNT：有限本体结论

结论：`not-applicable`。没有新增或替代业务政策，知识0.3.25/schema1.2.0、P0/in-progress保持。

这次把共享人员目标目录的Page内容读取换成现有Spring Data有界列表API。变更没有返回总数的消费者，控制器仍返回List；原租户、ACTIVE、未锁定、关键词、当前人排除、两个权限均需具备以及领域候选scope，仍先组合进Specification再查询。displayName、数字id的次序和100上限保持。没有在Java全量加载后limit。实际SQL次数和限量由主侧及最终独立质量另验，本角色不冒称执行。

有限核对9个相关ID见finite-id-review.json，8项consistent，1项保留现有完整多租户evidence-gap。此数是本批实际相关ID，并不增加历史unique已审数，也不关闭931知识候选。DEC-0081普通转办允许同租户有效人，不能外推到CHANGE/OBSOLETE；后者仍加原候选及申请人回避。DEC-0093仅局部替代旧DHR管理员重新分配禁止范围，DHR本人转办、通用批准旁路仍禁止；不把DEC-0092-06历史实现的DHR排除当现行政策。

100条上限、具体权限码、SQL及API形态属于既有工程选择，不伪装成用户本轮新确认。原始确认明确区分普通表单处理人转办与签名管理员改派、DHR仅管理员改派，并要求领域数据审计。目录读取本身不授予最终办理资格；require/eligible、权限、状态、签名、锁、原候选、责任、历史审计和冻结证据全部留在原领域写入链。

9个受保护完整源文件、共享帮助类的查询资格区和读取后/最终require区，均对00f864cd源提交逐字节保持，共11项相等。345个已跟踪知识文件逐字节与源提交一致。源码指纹、原始输入、命令回执和差异单独保存。输入快照不代表无关长文历史均已做语义全审；已实际阅读范围列于read-scope.json。

本角色未修改产品、测试、fixture、配置或知识；未执行正式89、原生152、浏览器、CI/Actions，也未合并/部署或恢复历史。正式运行验证由实际未参与修复的新质量实例完成。931知识、86 UI、W2-W7高风险/A12与其余性能和暂停范围继续保留，不能以本批NA称全审完成。
''')
(out / 'FINAL.md').write_text('''# FINAL

- ontologyResult: not-applicable
- Knowledge: 0.3.25 / schema1.2.0, P0/in-progress;345 tracked files unchanged.
- Finite IDs:9(8 consistent,1 retained existing evidence-gap), not historical unique coverage.
- Product/test/source final fingerprints:source-fingerprints.json.
- Guard checks:11 unchanged.
- Runtime knowledge/native/browser tests executed by this role:none.
- No business question blocks this narrow change; no knowledge edits required.
- Remaining audit and multi-tenant gaps are retained in ontology-result.yaml.
''')
shutil.copyfile('/tmp/build-personnel-count-ontology-20261105.py', out / 'build-artifacts.py')
write('command-log.json', {'argv': ['python', '/tmp/build-personnel-count-ontology-20261105.py'], 'cwd': str(repo), 'gitCommands': commands, 'scriptSha256': sha((out / 'build-artifacts.py').read_bytes()), 'nativeOrKnowledgeTestCommandsExecuted': []})
artifacts = []
for p in sorted(out.rglob('*')):
    if p.is_file() and p.name not in ['manifest.json', 'manifest.sha256']:
        data = p.read_bytes()
        artifacts.append({'path': str(p.relative_to(out)), 'bytes': len(data), 'sha256': sha(data)})
write('manifest.json', {'status': 'FINAL', 'ontologyResult': 'not-applicable', 'artifactCount': len(artifacts), 'artifacts': artifacts, 'manifestExcludesItselfAndDigest': True})
digest = sha((out / 'manifest.json').read_bytes())
(out / 'manifest.sha256').write_text(digest + '  manifest.json\n')
print(json.dumps({'output': str(out), 'result': 'not-applicable', 'inputFiles': len(fingerprints), 'knowledgeFiles': len(knowledge), 'guardChecks': len(guard_checks), 'finiteIds': len(entries), 'artifactCountExcludingManifestAndDigest': len(artifacts), 'manifestSha256': digest}, ensure_ascii=False))
