import pathlib,json,hashlib,subprocess,tarfile,shutil,yaml
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=r/'docs/development/branch-review-20261105-personnel-count';o.joinpath('evidence').mkdir(exist_ok=True);q=pathlib.Path('/tmp/edhr-personnel-count-ontology-20261105');base='00f864cdaf0796c9410173c835a477c7a3068d06'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((q/'manifest.json').read_bytes())=='a8fd8dd0adb40cf0623bca5b5cbbf67c712f393f49ca26af208b9cadb8f3ae8c'
m=json.loads((q/'manifest.json').read_text());assert m['artifactCount']==len(m['artifacts'])==40
for f in m['artifacts']:
 b=(q/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert yaml.safe_load((q/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
files=[]
for mode,total in [('red',{'tests':7,'failures':4,'errors':0,'skipped':0}),('green',{'tests':152,'failures':0,'errors':0,'skipped':0})]:
 d=pathlib.Path('/tmp/edhr-personnel-count-main-'+mode+'-20261105');assert json.loads((d/'test-summary.json').read_text())['totals']==total;assert json.loads((d/'cleanup.json').read_text())['removed']
 for f in json.loads((d/'run.json').read_text())['sourceFingerprints']:
  b=(d/'source-snapshot'/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
  if mode=='red' and '/src/main/' in f['path']:assert b==subprocess.check_output(['git','show',base+':'+f['path']],cwd=r)
  if mode=='green' or '/src/test/' in f['path']:assert b==(r/f['path']).read_bytes()
 for p in sorted(d.rglob('*')):
  if p.is_file():files.append(('primary/'+mode+'/'+str(p.relative_to(d)),p))
for p in sorted(q.rglob('*')):
 if p.is_file():files.append(('ontology/'+str(p.relative_to(q)),p))
for n in ['run-personnel-list-count.py','archive-personnel-count-primary.py','edhr-personnel-count-red-runner-20261105.log','edhr-personnel-count-green-runner-20261105.log','edhr-personnel-count-fluent-api-20261105.txt']:
 files.append(('tools/'+n,pathlib.Path('/tmp')/n))
raw=[{'member':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files];a=o/'evidence/primary-and-ontology.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,p in files:t.add(p,arcname=n,recursive=False)
(o/'evidence-manifest.json').write_text(json.dumps({'sourceHeadDuringRuns':base,'rawArtifacts':raw,'archive':{'path':str(a.relative_to(o)),'bytes':a.stat().st_size,'sha256':sha(a.read_bytes())},'note':'Raw old7=4 real query-budget failures+3positive; current1520F/E/S. Same final test bytes; raw member sizes differ from stored gzip.'},ensure_ascii=False,indent=2)+'\n');shutil.copy2(q/'ontology-result.yaml',o/'ontology-result.yaml')
print(json.dumps({'rawArtifacts':len(raw),'archiveBytes':a.stat().st_size,'sha256':sha(a.read_bytes())},ensure_ascii=False))
