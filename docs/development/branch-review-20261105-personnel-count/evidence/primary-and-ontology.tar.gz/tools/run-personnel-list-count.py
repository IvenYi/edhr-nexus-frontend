import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,sys,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend');mode=sys.argv[1];assert mode in ('red','green')
out=pathlib.Path('/tmp/edhr-personnel-count-main-'+mode+'-20261105');out.mkdir(exist_ok=False)
name='edhr-personnel-count-main-'+mode+'-20261105';db='edhr_record_control_test_personnel_'+mode;created=False;code=99
selected='WorkflowReadObservationPostgresTest#personnelDirectoryObservesFullPageCount+personnelDirectoryKeepsEligibilityAndTieOrder' if mode=='red' else 'WorkflowReadObservationPostgresTest,RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own PG not ready')
 run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE ROLE edhr LOGIN'])
 run(['docker','exec',name,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
 run(['docker','exec',name,'createdb','-U','postgres','edhr_workflow_read_test_'+mode])
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 env=os.environ.copy();env.update(RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',PGUSER='postgres',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test',W3_TRANSFER_DATABASE_USER='postgres',W3_TRANSFER_DATABASE_PASSWORD='')
 env['WORKFLOW_READ_TEST_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/edhr_workflow_read_test_'+mode
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'observations.jsonl'),'-Dtest='+selected,'test'];start=datetime.datetime.now(datetime.timezone.utc)
 source=[]
 for p in ['gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']:
  b=(root/p).read_bytes();source.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});dest=out/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 with (out/'maven.log').open('w') as log:r=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 runmeta={'command':command,'workingDirectory':str(root),'sourceCommit':run(['git','rev-parse','HEAD'],cwd=root),'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'sourceFingerprints':source,'database':env['RECORD_CONTROL_TEST_DATABASE_URL'],'observationDatabase':env['WORKFLOW_READ_TEST_DATABASE_URL'],'containerId':cid,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])}
 (out/'run.json').write_text(json.dumps(runmeta,indent=2)+'\n')
 totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[];missing=[]
 for test in selected.split(','):
  test=test.split('#')[0];files=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not files:missing.append(test)
  for p in files:
   shutil.copy2(p,out/p.name);doc=ET.parse(p).getroot();c={k:int(doc.attrib.get(k,0)) for k in totals};classes.append({'class':doc.attrib['name'],**c})
   for k in totals:totals[k]+=c[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'run':runmeta,'summary':summary}));print((out/'maven.log').read_text()[-3500:])
 code=0 if not missing and ((mode=='green' and r.returncode==0 and totals=={'tests':152,'failures':0,'errors':0,'skipped':0}) or (mode=='red' and r.returncode==1 and totals=={'tests':7,'failures':4,'errors':0,'skipped':0})) else 1
finally:
 if created:
  stopped=run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedName':name,'stopOutput':stopped,'removed':removed},indent=2)+'\n');print('owned cleanup',removed)
sys.exit(code)
