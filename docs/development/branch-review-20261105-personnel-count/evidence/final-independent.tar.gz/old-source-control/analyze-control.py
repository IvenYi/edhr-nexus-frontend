import hashlib
import json
import pathlib
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path(__file__).resolve().parent
BASE = '00f864cdaf0796c9410173c835a477c7a3068d06'
HEAD = 'ca836ef60415d61cf352cc3375a23106ec0f46a3'
HELPER = 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'

def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, capture_output=True, check=True).stdout

def put(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

old = (OUT / 'old-TenantTransferTargets.java').read_text()
candidate = git('show', HEAD + ':' + HELPER).decode()
(OUT / 'candidate-TenantTransferTargets.java').write_text(candidate)
old_terminal = '''return users.findAll(specification.and(scope), PageRequest.of(0, 100,
                        Sort.by("displayName").ascending().and(Sort.by("id").ascending()))).getContent().stream()'''
new_terminal = '''return users.findBy(specification.and(scope), finder -> finder
                        .sortBy(Sort.by("displayName").ascending().and(Sort.by("id").ascending()))
                        .limit(100).all()).stream()'''
assert old.count(old_terminal) == 1
assert old.replace('import org.springframework.data.domain.PageRequest;\n', '').replace(old_terminal, new_terminal) == candidate
(OUT / 'product-diff.patch').write_bytes(git('diff', BASE, HEAD, '--', HELPER))
put('product-equivalence.json', {
    'exactReconstructionWithOnlyTerminalAndImportReplacement': True,
    'unchanged': ['all search overloads', 'tenant and ACTIVE status predicates', 'unlocked predicate',
                  'operator exclusion predicate', 'normalized keyword predicates',
                  'permission EXISTS predicates joined with AND', 'domain scope joined before database bound',
                  'displayName then Long id ordering', 'database limit 100',
                  'post-read available/operator filters', 'Map response fields', 'require and available methods'],
    'oldProductBlob': git('rev-parse', BASE + ':' + HELPER).decode().strip(),
    'candidateProductBlob': git('rev-parse', HEAD + ':' + HELPER).decode().strip(),
    'noRepairsByThisRole': True})

observations = [json.loads(line) for line in (OUT / 'observations.jsonl').read_text().splitlines()]
assert len(observations) == 7
assert [o['totalStatements'] for o in observations] == [1, 1, 1, 2, 2, 2, 2]
assert [o['data'].get('matchingPersonnel') for o in observations[:6]] == [0, 1, 99, 100, 101, 5000]
assert [o['data']['returnedPersonnel'] for o in observations] == [0, 1, 99, 100, 100, 100, 100]
server = (OUT / 'postgres.log').read_text().splitlines()
entries = []
for i, line in enumerate(server):
    if re.search(r'LOG:  execute [^:]+: select (?:ua1_0\.id|count\(ua1_0\.id\))', line):
        assert ' from user_account ua1_0 where ua1_0.tenant_id=$1' in line
        params = server[i + 1]
        assert 'DETAIL:  parameters:' in params
        is_count = ': select count(ua1_0.id)' in line
        if not is_count:
            assert "order by ua1_0.display_name,ua1_0.id offset $7 rows fetch first $8 rows only" in line
            assert "$7 = '0', $8 = '100'" in params
        assert "$1 = '0', $2 = 'ACTIVE'" in params and "$4 = '42'" in params
        entries.append({'line': i + 1, 'kind': 'count' if is_count else 'content',
                        'statement': line, 'parameters': params})
assert len(entries) == 11
assert sum(e['kind'] == 'content' for e in entries) == 7
assert sum(e['kind'] == 'count' for e in entries) == 4
doc = ET.parse(OUT / 'TEST-com.zencas.edhr.workflow.service.WorkflowReadObservationPostgresTest.xml').getroot()
failures = []
for case in doc.findall('testcase'):
    failure = case.find('failure')
    if failure is not None:
        location = re.search(r'WorkflowReadObservationPostgresTest\.java:(\d+)', failure.text or '')
        assert location
        failures.append({'name': case.attrib['name'], 'type': failure.attrib['type'],
                         'message': failure.attrib['message'], 'firstTestFailureLine': int(location.group(1))})
assert len(failures) == 4
assert [f['firstTestFailureLine'] for f in failures] == [191, 191, 191, 218]
put('negative-control-analysis.json', {
    'status': 'passed', 'caseCount': 7, 'realQueryBudgetFailures': 4, 'positiveControls': 3,
    'environmentCompilationFixtureErrors': 0, 'skipped': 0,
    'semanticAssertionsPrecedeRecordAndBudget': True,
    'allSemanticAssertionsPassed': True,
    'failureSitesAreOnlyQueryBudgetAssertions': failures,
    'observations': [{'kind': o['kind'], 'data': o['data'], 'totalStatements': o['totalStatements'],
                      'countStatements': sum('count(' in sql.lower() for sql in o['hibernateSql'])} for o in observations],
    'serverDirectoryContentStatements': 7, 'serverDirectoryCountStatements': 4,
    'serverDirectoryTotalStatements': 11, 'allContentDatabaseBounds': 100,
    'excluded': 'Startup, migrations, fixture preparation and bookkeeping SQL; this is not all network SQL.',
    'serverEvidence': entries})

paths = ['AGENTS.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/quality-verifier.md',
         'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml', 'docs/knowledge/schema.yaml',
         'docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml',
         'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
         'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
         'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md',
         'docs/knowledge/evidence/workflow-operations-20261030.md',
         'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md',
         'docs/development/workflow-central-entry-extension-20261102/user-confirmed.md',
         'docs/development/workflow-operations-20261030/user-confirmed.md']
paths += [str(p.relative_to(ROOT)) for p in sorted((ROOT / 'docs/development/branch-review-20261105-personnel-count').iterdir()) if p.is_file()]
inputs = []
for path in paths:
    content = (ROOT / path).read_bytes()
    inputs.append({'path': path, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest(),
                   'gitBlob': git('rev-parse', HEAD + ':' + path).decode().strip(),
                   'sameAtBase': git('show', BASE + ':' + path) == content if not path.startswith('docs/development/branch-review-20261105-personnel-count/') else None})
assert all(p['sameAtBase'] is True for p in inputs if p['sameAtBase'] is not None)
put('baseline-and-inputs.json', {
    'baseCommit': BASE, 'headCommit': HEAD, 'contractReadCommit': HEAD,
    'targetBranch': 'edhr-dev', 'targetCommit': git('rev-parse', 'origin/edhr-dev').decode().strip(),
    'mainStatusAfterOwnCleanup': git('status', '--porcelain=v1').decode(),
    'contractAndKnowledgeUnchangedAtBase': True, 'knowledgeModelVersion': '0.3.25',
    'schemaVersion': '1.2.0', 'currentStage': 'P0', 'inputs': inputs,
    'limitedKnowledgeRead': 'Relevant current README sections, open-questions, decisions and original confirmation evidence; not a full semantic knowledge audit.'})
print(json.dumps({'negativeControl': 'passed', 'counts': [7, 4, 3, 0, 0], 'serverSelects': 11, 'sourceEquivalent': True}))
