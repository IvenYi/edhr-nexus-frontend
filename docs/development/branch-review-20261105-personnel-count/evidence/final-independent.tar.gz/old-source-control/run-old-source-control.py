import datetime as dt
import hashlib
import json
import os
import pathlib
import shutil
import subprocess
import sys
import time
import traceback
import xml.etree.ElementTree as ET

OUT = pathlib.Path(__file__).resolve().parent
REPO = pathlib.Path('/workspace/edhr-nexus-frontend')
WT = pathlib.Path('/tmp/edhr-personnel-old-control-wt-20261105')
BASE = '00f864cdaf0796c9410173c835a477c7a3068d06'
HEAD = 'ca836ef60415d61cf352cc3375a23106ec0f46a3'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
HELPER = 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java'
NAME = 'edhr-personnel-final-old-control-20261105'
DB = 'edhr_workflow_read_test_final_old_control_20261105'
SELECTED = 'WorkflowReadObservationPostgresTest#personnelDirectoryObservesFullPageCount+personnelDirectoryKeepsEligibilityAndTieOrder'
created_container = False
created_worktree = False
made_link = False
exitcode = 2

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def write(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def run(args, cwd=None, check=True):
    started = now()
    p = subprocess.run(args, cwd=cwd, capture_output=True, text=True)
    with (OUT / 'commands.jsonl').open('a') as f:
        f.write(json.dumps({'started': started, 'finished': now(), 'command': args,
                           'cwd': str(cwd) if cwd else None, 'exitCode': p.returncode,
                           'stdout': p.stdout, 'stderr': p.stderr}, ensure_ascii=False) + '\n')
    if check and p.returncode:
        raise RuntimeError(f'Own command failed ({p.returncode}): {args}\n{p.stdout}\n{p.stderr}')
    return p.stdout.strip()

try:
    assert not (OUT / 'run.json').exists(), 'Do not overwrite an earlier execution'
    assert not WT.exists(), 'Independent worktree path already exists'
    assert run(['git', 'rev-parse', 'HEAD'], REPO) == HEAD
    assert run(['git', 'rev-parse', 'origin/edhr-dev'], REPO) == BASE
    assert run(['git', 'status', '--porcelain=v1'], REPO) == ''
    run(['git', 'merge-base', '--is-ancestor', BASE, HEAD], REPO)
    run(['git', 'worktree', 'add', '--detach', str(WT), BASE], REPO)
    created_worktree = True
    source_before = run(['git', 'hash-object', HELPER], WT)
    test_blob = subprocess.run(['git', 'show', HEAD + ':' + TEST], cwd=REPO,
                               capture_output=True, check=True).stdout
    (WT / TEST).write_bytes(test_blob)
    candidate_blob = run(['git', 'rev-parse', HEAD + ':' + TEST], REPO)
    assembled_blob = run(['git', 'hash-object', TEST], WT)
    assert candidate_blob == assembled_blob
    old_blob = run(['git', 'rev-parse', BASE + ':' + HELPER], REPO)
    assert source_before == old_blob
    snapshots = []
    for label, data in [('old-TenantTransferTargets.java', (WT / HELPER).read_bytes()),
                        ('candidate-WorkflowReadObservationPostgresTest.java', test_blob)]:
        (OUT / label).write_bytes(data)
        snapshots.append({'path': label, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    write('source-fingerprints.json', {'baseCommit': BASE, 'candidateCommit': HEAD,
          'oldProductBlob': old_blob, 'oldProductAssembledBlob': source_before,
          'candidateTestBlob': candidate_blob, 'assembledTestBlob': assembled_blob,
          'snapshots': snapshots})
    link = WT / 'gmp-platform/frontend/node_modules'
    link.symlink_to(REPO / 'gmp-platform/frontend/node_modules', target_is_directory=True)
    made_link = True
    write('assembly.json', {'sourceHead': run(['git', 'rev-parse', 'HEAD'], WT),
          'expectedModifiedPath': TEST, 'toolingSymlink': str(link),
          'status': run(['git', 'status', '--porcelain=v1'], WT),
          'testOrigin': HEAD + ':' + TEST, 'testCopiedExactly': True})
    cid = run(['docker', 'run', '--rm', '-d', '--name', NAME,
               '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', '-e', 'POSTGRES_DB=' + DB,
               '-p', '127.0.0.1::5432', 'postgres:16-alpine',
               '-c', 'log_statement=all', '-c', 'log_connections=on'])
    created_container = True
    for _ in range(120):
        ready = subprocess.run(['docker', 'exec', NAME, 'pg_isready', '-h', '127.0.0.1', '-U', 'postgres'],
                               capture_output=True)
        if ready.returncode == 0:
            break
        time.sleep(0.5)
    else:
        raise RuntimeError('Own PostgreSQL did not become ready')
    port = run(['docker', 'inspect', '--format', '{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}', NAME])
    url = f'jdbc:postgresql://127.0.0.1:{port}/{DB}'
    env = os.environ.copy()
    env.update(PGUSER='postgres', WORKFLOW_READ_TEST_DATABASE_URL=url)
    command = ['bash', '/workspace/.edhr-cloud-tools/mvn-edhr', '-f', 'gmp-platform/backend/pom.xml',
               '-Dedhr.audit.workflowReads=true', '-Dedhr.audit.workflowReadOutput=' + str(OUT / 'observations.jsonl'),
               '-Dtest=' + SELECTED, 'test']
    start = dt.datetime.now(dt.timezone.utc)
    write('started.json', {'command': command, 'cwd': str(WT), 'started': start.isoformat(),
          'baseCommit': BASE, 'candidateTestCommit': HEAD, 'observationDatabase': url,
          'containerId': cid, 'containerName': NAME, 'purpose': 'old-source negative control'})
    with (OUT / 'maven.log').open('w') as log:
        process = subprocess.run(command, cwd=WT, env=env, stdout=log, stderr=subprocess.STDOUT)
    finished = now()
    with (OUT / 'commands.jsonl').open('a') as f:
        f.write(json.dumps({'started': start.isoformat(), 'finished': finished, 'command': command,
                           'cwd': str(WT), 'exitCode': process.returncode,
                           'stdoutAndStderr': 'maven.log',
                           'environmentOverrides': {'PGUSER': 'postgres', 'WORKFLOW_READ_TEST_DATABASE_URL': url}}) + '\n')
    totals = {key: 0 for key in ('tests', 'failures', 'errors', 'skipped')}
    reports = []
    cases = []
    for source in (WT / 'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml'):
        assert source.stat().st_mtime >= start.timestamp(), 'Stale JUnit report'
        shutil.copy2(source, OUT / source.name)
        document = ET.parse(source).getroot()
        counts = {key: int(document.attrib.get(key, 0)) for key in totals}
        for key in totals:
            totals[key] += counts[key]
        reports.append({'path': source.name, 'mtime': source.stat().st_mtime, **counts})
        for testcase in document.findall('testcase'):
            failure = testcase.find('failure')
            error = testcase.find('error')
            cases.append({'name': testcase.attrib['name'],
                          'outcome': 'failure' if failure is not None else 'error' if error is not None else 'skipped' if testcase.find('skipped') is not None else 'passed',
                          'failureType': failure.attrib.get('type') if failure is not None else None,
                          'failureMessage': failure.attrib.get('message') if failure is not None else None})
    version = run(['docker', 'exec', NAME, 'psql', '-U', 'postgres', '-d', DB, '-Atc', 'SELECT version()'])
    migrations = run(['docker', 'exec', NAME, 'psql', '-U', 'postgres', '-d', DB, '-Atc',
                      'SELECT id,filename,exectype FROM databasechangelog ORDER BY orderexecuted'])
    (OUT / 'liquibase-executed.txt').write_text(migrations + '\n')
    summary = {'totals': totals, 'reports': reports, 'testcases': cases,
               'expected': {'tests': 7, 'failures': 4, 'errors': 0, 'skipped': 0},
               'mavenExitCode': process.returncode}
    write('test-summary.json', summary)
    write('run.json', {'command': command, 'cwd': str(WT), 'started': start.isoformat(),
          'finished': finished, 'exitCode': process.returncode, 'baseCommit': BASE,
          'candidateTestCommit': HEAD, 'observationDatabase': url, 'postgres': version,
          'containerId': cid, 'liquibaseChangeCount': len(migrations.splitlines())})
    assert reports, 'Missing fresh JUnit report'
    assert totals == summary['expected'], 'Unexpected test distribution; inspect originals'
    assert process.returncode == 1, 'Expected Maven assertion-failure exit'
    failures = [c for c in cases if c['outcome'] == 'failure']
    assert all(c['failureType'] == 'java.lang.AssertionError' for c in failures)
    assert all('Expecting actual:\n  2\nto be less than or equal to:\n  1' in c['failureMessage'] for c in failures)
    assert run(['git', 'hash-object', HELPER], WT) == old_blob
    assert run(['git', 'hash-object', TEST], WT) == candidate_blob
    write('post-run-source.json', {'oldProductBlob': old_blob, 'candidateTestBlob': candidate_blob,
          'worktreeStatus': run(['git', 'status', '--porcelain=v1'], WT)})
    exitcode = 0
except BaseException:
    (OUT / 'runner-error.txt').write_text(traceback.format_exc())
    print(traceback.format_exc())
finally:
    cleanup = {'ownedContainer': NAME, 'ownedWorktree': str(WT)}
    if created_container:
        logs = subprocess.run(['docker', 'logs', NAME], capture_output=True, text=True)
        (OUT / 'postgres.log').write_text(logs.stdout + logs.stderr)
        cleanup['containerStop'] = run(['docker', 'stop', NAME], check=False)
        for _ in range(50):
            inspect = subprocess.run(['docker', 'inspect', NAME], capture_output=True)
            if inspect.returncode != 0:
                cleanup['containerRemoved'] = True
                break
            time.sleep(0.1)
        else:
            cleanup['containerRemoved'] = False
    if made_link:
        link.unlink()
        cleanup['toolingSymlinkRemoved'] = not link.exists()
    if created_worktree:
        cleanup['worktreeFinalStatus'] = run(['git', 'status', '--porcelain=v1'], WT)
        run(['git', 'worktree', 'remove', '--force', str(WT)], REPO)
        cleanup['worktreeRemoved'] = not WT.exists()
    cleanup['mainHead'] = run(['git', 'rev-parse', 'HEAD'], REPO)
    cleanup['mainStatus'] = run(['git', 'status', '--porcelain=v1'], REPO)
    cleanup['runnerExitCode'] = exitcode
    write('cleanup.json', cleanup)
    print(json.dumps({'runnerExitCode': exitcode, 'output': str(OUT), 'cleanup': cleanup}, ensure_ascii=False))
sys.exit(exitcode)
