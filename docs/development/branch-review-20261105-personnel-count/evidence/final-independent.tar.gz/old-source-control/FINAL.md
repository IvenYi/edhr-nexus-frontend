FINAL — independent old-source negative control passed.

Unchanged old product `00f864cdaf0796c9410173c835a477c7a3068d06` plus byte-identical candidate test from `ca836ef60415d61cf352cc3375a23106ec0f46a3` ran once on isolated PostgreSQL 16.15. Seven invocations produced 4 genuine query-budget assertion failures and 3 positive controls, 0 test errors and 0 skips. All response, eligibility and numeric-ID tie-order assertions precede and passed before the failing budgets at original final test lines 191/218.

The 0/1/99 cases read once; 100/101/5000 and the 120-person tie fixture each read twice due to COUNT. Server logs independently show 7 content SELECTs with offset 0 / fetch 100 and 4 COUNTs. Startup, fixture and bookkeeping SQL are excluded; this is not all network traffic. All 11 changes in the configured Liquibase graph actually executed, not every historical migration file.

The initial report analyzer guessed source line numbers incorrectly; its original source and error are retained. Correcting that own report assertion did not touch product, test, fixture, configuration, raw run evidence or test counts, and no Maven rerun was needed. Source hashes before/after prove the test and old helper were untouched after assembly.

Own container/worktree/tooling link are removed. Main source remains clean at `ca836ef...`. This result is solely the old-source control: current-candidate acceptance remains the parent role's separate final QA responsibility. No new candidate defect, business change, browser/HTTP/JWT/complete signing claim, merge, deployment, CI action or historical recovery was performed.

Artifacts are frozen after manifest creation. `manifest.json` inventories evidence files, excluding itself and its digest receipt; `manifest.sha256` binds the manifest.
