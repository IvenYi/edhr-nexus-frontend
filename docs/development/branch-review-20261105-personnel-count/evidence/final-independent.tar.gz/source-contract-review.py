import datetime, hashlib, json, pathlib, re, subprocess
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-personnel-count-final-qa-20261105/source-review');OUT.mkdir(exist_ok=False)
HEAD='ca836ef60415d61cf352cc3375a23106ec0f46a3'
BASE='00f864cdaf0796c9410173c835a477c7a3068d06'
commands=[]
def run(args, check=True):
    p=subprocess.run(args,cwd=ROOT,capture_output=True)
    commands.append({'command':args,'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
    if check:assert p.returncode==0,(args,p.stderr)
    return p.stdout
def gitfile(commit,path):return run(['git','show',commit+':'+path])
def fp(b):return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/knowledge/evidence/workflow-operations-20261030.md','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md','docs/development/workflow-central-entry-extension-20261102/user-confirmed.md']
paths+=['docs/development/branch-review-20261105-personnel-count/'+x for x in ['decision-package.yaml','README.md','review-notes.md','ontology-result.yaml','performance-report.json','source-review.json','baseline-review.json','evidence-manifest.json']]
prod='gmp-platform/backend/src/main/java/com/zencas/edhr/'
paths+=[prod+x for x in ['identity/service/TenantTransferTargets.java','workflow/service/WorkflowOperationsQuery.java','workflow/service/WorkflowResponsibilityService.java','workflow/engine/WorkflowEngine.java','production/service/ExecutionAccess.java','production/service/FormWorkflowOperations.java','identity/repository/UserAccountRepository.java']]
paths+=['gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']
inputs=[]
for path in paths:
    b=(ROOT/path).read_bytes();target=OUT/'inputs'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
    inputs.append({'path':path,**fp(b),'sameAsCandidateGit':b==gitfile(HEAD,path)})
helper=prod+'identity/service/TenantTransferTargets.java'
old=gitfile(BASE,helper).decode();new=gitfile(HEAD,helper).decode()
before='        return users.findAll(specification.and(scope), PageRequest.of(0, 100,\n                        Sort.by("displayName").ascending().and(Sort.by("id").ascending()))).getContent().stream()'
after='        return users.findBy(specification.and(scope), finder -> finder\n                        .sortBy(Sort.by("displayName").ascending().and(Sort.by("id").ascending()))\n                        .limit(100).all()).stream()'
assert old.count(before)==1 and new.count(after)==1
expected=old.replace('import org.springframework.data.domain.PageRequest;\n','').replace(before,after)
assert new==expected
protected={'completeHelperEqualsOnlyAllowedQueryReplacement':new==expected,'specificationAndAllOtherHelperBytesIdentical':True}
for path in paths:
    if path.startswith(prod) and path!=helper:protected[path]=gitfile(BASE,path)==gitfile(HEAD,path)
knowledge=[]
for path in run(['git','ls-tree','-r','--name-only',HEAD,'--','docs/knowledge']).decode().splitlines():
    b=gitfile(HEAD,path);knowledge.append({'path':path,**fp(b),'sameBaseBytes':gitfile(BASE,path)==b,'sameWorkingTreeBytes':(ROOT/path).read_bytes()==b})
assert len(knowledge)==345 and all(x['sameBaseBytes'] and x['sameWorkingTreeBytes'] for x in knowledge)
changed=run(['git','diff','--name-status',BASE,HEAD]).decode();(OUT/'changed-paths.txt').write_text(changed)
(OUT/'product-test.diff').write_bytes(run(['git','diff',BASE,HEAD,'--','gmp-platform/backend/src/main','gmp-platform/backend/src/test']))
javap='/workspace/.edhr-cloud-tools/jdk-21/bin/javap'
jars={'commons':'/workspace/.pr6-m2/org/springframework/data/spring-data-commons/3.3.0/spring-data-commons-3.3.0.jar','jpa':'/workspace/.pr6-m2/org/springframework/data/spring-data-jpa/3.3.0/spring-data-jpa-3.3.0.jar'}
api=run([javap,'-classpath',jars['commons'],'org.springframework.data.repository.query.FluentQuery$FetchableFluentQuery']).decode();(OUT/'installed-api.txt').write_text(api)
impl=run([javap,'-c','-p','-classpath',jars['jpa'],'org.springframework.data.jpa.repository.support.FetchableFluentQueryBySpecification']).decode();(OUT/'installed-jpa-implementation.txt').write_text(impl)
allbody=impl.split('public java.util.List<R> all();',1)[1].split('\n  public ',1)[0]
createbody=impl.split('private jakarta.persistence.TypedQuery<S> createSortedAndProjectedQuery();',1)[1].split('\n  private ',1)[0]
assert 'limit(int)' in api and 'createSortedAndProjectedQuery' in allbody and 'getResultList' in allbody and 'countOperation' not in allbody and 'setMaxResults' in createbody
(OUT/'framework-extract.txt').write_text('all()'+allbody+'\ncreateSortedAndProjectedQuery()'+createbody)
(OUT/'input-fingerprints.json').write_text(json.dumps(inputs,indent=2)+'\n')
(OUT/'knowledge-byte-check.json').write_text(json.dumps({'count':len(knowledge),'allUnchanged':True,'files':knowledge},indent=2)+'\n')
(OUT/'protected-byte-check.json').write_text(json.dumps(protected,indent=2)+'\n')
(OUT/'framework-check.json').write_text(json.dumps({'version':'3.3.0','jars':{k:{'path':v,**fp(pathlib.Path(v).read_bytes())} for k,v in jars.items()},'allMethodNoCount':True,'databaseSetMaxResults':True,'initialShellToolingProbe':{'command':'javap ... (without wrapper toolchain PATH)','exitCode':127,'stderr':'javap: command not found','classification':'QA tool PATH probe, not compilation/test/product failure','correctedBy':'explicit installed JDK21 javap path'}},indent=2)+'\n')
(OUT/'baseline.json').write_text(json.dumps({'head':run(['git','rev-parse','HEAD']).decode().strip(),'target':run(['git','rev-parse','origin/edhr-dev']).decode().strip(),'headTree':run(['git','rev-parse',HEAD+'^{tree}']).decode().strip(),'baseTree':run(['git','rev-parse',BASE+'^{tree}']).decode().strip(),'status':run(['git','status','--porcelain=v1']).decode(),'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0 in-progress','readTime':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
(OUT/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'inputs':len(inputs),'knowledge':len(knowledge),'protections':protected,'framework':'passed'}))
