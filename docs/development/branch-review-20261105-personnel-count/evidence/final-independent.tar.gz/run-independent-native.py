import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time
import xml.etree.ElementTree as ET

OUT = pathlib.Path('/tmp/edhr-personnel-count-final-qa-20261105/native')
ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
WT = pathlib.Path('/tmp/edhr-personnel-count-final-qa-native-worktree-20261105')
HEAD = 'ca836ef60415d61cf352cc3375a23106ec0f46a3'
BASE = '00f864cdaf0796c9410173c835a477c7a3068d06'
NAME = 'edhr-personnel-count-final-qa-native-20261105'
CLASSES = 'WorkflowReadObservationPostgresTest,RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest'
OUT.mkdir(exist_ok=False)
COMMANDS = []
def run(args, cwd=ROOT, env=None, check=True):
    p = subprocess.run(args, cwd=cwd, env=env, capture_output=True, text=True)
    COMMANDS.append({'command': args, 'cwd': str(cwd), 'exitCode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    (OUT/'commands.json').write_text(json.dumps(COMMANDS, indent=2)+'\n')
    if check and p.returncode: raise RuntimeError(f'command failed: {args}: {p.stderr}')
    return p.stdout.strip()
def reports(reportdir, dest, start, expected, selected=None):
    dest.mkdir(exist_ok=True)
    total = dict(tests=0, failures=0, errors=0, skipped=0)
    classes=[]
    for p in sorted(reportdir.glob('TEST-*.xml')):
        if p.stat().st_mtime < start.timestamp(): continue
        doc=ET.parse(p).getroot()
        if selected is not None and doc.attrib['name'].rsplit('.',1)[-1] not in selected: continue
        shutil.copy2(p, dest/p.name)
        entry={'class':doc.attrib['name'], **{k:int(doc.attrib.get(k,0)) for k in total}, 'reportMtime':p.stat().st_mtime, 'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
        classes.append(entry)
        for k in total:total[k]+=entry[k]
    result={'totals':total,'classes':classes,'expected':expected,'freshAfter':start.isoformat()}
    (dest/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

created=False
worktree=False
link=None
status=99
try:
    baseline={'head':run(['git','rev-parse','HEAD']), 'target':run(['git','rev-parse','origin/edhr-dev']), 'status':run(['git','status','--porcelain=v1']), 'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    assert baseline['head']==HEAD and baseline['target']==BASE and baseline['status']==''
    run(['git','merge-base','--is-ancestor',BASE,HEAD])
    run(['git','worktree','add','--detach',str(WT),HEAD]);worktree=True
    link=WT/'gmp-platform/frontend/node_modules'
    link.symlink_to(ROOT/'gmp-platform/frontend/node_modules',target_is_directory=True)
    baseline['worktreeStatusWithToolingSymlink']=run(['git','status','--porcelain=v1'],cwd=WT)
    (OUT/'baseline-start.json').write_text(json.dumps(baseline,indent=2)+'\n')
    fingerprints=[]
    for path in [
        'AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md',
        'docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
        'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']:
        b=(WT/path).read_bytes();dest=OUT/'source-snapshot'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        fingerprints.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
    (OUT/'source-fingerprints.json').write_text(json.dumps(fingerprints,indent=2)+'\n')
    record='edhr_record_control_test_final_count_qa'
    observer='edhr_workflow_read_test_final_count_qa'
    cid=run(['docker','run','--rm','-d','--name',NAME,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+record,'-p','127.0.0.1::5432','postgres:16-alpine']);created=True
    for _ in range(120):
        if subprocess.run(['docker','exec',NAME,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('own postgres TCP not ready')
    run(['docker','exec',NAME,'psql','-U','postgres','-d',record,'-c','CREATE ROLE edhr LOGIN'])
    run(['docker','exec',NAME,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
    run(['docker','exec',NAME,'createdb','-U','postgres',observer])
    port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',NAME])
    env=os.environ.copy();env.update(PGUSER='postgres',RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{record}',WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{observer}',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test',W3_TRANSFER_DATABASE_USER='postgres',W3_TRANSFER_DATABASE_PASSWORD='')
    meta={'head':run(['git','rev-parse','HEAD'],cwd=WT),'tree':run(['git','rev-parse','HEAD^{tree}'],cwd=WT),'containerId':cid,'port':port,'postgres':run(['docker','exec',NAME,'psql','-U','postgres','-d',record,'-Atc','SELECT version()']),'databases':{k:env[k] for k in ['RECORD_CONTROL_TEST_DATABASE_URL','WORKFLOW_READ_TEST_DATABASE_URL','W3_TRANSFER_DATABASE_URL']}}
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(OUT/'observations.jsonl'),'-Dtest='+CLASSES,'test']
    start=datetime.datetime.now(datetime.timezone.utc)
    with (OUT/'maven-native.log').open('w') as log:r=subprocess.run(command,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
    meta['native']={'command':command,'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode}
    native=reports(WT/'gmp-platform/backend/target/surefire-reports',OUT/'native-reports',start,152,set(CLASSES.split(',')))
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test']
    kstart=datetime.datetime.now(datetime.timezone.utc)
    with (OUT/'maven-knowledge.log').open('w') as log:kr=subprocess.run(command,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
    meta['knowledge']={'command':command,'started':kstart.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':kr.returncode}
    knowledge=reports(WT/'tools/knowledge-model/target/surefire-reports',OUT/'knowledge-reports',kstart,89)
    (OUT/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
    for db in [record,observer]:
        (OUT/(db+'-liquibase.csv')).write_text(run(['docker','exec',NAME,'psql','-U','postgres','-d',db,'--csv','-c','SELECT id,author,filename,exectype FROM databasechangelog ORDER BY orderexecuted'])+'\n')
    (OUT/'postgres.log').write_text(subprocess.run(['docker','logs',NAME],capture_output=True,text=True).stdout+subprocess.run(['docker','logs',NAME],capture_output=True,text=True).stderr)
    status=0 if r.returncode==0 and kr.returncode==0 and native['totals']==dict(tests=152,failures=0,errors=0,skipped=0) and knowledge['totals']==dict(tests=89,failures=0,errors=0,skipped=0) and len(native['classes'])==10 else 1
    print(json.dumps({'native':native,'knowledge':knowledge,'status':status}))
except Exception as e:
    (OUT/'environment-error.json').write_text(json.dumps({'error':repr(e)},indent=2)+'\n')
    print(repr(e));status=2
finally:
    cleanup={}
    if created:
        cleanup['dockerStop']=run(['docker','stop',NAME]);
        for _ in range(30):
            if subprocess.run(['docker','inspect',NAME],capture_output=True).returncode!=0:break
            time.sleep(.1)
        cleanup['containerRemoved']=subprocess.run(['docker','inspect',NAME],capture_output=True).returncode!=0
    if link is not None and link.is_symlink():link.unlink();cleanup['toolingSymlinkRemoved']=True
    if worktree:
        cleanup['worktreeStatusAfterSymlinkRemoval']=run(['git','status','--porcelain=v1'],cwd=WT)
        run(['git','worktree','remove',str(WT)]);cleanup['worktreeRemoved']=not WT.exists()
    cleanup['mainHead']=run(['git','rev-parse','HEAD']);cleanup['mainStatus']=run(['git','status','--porcelain=v1'])
    (OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
sys.exit(status)
