import pathlib, json, re, collections, hashlib

OUT=pathlib.Path('/tmp/edhr-personnel-count-final-qa-20261105/server-sql')
def norm(sql):
    return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql)).strip().rstrip(';').lower()

events=[json.loads(x) for x in (OUT/'observations.jsonl').read_text().splitlines() if x.strip()]
expected=collections.Counter()
event_details=[];directory_signatures=set()
for e in events:
    sqls=e['jdbcSql']+e['hibernateSql']
    counter=collections.Counter(norm(s) for s in sqls)
    expected.update(counter)
    if e['kind'].startswith('personnel-directory'):directory_signatures.update(counter)
    event_details.append(dict(kind=e['kind'],data=e['data'],totalStatements=e['totalStatements'],normalizedSqlCounts=dict(counter)))

entries=[];active=None;last_pid={}
for number,line in enumerate((OUT/'postgres-server.log').read_text().splitlines(),1):
    line=re.sub(r'^\d{4}-\d\d-\d\dT\S+Z ','',line)
    m=re.match(r'^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+ UTC \[(\d+)\] ([A-Z]+):\s+(.*)$',line)
    if m:
        pid,level,message=m.groups();active=None
        q=re.match(r'(?:execute [^:]+:|statement:)\s*(.*)$',message)
        if level=='LOG' and q:
            active=dict(line=number,pid=int(pid),sql=q.group(1),parameters=None)
            entries.append(active);last_pid[pid]=active
        elif level=='DETAIL' and message.startswith('parameters:') and pid in last_pid:
            last_pid[pid]['parameters']=message.removeprefix('parameters:').strip()
    elif active is not None:
        active['sql']+='\n'+line
for q in entries:q['normalizedSql']=norm(q['sql'])

matched=[q for q in entries if q['normalizedSql'] in expected]
actual=collections.Counter(q['normalizedSql'] for q in matched)
signatures=[]
for i,(sql,n) in enumerate(expected.items(),1):
    signatures.append(dict(id='SQL-%02d'%i,normalizedSql=sql,expectedCount=n,serverCount=actual[sql],matches=n==actual[sql],directory=sql in directory_signatures,nameBatch='from user_account where cast(id as varchar)' in sql,serverLines=[q['line'] for q in matched if q['normalizedSql']==sql]))

directory=[q for q in matched if q['normalizedSql'] in directory_signatures]
directory_limits=[]
for q in directory:
    p=re.search(r'(?:fetch first|limit)\s+\$(\d+)',q['sql'],re.I)
    bind=p.group(1) if p else None
    parameters=q['parameters'] or ''
    value=re.search(r'(?:^|, )\$'+re.escape(bind or 'missing')+r" = '([^']*)'(?=, \$|$)",parameters)
    directory_limits.append(dict(serverLine=q['line'],limitParameter=bind,limitValue=value.group(1) if value else None,parameters=parameters,hasDisplayNameThenNumericId=bool(re.search(r'order by\s+\w+\.display_name\s*,\s*\w+\.id',q['sql'],re.I)),databaseLimit100=bool(value and value.group(1)=='100'),hasCount='count(' in q['normalizedSql']))

name_batch=[dict(serverLine=q['line'],parameterNumbers=re.findall(r'(?:^|, )\$(\d+) =',q['parameters'] or ''),parameterTextBytes=len((q['parameters'] or '').encode())) for q in matched if 'from user_account where cast(id as varchar)' in q['normalizedSql']]

unmatched=[q for q in entries if q['normalizedSql'] not in expected]
unmatched_selects=[q for q in unmatched if re.match(r'^(?:/\*.*?\*/\s*)?select\b',q['normalizedSql'])]
excluded=collections.Counter(q['normalizedSql'] for q in unmatched_selects)
categories=collections.Counter()
def category(sql):
    if 'snapshot_data::text from signature where id=777' in sql or 'candidate_snapshot::text from workflow_task where id=10000' in sql:return 'fixture-and-historical-signature-assertions'
    if 'databasechangelog' in sql or 'information_schema' in sql or 'pg_' in sql or 'version()' in sql:return 'startup-schema-liquibase-or-independent-metadata'
    if sql in ('select 1','select current_schema()','select current_database()'):return 'startup-connection-or-schema'
    return 'other-outside-capture-inspect-raw-sql'
for sql,count in excluded.items():categories[category(sql)]+=count

summary=dict(status='FINAL',candidate='ca836ef60415d61cf352cc3375a23106ec0f46a3',eventCount=len(events),measuredSelectExecutions=sum(expected.values()),serverMatchedSelectExecutions=sum(actual.values()),measuredSignatureCount=len(expected),serverMatchedSignatureCount=len(actual),allSignatureCountsEqual=actual==expected,signatures=signatures,directoryExecutionCount=len(directory),directoryLimits=directory_limits,allDirectoryDatabaseLimits100=all(q['databaseLimit100'] for q in directory_limits),allDirectoryOrderByDisplayNameThenId=all(q['hasDisplayNameThenNumericId'] for q in directory_limits),directoryCountStatements=sum(q['hasCount'] for q in directory_limits),nameBatchExecutionCount=sum(q['nameBatch']*q['serverCount'] for q in signatures),nameBatchParameters=name_batch,allNameBatchesOneArrayBind=all(x['parameterNumbers']==['1'] for x in name_batch),serverSqlLogEntryCount=len(entries),excludedSqlLogEntryCount=len(unmatched),excludedSelectLogEntryCount=len(unmatched_selects),excludedSelectSignatureCount=len(excluded),excludedSelectCategories=dict(categories),excludedSelects=[dict(normalizedSql=s,count=c,category=category(s)) for s,c in excluded.items()],boundary='Exact observed service SQL signatures matched against log_statement=all execution records in this self-owned isolated PostgreSQL run. Nonmatching startup/schema/fixture/historical-assertion/metadata SELECT log entries excluded. This is not all network SQL, HTTP/JWT/browser coverage, production latency or full-distribution EXPLAIN evidence.')
(OUT/'server-sql-entries.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2)+'\n')
(OUT/'observations-classified.json').write_text(json.dumps(event_details,ensure_ascii=False,indent=2)+'\n')
(OUT/'server-sql-crosscheck.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ('directoryLimits','signatures','excludedSelects')},ensure_ascii=False,indent=2))
assert len(events)==14
assert actual==expected
assert len(directory)==7 and summary['allDirectoryDatabaseLimits100'] and summary['allDirectoryOrderByDisplayNameThenId']
assert not summary['directoryCountStatements']
assert len(expected)==7 and sum(expected.values())==47 and summary['nameBatchExecutionCount']==5
assert summary['allNameBatchesOneArrayBind']
