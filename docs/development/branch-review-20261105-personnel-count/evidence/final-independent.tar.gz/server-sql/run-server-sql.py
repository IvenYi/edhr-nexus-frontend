import pathlib, subprocess, os, json, time, datetime, hashlib, shutil, traceback, xml.etree.ElementTree as ET

OUT=pathlib.Path('/tmp/edhr-personnel-count-final-qa-20261105/server-sql')
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
HEAD='ca836ef60415d61cf352cc3375a23106ec0f46a3'
BASE='00f864cdaf0796c9410173c835a477c7a3068d06'
WT=pathlib.Path('/tmp/edhr-personnel-count-server-sql-worktree-20261105')
NAME='edhr-personnel-count-server-sql-20261105'
DB='edhr_workflow_read_test_server_sql_20261105'
COMMANDS=[]
created=False; worktree=False; symlink=False; exitcode=2

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(args, cwd=ROOT, env=None, check=True):
    n=len(COMMANDS)+1; start=now()
    r=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
    out='command-%02d.stdout.txt'%n; err='command-%02d.stderr.txt'%n
    (OUT/out).write_text(r.stdout); (OUT/err).write_text(r.stderr)
    COMMANDS.append(dict(argv=args,cwd=str(cwd),started=start,finished=now(),exitCode=r.returncode,stdout=out,stderr=err))
    (OUT/'commands.json').write_text(json.dumps(COMMANDS,ensure_ascii=False,indent=2)+'\n')
    if check and r.returncode: raise RuntimeError(f'command {n} failed: {args}; {r.stderr[-1000:]}')
    return r.stdout.strip()

try:
    assert run(['git','rev-parse','HEAD'])==HEAD
    assert run(['git','rev-parse','origin/edhr-dev'])==BASE
    assert not run(['git','status','--porcelain'])
    run(['git','merge-base','--is-ancestor',BASE,HEAD])
    run(['git','worktree','add','--detach',str(WT),HEAD]);worktree=True
    dep=WT/'gmp-platform/frontend/node_modules';dep.symlink_to(ROOT/'gmp-platform/frontend/node_modules',target_is_directory=True);symlink=True
    sources=[]
    for p in ['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java','gmp-platform/backend/src/main/resources/application.yml']:
        f=WT/p
        if not f.exists(): continue
        b=f.read_bytes(); original=subprocess.check_output(['git','show',HEAD+':'+p],cwd=ROOT)
        assert b==original
        dest=OUT/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        sources.append(dict(path=p,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),matchesCandidateBlob=True))
    (OUT/'source-fingerprints.json').write_text(json.dumps(sources,indent=2)+'\n')
    run(['docker','run','--rm','-d','--name',NAME,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+DB,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_statement=all']);created=True
    for _ in range(120):
        r=subprocess.run(['docker','exec',NAME,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True)
        if not r.returncode: break
        time.sleep(.5)
    else: raise RuntimeError('own PostgreSQL not ready')
    port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',NAME])
    url=f'jdbc:postgresql://127.0.0.1:{port}/{DB}'
    env=os.environ.copy();env.update(WORKFLOW_READ_TEST_DATABASE_URL=url,PGUSER='postgres')
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(OUT/'observations.jsonl'),'-Dtest=WorkflowReadObservationPostgresTest','test']
    start=time.time();started=now()
    with (OUT/'maven.log').open('w') as log:r=subprocess.run(command,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
    meta=dict(command=command,workingDirectory=str(WT),environment={'WORKFLOW_READ_TEST_DATABASE_URL':url,'PGUSER':'postgres'},started=started,finished=now(),exitCode=r.returncode,headCommit=HEAD,baseCommit=BASE,tree=run(['git','rev-parse','HEAD^{tree}'],cwd=WT))
    (OUT/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
    reports=[]; totals=dict(tests=0,failures=0,errors=0,skipped=0)
    for f in (WT/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml'):
        assert f.stat().st_mtime>=start
        shutil.copy2(f,OUT/f.name);doc=ET.parse(f).getroot()
        c={k:int(doc.attrib.get(k,0)) for k in totals}
        reports.append(dict(path=f.name,mtime=f.stat().st_mtime,fresh=True,classname=doc.attrib['name'],**c))
        for k in totals: totals[k]+=c[k]
    (OUT/'test-summary.json').write_text(json.dumps(dict(totals=totals,reports=reports),indent=2)+'\n')
    dbmeta=run(['docker','exec',NAME,'psql','-U','postgres','-d',DB,'-Atc',"SELECT version(); SELECT count(*) FROM databasechangelog; SELECT id||'|'||author||'|'||filename FROM databasechangelog ORDER BY orderexecuted; SHOW log_statement;"])
    (OUT/'database-metadata.txt').write_text(dbmeta+'\n')
    # Preserve docker streams separately and combined, without altering original server SQL text.
    logs=subprocess.run(['docker','logs','--timestamps',NAME],capture_output=True,text=True)
    (OUT/'postgres-server.stdout.log').write_text(logs.stdout);(OUT/'postgres-server.stderr.log').write_text(logs.stderr)
    (OUT/'postgres-server.log').write_text(logs.stdout+'\n'+logs.stderr)
    assert reports and totals==dict(tests=14,failures=0,errors=0,skipped=0) and not r.returncode
    exitcode=0
except Exception:
    (OUT/'runner-error.txt').write_text(traceback.format_exc())
    print(traceback.format_exc())
finally:
    cleanup=dict(ownedContainer=NAME,ownedWorktree=str(WT),symlinkRemoved=False,worktreeClean=None,worktreeRemoved=False,containerRemoved=False)
    if created:
        try:
            run(['docker','stop',NAME])
            for _ in range(30):
                if subprocess.run(['docker','inspect',NAME],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
                    cleanup['containerRemoved']=True;break
                time.sleep(.1)
        except Exception: cleanup['containerCleanupError']=traceback.format_exc()
    if symlink:
        (WT/'gmp-platform/frontend/node_modules').unlink();cleanup['symlinkRemoved']=True
    if worktree:
        status=run(['git','status','--porcelain'],cwd=WT);cleanup['worktreeClean']=not status;cleanup['gitStatus']=status
        if not status:
            run(['git','worktree','remove',str(WT)]);cleanup['worktreeRemoved']=not WT.exists()
    cleanup['finished']=now();(OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
    print(json.dumps(dict(exitCode=exitcode,cleanup=cleanup)))
raise SystemExit(exitcode)
