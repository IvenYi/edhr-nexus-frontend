import datetime,hashlib,json,pathlib,yaml
root=pathlib.Path('/tmp/edhr-personnel-count-final-qa-20261105')
quality=yaml.safe_load((root/'quality-result.yaml').read_text())
assert quality['qualityResult']['result']=='passed' and quality['verificationScope']['status']=='FINAL'
children=json.loads((root/'child-results-verification.json').read_text())
for child in children:
    sub=root/child['role'];result=yaml.safe_load((sub/'result.yaml').read_text())
    assert result['qualityResult']['result']=='passed' and result.get('status',result.get('verificationScope',{}).get('status'))=='FINAL'
    assert hashlib.sha256((sub/'manifest.json').read_bytes()).hexdigest()==child['manifestSha256']
items=[]
for p in sorted(root.rglob('*')):
    if not p.is_file() or p in [root/'manifest.json',root/'manifest.sha256']:continue
    b=p.read_bytes();items.append({'path':str(p.relative_to(root)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'status':'FINAL','result':'passed','actualTestedCandidate':quality['verificationScope']['testedCandidate'],'tree':quality['verificationScope']['candidateTree'],'target':quality['qualityResult']['baseCommit'],'frozenAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fileCount':len(items),'totalBytes':sum(i['bytes'] for i in items),'excludedSelfReferentialPaths':['manifest.json','manifest.sha256'],'artifacts':items}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
digest=hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest();(root/'manifest.sha256').write_text(digest+'  manifest.json\n')
for item in items:
    b=(root/item['path']).read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
print(json.dumps({'status':'FINAL','result':'passed','artifactCount':len(items),'filesIncludingManifestDigest':len(items)+2,'totalArtifactBytes':manifest['totalBytes'],'manifestSha256':digest}))
