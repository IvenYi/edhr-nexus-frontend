#!/usr/bin/env python3
"""Read-only evidence/scope checks; never executes application tests or modifies repository."""
import collections
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import yaml

REPO = Path('/workspace/edhr-nexus-frontend')
OUT = Path(__file__).resolve().parent
PKG = Path('docs/development/branch-review-20261105-personnel-count')
BASE = '00f864cdaf0796c9410173c835a477c7a3068d06'
HEAD = 'ca836ef60415d61cf352cc3375a23106ec0f46a3'
HELPER = 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
COMMANDS = []
CHECKS = []
def sha(b): return hashlib.sha256(b).hexdigest()
def write(name, obj):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
def command(*args):
    p = subprocess.run(args, cwd=REPO, capture_output=True)
    COMMANDS.append({'command':list(args), 'exitCode':p.returncode,
                     'stdout':p.stdout.decode(errors='replace'), 'stderr':p.stderr.decode(errors='replace')})
    if p.returncode: raise RuntimeError(COMMANDS[-1])
    return p.stdout
def git(*args): return command('git', *args)
def check(name, ok, evidence):
    CHECKS.append({'id':name, 'outcome':'passed' if ok else 'failed', 'evidence':evidence})
def blob(path): return git('show', BASE + ':' + path)

OUT.mkdir(parents=True, exist_ok=True)
status=git('status','--porcelain=v1').decode()
check('candidate-and-clean-tree', git('rev-parse','HEAD').decode().strip()==HEAD and not status, status)
check('target-ref-and-ancestry', git('rev-parse','origin/edhr-dev').decode().strip()==BASE and
      command('git','merge-base','--is-ancestor',BASE,HEAD)==b'', 'origin/edhr-dev/base ancestry checked')
delta=git('diff','--name-only',BASE,HEAD).decode().splitlines()
product=[p for p in delta if '/src/main/' in p]
tests=[p for p in delta if '/src/test/' in p]
check('only-one-product-one-test',product==[HELPER] and tests==[TEST],delta)
(OUT/'candidate.diff').write_bytes(git('diff',BASE,HEAD,'--',HELPER,TEST))

manifest=json.loads((REPO/PKG/'evidence-manifest.json').read_bytes())
archive=REPO/PKG/manifest['archive']['path']
archive_data=archive.read_bytes()
check('primary-archive-bytes-sha',len(archive_data)==manifest['archive']['bytes'] and
      sha(archive_data)==manifest['archive']['sha256'],manifest['archive'])
with tarfile.open(archive) as tar:
    members={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
    allrows=[]
    for a in manifest['rawArtifacts']:
        b=members[a['member']]
        allrows.append({**a,'actualBytes':len(b),'actualSha256':sha(b),
                        'equal':len(b)==a['bytes'] and sha(b)==a['sha256']})
    check('all-76-raw-members',len(members)==len(allrows)==76 and all(x['equal'] for x in allrows),
          'archive-verification.json')
    write('archive-verification.json',{'archive':manifest['archive'],'memberCount':len(members),'members':allrows})

    om=json.loads(members['ontology/manifest.json'])
    nested=[]
    for a in om['artifacts']:
        b=members['ontology/'+a['path']]
        nested.append({**a,'equal':len(b)==a['bytes'] and sha(b)==a['sha256']})
    digest=members['ontology/manifest.sha256'].decode().split()[0]
    check('ontology-40-originals-and-final',om['status']=='FINAL' and om['artifactCount']==40 and
          len(nested)==40 and all(x['equal'] for x in nested) and
          sha(members['ontology/manifest.json'])==digest,'ontology-verification.json')

    fps=json.loads(members['ontology/source-fingerprints.json'])
    inputs=[]
    for a in fps['files']:
        b=(REPO/a['path']).read_bytes()
        inputs.append({**a,'currentEqual':len(b)==a['bytes'] and sha(b)==a['sha256'],
                       'snapshotEqual':b==members['ontology/'+a['snapshot']]})
    check('ontology-26-final-inputs',fps['fileCount']==len(inputs)==26 and
          all(x['currentEqual'] and x['snapshotEqual'] for x in inputs),'ontology-verification.json')
    finite=json.loads(members['ontology/finite-id-review.json'])
    conclusions=collections.Counter(a['conclusion'] for a in finite['entries'])
    check('finite-nine-not-nine-consistent',len(finite['entries'])==9 and
          conclusions=={'consistent':8,'evidence-gap':1} and
          [a['id'] for a in finite['entries'] if a['conclusion']=='evidence-gap']==['question.multi-tenant-workflow-isolation'],dict(conclusions))

    guard=json.loads(members['ontology/guard-byte-equivalence.json'])
    guardrows=[]
    now=(REPO/HELPER).read_text()
    before=blob(HELPER).decode()
    for a in guard['checks']:
        if a['check']=='whole-file-equality': x,y=blob(a['path']),(REPO/a['path']).read_bytes()
        elif a['check']=='search-overloads-and-qualification-predicates':
            f=lambda s:s[s.index('    public List<Map<String, String>> search('):s.index('        return users.find')]
            x,y=f(before).encode(),f(now).encode()
        else:
            f=lambda s:s[s.index('                .filter(user -> available'):]
            x,y=f(before).encode(),f(now).encode()
        guardrows.append({**a,'independentEqual':x==y,'independentOldSha256':sha(x),'independentNewSha256':sha(y)})
    check('eleven-qualification-consumer-write-protections',len(guardrows)==11 and
          all(a['independentEqual'] and a['independentOldSha256']==a['sourceSha256'] and
              a['independentNewSha256']==a['workingTreeSha256'] for a in guardrows),'guard-verification.json')
    write('guard-verification.json',guardrows)
    write('ontology-verification.json',{'manifestSha256':digest,'artifacts':nested,'inputs':inputs,
                                      'finiteConclusions':dict(conclusions),'finiteEntries':finite['entries']})

    runs={}
    for mode in ('red','green'):
        run=json.loads(members[f'primary/{mode}/run.json'])
        ss=[]
        for a in run['sourceFingerprints']:
            b=members[f'primary/{mode}/source-snapshot/'+a['path']]
            expected=blob(a['path']) if mode=='red' and a['path']==HELPER else (REPO/a['path']).read_bytes()
            ss.append({**a,'matchesRecorded':len(b)==a['bytes'] and sha(b)==a['sha256'],
                       'matchesReviewedVersion':b==expected})
        xmls=[(n,ET.fromstring(b)) for n,b in members.items() if n.startswith(f'primary/{mode}/TEST-') and n.endswith('.xml')]
        totals={k:sum(int(x.attrib.get(k,0)) for _,x in xmls) for k in ('tests','failures','errors','skipped')}
        cases=[]
        for n,root in xmls:
            for tc in root.findall('testcase'):
                failures=[{'type':f.attrib.get('type'),'message':f.attrib.get('message'),'stack':f.text} for f in tc.findall('failure')]
                cases.append({'member':n,'name':tc.attrib['name'],'failures':failures,
                              'errors':len(tc.findall('error')),'skips':len(tc.findall('skipped'))})
        events=[json.loads(l) for l in members[f'primary/{mode}/observations.jsonl'].splitlines()]
        for e in events:
            sql=e['jdbcSql']+e['hibernateSql']
            e['independentCountStatements']=sum(bool(re.search(r'\bcount\s*\(',q,re.I)) for q in sql)
            e['independentSqlCount']=len(sql)
        runs[mode]={'run':run,'sourceFingerprints':ss,'totals':totals,'cases':cases,'events':events,
                    'cleanup':json.loads(members[f'primary/{mode}/cleanup.json'])}
        check(mode+'-source-byte-provenance',all(x['matchesRecorded'] and x['matchesReviewedVersion'] for x in ss),ss)
    old,new=runs['red'],runs['green']
    check('raw-green-152-xml',new['totals']=={'tests':152,'failures':0,'errors':0,'skipped':0} and
          new['run']['exitCode']==0,new['totals'])
    redfail=[f for tc in old['cases'] for f in tc['failures']]
    check('raw-red-seven-real-budget-failures',old['totals']=={'tests':7,'failures':4,'errors':0,'skipped':0} and
          len(redfail)==4 and all(f['type']=='java.lang.AssertionError' and
          re.search(r'Expecting actual:\s+2\s+to be less than or equal to:\s+1',f['message']) for f in redfail),old['totals'])
    ev=new['events']; dirs=[e for e in ev if e['kind'].startswith('personnel-directory')]
    check('14-events-47-observed-selects-directory-seven',len(ev)==14 and len(dirs)==7 and
          sum(e['totalStatements'] for e in ev)==47 and all(e['totalStatements']==e['independentSqlCount'] for e in ev) and
          all(e['totalStatements']==1 and e['independentCountStatements']==0 and
              any('fetch first' in q.lower() or 'limit' in q.lower() for q in e['hibernateSql']) for e in dirs),
          {'events':len(ev),'directoryEvents':len(dirs),'observedSql':sum(e['totalStatements'] for e in ev)})
    perf=json.loads((REPO/PKG/'performance-report.json').read_bytes())
    actual=[{'kind':e['kind'],'data':e['data'],'totalStatements':e['totalStatements'],
             'countStatements':e['independentCountStatements']} for e in ev]
    check('performance-summary-matches-events',actual==perf['observations'] and perf['currentTotalObservedSelects']==47,
          'raw-test-and-event-verification.json')
    write('raw-test-and-event-verification.json',runs)
    (OUT/'archived-api-bytecode.txt').write_bytes(members['tools/edhr-personnel-count-fluent-api-20261105.txt'])

source=json.loads((REPO/PKG/'source-review.json').read_bytes())
rows=[]
for a in source['sourceFingerprints']:
    b=(REPO/a['path']).read_bytes()
    rows.append({**a,'equal':len(b)==a['bytes'] and sha(b)==a['sha256']})
check('source-nine-fingerprints',len(rows)==9 and all(x['equal'] for x in rows),rows)
write('source-fingerprint-verification.json',rows)

knowledge=[]
for p in git('ls-tree','-r','--name-only',BASE,'docs/knowledge').decode().splitlines():
    a,b=blob(p),(REPO/p).read_bytes()
    knowledge.append({'path':p,'bytes':len(b),'sha256':sha(b),'equal':a==b})
check('knowledge-345-unchanged',len(knowledge)==345 and all(x['equal'] for x in knowledge),'knowledge-byte-verification.json')
write('knowledge-byte-verification.json',knowledge)

oldtest=blob(TEST).decode().splitlines(keepends=True)
newtest=(REPO/TEST).read_text().splitlines(keepends=True)
ops=difflib.SequenceMatcher(None,oldtest,newtest,autojunk=False).get_opcodes()
check('functional-test-source-only-additions',all(tag in ('equal','insert') for tag,*_ in ops),
      [{'kind':t,'oldStart':i,'oldEnd':j,'newStart':a,'newEnd':b} for t,i,j,a,b in ops])

prior='90cca1c08155a01cb0a51efe6d7fc31f19eda777'
baseline=json.loads((REPO/PKG/'baseline-review.json').read_bytes())
paths=git('ls-tree','-r','--name-only','-z',BASE)
check('baseline-delta-and-unfinished-queues',git('rev-parse',BASE+'^{tree}')==git('rev-parse',prior+'^{tree}') and
      len(paths.rstrip(b'\0').split(b'\0'))==7468 and sha(paths)==baseline['rawNulPathListSha256'] and
      baseline['wholeFileComplete']==0 and baseline['historicalUniqueCoverage'] is None and
      baseline['pendingKnowledgeCandidates']==931 and baseline['priorUiDiagnosticCandidates']==86,baseline)

jar='/workspace/.pr6-m2/org/springframework/data/spring-data-jpa/3.3.0/spring-data-jpa-3.3.0.jar'
bytecode=command('/workspace/.edhr-cloud-tools/jdk-21.0.12.1+1/bin/javap','-p','-c','-classpath',jar,
                 'org.springframework.data.jpa.repository.support.FetchableFluentQueryBySpecification').decode()
(OUT/'independent-api-bytecode.txt').write_text(bytecode)
def method(part):
    m=re.search(r'^  '+re.escape(part)+r'.*?(?=\n  (?:public|private|protected) |\Z)',bytecode,re.S|re.M)
    return m.group(0) if m else ''
limit=method('public org.springframework.data.repository.query.FluentQuery$FetchableFluentQuery<R> limit(int);')
allmethod=method('public java.util.List<R> all();')
query=method('private jakarta.persistence.TypedQuery<S> createSortedAndProjectedQuery();')
check('installed-spring-data-33-database-limit-without-count',
      bool(limit) and bool(allmethod) and bool(query) and 'getResultList' in allmethod and
      'count' not in allmethod.lower() and 'setMaxResults' in query and 'Field limit:I' in query,
      {'jar':jar,'sha256':sha(Path(jar).read_bytes()),'limit':limit,'all':allmethod,'query':query})

inputs=set(['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md',
            'docs/knowledge/README.md','docs/knowledge/open-questions.yaml'])
inputs.update(a['path'] for a in fps['files'])
inputs.update(a['path'] for a in source['sourceFingerprints'])
inputs.update(str(p.relative_to(REPO)) for p in (REPO/PKG).iterdir() if p.is_file())
readrows=[]
for p in sorted(inputs):
    b=(REPO/p).read_bytes()
    dest=OUT/'read-inputs'/p
    dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
    readrows.append({'path':p,'bytes':len(b),'sha256':sha(b),'snapshot':str(dest.relative_to(OUT))})
write('read-inputs.json',readrows)
write('command-log.json',COMMANDS)
write('checks.json',{'status':'COMPLETE','scope':'read-only evidence and source review; no tests executed by this role',
                     'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':CHECKS,
                     'nativeTestsExecuted':False,'browserExecuted':False,'formalKnowledgeTestsExecuted':False})
print(json.dumps({'checks':len(CHECKS),'passed':sum(x['outcome']=='passed' for x in CHECKS),
                  'failed':[x for x in CHECKS if x['outcome']!='passed']},ensure_ascii=False,indent=2))
