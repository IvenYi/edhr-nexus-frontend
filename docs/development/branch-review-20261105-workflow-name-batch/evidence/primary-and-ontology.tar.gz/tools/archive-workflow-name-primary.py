import pathlib,json,hashlib,subprocess,tarfile,shutil,yaml
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=r/'docs/development/branch-review-20261105-workflow-name-batch';o.joinpath('evidence').mkdir(exist_ok=True);onto=pathlib.Path('/tmp/edhr-workflow-name-ontology-20261105');base='5e2d1c084eea20a8d1be6f86bda4121b612cacce'
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((onto/'manifest.json').read_bytes())=='0470d09b327b9cc5244ea7f42e5903a3f2418b62bdbac5e48f42d04c63a045df'
m=json.loads((onto/'manifest.json').read_text());assert m['artifactCount']==len(m['artifacts'])==40
for f in m['artifacts']:
 b=(onto/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert yaml.safe_load((onto/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
files=[]
expected={'red':{'tests':7,'failures':3,'errors':2,'skipped':0},'red_final':{'tests':7,'failures':5,'errors':0,'skipped':0},'green':{'tests':151,'failures':0,'errors':1,'skipped':0},'green_final':{'tests':151,'failures':0,'errors':0,'skipped':0}}
for mode,totals in expected.items():
 d=pathlib.Path('/tmp/edhr-workflow-name-main-'+mode+'-20261105');assert json.loads((d/'test-summary.json').read_text())['totals']==totals
 assert json.loads((d/'cleanup.json').read_text())['removed']
 for f in json.loads((d/'run.json').read_text())['sourceFingerprints']:
  b=(d/'source-snapshot'/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
  if mode.startswith('red') and '/src/main/' in f['path']:assert b==subprocess.check_output(['git','show',base+':'+f['path']],cwd=r)
  if mode=='green_final' or mode=='red_final' and '/src/test/' in f['path']:assert b==(r/f['path']).read_bytes()
 for p in sorted(d.rglob('*')):
  if p.is_file():files.append(('primary/'+mode+'/'+str(p.relative_to(d)),p))
for p in sorted(onto.rglob('*')):
 if p.is_file():files.append(('ontology/'+str(p.relative_to(onto)),p))
for n in ['run-workflow-name-batch.py','archive-workflow-name-primary.py','edhr-workflow-name-red-runner-20261105.log','edhr-workflow-name-red-final-runner-20261105.log','edhr-workflow-name-green-runner-20261105.log','edhr-workflow-name-green-final-runner-20261105.log','edhr-workflow-name-spring-api-20261105.txt']:
 files.append(('tools/'+n,pathlib.Path('/tmp')/n))
raw=[{'member':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files];a=o/'evidence/primary-and-ontology.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,p in files:t.add(p,arcname=n,recursive=False)
(o/'evidence-manifest.json').write_text(json.dumps({'sourceHeadDuringRuns':base,'rawArtifacts':raw,'archive':{'path':str(a.relative_to(o)),'bytes':a.stat().st_size,'sha256':sha(a.read_bytes())},'note':'Each stage retains original source/XML/logs. Initial fixture2E and initial implementation1E are not hidden or cumulative coverage. Final same-test old7=5F2positive, green1510F/E/S. Raw member sizes distinct from compressed storage.'},ensure_ascii=False,indent=2)+'\n');shutil.copy2(onto/'ontology-result.yaml',o/'ontology-result.yaml')
print(json.dumps({'rawArtifacts':len(raw),'archiveBytes':a.stat().st_size,'sha256':sha(a.read_bytes())},ensure_ascii=False))
