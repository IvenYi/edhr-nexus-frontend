import pathlib,subprocess,json,hashlib,datetime,yaml,sys
root=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-workflow-name-ontology-20261105');out.mkdir(exist_ok=True)
source='5e2d1c084eea20a8d1be6f86bda4121b612cacce';target='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
commands=[]
def cmd(args):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True)
 commands.append({'argv':args,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 if p.returncode:raise RuntimeError(args)
 return p.stdout
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,x): (out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
paths=[
 'AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
 'docs/development/branch-review-20261105-workflow-name-batch/decision-package.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml',
 'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
 'docs/knowledge/evidence/button-signature-confirmed.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md',
 'docs/development/workflow-operations-20261030/user-confirmed.md','docs/knowledge/evidence/workflow-operations-20261030.md',
 'docs/development/workflow-central-entry-extension-20261102/user-confirmed.md','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/Signature.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/entity/WorkflowTask.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/WorkflowOperationsController.java']
baseline={'sourceHead':cmd(['git','rev-parse','HEAD']).strip(),'targetRef':cmd(['git','rev-parse','origin/edhr-dev']).strip(),'contractReadCommit':source,
 'statusAtRead':cmd(['git','status','--porcelain=v1']),'contractDelta':cmd(['git','diff','--name-only',target,source,'--','AGENTS.md','docs/agents']),
 'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0/in-progress','roleChangedRepositoryPaths':[]}
dump('baseline.json',baseline)
assert baseline['contractDelta']==''
assert baseline['targetRef']==target
inputs=[]
for path in paths:
 if path.startswith('docs/development/branch-review-20261105'):
  b=(root/path).read_bytes();basis='uncommitted-working-tree-input'
 else:
  b=subprocess.check_output(['git','show',source+':'+path],cwd=root);basis='fixed-source-Git-blob'
 p=out/'read-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 inputs.append({'path':path,'basis':basis,'bytes':len(b),'sha256':sha(b)})
dump('input-fingerprints.json',inputs)
knowledge=[]
for path in cmd(['git','ls-tree','-r','--name-only',source,'docs/knowledge']).splitlines():
 before=subprocess.check_output(['git','show',source+':'+path],cwd=root);current=(root/path).read_bytes()
 knowledge.append({'path':path,'bytes':len(current),'sha256':sha(current),'unchangedFromSource':before==current})
assert len(knowledge)==345 and all(f['unchangedFromSource'] for f in knowledge)
dump('knowledge-byte-check.json',{'sourceCommit':source,'targetCommit':target,'files':knowledge,'unchanged':345,'isSemanticAuditOfAll345':False})
specs=[
 ('DEC-0074-01',8,[12], '实际签署人身份及独立签名凭证与会话身份分开；当前目录姓名不能改写signature.signerName/snapshotData。'),
 ('DEC-0081-01',9,[13], '通用任务/普通表单本人转办的同租户正常可用目标范围保持；批量姓名不新增目标权限政策。'),
 ('DEC-0081-02',9,[13], '原候选来源与当前责任分开；只读姓名不会重算候选或赋予旧候选当前处理权。'),
 ('DEC-0092-01',10,[14], '集中日志/干预继续原实例身份和读路径；姓名复用不创建运行任务或修改历史身份。'),
 ('DEC-0092-02',10,[14,15], '记录控制转办仍限自身授权候选且申请人回避；不能从通用委托外推资格。'),
 ('DEC-0093-01',11,[16,17], '集中日志/干预按领域授权读取；菜单及姓名映射不授予审批、填报或内容修改权。'),
 ('DEC-0093-03',11,[16,17], '责任历史、领域审计及签名关联保留实际会话/签署身份；当前姓名投影不替代历史签署证据。'),
 ('DEC-0093-04',11,[17], '具体查询/权限码/投影实现是工程选择；批量SQL和有限测试不构成新业务政策或全系统验收。')]
review=[]
for ident,index,refs,meaning in specs:
 path=paths[index];data=yaml.safe_load((out/'read-snapshot'/path).read_text());records=data['decisions'][0]['decisionStatements'];record=next(x for x in records if x['id']==ident)
 lines=(out/'read-snapshot'/path).read_text().splitlines();line=next(i+1 for i,x in enumerate(lines) if 'id: '+ident==x.strip().lstrip('- ').strip()) if False else next(i+1 for i,x in enumerate(lines) if x.strip()=='- id: '+ident)
 review.append({'id':ident,'recordType':'decisionStatement','sourcePath':path,'sourceLocator':{'line':line,'recordId':ident},'assetMaturity':{'status':record['status'],'visibility':record['visibility']},'auditScope':'finite-current-name-and-read-ownership-boundary','semanticReviewStatus':'reviewed','conclusion':'consistent','disposition':'retained','definition':record['statement'],'checkedMeaning':meaning,'originalEvidenceReferences':[paths[i] for i in refs], 'implementationReferences':paths[18:25],'notFullFileOrUniqueHistoricalCoverage':True})
dump('finite-id-review.json',{'baseline':source,'finiteExistingStatements':8,'records':review,'historicalUniqueCoverageUnknown':True,'pendingKnowledgeCandidatesRetained':931})
dump('commands.json',commands)
print(json.dumps({'readInputs':len(inputs),'knowledgeUnchanged':len(knowledge),'finiteIds':len(review),'output':str(out)},ensure_ascii=False))
