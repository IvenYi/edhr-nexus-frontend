import pathlib,subprocess,json,hashlib,yaml,shutil
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-name-ontology-20261105')
source='5e2d1c084eea20a8d1be6f86bda4121b612cacce';target='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(n,x):(out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
assert git('rev-parse','origin/edhr-dev').decode().strip()==target
inputs=json.loads((out/'input-fingerprints.json').read_text());paths=[x['path'] for x in inputs]
test='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java';paths.append(test)
fingerprints=[]
for path in paths:
 b=(root/path).read_bytes();old=out/'read-snapshot'/path
 if old.exists() and old.read_bytes()==b:artifact='read-snapshot/'+path
 else:
  p=out/'final-source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);artifact=str(p.relative_to(out))
 fingerprints.append({'path':path,'bytes':len(b),'sha256':sha(b),'artifact':artifact,'sourceHead':git('rev-parse','HEAD').decode().strip(),'workingTreeFingerprint':True})
dump('source-fingerprints.json',fingerprints)
q='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java';old=git('show',source+':'+q).decode();new=(root/q).read_text()
def between(text,a,b):start=text.index(a);return text[start:text.index(b,start)]
checks=[]
def proof(name,a,b):
 assert a==b,name
 checks.append({'name':name,'beforeBytes':len(a.encode()),'afterBytes':len(b.encode()),'sha256':sha(a.encode()),'unchanged':True})
proof('list-method',between(old,'    public PageResult','    public Map<String, Object> detail'),between(new,'    public PageResult','    public Map<String, Object> detail'))
proof('instance-visibility-and-nodes-edges-prefix',between(old,'    public Map<String, Object> detail','        result.put("tasks"'),between(new,'    public Map<String, Object> detail','        var instanceTasks'))
proof('task-fields-state-signature-opinion-action',between(old,'            Map<String, Object> view','            var names ='),between(new,'            Map<String, Object> view','            view.put("assigneeName"'))
proof('logs-query-and-current-name-priority',between(old,'        result.put("logs"','        return result;'),between(new,'        result.put("logs"','        return result;'))
proof('visibility-has-and-error-tail',old[old.index('    private String visibility'):],new[new.index('    private String visibility'):])
proof('class-readonly-transaction-and-constants',between(old,'/** Shared read projection','    public PageResult'),between(new,'/** Shared read projection','    public PageResult'))
for path in [p for p in paths if '/src/main/' in p and p!=q]:
 before=git('show',source+':'+path);current=(root/path).read_bytes();assert before==current,path
 checks.append({'name':path,'bytes':len(current),'sha256':sha(current),'unchanged':True})
dump('guard-byte-equivalence.json',{'sourceCommit':source,'checks':checks,'count':len(checks),'runtimeVerificationClaim':False})
(out/'product.diff').write_bytes(git('diff',source,'--','gmp-platform/backend/src/main'))
knowledge=json.loads((out/'knowledge-byte-check.json').read_text())
for f in knowledge['files']:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
records=json.loads((out/'finite-id-review.json').read_text())['records']
result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':source,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':source,'uncommittedContractPaths':[]},
 'reason':'用户仅授权姓名查询性能优化；稳定源码在原可见实例检查后按原文本ID一次读取当前目录名，NULL/缺失fallback、任务投影和历史签署/日志证据保持。无新业务概念、政策、生命周期或定义替代，知识无需修改。',
 'changedArtifacts':[],
 'knowledgeSync':[{'id':a['id'],'disposition':'retained','scope':a['checkedMeaning'],'sourceReferences':[a['sourcePath'],*a['originalEvidenceReferences']]} for a in records],
 'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.current-contract-and-inputs','checkType':'reference','command':'Read source5e2 project/handoff/role contracts, fixed knowledge/original evidence and current decisionPackage; compare target contract delta','outcome':'passed','evidence':['baseline.json','commands.json','input-fingerprints.json','read-snapshot/']},
  {'id':'validation.finite-eight-current-policy-statements','checkType':'evidence-path','command':'Compare eight current statements and original user confirmations against current-name versus historical-signature ownership boundary','outcome':'passed','evidence':['finite-id-review.json','semantic-review.md']},
  {'id':'validation.knowledge-345-unchanged','checkType':'reference','command':'Byte-compare345 tracked knowledge files against source5e2 and recheck final fingerprints','outcome':'passed','evidence':['knowledge-byte-check.json']},
  {'id':'validation.stable-query-and-adjacent-guards','checkType':'projection','command':'Read stable diff, compare unchanged list/authorization/task-fields/log/tail/transaction ranges and adjacent product files, fingerprint26 current inputs','outcome':'passed','evidence':['source-fingerprints.json','guard-byte-equivalence.json','product.diff','final-source-snapshot/']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
},'verificationScope':{
 'status':'FINAL','finiteExistingStatementsReviewed':8,'historicalUniqueCoverageClaim':False,'knowledgeFilesUnchanged':345,'currentSourceFingerprints':len(fingerprints),'guardByteComparisonGroups':len(checks),
 'formalKnowledgeTestsExecuted':0,'nativeTestsExecuted':0,'browserExecuted':False,'roleChangedRepositoryPaths':[],'childRoles':[],
 'sourceWorkingTree':{'head':source,'productIncludedUncommitted':[q],'testIncludedAsReadOnlyAnchor':test,'noFabricatedCandidateCommit':True},
 'readScope':'Mandatory governance/model/open-question inputs loaded in full into provenance snapshots; relevant ownership/status/stage and eight declarations/original confirmations semantically reviewed. Snapshot/hash presence is not whole-file or full-knowledge semantic completion.',
 'implementationChoiceBoundary':'One request-local varchar-array query, exact text identity, no cross-request cache; query timing is consolidated once rather than per task, still current directory data. This is engineering implementation of approved optimization, not new signing or historical-name policy.',
 'fullKnowledgeSemanticAuditComplete':False,'pendingKnowledgeCandidates':931,'priorUiDiagnosticCandidates':86,
 'residuals':['Main/fresh quality own final151/89/old-source/SQL/server verification; this role does not certify actual run results','Directory unused COUNT intentionally not optimized by user selection','Huge candidate/text-ID plans, production latency/network/concurrent rename and full account/recipient/ACL/signature/UI matrices not certified','All prior W2-W7/high/A12/full-audit gaps and user-paused scopes remain']}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=110))
(out/'FINAL.md').write_text('# FINAL\n\nontologyResult.result: not-applicable. Eight existing statements finite-reviewed;345 knowledge files unchanged;26 current inputs and protected source groups pinned. No business/knowledge/architecture modification and no tests/browser executed. Runtime verification belongs to main/fresh quality;931 knowledge/86 UI and previous audit gaps stay pending.\n')
for name in ['build-workflow-name-ontology-20261105.py','finalize-workflow-name-ontology-20261105.py']:
 shutil.copy2(pathlib.Path('/tmp')/name,out/name)
artifacts=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name not in ('manifest.json','manifest.sha256'):
  b=p.read_bytes();artifacts.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
manifest={'status':'FINAL','ontologyResult':'not-applicable','artifactCount':len(artifacts),'artifacts':artifacts,'note':'Original read/proof/script bytes retained; no native/knowledge/browser tests executed by this role. Final worktree product fingerprints are not fabricated commit hashes.'}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');digest=sha((out/'manifest.json').read_bytes());(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'status':'FINAL','result':'not-applicable','artifacts':len(artifacts),'manifestSha256':digest,'sourceFingerprints':len(fingerprints),'guardChecks':len(checks)},ensure_ascii=False))
