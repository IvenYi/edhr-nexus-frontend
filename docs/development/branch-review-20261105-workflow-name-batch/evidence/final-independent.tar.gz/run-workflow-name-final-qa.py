import pathlib,subprocess,os,time,datetime,json,hashlib,shutil,xml.etree.ElementTree as ET,sys
repo=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105');out.mkdir(exist_ok=True)
wt=pathlib.Path('/tmp/edhr-workflow-name-qa-wt-20261105');candidate='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9';base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
name='edhr-workflow-name-finalqa-20261105';record='edhr_record_control_test_name_finalqa';observation='edhr_workflow_read_test_name_finalqa';created=False;worktree=False;commands=[];exitcode=1
selected=['WorkflowReadObservationPostgresTest','RecordControlPostgresIntegrationTest','WorkflowTransferPostgresTest','ProductionExecutionEngineTest','ExecutionAccessTest','DhrReviewServiceTest','DhrReviewLifecycleIntegrationTest','RecordControlCandidateAuthorizationTest','RecordControlWorkflowControllerTest','WorkflowTaskControllerTest']
def call(args,cwd=repo,check=True):
 p=subprocess.run(args,cwd=cwd,text=True,capture_output=True);commands.append({'command':args,'cwd':str(cwd),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});(out/'orchestration-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if check and p.returncode:raise RuntimeError(str(args)+' '+p.stderr[-1000:])
 return p.stdout.strip()
def snapshot(paths):
 result=[]
 for p in paths:
  b=(wt/p).read_bytes();d=out/'source-snapshot'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);result.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 (out/'source-fingerprints.json').write_text(json.dumps(result,indent=2)+'\n')
def tests(folder,names,started):
 reports=folder/'surefire';reports.mkdir(parents=True,exist_ok=True);totals={k:0 for k in ['tests','failures','errors','skipped']};classes=[]
 for n in names:
  found=[p for p in (wt/('gmp-platform/backend/target/surefire-reports' if folder.name=='native' else 'tools/knowledge-model/target/surefire-reports')).glob('TEST-*'+n+'.xml') if p.stat().st_mtime>=started]
  assert len(found)==1,(n,found)
  p=found[0];shutil.copy2(p,reports/p.name);doc=ET.parse(p).getroot();row={'class':doc.attrib['name'],**{k:int(doc.attrib.get(k,0)) for k in totals}};classes.append(row)
  for k in totals:totals[k]+=row[k]
 data={'totals':totals,'classes':classes};(folder/'test-summary.json').write_text(json.dumps(data,indent=2)+'\n');return data
try:
 call(['git','fetch','origin','edhr-dev']);starthead=call(['git','rev-parse','HEAD']);target=call(['git','rev-parse','origin/edhr-dev']);status=call(['git','status','--porcelain=v1']);assert starthead==candidate and target==base and not status;call(['git','merge-base','--is-ancestor',base,candidate])
 (out/'baseline-start.json').write_text(json.dumps({'head':starthead,'target':target,'status':status,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
 call(['git','worktree','add','--detach',str(wt),candidate]);worktree=True
 link=wt/'gmp-platform/frontend/node_modules';link.symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True)
 paths=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'];snapshot(paths)
 cid=call(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+record,'-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(100):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.3)
 else:raise RuntimeError('own PostgreSQL not ready')
 call(['docker','exec',name,'psql','-U','postgres','-d',record,'-c','CREATE ROLE edhr LOGIN']);call(['docker','exec',name,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test']);call(['docker','exec',name,'createdb','-U','postgres',observation])
 port=call(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env=os.environ.copy();env.update(PGUSER='postgres',RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{record}',WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{observation}',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test')
 (out/'native').mkdir(exist_ok=True);cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'native/observations.jsonl'),'-Dtest='+','.join(selected),'test'];start=datetime.datetime.now(datetime.timezone.utc)
 with (out/'native/maven.log').open('w') as log:p=subprocess.run(cmd,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 native=tests(out/'native',selected,start.timestamp());(out/'native/command.json').write_text(json.dumps({'command':cmd,'exitCode':p.returncode,'cwd':str(wt),'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');assert p.returncode==0 and native['totals']=={'tests':151,'failures':0,'errors':0,'skipped':0}
 migrations={}
 for d in [record,observation]:migrations[d]=call(['docker','exec',name,'psql','-U','postgres','-d',d,'-Atc','SELECT id||\'|\'||exectype FROM databasechangelog ORDER BY orderexecuted'])
 (out/'native/liquibase-applied.json').write_text(json.dumps(migrations,indent=2)+'\n')
 (out/'knowledge').mkdir(exist_ok=True);cmd2=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test'];ks=datetime.datetime.now(datetime.timezone.utc)
 with (out/'knowledge/maven.log').open('w') as log:k=subprocess.run(cmd2,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 names=[p.stem.split('.')[-1] for p in (wt/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml') if p.stat().st_mtime>=ks.timestamp()];knowledge=tests(out/'knowledge',names,ks.timestamp());(out/'knowledge/command.json').write_text(json.dumps({'command':cmd2,'exitCode':k.returncode,'started':ks.isoformat()},indent=2)+'\n');assert k.returncode==0 and knowledge['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
 tooling=call(['git','status','--porcelain=v1'],cwd=wt);assert tooling in ('?? gmp-platform/frontend/node_modules',''),tooling
 (out/'run-result.json').write_text(json.dumps({'candidate':candidate,'base':base,'native':native['totals'],'knowledge':knowledge['totals'],'postgres':call(['docker','exec',name,'psql','-U','postgres','-d',record,'-Atc','SELECT version()']),'databases':{k:v for k,v in env.items() if k in ['RECORD_CONTROL_TEST_DATABASE_URL','WORKFLOW_READ_TEST_DATABASE_URL','W3_TRANSFER_DATABASE_URL']},'allowedToolingStatus':tooling},indent=2)+'\n');exitcode=0
finally:
 cleanup={}
 if created:
  p=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'native-postgres.log').write_text(p.stdout+p.stderr)
  cleanup['stop']=call(['docker','stop',name],check=False)
  for _ in range(50):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode:break
   time.sleep(.1)
  cleanup['containerRemoved']=subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
 if worktree:
  link=wt/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink()
  cleanup['worktreeStatusBeforeRemoval']=call(['git','status','--porcelain=v1'],cwd=wt);call(['git','worktree','remove',str(wt)]);cleanup['worktreeRemoved']=not wt.exists()
 cleanup['mainStatus']=call(['git','status','--porcelain=v1']);cleanup['exitCode']=exitcode;(out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
sys.exit(exitcode)
