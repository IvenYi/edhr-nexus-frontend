import pathlib,subprocess,json,hashlib,shutil
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105');old='5e2d1c084eea20a8d1be6f86bda4121b612cacce';candidate='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9';base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
def sha(x):return hashlib.sha256(x).hexdigest()
path='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java';a=git('show',old+':'+path).decode();b=git('show',candidate+':'+path).decode()
def cut(s,start,end):return s[s.index(start):s.index(end,s.index(start))]
sections=[]
for name,sa,sb in [
 ('list',cut(a,'    public PageResult','    public Map<String, Object> detail'),cut(b,'    public PageResult','    public Map<String, Object> detail')),
 ('visibility-and-tail',a[a.index('    private String visibility'):],b[b.index('    private String visibility'):]),
 ('detail-guard-nodes-edges',cut(a,'    public Map<String, Object> detail','        result.put("tasks"'),cut(b,'    public Map<String, Object> detail','        var instanceTasks')),
 ('task-fields-before-name',cut(a,'            Map<String, Object> view','            var names ='),cut(b,'            Map<String, Object> view','            view.put("assigneeName"')),
 ('logs',cut(a,'        result.put("logs"','        return result;'),cut(b,'        result.put("logs"','        return result;')),
 ('annotations-and-query-constants',cut(a,'/** Shared read projection','    public PageResult'),cut(b,'/** Shared read projection','    public PageResult'))]:
 assert sa==sb,name;sections.append({'name':name,'bytes':len(sa.encode()),'sha256':sha(sa.encode()),'equal':True})
for p in ['gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/entity/WorkflowTask.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/WorkflowOperationsController.java']:
 before=git('show',old+':'+p);after=git('show',candidate+':'+p);assert before==after;sections.append({'path':p,'bytes':len(after),'sha256':sha(after),'equal':True})
changed=[p for p in git('diff','--name-only','-z',old,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend/src').decode().split('\0') if p];assert changed==[path],changed
(o/'independent-source-equivalence.json').write_text(json.dumps({'sourcePreChange':old,'candidate':candidate,'target':base,'equalGroups':sections,'changedProductPaths':changed},indent=2)+'\n')
knowledge=[]
paths=[p for p in git('ls-tree','-r','--name-only','-z',candidate,'docs/knowledge').decode().split('\0') if p]
for p in paths:
 content=git('show',candidate+':'+p);assert content==git('show',old+':'+p)==git('show',base+':'+p)==(r/p).read_bytes();knowledge.append({'path':p,'bytes':len(content),'sha256':sha(content)})
assert len(knowledge)==345;(o/'knowledge-byte-check.json').write_text(json.dumps({'count':len(knowledge),'allUnchanged':True,'sourcePreChange':old,'target':base,'candidate':candidate,'files':knowledge},indent=2)+'\n')
policy=['docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/evidence/button-signature-confirmed.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/development/workflow-operations-20261030/user-confirmed.md','docs/development/workflow-central-entry-extension-20261102/user-confirmed.md']
for p in policy:
 dest=o/'policy-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(git('show',candidate+':'+p))
for cls in ['org.springframework.jdbc.support.SqlArrayValue','org.springframework.jdbc.core.ArgumentPreparedStatementSetter']:
 result=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/javap','-c','-classpath','/workspace/.pr6-m2/org/springframework/spring-jdbc/6.1.8/spring-jdbc-6.1.8.jar',cls],capture_output=True,text=True);assert result.returncode==0;(o/(cls.rsplit('.',1)[1]+'.javap.txt')).write_text(result.stdout)
assert 'java/sql/Array.free' in (o/'SqlArrayValue.javap.txt').read_text();assert 'cleanupParameters' in (o/'ArgumentPreparedStatementSetter.javap.txt').read_text()
print(json.dumps({'knowledge':len(knowledge),'equalGroups':len(sections),'policySources':len(policy),'productFilesChanged':len(changed)}))
