import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,xml.etree.ElementTree as ET,sys
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105/server-sql');out.mkdir(parents=True,exist_ok=True)
wt=pathlib.Path('/tmp/edhr-name-server-sql-wt-20261105');name='edhr-name-server-sql-qa-20261105';db='edhr_workflow_read_test_nameserverqa';head='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9';base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620';commands=[];created=False;added=False;code=99
def run(args,cwd=None,check=True):
 p=subprocess.run(args,cwd=cwd,capture_output=True,text=True);commands.append({'args':args,'cwd':str(cwd) if cwd else None,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});
 if check and p.returncode:raise RuntimeError(str(args)+': '+p.stderr)
 return p.stdout.strip()
try:
 baseline={'head':run(['git','rev-parse','HEAD'],root),'target':run(['git','rev-parse','origin/edhr-dev'],root),'status':run(['git','status','--porcelain=v1'],root)};assert baseline=={'head':head,'target':base,'status':''};(out/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
 run(['git','worktree','add','--detach',str(wt),head],root);added=True
 (wt/'gmp-platform/frontend/node_modules').symlink_to(root/'gmp-platform/frontend/node_modules',target_is_directory=True)
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_statement=all','-c','logging_collector=off','-c','log_line_prefix=%m [%p] ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('Own PG did not become ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);url=f'jdbc:postgresql://127.0.0.1:{port}/{db}'
 sources=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/development/branch-review-20261105-workflow-name-batch/decision-package.yaml','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java']
 fps=[]
 for p in sources:
  b=(wt/p).read_bytes();dest=out/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);fps.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 (out/'source-fingerprints.json').write_text(json.dumps(fps,indent=2)+'\n')
 env=os.environ.copy();env.update(WORKFLOW_READ_TEST_DATABASE_URL=url,PGUSER='postgres');command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'observations.jsonl'),'-Dtest=WorkflowReadObservationPostgresTest','test'];started=datetime.datetime.now(datetime.timezone.utc)
 with (out/'maven.log').open('w') as log:p=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 meta={'head':head,'base':base,'command':command,'cwd':str(wt),'started':started.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'url':url,'containerId':cid,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])};(out/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
 xmls=[x for x in (wt/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml') if x.stat().st_mtime>=started.timestamp()];assert len(xmls)==1
 for x in xmls:shutil.copy2(x,out/x.name)
 doc=ET.parse(xmls[0]).getroot();counts={k:int(doc.attrib[k]) for k in ('tests','failures','errors','skipped')};(out/'test-summary.json').write_text(json.dumps(counts,indent=2)+'\n')
 assert p.returncode==0 and counts=={'tests':13,'failures':0,'errors':0,'skipped':0}
 status=run(['git','status','--porcelain=v1'],wt)
 assert status in ('', '?? gmp-platform/frontend/node_modules')
 code=0
finally:
 cleanup={}
 if created:
  p=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(p.stdout+p.stderr);cleanup['containerStop']=run(['docker','stop',name],check=False)
  for _ in range(50):
   gone=subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0
   if gone:break
   time.sleep(.1)
  cleanup['containerRemoved']=gone
 if added:
  link=wt/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink()
  cleanup['worktreeRemove']=run(['git','worktree','remove',str(wt)],root,check=False);cleanup['worktreeRemoved']=not wt.exists()
 cleanup['mainStatus']=run(['git','status','--porcelain=v1'],root,check=False);(out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
sys.exit(code)
