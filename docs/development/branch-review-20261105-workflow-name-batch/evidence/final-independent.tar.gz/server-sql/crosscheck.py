import pathlib,json,re,collections,subprocess,hashlib
o=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105/server-sql');r=pathlib.Path('/workspace/edhr-nexus-frontend');head='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9'
def norm(sql):return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql)).strip().rstrip(';')
events=list(map(json.loads,(o/'observations.jsonl').read_text().splitlines()));assert len(events)==13
expected=collections.Counter()
for e in events:
 assert e['totalStatements']==len(e['jdbcSql'])+len(e['hibernateSql'])
 expected.update(norm(s) for s in e['jdbcSql']+e['hibernateSql'])
messages=[];current=None
for no,line in enumerate((o/'postgres.log').read_text().splitlines(),1):
 m=re.match(r'^(\d{4}-\d\d-\d\d .*?) \[(\d+)\] (LOG|DETAIL|HINT|ERROR|WARNING|FATAL|STATEMENT):\s*(.*)$',line)
 if m:
  if current:messages.append(current)
  current={'line':no,'timestamp':m.group(1),'pid':m.group(2),'level':m.group(3),'message':m.group(4)}
 elif current:current['message']+='\n'+line
if current:messages.append(current)
actual=collections.Counter();matched=[];allselects=[];bindings=[];excluded=collections.Counter()
for index,m in enumerate(messages):
 if m['level']!='LOG':continue
 x=re.match(r'(?:execute\s+\S+:|statement:)\s*(.*)',m['message'],re.S)
 if not x:continue
 sql=norm(x.group(1))
 if re.match(r'^SELECT\b',sql,re.I):
  allselects.append({'line':m['line'],'sql':sql})
  if sql not in expected:excluded[sql]+=1
 if sql in expected:
  actual[sql]+=1;matched.append({'line':m['line'],'pid':m['pid'],'sql':sql})
  if 'FROM user_account WHERE CAST(id AS VARCHAR)=ANY(?)' in sql:
   assert sql.count('?')==1
   detail=messages[index+1] if index+1<len(messages) else None
   assert detail and detail['level']=='DETAIL' and detail['pid']==m['pid'] and detail['message'].startswith('parameters:'),m
   params=re.findall(r'\$(\d+)\s*=',detail['message']);assert params==['1'],detail
   body=re.search(r"\$1 = '(.*)'$",detail['message'],re.S);assert body and body.group(1).startswith('{') and body.group(1).endswith('}'),detail
   bindings.append({'statementLogLine':m['line'],'parameterDetailLogLine':detail['line'],'parameterNumbers':[1],'varcharArrayLiteralObserved':True,'parameterTextBytes':len(detail['message'].encode())})
comparisons=[{'normalizedSql':k,'observationStatements':v,'serverExecutedStatements':actual[k],'equal':v==actual[k]} for k,v in sorted(expected.items())]
proof={'normalization':'Collapse whitespace; replace PostgreSQL $n with JDBC ?; keep case/literals; remove optional terminal semicolon.','observationCases':len(events),'distinctObservedSignatures':len(expected),'observationStatementTotal':sum(expected.values()),'serverMatchedStatementTotal':sum(actual.values()),'allObservedSignaturesExact':all(x['equal'] for x in comparisons),'serverAllSelectMessages':len(allselects),'nonObservationSelectMessagesExcluded':sum(excluded.values()),'comparisons':comparisons,'matchedLogLocations':matched,'excludedSelectSignatures':[{'sql':k,'count':v} for k,v in sorted(excluded.items())],'batchNameArrayBindings':bindings,'scope':'Aggregate signatures from current13 observation cases only. Startup/fixture/post-read evidence-check SELECT whose signatures are absent from events are explicitly excluded, as are DDL/DML/control statements. Not all protocol/network SQL or arbitrary future JDBC paths.'}
(o/'server-crosscheck.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
assert proof['allObservedSignaturesExact'];assert len(bindings)==sum(v for k,v in expected.items() if 'FROM user_account WHERE CAST(id AS VARCHAR)=ANY(?)' in k)
for f in json.loads((o/'source-fingerprints.json').read_text()):
 b=subprocess.check_output(['git','show',head+':'+f['path']],cwd=r);assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
clean=json.loads((o/'cleanup.json').read_text());assert clean['containerRemoved'] and clean['worktreeRemoved'] and clean['mainStatus']==''
print(json.dumps({k:proof[k] for k in ['observationCases','distinctObservedSignatures','observationStatementTotal','serverMatchedStatementTotal','serverAllSelectMessages','nonObservationSelectMessagesExcluded','allObservedSignaturesExact']},ensure_ascii=False));print('arrayBindings',len(bindings))
