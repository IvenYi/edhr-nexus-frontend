import pathlib,subprocess,os,time,json,hashlib,datetime,shutil,xml.etree.ElementTree as ET
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend');OUT=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105/old-source-control');WT=pathlib.Path('/tmp/edhr-name-old-control-worktree-20261105')
BASE='5e2d1c084eea20a8d1be6f86bda4121b612cacce';CANDIDATE='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9';TARGET='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
TEST='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java';NAME='edhr-name-old-independent-20261105';DB='edhr_workflow_read_test_old_name_independent';commands=[];made_wt=False;made_pg=False
OUT.mkdir(parents=True,exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def run(args,cwd=ROOT,check=True,env=None):
 p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True);commands.append({'args':list(map(str,args)),'cwd':str(cwd),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});
 if check and p.returncode:raise RuntimeError(str(args)+' failed: '+p.stderr[-1500:])
 return p
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=ROOT)
try:
 run(['git','fetch','origin','edhr-dev']);head=run(['git','rev-parse','HEAD']).stdout.strip();target=run(['git','rev-parse','origin/edhr-dev']).stdout.strip();assert head==CANDIDATE and target==TARGET;assert not run(['git','status','--porcelain=v1']).stdout
 run(['git','worktree','add','--detach',str(WT),BASE]);made_wt=True
 test=blob(CANDIDATE,TEST);(WT/TEST).write_bytes(test)
 link=WT/'gmp-platform/frontend/node_modules';link.symlink_to(ROOT/'gmp-platform/frontend/node_modules',target_is_directory=True)
 paths=['gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java',TEST]
 fps=[]
 for path in paths:
  b=(WT/path).read_bytes();f={'path':path,'bytes':len(b),'sha256':sha(b)}
  if path==TEST:assert b==test;f['candidateTestByteIdentical']=True
  else:assert b==blob(BASE,path)==blob(TARGET,path);f['oldBaseAndTargetProductByteIdentical']=True
  dst=OUT/'source-snapshot'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);fps.append(f)
 (OUT/'source-fingerprints.json').write_text(json.dumps(fps,indent=2)+'\n')
 reads=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/evidence/button-signature-confirmed.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/development/workflow-operations-20261030/user-confirmed.md','docs/development/workflow-central-entry-extension-20261102/user-confirmed.md','docs/development/branch-review-20261105-workflow-name-batch/decision-package.yaml','docs/development/branch-review-20261105-workflow-name-batch/README.md']
 readfp=[]
 for path in reads:
  b=blob(CANDIDATE,path);dst=OUT/'read-snapshot'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);readfp.append({'path':path,'bytes':len(b),'sha256':sha(b),'readCommit':CANDIDATE})
 (OUT/'read-fingerprints.json').write_text(json.dumps(readfp,indent=2)+'\n')
 status=run(['git','status','--porcelain=v1'],cwd=WT).stdout
 (OUT/'assembled-working-tree.json').write_text(json.dumps({'head':BASE,'candidateTestSource':CANDIDATE,'status':status,'permittedChangedTest':TEST,'permittedUntrackedTool':'gmp-platform/frontend/node_modules'},indent=2)+'\n')
 assert set(line[3:] for line in status.splitlines())<={TEST,'gmp-platform/frontend/node_modules'}
 cid=run(['docker','run','--rm','-d','--name',NAME,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+DB,'-p','127.0.0.1::5432','postgres:16-alpine']).stdout.strip();made_pg=True
 for _ in range(120):
  if run(['docker','exec',NAME,'pg_isready','-h','127.0.0.1','-U','postgres'],check=False).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own native PostgreSQL unavailable')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',NAME]).stdout.strip();url=f'jdbc:postgresql://127.0.0.1:{port}/{DB}'
 env=os.environ.copy();env.update(WORKFLOW_READ_TEST_DATABASE_URL=url,PGUSER='postgres')
 selected='WorkflowReadObservationPostgresTest#detailObservesRepeatedNullAndMissingAssigneeLookups+noAssigneesSkipTheNameRead+batchNamesPreserveTextIdentityAndHistoricalEvidence+distinctAssigneesAreReadTogether'
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f',str(WT/'gmp-platform/backend/pom.xml'),'-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(OUT/'observations.jsonl'),'-Dtest='+selected,'test'];started=datetime.datetime.now(datetime.timezone.utc)
 with (OUT/'maven.log').open('w') as log:p=subprocess.run(command,cwd=WT,env=env,stdout=log,stderr=subprocess.STDOUT)
 commands.append({'args':command,'cwd':str(WT),'exitCode':p.returncode,'stdoutAndStderr':'maven.log'})
 files=[x for x in (WT/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml') if x.stat().st_mtime>=started.timestamp()];assert len(files)==1
 shutil.copy2(files[0],OUT/files[0].name);doc=ET.parse(files[0]).getroot();totals={k:int(doc.attrib[k]) for k in ['tests','failures','errors','skipped']};cases=[]
 for tc in doc.findall('testcase'):
  f=tc.find('failure');e=tc.find('error');cases.append({'name':tc.attrib['name'],'status':'failure' if f is not None else 'error' if e is not None else 'passed','message':f.attrib.get('message') if f is not None else e.attrib.get('message') if e is not None else None,'type':f.attrib.get('type') if f is not None else e.attrib.get('type') if e is not None else None})
 (OUT/'test-summary.json').write_text(json.dumps({'totals':totals,'cases':cases,'mavenExitCode':p.returncode},ensure_ascii=False,indent=2)+'\n')
 pgversion=run(['docker','exec',NAME,'psql','-U','postgres','-d',DB,'-Atc','SELECT version()']).stdout.strip()
 migration=run(['docker','exec',NAME,'psql','-U','postgres','-d',DB,'-Atc','SELECT orderexecuted,id,exectype FROM databasechangelog ORDER BY orderexecuted']).stdout
 (OUT/'migration-state.txt').write_text(migration)
 (OUT/'postgres.log').write_text(run(['docker','logs',NAME]).stdout+commands[-1]['stderr'])
 (OUT/'run.json').write_text(json.dumps({'negativeProductCommit':BASE,'candidateTestCommit':CANDIDATE,'target':TARGET,'database':url,'postgres':pgversion,'containerId':cid,'command':command,'started':started.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'fullConfiguredChangesets':len(migration.splitlines())},indent=2)+'\n')
 assert p.returncode==1 and totals=={'tests':7,'failures':5,'errors':0,'skipped':0},totals
 assert all(x['status']!='error' for x in cases);assert sum(x['status']=='passed' for x in cases)==2
 (OUT/'assertions-passed.json').write_text(json.dumps({'oldControlPassed':True,'expectedAssertionFailures':5,'positiveControls':2,'noErrorsOrSkips':True},indent=2)+'\n')
 print(json.dumps({'status':'native-negative-control-complete','totals':totals,'changesets':len(migration.splitlines()),'postgres':pgversion},ensure_ascii=False))
finally:
 cleanup={}
 if made_pg:
  cleanup['containerStop']=run(['docker','stop',NAME],check=False).returncode
  for _ in range(30):
   if run(['docker','inspect',NAME],check=False).returncode!=0:break
   time.sleep(.1)
  cleanup['containerRemoved']=run(['docker','inspect',NAME],check=False).returncode!=0
 if made_wt:
  link=WT/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink();cleanup['toolLinkRemoved']=True
  cleanup['worktreeStatusBeforeRemoval']=run(['git','status','--porcelain=v1'],cwd=WT).stdout
  cleanup['removeWorktreeExit']=run(['git','worktree','remove','--force',str(WT)],check=False).returncode
  cleanup['worktreeRemoved']=not WT.exists()
 cleanup['mainStatus']=run(['git','status','--porcelain=v1']).stdout
 (OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');(OUT/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
