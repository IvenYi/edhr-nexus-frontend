import pathlib,json,hashlib,subprocess,tarfile,xml.etree.ElementTree as ET,difflib,yaml
repo=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-name-final-qa-20261105/evidence-scope');out.mkdir(parents=True,exist_ok=True)
batch=repo/'docs/development/branch-review-20261105-workflow-name-batch';head='6e10604c7121c3e9ddb7196b560e1a079fd1ccf9';base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620';pre='5e2d1c084eea20a8d1be6f86bda4121b612cacce'
checks=[];commands=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(name,value,detail=None):
 assert value,(name,detail)
 checks.append({'id':name,'passed':True,'detail':detail})
def git(*args):
 p=subprocess.run(['git',*args],cwd=repo,capture_output=True,check=True);commands.append({'command':['git',*args],'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()});return p.stdout
def dump(n,x):(out/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
check('baseline',git('rev-parse','HEAD').decode().strip()==head and git('rev-parse','origin/edhr-dev').decode().strip()==base and not git('status','--porcelain=v1'))
git('merge-base','--is-ancestor',base,head)
contracts=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/architecture/business-knowledge-model.md']
docpaths=[str(p.relative_to(repo)) for p in batch.glob('*') if p.suffix in ['.md','.yaml','.json']]
policy=['docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml']
inputfps=[]
for p in contracts+docpaths+policy:
 b=(repo/p).read_bytes();d=out/'read-sources'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);inputfps.append({'path':p,'bytes':len(b),'sha256':sha(b)})
check('contracts-unchanged',not git('diff','--name-only',base,head,'--',*contracts[:3]))
m=json.loads((batch/'evidence-manifest.json').read_text());archive=batch/m['archive']['path'];raw=archive.read_bytes()
check('archive-storage',len(raw)==m['archive']['bytes'] and sha(raw)==m['archive']['sha256'],m['archive'])
with tarfile.open(archive) as tar:
 members={p.name:p for p in tar.getmembers() if p.isfile()};check('archive-members',len(members)==len(m['rawArtifacts'])==109)
 data={n:tar.extractfile(p).read() for n,p in members.items()}
 for f in m['rawArtifacts']:assert len(data[f['member']])==f['bytes'] and sha(data[f['member']])==f['sha256'],f['member']
 check('raw-artifact-bytes',True,109)
 om=json.loads(data['ontology/manifest.json']);check('ontology-manifest-final',om['status']=='FINAL' and om['ontologyResult']=='not-applicable' and om['artifactCount']==len(om['artifacts'])==40)
 check('ontology-manifest-sha',sha(data['ontology/manifest.json'])=='0470d09b327b9cc5244ea7f42e5903a3f2418b62bdbac5e48f42d04c63a045df')
 for f in om['artifacts']:assert len(data['ontology/'+f['path']])==f['bytes'] and sha(data['ontology/'+f['path']])==f['sha256'],f['path']
 check('ontology-nested-artifacts',True,40)
 sf=json.loads((batch/'source-review.json').read_text())['sourceFingerprints'];check('main-source-count',len(sf)==9)
 for f in sf:
  b=(repo/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
 check('main-current-source-fingerprints',True,9)
 of=json.loads(data['ontology/source-fingerprints.json']);check('ontology-source-count',len(of)==26)
 for f in of:
  b=(repo/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and data['ontology/'+f['artifact']]==b,f['path']
 check('ontology-current-source-fingerprints',True,26)
 finite=json.loads(data['ontology/finite-id-review.json']);check('finite-eight',finite['finiteExistingStatements']==len(finite['records'])==8 and finite['pendingKnowledgeCandidatesRetained']==931)
 knowledge=json.loads(data['ontology/knowledge-byte-check.json']);check('knowledge-count',len(knowledge['files'])==345)
 for f in knowledge['files']:
  b=(repo/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and b==git('show',pre+':'+f['path'])
 check('knowledge-unchanged-byteproof',True,345)
 expected={'red':{'tests':7,'failures':3,'errors':2,'skipped':0},'red_final':{'tests':7,'failures':5,'errors':0,'skipped':0},'green':{'tests':151,'failures':0,'errors':1,'skipped':0},'green_final':{'tests':151,'failures':0,'errors':0,'skipped':0}}
 phase={}
 for mode,expect in expected.items():
  prefix='primary/'+mode+'/';summary=json.loads(data[prefix+'test-summary.json']);assert summary['totals']==expect
  xmls=[n for n in data if n.startswith(prefix+'TEST-') and n.endswith('.xml')];tot={k:0 for k in expect};caseDetails=[]
  for n in xmls:
   x=ET.fromstring(data[n]);assert all(int(x.attrib[k])>=0 for k in tot)
   for k in tot:tot[k]+=int(x.attrib[k])
   for t in x.findall('testcase'):
    f=t.find('failure');e=t.find('error');caseDetails.append({'name':t.attrib['name'],'failureType':None if f is None else f.attrib['type'],'errorType':None if e is None else e.attrib['type'],'message':None if f is None and e is None else (f if f is not None else e).attrib.get('message')})
  assert tot==expect,(mode,tot,expect)
  run=json.loads(data[prefix+'run.json']);assert run['sourceCommit']==pre
  for f in run['sourceFingerprints']:
   b=data[prefix+'source-snapshot/'+f['path']];assert len(b)==f['bytes'] and sha(b)==f['sha256']
   if mode.startswith('red') and '/src/main/' in f['path']:assert b==git('show',pre+':'+f['path'])
   if mode=='green_final' or mode=='red_final' and '/src/test/' in f['path']:assert b==(repo/f['path']).read_bytes()
  assert json.loads(data[prefix+'cleanup.json'])['removed']
  phase[mode]={'totals':tot,'cases':caseDetails,'xmlCount':len(xmls),'mavenExit':run['exitCode']}
 check('four-stage-xml-totals-and-provenance',True,{n:p['totals'] for n,p in phase.items()})
 red=phase['red_final']['cases'];check('old-final-real-assertion-control',sum(x['failureType'] in ['java.lang.AssertionError','org.opentest4j.AssertionFailedError'] for x in red)==5 and all(x['errorType'] is None for x in red))
 check('initial-fixture-errors-retained',sum(x['errorType'] is not None and 'uq_workflow_task_active_instance_node' in (x['message'] or '') for x in phase['red']['cases'])==2)
 check('initial-map-null-error-retained',sum(x['errorType']=='java.lang.NullPointerException' for x in phase['green']['cases'])==1)
 test='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
 initial=data['primary/red/source-snapshot/'+test].decode();final=data['primary/red_final/source-snapshot/'+test].decode();lines=list(difflib.unified_diff(initial.splitlines(),final.splitlines(),lineterm=''));delta=[l for l in lines if l[:1] in ['+','-'] and not l.startswith(('+++','---'))]
 check('fixture-only-two-status-corrections',len(delta)==4 and all("'PENDING'" in x if x.startswith('-') else "'COMPLETED'" in x for x in delta))
 (out/'initial-fixture-test.diff').write_text('\n'.join(lines)+'\n')
 check('final-test-byte-identity',data['primary/red_final/source-snapshot/'+test]==data['primary/green/source-snapshot/'+test]==data['primary/green_final/source-snapshot/'+test]==(repo/test).read_bytes())
 rows=list(map(json.loads,data['primary/green_final/observations.jsonl'].decode().splitlines()));report=json.loads((batch/'performance-report.json').read_text());actual=[{'kind':x['kind'],'data':x['data'],'totalStatements':x['totalStatements'],'nameStatements':sum(v for k,v in x['jdbcSqlCounts'].items() if 'FROM user_account WHERE CAST(id AS VARCHAR)' in k)} for x in rows]
 check('observations-versus-report',len(rows)==13 and actual==report['observations'] and sum(x['totalStatements'] for x in rows)==49)
 dirs=[x for x in actual if x['kind']=='personnel-directory'];check('directory-still-unoptimized',[(x['data']['matchingPersonnel'],x['totalStatements']) for x in dirs]==[(0,1),(1,1),(99,1),(100,2),(101,2),(5000,2)])
 assertions=phase['red_final']['cases'];check('final-negative-plus-positive-only',len(assertions)==7 and sum(x['failureType'] is None for x in assertions)==2)
 # Independently recalculate the twelve unchanged scope slices/files, not only trust booleans.
 q='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java';before=git('show',pre+':'+q).decode();after=(repo/q).read_text()
 def between(s,a,b):i=s.index(a);return s[i:s.index(b,i)]
 pairs=[('list-method',between(before,'    public PageResult','    public Map<String, Object> detail'),between(after,'    public PageResult','    public Map<String, Object> detail')),('instance-visibility-and-nodes-edges-prefix',between(before,'    public Map<String, Object> detail','        result.put("tasks"'),between(after,'    public Map<String, Object> detail','        var instanceTasks')),('task-fields-state-signature-opinion-action',between(before,'            Map<String, Object> view','            var names ='),between(after,'            Map<String, Object> view','            view.put("assigneeName"')),('logs-query-and-current-name-priority',between(before,'        result.put("logs"','        return result;'),between(after,'        result.put("logs"','        return result;')),('visibility-has-and-error-tail',before[before.index('    private String visibility'):],after[after.index('    private String visibility'):]),('class-readonly-transaction-and-constants',between(before,'/** Shared read projection','    public PageResult'),between(after,'/** Shared read projection','    public PageResult'))]
 guards=json.loads(data['ontology/guard-byte-equivalence.json'])['checks'];assert len(guards)==12
 for name,a,b in pairs:
  rec=next(x for x in guards if x['name']==name);assert a==b and len(a.encode())==rec['beforeBytes']==rec['afterBytes'] and sha(a.encode())==rec['sha256']
 for rec in guards[6:]:
  b=(repo/rec['name']).read_bytes();assert b==git('show',pre+':'+rec['name']) and len(b)==rec['bytes'] and sha(b)==rec['sha256']
 check('twelve-protected-slices-files-recomputed',True,12)
 mainChanged=git('diff','--name-only',pre,head,'--','gmp-platform/backend/src/main').decode().splitlines();testChanged=git('diff','--name-only',pre,head,'--','gmp-platform/backend/src/test').decode().splitlines()
 check('only-authorized-runtime-and-test-changed',mainChanged==[q] and testChanged==[test])
 check('no-other-boundary-delta',not git('diff','--name-only',pre,head,'--','gmp-platform/frontend/src','gmp-platform/backend/src/main/resources','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents'))
 oldtest=git('show',pre+':'+test).decode();newtest=(repo/test).read_text();start='    @ParameterizedTest @ValueSource(ints = {0, 1, 99, 100, 101, 5000})';end='    private static class Read<T>'
 check('old-directory-observation-body-unchanged',between(oldtest,start,end)==between(newtest,start,end))
 check('test-observer-isolation',all(x in newtest for x in ['@EnabledIfSystemProperty','@EnabledIfEnvironmentVariable','@Import(WorkflowReadObservationPostgresTest.Config.class)','ThreadLocal<Read<?>>','CURRENT.remove()','@TestConfiguration']))
 check('bounded-private-batch-no-id-coercion',all(x in after for x in ['private Map<String, String> assigneeNames','filter(Objects::nonNull).distinct().toArray()','new SqlArrayValue("varchar", assigneeIds)','CAST(id AS VARCHAR)=ANY(?)','if (assigneeIds.length == 0) return names;']) and all(x not in between(after,'    private Map<String, String> assigneeNames','    private String visibility') for x in ['Long.valueOf','parseLong','.trim()', '.strip()']))
 check('scope-is-not-all-audit',report['findingClosureRequiresFreshFinalQA'] is True and report['directoryFindingStillOpen']=='PERF-TENANT-DIRECTORY-COUNT-20261104' and not report['wholeAuditComplete'])
 check('ledger-historical-coverage-remains',json.loads((batch/'baseline-review.json').read_text())['pendingKnowledgeCandidates']==931 and json.loads((batch/'source-review.json').read_text())['wholeFileComplete']==0)
dump('checks.json',checks);dump('phase-original-review.json',phase);dump('input-fingerprints.json',inputfps);dump('commands.json',commands)
dump('baseline.json',{'head':head,'base':base,'preChange':pre,'contractReadCommit':head,'status':git('status','--porcelain=v1').decode(),'knowledgeVersion':'0.3.25','checks':len(checks),'testExecutionByThisRole':False})
print(json.dumps({'checks':len(checks),'rawOriginals':len(m['rawArtifacts']),'ontologyOriginals':om['artifactCount'],'currentSourceFingerprints':len(sf),'ontologySourceFingerprints':len(of),'result':'passed'},ensure_ascii=False))
