from pathlib import Path
import json,re,subprocess,hashlib,shutil,yaml
root=Path('/tmp/edhr-upload-verify-quality-20261106');wt=Path('/tmp/edhr-upload-verify-quality-wt-20261106');raw=root/'native-full';dest=root/'source-review';dest.mkdir(exist_ok=True)
base='c4e451c264c11978515b2ae0088e64011fe2fcef';head='7e9defaaf8f5f557c4b2debb38417f33b764783b'
def git(*args):return subprocess.check_output(['git','-C',str(wt),*args],text=True).strip()
changed=git('diff','--name-status',base,head);(dest/'candidate-diff-name-status.txt').write_text(changed+'\n');assert git('rev-parse','HEAD')==head;subprocess.run(['git','-C',str(wt),'merge-base','--is-ancestor',base,head],check=True)
changes=[x.split('\t') for x in changed.splitlines()];test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java';assert sum(p==test for _,p in changes)==1
assert all(p==test or p.startswith('docs/development/') for _,p in changes)
protected=json.loads((wt/'docs/development/branch-review-20261106-attachment-upload-verify/protected-source-manifest.json').read_text());pfiles=protected['files'];mismatch=[]
for item in pfiles:
 p=item['path'];actual=(wt/p).read_bytes();b=subprocess.check_output(['git','-C',str(wt),'show',base+':'+p]);h=hashlib.sha256(actual).hexdigest()
 if actual!=b or h!=item['sha256']:mismatch.append(p)
assert not mismatch and len(pfiles)==1122
knowledge=git('ls-files','docs/knowledge').splitlines();assert len(knowledge)==350
assert not git('diff',base,head,'--','docs/knowledge')
copyPaths=['docs/knowledge/README.md','docs/knowledge/schema.yaml','docs/knowledge/open-questions.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-workflow.yaml','docs/development/branch-review-20261106-attachment-upload-verify/ontology-result.yaml','docs/development/branch-review-20261106-attachment-upload-verify/decision-package.yaml','docs/development/branch-review-20261106-attachment-upload-verify/review-notes.md','docs/development/branch-review-20261106-attachment-upload-verify/existing-issue-dedup.json','docs/development/branch-review-20261026-capacity-audit/ledger/findings.json']
copyPaths=[p for p in copyPaths if (wt/p).exists()];fingerprints=[]
for p in copyPaths:
 t=dest/'snapshots'/p;t.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(wt/p,t);fingerprints.append({'path':p,'sha256':hashlib.sha256(t.read_bytes()).hexdigest(),'bytes':t.stat().st_size})
q=yaml.safe_load((wt/'docs/knowledge/open-questions.yaml').read_text());assert q['knowledgeModelVersion']=='0.3.25';(dest/'open-question-ids.txt').write_text('\n'.join(x['id'] for x in q['questions'])+'\n')
schema=yaml.safe_load((wt/'docs/knowledge/schema.yaml').read_text());assert schema['schemaVersion']=='1.2.0' and schema['knowledgeModelVersion']=='0.3.25'
log=(raw/'postgres.log').read_text();blocks=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',log,flags=re.M);identity=[]
for i,b in enumerate(blocks):
 m=re.search(r'audit_write_((?:upload|verify)_(?:format|size)_\w+) LOG:.*execute [^:]+: insert into audit_event',b,re.I|re.S)
 if not m:continue
 name=m.group(1);detail=blocks[i+1];params={int(n):v for n,v in re.findall(r'\$(\d+) = (NULL|\'(?:[^\']|\'\')*\')(?=, \$|\s*$)',detail)}
 expect= ('LINK','attachment-observer','41','附件观察员') if name.startswith('upload_') else ('VERIFY','verification-observer','42','核验观察员')
 actual=tuple(params[n].strip("'") for n in [1,12,13,14]);assert actual==expect,(name,actual,expect)
 assert re.fullmatch(r"'[a-f0-9]{64}'",params[16]);identity.append({'action':name,'event':actual[0],'operatorAccount':actual[1],'operatorId':actual[2],'operatorName':actual[3],'sealedHashPresent':True,'hashRecomputeTested':False,'serverExecuteAndParameterDetail':b+detail})
assert len(identity)==22
(dest/'audit-identity-server-parameters.json').write_text(json.dumps(identity,ensure_ascii=False,indent=2)+'\n')
result={'base':base,'head':head,'targetAncestor':True,'changedPaths':len(changes),'allowedDocumentationPaths':len(changes)-1,'newOptInNativeTests':1,'productFrontendKnowledgeConfigMigrationChanges':0,'protectedFilesIndependentlyByteCompared':len(pfiles),'protectedMismatch':mismatch,'knowledgeFiles':len(knowledge),'knowledgeVersion':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion'],'phaseCompletionClaimed':False,'openQuestionsRead':len(q['questions']),'identityActionsServerValidated':len(identity),'snapshots':fingerprints}
(dest/'scope-independent.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
