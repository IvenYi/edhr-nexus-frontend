# 固定候选只读证据复核

此文件属于最终质量角色的只读证据子项，不是最终 `qualityResult`，不代替父实例的新鲜独立运行。实际固定读取 worktree `/tmp/edhr-upload-verify-quality-wt-20261106`，候选 `7e9defaaf8f5f557c4b2debb38417f33b764783b`，base/target `edhr-dev@c4e451c264c11978515b2ae0088e64011fe2fcef`。已读 AGENTS、quality-verifier、交接契约、当前知识 README/open questions 与相关附件规则及 DP；源码和证据都只读。没有 Maven、PG、浏览器或业务运行，没有修复产品、测试、夹具、配置，也没有新子实例。

## 实际复核及原件定位

- `archive-verification.json`：3 archive 外层 bytes/SHA 和全部 372 member 的路径、bytes/SHA 精确匹配；284+48+40，未解包成永久副本。原件来源仍为固定提交的 `evidence/archive-manifest.json` 和三个 tar.gz。
- `baseline-check.json`：候选只新增一个 opt-in 测试和研发文档。保护清单 1122 个文件分别读候选字节及 `git show base:path`，都相同；其中知识 350 个文件。7630 项 gzip 路径盘点与 base 的 `git ls-tree` 完全相同，它是覆盖分母，不是7630项审查通过。
- `archived-tests-check.json`：直接解析主侧归档 full 六份 XML 的 81（27+54）、focused 一份27及知识一份89，均0F/E/S；断言测试项数量与 XML totals 一致、主运行命令退出0、其源码快照匹配固定候选。focused27属于81子集，不计108 unique。本子项没有把归档运行称为自己新运行。
- `observations-check.json`：52 原始 JSON、11 个 roundtrip 原件输出（7小格式+4容量/输入轴）与研发汇总逐项匹配。上传读 fixture N、写 store N；verify/download 读 store N。原件 SHA/size/逐字保持断言的实现位置是新测试 `roundTrip`，元数据 PENDING→VERIFIED、verified_by、verified_at 和 LINK/VERIFY动作另有断言。
- `archived-server-sql-check.json`：直接分割完整 PG 日志记录，保留多行 SQL，逐 application_name 与 JDBC/Hibernate 的完整 SELECT 形状相比：52 动作、128 business SELECT、52 SET，原档无额外 driver catalog SELECT。36 INSERT+12 UPDATE 是成功 execute，48中有 upload_audit1、verify_audit1、outer_rollback2 共4次随后回滚；3具名 CHECK 拒绝的 INSERT ERROR另列。HibernateAttemptSQL中的失败审计 INSERT 只表示尝试，不表示 execute 成功或提交。种数、guard预上传、断言、事务及 runner 都在 tag 口径之外。
- `archived-jfr-external-recount.json`：离线调用外部 JDK21 `jfr print` 读取全部52份原录制，按动作 JavaThreadId 及自有 `/tmp/junit<id>/` 路径逐项独立重算 fixtureRead/storeRead/storeWrite/eventCount，与原 JSON 完全相同。逐份打印命令及输出SHA见 commands。临时 .jfr 副本执行后已删除；原 tar 不变。此结果是逻辑IO，不是物理磁盘IO，ImageIO全局临时文件不在该口径。
- `finite-ontology-check.json`：16有限记录（14 ID+2 Markdown）全部按实际 YAML jsonPointer/Markdown定位回读；13 consistent、3 evidence-gap仅表示既有声明子范围。两广域导出/版式场景和旧W5 hash回读缺口保留。350资产字节、0.3.25/schema1.2/P0 in-progress未变，不增加成熟度、整文件或历史unique。
- `old-hash-issue-check.json`：旧 ledger 的 `W5-AUDIT-HASH-001` 原记录、来源SHA及三条原证据逐项匹配，medium/open未修。历史README SHA是在该条明确声明的 `df6ea28a...` 提交核验，当前README已后续变化不能作为历史hash失败；三个引用均在声明历史commit吻合。该问题不新增计数、不改算法或历史hash。
- `source-scope-and-A23-check.json`：实际回源码核对必要保护及具体局部抽取方案；没有为行数重构或机械删除保护。

## A23、长方法和稳健性边界

上传在读字节之前检查声明 size，读完又检查实际长度，两者保护不同输入边界。父DHR、附件tenant/DHR/active、SHA和格式分别检查资格、归属、关联状态、完整性和结构。CREATE_NEW开流在局部catch之前，避免路径碰撞时误删他人原件；局部write/close失败只删本次片段，成功关闭后、登记/审计前注册最终事务hook。UNKNOWN只保留原件并记录定位，不能把未知结果当回滚并扫删。checked IOException路径在元数据之前只有SELECT锁，本批没有凭空增加rollbackFor/catch Throwable或全局清理。原 WriteFailure 相邻5例属于注入IO/close/cleanup/collision边界，不冒称真实磁盘满或进程崩溃。

具体抽取候选为：`readAndValidateUploadBytes`（永久文件前）、`storeNewOriginal`（保持CREATE_NEW及片段/关闭所有权）、`registerRollbackCleanup`（保持最终事务语义）；verify可有`validateRegisteredOriginal`，前提是摘要与格式仍读同一稳定视图。当前byte[]天然提供同一复制视图；直接流式SHA后重开可变路径会失去此属性。上述都是方案，固定候选中没有实施。

## 保留的限制

实际使用 Spring `StandardMultipartHttpServletRequest`/`StandardMultipartFile`，但HTTP request和disk Part是夹具，不认证容器multipart解析、网络上传、HTTP/JWT/RBAC。JDK ChannelInputStream自己覆写readAllBytes，合成generic仅覆写read/read(b)/close，因此50MiB分别约50.10和100.61MiB调用线程累计分配，不能推定所有部署固定两倍。核验约50.11MiB、下载约0.07MiB也不是存活堆、峰值、RSS、并发上限或SLA。

PNG/JPEG仅选择reader并读width/height/尺寸上限，没有完整像素解码；全SHA读取也不等于全格式解码。PDF解析/页数/加密检查不等于页面完整渲染。Office宏/加密、完整ZIP索引、重复/项数、CRC/size、100MiB展开限制仍在；展开限额不是堆上限。七种小阳性原件和大padded PNG不代表大PDF/Office、全部恶意内容或并发容量。

测试assertAudits核LINK/VERIFY动作、64hex及operator_id/account非空，没有对所有审计身份值精确断言；verified_by有明确核验员断言。父最终质量实例另行对新运行22个成功审计INSERT的PG参数做精确身份比对，该结果属于父实例，不写成此子项运行。64hex存在不是PG JSONB/时间往返可重算或全防篡改。AuditEvent、DHR冻结、签署及附件原件摘要不是同一对象。

PNG/JPEG小缓冲+临时快照优化在固定候选仍待用户答复，不能当批准或已实现。原931知识/86UI、wholeFile0/历史unique未知、W2余项/W3-W5交叉/W6健壮性性能具体抽取A23含旧已审/W7增量、原DHR high/A12/完整矩阵、PDF累计/大解析器/UNKNOWN崩溃/持久对账及通用任务签名密码/生产弹窗暂停全部保留。本子项不触发CI、不自动merge/deploy/恢复。

## 资源与输出

仅在自身 evidence-review 目录写复核脚本、结果、命令、读取快照和manifest。没有启动数据库/浏览器或其他业务进程；外部JFR命令已结束、自有临时录制副本已删除。父实例worktree及node_modules依赖软链保持不动，交由父实例清理。以 result.json 和最终manifest核实际结果，不能由本说明代替最终qualityResult。
