#!/usr/bin/env python3
"""Read-only independent evidence subcheck; no business runtime or source edits."""
from pathlib import Path
import hashlib,json,gzip,tarfile,re,collections,subprocess,xml.etree.ElementTree as ET,datetime,shutil
import yaml
ROOT=Path('/tmp/edhr-upload-verify-quality-wt-20261106')
OUT=Path('/tmp/edhr-upload-verify-quality-20261106/evidence-review')
BATCH=ROOT/'docs/development/branch-review-20261106-attachment-upload-verify'
BASE='c4e451c264c11978515b2ae0088e64011fe2fcef'
HEAD='7e9defaaf8f5f557c4b2debb38417f33b764783b'
JFR='/workspace/.edhr-cloud-tools/jdk-21/bin/jfr'
OUT.mkdir(parents=True,exist_ok=True)
checks=[]; findings=[]; read_files={}; commands=[]
def h(b): return hashlib.sha256(b).hexdigest()
def write(n,v):
 p=OUT/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*args):
 cmd=['git',*args];r=subprocess.run(cmd,cwd=ROOT,capture_output=True,check=True);commands.append({'command':cmd,'exitCode':r.returncode,'stdoutSha256':h(r.stdout)});return r.stdout

def read(p):
 p=Path(p);d=p.read_bytes();rel=str(p.relative_to(ROOT));read_files[rel]={'path':rel,'bytes':len(d),'sha256':h(d)};return d

def load(p):return json.loads(read(p))
def check(i,fn):
 try:
  detail=fn();checks.append({'id':i,'outcome':'passed','evidence':detail});print(i,'passed',flush=True)
 except Exception as e:
  findings.append({'id':i,'summary':str(e),'kind':'evidence-mismatch','repairPerformed':False});checks.append({'id':i,'outcome':'failed','evidence':[str(e)]});print(i,'FAILED',str(e),flush=True)

def baseline():
 assert git('rev-parse','HEAD').decode().strip()==HEAD
 changed=git('diff','--name-status',BASE,HEAD).decode();(OUT/'candidate-diff.txt').write_text(changed)
 names=git('diff','--name-only',BASE,HEAD).decode().splitlines()
 test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java'
 assert all(n==test or n.startswith('docs/development/') for n in names),names
 p=load(BATCH/'protected-source-manifest.json');assert p['baseCommit']==BASE and p['allUnchanged']
 assert len(p['files'])==1122
 bad=[]
 for f in p['files']:
  data=read(ROOT/f['path']);old=git('show',BASE+':'+f['path'])
  if data!=old or h(data)!=f['sha256'] or not f['unchanged']:bad.append(f['path'])
 assert not bad,bad
 paths=git('ls-tree','-r','--name-only',BASE).decode().splitlines()
 assert len(paths)==7630
 assert gzip.decompress(read(BATCH/'baseline-tracked-paths.txt.gz')).decode().splitlines()==paths
 assert sum(n.startswith('docs/knowledge/') for n in paths)==350
 inv=load(BATCH/'inventory-summary.json');assert inv['wholeFileCompletionThisBatch']==0 and inv['historicalUniqueCoverage'].startswith('unknown')
 status=git('status','--short').decode();(OUT/'fixed-worktree-status.txt').write_text(status)
 write('baseline-check.json',{'baseCommit':BASE,'headCommit':HEAD,'changedFiles':names,'protectedFiles':1122,'protectedAllBytesEqual':True,'knowledgeFilesUnchanged':350,'baselineInventory':7630,'wholeFileCompletion':0,'historicalUniqueCoverage':'unknown','parentRuntimeDependencyStatus':status,'note':'node_modules, if present, is parent-owned excluded dependency; this child never deletes it.'})
 return ['baseline-check.json','candidate-diff.txt','fixed-worktree-status.txt']

archives={}
def archive_check():
 manifest=load(BATCH/'evidence/archive-manifest.json');summaries=[]
 for a in manifest['archives']:
  p=BATCH/'evidence'/a['archive'];data=read(p);assert len(data)==a['bytes'] and h(data)==a['sha256'],a['archive']
  with tarfile.open(p) as t:
   members=[m for m in t.getmembers() if m.isfile()]
   assert len(members)==a['fileCount']==len(a['files'])
   assert len({m.name for m in members})==len(members)
   expected={f['path']:f for f in a['files']};assert set(expected)=={m.name for m in members}
   blobs={}
   for m in members:
    assert not m.name.startswith('/') and '..' not in Path(m.name).parts
    b=t.extractfile(m).read();e=expected[m.name];assert len(b)==e['bytes'] and h(b)==e['sha256'],(a['archive'],m.name)
    blobs[m.name]=b
   archives[a['archive']]=blobs
  summaries.append({'archive':a['archive'],'files':len(members),'bytes':len(data),'sha256':h(data),'allMembersExact':True})
 assert sum(x['files'] for x in summaries)==372
 write('archive-verification.json',{'archives':summaries,'totalOriginalFiles':372,'allOuterAndMemberHashesMatch':True,'unpackedWorkingCopies':False})
 return ['archive-verification.json','reads/docs/development/branch-review-20261106-attachment-upload-verify/evidence/archive-manifest.json']

def xml_check():
 raw=archives['main-originals.tar.gz'];summary={}
 for phase,expected,classes in [('native-full',81,6),('native-focused',27,1),('knowledge',89,1)]:
  files=[n for n in raw if n.startswith(phase+'/') and n.endswith('.xml')]
  rows=[]
  for f in files:
   x=ET.fromstring(raw[f]);r={'path':f,'sha256':h(raw[f]),'class':x.attrib['name'],**{k:int(x.attrib[k]) for k in ['tests','failures','errors','skipped']},'testCases':len(x.findall('testcase'))};rows.append(r)
  assert len(rows)==classes,(phase,len(rows));assert sum(r['tests'] for r in rows)==expected
  assert all(r['tests']==r['testCases'] and r['failures']==r['errors']==r['skipped']==0 for r in rows)
  summary[phase]=rows
 fullrun=json.loads(raw['native-full/run.json']);focusrun=json.loads(raw['native-focused/run.json'])
 assert fullrun['exitCode']==focusrun['exitCode']==0
 snapshots=[]
 for n in raw:
  prefix='native-full/source/'
  if n.startswith(prefix):
   path=n[len(prefix):]; actual=read(ROOT/path)
   assert raw[n]==actual,('snapshot != candidate',path)
   snapshots.append({'path':path,'sha256':h(actual)})
 assert len(snapshots)>15
 write('archived-tests-check.json',{'totals':{'nativeFull':81,'nativeFocused':27,'knowledge':89},'reports':summary,'fullAndFocusedExitCode':0,'sourceSnapshotsMatchFixedCandidate':snapshots,'runtimeByThisChild':False,'scope':'These are main-side archived reports independently parsed; parent owns fresh independent runtime. Focused27 is subset, not unique108.'})
 return ['archived-tests-check.json']

def events_check():
 raw=archives['main-originals.tar.gz'];events=[];originals=[]
 for n,b in sorted(raw.items()):
  if n.startswith('native-full/observations/') and n.endswith('.json'):
   d=json.loads(b)
   if 'applicationName' in d:events.append(d)
   elif n.rsplit('/',1)[-1].startswith('original_'):originals.append({'path':n,**d})
 assert len(events)==52 and len(originals)==11
 assert sum(d['selectStatements'] for d in events)==128
 assert len({e['applicationName'] for e in events})==52
 assert all(e['applicationName']=='audit_write_'+e['name'] for e in events)
 persisted=load(BATCH/'performance-report.json')['events']
 assert len(persisted)==52
 for e,p in zip(events,persisted):
  assert {k:v for k,v in e.items() if k not in ['jdbcQuerySql','hibernateAttemptSql','failureStack']}==p
 format_names={o['path'].rsplit('/',1)[-1] for o in originals if 'original_format_' in o['path']}
 assert format_names=={f'original_format_{x}.json' for x in ['pdf','png','jpg','doc','docx','xls','xlsx']}
 for o in originals: assert o['exactBytesAfterVerify'] is True and re.fullmatch('[0-9a-f]{64}',o['sha256'])
 for e in events:
  name=e['name'];size=e['data'].get('bytes')
  if name.startswith('upload_format_') or name.startswith('upload_size_'):
   assert e['fixtureReadBytes']==e['storedWriteBytes']==size and e['storedReadBytes']==0
   assert e['data']['multipartClass']=='org.springframework.web.multipart.support.StandardMultipartHttpServletRequest$StandardMultipartFile'
  elif name.startswith('verify_format_') or name.startswith('verify_size_') or name.startswith('download_format_') or name.startswith('download_size_'):
   assert e['storedReadBytes']==size and e['fixtureReadBytes']==e['storedWriteBytes']==0
 write('observations-check.json',{'actions':52,'businessSELECT':128,'originalOutcomes':originals,'allExpectedReadWriteBytesMatched':True,'allocationValues':[{'name':e['name'],'threadAllocatedBytes':e['threadAllocatedBytes'],'MiB':e['threadAllocatedBytes']/1048576} for e in events if '_size_' in e['name']],'allocationIsNotPeak':True,'logicalIoScope':'Owned junit fixture/store paths, measured Java thread only; excludes all ImageIO temp files and physical disk/cache effects.'})
 return ['observations-check.json']

# Server records kept whole across multiline SQL so no SQL shape is silently discarded.
def sql_check():
 raw=archives['main-originals.tar.gz'];events=[json.loads(b) for n,b in sorted(raw.items()) if n.startswith('native-full/observations/') and n.endswith('.json') and 'applicationName' in json.loads(b)]
 norm=lambda s:' '.join(re.sub(r'\$\d+','?',s).lower().split())
 text=raw['native-full/postgres.log'].decode();parts=re.split(r'(?=^\d{4}-\d{2}-\d{2} .*? UTC \[\d+\])',text,flags=re.M)
 success=collections.defaultdict(collections.Counter);errors=[]
 for p in parts:
  m=re.search(r'edhr_dhr_attachment_write_test_full (audit_write_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',p,re.S)
  if m:success[m.group(1)][norm(m.group(2).strip())]+=1
  m=re.search(r'edhr_dhr_attachment_write_test_full (audit_write_\w+) ERROR:  (.*)',p)
  if m:errors.append({'applicationName':m.group(1),'error':m.group(2)})
 types=collections.Counter();rows=[];catalog=[]
 for e in events:
  tag=e['applicationName'];expected=collections.Counter(norm(s) for s in e['jdbcQuerySql']+e['hibernateAttemptSql'] if norm(s).startswith('select'))
  actual=collections.Counter({s:n for s,n in success[tag].items() if s.startswith('select')})
  for s,n in (actual-expected).items():
   assert 'pg_catalog.pg_type' in s,(tag,s);catalog.append({'tag':tag,'sql':s,'count':n});actual[s]-=n
  assert +actual==expected,(tag,expected-actual,actual-expected)
  assert sum(expected.values())==e['selectStatements']
  counts=collections.Counter()
  for s,n in success[tag].items():counts[s.split()[0]]+=n;types[s.split()[0]]+=n
  rows.append({'name':e['name'],'applicationName':tag,'successfulExecuteTypes':dict(counts),'businessSelectShapes':[{'sql':s,'count':n} for s,n in actual.items() if n],'hibernateAttemptSQL':e['hibernateAttemptSql'],'shapeMatch':True,'requestedRollback':e['requestedRollback'],'failureClass':e['failureClass']})
 assert dict(types)=={'set':52,'select':128,'insert':36,'update':12},dict(types)
 assert len(errors)==3
 assert {e['applicationName'] for e in errors}=={'audit_write_failure_upload_sql','audit_write_failure_upload_audit','audit_write_failure_verify_audit'}
 assert all('native_write_refusal' in e['error'] or 'native_audit_refusal' in e['error'] for e in errors)
 writes_rolled_back={}
 for r in rows:
  if r['name'] in ['failure_upload_audit','failure_verify_audit','failure_outer_rollback']:
   writes_rolled_back[r['name']]=sum(r['successfulExecuteTypes'].get(x,0) for x in ['insert','update'])
 assert writes_rolled_back=={'failure_outer_rollback':2,'failure_upload_audit':1,'failure_verify_audit':1},writes_rolled_back
 write('archived-server-sql-check.json',{'actions':52,'successfulExecuteTypes':dict(types),'driverMetadataSelect':catalog,'successfulWritesLaterRolledBack':writes_rolled_back,'refusedInsertErrors':errors,'rows':rows,'semantics':'48 successful write executes, including four subsequently rolled back; three refused INSERT ERRORs separately. No committed-write total inferred from StatementInspector or these counters.'})
 return ['archived-server-sql-check.json']

def finite_check():
 records=[json.loads(l) for l in read(BATCH/'finite-audit-records.jsonl').decode().splitlines() if l]
 assert len(records)==16
 assert collections.Counter(r['conclusion'] for r in records)=={'consistent':13,'evidence-gap':3}
 selected=[]
 for r in records:
  path=ROOT/r['sourcePath'];b=read(path)
  if 'jsonPointer' in r['sourceLocator']:
   obj=yaml.safe_load(b)
   for part in r['sourceLocator']['jsonPointer'].split('/')[1:]:obj=obj[int(part)] if isinstance(obj,list) else obj[part]
   assert obj['id']==r['id'],r['id'];selected.append({'id':r['id'],'path':r['sourcePath'],'object':obj,'originalMaturity':r['originalMaturity'],'conclusion':r['conclusion']})
  else:selected.append({'id':r['id'],'path':r['sourcePath'],'locator':r['sourceLocator'],'conclusion':r['conclusion']})
  for e in r.get('implementationEvidence',[]):assert h(read(ROOT/e['path']))==e['sha256']
 result=yaml.safe_load(read(BATCH/'ontology-result.yaml'))['ontologyResult']
 assert result['result']=='not-applicable' and result['baselineBefore']==result['baselineAfter']=='0.3.25'
 assert result['changedArtifacts']==result['knowledgeSync']==result['conflicts']==result['questions']==[]
 assert result['roadmapProgress']['stage']=='P0' and result['roadmapProgress']['status']=='in-progress'
 assert result['roadmapProgress']['exitCriteriaEvidence']==[]
 onto=archives['ontology-originals.tar.gz'];src=archives['source-review-originals.tar.gz']
 assert onto['finite-audit-records.jsonl']==read(BATCH/'finite-audit-records.jsonl')
 assert onto['ontologyResult.yaml']==read(BATCH/'ontology-result.yaml')
 for label,raw in [('ontology',onto),('source',src)]:
  for key in ['manifest.json','manifest.sha256']:
   assert key in raw
  digest=h(raw['manifest.json']);assert raw['manifest.sha256'].decode().split()[0]==digest,(label,digest)
 write('finite-ontology-check.json',{'records':16,'idRecords':14,'markdownRecords':2,'conclusionCounts':{'consistent':13,'evidence-gap':3},'selectedRecords':selected,'knowledgeUnchanged':350,'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0/in-progress','ontologyArchiveInnerManifestSha256':h(onto['manifest.json']),'sourceArchiveInnerManifestSha256':h(src['manifest.json']),'scope':'Only declared subscopes; no whole-file/unique/maturity progress inferred; no runtime performed by child or ontology/source roles.'})
 return ['finite-ontology-check.json']

def dedup_check():
 d=load(BATCH/'existing-issue-dedup.json');b=read(ROOT/d['sourcePath']);assert h(b)==d['sourceSha256']
 old=next(x for x in json.loads(b) if x['id']=='W5-AUDIT-HASH-001');assert old==d['existingRecord']
 assert old['severity']=='medium' and old['disposition']=='preexisting-medium-open'
 assert old['resolution']['fixCommits']==[]
 raw=[]
 for e in old['evidence']:
  p=ROOT/e['path'];current=read(p);b=git('show',e['commit']+':'+e['path']);assert h(b)==e['sha256'],e['path'];raw.append({'path':e['path'],'declaredCommit':e['commit'],'sha256':h(b),'currentSha256':h(current),'matchesDeclaredHistoricalCommit':True})
 source=read(ROOT/'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java').decode()
 assert '@PrePersist' in source and 'computeSnapshotHash' in source
 write('old-hash-issue-check.json',{'id':old['id'],'severity':'medium','status':'open','dedupExact':True,'ledgerSha256':d['sourceSha256'],'originalEvidence':raw,'newFindingCount':0,'repaired':False,'auditHash64PresenceIsNotRoundtripCertification':True,'distinctDigestScopes':['AuditEvent sealed snapshot','DHR frozen summary','electronic signature','attachment original SHA-256']})
 return ['old-hash-issue-check.json']

def jfr_check():
 raw=archives['main-originals.tar.gz'];events=[json.loads(b) for n,b in sorted(raw.items()) if n.startswith('native-full/observations/') and n.endswith('.json') and 'applicationName' in json.loads(b)];rows=[]
 scratch=OUT/'scratch-jfr';scratch.mkdir(exist_ok=True)
 try:
  for e in events:
   name=e['name'];path='native-full/observations/'+name+'.jfr';file=scratch/(name+'.jfr');file.write_bytes(raw[path])
   cmd=[JFR,'print','--json','--events','jdk.FileRead,jdk.FileWrite',str(file)]
   p=subprocess.run(cmd,capture_output=True,check=True);commands.append({'command':cmd,'exitCode':p.returncode,'stdoutSha256':h(p.stdout)})
   parsed=json.loads(p.stdout)['recording']['events'];count=0;fixture=storedread=storedwrite=0;owned_paths=[];roots=set()
   for item in parsed:
    v=item['values'];thread=v.get('eventThread') or {};pathstr=v.get('path') or ''
    if thread.get('javaThreadId')!=e['measuredThreadId'] or not re.match(r'^/tmp/junit\d+/',pathstr):continue
    roots.add('/'.join(pathstr.split('/')[:3]));owned_paths.append(pathstr);count+=1;isstore='/store/' in pathstr
    if item['type']=='jdk.FileRead':
     if isstore:storedread+=v['bytesRead']
     else:fixture+=v['bytesRead']
    elif item['type']=='jdk.FileWrite' and isstore:storedwrite+=v['bytesWritten']
   assert len(roots)<=1,(name,roots)
   actual={'fixtureReadBytes':fixture,'storedReadBytes':storedread,'storedWriteBytes':storedwrite,'trackedIoEvents':count}
   assert all(actual[k]==e[k] for k in actual),(name,actual,{k:e[k] for k in actual})
   rows.append({'name':name,'recordingArchivePath':path,'recordingSha256':h(raw[path]),'jfrPrintStdoutSha256':h(p.stdout),'measuredThreadId':e['measuredThreadId'],'roots':sorted(roots),'ownedPaths':sorted(set(owned_paths)),**actual,'matchesOriginal':True});file.unlink()
 finally:shutil.rmtree(scratch)
 write('archived-jfr-external-recount.json',{'events':len(rows),'allRecountedUsingExternalJfr':True,'tool':JFR,'toolSha256':h(Path(JFR).resolve().read_bytes()),'rows':rows,'temporaryCopiesRemoved':True,'scope':'Archived main-side JFR parsed offline; owned /tmp/junit<id>/ paths and measured Java thread only. Not parent fresh runtime, physical IO, all temporary files, or peak memory.'})
 return ['archived-jfr-external-recount.json']


def source_scope_check():
 service=read(ROOT/'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java').decode()
 office=read(ROOT/'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrOfficeAttachment.java').decode()
 test=read(ROOT/'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java').decode()
 notes=read(BATCH/'review-notes.md').decode()
 assert 'file.getSize() > MAX_BYTES' in service and 'bytes.length > MAX_BYTES' in service
 assert service.index('Files.newOutputStream(stored, java.nio.file.StandardOpenOption.CREATE_NEW)')<service.index('try (output)')
 assert service.index('try (output)')<service.index('TransactionSynchronizationManager.registerSynchronization')<service.index('INSERT INTO dhr_attachment')
 assert 'STATUS_ROLLED_BACK' in service and 'STATUS_UNKNOWN' in service
 assert 'reader.getWidth(0)' in service and 'reader.getHeight(0)' in service and 'reader.read(' not in service
 assert all(x in office for x in ['FilePassRecord','TYPE_EXCEL_4_MACRO','TYPE_VB_MODULE','inspectDirectory','encryptedpackage','vba','inspectZipSize','10_000','100L * 1024 * 1024','getCrc()','getSize()','remaining.isEmpty()'])
 assert 'new StandardMultipartHttpServletRequest(request)' in test and 'new MockHttpServletRequest()' in test
 assert 'new InputStream() { public int read()' in test
 assert '@MockBean FormProjectionWorker worker' in test and test.count('@MockBean')==1
 assert all(x in notes for x in ['readAndValidateUploadBytes','storeNewOriginal','registerRollbackCleanup','validateRegisteredOriginal','尚未答复，不实现','当前核验byte[]让摘要与格式读取同一复制视图'])
 write('source-scope-and-A23-check.json',{'reviewType':'finite source inspection + claim boundary checks; not whole-file completion','A23':[{'boundary':'declared size vs actual bytes','purpose':'early metadata guard and actual input guard are distinct'}, {'boundary':'CREATE_NEW outside partial-write catch','purpose':'avoid deletion of an existing colliding file'}, {'boundary':'local partial write/close cleanup vs transaction synchronization','purpose':'only own fragment vs final rollback after successful file creation'}, {'boundary':'UNKNOWN retains original and logs','purpose':'outcome unknown is not permission for destructive cleanup'}, {'boundary':'parent/attachment tenant DHR active SHA and format','purpose':'distinct qualification integrity and format guards, no mechanical deletion'}], 'concreteExtractionCandidates':['readAndValidateUploadBytes before permanent file creation','storeNewOriginal preserving CREATE_NEW and partial/close ownership','registerRollbackCleanup preserving final transaction outcome','validateRegisteredOriginal using one stable original view before metadata/audit'],'proposalOnly':True,'productOptimizationImplemented':False,'imageCheck':'reader/header + width/height only, not pixel decode','multipartScope':'real Spring wrapper, MockHttpServletRequest + disk Part, not actual network/container parser','allocationInputAxes':'JDK ChannelInputStream readAllBytes override vs synthetic generic InputStream inherited readAllBytes; not universal 2x','OfficeGuardsRemain':['macro/encryption','complete ZIP index + streamed entries','duplicates + entry count','CRC/size consistency','expanded byte cap, not heap cap'],'auditIdentityAssertionLimit':'existing assertAudits asserts operator id/account nonnull, not exact values; verified_by is checked explicitly. Parent separately verifies exact server parameters in its fresh runtime.'})
 return ['source-scope-and-A23-check.json']

for n in ['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/roadmap.yaml']:
 if (ROOT/n).is_file():read(ROOT/n)
for n in ['README.md','decision-package.yaml','review-notes.md','main-validation.json','performance-report.json','server-sql-review.json','existing-issue-dedup.json','inventory-summary.json','ontology-result.yaml','finite-audit-records.jsonl','finite-audit-summary.json']:read(BATCH/n)
for i,fn in [('fixed-candidate-and-byte-protection',baseline),('archive-outer-and-372-member-hashes',archive_check),('archived-xml-source-identity',xml_check),('52-observations-byte-and-allocation-math',events_check),('server-success-refused-and-rollback-separation',sql_check),('finite-ontology-and-maturity-scope',finite_check),('existing-W5-hash-dedup',dedup_check),('external-archived-JFR-recount',jfr_check),('A23-concrete-extraction-and-evidence-limits',source_scope_check)]:check(i,fn)
# Save only the read contracts, decision package and finite original rules as byte snapshots;
# all other read paths are fixed-commit + content-addressed in read-manifest.json.
snapshot_paths=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md']
snapshot_paths += [str((BATCH/n).relative_to(ROOT)) for n in ['decision-package.yaml','evidence/archive-manifest.json','review-notes.md','ontology-result.yaml','finite-audit-records.jsonl','existing-issue-dedup.json']]
for n in snapshot_paths:
 p=ROOT/n
 if p.is_file():
  q=OUT/'reads'/n;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(read(p))
write('commands.json',commands);write('read-manifest.json',{'fixedReadCommit':HEAD,'paths':list(read_files.values())})
result={'kind':'read-only-evidence-subcheck-not-final-quality','result':'failed' if findings else 'passed','baseCommit':BASE,'headCommit':HEAD,'contractBaseline':{'sourceCommit':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':HEAD,'uncommittedContractPaths':[]},'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','checks':checks,'findings':findings,'blockingConditions':[],'resources':{'businessTestsRunByChild':False,'PGStartedByChild':False,'browserUsed':False,'productTestFixtureConfigEdits':False,'temporaryJfrCopiesRemoved':True,'parentWorktreeAndDependencyUntouched':True},'residualRisks':['Not the final independent quality gate: parent runs fresh81/89/PG/JFR.','Seven small valid formats and padded large PNG do not certify full PDF/Office content/large-format capacity/concurrency/peak/SLA.','Actual Spring wrapper + fixture Part is not container parsing/network/HTTP/JWT/RBAC.','PNG/JPEG checks header/reader/dimensions, not complete pixel decode; full SHA is not full format decode.','Audit64 hex field/action/identity presence/transaction checks do not close preexisting W5-AUDIT-HASH-001 hash readback.','7630 paths only inventory, wholeFile0/historical unique unknown; 931/86/W2-W7 and original high/A12/PDF/UNKNOWN/durable reconciliation and pauses retained.','PNG/JPEG temp snapshot optimization proposal unapproved and unimplemented in fixed candidate.']}
write('result.json',result)
print(json.dumps({'result':result['result'],'checks':len(checks),'failed':len(findings),'output':str(OUT)},ensure_ascii=False),flush=True)
