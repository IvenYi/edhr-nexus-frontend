from pathlib import Path
import json,re,subprocess,concurrent.futures,collections,hashlib,xml.etree.ElementTree as ET,shutil
root=Path('/tmp/edhr-upload-verify-quality-20261106');wt=Path('/tmp/edhr-upload-verify-quality-wt-20261106');raw=root/'native-full';obsdir=raw/'observations';out=root/'independent-recalculation';out.mkdir(exist_ok=True)
observations={j['name']:j for p in sorted(obsdir.glob('*.json')) if (j:=json.loads(p.read_text())).get('applicationName')}
assert len(observations)==52
normalize=lambda x:re.sub(r'\s+',' ',re.sub(r'\$\d+','?',x.strip())).lower()
expected={name:collections.Counter(normalize(s) for s in o['jdbcQuerySql']+o['hibernateAttemptSql'] if s.lstrip().lower().startswith('select')) for name,o in observations.items()}
actual={n:collections.Counter() for n in observations};success=[];extras=[];errors=[];sets=[];other=[]
log=(raw/'postgres.log').read_text()
for block in re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',log,flags=re.M):
 m=re.search(r'edhr_dhr_attachment_write_test_full audit_write_(\w+) (LOG|ERROR):\s+(.*)',block,re.S)
 if not m:continue
 name,kind,body=m.groups()
 if name not in observations:raise AssertionError(('unexpected action',name))
 if kind=='ERROR':errors.append({'name':name,'message':body.strip()});continue
 q=re.match(r'duration:\s+[\d.]+ ms\s+execute [^:]+:\s*(.*)',body,re.S)
 if not q:continue
 sql=normalize(q.group(1))
 if sql.startswith('set local application_name'):sets.append({'name':name,'sql':sql})
 elif sql.startswith('select'):
  if 'pg_catalog.pg_type' in sql:extras.append({'name':name,'sql':sql})
  else:actual[name][sql]+=1
 elif sql.startswith(('insert ','update ','delete ')):success.append({'name':name,'sql':sql})
 else:other.append({'name':name,'sql':sql})
compare=[{'name':n,'expectedSelects':sum(expected[n].values()),'actualBusinessSelects':sum(actual[n].values()),'exactShapeMatch':expected[n]==actual[n],'expectedShapes':dict(expected[n]),'actualShapes':dict(actual[n])} for n in observations]
assert all(x['exactShapeMatch'] for x in compare),[x for x in compare if not x['exactShapeMatch']]
assert sum(sum(x.values()) for x in actual.values())==128
assert len(sets)==52 and len(success)==48 and len(errors)==3
writes=collections.Counter(x['sql'].split(' ')[0].upper() for x in success)
assert dict(writes)=={'INSERT':36,'UPDATE':12},writes
rollbackNames={'failure_upload_audit','failure_verify_audit','failure_outer_rollback'}
rollback=[x for x in success if x['name'] in rollbackNames]
assert len(rollback)==4
sqlresult={'observations':52,'businessSelectCount':128,'shapeMatchActions':52,'setLocalCount':len(sets),'successfulWriteExecutions':len(success),'successfulWriteKinds':dict(writes),'successfulWritesLaterRolledBack':rollback,'writeCountsAreCommittedRows':False,'expectedCheckConstraintErrors':errors,'driverCatalogMetadataSelects':extras,'otherTaggedExecute':other,'perAction':compare,'successfulWriteExecutionsRaw':success,'scope':'Only tagged action execute completions; parse/bind, seed, guard, assertion and runner SQL excluded. Hibernate inspector logs attempts and may include rejected INSERTs.'}
(out/'postgres-independent.json').write_text(json.dumps(sqlresult,ensure_ascii=False,indent=2)+'\n')
jfrtool='/workspace/.edhr-cloud-tools/jdk-21/bin/jfr';jfrout=out/'jfr-json';jfrout.mkdir(exist_ok=True)
def recalc(item):
 name,o=item;path=obsdir/(name+'.jfr');cmd=[jfrtool,'print','--json','--events','jdk.FileRead,jdk.FileWrite',str(path)];dest=jfrout/(name+'.json')
 with dest.open('w') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.PIPE,text=True)
 assert p.returncode==0,(name,p.stderr)
 events=json.loads(dest.read_text())['recording']['events'];counts=dict(fixtureReadBytes=0,storedReadBytes=0,storedWriteBytes=0,trackedIoEvents=0);paths=collections.Counter();outside=collections.Counter()
 for e in events:
  v=e['values'];path=v.get('path');tid=(v.get('eventThread') or {}).get('javaThreadId')
  if tid!=o['measuredThreadId']:continue
  if not path or not re.match(r'^/tmp/junit[0-9]+(?:/|$)',path):
   if path:outside[path]+=1
   continue
  paths[path]+=1;counts['trackedIoEvents']+=1;stored='/store/' in path
  if e['type']=='jdk.FileRead':counts['storedReadBytes' if stored else 'fixtureReadBytes']+=v['bytesRead']
  elif stored:counts['storedWriteBytes']+=v['bytesWritten']
 match=all(o[k]==v for k,v in counts.items())
 return dict(name=name,command=cmd,exitCode=p.returncode,jfrSha256=hashlib.sha256((obsdir/(name+'.jfr')).read_bytes()).hexdigest(),externalJsonSha256=hashlib.sha256(dest.read_bytes()).hexdigest(),measuredJavaThreadId=o['measuredThreadId'],externalRecomputed=counts,recorded={k:o[k] for k in counts},match=match,trackedPaths=dict(paths),outsideOwnedFixturePaths=dict(outside),threadAllocatedBytes=o['threadAllocatedBytes'])
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(recalc,observations.items()))
assert len(rows)==52 and all(x['match'] for x in rows)
selected={r['name']:{'allocatedMiB':r['threadAllocatedBytes']/1024/1024,**r['externalRecomputed']} for r in rows if '50mib' in r['name']}
(out/'jfr-independent.json').write_text(json.dumps({'observations':52,'externalMatches':52,'allJfrRecomputedUsingExternalTool':True,'selectionRule':'recorded JavaThreadId AND owned /tmp/junit<digits> path; /store/ classified as stored; unrelated ImageIO temp/classpath IO excluded, not all physical IO.','selected50MiB':selected,'records':rows},ensure_ascii=False,indent=2)+'\n')
knowledge=root/'knowledge';kxml=wt/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml';shutil.copy2(kxml,knowledge/kxml.name);k=ET.parse(kxml).getroot();ks={key:int(k.attrib[key]) for key in ['tests','failures','errors','skipped']};assert ks==dict(tests=89,failures=0,errors=0,skipped=0);(knowledge/'test-summary.json').write_text(json.dumps(ks,indent=2)+'\n')
print(json.dumps(dict(sql={'actions':52,'businessSELECT':128,'SET':52,'successfulWrites':48,'rollbackWrites':4,'CHECKrefusals':3,'driverMetadataSelect':len(extras)},jfr={'externalMatched':52,'selected50MiB':selected},knowledge=ks),indent=2))
