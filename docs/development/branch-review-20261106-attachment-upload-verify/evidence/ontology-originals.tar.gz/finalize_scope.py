from pathlib import Path
import json,hashlib,yaml
o=Path('/tmp/edhr-upload-verify-ontology-20261106')
p='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java'
source=(o/'snapshot'/p).read_text()
cases={'sevenSmallFormatsKeepExactOriginalAndAtomicVerification':7,'diskChannelMultipartAndVerificationAllocation':3,'genericInputStreamIsASeparateFiftyMiBAdapterAxis':1,'realDatabaseOrAuditRefusalAndFlushedOuterRollbackKeepOwnership':4,'verificationRefusalPreservesRegistrationAndOriginalOwnership':7,'seededDhrWriteStatesRejectBeforeConsumingUploadOrOriginal':3,'invalidUploadsNeverRegisterOrWriteAnOriginal':2}
assert all('void '+name+'(' in source for name in cases) and sum(cases.values())==27
observation=json.loads((o/'test-scope-observation.json').read_text())
observation.update(actualSourceInspected=True,capturedSourceLines=len(source.splitlines()),capturedSourceSha256=hashlib.sha256(source.encode()).hexdigest(),declaredCaseInvocations=cases,totalDeclaredInvocations=27,compiledOrExecutedByRole=False,scopeNote='Actual 288-line initial source snapshot only; later compile/fixture fixes and final runtime are owned by main/final quality; no pass claim from source.')
(o/'test-scope-observation.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n')
result=yaml.safe_load((o/'ontologyResult.yaml').read_text())['ontologyResult']
assert result['result']=='not-applicable' and not result['changedArtifacts'] and not result['questions'] and not result['conflicts']
fps=json.loads((o/'source-snapshot-manifest.json').read_text())
for item in fps:assert hashlib.sha256((o/'snapshot'/item['path']).read_bytes()).hexdigest()==item['sha256']
records=[json.loads(x) for x in (o/'finite-audit-records.jsonl').read_text().splitlines()]
assert len(records)==16 and sum(x['conclusion']=='consistent' for x in records)==13 and sum(x['conclusion']=='evidence-gap' for x in records)==3
assert all(x['semanticReviewStatus']=='reviewed' and not x['maturityChanged'] and not x['runtimeEvidenceByRole'] for x in records)
(o/'validation-final.log').write_text('PASS strict result reload; 16 finite records = 13 scoped consistent/3 gaps; '+str(len(fps))+' source snapshots exact; actual captured 288-line initial test source/27 declared invocations inspected, not compiled or executed; source/target c4e451c264c11978515b2ae0088e64011fe2fcef.\n')
files=sorted(p for p in o.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256'])
manifest={'sourceCommit':result['contractBaseline']['sourceCommit'],'targetCommit':result['contractBaseline']['targetCommit'],'fileCount':len(files),'files':[{'path':str(p.relative_to(o)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(o/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');digest=hashlib.sha256((o/'manifest.json').read_bytes()).hexdigest();(o/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'result':result['result'],'records':16,'conclusions':{'consistent':13,'evidence-gap':3},'sourceSnapshots':len(fps),'rawFiles':len(files),'manifestSha256':digest},ensure_ascii=False))
