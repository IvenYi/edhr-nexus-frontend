# 上传／核验有限本体核对

结论为 `ontologyResult.result: not-applicable`。实际 source、target、契约读取均为 `c4e451c264c11978515b2ae0088e64011fe2fcef`；知识350文件及 `0.3.25 / schema1.2.0 / P0 in-progress` 保持。主侧当时仅新增计划中的显式opt-in原生观察及研发记录，本角色未修改仓库、未执行Maven/PG/JFR/浏览器或任何运行测试，未创建子项或业务资源。

有限清单16条为14个既有ID加2份Markdown：13条在明确子范围一致，2个完整验收场景和已有W5审计摘要回读为3条evidence-gap。它们有前批重叠，不作为全审新增unique或整文件完成；350指纹只证明字节基线，不能称350份语义审完。原931知识候选、86 UI、W2余项/W3-W5交叉/W6健壮性性能抽取A23含旧已审/W7增量、原DHR high/A12/完整矩阵、PDF容量以及用户两暂停继续。

实际核对当前定义与原始源码的边界：

- `DEC-0063-10/13`、受控附件术语/概念及关系要求来源/生产对象/内容核验、原字节和SHA、带原因解除而保留历史原件。附件不是第四种表单来源。格式和容量通过不替代人工关联核验。
- 单文件上限为52428800字节、含边界；不是整个multipart请求体上限。保留PDF/PNG/JPEG、DOC/DOCX/XLS/XLSX，Office只原件上传下载，不在线预览、编辑或转换。宏/加密、ZIP展开/条目限额是原工程防护，确认证据明确标为inference；本批不放宽它们，也不发明新的用户政策。
- 当前upload先锁父DHR并核资格/元信息，实际读取字节后再校验长度和格式，CREATE_NEW写原件，失败只清理本次不完整文件；成功写盘后注册事务完成回调，rollback清当前原件，UNKNOWN保留原件并记录错误。源码不是完整崩溃/磁盘失败/对账运行证明。
- verify锁父DHR和指定tenant/DHR成员，拒绝解除；读取原字节并校验SHA、再检查格式，之后才写VERIFIED及审计。PENDING/VERIFIED描述核验记录，不从失败异常推导自动清除既有状态或新增作废政策。实际事务/失败结果由主侧与最终独立质量取证。
- 下载继续按当前active或指定冻结版本id+SHA，审批附件先取任务detail再绑定该版本；不能用DHR菜单权替任务办理权。解除保留文件和旧冻结引用，上传/核验不回写旧attachment_snapshot。NONE定稿、版本副本下载和DEC0090受控归档仍为不同能力。
- 当前PNG/JPEG仅获得reader及width/height，不做全像素解码；完整SHA也不等于所有格式全内容解码或病毒扫描。大PNG不能代表大Office/PDF解析内存，实际Spring标准包装磁盘Part也不能认证真实容器multipart解析或生产峰值/并发/SLA。
- AuditEvent当前按原content字符串和LocalDateTime文本生成PrePersist摘要，PreUpdate限制ORM修改；JSONB/时间往返重算的问题已在W5原文登记。审计行、动作、64位摘要存在和事务回滚，不等于回读可重算一致或全部防篡改。本角色仅回源码核边界，不运行新探针、不修算法或历史hash。

初次检查时主侧新测试尚未出现；封存快照时已捕获并只读288行 `DhrAttachmentUploadVerifyObservationPostgresTest` 初版。其27个参数化调用覆盖七小格式、三种大PNG、另一个明确标为合成的generic InputStream轴、四类事务故障、七类核验拒绝、三种状态及两类上传拒绝。实际Spring包装与磁盘Part并未冒称真实容器解析；审计断言仅检查动作/身份和64位摘要存在，没有重算认证。源码阅读不证明编译、运行或后续改动通过；实际新测试、生成文件、数据库日志和独立验收不能由本结果替代。两个广域场景保留整链/权限/冻结ZIP/布局等缺口，W5仍单列，知识成熟度不提高。

完整原文、原始源码及指纹在 `snapshot/`、`source-snapshot-manifest.json`；逐ID证据与范围在 `finite-audit-records.jsonl`。静态结果格式、存在性、知识字节和基线校验记录在 `validation-*.log`，不是89项知识JUnit或业务运行通过声明。
