from pathlib import Path
import subprocess,hashlib,json,yaml,re,datetime

root=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-upload-verify-ontology-20261106')
base='c4e451c264c11978515b2ae0088e64011fe2fcef'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(name,value): (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD')==base
assert git('rev-parse','origin/edhr-dev')==base
contracts=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md']
for path in contracts:assert (root/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=root)
schema=yaml.safe_load((root/'docs/knowledge/schema.yaml').read_text())
assert schema['knowledgeModelVersion']=='0.3.25' and schema['schemaVersion']=='1.2.0'
dp='docs/development/branch-review-20261106-attachment-upload-verify/decision-package.yaml'
package=yaml.safe_load((root/dp).read_text())['decisionPackage']
assert package['knowledgeBaselineVersion']=='0.3.25' and not package['confirmed']['rules'] and not package['unresolved']
for k in ['sourceCommit','targetCommit','contractReadCommit']:assert package['contractBaseline'][k]==base

selected={
 'term.dhr-controlled-attachment':('consistent','定义只核受控文件、来源/核验/关联追溯、冻结引用，不将附件当第四种表单来源；不证明人工内容判断已自动化。'),
 'concept.dhr-controlled-attachment':('consistent','概念与原服务身份/关联/核验分离一致，specified/internal保持，测试与性能取证不新增运行事实。'),
 'relation.dhr-summary-version-contains-controlled-attachments':('consistent','仅核冻结引用关系不被上传/核验覆盖，downloadableFile仍按显式版本id+SHA成员读取；不认证全冻结/导出链。'),
 'DEC-0063-10':('consistent','七格式、52428800含边界及Office原件不转换、解除保留原件规范与当前MAX_BYTES/字节原件/SHA及unlink一致；宏/加密/展开限额属原工程防护，不伪造为用户业务规定。'),
 'DEC-0063-13':('consistent','附件误关联需核验，当前服务按tenant/DHR筛选并保留来源/用途和纸质记录元信息；格式合格不等于内容/对象关联人工核验通过。'),
 'rule.dhr-summary-controlled-attachment-upload':('consistent','当前单文件边界、七格式与Office仅原件上传下载一致；完整SHA不同于完整像素解码或恶意软件扫描，相关能力不外推。'),
 'rule.dhr-review-task-frozen-attachment-download':('consistent','限已读的不受本批改变的任务detail→任务绑定版本→附件id+SHA门禁；未运行完整账号权限矩阵，不由DHR菜单权扩大任务附件权。'),
 'rule.dhr-summary-freeze-version':('consistent','限上传/核验/解除不回写既有attachment_snapshot，明确冻结与下载/归档分离；不由本批源服务取证认证完整提交/放行。'),
 'evidence.dhr-summary-attachment-migration':('consistent','历史0103测试迁移保留原文/64字节MIME时点；当前canonical基线mime_type128、核验枚举和active索引另核，不将旧测试迁移当运行安装图。'),
 'evidence.dhr-summary-attachment-service':('consistent','历史只读证据与其当时25MB片段不覆盖当前代码；当前MAX_BYTES50MiB/七格式/父DHR资格/原件SHA及事务hook已回源码核对，未宣称运行或发布通过。'),
 'evidence.dhr-summary-attachment-archive-tests':('consistent','核的是现存测试源码包含七格式、边界与加密/宏/损坏拒绝及历史原件回读，未运行其业务测试；不能把源码条目当本角色成功验收。'),
 'DEC-0090-01':('consistent','上传/核验的状态及附件原件不是DHR归档；版本冻结、指定版本副本下载与受控归档生命周期不可互换，未实现能力不由测试提升。'),
 'scenario.dhr-summary-attachment-export-and-audit':('evidence-gap','本批拟补七格式小原件/大PNG和部分事务失败，仍无本角色运行证据，且不覆盖完整/部分ZIP/冻结引用/真实HTTP权限双审计/全格式50MiB与生产容器等整体场景。'),
 'scenario.dhr-summary-printable-archive-layout':('evidence-gap','本批上传核验不认证冻结树/切版、总PDF与单表版式、两类附件/目录/中文ZIP、签名审计清单及完整/选定范围全场景。')
}
found={}
def visit(value,path,loc='',inherited_status=None,inherited_visibility=None):
 if isinstance(value,dict):
  status=value.get('status',inherited_status);visibility=value.get('visibility',inherited_visibility)
  if value.get('id') in selected:
   asset_id=value['id'];lines=(root/path).read_text().splitlines();line=next(i+1 for i,l in enumerate(lines) if re.search(r'\bid:\s*'+re.escape(asset_id)+r'\s*$',l))
   found[asset_id]={'record':value,'path':path,'jsonPointer':loc,'line':line,'status':status,'visibility':visibility}
  for k,x in value.items():visit(x,path,loc+'/'+str(k),status,visibility)
 elif isinstance(value,list):
  for i,x in enumerate(value):visit(x,path,loc+'/'+str(i),inherited_status,inherited_visibility)
for p in (root/'docs/knowledge').rglob('*.yaml'):
 if p.name!='schema.yaml':visit(yaml.safe_load(p.read_text()),str(p.relative_to(root)))
assert set(found)==set(selected)

source_paths=[
 *contracts,'codeplzreadme.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
 'docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/evidence/dhr-summary.yaml',
 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml',
 'docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/knowledge/evidence/work-template-write-shape-audit-2026-10-20.md',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrOfficeAttachment.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentAndArchiveTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentWriteFailureTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentTransactionPostgresTest.java',
 'gmp-platform/backend/src/test/resources/db/changelog/0103-dhr-controlled-attachments.sql','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',dp]
new_test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java'
test_exists=(root/new_test).exists()
if test_exists:source_paths.append(new_test)
fingerprints=[]
for path in source_paths:
 b=(root/path).read_bytes()
 if path not in [dp,new_test]:assert b==subprocess.check_output(['git','show',base+':'+path],cwd=root),path
 p=out/'snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 fingerprints.append({'path':path,'bytes':len(b),'sha256':sha(b),'sourceRevision':'working-tree' if path in [dp,new_test] else base})
write('source-snapshot-manifest.json',fingerprints)
knowledge=[]
for path in git('ls-tree','-r','--name-only',base,'--','docs/knowledge').splitlines():
 b=(root/path).read_bytes();old=subprocess.check_output(['git','show',base+':'+path],cwd=root);assert b==old,path
 knowledge.append({'path':path,'bytes':len(b),'sha256':sha(b),'baselineUnchanged':True})
assert len(knowledge)==350
write('knowledge-fingerprint-inventory.json',{'sourceCommit':base,'files':knowledge,'meaning':'350 byte fingerprints only; not 350 semantic completions'})
write('baseline.json',{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev'),'contractReadCommit':base,'uncommittedContractPaths':[],
 'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','roadmapStage':'P0','roadmapStatus':'in-progress','workingTreeStateAtRead':git('status','--porcelain'),'runtimeExecuted':False,'repositoryEditsByRole':False})
write('test-scope-observation.json',{'newNativeTestExistsAtCapture':test_exists,'sourceSnapshot':new_test if test_exists else None,'actualExecutionByRole':False,
 'declaredOnly':['canonical real upload/verify/download services and Spring standard multipart wrapper over owned disk Part','seven-format small fixtures and 1/10/50MiB PNG','SQL/audit refusal and outer rollback','service tenant/DHR/active/status guards'],
 'notCertified':['actual container multipart parser or network HTTP/JWT/RBAC','full pixel decode, every Office/PDF large object, virus scanning','peak/RSS/production concurrency/SLA','full frozen ZIP/layout/lifecycle release/archive','read-back audit hash recomputation and all anti-tamper protections']})

records=[]
impl=[{'path':p,'sourceRevision':base,'sha256':next(f['sha256'] for f in fingerprints if f['path']==p)} for p in source_paths if p.startswith('gmp-platform/backend/src/main/java/')]
for asset_id,(conclusion,scope) in selected.items():
 a=found[asset_id];record_type=a['jsonPointer'].split('/')[1]
 records.append({'id':asset_id,'recordType':record_type,'sourcePath':a['path'],'sourceLocator':{'line':a['line'],'jsonPointer':a['jsonPointer']},'originalMaturity':{'status':a['status'] if a['status'] else 'not-declared/index-only','visibility':a['visibility']},
 'auditScopeClassification':'current-defined-subscope' if not asset_id.startswith('evidence.') else 'supporting-historical-index-subscope','semanticReviewStatus':'reviewed','conclusion':conclusion,
 'reviewedScope':scope,'decisionsActuallyCompared':['DEC-0063-10','DEC-0063-13','DEC-0090-01'],'implementationEvidence':impl,'originalAsset':a['record'],
 'runtimeEvidenceByRole':[],'maturityChanged':False})
records.append({'id':'markdown.dhr-summary-user-confirmed','recordType':'markdown-supporting-evidence','sourcePath':'docs/knowledge/evidence/dhr-summary-user-confirmed.md','sourceLocator':{'lines':'50-67'},'originalMaturity':{'status':'specified (historical source header)','visibility':'internal'},'auditScopeClassification':'supporting-original-confirmation','semanticReviewStatus':'reviewed','conclusion':'consistent','reviewedScope':'50MiB含边界/七格式/Office原件/来源核验及解除保留是用户确认；宏加密/资源阈值为工程inference。历史25MB/并行实现/59知识测试均保留时点，不用作当前未实现或本角色运行通过。','originalReferences':['DEC-0063-10','DEC-0063-13'],'runtimeEvidenceByRole':[],'maturityChanged':False})
records.append({'id':'markdown.retained-w5-audit-hash-gap','recordType':'markdown-supporting-evidence','sourcePath':'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','sourceLocator':{'line':52},'originalMaturity':{'status':'existing W5 evidence gap','visibility':'internal'},'auditScopeClassification':'retained-existing-runtime-gap','semanticReviewStatus':'reviewed','conclusion':'evidence-gap','reviewedScope':'原文已登记PG JSONB/时间往返后审计摘要可能无法重算一致。AuditEvent当前以原字符串及LocalDateTime文本封存，行/64位hash存在不认证回读可重算；未运行本轮探针、不修改旧hash或虚构新政策。','implementationEvidence':[x for x in impl if x['path'].endswith('/AuditEvent.java')],'corroboratingSource':'docs/knowledge/evidence/work-template-write-shape-audit-2026-10-20.md:13','runtimeEvidenceByRole':[],'maturityChanged':False})
assert len(records)==16
(out/'finite-audit-records.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in records))
counts={v:sum(e['conclusion']==v for e in records) for v in ['consistent','evidence-gap']};assert counts=={'consistent':13,'evidence-gap':3}
write('finite-audit-summary.json',{'scope':'16 finite records: 14 existing IDs plus 2 Markdown; declared subscopes only','records':16,'semanticReviewed':16,'conclusions':counts,'knowledgeFiles':350,'runtimeExecutedByRole':False,'newNativeTestExistsAtCapture':test_exists,'uniqueWholeAuditIncrement':'not inferred; overlapping prior finite reviews retained','notClosed':['931 knowledge candidates','86 UI diagnostics','original DHR high/A12/complete runtime matrices','W5 read-back audit digest','W2 remainder/W3-W5 cross-cutting/W6 robustness-performance-extraction-A23 incl prior code/W7 increments','PDF cumulative memory/large parser/UNKNOWN-crash-persistent reconciliation','friend task password-signature and production modal styling pauses']})
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},
 'reason':'This slice currently adds opt-in observation/tests and development evidence only. Existing attachment format/50MiB/original bytes, qualification, verification/frozen references and audit policy are unchanged. Fourteen existing IDs and two Markdown sources were reviewed only in declared subscopes; two complete scenarios and the existing W5 read-back audit digest remain evidence gaps. No ontology policy or maturity change is required.',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[{'id':'validation.upload-verify-result-shape','checkType':'schema','command':'python build_review.py plus strict ontologyResult field/enumeration assertions','outcome':'passed','evidence':['validation-result.log','finite-audit-summary.json']},
 {'id':'validation.upload-verify-definition-source','checkType':'reference','command':'Read original selected knowledge records/user confirmation and current source; validate all selected IDs and source snapshot hashes','outcome':'passed','evidence':['finite-audit-records.jsonl','source-snapshot-manifest.json','test-scope-observation.json']},
 {'id':'validation.upload-verify-baseline','checkType':'evidence-path','command':'actual git source/target/contract equality and 350 baseline knowledge byte fingerprints','outcome':'passed','evidence':['baseline.json','knowledge-fingerprint-inventory.json','validation-baseline.log']}],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(out/'ontologyResult.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
rr=yaml.safe_load((out/'ontologyResult.yaml').read_text())['ontologyResult']
assert set(rr)=={'result','baselineBefore','baselineAfter','contractBaseline','reason','changedArtifacts','knowledgeSync','conflicts','questions','validationEvidence','roadmapProgress'}
assert rr['result']=='not-applicable' and all(v['outcome']=='passed' for v in rr['validationEvidence'])
(out/'validation-result.log').write_text('PASS strict ontologyResult keys, enumerations, 16 finite records, 13 scoped consistent/3 evidence-gap; no runtime or maturity claim.\n')
(out/'validation-reference.log').write_text('PASS 14 existing IDs and 2 actual Markdown sources; all referenced implementation/knowledge snapshot paths exist; macro/encryption/expansion remain engineering inference.\n')
(out/'validation-baseline.log').write_text('PASS source/target/contracts '+base+'; knowledge 0.3.25/schema 1.2.0; 350 current baseline byte fingerprints unchanged; no repository edits by role.\n')
print(json.dumps({'result':rr['result'],'records':len(records),'conclusions':counts,'snapshots':len(fingerprints),'newTestExists':test_exists},ensure_ascii=False))
