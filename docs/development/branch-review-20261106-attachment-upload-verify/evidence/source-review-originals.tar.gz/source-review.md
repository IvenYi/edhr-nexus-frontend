# 附件上传/核验：有限只读源码复核

来源、最新fetch目标和契约读取均为`c4e451c264c11978515b2ae0088e64011fe2fcef`，PR64合入后整树承接a89dbd36。知识保持`0.3.25/schema1.2.0/P0 in-progress`。本子项不是最终qualityResult；未修改仓库或业务/测试/配置，未运行Maven、PG、JFR、浏览器或业务服务。只执行源码/静态字节码读取并在本目录保存原件。27份源码快照及350份知识指纹是字节盘点，不是全库语义完成。

## 当前原始调用和数组语义

`DhrAttachmentController:29–46`上传和核验都要求records.dhr-summary与dhr.summaries.edit；服务还要求可编辑的完成DHR。真实HTTP授权不能由直接服务测试替代。`DhrAttachmentService.upload:108–128`先锁父DHR及核前置元信息/声明尺寸，再getBytes读完整输入、复查实际长度并按扩展名/头部/解析器检查；成功写入相同bytes后用它算SHA256并登记PENDING，LINK审计同事务。verify:175–187先父DHR/附件锁与active，再readAllBytes完整当前原件，用同一byte[]同时算登记SHA与检查格式，成功才更新核验人与时间并写VERIFY。

目前保留byte[]是现行格式检查API的结构结果：PDF Loader、Office inspect及图像输入都消费同一份bytes。不能凭此推断开发者当年的考虑，也不能说摘要实现天然需要整数组；下载/提交消费者已有8192B流式SHA，但上传和核验还需另外解析。只替换readAllBytes而保留第二次按路径打开解析，会改变原先摘要与格式检查引用同一内存视图的性质。

已静态核对真实Spring 6.1.8字节码：StandardMultipartFile.getBytes调用FileCopyUtils.copyToByteArray(Part.getInputStream())，后者调用输入流自身的readAllBytes并关闭输入。复制行为因此取决于输入流实现。当前JDK21的ChannelInputStream override readAllBytes，对正常可seek、长度已知且读取期间不变的文件可按size一次分配；不能预设磁盘Part一定两倍拷贝。普通仅转发read的InputStream可走基类分块累计与最终拼接，是另一明确输入实现轴；这种合成包装不能冒称真实容器Part实现。四份javap原文与依赖jar指纹已保留。

application.yml:13–14的通用multipart上限为150MB/160MB；DHR服务与既有rule.dhr-summary-controlled-attachment-upload独立规定50*1024*1024=52428800含边界。不要通过修改全局限额来让此处测量变绿，也不要将服务测试推为容器解析/网关容量认证。

## 事务与资源所有权

1. checked IOException默认不令Spring事务回滚，但当前upload在getBytes或文件写/close失败之前只执行父DHR SELECT锁，无业务登记写入；写/close IOException由局部catch删除本次新片段，原异常保留，删除失败作为suppressed并记录id/path。现有公开调用方是控制器；没有据此确认新的正常入口原子性缺陷，不添加rollbackFor或catch Throwable假设防御。
2. CREATE_NEW开流在catch外，发生碰撞时不会进入删除路径，因此既有文件/目录安全；现有写失败测试实际注入部分写/close/删除失败，并检查不误删无关或碰撞文件。只读本子项没有重跑它们，不将模拟故障称为真实磁盘满。
3. 文件完整关闭后、SHA/登记/审计之前注册afterCompletion。SQL或审计Runtime失败、已flush但外层最终回滚，都能以最终ROLLED_BACK清理本次新原件；成功COMMITTED保留。不能提前在内层方法返回时删文件。父侧新canonical实际失败用例须核row/audit/file三方，而不只看抛异常。
4. UNKNOWN保留并记录定位，避免真实已提交却删除原件；既有测试是实际数据库提交后注入确认异常，不是真实网络失联或崩溃。失败删除只留日志，不代表持久对账/幂等补偿已完成。不得据此自动扫描或删除历史/未知所有权文件。
5. verify写核验状态在完整摘要和格式检查之后，审计失败应连同状态回滚；失败保持原核验记录不等于证明当前磁盘健康。对已有VERIFIED文件的后续篡改，当前其他完整SHA消费者仍需独立阻断，不能为状态展示擅改为失败即回写PENDING等新政策。

## 格式、容量及同一视图边界

PDF分支检查Loader可解析、未加密、至少一页，不执行页面渲染。PNG/JPEG分支只选ImageReader并读取宽高和100,000,000像素尺寸上限，没有解码全部像素/全部图像压缩数据。完整SHA读取所有字节不等于已解码整张图；先作为验收范围限制，不凭方法名或当前小样本声称所有内容均完整可视，也不直接新增大图全解码导致另一内存问题。

Office OLE分支检查目录内加密/VBA、HWPF加密标志、XLS的FilePass和Excel4宏/VB模块，再用HWPF/HSSF解析；OOXML先核完整中央目录、重复/最多10,000项、全部解压累计不超过100MiB、CRC/大小和索引集合一致，再核内容类型和宏/VBA并用XWPF/XSSF解析。此处多层校验各有不同目的，不能为降低分配删除宏、加密、索引或展开限制。OPC/POI模型仍可能有较大的结构/字符串/单元格开销；压缩体积和100MiB展开限制不能直接承诺Java堆峰值，PNG资源结果不代表大Office/PDF。

当前核验数组让摘要与格式检查消费同一份复制视图。若后续讨论文件/流式解析，建议先明确对输入字节有唯一、受控所有权的稳定视图，再让摘要和解析器消费它；不能简单先流式SHA后重新打开可变路径。可按格式采用有界流或file-backed/seekable解析入口，但必须保留格式、宏/加密、CRC/完整索引、展开及大小检查，并验证文件变化/失败关闭/临时副本清理与冻结语义。这里是工程方案，不是本次授权的产品实现或新业务政策。

## A23及具体抽取候选

- 声明size与实际bytes.length分别保护输入元数据及实际结果，不是可机械删去的双重校验；父DHR、附件所属/active、完整SHA、可解析格式也不能相互替代。
- try/catch与afterCompletion覆盖不同阶段：新文件局部写失败、SQL/审计/外层事务失败；CREATE_NEW碰撞保护必须保留。UNKNOWN不删、删除失败日志/原异常保持是正确所有权边界，不补通用清理框架。
- 最小拆分可在原服务内提取readAndValidateUploadBytes（所有创建永久文件前的检查）、storeNewOriginal（CREATE_NEW/关闭/本次片段清理）及registerRollbackCleanup；仍由原@Transactional upload拥有流程顺序和登记/审计。只有确有资源收益时再拆format-specific inspectReadable来源，避免一次性建通用文件处理框架。
- verify可提取validateRegisteredOriginal，同一稳定视图内完成完整SHA与格式检查，原方法继续持有固定父DHR→附件锁、更新与审计；不能为提取把读取资格或失败优先级移走。PR64的提交内部上下文与其他下载/导出入口保持，本子项不重开其已验收范围。

## AuditEvent摘要：既有问题去重

补充只读核对已确认是既有`W5-AUDIT-HASH-001`（medium/open），并非本轮新增：当前ledger保留a828两条原生PG失败证据及摘要往返缺口。AuditEvent:58–110在PrePersist按原contentBefore/After字符串和LocalDateTime.toString封存；schema为jsonb和timestamp，持久化往返可能规范化。单元AuditEventTest只检查同一内存对象反复seal及禁止JPA更新，不证明PG回读可重算。

当前生产中computeSnapshotHash仅实体内部seal调用；AuditController输出现存hash，DhrArchiveService:auditsFor/sourceAuditEvents带出hash但不重算。它们与Signature原始载荷摘要、DHR版本/单源hash、附件SHA是不同对象，不得混淆。因此本轮审计行存在/事务一致或64位字符串只能证明封存字段已写，不是完整防篡改或回读重算认证。原open保持；不更换算法、补造原文或改历史hash。相关原ledger记录及两份历史探针/源码映射按原字节保留，历史证据未由本子项重新执行。

## 结论与残余范围

未确认新的正常上传/核验入口正确性缺陷；数组/解析器资源是待主侧真实测量后讨论的性能候选，不把源码推导当实测。小七格式和大PNG仍不能覆盖所有大格式、真实容器/HTTP/RBAC、冷/热并发/SLA、崩溃/UNKNOWN/清理失败持久对账。原931知识候选、86 UI、W2余项/W3-W5交叉/W6健壮性/性能/抽取/A23含旧已审/W7增量、原DHR high/A12/PDF累计及全部用户暂停保持；不计整文件完成、历史unique或全仓语义一致。
