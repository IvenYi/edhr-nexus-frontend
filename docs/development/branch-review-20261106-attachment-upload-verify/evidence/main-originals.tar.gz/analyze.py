from pathlib import Path
import json,hashlib,re,collections,subprocess,gzip,xml.etree.ElementTree as ET,shutil,datetime
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-upload-verify-20261106');out=r/'docs/development/branch-review-20261106-attachment-upload-verify';base='c4e451c264c11978515b2ae0088e64011fe2fcef'
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def norm(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
events=[]
for p in sorted((raw/'native-full/observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==52
parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(raw/'native-full/postgres.log').read_text(),flags=re.M)
server=collections.defaultdict(collections.Counter);alltagged=collections.defaultdict(collections.Counter);errors=[]
for part in parts:
 m=re.search(r'edhr_dhr_attachment_write_test_full (audit_write_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if m:
  shape=norm(m.group(2).strip());alltagged[m.group(1)][shape]+=1
  if shape.startswith('select'):server[m.group(1)][shape]+=1
 error=re.search(r'edhr_dhr_attachment_write_test_full (audit_write_\w+) ERROR:  (.*)',part)
 if error:errors.append({'applicationName':error.group(1),'error':error.group(2)})
matched=[];types=collections.Counter();driver=[]
for e in events:
 observed=collections.Counter(norm(s) for s in e['jdbcQuerySql']+e['hibernateAttemptSql'] if norm(s).startswith('select'));actual=server[e['applicationName']].copy()
 for sql,n in (actual-observed).items():
  assert 'pg_catalog.pg_type' in sql,(e['name'],sql)
  driver.append({'event':e['name'],'sql':sql,'count':n});actual[sql]-=n
 assert observed==+actual,(e['name'],observed-actual,actual-observed)
 matched.append({'name':e['name'],'selectStatements':e['selectStatements'],'shapesMatch':True,'selectShapes':[{'sql':s,'count':n} for s,n in actual.items() if n]})
 for s,n in alltagged[e['applicationName']].items():types[s.split()[0]]+=n
assert len(errors)==3 and all('native_' in e['error'] for e in errors)
write('server-sql-review.json',{'events':matched,'businessSELECT':sum(e['selectStatements'] for e in events),'taggedSuccessfulStatementTypes':dict(types),'driverMetadataSelect':driver,'expectedConstraintErrors':errors,'hibernateNonSelectAttempts':sum(1 for e in events for s in e['hibernateAttemptSql'] if not norm(s).startswith('select')),'scope':'successful execute inside per-action tags; parse/bind/SET/transaction and setup/assertions/control outside tags separate','writeSemantics':'48 successful write executions include 4 subsequently rolled back (upload audit refusal1,verify audit refusal1,outer rollback2); failed INSERT3 separate. Successful execute is not commit.'})
small=[{k:v for k,v in e.items() if k not in ['jdbcQuerySql','hibernateAttemptSql','failureStack']} for e in events]
write('performance-report.json',{'baseCommit':base,'events':small,'source':'native-full raw JSON/JFR/PG/source snapshots','proposal':'PNG/JPEG verification temporary snapshot with small buffers proposed, awaiting actual user reply; no product changes','measurementLimits':['real Spring StandardMultipartHttpServletRequest with disk Part fixture; not container multipart parsing/network/JWT/HTTP/RBAC','ChannelInputStream override readAllBytes and synthetic generic InputStream measured separately, not a universal copy factor','ThreadMXBean calling-thread cumulative allocated bytes, not retained heap/peak/RSS/production concurrency or SLA','JFR logical read/write bytes only owned fixture/store paths and current Java thread, not physical IO or all ImageIO temporary IO','seven small valid formats + large padded PNG; no full pixel decoding/large PDF/Office resource claim','verify metadata seeded for negative cases; state guards not full lifecycle/START proof','SQL failures are added named check constraints in isolated DB; not real disk full/network/crash','audit hash presence/identity/action/atomicity only; old W5-AUDIT-HASH-001 PG hash roundtrip stays open']})
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):shutil.copy2(p,raw/'knowledge'/p.name)
knowledge=[]
for p in (raw/'knowledge').glob('TEST-*.xml'):
 a=ET.parse(p).getroot().attrib;knowledge.append({'class':a['name'],**{k:int(a[k]) for k in ['tests','failures','errors','skipped']}})
write('main-validation.json',{'regression':json.loads((raw/'native-full/test-summary.json').read_text()),'focused':json.loads((raw/'native-focused/test-summary.json').read_text()),'knowledge':knowledge,'observations':len(events),'businessSELECT':sum(e['selectStatements'] for e in events),'serverTypes':dict(types),'constraintErrors':len(errors),'noProductEdits':True,'scope':'27 actual native plus 54 adjacent tests =81, not all81 PG or all-system coverage'})
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines()
with gzip.open(out/'baseline-tracked-paths.txt.gz','wb') as f:f.write(('\n'.join(paths)+'\n').encode())
write('inventory-summary.json',{'baseCommit':base,'trackedPaths':len(paths),'knowledgePaths':sum(p.startswith('docs/knowledge/') for p in paths),'wholeFileCompletionThisBatch':0,'historicalUniqueCoverage':'unknown; not inferred from finite method/knowledge records','meaning':'baseline inventory only, no automatic semantic completion','pending':['W2 remainder/W3-W5 cross-cutting/W6 robustness performance concrete extraction A23 incl reviewed code/W7 increments','931 knowledge/86 UI/original DHR high/A12/full matrices/history/text-ID index/PDF/large parser/UNKNOWN durable reconciliation','friend generic task password/signature and production modal styling remain paused']})
protected=[]
for path in paths:
 if not(path.startswith('docs/knowledge/') or path.startswith('gmp-platform/backend/src/main/') or path.startswith('gmp-platform/frontend/') or path in ['AGENTS.md','codeplzreadme.md'] or path.startswith('docs/agents/')):continue
 p=r/path
 if not p.is_file():continue
 old=subprocess.check_output(['git','show',base+':'+path],cwd=r);assert old==p.read_bytes(),path
 protected.append({'path':path,'sha256':hashlib.sha256(old).hexdigest(),'unchanged':True})
write('protected-source-manifest.json',{'baseCommit':base,'files':protected,'allUnchanged':True})
ledger='docs/development/branch-review-20261026-capacity-audit/ledger/findings.json';issues=json.loads((r/ledger).read_text());old=next(x for x in issues if x['id']=='W5-AUDIT-HASH-001')
write('existing-issue-dedup.json',{'sourcePath':ledger,'sourceCommit':base,'sourceSha256':hashlib.sha256((r/ledger).read_bytes()).hexdigest(),'existingRecord':old,'disposition':'retain preexisting-medium-open; no new finding count/no hash or historical-data changes','runtimeThisBatch':'presence/shape and transaction only, no new replay/recompute claim'})
print(json.dumps({'events':len(events),'businessSELECT':sum(e['selectStatements'] for e in events),'successfulServerTypes':dict(types),'expectedConstraintErrors':len(errors),'baselinePaths':len(paths),'protectedFiles':len(protected)},indent=2))
