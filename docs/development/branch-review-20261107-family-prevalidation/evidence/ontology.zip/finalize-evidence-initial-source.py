from pathlib import Path
import argparse,subprocess,json,hashlib,datetime,yaml,xml.etree.ElementTree as ET
ROOT=Path('/workspace/edhr-nexus-frontend');OUT=Path('/tmp/edhr-family-prevalidation-ontology-20261107')
BASE='5e8edb47ae91af83555f4b67a87598c3c2a9a664'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT).strip()
ap=argparse.ArgumentParser();ap.add_argument('--source-commit',required=True);ap.add_argument('--product-evidence',required=True);args=ap.parse_args()
head=args.source_commit;raw=Path(args.product_evidence);assert len(head)==40
subprocess.run(['git','merge-base','--is-ancestor',BASE,head],cwd=ROOT,check=True)
subprocess.run(['git','fetch','origin','edhr-dev'],cwd=ROOT,check=True)
assert git('rev-parse','origin/edhr-dev').decode()==BASE,'Target changed; parent must re-evaluate actual increment'
assert git('diff',BASE,head,'--','AGENTS.md','codeplzreadme.md','docs/agents')==b''
before=json.loads((OUT/'knowledge-before.json').read_text());rows=[]
for r in before['files']:
    b=git('show',head+':'+r['path']);assert sha(b)==r['sha256'],r['path'];assert (ROOT/r['path']).read_bytes()==b,r['path']
    rows.append({'path':r['path'],'bytes':len(b),'sha256':sha(b),'gitBlob':git('rev-parse',head+':'+r['path']).decode()})
assert git('ls-tree','-r','--name-only',head,'docs/knowledge').decode().splitlines()==[r['path'] for r in rows]
after={'sourceCommit':head,'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'count':len(rows),'allUnchangedFromBase':True,'sha256sumDigest':sha(''.join(r['sha256']+'  '+r['path']+'\n' for r in rows).encode()),'files':rows}
assert after['count']==350 and after['sha256sumDigest']==before['sha256sumDigest']
(OUT/'knowledge-after.json').write_text(json.dumps(after,indent=2)+'\n')
run=json.loads((raw/'run.json').read_text());summary=json.loads((raw/'test-summary.json').read_text());totals=summary['totals']
assert run['exitCode']==0 and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0
assert not summary.get('missingFreshReports',[])
product_inputs=run.get('sourceFingerprints',[]);assert product_inputs
for r in product_inputs:
    b=git('show',head+':'+r['path']);assert sha(b)==r['sha256'],r['path']
    assert (ROOT/r['path']).read_bytes()==b,r['path']
    p=OUT/'final-source'/r['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
check=dict(tests=0,failures=0,errors=0,skipped=0)
for p in raw.glob('TEST-*.xml'):
    a=ET.parse(p).getroot().attrib
    for k in check:check[k]+=int(a.get(k,0))
assert check==totals,(check,totals)
knowledge=json.loads((OUT/'knowledge-result.json').read_text());assert knowledge['tests']==dict(tests=89,failures=0,errors=0,skipped=0)
neg=raw.parent/'negative/test-summary.json'
negative=json.loads(neg.read_text()) if neg.is_file() else None
negative_failures=[]
if negative:
    for p in neg.parent.glob('TEST-*.xml'):
        for case in ET.parse(p).getroot().findall('testcase'):
            for f in case.findall('failure'):
                negative_failures.append({'case':case.attrib['name'],'type':f.attrib.get('type'),'message':f.attrib.get('message','')[:280]})
    assert len(negative_failures)==negative['totals']['failures']
    assert all('bulkAddPreservesAllSelectedProductsWithReducedPrevalidationReads' in r['case'] for r in negative_failures)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'
service='gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (neg.parent/'source'/test).read_bytes()==git('show',head+':'+test)
assert (neg.parent/'source'/service).read_bytes()==git('show',BASE+':'+service)
dp='docs/development/branch-review-20261107-family-prevalidation/decision-package.yaml'
initial_dp=next(r for r in json.loads((OUT/'source-inputs.json').read_text()) if r['path']==dp)
current_dp_sha=sha(git('show',head+':'+dp))
dp_binding={'initialReadSha256':initial_dp['sha256'],'finalReadSha256':current_dp_sha,'change':'Permission impact wording now explicitly states batch-add has no confirmed; transfer confirmation retained. This clarifies existing source, no new policy.' if initial_dp['sha256']!=current_dp_sha else 'unchanged'}
observations=[]
for p in (raw/'observations').glob('bulk-*.json'):
    o=json.loads(p.read_text());observations.append({'file':p.name,'selectCalls':o.get('selectCalls'),'scope':'parent actual observation; not executed by ontology role'})
snapshots=[]
for p in [raw/'run.json',raw/'test-summary.json']:
    b=p.read_bytes();(OUT/('parent-'+p.name)).write_bytes(b);snapshots.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})
binding={'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'contractIncrement':'none','workingTreeState':git('status','--porcelain').decode(),'knowledgeFileCount':350,'knowledgeAllUnchanged':True,'knowledgeBeforeDigest':before['sha256sumDigest'],'knowledgeAfterDigest':after['sha256sumDigest'],'parentProductRun':{'directory':str(raw),'runHead':run['head'],'totals':totals,'sourceInputs':product_inputs,'reportsRecounted':check,'snapshots':snapshots,'runtimePerformedByOntologyRole':False},'parentNegativeSummaryInspected':negative,'parentBulkObservationsInspected':observations,'knowledgeRuntimeActuallyPerformedByThisRole':knowledge,'children':[],'wholeFileCompleted':0,'historicalUnique':None}
binding.update(parentNegativePerformanceFailures=negative_failures,nativeTestOldNewSameBytes=True,negativeServiceMatchesBase=True,decisionPackageReadIncrement=dp_binding)
if (raw/'index-analysis.json').is_file():
    idx=json.loads((raw/'index-analysis.json').read_text());binding['parentIndexProbe']={'scope':idx['scope'],'plans':[{'table':p['table'],'selected':p['selected'],'parameters':p['parameters'],'nodeType':p['plan'][0]['Plan']['Node Type'],'indexName':p['plan'][0]['Plan'].get('Index Name'),'actualRows':p['plan'][0]['Plan'].get('Actual Rows')} for p in idx['plans']],'runtimePerformedByOntologyRole':False}
    (OUT/'parent-index-analysis.json').write_bytes((raw/'index-analysis.json').read_bytes())
(OUT/'source-binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
records=json.loads((OUT/'finite-review-records.json').read_text());records['status']='FINAL';records['sourceCommit']=head;records['sourceBinding']='source-binding.json';(OUT/'finite-review-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
q=[]
for i,scope,disp in [
 ('DEC-0002-01','保持半成品/产成品资格；仅批读形状变化，不新增状态资格。','retained'),
 ('DEC-0002-02','保持一个产品最多一簇与原即时唯一约束/写前复核。','retained'),
 ('rule.product-family.membership-cardinality','原单一归属规范不变，不新增或假定通用规则求值。','retained'),
 ('fact.catalog.product-productfamilycount','integer与规范保持；精确provider/sourceLocator作为已有P1粗定位evidence-gap保留，本批不造count API或抬成熟度。','deferred')]:
    p=next(r['sourcePath'] for r in records['records'] if r['id']==i);q.append({'id':i,'disposition':disp,'scope':scope,'sourceReferences':[p,'finite-review-records.json']})
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[]},'reason':'仅工程有界预校验读取，保留业务资格/基数/顺序/即时复核/事务审计/快照及成熟度；无新业务语义或来源纠错，350知识文件与基线全同。用户授权不构成新的业务政策或自动merge许可。','changedArtifacts':[],'knowledgeSync':q,'conflicts':[],'questions':[],'validationEvidence':[{'id':'validation.family-prevalidation.knowledge89','checkType':'schema','command':' '.join(knowledge['command']),'outcome':'passed','evidence':['knowledge-result.json','knowledge89.log','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','实际89项0failure/error/skipped；不是产品运行验收。']},{'id':'validation.family-prevalidation.finite-meaning','checkType':'reference','command':'python3 build-evidence.py','outcome':'passed','evidence':['finite-review-records.json','28项有限重核=27范围一致+1已有P1精确来源evidence-gap；该gap不计完整一致，不改原成熟度。']},{'id':'validation.family-prevalidation.final-source','checkType':'evidence-path','command':'python3 finalize-evidence.py --source-commit '+head+' --product-evidence '+str(raw),'outcome':'passed','evidence':['source-binding.json','knowledge-before.json','knowledge-after.json','350文件逐字相同，产品源与主侧绿run输入逐指纹绑定；本体角色只读取，不代跑产品。']}],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
prepared=(OUT/'REVIEW.PREPARED.md').read_text()
report=prepared.replace('（待最终源绑定）','').replace('当前仅预备结果，尚未作最终产品源/原件绑定，不提前声明全部门禁通过。',f'当前状态FINAL；已一次只读绑定最终来源 `{head}` 及主侧实际产品原件。').replace('准备正式 `ontologyResult: not-applicable`','正式 `ontologyResult: not-applicable`').replace('主侧负责同测试字节旧新PG SQL','已读取主侧同测试字节旧新PG SQL').replace('暂不将预计602→404写成实测。','已从主侧原件读取100样本602→404；全部观察见本报告末尾与source-binding.json，本角色未执行产品。')
start='待主侧给最终cleanSHA和绿原件目录后，做一次只读源绑定及350知识字节再核，生成正式ontology-result.yaml/REVIEW.md/source-binding.json/manifest.json并FINAL。'
report=report.replace(start,f'最终已核来源 `{head}`、目标仍 `{BASE}`，契约无增量、350知识字节全同，主侧绿运行实际{totals["tests"]}项、0失败/错误/跳过，逐XML重计一致；knowledge89为本角色自己实际运行。')
report+='\n\n最终正式产物：ontology-result.yaml（not-applicable）、finite-review-records.json（28有限项、27一致/1gap）、source-binding.json、知识350前后清单与知识89原件。无repo改动，无孩子；最终独立产品质量由主侧另派未参与修复实例完成，本结果不能替代qualityResult。\n'
report+='\n主侧批量观察（仅读取原件，不冒称本角色运行）：'+json.dumps(observations,ensure_ascii=False)+'。\n'
report+='\n原负控23=19通过/4项查询预算真实性能断言失败/0错误或跳过；这四项不是新的正常路径正确性bug。原native测试与最终同字节，负控Service同5e8；最终主侧166包含新native23及原相邻143（旧仓储6为H2，不混称全PG）。DP最终已明确batch-add无confirmed，仅转移原确认保持；初次来源和最终读取均保留，不覆盖初次快照。\n'
report+='\n主侧单独50k合成fixture prepared SELECT计划：material100/512用PK、member100用既有tenant/product唯一索引，member512与小类型表512选择Seq Scan；不宣称全部走索引、不把物理扫描等同应用全租户加载，也不据本地样本加索引。threadAllocatedBytes只为调用线程累计分配，不是峰值或生产SLA。\n'
(OUT/'REVIEW.md').write_text(report)
(OUT/'result.json').write_text(json.dumps({'status':'FINAL','result':'not-applicable','sourceCommit':head,'targetCommit':BASE,'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','counts':records['counts'],'knowledgeActualTests':knowledge['tests'],'parentProductTestsInspected':totals,'knowledgeModified':False,'repoModified':False,'children':[]},ensure_ascii=False,indent=2)+'\n')
manifest={'status':'FINAL','sourceCommit':head,'targetCommit':BASE,'contractReadCommit':BASE,'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceInputs':json.loads((OUT/'source-inputs.json').read_text()),'knowledgeFiles':350,'wholeFileCompleted':0,'historicalUnique':None,'artifacts':[],'note':'Finite source review and knowledge runtime89 only; parent product evidence is read and bound, not run by ontology role. All knowledge bytes unchanged.'}
for p in sorted(OUT.rglob('*')):
    assert not p.is_symlink(),str(p)
    if not p.is_file() or p.name=='manifest.json':continue
    b=p.read_bytes();manifest['artifacts'].append({'path':str(p.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'FINAL','ontologyResult':'not-applicable','sourceCommit':head,'parentProductTests':totals,'knowledgeActualTests':knowledge['tests'],'artifactCount':len(manifest['artifacts'])},ensure_ascii=False))
