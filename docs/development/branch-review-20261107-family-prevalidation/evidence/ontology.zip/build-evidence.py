from pathlib import Path
import subprocess,json,hashlib,datetime,yaml,zipfile
ROOT=Path('/workspace/edhr-nexus-frontend');OUT=Path('/tmp/edhr-family-prevalidation-ontology-20261107')
BASE='5e8edb47ae91af83555f4b67a87598c3c2a9a664'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):
    b=subprocess.check_output(['git',*args],cwd=ROOT)
    return b if args[0]=='show' else b.strip()
def record_type(i):
    return {'DEC':'decisionStatement','term':'term','concept':'concept','relation':'relation','rule':'rule','fact':'fact','scenario':'acceptanceScenario'}.get(i.split('-')[0] if i.startswith('DEC-') else i.split('.')[0],'record')
with zipfile.ZipFile(ROOT/'docs/development/branch-review-20261107-family-transfer/evidence/ontology.zip') as z:
    old=json.loads(z.read('finite-review-records.json'))
    navigation_ids=[r['id'] for r in old['records']]
# Prior report supplies navigation IDs only; definitions and conclusions below are read/reasoned against fixed current source.
index={}; paths=git('ls-tree','-r','--name-only',BASE,'docs/knowledge').decode().splitlines()
def walk(v,p):
    if isinstance(v,dict):
        if isinstance(v.get('id'),str):
            index.setdefault(v['id'],[]).append((p,v))
        for x in v.values():walk(x,p)
    elif isinstance(v,list):
        for x in v:walk(x,p)
for p in paths:
    if p.endswith(('.yaml','.yml')):walk(yaml.safe_load(git('show',BASE+':'+p).decode()),p)
direct={
 'DEC-0002-01','DEC-0002-02','term.product-family','concept.product-family',
 'relation.product-belongs-to-product-family','relation.product-family-contains-products',
 'rule.product.source-from-material','rule.product-family.membership-cardinality',
 'rule.product-family.member-audit-customer-labels','fact.catalog.material-typename',
 'fact.catalog.product-productfamilycount','scenario.product-family-membership'}
assert len(direct)==12 and len(navigation_ids)==28
notes={
 'DEC-0002-01':'半成品/产成品作为成员资格，按物料类型名称判定；本次仅改变读取形状，不新增状态或其他资格。',
 'DEC-0002-02':'每产品最多一簇合理且继续由tenant/product即时唯一索引及原即时写前复核守住；不弱化约束。',
 'term.product-family':'集合定义与当前成员归属模型一致；512仅工程批次，不是定义中的产品上限。',
 'concept.product-family':'概念与成员关系实体不变；此次不复制主数据或增加新业务概念。',
 'relation.product-belongs-to-product-family':'source product到family的0..1基数保持；批读不允许一个产品多簇。',
 'relation.product-family-contains-products':'source family到products的0..many基数保持；全部选择完整处理，不限制100或512。',
 'rule.product.source-from-material':'物料typeName为产成品/半成品的既有来源规则合理；按ID批读后按原顺序核资格，不改来源身份。',
 'rule.product-family.membership-cardinality':'规则规范的>=2阻断保留，实际持久化唯一索引保护不改；不据规则文字新增通用求值器。',
 'rule.product-family.member-audit-customer-labels':'保留原memberProductId/Code/Name服务端审计键及UI中文投影；本次不改UI标签或原审计内容。',
 'fact.catalog.material-typename':'保持string/in；原ProductProcessController的materialTypeNames/isProductMaterial可定位来源，成员Service资格也按真实类型名；不注册新运行事实提供器。',
 'fact.catalog.product-productfamilycount':'integer及>=2基数规范保持；成员仓储/唯一索引有0或1归属来源依据，但原sourceLocator仅product.productFamilyCount语义路径，ProductProcessResolutionService没有该命名计数求值接口。精确provider/符号locator仍属已有P1粗定位证据缺口，本批不伪造countAPI、不改类型/availability/成熟度，亦不把此项计为完整实现一致。',
 'scenario.product-family-membership':'多产品同簇可添加，已有另一簇需拒绝/走转移；空/重复/同簇及首错边界从原Service作为行为契约保留，不新增政策。',
 'DEC-0002-11':'转移原事务/confirmed/不收原因/三方审计不受批量添加读取影响；batch-add本身无confirmed参数，不新增确认。',
 'rule.product-family.member-transfer-audit':'保持现有转移二次确认语义标签、原三方审计，PR73 flush仍在原事务；本次不替代该规则。',
 'fact.catalog.productfamilytransfer-confirmation':'PR73已纠正到Controller实际confirmed/requireConfirmed；string语义标签second-confirmation保持，不新增字段或通用provider。',
 'fact.catalog.productfamilytransfer-reason':'PR73已纠正到实际Controller无reason输入；is-null描述原缺省语义，不新增原因输入。',
 'scenario.product-family-transfer':'转移按PR73真实flush和新关系ID/三方审计保持；该相邻场景不因批读重新定义。',
 'DEC-0002-06':'当前产品有可用制程优先，只返回产品版本；成员添加读取不改解析优先级。',
 'DEC-0002-07':'产品无可用制程时簇兜底及原提示保持；不自动选新版本。',
 'DEC-0002-10':'现行未开工引用在首次START按当前归属/时间/形态重核后冻结，已开工不改；本次不恢复旧创建时冻结政策。',
 'DEC-0007-03':'按当前生产上下文/产品簇实时匹配后续工序，查询不创建，已过站不补做；本次不触动。',
 'DEC-0007-04':'已有作业实例（包括零业务节点）保原快照及归属；批读不删除/重置既有实例。',
 'rule.product-family.member-transfer-future-only':'产品簇改变对未开工制程重核与后续作业实时匹配分别解释，不简化成所有历史冻结或全部后续候选冻结。',
 'rule.product-process.product-version-takes-precedence':'与DEC-0002-06一致，保持产品优先；本次不调整制程消费链。',
 'rule.product-process.product-family-fallback':'与DEC-0002-07一致，保持当前簇兜底；本次不调整制程消费链。',
 'rule.production.process-resolution-product-then-family':'现行产品优先/当前簇兜底规范保持，specified/internal不因局部批读验收提升。',
 'rule.production-work.instance-auto-matches-applicability':'保持现行运行匹配及实例创建职责，不由批量成员预校验引入作业手工绑定或新触发。',
 'rule.production-work.instance-freezes-work-and-rule-snapshot':'保持实际创建时冻结作业模板/发布流程/规则/匹配事实；本批不证明完整规则求值/异常证据包。'
}
assert set(notes)==set(navigation_ids)
source_paths=set()
records=[]
for i in navigation_ids:
    matches=index[i];assert len(matches)==1,(i,len(matches));p,r=matches[0];source_paths.add(p)
    text=git('show',BASE+':'+p).decode();line=next(j for j,l in enumerate(text.splitlines(),1) if 'id: '+i in l and l.strip().split('id: ',1)[1].strip('"\'')==i)
    gap=i=='fact.catalog.product-productfamilycount'
    records.append({'id':i,'recordType':record_type(i),'sourcePath':p,'sourceLocator':f'line:{line}','originalMaturity':{k:r[k] for k in ['status','visibility','availability'] if k in r},'scopeClass':'direct' if i in direct else 'adjacent','semanticReview':'reviewed','conclusion':'evidence-gap' if gap else 'consistent','conclusionScope':'Finite preservation/engineering-boundary review, not complete execution verification','rationale':notes[i],'originalRecord':r,'recordSha256':sha(json.dumps(r,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()),'originalEvidenceReferences':[p,'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql'],'runtimeVerifiedByThisRole':False})
data={'status':'PREPARED-awaiting-final-source-binding','fixedBaseline':BASE,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','counts':{'direct':12,'adjacent':16,'reviewedRecords':28,'consistentWithinFiniteScope':27,'evidenceGap':1,'knowledgeModified':0,'wholeFileCompleted':0,'historicalUnique':None},'notFullAuditCoverage':True,'priorBatchUse':'navigation only; current source/meaning rechecked; records do not add unique global coverage','records':records,'existingGapReference':'discrepancy.ontology-p0-coarse-fact-locators: current open medium P1 symbol-level locator gap; not a new policy or a newly confirmed product defect'}
(OUT/'finite-review-records.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
core=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductProcessResolutionService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProductProcessController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/repository/ProductFamilyMemberRepository.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']
core += ['docs/knowledge/decisions/DEC-0038-ontology-p0-foundation.yaml']
inputs=[]
for p in sorted(source_paths|set(core)):
    b=git('show',BASE+':'+p);dst=OUT/'source'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
    inputs.append({'path':p,'sourceCommit':BASE,'bytes':len(b),'sha256':sha(b),'gitBlob':git('rev-parse',BASE+':'+p).decode(),'coverage':'finite scope; fingerprint does not imply whole-file semantic review'})
dp='docs/development/branch-review-20261107-family-prevalidation/decision-package.yaml';b=(ROOT/dp).read_bytes();dst=OUT/'source'/dp;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
dp_commit=git('rev-parse','HEAD').decode();assert git('show',dp_commit+':'+dp)==b
inputs.append({'path':dp,'sourceCommit':dp_commit,'gitBlob':git('rev-parse',dp_commit+':'+dp).decode(),'bytes':len(b),'sha256':sha(b),'coverage':'final actual parent decision package read; initial pre-correction tool snapshot preserved separately'})
(OUT/'source-inputs.json').write_text(json.dumps(inputs,indent=2)+'\n')
print(json.dumps({'counts':data['counts'],'sourceInputFiles':len(inputs),'knowledgeModified':False}))
