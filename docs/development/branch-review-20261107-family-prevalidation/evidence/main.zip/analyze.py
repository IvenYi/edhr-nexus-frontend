from pathlib import Path
import json,re,hashlib,subprocess,collections,decimal,datetime,xml.etree.ElementTree as ET
ROOT=Path('/workspace/edhr-nexus-frontend');RAW=Path('/tmp/edhr-family-prevalidation-20261107')
BASE='5e8edb47ae91af83555f4b67a87598c3c2a9a664';HEAD='4ee3efba39c5ff44972561ae25956c33a0c14357'
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(v):
    if isinstance(v,dict):return '{'+','.join(json.dumps(k,ensure_ascii=False)+':'+canonical(v[k]) for k in sorted(v))+'}'
    if isinstance(v,list):return '['+','.join(canonical(x) for x in v)+']'
    if v is None or isinstance(v,(str,bool)):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
    return str(decimal.Decimal(str(v)).normalize())
def audit_hash(a):
    vals=['audit-event-v2',str(a['id'])]+[a[k] for k in ['tenant_id','entity_type','entity_id','action']]
    vals += [[a[k]] if a[k] is not None else None for k in ['content_before','content_after']]
    vals += [a[k] for k in ['operator_id','operator_name','operator_account','source','module_name','menu_name','function_name','data_summary','reason','ip_address']]
    vals += [datetime.datetime.fromisoformat(a['created_at']).isoformat(timespec='microseconds')]
    return sha(canonical(vals).encode())
def norm(sql):return re.sub(r'\$\d+','?',sql.strip())
def normalized_rows(rows,audit=False):
    omit={'id','created_at','updated_at','snapshot_hash'} if audit else {'id','created_at','updated_at'}
    return sorted(canonical({k:v for k,v in row.items() if k not in omit}) for row in rows)
run=load(RAW/'verified/run.json')
for a in run['sourceFingerprints']:
    assert sha((ROOT/a['path']).read_bytes())==a['sha256']
    assert sha(subprocess.check_output(['git','show',HEAD+':'+a['path']],cwd=ROOT))==a['sha256']
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'
service='gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (RAW/'negative/source'/test).read_bytes()==(ROOT/test).read_bytes()
assert (RAW/'negative/source'/service).read_bytes()==subprocess.check_output(['git','show',BASE+':'+service],cwd=ROOT)
assert load(RAW/'negative/test-summary.json')['totals']==dict(tests=23,failures=4,errors=0,skipped=0)
assert load(RAW/'verified/test-summary.json')['totals']==dict(tests=166,failures=0,errors=0,skipped=0)
xml=ET.parse(RAW/'negative/TEST-com.zencas.edhr.masterdata.service.ProductFamilyTransferPostgresTest.xml').getroot()
failures=[c.attrib['name'] for c in xml.findall('testcase') if c.find('failure') is not None]
assert len(failures)==4 and all(n.startswith('bulkAddPreservesAllSelectedProductsWithReducedPrevalidationReads') for n in failures)
results={};observed={}
for phase in ['negative','verified']:
    pg=(RAW/phase/'postgres.log').read_text();events=[]
    for line in pg.splitlines():
        m=re.search(r' Driver (\d+) LOG: .*execute [^:]+: /\* family-transfer:([^ ]+) \*/\s+(.*)',line)
        if m:events.append(dict(tx=m[1],tag=m[2],sql=norm(m[3])))
    observations={p.stem:load(p) for p in (RAW/phase/'observations').glob('*.json')};observed[phase]=observations
    assert len(observations)==33
    details={};unique_hashes={};hash_observations=0
    for tag,o in observations.items():
        selected=[e for e in events if e['tag']==tag and e['sql'].startswith('select')]
        actual=collections.Counter(e['sql'] for e in selected)
        expected=collections.Counter({s:n for s,n in o['preparedSql'].items() if s.startswith('select')})
        assert actual==expected,(phase,tag,actual-expected,expected-actual)
        assert len(selected)==o['selectCalls']
        for a in json.loads(o['committedAudits']):
            assert a['snapshot_hash_version']=='audit-event-v2' and audit_hash(a)==a['snapshot_hash']
            assert (a['operator_id'],a['operator_name'],a['operator_account'],a['source'],a['ip_address'])==('901','簇成员审查员','family-transfer-qa','UI','127.0.0.1')
            unique_hashes[a['id']]=a['snapshot_hash'];hash_observations+=1
        if tag.startswith('bulk-'):
            details[tag]=dict(selectCalls=o['selectCalls'],threadAllocatedBytes=o['threadAllocatedBytes'],elapsedNanos=o['elapsedNanos'],members=len(json.loads(o['committedMembers'])),auditRows=len(json.loads(o['committedAudits'])),selectShapes=[dict(sql=s,calls=n,parameters=s.count('?')) for s,n in expected.items()])
    for n in [1,10,100,513,1025]:
        tag='bulk-'+str(n);o=observations[tag];ms=json.loads(o['committedMembers']);aa=json.loads(o['committedAudits'])
        assert len([m for m in ms if m['product_family_id']==12])==n and len(aa)==2*n
        expected=6*n+2 if phase=='negative' else 4*n+2+2*((n+511)//512)
        assert o['selectCalls']==expected,(phase,n,o['selectCalls'],expected)
        assert sum(e['sql'].startswith('insert into product_family_member') for e in events if e['tag']==tag)==n
        assert sum(e['sql'].startswith('insert into audit_event') for e in events if e['tag']==tag)==2*n
    assert observations['bulk-many-types']['selectCalls']==(3592 if phase=='negative' else 2059)
    failed=observations['bulk-audit-failure']
    assert len(json.loads(failed['committedMembers']))==1 and json.loads(failed['committedMembers'])[0]['id']==201
    assert json.loads(failed['committedAudits'])==[]
    writes=[e for e in events if e['tag']=='bulk-audit-failure' and e['sql'].startswith('insert')]
    assert sum(e['sql'].startswith('insert into product_family_member') for e in writes)==2
    assert sum(e['sql'].startswith('insert into audit_event') for e in writes)==2
    assert len({e['tx'] for e in writes})==1 and writes[0]['tx']!='0'
    assert 'STATEMENT:  /* family-transfer:bulk-audit-failure */ insert into audit_event' in pg
    concurrent=observations['bulk-concurrent-membership'];mm=json.loads(concurrent['committedMembers'])
    assert any(m['id']==202 and m['product_family_id']==11 and m['product_id']==103 for m in mm)
    assert json.loads(concurrent['committedAudits'])==[]
    if phase=='verified':
        for tag,d in details.items():
            for shape in d['selectShapes']:
                if ' in (' in shape['sql']:assert shape['parameters']<= (513 if 'from product_family_member' in shape['sql'] else 512)
        for tag,n in [('bulk-1025',1025),('bulk-many-types',513)]:
            shapes=details[tag]['selectShapes']
            for table in ['material','material_type','product_family_member']:
                chunks=[s for s in shapes if 'from '+table+' ' in s['sql'] and ' in (' in s['sql']]
                expected_ids=1 if tag=='bulk-1025' and table=='material_type' else n
                assert sum((s['parameters']-(1 if table=='product_family_member' else 0))*s['calls'] for s in chunks)==expected_ids,(tag,table)
    assert len(unique_hashes)==4339 and hash_observations==4343
    assert load(RAW/phase/'cleanup.json')['removed'] is True
    results[phase]=dict(observationFiles=len(observations),taggedSelectExecutions=sum(o['selectCalls'] for o in observations.values()),uniqueAuditEventsReencoded=len(unique_hashes),auditObservationRowsReencoded=hash_observations,bulkObservations=details,bulkAuditFailureSuccessfulWrites=writes)
assert set(observed['negative'])==set(observed['verified'])
for tag in observed['negative']:
    for field in ['committedMembers','committedAudits']:
        assert normalized_rows(json.loads(observed['negative'][tag][field]),field=='committedAudits')==normalized_rows(json.loads(observed['verified'][tag][field]),field=='committedAudits'),(tag,field)
plans=load(RAW/'verified/index-analysis.json')
plan_summary=[]
for x in plans['plans']:
    p=x['plan'][0];r=p['Plan'];plan_summary.append(dict(table=x['table'],selected=x['selected'],node=r['Node Type'],index=r.get('Index Name'),executionMs=p['Execution Time'],sharedHitBlocks=r.get('Shared Hit Blocks'),rowsRemoved=r.get('Rows Removed by Filter',0)))
record=dict(baseCommit=BASE,testedCommit=HEAD,sourceFingerprints=run['sourceFingerprints'],oldServiceMatchesBaseline=True,nativeTestBytesIdentical=True,negativeSummary='23=19pass/4 real query-budget failures/0errors/skips; no new functional bug claimed',finalSummary='166/166,0failures/errors/skips',negativeFailures=failures,observations=results,all33NormalizedCommittedStateAndAuditPayloadsEqual=True,indexPlans=plan_summary,indexDecision='No new index/schema changes: existing PK and tenant/product unique cover predicates. Actual planner chooses seqscan for member512 and small type512;100 uses unique. A local warm50k fixture is not production threshold/SLA or proof all queries choose indexes.',remaining='Second-round realtime and member/audit merge reads remain4N plus bounded precheck; no all-constant query claim',allocationScope='Calling-thread cumulative bytes during service/proxy call with same test instrumentation; excludes fixture/assertion/observation serialization and other threads; not peak/RSS or production SLA. N1 allocations may rise; larger samples reduce.',verificationLimits=['In-process MockMvc/JWT on transfer plus existing55 controller tests, no browser/socket bulk UX','Concurrent writer is independent JDBC fixture, not a full concurrent product API/START matrix','Old repository6 use H2;new23 and Batch21 use actual PG','Index probe adds50k owned disposable fixtures after runtime tests; separate from business/audit counts','Knowledge schema/89 and finite semantic records do not complete931/fullP0','Whole auditW2-W7/A12/highrisk/A23inclalreadyreviewed/capacity/UNKNOWN/userpaused continue; wholefile0/historyuniqueunknown'])
(RAW/'main-analysis.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sourceInputs=len(run['sourceFingerprints']),oldNewStates='all33 semantically identical excluding generatedid/times/hash',uniqueAuditEventsEachPhase=4339,observedAuditRowsEachPhase=4343,plans=plan_summary),ensure_ascii=False))
