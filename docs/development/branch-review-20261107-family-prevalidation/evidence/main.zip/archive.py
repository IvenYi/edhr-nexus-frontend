from pathlib import Path
import json,hashlib,zipfile,subprocess,shutil,sys
ROOT=Path('/workspace/edhr-nexus-frontend');DEST=ROOT/'docs/development/branch-review-20261107-family-prevalidation';OUT=DEST/'evidence';OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def archive(label,source):
    source=Path(source)
    if (source/'manifest.json').exists():
        m=json.loads((source/'manifest.json').read_text())
        for a in m.get('artifacts',m.get('files',[])):
            assert sha((source/a['path']).read_bytes())==a['sha256'],a['path']
        for a in m.get('sourceInputs',[]):
            if a.get('sourceCommit'):assert sha(subprocess.check_output(['git','show',a['sourceCommit']+':'+a['path']],cwd=ROOT))==a['sha256'],a['path']
    target=OUT/(label+'.zip');members=[]
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(source.rglob('*')):
            assert not p.is_symlink(),str(p)
            if p.is_file():
                b=p.read_bytes();rel=str(p.relative_to(source));z.writestr(rel,b);members.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(set(z.namelist()))==len(members)
        for f in members:assert sha(z.read(f['path']))==f['sha256']
        assert z.testzip() is None
    manifest=dict(sourceDirectory=str(source),archive=target.name,archiveSha256=sha(target.read_bytes()),archiveBytes=target.stat().st_size,memberCount=len(members),members=members)
    (OUT/(label+'-manifest.json')).write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(label,len(members),target.stat().st_size,manifest['archiveSha256'])
if len(sys.argv)>1:archive(sys.argv[1],sys.argv[2])
else:
    for source,name in [('/tmp/edhr-family-prevalidation-20261107/main-analysis.json','main-analysis.json'),('/tmp/edhr-family-prevalidation-ontology-20261107/ontology-result.yaml','ontology-result.yaml'),('/tmp/edhr-family-prevalidation-ontology-20261107/REVIEW.md','ontology-review.md')]:shutil.copy2(source,DEST/name)
    archive('main','/tmp/edhr-family-prevalidation-20261107')
    archive('ontology','/tmp/edhr-family-prevalidation-ontology-20261107')
