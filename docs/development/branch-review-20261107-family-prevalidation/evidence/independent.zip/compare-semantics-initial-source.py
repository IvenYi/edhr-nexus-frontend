from pathlib import Path
import json
old=Path('/tmp/edhr-family-prevalidation-20261107/negative/observations')
new=Path('/tmp/edhr-family-prevalidation-final-qa-20261107/verified/observations')
def normalize_members(v):
    rows=[]
    for row in json.loads(v):
        r=dict(row)
        if r['id'] not in [201,202]:
            for k in ['id','created_at','updated_at']:r.pop(k)
        rows.append(r)
    return sorted(rows,key=lambda r:json.dumps(r,sort_keys=True,ensure_ascii=False))
def normalize_audits(v):
    rows=[]
    for row in json.loads(v):
        r={k:v for k,v in row.items() if k not in ['id','created_at','snapshot_hash']};rows.append(r)
    return sorted(rows,key=lambda r:json.dumps(r,sort_keys=True,ensure_ascii=False))
results=[]
for p in sorted(new.glob('*.json')):
    a=json.loads((old/p.name).read_text());b=json.loads(p.read_text())
    assert normalize_members(a['committedMembers'])==normalize_members(b['committedMembers']),p.name
    assert normalize_audits(a['committedAudits'])==normalize_audits(b['committedAudits']),p.name
    results.append(dict(observation=p.stem,membersEqual=True,auditBusinessPayloadEqual=True))
assert len(results)==33
Path('/tmp/edhr-family-prevalidation-final-qa-20261107/semantic-comparison.json').write_text(json.dumps(dict(scope='33 synthetic fixtures; parent original old run inspected, independent new run executed; generated new member ID/timestamps and generated audit ID/time/hash excluded; fixed201/202 complete member values retained',results=results),ensure_ascii=False,indent=2)+'\n')
print('33 independent new/old committed member and audit business payload comparisons passed')
