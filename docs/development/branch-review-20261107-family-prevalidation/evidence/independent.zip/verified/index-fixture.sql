INSERT INTO material(id,tenant_id,code,name,material_type_id)
SELECT 1000000+i,'default','INDEX-PROBE-'||i,'索引实验产品',
(SELECT id FROM material_type WHERE code='MT-FINISHED' AND tenant_id='default') FROM generate_series(0,49999) i;
INSERT INTO product_family_member(id,tenant_id,product_family_id,product_id)
SELECT 100000000+i,'default',11,1000000+i FROM generate_series(0,49999) i;
ANALYZE material; ANALYZE material_type; ANALYZE product_family_member;
