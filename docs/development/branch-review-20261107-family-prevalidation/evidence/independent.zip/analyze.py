from pathlib import Path
import json,re,subprocess,hashlib,collections,decimal,datetime
ROOT=Path('/tmp/edhr-family-prevalidation-qa-worktree-20261107')
OUT=Path('/tmp/edhr-family-prevalidation-final-qa-20261107')
PARENT=Path('/tmp/edhr-family-prevalidation-20261107')
HEAD='4ee3efba39c5ff44972561ae25956c33a0c14357'
BASE='5e8edb47ae91af83555f4b67a87598c3c2a9a664'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT)
def norm(s):return re.sub(r'\$\d+','?',re.sub(r'\s+',' ',s).strip())
def jencode(v):
    if isinstance(v,dict):return '{'+','.join(json.dumps(k,ensure_ascii=False)+':'+jencode(v[k]) for k in sorted(v))+'}'
    if isinstance(v,list):return '['+','.join(jencode(x) for x in v)+']'
    if isinstance(v,str) or isinstance(v,bool) or v is None:return json.dumps(v,ensure_ascii=False,separators=(',',':'))
    return str(decimal.Decimal(str(v)).normalize())
def audit_hash(a):
    # Independent encoder for the ordinary UTF-8/integer fixtures of this run, not a general product-codec replacement.
    xs=['audit-event-v2',str(a['id'])]+[a[k] for k in ['tenant_id','entity_type','entity_id','action']]
    xs += [None if a[k] is None else [a[k]] for k in ['content_before','content_after']]
    xs += [a[k] for k in ['operator_id','operator_name','operator_account','source','module_name','menu_name','function_name','data_summary','reason','ip_address']]
    xs += [datetime.datetime.fromisoformat(a['created_at']).isoformat(timespec='microseconds')]
    return sha(jencode(xs).encode())
def scan(folder):
    text=(folder/'postgres.log').read_text();lines=text.splitlines();executions=[]
    for n,line in enumerate(lines):
        m=re.search(r'\[(\d+)\] .* Driver (\d+) LOG: .*execute [^:]+: /\* family-transfer:([^ ]+) \*/ (.+)',line)
        if not m:continue
        sql=m[4].strip();vals=[]
        if n+1<len(lines) and 'DETAIL:  parameters:' in lines[n+1]:
            vals=re.findall(r"\$(\d+) = (NULL|'(?:[^']|'')*')",lines[n+1])
        executions.append(dict(line=n+1,pid=m[1],xid=m[2],tag=m[3],sql=sql,shape=norm(sql),parameters=vals))
    return text,lines,executions
run=read(OUT/'verified/run.json');summary=read(OUT/'verified/test-summary.json')
assert run['head']==HEAD and run['exitCode']==0
assert summary['totals']==dict(tests=166,failures=0,errors=0,skipped=0) and not summary['missingFreshReports']
assert read(OUT/'knowledge/run.json')['totals']==dict(tests=89,failures=0,errors=0,skipped=0)
assert len(run['sourceFingerprints'])==29
for a in run['sourceFingerprints']:
    assert sha((ROOT/a['path']).read_bytes())==a['sha256']
    assert sha(git('show',HEAD+':'+a['path']))==a['sha256']
    assert sha((OUT/'verified/source'/a['path']).read_bytes())==a['sha256']
assert not git('diff',BASE,HEAD,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','gmp-platform/backend/src/main/resources/db')
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'
svc='gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (PARENT/'negative/source'/test).read_bytes()==(ROOT/test).read_bytes()
assert (PARENT/'negative/source'/svc).read_bytes()==git('show',BASE+':'+svc)
assert read(PARENT/'negative/test-summary.json')['totals']==dict(tests=23,failures=4,errors=0,skipped=0)
knowledge=[]
for name in git('ls-tree','-r','--name-only',HEAD,'docs/knowledge').decode().splitlines():
    data=(ROOT/name).read_bytes();assert data==git('show',BASE+':'+name)
    knowledge.append(dict(path=name,bytes=len(data),sha256=sha(data)))
assert len(knowledge)==350
(OUT/'knowledge-inventory.json').write_text(json.dumps(dict(sourceCommit=HEAD,baseCommit=BASE,files=knowledge,all350ByteIdenticalToBase=True),ensure_ascii=False,indent=2)+'\n')
text,lines,es=scan(OUT/'verified');obs={p.stem:read(p) for p in (OUT/'verified/observations').glob('*.json')}
assert len(obs)==33
selects={};batches={};hashes=[];unique=set()
for tag,o in sorted(obs.items()):
    events=[e for e in es if e['tag']==tag];counter=collections.Counter(e['shape'] for e in events if e['sql'].lower().startswith('select'))
    expected=collections.Counter({norm(k):v for k,v in o['preparedSql'].items() if k.lower().startswith('select')})
    assert counter==expected,(tag,counter,expected)
    assert sum(counter.values())==o['selectCalls'];selects[tag]=o['selectCalls']
    for e in events:
        if ' in (' not in e['sql'].lower():continue
        params=[int(i) for i,v in e['parameters']];highest=max([int(x) for x in re.findall(r'\$(\d+)',e['sql'])],default=0)
        assert len(params)==highest and params==list(range(1,highest+1)),(tag,e)
        ismember='from product_family_member ' in e['sql'];ids=[int(v.strip("'")) for i,v in e['parameters'][(1 if ismember else 0):]]
        if ismember:assert e['parameters'][0][1]=="'default'"
        assert 0<len(ids)<=512
        table=re.search(r' from (\w+)',e['sql']).group(1)
        batches.setdefault(tag,[]).append(dict(table=table,ids=ids,totalParameters=highest,line=e['line']))
    for a in json.loads(o['committedAudits']):
        calculated=audit_hash(a);assert calculated==a['snapshot_hash'],(tag,a['id'])
        assert a['snapshot_hash_version']=='audit-event-v2'
        assert (a['operator_id'],a['operator_name'],a['operator_account'],a['source'],a['ip_address'])==('901','簇成员审查员','family-transfer-qa','UI','127.0.0.1')
        unique.add(a['id']);hashes.append(dict(observation=tag,eventId=a['id'],calculated=calculated,persisted=a['snapshot_hash']))
assert len(hashes)==4343 and len(unique)==4339
bulk=[]
for n,old,new in [(1,8,8),(10,62,44),(100,602,404),(513,3080,2058),(1025,6152,4108)]:
    tag='bulk-'+str(n);o=obs[tag];assert selects[tag]==new
    before=read(PARENT/'negative/observations'/(tag+'.json'));assert before['selectCalls']==old
    members=json.loads(o['committedMembers']);aa=json.loads(o['committedAudits'])
    actual={r['product_id'] for r in members if r['product_family_id']==12}
    assert actual==set(range(1000,1000+n)) and len(aa)==2*n
    tagged=[e for e in es if e['tag']==tag]
    assert sum(e['sql'].startswith('insert into product_family_member ') for e in tagged)==n
    assert sum(e['sql'].startswith('insert into audit_event ') for e in tagged)==2*n
    for table in ['material','product_family_member']:
        chunks=[b for b in batches[tag] if b['table']==table]
        assert [len(b['ids']) for b in chunks]==([512]*(n//512)+([n%512] if n%512 else []))
        assert set(x for b in chunks for x in b['ids'])==set(range(1000,1000+n))
    preparedAudit=sum(v for k,v in o['preparedSql'].items() if k.startswith('insert into audit_event '))
    bulk.append(dict(selected=n,oldSelect=old,newSelect=new,oldThreadAllocatedBytes=before['threadAllocatedBytes'],independentThreadAllocatedBytes=o['threadAllocatedBytes'],preparedAuditInsert=preparedAudit,successfulServerAuditInsert=2*n))
assert selects['bulk-many-types']==2059
typeChunks=[b for b in batches['bulk-many-types'] if b['table']=='material_type'];assert [len(x['ids']) for x in typeChunks]==[512,1]
assert set(x for b in typeChunks for x in b['ids'])==set(range(5000,5513))
failures={}
for tag in ['bulk-audit-failure','audit-failure','member-failure']:
    o=obs[tag];mm=json.loads(o['committedMembers']);aa=json.loads(o['committedAudits'])
    assert len(mm)==1 and mm[0]['id']==201 and mm[0]['product_family_id']==11 and aa==[]
    writes=[e for e in es if e['tag']==tag and e['sql'].startswith(('insert','delete'))]
    failed=[dict(line=i+1,text=l) for i,l in enumerate(lines) if 'STATEMENT:  /* family-transfer:'+tag+' */ insert' in l]
    assert len(failed)==1
    failures[tag]=dict(successfulWrites=[dict(line=e['line'],xid=e['xid'],shape=e['shape']) for e in writes],failedStatements=failed)
assert len(failures['bulk-audit-failure']['successfulWrites'])==4
assert len(failures['audit-failure']['successfulWrites'])==4
assert len(failures['member-failure']['successfulWrites'])==1
concurrent=[e for e in es if e['tag']=='bulk-concurrent-membership']
before=[e for e in concurrent if 'from product_family_member ' in e['sql'] and ' in (' in e['sql']]
after=[e for e in concurrent if 'from product_family_member ' in e['sql'] and '.product_id=$2' in e['sql']]
writer=[dict(line=i+1,text=l) for i,l in enumerate(lines) if 'LOG:' in l and 'VALUES(202,\'default\',11,103)' in l and 'execute' in l]
assert len(before)==len(after)==len(writer)==1
assert before[0]['line']<writer[0]['line']<after[0]['line']
assert before[0]['pid']==after[0]['pid']
assert not any(e['sql'].startswith(('insert','delete','update')) for e in concurrent)
cm=json.loads(obs['bulk-concurrent-membership']['committedMembers']);assert any(m['id']==202 and m['product_family_id']==11 and m['product_id']==103 for m in cm)
assert json.loads(obs['bulk-concurrent-membership']['committedAudits'])==[]
plans=[]
for p in read(OUT/'verified/index-analysis.json')['plans']:
    root=p['plan'][0]['Plan'];plans.append(dict(table=p['table'],selected=p['selected'],node=root['Node Type'],index=root.get('Index Name'),rows=root['Actual Rows'],rowsRemoved=root.get('Rows Removed by Filter',0),sharedHits=root.get('Shared Hit Blocks',0),executionMs=p['plan'][0]['Execution Time']))
assert read(OUT/'verified/cleanup.json')['removed']
(OUT/'independent-audit-hashes.json').write_text(json.dumps(dict(observationRows=len(hashes),uniqueEvents=len(unique),rows=hashes),ensure_ascii=False,indent=2)+'\n')
(OUT/'sql-execution-extract.log').write_text('\n'.join(lines[e['line']-1] for e in es)+'\n')
result=dict(headCommit=HEAD,baseCommit=BASE,testTotals=summary['totals'],knowledgeTotals=read(OUT/'knowledge/run.json')['totals'],sourceInputs=run['sourceFingerprints'],sourceInputsVerified=29,observations=33,taggedSelectsMatchEveryInspectorShape=True,selectCounts=selects,bulk=bulk,batchParameters=batches,auditObservationRowsVerified=4343,uniqueAuditEventsVerified=4339,failureWriteEvidence=failures,concurrent=dict(prevalidationLine=before[0]['line'],externalJdbcWriter=writer[0],realtimeReadLine=after[0]['line'],workerPid=before[0]['pid'],scope='real double-connection JDBC commit and original skip behavior; not production API writer/complete concurrent matrix'),preparedPlans=plans,negativeEvidence=dict(inspectedNotRerun=True,totals=read(PARENT/'negative/test-summary.json')['totals'],sameNativeTestBytes=True,oldServiceEqualsBase=True,failures='Four query budget assertion failures, not functional regressions or fixture errors'),limitations=['Calling-thread tagged Hibernate SQL only; fixtures/assertions/index probe SQL excluded','Allocation is calling-thread cumulative bytes, not live/peak memory or production SLA','Legacy repository6 uses H2; service/controller/audit unit tests do not become native integration','New23 uses canonical PG plus actual signedJWT/MockMvc, not socket/browser/live directory','Known remaining4N realtime/merge reads and full-tenant option loading are outside this authorized prevalidation slice','Existing P1 coarse fact locator/provider gap remains; knowledge structure checks are not runtime fact registration proof','Whole audit W2-W7/931knowledge86UI/A12/high-risk/fullmatrices/A23 incl old and paused items remain; wholefile0/historyuniqueunknown'])
(OUT/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(tests=result['testTotals'],source29=True,observations=33,auditObservationRows=4343,uniqueAuditEvents=4339,bulk=bulk,plans=plans),ensure_ascii=False))
