import subprocess,json

def probe(container,db,out):
    def sql(text):
        return subprocess.run(['docker','exec','-i',container,'psql','-X','-q','-A','-t','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],input=text,text=True,check=True,capture_output=True).stdout.strip()
    fixture="""INSERT INTO material(id,tenant_id,code,name,material_type_id)
SELECT 1000000+i,'default','INDEX-PROBE-'||i,'索引实验产品',
(SELECT id FROM material_type WHERE code='MT-FINISHED' AND tenant_id='default') FROM generate_series(0,49999) i;
INSERT INTO product_family_member(id,tenant_id,product_family_id,product_id)
SELECT 100000000+i,'default',11,1000000+i FROM generate_series(0,49999) i;
ANALYZE material; ANALYZE material_type; ANALYZE product_family_member;"""
    (out/'index-fixture.sql').write_text(fixture+'\n');sql(fixture)
    indexes=json.loads(sql("SELECT json_agg(row_to_json(x)) FROM (SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public' AND tablename IN ('material','material_type','product_family_member') ORDER BY tablename,indexname) x"))
    plans=[]
    for table,column,n,start,tenant in [('material','id',100,1000000,False),('material','id',512,1000000,False),('material_type','id',512,5000,False),('product_family_member','product_id',100,1000000,True),('product_family_member','product_id',512,1000000,True)]:
        shift=2 if tenant else 1
        placeholders=','.join('$'+str(i+shift) for i in range(n));args=','.join(str(start+i) for i in range(n))
        where=("tenant_id=$1 AND " if tenant else '')+column+' IN ('+placeholders+')'
        query='PREPARE edhr_index_probe AS SELECT * FROM '+table+' WHERE '+where+';\nEXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) EXECUTE edhr_index_probe('+ ("'default'," if tenant else '')+args+');\nDEALLOCATE edhr_index_probe;'
        tag=table+'-'+str(n);(out/(tag+'-plan.sql')).write_text(query+'\n');plan=json.loads(sql(query));(out/(tag+'-plan.json')).write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
        plans.append(dict(table=table,selected=n,parameters=n+(1 if tenant else 0),plan=plan))
    (out/'index-analysis.json').write_text(json.dumps(dict(scope='Separate synthetic prepared SELECT plan probe after tests; 50k extra fixture materials/members in the owned disposable canonical DB; not production statistics or business actions',indexes=indexes,plans=plans),ensure_ascii=False,indent=2)+'\n')
