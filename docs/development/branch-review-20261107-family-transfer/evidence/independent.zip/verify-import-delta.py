from pathlib import Path
import subprocess,json,hashlib,datetime
W=Path('/tmp/edhr-family-transfer-final-qa-worktree-20261107');R=Path('/tmp/edhr-family-transfer-final-qa-20261107');O=R/'import-only-b2b0'
old='1709dbc4d3d28d8721ff001b69ad934a6de54d18';new='b2b0df85572f634925d9e3b1ac4a91c0988bb86c';base='04db7e838ec5e194355ff954ff173a02205e0fd6'
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java';unused=b'import java.util.concurrent.atomic.AtomicInteger;\n'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=W)
assert git('rev-parse','HEAD').decode().strip()==new
assert git('diff','--name-only',old,new).decode().splitlines()==[test]
oldBytes=git('show',old+':'+test);newBytes=git('show',new+':'+test);assert oldBytes.count(unused)==1 and newBytes==oldBytes.replace(unused,b'')==(W/test).read_bytes()
compileRun=json.loads((O/'compile-run.json').read_text());assert compileRun['head']==new and compileRun['exitCode']==0 and compileRun['testsExecuted']==0
run=json.loads((R/'verified/run.json').read_text());matched=[];changed=[]
for x in run['sourceFingerprints']:
 b=(W/x['path']).read_bytes();assert b==git('show',new+':'+x['path'])
 if sha(b)==x['sha256']:matched.append(x)
 else:changed.append({'path':x['path'],'oldSha256':x['sha256'],'newSha256':sha(b),'onlyUnusedImportRemoved':True})
assert len(matched)==24 and len(changed)==1 and changed[0]['path']==test
inventory=json.loads((R/'knowledge-source-child/knowledge-inventory.json').read_text());assert len(inventory)==350
for x in inventory:assert sha((W/x['path']).read_bytes())==x['headSha256']==sha(git('show',new+':'+x['path']))
classes=[];classDir=W/'gmp-platform/backend/target/test-classes';compiled=sorted(classDir.rglob('ProductFamilyTransferPostgresTest*.class'));saved=json.loads((R/'initial-1709/class-instructions.json').read_text());assert len(compiled)==len(saved)==3
for p,s in zip(compiled,saved):
 name=str(p.relative_to(classDir)).replace('/','.').removesuffix('.class');assert name==s['className']
 command=['/workspace/.edhr-cloud-tools/jdk-21/bin/javap','-classpath',str(classDir),'-c','-p','-s','-constants',name];data=subprocess.check_output(command)
 assert data==(R/s['javap']).read_bytes()
 assert p.stat().st_mtime>=datetime.datetime.fromisoformat(compileRun['startedAt']).timestamp()
 out=O/(p.name+'.javap.txt');out.write_bytes(data)
 classes.append({'className':name,'javapCommand':command,'instructionsSha256':sha(data),'instructionsExactlyEqual':True,'oldClassFileSha256':s['classBytesSha256'],'newClassFileSha256':sha(p.read_bytes()),'classFileBytesEqual':s['classBytesSha256']==sha(p.read_bytes()),'note':'Line/debug attributes may differ; no claim of full class-file byte equality'})
symlink=W/'gmp-platform/frontend/node_modules';assert symlink.is_symlink() and symlink.readlink()==Path('/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules');symlink.unlink()
assert git('status','--porcelain','--untracked-files=all').decode().strip()==''
assert git('rev-parse','origin/edhr-dev').decode().strip()==base
subprocess.run(['git','diff','--check'],cwd=W,check=True)
result={'sourceCommit':old,'finalCandidate':new,'targetCommit':base,'exactDelta':'one unused import removed from test only','oldRuntimeProductTests':156,'oldRuntimeKnowledgeTests':89,'newRuntime156or89NotExecuted':True,'independentCompile':compileRun,'unchangedTestedInputs':matched,'changedTestedInput':changed,'knowledge350ByteUnchanged':True,'newTestClassInstructions':classes,'runtimeReuseDecision':'Applicable candidate delta checks passed: import removal changes no executable instruction/signature/constant/annotation/fixture/assertion; product inputs and knowledge identical. Original156+89 retained at actual1709 and reused by impact assessment, not reattributed to b2b0.','finalWorkingTree':'clean','temporaryDependencySymlinkRemoved':True,'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(O/'verification.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');(O/'git.diff').write_bytes(git('diff',old,new));(O/'final-test-source.java').write_bytes(newBytes)
print(json.dumps({'compiledExit':compileRun['exitCode'],'classes':3,'instructionsIdentical':True,'sourceInputsUnchanged':24,'testOnlyUnusedImportChanged':1,'knowledge350Same':True,'finalStatus':'clean'}))
