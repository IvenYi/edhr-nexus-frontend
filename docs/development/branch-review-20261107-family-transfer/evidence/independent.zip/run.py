from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,shutil,time,xml.etree.ElementTree as ET
root=Path(os.getenv('EDHR_FAMILY_ROOT','/tmp/edhr-family-transfer-final-qa-worktree-20261107'));raw=Path(os.getenv('EDHR_FAMILY_RAW','/tmp/edhr-family-transfer-final-qa-20261107'));phase=sys.argv[1];assert phase in ['negative','final','retry','verified'];negative=phase=='negative'
out=raw/phase;out.mkdir(parents=True,exist_ok=False);tmp=out/'vm-tmp';tmp.mkdir();name='edhr-family-transfer-final-qa-'+phase+'-20261107';created=False;code=1
shutil.copy2(__file__,out/'runner-source.py')
selected='ProductFamilyTransferPostgresTest'
if not negative:selected+=',ProductFamilyMembershipServiceTest,ProductFamilyMemberRepositoryTest,ProductProcessResolutionServiceTest,ProcessModelingControllerTest,BatchProcessIntegrationTest,AuditEventHashTest,AuditEventTest,AuditAspectTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 env=os.environ.copy();env.update(PGUSER='postgres',PGPASSWORD='')
 db='edhr_family_transfer_test_'+phase;batchdb='edhr_batch_process_family_'+phase
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','shared_preload_libraries=pg_stat_statements','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a %x ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('owned PG unavailable')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env['FAMILY_TRANSFER_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/{db}'
 if not negative:run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE DATABASE '+batchdb])
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/development/branch-review-20261107-family-transfer/decision-package.yaml','gmp-platform/backend/pom.xml','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/repository/ProductFamilyMemberRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/main/resources/db/changelog/baseline/0002-current-seed.sql']
 for test in selected.split(','):
  files=list((root/'gmp-platform/backend/src/test/java').rglob(test+'.java'));assert len(files)==1;paths.append(str(files[0].relative_to(root)))
 paths.append('docs/knowledge/facts/core-business.yaml')
 fingers=[]
 for path in paths:
  b=(root/path).read_bytes();fingers.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.familyTransfer=true','-Dedhr.audit.familyTransferOutput='+str(out/'observations'),'-DargLine=-Xmx1536m -Djava.io.tmpdir='+str(tmp),'-Dtest='+selected]
 if not negative:command+=['-Dbatch.test.url=jdbc:postgresql://127.0.0.1:'+port+'/'+batchdb,'-Dbatch.test.user=postgres','-Dproduction.growth.observe=true']
 command+=['test'];start=datetime.datetime.now(datetime.timezone.utc)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'run.json').write_text(json.dumps({'command':command,'head':run(['git','rev-parse','HEAD'],cwd=root),'status':run(['git','status','--porcelain'],cwd=root),'startedAt':start.isoformat(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fingers,'databaseUrl':env['FAMILY_TRANSFER_DATABASE_URL'],'batchDatabase':batchdb if not negative else None},indent=2)+'\n')
 totals=dict(tests=0,failures=0,errors=0,skipped=0);classes=[];missing=[]
 for test in selected.split(','):
  reports=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not reports:missing.append(test)
  for p in reports:
   shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;v={k:int(a.get(k,0)) for k in totals};classes.append({'class':a['name'],**v})
   for k in totals:totals[k]+=v[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-1800:]);code=0 if result.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n')
sys.exit(code)
