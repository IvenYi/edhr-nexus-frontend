from pathlib import Path
import subprocess, hashlib, json, datetime
import yaml

REPO = Path('/workspace/edhr-nexus-frontend')
OUT = Path(__file__).parent
BASE = '04db7e838ec5e194355ff954ff173a02205e0fd6'
HEAD = '1709dbc4d3d28d8721ff001b69ad934a6de54d18'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)
def source(commit, path):
    return git('show', commit + ':' + path)
def sha(value):
    return hashlib.sha256(value).hexdigest()
def write(name, obj):
    (OUT/name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

paths = git('ls-tree', '-r', '--name-only', HEAD, 'docs/knowledge').decode().splitlines()
basepaths = git('ls-tree', '-r', '--name-only', BASE, 'docs/knowledge').decode().splitlines()
assert paths == basepaths and len(paths) == 350
inventory = []
for path in paths:
    before, after = source(BASE, path), source(HEAD, path)
    inventory.append(dict(path=path, baseSha256=sha(before), headSha256=sha(after), unchanged=before==after))
changed = [x['path'] for x in inventory if not x['unchanged']]
assert changed == ['docs/knowledge/facts/core-business.yaml']
write('knowledge-inventory.json', inventory)

factpath = changed[0]
before, after = (yaml.safe_load(source(c, factpath)) for c in [BASE, HEAD])
assert set(before) == set(after)
assert before['knowledgeModelVersion'] == after['knowledgeModelVersion'] == '0.3.25'
oldfacts = {f['id']:f for f in before['facts']}
newfacts = {f['id']:f for f in after['facts']}
assert oldfacts.keys() == newfacts.keys()
ids = ['fact.catalog.productfamilytransfer-confirmation', 'fact.catalog.productfamilytransfer-reason']
assert [i for i in oldfacts if oldfacts[i] != newfacts[i]] == ids
field_changes = []
expected = {'sourcePath','evidenceIds','sourceRevision','sourceLocator','capturedAt'}
controller = 'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java'
for factid in ids:
    old, new = oldfacts[factid], newfacts[factid]
    assert old.keys() == new.keys()
    keys = {k for k in old if old[k] != new[k]}
    assert keys == expected
    assert new['sourcePath'] == controller
    assert new['evidenceIds'] == ['evidence.process-modeling-controller']
    assert new['sourceRevision'] == BASE
    field_changes.append(dict(id=factid, changedFields=sorted(keys), changes={k:dict(before=old[k],after=new[k]) for k in sorted(keys)}))
assert source(BASE,controller) == source(HEAD,controller)
write('fact-field-changes.json', field_changes)

input_paths = [
    'AGENTS.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/quality-verifier.md',
    'docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md',
    'docs/knowledge/open-questions.yaml', 'docs/knowledge/schema.yaml',
    'docs/knowledge/decisions/DEC-0002-product-family-process-modeling.yaml',
    'docs/knowledge/decisions/DEC-0007-production-work-applicability-and-runtime-snapshot.yaml',
    'docs/knowledge/facts/core-business.yaml', 'docs/knowledge/rules/product-process.yaml',
    'docs/knowledge/evidence/product-process.yaml', controller,
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java',
    'docs/development/branch-review-20261107-family-transfer/decision-package.yaml',
]
inputs = []
for path in input_paths:
    b=source(HEAD,path)
    dst=OUT/'source'/path
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_bytes(b)
    inputs.append(dict(path=path,sourceCommit=HEAD,gitBlob=git('rev-parse',HEAD+':'+path).decode().strip(),bytes=len(b),sha256=sha(b)))

result = dict(
    result='passed', scope='finite source and knowledge provenance auxiliary review only',
    contractBaseline=dict(sourceCommit=HEAD,targetBranch='edhr-dev',targetCommit=BASE,contractReadCommit=HEAD,uncommittedContractPaths=[]),
    knowledgeBaselineVersion='0.3.25', schemaVersion='1.2.0',
    trackedKnowledgeFiles=350, byteUnchangedKnowledgeFiles=349,
    changedKnowledgePaths=changed, changedFactIds=ids,
    eachFactChangedFields=sorted(expected),
    genericRuntimeFactProviderVerified=False,
    semanticMaturityChanged=False, businessPolicyChanged=False,
    applicationOrTestsExecuted=False, repositoryModified=False,
    wholeFileCompleted=0, historicalUniqueCoverage='unknown', findings=[],
    originRefObserved=git('rev-parse','origin/edhr-dev').decode().strip(),
    observedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),
)
write('result.json', result)
report='''# 独立质量辅助：转簇事实来源核对

FINAL。有限源码结论 passed；不是最终独立运行质量结果。候选 `{head}`，目标 `{base}`，实际读取契约同候选，知识0.3.25/schema1.2.0。

固定Git树逐字节核对350个知识文件：路径无增删，349个未改，只有facts/core-business.yaml修改。解析前后YAML，全部fact ID及顶层键不变；恰好 `fact.catalog.productfamilytransfer-confirmation` 与 `fact.catalog.productfamilytransfer-reason` 各修改sourcePath、evidenceIds、sourceRevision、sourceLocator、capturedAt五个字段。valueType/string、sourceType/derived、availability、allowedOperators、status/implemented、visibility/internal、reviewStatus及别名等均原样；没有提升成熟度或添加业务政策。

源码锚点可复核：ProcessModelingController.java:426–436的现有转移POST带 `master-data.product-families` 权限和事务，confirmed缺省false，先requireConfirmed再调用服务；1543–1545的requireConfirmed拒绝false。入口参数仅id/productId/confirmed，无原因输入。Controller在目标与候选字节相同，sourceRevision完整04db确能定位；既有evidence.process-modeling-controller指向该Controller。旧ProductProcessResolutionService并不承载此确认入口。新sourceLocator解释second-confirmation是规则语义标签，避免把boolean参数改成新的字符串请求字段；空原因来自不采集，而非新增原因输入。

DEC-0002-02/11与rule.product-family.member-transfer-audit既有要求仍是单产品唯一归属、事务、二次确认、不采集原因、产品/旧簇/新簇三方审计。候选服务只在delete(existing)后增加flush，仍新ID保存并调用原三方审计；flush不是commit，不更改规范。DEC-0002-10及DEC-0007-03/04的首次START当前归属/已开工制程冻结、作业实时匹配和已有实例保留原文均未改，本批不能代替整条START运行矩阵验收。

A23：这里的flush有现存立即唯一约束和ORM动作排序的具体依据，属于事务内写序要求；未添加重试、吞异常、缓存、默认回退或重复业务检查。原Controller二次确认是已确认政策。批量添加中已有两轮成员读取并不能仅凭重复形状断言过度防御，第二轮可能读取并发新增；下一批批量预校验仍须保留既有实时复核/写入/审计。此处只做有限源码判断，未运行并发或性能实验。

catalog事实的configuration-and-runtime/implemented是既有描述，不因来源定位纠错获得通用运行事实注册证明。当前后端源码检索productFamilyTransfer无显式通用provider注册，本辅助不认证通用求值闭环；新locator已明示不是新增通用事实求值注册。知识测试及实际事务/审计/hash/SQL由最终质量父角色独立运行。

未改仓库，未启动应用、测试、PG或浏览器，未查询/触发CI，未合并/部署/恢复数据。此次有限重核不新增主侧28ID或全量unique覆盖；整文件完成0，历史unique未知。W2–W7、931知识/86UI、A12/高风险完整矩阵及A23含已审复查、用户暂停项继续。

原件：knowledge-inventory.json（350路径双SHA）、fact-field-changes.json（两fact逐字段）、source/（15固定输入）、manifest.json（输入与产物指纹）。
'''.format(head=HEAD,base=BASE)
(OUT/'REVIEW.md').write_text(report)
outputs=[]
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name != 'manifest.json':
        b=path.read_bytes(); outputs.append(dict(path=str(path.relative_to(OUT)),bytes=len(b),sha256=sha(b)))
write('manifest.json',dict(sourceCommit=HEAD,targetCommit=BASE,inputs=inputs,outputs=outputs))
print(json.dumps(result,ensure_ascii=False))
