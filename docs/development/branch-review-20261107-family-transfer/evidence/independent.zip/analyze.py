from pathlib import Path
import json,re,hashlib,subprocess,datetime,collections,decimal,xml.etree.ElementTree as ET
R=Path('/tmp/edhr-family-transfer-final-qa-20261107'); W=Path('/tmp/edhr-family-transfer-final-qa-worktree-20261107'); M=Path('/tmp/edhr-family-transfer-20261107')
sha=lambda b:hashlib.sha256(b).hexdigest()
base='04db7e838ec5e194355ff954ff173a02205e0fd6'; head='1709dbc4d3d28d8721ff001b69ad934a6de54d18'
run=json.loads((R/'verified/run.json').read_text()); summary=json.loads((R/'verified/test-summary.json').read_text())
assert run['head']==head and run['exitCode']==0
assert summary['totals']==dict(tests=156,failures=0,errors=0,skipped=0) and not summary['missingFreshReports']
assert len(run['sourceFingerprints'])==25
for x in run['sourceFingerprints']:
 assert sha((W/x['path']).read_bytes())==x['sha256']==sha(subprocess.check_output(['git','show',head+':'+x['path']],cwd=W)),x['path']
knowledge=json.loads((R/'knowledge/run.json').read_text()); assert knowledge['head']==head and knowledge['exitCode']==0
assert knowledge['reports']==[dict(name='com.zencas.edhr.knowledge.BusinessKnowledgeModelTest',tests='89',failures='0',errors='0',skipped='0')]
log=(R/'verified/postgres.log').read_text(); executions=collections.defaultdict(list)
for line in log.splitlines():
 m=re.search(r' (\d+) LOG: .*?execute [^:]+: /\* family-transfer:([^ ]+) \*/\s+(.*)',line)
 if m:executions[m[2]].append({'transactionId':m[1],'sql':m[3]})
def writes(tag):return [e for e in executions[tag] if re.match(r'(insert|delete|update)\b',e['sql'],re.I)]
sqlOrders={}
for tag in ['native-transfer','http-transfer','uncommitted-transfer']:
 ws=writes(tag); assert len(ws)==5 and len({e['transactionId'] for e in ws})==1 and ws[0]['transactionId']!='0'
 assert ws[0]['sql'].startswith('delete from product_family_member') and ws[1]['sql'].startswith('insert into product_family_member') and all(e['sql'].startswith('insert into audit_event') for e in ws[2:])
 sqlOrders[tag]=ws
assert [e['sql'].split()[0] for e in writes('audit-failure')]==['delete','insert','insert','insert']
assert [e['sql'].split()[0] for e in writes('member-failure')]==['delete']
assert re.search(r'ERROR:  edhr_test_family_audit_failure',log) and re.search(r'STATEMENT:  /\* family-transfer:audit-failure \*/ insert into audit_event',log)
assert re.search(r'ERROR:  edhr_test_family_member_failure',log) and re.search(r'STATEMENT:  /\* family-transfer:member-failure \*/ insert into product_family_member',log)
observations={p.stem:json.loads(p.read_text()) for p in (R/'verified/observations').glob('*.json')}; assert len(observations)==16
hashes=[];states={};bulk={}
def encoded(value):
 if value is None:return 'null'
 if value is True:return 'true'
 if value is False:return 'false'
 if isinstance(value,int):return str(decimal.Decimal(value).normalize())
 if isinstance(value,str):return json.dumps(value,ensure_ascii=False,separators=(',',':'))
 if isinstance(value,list):return '['+','.join(encoded(x) for x in value)+']'
 if isinstance(value,dict):return '{'+','.join(encoded(k)+':'+encoded(value[k]) for k in sorted(value))+'}'
 raise TypeError(type(value))
def v2(e):
 a=['audit-event-v2',str(e['id']),e['tenant_id'],e['entity_type'],e['entity_id'],e['action'],[e['content_before']],[e['content_after']],e['operator_id'],e['operator_name'],e['operator_account'],e['source'],e['module_name'],e['menu_name'],e['function_name'],e['data_summary'],e['reason'],e['ip_address'],datetime.datetime.fromisoformat(e['created_at']).isoformat(timespec='microseconds')]
 return sha(encoded(a).encode())
for tag,o in observations.items():
 members=json.loads(o['committedMembers']); audits=json.loads(o['committedAudits']); states[tag]={'members':members,'auditCount':len(audits),'failure':o['failure']}
 assert sum(e['sql'].startswith('select') for e in executions[tag])==o['selectCalls'],tag
 for e in audits:
  assert e['snapshot_hash_version']=='audit-event-v2' and v2(e)==e['snapshot_hash'],(tag,e['id'])
  assert (e['operator_id'],e['operator_name'],e['operator_account'],e['source'],e['ip_address'])==('901','簇成员审查员','family-transfer-qa','UI','127.0.0.1')
  hashes.append({'tag':tag,'id':str(e['id']),'computedSha256':v2(e),'persistedSha256':e['snapshot_hash']})
 if tag in sqlOrders:
  assert len(members)==1 and members[0]['id']!=201 and members[0]['product_id']==101 and members[0]['product_family_id']==12 and len(audits)==3
  assert {(e['entity_type'],e['entity_id']) for e in audits}=={('PRODUCT','101'),('PRODUCT_FAMILY','11'),('PRODUCT_FAMILY','12')}
  for e in audits:
   assert e['action']=='UPDATE' and e['reason'] is None
   if e['entity_type']=='PRODUCT':assert e['content_before']['productFamilyId']==11 and e['content_after']['productFamilyId']==12
   elif e['entity_id']=='11':assert e['content_before']['memberProductId']==101 and e['content_after']=={}
   else:assert e['content_before']=={} and e['content_after']['memberProductId']==101
 elif tag.startswith('bulk-'):
  n=int(tag.split('-')[1]); assert len(members)==n+1 and len(audits)==2*n and o['selectCalls']==6*n+2
  actualAuditInsert=sum(e['sql'].startswith('insert into audit_event') for e in executions[tag]); preparedAuditInsert=sum(n for sql,n in o['preparedSql'].items() if sql.startswith('insert into audit_event'))
  assert actualAuditInsert==2*n
  bulk[tag]={'products':n,'selectExecutions':o['selectCalls'],'serverAuditInsertExecutions':actualAuditInsert,'inspectorAuditInsertPreparedStatements':preparedAuditInsert}
 else:
  assert len(members)==1 and members[0]['id']==201 and members[0]['product_family_id']==11 and members[0]['created_by']=='旧记录人' and members[0]['created_at']=='2020-01-01T00:00:00' and audits==[],tag
assert len(hashes)==231
old=M/'negative'; oldSummary=json.loads((old/'test-summary.json').read_text());assert oldSummary['totals']==dict(tests=13,failures=3,errors=1,skipped=0)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'; service='gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (old/'source'/test).read_bytes()==(W/test).read_bytes()
assert (old/'source'/service).read_bytes()==subprocess.check_output(['git','show',base+':'+service],cwd=W)
oldXml=next(old.glob('TEST-*ProductFamilyTransferPostgresTest.xml')); xml=ET.parse(oldXml).getroot(); errors=[(c.attrib['name'],c.find('error')) for c in xml.findall('testcase') if c.find('error') is not None]
assert len(errors)==1 and errors[0][0]=='committedTransferPreservesNewIdentityAndThreeAccurateAudits' and 'uk_product_family_member_tenant_product' in errors[0][1].text
oldLog=(old/'postgres.log').read_text();assert 'duplicate key value violates unique constraint "uk_product_family_member_tenant_product"' in oldLog
assert not re.search(r'execute [^:]+: /\* family-transfer:native-transfer \*/\s+(delete|insert)',oldLog)
assert re.search(r'STATEMENT:  /\* family-transfer:native-transfer \*/ insert into product_family_member',oldLog)
cleanup=json.loads((R/'verified/cleanup.json').read_text());assert cleanup['removed'] is True and 'final-qa' in cleanup['ownedContainer']
assert subprocess.run(['docker','inspect',cleanup['ownedContainer']],capture_output=True).returncode!=0
result={'head':head,'base':base,'independentActualProductTests':summary,'independentActualKnowledgeTests':knowledge['reports'],'source25ByteIdentical':True,'oldNegativeEvidenceInspectedNotRerun':{'totals':oldSummary['totals'],'passed':9,'errorMeaning':'genuine valid transfer unique-constraint product failure, not fixture error','sameTestBytes':True,'oldServiceEqualsBase':True,'xmlSha256':sha(oldXml.read_bytes()),'postgresSha256':sha((old/'postgres.log').read_bytes())},'sqlSuccessfulWriteOrder':sqlOrders,'failureWriteExecutions':{k:writes(k) for k in ['audit-failure','member-failure']},'failedSqlEvidence':'ERROR and STATEMENT logs; not successful execute counts','committedStates':states,'independentlyRecomputedAuditRows':len(hashes),'bulkReadObservations':bulk,'cleanup':cleanup,'scope':'Calling-thread tagged Hibernate statements; real canonical PG/JPA+JWT MockMvc; no real HTTP socket/browser/full START writer matrix'}
(R/'analysis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');(R/'independent-audit-hashes.json').write_text(json.dumps(hashes,indent=2,ensure_ascii=False)+'\n')
extract=[line for line in log.splitlines() if ('family-transfer:' in line and (' execute ' in line or 'STATEMENT:' in line)) or 'ERROR:  edhr_test_family_' in line]
(R/'sql-execution-extract.log').write_text('\n'.join(extract)+'\n')
print(json.dumps({'productTests':156,'knowledgeTests':89,'inputHashes':25,'auditsRecomputed':len(hashes),'observations':len(observations),'bulk':bulk,'cleanup':cleanup},ensure_ascii=False))
