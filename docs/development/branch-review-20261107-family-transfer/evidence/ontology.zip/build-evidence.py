from pathlib import Path
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import yaml

REPO = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-family-transfer-ontology-20261107')
BASE = '04db7e838ec5e194355ff954ff173a02205e0fd6'
CHANGED_IDS = ['fact.catalog.productfamilytransfer-confirmation', 'fact.catalog.productfamilytransfer-reason']
PRIMARY = [
    'DEC-0002-01', 'DEC-0002-02', 'DEC-0002-11', 'term.product-family',
    'concept.product-family', 'relation.product-belongs-to-product-family',
    'relation.product-family-contains-products', 'rule.product.source-from-material',
    'rule.product-family.membership-cardinality', 'rule.product-family.member-transfer-audit',
    'rule.product-family.member-audit-customer-labels', 'fact.catalog.material-typename',
    'fact.catalog.product-productfamilycount', *CHANGED_IDS,
    'scenario.product-family-membership', 'scenario.product-family-transfer',
]
ADJACENT = [
    'DEC-0002-06', 'DEC-0002-07', 'DEC-0002-10', 'DEC-0007-03', 'DEC-0007-04',
    'rule.product-family.member-transfer-future-only',
    'rule.product-process.product-version-takes-precedence',
    'rule.product-process.product-family-fallback',
    'rule.production.process-resolution-product-then-family',
    'rule.production-work.instance-auto-matches-applicability',
    'rule.production-work.instance-freezes-work-and-rule-snapshot',
]
schema = yaml.safe_load((REPO/'docs/knowledge/schema.yaml').read_text())
mapping = {**schema['collectionTypes'], **schema['nestedCollectionTypes']}
index = {}

def visit(value, path, record_type=None, parent=None):
    if isinstance(value, dict):
        current_parent = parent
        if 'id' in value:
            index[value['id']] = (path, record_type, value, parent)
            current_parent = value
        for key, child in value.items():
            if isinstance(child, list):
                for item in child:
                    visit(item, path, mapping.get(key), current_parent)
    elif isinstance(value, list):
        for item in value:
            visit(item, path, record_type, parent)

for path in sorted((REPO/'docs/knowledge').rglob('*.yaml')):
    if path.name != 'schema.yaml':
        visit(yaml.safe_load(path.read_text()), str(path.relative_to(REPO)))

source_refs = [
    'docs/knowledge/decisions/DEC-0002-product-family-process-modeling.yaml',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java#transferMember/requireEligibleProduct/writeMembershipAudits',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java#transferProductFamilyMember/requireConfirmed',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java',
    'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql#uk_product_family_member_tenant_product',
]
adjacent_refs = [
    'docs/knowledge/decisions/DEC-0002-product-family-process-modeling.yaml',
    'docs/knowledge/decisions/DEC-0007-production-work-applicability-and-runtime-snapshot.yaml',
    'docs/knowledge/evidence/batch-process-2026-10-27.md',
    'docs/knowledge/evidence/work-live-matching-2026-10-26.md',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductProcessResolutionService.java',
]
rows = []
for ident in PRIMARY + ADJACENT:
    path, record_type, record, parent = index[ident]
    lines = (REPO/path).read_text().splitlines()
    line = next(i+1 for i, text in enumerate(lines) if re.match(r'\s*- id: '+re.escape(ident)+r'\s*$', text))
    adjacent = ident in ADJACENT
    changed = ident in CHANGED_IDS
    rows.append({
        'id': ident, 'recordType': record_type, 'sourcePath': path, 'sourceLocator': f'line:{line}',
        'originalMaturity': {'status': record.get('status'), 'visibility': record.get('visibility'),
                             'parentStatus': parent.get('status') if parent and 'status' not in record else None},
        'scopeClassification': 'adjacent-boundary-preserved' if adjacent else 'direct-finite-transfer',
        'semanticReviewStatus': 'reviewed', 'conclusion': 'consistent',
        'conclusionScope': ('Confirmed source-location error corrected to the actual Controller; policy/type/operator/maturity unchanged.' if changed
                            else 'Current confirmed boundary retained; this slice does not re-accept the full START/work matrix.' if adjacent
                            else 'Existing eligible-membership, unique ownership or transaction/confirmation/three-side audit meaning retained within this transfer slice.'),
        'remediation': 'source-location-corrected' if changed else 'retained',
        'originalEvidenceReferences': adjacent_refs if adjacent else source_refs,
        'reviewNarrative': 'authority-review.md',
        'runtimeValidation': 'No product runtime executed by this ontology instance; parent raw evidence bound separately at FINAL.',
        'recordSnapshot': record,
    })

OUT.joinpath('finite-review-records.json').write_text(json.dumps({
    'status': 'PREPARED-awaiting-final-source-binding', 'fixedBaseline': BASE,
    'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0',
    'counts': {'direct': len(PRIMARY), 'adjacent': len(ADJACENT), 'reviewedRecords': len(rows),
               'consistentWithinFiniteScope': len(rows), 'knowledgeRecordsSourceCorrected': 2,
               'wholeFileCompleted': 0, 'historicalUnique': None},
    'notFullAuditCoverage': True, 'records': rows,
}, ensure_ascii=False, indent=2)+'\n')

path = 'docs/knowledge/facts/core-business.yaml'
before_doc = yaml.safe_load(subprocess.check_output(['git', 'show', BASE+':'+path], cwd=REPO))
before = {record['id']: record for record in before_doc['facts']}
after_doc = yaml.safe_load((REPO/path).read_text())
after = {record['id']: record for record in after_doc['facts']}
changes = []
for ident in sorted(before.keys() | after.keys()):
    if before.get(ident) != after.get(ident):
        fields = {key: {'before': before[ident].get(key), 'after': after[ident].get(key)}
                  for key in before[ident].keys() | after[ident].keys()
                  if before[ident].get(key) != after[ident].get(key)}
        changes.append({'id': ident, 'changedFields': fields})
assert sorted(c['id'] for c in changes) == sorted(CHANGED_IDS)
allowed = {'sourcePath', 'evidenceIds', 'sourceRevision', 'sourceLocator', 'capturedAt'}
assert all(set(c['changedFields']) == allowed for c in changes)
assert (REPO/after[CHANGED_IDS[0]]['sourcePath']).read_bytes() == subprocess.check_output(
    ['git', 'show', BASE+':'+after[CHANGED_IDS[0]]['sourcePath']], cwd=REPO)
OUT.joinpath('fact-source-correction.json').write_text(json.dumps({
    'classification': 'confirmed-current-source-location-record-error',
    'beforeGitCommit': BASE, 'sourceCodeVerifiedAt': BASE,
    'semanticPolicyChanged': False, 'maturityChanged': False,
    'permittedChangedFields': sorted(allowed), 'changes': changes,
}, ensure_ascii=False, indent=2)+'\n')
OUT.joinpath('knowledge-source-correction.diff').write_bytes(subprocess.check_output(
    ['git', 'diff', BASE, '--', path], cwd=REPO))

tracked = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, 'docs/knowledge'], cwd=REPO).decode().splitlines()
paths = sorted(str(p.relative_to(REPO)) for p in (REPO/'docs/knowledge').rglob('*') if p.is_file())
assert tracked == paths and len(paths) == 350
inventory = []
for path in paths:
    original = subprocess.check_output(['git', 'show', BASE+':'+path], cwd=REPO)
    actual = (REPO/path).read_bytes()
    inventory.append({'path': path, 'bytes': len(actual), 'sha256': hashlib.sha256(actual).hexdigest(),
                      'baselineSha256': hashlib.sha256(original).hexdigest(), 'sameBytes': actual == original})
assert [r['path'] for r in inventory if not r['sameBytes']] == ['docs/knowledge/facts/core-business.yaml']
manifest = ''.join(r['sha256']+'  '+r['path']+'\n' for r in inventory)
OUT.joinpath('knowledge-after.sha256').write_text(manifest)
OUT.joinpath('knowledge-after.json').write_text(json.dumps({
    'status': 'PREPARED-awaiting-final-source-binding', 'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'fixedSourceTargetContract': BASE, 'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0',
    'roadmap': 'P0/in-progress', 'files': 350, 'yamlFiles': 259, 'unchangedFiles': 349, 'changedFiles': 1,
    'manifestAlgorithm': 'sha256 over sorted sha256sum-form lines (sha256 + two spaces + relative path + LF)',
    'manifestSha256': hashlib.sha256(manifest.encode()).hexdigest(),
    'inventoryOnlyNotWholeFileReview': True, 'records': inventory,
}, ensure_ascii=False, indent=2)+'\n')

for report in (REPO/'tools/knowledge-model/target/surefire-reports').glob('*BusinessKnowledgeModelTest*'):
    shutil.copy2(report, OUT/report.name)
report = OUT/'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
attrs = ET.parse(report).getroot().attrib
result = {'phase': 'final-after-two-fact-source-correction',
          'actualCommand': ['bash', '/workspace/.edhr-cloud-tools/mvn-edhr', '--batch-mode', '--no-transfer-progress', '--file', 'tools/knowledge-model/pom.xml', 'clean', 'test'],
          'exitCode': 0, **{key: int(attrs[key]) for key in ['tests', 'failures', 'errors', 'skipped']},
          'correctedKnowledgeManifestSha256': hashlib.sha256(manifest.encode()).hexdigest(),
          'notProductRuntimeValidation': True,
          'priorInvocation': 'knowledge-precheck-result.json; precheck passed before correction, retained separately',
          'launchFailure': 'knowledge-launch-failed.log; mvn absent from PATH, no Maven/test process started'}
assert result['tests'] == 89 and all(result[key] == 0 for key in ['failures', 'errors', 'skipped'])
assert 'BUILD SUCCESS' in (OUT/'knowledge89.log').read_text()
OUT.joinpath('knowledge-result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'reviewedRecords': len(rows), 'direct': len(PRIMARY), 'adjacent': len(ADJACENT),
                  'knowledgeFiles': 350, 'changedKnowledgeFiles': 1,
                  'knowledgeAfterManifestSha256': hashlib.sha256(manifest.encode()).hexdigest(),
                  'knowledgeTests': result['tests'], 'failures': 0, 'errors': 0, 'skipped': 0}, indent=2))
