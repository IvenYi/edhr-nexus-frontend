# 产品簇转移有限权威来源核对

状态：FINAL（本只读来源核对子任务）。日期：2026-11-07。

结论：本批删除后显式 `repository.flush()` 的单行改动落实既有唯一归属与事务性转移要求，未发现需要新增或替代业务政策的语义冲突。另有两条既有事实的实现来源定位可确定为错误，上级本体任务按主侧指示执行同批最小来源纠错；本只读子任务核实其纠错依据和语义保留范围，不修改仓库。不得从既有 `implemented/internal`、本报告或源码存在推导本批运行通过、`verified`、客户/运行知识发布或 P0 退出。最终知识字节、候选提交和实际运行结果由上级本体任务及独立质量角色分别绑定。

## 读取基线与范围

- 仓库 `/workspace/edhr-nexus-frontend`，分支 `audit/edhr-dev-family-membership-transfer-20261107`。
- 实际读取 HEAD、source、target、contractReadCommit：`04db7e838ec5e194355ff954ff173a02205e0fd6`；目标分支 `edhr-dev`；`uncommittedContractPaths: []`。
- 实际知识版本 `0.3.25`，schema `1.2.0`，P0 `in-progress`。已读 `AGENTS.md`、本体角色契约、统一交接契约、架构说明、knowledge README、完整 open-questions 及本批 decision-package。
- 核对时工作树包含主侧产品服务单行改动及新测试/开发文档，未冒充 clean 提交。服务基线字节 SHA-256 为 `7022cfe3002b51705452a1d63890693f999d1e94c1ef1487923753db51e6e41e`，读取候选服务为 `c990a1b99e0afea7487e57df2eb8d8f9ee40890b6d098e19765af24c4eb90bd0`。`git diff` 显示产品服务唯一变更是在 `delete(existing)` 后新增 `productFamilyMemberRepository.flush()`。
- 启动核对时对契约、`docs/knowledge/**` 及本体架构说明相对固定基线的 diff 为空；随后两事实来源纠错以本报告下文明确范围及上级最终差异为准。本报告不负责 350 资产指纹或正式 knowledge89，均由上级本体任务独立执行。

## 受影响既有 ID

下表的成熟度是实际读取的现有值，业务语义与成熟度均保留；两事实来源定位的同批纠错另列，不是新成熟度批准。决策声明引用是当前权威定义，代码及 SQL 是原始实现证据。既有 evidence YAML 的说明仅作来源索引，旧测试源码不计为本次已运行测试。

| ID | 现有成熟度 | 有限核对结论及依据 |
|---|---|---|
| `DEC-0002-01` | implemented/internal | 保留半成品或产成品可成为产品簇成员；原始服务 `requireEligibleProduct/isEligibleMaterialType` 仍按物料类型名校验，两类以外拒绝。 |
| `DEC-0002-02` | implemented/internal | 保留一个产品最多一个簇；实体约束、仓储按 tenant/product 读取及 canonical PG `uk_product_family_member_tenant_product` 一致。 |
| `DEC-0002-11` | implemented/internal | 保留同事务、二次确认、不收原因、产品/旧簇/新簇审计；服务与控制器当前结构吻合。真实事务保证另取本批运行原件。 |
| `term.product-family` | implemented/internal | 定义为半成品/产成品集合且租户内最多一个簇，未改变。 |
| `concept.product-family` | implemented/internal | 仍沿已有概念及成员实体，无新概念、身份或独立状态。 |
| `relation.product-belongs-to-product-family` | implemented/internal | `one-to-zero-or-one` 保留，不将转移中 DELETE 发出误解为对外已提交的无归属状态。 |
| `relation.product-family-contains-products` | implemented/internal | `one-to-zero-or-many` 保留。 |
| `rule.product.source-from-material` | implemented/internal | 产品复用产成品/半成品物料身份；无重复产品主数据。 |
| `rule.product-family.membership-cardinality` | implemented/internal | 规则表达阻断 >=2 归属，DB 唯一索引保持；显式 flush 改 SQL 顺序，不放宽唯一约束。 |
| `rule.product-family.member-transfer-audit` | implemented/internal | `transactionRequired: true`、`reasonField: not-collected`、三方审计主体保持，未登记新通用执行契约。 |
| `rule.product-family.member-audit-customer-labels` | implemented/internal | 原审计内部键 `memberProductId/memberProductCode/memberProductName` 保留；本批不改审计显示。 |
| `fact.catalog.material-typename` | implemented/internal | 现有 string/in 事实定义保留；实际成员资格读取物料类型 ID 后取名称。 |
| `fact.catalog.product-productfamilycount` | implemented/internal | 现有 integer/>= 事实及唯一归属含义保留；本批不将泛化事实目录解释为已经注册的独立运行事实提供器。 |
| `fact.catalog.productfamilytransfer-confirmation` | implemented/internal | string/equals 及二次确认语义保留；错误来源由上级同批精确改至控制器转移入口，见下文。 |
| `fact.catalog.productfamilytransfer-reason` | implemented/internal | string/is-null 及不收原因语义保留；错误来源由上级同批改至无 reason 入参的控制器契约，见下文，不声称存在运行时 reason 读取。 |

`DEC-0002` 决策整体成熟度仍为 `specified/internal`，其部分声明 `implemented/internal` 不会把整份决策升级。

## 原始实现证据

- `gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java`：`transferMember` 为 `@Transactional`；查询并拒绝未归属产品；目标同簇直接返回旧成员；跨簇先取旧簇，删除旧成员后 flush，再用新 Snowflake ID 创建新成员。`createdBy/updatedBy` 仍取当前 AuditContext 身份，`ProductFamilyMember.@PrePersist` 继续产生新 created/updated 时间。没有改为原位 UPDATE。
- 同服务 `writeMembershipAudits`：产品审计 old->new；旧簇 member->`{}`；新簇 `{}`->member。审计 action 为原 `UPDATE`，内容键、module/menu/function、操作人 ID/姓名/账号、source/IP 均保持。本批 diff 未触及审计内容或 hash 处理。
- `gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java:427`：转移入口继续要求 `master-data.product-families`，`confirmed` 默认 false，并调用 `requireConfirmed`；无 reason 参数。控制器及服务事务注解保持。
- `gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java` 与 `repository/ProductFamilyMemberRepository.java`：租户产品唯一、成员身份、租户产品读取保持。服务本批仍使用既有默认租户，不能据索引宣称完整多租户矩阵已验证。
- `gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql:867` 与 `:2008`：canonical 成员表及 tenant/product 唯一索引是当前数据库结构原件。`src/test/resources/db/changelog/0053-product-family-process-owner.sql` 为既有历史迁移/测试证据，不用它替代 canonical 结构或真实 PG 运行。
- `gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductProcessResolutionService.java`：新候选产品可用版本优先，无产品可用版本时才查当前簇兜底；`findVersionForProduct` 独立复核既有簇引用归属。服务未包含转移 `confirmed` 或 reason 读取。

## 相邻边界保留

| ID | 现有成熟度 | 本批保留范围 |
|---|---|---|
| `DEC-0002-10`、`rule.product-family.member-transfer-future-only` | specified/internal | 旧未开工引用保留，首次合法 START 按当前归属、时间、形态重核冻结；不适用需明确重选；已开工快照不回写；新增自有制程不否定合法旧簇引用。依据当前定义及 `evidence/batch-process-2026-10-27.md` 的既有用户确认，不重新验收整条 START 矩阵。 |
| `DEC-0002-06/07`、`rule.product-process.product-version-takes-precedence`、`rule.product-process.product-family-fallback` | implemented/internal | 新候选产品优先/簇兜底含义保持，不自动迁移既有引用。 |
| `DEC-0007-03/04`、`rule.production-work.instance-auto-matches-applicability`、`rule.production-work.instance-freezes-work-and-rule-snapshot` | specified/internal | 当前簇/规则匹配后续工序，已过站不补做；已创建实例包括零业务节点执行实例保留原图、表单、进度与归属。原话来源 `evidence/work-live-matching-2026-10-26.md`，不回写历史原件。 |

Open questions 中作业运行来源/快照、求值异常/推进、分支绑定以及完整多租户等未决继续保留。没有新的产品簇转移业务歧义。全审 W2-W7、931 知识/86 UI、A12、高风险、完整矩阵、A23 及暂停队列均未关闭；wholefile 审查数为 0，historicalunique 未统计。

## 来源定位缺口与交接

既有 `facts/core-business.yaml:1237` 的 `fact.catalog.productfamilytransfer-confirmation` 和 `:1253` 的 `fact.catalog.productfamilytransfer-reason`，`sourcePath` 和 `evidenceIds` 均指向 `ProductProcessResolutionService`/`evidence.product-process-resolution-service`；该原始源码没有确认参数、转移命令或原因读取。实际确认在 `ProcessModelingController.transferProductFamilyMember`，无原因字段及事务/审计组合由控制器和 `ProductFamilyMembershipService` 共同证明。因此这两条记录的来源定位有既有证据质量缺口，不能仅因原 `reviewStatus: reviewed` 将其判为来源准确。

此错误不产生两种互斥业务政策，也不改变本批单行修复的业务验收。上级按主侧指示同批执行最小纠错：仅将两 fact 的 `sourcePath` 改至 `ProcessModelingController.java`，`evidenceIds` 复用现有 `evidence.process-modeling-controller`，`sourceLocator` 精确记录 `transferProductFamilyMember` 的 confirmed 默认 false、`requireConfirmed` 调用和无 reason 入参；`sourceRevision` 固定为实际核对的 `04db7e838ec5e194355ff954ff173a02205e0fd6`，`capturedAt` 记录本次实际核对日。原标签、类型、别名、操作符、规范含义、成熟度和 visibility 均不变。历史 Git 原件继续解释纠正前来源，不虚构新政策、reason 对象属性读取或一次历史运行。此拟定改法与本实例实际读到的原始代码一致；最终知识 diff、指纹和验证由上级一次源绑定。

本实例未运行应用、数据库、HTTP、浏览器、Maven、knowledge89 或 CI，也未读取主侧日志并转述为本实例独立运行。负对照的 9P/3assertF/1真实 DataIntegrityViolation E、修复后成功/失败回滚/隔离结果均须保留主侧原件并由上级按实际记录引用。未修改 repo 产品、测试、fixture、迁移、配置或知识文件。
