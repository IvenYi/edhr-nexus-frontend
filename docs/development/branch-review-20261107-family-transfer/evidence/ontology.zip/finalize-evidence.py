from pathlib import Path
import argparse
import datetime
import hashlib
import json
import subprocess
import yaml

parser = argparse.ArgumentParser()
parser.add_argument('--source-commit', required=True)
parser.add_argument('--product-evidence', required=True)
args = parser.parse_args()
repo = Path('/workspace/edhr-nexus-frontend')
out = Path('/tmp/edhr-family-transfer-ontology-20261107')
base = '04db7e838ec5e194355ff954ff173a02205e0fd6'
product_dir = Path(args.product_evidence)
now = datetime.datetime.now(datetime.timezone.utc).isoformat()

def git(*params):
    return subprocess.check_output(['git', *params], cwd=repo).decode().strip()

def digest(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD') == args.source_commit
assert not git('status', '--porcelain'), 'Final source binding requires the parent-provided clean commit.'
contracts = ['AGENTS.md', 'docs/agents/business-knowledge-modeler.md',
             'docs/agents/agent-handoff-contract.md', 'docs/architecture/business-knowledge-model.md',
             'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml', 'docs/knowledge/schema.yaml']
assert not git('diff', '--name-only', base, args.source_commit, '--', *contracts)
before = json.loads((out/'knowledge-before.json').read_text())
after = json.loads((out/'knowledge-after.json').read_text())
for record in after['records']:
    assert digest((repo/record['path']).read_bytes()) == record['sha256'], record['path']
knowledge_paths = sorted(str(p.relative_to(repo)) for p in (repo/'docs/knowledge').rglob('*') if p.is_file())
assert knowledge_paths == [r['path'] for r in after['records']]
changed_knowledge = git('diff', '--name-only', base, args.source_commit, '--', 'docs/knowledge').splitlines()
assert changed_knowledge == ['docs/knowledge/facts/core-business.yaml']

run = json.loads((product_dir/'run.json').read_text())
summary = json.loads((product_dir/'test-summary.json').read_text())
totals = summary['totals']
assert run['exitCode'] == 0
assert not summary['missingFreshReports']
assert totals['tests'] > 0 and all(totals[key] == 0 for key in ['failures', 'errors', 'skipped'])
source_comparisons = []
document_deltas = []
for record in run['sourceFingerprints']:
    actual = (repo/record['path']).read_bytes()
    matched = digest(actual) == record['sha256']
    if record['path'].startswith('gmp-platform/'):
        assert matched, record['path']
    elif not matched:
        document_deltas.append(record['path'])
    source_comparisons.append({'path': record['path'], 'testedSha256': record['sha256'],
                               'finalSha256': digest(actual), 'sameBytes': matched})
negative_dir = Path('/tmp/edhr-family-transfer-20261107/negative')
negative = json.loads((negative_dir/'test-summary.json').read_text())
assert negative['totals'] == {'tests': 13, 'failures': 3, 'errors': 1, 'skipped': 0}
service_path = 'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (negative_dir/'source'/service_path).read_bytes() == subprocess.check_output(['git', 'show', base+':'+service_path], cwd=repo)
service_diff = git('diff', base, args.source_commit, '--', service_path)
assert service_diff.count('+        productFamilyMemberRepository.flush();') == 1
assert [line for line in service_diff.splitlines() if line.startswith('+') and not line.startswith('+++')] == ['+        productFamilyMemberRepository.flush();']
assert not [line for line in service_diff.splitlines() if line.startswith('-') and not line.startswith('---')]
product_hashes = []
for path in sorted(product_dir.rglob('*')):
    if path.is_file() and path.suffix in ['.json', '.xml', '.log']:
        data = path.read_bytes()
        product_hashes.append({'path': str(path), 'bytes': len(data), 'sha256': digest(data)})
binding = {
    'status': 'FINAL', 'boundAt': now, 'sourceCommit': args.source_commit,
    'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'cleanWorkingTree': True,
    'targetBranch': 'edhr-dev', 'targetCommit': base, 'contractReadCommit': base,
    'contractDeltaPaths': [], 'knowledgeFiles': 350, 'knowledgeManifestBefore': before['manifestSha256'],
    'knowledgeManifestAfter': after['manifestSha256'], 'changedKnowledgeFiles': changed_knowledge,
    'knowledgeBytesMatchFinalCommit': True, 'productCodeAndTestsMatchGreenRun': True,
    'parentProductEvidenceDirectory': str(product_dir), 'parentProductRunHead': run['head'],
    'parentProductRuntimeSummary': summary, 'productSourceComparisons': source_comparisons,
    'documentDeltasSinceProductRun': document_deltas,
    'productRuntimeExecutedByOntologyRole': False,
    'negativeSummaryPreserved': negative, 'negativeErrorClassification': 'real-product-unique-constraint-DataIntegrityViolationException',
    'parentProductRawArtifacts': product_hashes,
}
(out/'source-binding.json').write_text(json.dumps(binding, ensure_ascii=False, indent=2)+'\n')
records = json.loads((out/'finite-review-records.json').read_text())
records['status'] = 'FINAL'
records['sourceCommit'] = args.source_commit
records['sourceBinding'] = 'source-binding.json'
(out/'finite-review-records.json').write_text(json.dumps(records, ensure_ascii=False, indent=2)+'\n')

sync = []
for ident in ['fact.catalog.productfamilytransfer-confirmation', 'fact.catalog.productfamilytransfer-reason']:
    sync.append({'id': ident, 'disposition': 'updated',
                 'scope': '仅纠正来源路径/证据/定位及实际核对provenance，保留规范、类型、操作符、别名和implemented/internal；不注册通用事实求值。',
                 'sourceReferences': ['docs/knowledge/facts/core-business.yaml',
                                      'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java',
                                      str(out/'fact-source-correction.json')]})
for ident, scope in [
    ('DEC-0002-01', '保留半成品/产成品成员资格。'),
    ('DEC-0002-02', '保留每产品最多一个簇；不放宽tenant/product唯一约束。'),
    ('DEC-0002-11', '保留同事务、二次确认、不收原因、产品旧簇新簇三方审计；flush不是commit。'),
    ('DEC-0002-10', '保留未开工首次START当前归属/有效期/形态重核冻结与已开工不改；不重验完整START矩阵。'),
    ('DEC-0007-03', '保留后续工序按当前上下文/簇匹配，已过站不补做。'),
    ('DEC-0007-04', '保留已创建实例原快照及归属，含零业务节点执行的实例。'),
]:
    sync.append({'id': ident, 'disposition': 'retained', 'scope': scope,
                 'sourceReferences': ['docs/knowledge/decisions/DEC-0002-product-family-process-modeling.yaml' if ident.startswith('DEC-0002') else 'docs/knowledge/decisions/DEC-0007-production-work-applicability-and-runtime-snapshot.yaml',
                                      str(out/'finite-review-records.json')]})
result = {'ontologyResult': {
    'result': 'updated', 'baselineBefore': '0.3.25', 'baselineAfter': '0.3.25',
    'contractBaseline': {'sourceCommit': args.source_commit, 'targetBranch': 'edhr-dev',
                         'targetCommit': base, 'contractReadCommit': base, 'uncommittedContractPaths': []},
    'reason': '产品单行flush落实既有事务转移政策；有限核对中两条transfer fact存在确定来源定位错误，已同批最小纠正。业务语义、类型、成熟度、schema及P0阶段保持。',
    'changedArtifacts': [{'path': 'docs/knowledge/facts/core-business.yaml', 'changeType': 'update',
                          'ids': ['fact.catalog.productfamilytransfer-confirmation', 'fact.catalog.productfamilytransfer-reason']}],
    'knowledgeSync': sync, 'conflicts': [], 'questions': [],
    'validationEvidence': [
        {'id': 'validation.family-transfer.knowledge89', 'checkType': 'schema',
         'command': 'bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress --file tools/knowledge-model/pom.xml clean test',
         'outcome': 'passed', 'evidence': [str(out/'knowledge89.log'), str(out/'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'), str(out/'knowledge-result.json'), '纠正后89项、0 failure、0 error、0 skipped；纠正前precheck单独保留。']},
        {'id': 'validation.family-transfer.source-reference', 'checkType': 'reference',
         'command': 'python3 /tmp/edhr-family-transfer-ontology-20261107/build-evidence.py',
         'outcome': 'passed', 'evidence': [str(out/'fact-source-correction.json'), str(out/'knowledge-source-correction.diff'), str(out/'authority-review.md'), '仅2个ID的sourcePath/evidenceIds/sourceRevision/sourceLocator/capturedAt改变，其余字段保持。']},
        {'id': 'validation.family-transfer.maturity-preserved', 'checkType': 'status-transition',
         'command': '比较两fact前后全部字段与28项有限记录；检查schema/status及投影边界',
         'outcome': 'passed', 'evidence': [str(out/'fact-source-correction.json'), str(out/'finite-review-records.json'), '知识0.3.25/schema1.2.0/P0 in-progress保持，无verified或customer/runtime提升。']},
        {'id': 'validation.family-transfer.final-source-binding', 'checkType': 'evidence-path',
         'command': f'python3 {out}/finalize-evidence.py --source-commit {args.source_commit} --product-evidence {product_dir}',
         'outcome': 'passed', 'evidence': [str(out/'source-binding.json'), str(out/'knowledge-before.json'), str(out/'knowledge-after.json'), f'最终clean源{args.source_commit}，350知识文件逐字节绑定；产品绿原件为主侧执行，本体未代跑。']},
    ],
    'roadmapProgress': {'stage': 'P0', 'status': 'in-progress', 'exitCriteriaEvidence': [], 'deferredStages': ['P1', 'P2', 'P3']},
}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(result, allow_unicode=True, sort_keys=False, width=120))
review = (out/'REVIEW.PREPARED.md').read_text()
review = review.replace('状态：PREPARED，等待主侧最终 clean 提交与产品运行原件的一次增量源绑定。',
                        f'状态：FINAL。最终 clean 来源提交 `{args.source_commit}`；目标/契约保持 `{base}`。')
review = review.replace('最终功能提交尚未收到，不能以本准备记录替代最终源绑定。',
                        '最终源码已增量核对：契约无增量、知识字节与纠正后89项验证一致，产品源码/测试与主侧绿运行原件逐字节一致；详见 `source-binding.json`。')
review = review.replace('修复后产品结果须等待主侧实际最终原件绑定。',
                        f'修复后主侧最终运行原件 `{product_dir}` 为 {totals["tests"]} 项、0 failure、0 error、0 skipped，已核对新ID/三方审计、失败回滚及提交前隔离的13项新测试与相邻回归；本角色只读取并绑定该原件，未独立执行。')
review += f'\n最终交付：`ontology-result.yaml` 为 updated；`finite-review-records.json` 为28项有限记录，`source-binding.json` 绑定 clean 源及主侧产品运行原件。主侧运行后仅文档差异为 {document_deltas!r}；产品/测试/结构字节全部相同。本次有限完成不代表全量知识审计或质量角色通过，亦不构成merge授权。\n'
(out/'REVIEW.md').write_text(review)
(out/'result.json').write_text(json.dumps({'status': 'FINAL', 'ontologyResult': 'updated', 'sourceCommit': args.source_commit,
    'knowledgeFiles': 350, 'changedKnowledgeFiles': 1, 'sourceCorrectedFacts': 2,
    'finiteReviewedRecords': 28, 'wholeFileCompleted': 0, 'historicalUnique': None,
    'knowledgeTests': {'tests': 89, 'failures': 0, 'errors': 0, 'skipped': 0},
    'parentProductEvidence': str(product_dir), 'parentProductTests': totals,
    'productRuntimeExecutedByOntologyRole': False, 'child': {'task': 'family_transfer_authority', 'status': 'FINAL', 'evidence': 'authority-review.md'},
    'preservedQueues': ['W2-W7', '931 knowledge / 86 UI', 'A12', 'high-risk', 'full matrices', 'A23 including previously reviewed', 'paused queues', 'bulk prevalidation optimization'],
}, ensure_ascii=False, indent=2)+'\n')
sources = contracts + [
    'docs/development/branch-review-20261107-family-transfer/decision-package.yaml',
    'docs/knowledge/decisions/DEC-0002-product-family-process-modeling.yaml',
    'docs/knowledge/decisions/DEC-0007-production-work-applicability-and-runtime-snapshot.yaml',
    'docs/knowledge/facts/core-business.yaml', 'docs/knowledge/rules/product-process.yaml',
    service_path,
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/entity/ProductFamilyMember.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/repository/ProductFamilyMemberRepository.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductProcessResolutionService.java',
    'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java',
]
source_records = []
for path in sources:
    data = (repo/path).read_bytes()
    source_records.append({'path': path, 'sourceCommit': args.source_commit, 'gitBlob': git('rev-parse', f'{args.source_commit}:{path}'),
                           'bytes': len(data), 'sha256': digest(data), 'coverage': 'finite-scope/reference; not whole-file review completion'})
artifacts = []
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name != 'manifest.json':
        data = path.read_bytes()
        artifacts.append({'path': str(path.relative_to(out)), 'bytes': len(data), 'sha256': digest(data)})
(out/'manifest.json').write_text(json.dumps({'status': 'FINAL', 'createdAt': now, 'sourceCommit': args.source_commit,
    'targetCommit': base, 'contractReadCommit': base, 'sourceTree': git('rev-parse', 'HEAD^{tree}'),
    'knowledgeFiles': 350, 'knowledgeBeforeManifestSha256': before['manifestSha256'], 'knowledgeAfterManifestSha256': after['manifestSha256'],
    'wholeFileCompleted': 0, 'historicalUnique': None, 'sourceInputs': source_records, 'artifacts': artifacts,
    'note': 'Full bytes are pinned; pinning does not count as whole-file semantic review. Product runtime raw evidence belongs to parent; no CI/merge/deploy performed.',
}, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'status': 'FINAL', 'sourceCommit': args.source_commit, 'ontologyResult': 'updated',
                  'productTests': totals, 'knowledgeFiles': 350, 'finiteRecords': 28,
                  'knowledgeAfterManifestSha256': after['manifestSha256'], 'artifacts': len(artifacts)}, indent=2))
