from pathlib import Path
import subprocess,hashlib,json,datetime
ROOT=Path('/workspace/edhr-nexus-frontend');OUT=Path('/tmp/edhr-family-transfer-import-clean-20261107')
JAVAP='/workspace/.edhr-cloud-tools/jdk-21/bin/javap'
TEST='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'
OLD='1709dbc4d3d28d8721ff001b69ad934a6de54d18'
old=subprocess.check_output(['git','show',OLD+':'+TEST],cwd=ROOT)
new=(ROOT/TEST).read_bytes();assert new==old.replace(b'import java.util.concurrent.atomic.AtomicInteger;\n',b'',1)
(OUT/'before.java').write_bytes(old);(OUT/'after.java').write_bytes(new)
classes=sorted((ROOT/'gmp-platform/backend/target/test-classes/com/zencas/edhr/masterdata/service').glob('ProductFamilyTransferPostgresTest*.class'))
assert len(classes)==3
def snap(phase):
    folder=OUT/phase;folder.mkdir(exist_ok=True);vals={}
    for c in classes:
        data=subprocess.check_output([JAVAP,'-c','-p','-s','-constants',str(c)],text=True)
        (folder/(c.name+'.javap.txt')).write_text(data);vals[c.name]=hashlib.sha256(data.encode()).hexdigest()
    return vals
before=snap('before')
command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','test-compile']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (OUT/'test-compile.log').open('w') as f: result=subprocess.run(command,cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
assert result.returncode==0
after=snap('after');assert before==after,(before,after)
record=dict(sourceBefore=OLD,command=command,startedAt=started,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=result.returncode,onlyChange='Remove unused AtomicInteger import from new test',sourceBeforeSha256=hashlib.sha256(old).hexdigest(),sourceAfterSha256=hashlib.sha256(new).hexdigest(),javapBefore=before,javapAfter=after,allThreeClassInstructionOutputsIdentical=True,noRuntimeTestsRepeated=True,limitations='javap comparison excludes debug/line-number tables; identical source except unused import is also asserted. Original156 runtime and89 knowledge remain bound to original source. New compile plus independent change-impact evaluation validates import-only increment.')
(OUT/'verification.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
