# 有限历史去重与转移切片辅助

本实例只读源码与历史台账，不是最终独立质量验收，没有运行应用、Maven、数据库或浏览器，没有修改仓库产品、测试、配置或知识。固定目标04db7e838ec5e194355ff954ff173a02205e0fd6；工作树实际HEAD42bd62cc796feefa626384461b33d958f01aac14，git diff两提交为空。知识0.3.25/schema1.2.0/P0。

## 当前单切片的证据

- original-evidence：ProductFamilyMembershipService.java:83-102使用事务，读当前成员，跨簇时delete(existing)，随后save一个新Snowflake id，但中间没有显式flush。
- original-evidence：ProductFamilyMember.java:22-24与baseline/0001-current-schema.sql:2006-2008都有tenant/product唯一约束；原行删除未冲入数据库时，新行insert会与原行争用同一唯一键。Hibernate flush动作顺序是待主侧真实JPA/PG验证的推断，不冒称本实例已复现。
- user-confirmed authority：DEC-0002-11（decision yaml:49-52）要求成员转移以事务、二次确认、无原因和三对象审计完成；scenario.product-family-transfer:111-114同样明确允许跨簇转移。DEC-0002-10现行内容已按20261027确认替代旧对象上下文政策，与本次成员写入flush问题不同根因。
- original-evidence：ProductFamilyMembershipServiceTest.java:78-104只有Mockito repository，明确断言delete(existing)、新id301、三条审计；没有真实EntityManager、事务代理或唯一索引。ProcessModelingControllerTest.java:239-253整个service是mock。
- original-evidence：ProductionExecutionIntegrationTest.java:987/1008及BatchProcessIntegrationTest.java:156通过jdbc UPDATE现有关系模拟转簇；不调用transferMember，因此其通过不能反证delete+insert真实服务成功。

真实验证建议：原生PG完整baseline，真实Spring事务代理+JPA repository调用合法跨簇transferMember，事务完成后重新读取，验证旧关系消失、新id关系存在、产品/旧簇/新簇三条审计原子提交；同簇no-op作正对照，audit失败后旧关系保留且无新关系/审计作失败回滚。若红例证明flush顺序根因，最小方案是保留既有delete+新id语义，delete后同事务flush再save；不为了通过改成复用旧id或移除unique/拆事务，除非另有明确依据。

## 有限历史去陈旧

仅核对branch-review-20261015原findings/history及20261020—20261107相关scope/README/后续台账，不声称全历史unique或全文件完成。

- H009/H010：20261020-w3-write-boundaries及NEXT:675记录五类新写命令已按既有决策修复；不是当前开放切片。
- H012：原generic转办candidate来源问题已在同批按DEC0081租户内委托的精确范围解决/替代；原候选不应重开。
- H006：20261026-w4-lifecycle/findings.md仍open是当时快照；20261027-incremental/findings.md:12与README:24明确旧创建归属/工单锁版政策已被替代。不能按旧H006要求修当前行为。
- H007：20261026-w4-lifecycle正式独立b8804405 passed，闭缺失对象状态审计投影。
- H008：20261027-production-growth正式独立54daa6d7通过，SN模板三列差异关闭。
- 原findings.yaml中F004 pending是首批历史；NEXT后续已明确PR9修复合入，不能由旧pending重开。
- W5审计hash新行版本化封存、审计分页算术/动作筛选、页内批量姓名已经后续验收关闭各自子项；事件全载DB分页仍待真实答复，不能混进当前修复。
- PR70-72临时ZIP/异步/JWT响应生命周期、签名密码页面和生产弹窗暂停、性能未答方案均排除本切片。

同项历史搜索：在docs/development/branch-review-*的md/yaml有限检索ProductFamilyMembershipService、transferMember、转移唯一约束、成员flush及相关unique名，未找到已处理同根项。此负检索只说明本次限定集合未命中，不证明全历史从未出现。
