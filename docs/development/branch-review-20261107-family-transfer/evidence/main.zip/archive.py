from pathlib import Path
import hashlib,json,zipfile,subprocess,shutil,sys
ROOT=Path('/workspace/edhr-nexus-frontend')
DEST=ROOT/'docs/development/branch-review-20261107-family-transfer'
OUT=DEST/'evidence';OUT.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
def archive(label,source):
    source=Path(source); members=[]
    if (source/'manifest.json').is_file():
        m=json.loads((source/'manifest.json').read_text())
        for a in m.get('artifacts',[]):
            if not isinstance(a,dict):continue
            assert sha((source/a['path']).read_bytes())==a['sha256'],a['path']
        for a in m.get('sourceInputs',[]):
            if 'sourceCommit' in a:
                b=subprocess.check_output(['git','show',a['sourceCommit']+':'+a['path']],cwd=ROOT)
                assert sha(b)==a['sha256'],a['path']
    target=OUT/(label+'.zip')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(source.rglob('*')):
            assert not p.is_symlink(),str(p)
            if not p.is_file():continue
            rel=str(p.relative_to(source));b=p.read_bytes();z.writestr(rel,b)
            members.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(members)==len(set(z.namelist()))
        for f in members:assert sha(z.read(f['path']))==f['sha256'],f['path']
        assert z.testzip() is None
    doc=dict(sourceDirectory=str(source),archive=target.name,archiveBytes=target.stat().st_size,archiveSha256=sha(target.read_bytes()),memberCount=len(members),members=members)
    (OUT/(label+'-manifest.json')).write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n')
    print(label,len(members),target.stat().st_size,doc['archiveSha256'])
if len(sys.argv)>1:
    archive(sys.argv[1],sys.argv[2])
else:
    shutil.copy2('/tmp/edhr-family-transfer-20261107/main-analysis.json',DEST/'main-analysis.json')
    shutil.copy2('/tmp/edhr-audit-queue-source-20261107/REVIEW.md',DEST/'source-review.md')
    shutil.copy2('/tmp/edhr-family-transfer-ontology-20261107/REVIEW.md',DEST/'ontology-review.md')
    shutil.copy2('/tmp/edhr-family-transfer-ontology-20261107/ontology-result.yaml',DEST/'ontology-result.yaml')
    archive('main','/tmp/edhr-family-transfer-20261107')
    archive('source','/tmp/edhr-audit-queue-source-20261107')
    archive('ontology','/tmp/edhr-family-transfer-ontology-20261107')
