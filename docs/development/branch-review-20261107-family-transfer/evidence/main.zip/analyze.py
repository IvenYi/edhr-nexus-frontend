from pathlib import Path
import json, re, hashlib, subprocess, collections, decimal, datetime

RAW=Path('/tmp/edhr-family-transfer-20261107')
ROOT=Path('/workspace/edhr-nexus-frontend')
BASE='04db7e838ec5e194355ff954ff173a02205e0fd6'
CANDIDATE='1709dbc4d3d28d8721ff001b69ad934a6de54d18'
def load(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def canonical(v):
    if isinstance(v,dict): return '{'+','.join(json.dumps(k,ensure_ascii=False)+':'+canonical(v[k]) for k in sorted(v))+'}'
    if isinstance(v,list): return '['+','.join(canonical(x) for x in v)+']'
    if isinstance(v,bool) or v is None or isinstance(v,str): return json.dumps(v,ensure_ascii=False,separators=(',',':'))
    return str(decimal.Decimal(str(v)).normalize())
def audit_hash(a):
    # This fixture has ordinary UTF-8, in-range text and integral JSON; no general replacement for the product codec.
    tm=datetime.datetime.fromisoformat(a['created_at']).isoformat(timespec='microseconds')
    vals=['audit-event-v2',str(a['id'])]+[a[k] for k in ['tenant_id','entity_type','entity_id','action']]
    vals += [[a[k]] if a[k] is not None else None for k in ['content_before','content_after']]
    vals += [a[k] for k in ['operator_id','operator_name','operator_account','source','module_name','menu_name','function_name','data_summary','reason','ip_address']]+[tm]
    return sha(canonical(vals).encode())

run=load(RAW/'verified/run.json')
for f in run['sourceFingerprints']:
    assert sha((ROOT/f['path']).read_bytes())==f['sha256'],f['path']
    assert sha(subprocess.check_output(['git','show',CANDIDATE+':'+f['path']],cwd=ROOT))==f['sha256'],f['path']
test='gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/service/ProductFamilyTransferPostgresTest.java'
svc='gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java'
assert (RAW/'negative/source'/test).read_bytes()==(ROOT/test).read_bytes()
assert (RAW/'negative/source'/svc).read_bytes()==subprocess.check_output(['git','show',BASE+':'+svc],cwd=ROOT)
expected={'negative':dict(tests=13,failures=3,errors=1,skipped=0),'retry':dict(tests=156,failures=0,errors=0,skipped=2),'verified':dict(tests=156,failures=0,errors=0,skipped=0)}
for phase,t in expected.items(): assert load(RAW/phase/'test-summary.json')['totals']==t
assert 'uk_product_family_member_tenant_product' in (RAW/'negative/maven.log').read_text()
results={}
for phase in ['negative','verified']:
    text=(RAW/phase/'postgres.log').read_text(); executions=[]
    for line in text.splitlines():
        m=re.search(r' Driver (\d+) LOG: .*execute [^:]+: /\* family-transfer:([^ ]+) \*/\s+(select|insert|delete)([^\n]*)',line,re.I)
        if m: executions.append(dict(tx=m[1],tag=m[2],action=m[3],tail=m[4].strip()))
    observations={p.stem:load(p) for p in (RAW/phase/'observations').glob('*.json')}
    counts={}
    for n in [1,10,100]:
        tag='bulk-'+str(n); obs=observations[tag]; events=[e for e in executions if e['tag']==tag]
        counts[tag]=sum(e['action']=='select' for e in events)
        assert counts[tag]==obs['selectCalls']==6*n+2
        assert len(json.loads(obs['committedAudits']))==2*n
        assert len([m for m in json.loads(obs['committedMembers']) if m['product_family_id']==12])==n
        assert sum(e['action']=='insert' and e['tail'].startswith('into product_family_member') for e in events)==n
        assert sum(e['action']=='insert' and e['tail'].startswith('into audit_event') for e in events)==2*n
    mutation_orders={}
    for tag in ['native-transfer','http-transfer','uncommitted-transfer','audit-failure','member-failure']:
        es=[e for e in executions if e['tag']==tag and e['action']!='select']
        mutation_orders[tag]=es
        obs=observations[tag]; mm=json.loads(obs['committedMembers']); aa=json.loads(obs['committedAudits'])
        order=[e['action']+' '+e['tail'].split()[1 if e['action'] in ['delete','insert'] else 0] for e in es]
        if phase=='negative':
            assert mm[0]['id']==201 and mm[0]['product_family_id']==11 and aa==[]
            assert not es # Failed INSERT is ERROR/STATEMENT, not successful execute.
        elif tag in ['native-transfer','http-transfer','uncommitted-transfer']:
            assert len(mm)==1 and mm[0]['id']!=201 and mm[0]['product_family_id']==12
            assert order==['delete product_family_member','insert product_family_member']+['insert audit_event']*3
            assert len({e['tx'] for e in es})==1 and es[0]['tx']!='0'
            assert {(a['entity_type'],a['entity_id']) for a in aa}=={('PRODUCT','101'),('PRODUCT_FAMILY','11'),('PRODUCT_FAMILY','12')}
            assert len(aa)==3
        else:
            assert mm[0]['id']==201 and mm[0]['product_family_id']==11 and aa==[]
            assert order==(['delete product_family_member','insert product_family_member']+['insert audit_event']*2 if tag=='audit-failure' else ['delete product_family_member'])
            assert re.search(r'STATEMENT:  /\* family-transfer:'+tag+r' \*/ insert into',text)
    hash_count=0
    for tag,obs in observations.items():
        for a in json.loads(obs['committedAudits']):
            assert a['snapshot_hash_version']=='audit-event-v2'
            assert audit_hash(a)==a['snapshot_hash'],(phase,tag,a['id'])
            assert (a['operator_id'],a['operator_name'],a['operator_account'])==('901','簇成员审查员','family-transfer-qa')
            hash_count+=1
    results[phase]=dict(bulkSelectCounts=counts,successfulMutationExecutions=mutation_orders,persistedAuditHashesIndependentlyRecomputed=hash_count,observationFiles=len(observations))
for phase in ['negative','final','retry','verified']: assert load(RAW/phase/'cleanup.json')['removed'] is True
out=dict(baseCommit=BASE,testedCandidate=CANDIDATE,scope='finite W4 transfer order/atomicity and adjacent read observation',fingerprints=run['sourceFingerprints'],sameTestNegativeGreen=True,negativeProductMatchesBase=True,phases=expected,setupZeroJUnit='final: incorrect test class name in runner before Maven; not a product test failure',retrySkipped='Two existing growth observers not enabled; verified supplies original opt-in and pg_stat_statements; no assertions changed',sqlAndState=results,resources='All four owned disposable PG containers removed; worker executor joined by asserted test; MockMvc no HTTP port',limitations=['calling-thread tagged Hibernate SQL, fixtures/assert reads excluded; not all-network SQL','Failed statements are ERROR/STATEMENT, not successful execute; prepared/batched INSERT counts differ','Synthetic local fixtures; no production latency/SLA or complete concurrent writer/START matrix','Legacy repository6 use H2; transfer13 and Batch21 use canonical PG','No actual browser/socket login flow','Whole audit incomplete; no whole-file completion or historical unique count'],nextBatchAuthorization={'source':'user response to call_dad21472bffe4d2d8d878fa7adb7c04e','answer':'先批量化预校验读取（推荐）','scope':'Next batch only; preserve existing real-time recheck, writes and audit; current product unchanged'})
(RAW/'main-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{'bulk':v['bulkSelectCounts'],'hashes':v['persistedAuditHashesIndependentlyRecomputed']} for k,v in results.items()}))
