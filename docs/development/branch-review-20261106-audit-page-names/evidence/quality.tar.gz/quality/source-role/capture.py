from pathlib import Path
import subprocess,json,hashlib,re,datetime
r=Path('/tmp/edhr-audit-page-names-qa-worktree-20261106');out=Path('/tmp/edhr-audit-page-names-qa-source-20261106')
source='3c8e46943dbc3d02673d342e501b0884cb0c76dd';head='6fc13d2836629d6a6ae6d6a44e571f4220adb283';target='e69a8f3d97b34fea8737947c780b047bb0310c64'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==head;assert git('rev-parse','origin/edhr-dev')==target
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/development/branch-review-20261106-audit-page-names/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/UserAccount.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java']
manifest=[]
for revision in [source,head]:
 for p in paths:
  try:b=subprocess.check_output(['git','show',revision+':'+p],cwd=r,stderr=subprocess.DEVNULL)
  except subprocess.CalledProcessError:continue
  f=out/'source-snapshot'/revision/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
  manifest.append({'commit':revision,'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
controller=paths[9];old=(out/'source-snapshot'/source/controller).read_text();new=(out/'source-snapshot'/head/controller).read_text()
def method(text,name):
 match=re.search(r'^    (?:private|public) [^\n]+\b'+name+r'\(',text,re.M);assert match,name
 begin=text.index('{',match.start());depth=0
 for i in range(begin,len(text)):
  depth+=(text[i]=='{')-(text[i]=='}')
  if depth==0:return text[match.start():i+1]
 raise AssertionError(name)
unchanged=['listMyProfileLogs','findCurrentUser','blankToEmpty','matchesAuditText','resolveOperatorAccount','resolveActionLabel','resolveProjectedAction','isProductionEntity','resolveTriggerMethodLabel','resolveModuleName','resolveMenuName','resolveFunctionName','resolveDataSummary','normalizeEntityType','normalizeModuleLabel','resolveLeftSidebarModuleName','resolveMenuParent','resolveMenuLeaf','stripMenuPrefix','getById']
for name in unchanged:assert method(old,name)==method(new,name),name
newdto=method(new,'toAuditLogItem').replace('AuditEvent event, Map<String, String> operatorNames','AuditEvent event').replace('resolveOperatorDisplayName(event, operatorNames)','resolveOperatorDisplayName(event)')
assert method(old,'toAuditLogItem')==newdto
repo='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java'
assert subprocess.check_output(['git','show',source+':'+repo],cwd=r)==subprocess.check_output(['git','show',head+':'+repo],cwd=r)
protected=git('diff','--name-only',source,head,'--','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents','gmp-platform/frontend','gmp-platform/backend/src/main/resources');assert not protected
product=git('diff','--name-only',source,head,'--','gmp-platform/backend/src/main').splitlines();assert product==[controller,'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java']
(out/'product-diff.patch').write_text(git('diff',source,head,'--','gmp-platform/backend/src/main')+'\n')
result={'sourceReviewResult':'passed','scope':'read-only source equivalence subtask; not full independent runtime quality gate','finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':source,'headCommit':head,'targetCommit':target,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':head,'uncommittedContractPaths':[]},'knowledgeBaselineVersion':'0.3.25','sourceSnapshots':len(manifest),'unchangedMethodsVerified':unchanged,'dtoFieldsUnchangedExceptNameResolverInput':True,'existingActionSqlUnchangedInThisIncrement':True,'productChangedPaths':product,'protectedPathsChanged':[],'findings':[],'notExecuted':['JUnit','database/native SQL','browser','HTTP/JWT authorization matrix','load/concurrency/peak/RSS measurements','whole-branch or full-ontology audit'],'residualBoundaries':['full matching AuditEvent/JSON materialization retained','current displayName versus historical operatorName filtering policy remains existing evidence gap','global/detail authorization and full tenancy policy remain unchanged and not certified','query plan/index and database paging require separate design/evidence']}
(out/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'sourceSnapshots':len(manifest),'unchangedMethods':len(unchanged),'result':result['sourceReviewResult']},indent=2))
