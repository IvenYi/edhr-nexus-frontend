from pathlib import Path
import json,re,collections
out=Path('/tmp/edhr-audit-page-names-qa-20261106')
roots={'qa-final':out/'final','main-final':out/'parent-evidence/names/main/final','main-baseline':out/'parent-evidence/names/main/baseline'}
result={}
for label,p in roots.items():
    sql=collections.defaultdict(collections.Counter);bindings=collections.defaultdict(list)
    lines=(p/'postgres.log').read_text().splitlines()
    for i,line in enumerate(lines):
        m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*audit_read_([^*]+)\*/ (.*)$',line)
        if not m:continue
        event,statement=m.groups();normalized=re.sub(r'\$\d+','?',statement);sql[event][normalized]+=1
        if 'from user_account ' in statement and 'username in (' in statement:
            following=lines[i+1];assert 'DETAIL:  parameters:' in following
            values=re.findall(r"\$\d+ = '([^']*)'",following)
            assert len(values)==normalized.count('?')<=500
            bindings[event].append(values)
    cases=[]
    for f in sorted((p/'observations').glob('*.json')):
        a=json.loads(f.read_text())
        if 'sqlShapes' not in a:continue
        expected=collections.Counter({x['sql']:x['count'] for x in a['sqlShapes']})
        assert expected==sql[a['name']],(label,a['name'])
        assert sum(expected.values())==a['prepareStatements']
        assert all(x.startswith('select ') for x in expected)
        assert a['entityInserts']==a['entityUpdates']==a['entityDeletes']==0
        cases.append({'name':a['name'],'selectExecutions':a['prepareStatements'],'total':a['total'],'ids':a['ids'],'entityLoads':a['entityLoads'],'batchParameterCounts':[len(v) for v in bindings[a['name']]]})
    partial={k:sum(v.values()) for k,v in sql.items() if k not in {a['name'] for a in cases}}
    if label.endswith('final'):
        assert len(cases)==45;assert sum(a['selectExecutions'] for a in cases)==90;assert not partial
        for axis in ['shared','distinct','missing','blank']:
            for n in [100,1000,5000]:
                event=f'names_{axis}_{n}';actual=[v for batch in bindings[event] for v in batch]
                expected=['probe-1'] if axis=='shared' else ['-'] if axis=='blank' else [f'{"missing" if axis=="missing" else "probe"}-{i}' for i in range(n,n-20,-1)]
                assert actual==expected,(event,actual)
        assert [len(v) for v in bindings['names_large_first']]==[500,500,100]
        assert [len(v) for v in bindings['names_large_second']]==[105]
        assert [v for b in bindings['names_large_first'] for v in b]==[f'probe-{i}' for i in range(1205,105,-1)]
        assert [v for b in bindings['names_large_second'] for v in b]==[f'probe-{i}' for i in range(105,0,-1)]
        assert [v for b in bindings['names_off_page'] for v in b]==[f'probe-{i}' for i in range(50,30,-1)]
        assert [v for b in bindings['names_fallbacks'] for v in b]==['-','historical-id','老账号','probe-1']
        for event in ['names_filtered_empty','names_beyond_end','names_current_filter_empty']:assert not bindings[event]
    else:
        assert len(cases)==17;assert sum(a['selectExecutions'] for a in cases)==26628;assert partial=={'names_off_page':51}
    result[label]={'completedEvents':len(cases),'businessSelectExecutions':sum(a['selectExecutions'] for a in cases),'partialFailureEvents':partial,'exactSQLShapesAndCounts':True,'pageOnlyActualUsernameBindingsVerified':label.endswith('final'),'cases':cases}
assert result['qa-final']['cases']==result['main-final']['cases']
(out/'reconciliation.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:{a:b for a,b in v.items() if a!='cases'} for k,v in result.items()},indent=2))
