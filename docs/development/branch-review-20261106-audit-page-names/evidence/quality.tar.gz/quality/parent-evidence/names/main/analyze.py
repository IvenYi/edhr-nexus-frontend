from pathlib import Path
import json,re,collections,hashlib,subprocess,xml.etree.ElementTree as ET,shutil
r=Path('/workspace/edhr-nexus-frontend'); raw=Path('/tmp/edhr-audit-page-names-20261106')
out={'sourceHead':'3c8e46943dbc3d02673d342e501b0884cb0c76dd','target':'e69a8f3d97b34fea8737947c780b047bb0310c64','runs':{},'sql':{}}
for phase in ['baseline','final']:
 p=raw/phase;s=json.loads((p/'test-summary.json').read_text());out['runs'][phase]=s
 assert s['totals']==dict(tests=18,failures=16,errors=0,skipped=0) if phase=='baseline' else s['totals']==dict(tests=134,failures=0,errors=0,skipped=0)
 sql=collections.defaultdict(collections.Counter)
 for line in (p/'postgres.log').open():
  m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*audit_read_([^*]+)\*/ (.*)$',line)
  if m:sql[m[1]][re.sub(r'\$\d+','?',m[2])]+=1
 cases=[]
 for f in sorted((p/'observations').glob('*.json')):
  a=json.loads(f.read_text())
  if 'sqlShapes' not in a:continue
  expected=collections.Counter({x['sql']:x['count'] for x in a['sqlShapes']});assert expected==sql[a['name']],(phase,a['name'])
  assert sum(expected.values())==a['prepareStatements'];assert all(x.startswith('select ') for x in expected)
  assert a['entityInserts']==a['entityUpdates']==a['entityDeletes']==0
  item={k:a[k] for k in ['name','prepareStatements','entityLoads','total','ids','threadAllocatedBytes','elapsedNanos']}
  if phase=='final':
   batches=[{'parameters':x['sql'].count('?'),'executions':x['count']} for x in a['sqlShapes'] if 'from user_account' in x['sql'] and 'username in (' in x['sql']]
   assert all(x['parameters']<=500 for x in batches);item['nameBatches']=batches
  cases.append(item)
 orphan={k:sum(v.values()) for k,v in sql.items() if k not in {a['name'] for a in cases}}
 if phase=='final':assert not orphan;assert len(cases)==45;assert sum(a['prepareStatements'] for a in cases)==90
 else:assert set(orphan)=={'names_off_page'}
 out['sql'][phase]={'completedEvents':len(cases),'completedBusinessSelects':sum(a['prepareStatements'] for a in cases),'exactShapesMatch':True,'partialFailureEventSelects':orphan,'cases':cases}
name='AuditPageNamesPostgresTest.java';old=list((raw/'baseline/source').rglob(name))[0].read_bytes();new=list((raw/'final/source').rglob(name))[0].read_bytes();assert old==new
out['negativeTestSourceIdenticalSha256']=hashlib.sha256(old).hexdigest()
support='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditReadObservationPostgresTest.java';b=subprocess.check_output(['git','show',out['sourceHead']+':'+support],cwd=r);assert (r/support).read_bytes()==b
(raw/'baseline/support-from-fixed-git.java').write_bytes(b)
out['baselineFixtureProvenance']={'path':support,'sha256':hashlib.sha256(b).hexdigest(),'note':'Superclass source not snapshotted by initial baseline runner; recovered after run from fixed source commit, byte-identical to unchanged current tracked source. Baseline run status shows no modification to this file; not claimed as pre-run filesystem snapshot.'}
delta=[]
for x in json.loads((raw/'final/run.json').read_text())['sourceFingerprints']:
 if hashlib.sha256((r/x['path']).read_bytes()).hexdigest()!=x['sha256']:delta.append(x['path'])
assert set(delta)=={'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditPaginationBoundaryTest.java','docs/development/branch-review-20261106-audit-page-names/decision-package.yaml'}
out['postRunChanges']=delta;out['postRunChangeReason']='Only removed obsolete single-user mock/import in six-case pagination test; DP affectedFiles appended. Runtime and all native tests unchanged; focused six-case rerun and fresh QA cover final source.'
for phase in ['baseline','final']:assert json.loads((raw/phase/'cleanup.json').read_text())['removed']
out['measurementLimits']=['business SELECT tagged only, not all network roundtrips','calling-thread cumulative allocation includes statistics/observer/SessionMetrics logging; not production peak/RSS/SLA','still full event JSON/entity loading; no DB paging or index optimization']
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');shutil.copy2(raw/'analysis.json',r/'docs/development/branch-review-20261106-audit-page-names/main-analysis.json')
print(json.dumps({p:{k:v for k,v in a.items() if k!='cases'} for p,a in out['sql'].items()},indent=2))
for name in ['names_shared_5000','names_distinct_5000','names_large_first','names_large_second']:
 a=json.loads((raw/'final/observations'/f'{name}.json').read_text());print(name,a['prepareStatements'],a['entityLoads'],round(a['threadAllocatedBytes']/1048576,2),round(a['elapsedNanos']/1e6,1))
