from pathlib import Path
import json,re,collections,hashlib,xml.etree.ElementTree as ET,shutil
root=Path('/workspace/edhr-nexus-frontend'); raw=Path('/tmp/edhr-audit-read-20261106')
out={'baseline':'e69a8f3d97b34fea8737947c780b047bb0310c64','runs':{},'sqlReconciliation':{},'limits':['tagged business SELECT only, not all network roundtrips','calling-thread cumulative allocation includes statistics/observer/SessionMetrics logging; not peak/RSS/SLA','synthetic read fixtures, no HTTP/UI or production concurrency claim']}
for phase in ['unit_negative','baseline','final']:
 p=raw/phase; s=json.loads((p/'test-summary.json').read_text());out['runs'][phase]=s
 if phase=='unit_negative':assert s['totals']==dict(tests=6,failures=3,errors=0,skipped=0)
 if phase=='baseline':assert s['totals']==dict(tests=26,failures=6,errors=0,skipped=0)
 if phase=='final':assert s['totals']==dict(tests=116,failures=0,errors=0,skipped=0)
 if phase=='unit_negative':continue
 sql=collections.defaultdict(collections.Counter)
 for line in (p/'postgres.log').open():
  m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*audit_read_([^*]+)\*/ (.*)$',line)
  if m:sql[m[1]][re.sub(r'\$\d+','?',m[2])]+=1
 cases=[]
 for f in sorted((p/'observations').glob('*.json')):
  a=json.loads(f.read_text())
  if 'sqlShapes' not in a:continue
  expected=collections.Counter({x['sql']:x['count'] for x in a['sqlShapes']})
  assert expected==sql[a['name']],(phase,a['name'])
  assert sum(expected.values())==a['prepareStatements']
  assert all(x.lower().startswith('select ') for x in expected)
  assert a['entityInserts']==a['entityUpdates']==a['entityDeletes']==0
  cases.append({k:a[k] for k in ['name','prepareStatements','entityLoads','total','ids','threadAllocatedBytes','elapsedNanos']})
 assert set(sql)=={a['name'] for a in cases}
 out['sqlReconciliation'][phase]={'events':len(cases),'businessSelectExecutions':sum(sum(v.values()) for v in sql.values()),'exactShapesAndCountsMatch':True,'cases':cases}
out['negativeTestSourceIdentical']={}
for phase,name in [('unit_negative','AuditPaginationBoundaryTest.java'),('baseline','AuditActionFilterPostgresTest.java')]:
 old=list((raw/phase/'source').rglob(name))[0].read_bytes();new=list((raw/'final'/'source').rglob(name))[0].read_bytes();assert old==new
 out['negativeTestSourceIdentical'][name]=hashlib.sha256(new).hexdigest()
run=json.loads((raw/'final'/'run.json').read_text());fixed=[];docdelta=[]
for x in run['sourceFingerprints']:
 now=(root/x['path']).read_bytes();same=hashlib.sha256(now).hexdigest()==x['sha256']
 if not same:assert x['path'].endswith('decision-package.yaml');docdelta.append(x['path'])
 else:fixed.append(x['path'])
out['testedSourceStillIdentical']=fixed;out['docOnlyPostRunDelta']=docdelta
kdir=raw/'knowledge';totals=dict(tests=0,failures=0,errors=0,skipped=0)
for f in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 a=ET.parse(f).getroot().attrib
 for k in totals:totals[k]+=int(a[k])
 shutil.copy2(f,kdir/f.name)
assert totals==dict(tests=89,failures=0,errors=0,skipped=0);out['knowledge']=totals
(kdir/'test-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
for phase in ['baseline','final']:assert json.loads((raw/phase/'cleanup.json').read_text())['removed']
out['ownedContainersRemoved']=True
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
shutil.copy2(raw/'analysis.json',root/'docs/development/branch-review-20261106-audit-read/main-analysis.json')
print(json.dumps({'runs':{k:v['totals'] for k,v in out['runs'].items()},'sql':{k:{a:b for a,b in v.items() if a!='cases'} for k,v in out['sqlReconciliation'].items()},'knowledge':totals,'identicalInputs':len(fixed)},indent=2))
