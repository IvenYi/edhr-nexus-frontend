from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-audit-page-names-ontology-20261106')
base='3c8e46943dbc3d02673d342e501b0884cb0c76dd';target='e69a8f3d97b34fea8737947c780b047bb0310c64'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==base
assert git('rev-parse','origin/edhr-dev').decode().strip()==target
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/ontology.yaml','docs/knowledge/glossary.yaml','docs/knowledge/rules/production.yaml','docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/evidence/qualified-personnel-selection-20261105.md','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/UserAccount.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/dto/AuditLogItem.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditControllerTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditReadObservationPostgresTest.java']
manifest=[]
for path in paths:
 data=git('show',base+':'+path);f=out/'baseline-source'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 manifest.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'sourceCommit':base})
path='docs/development/branch-review-20261106-audit-page-names/decision-package.yaml';data=(root/path).read_bytes();f=out/'initial-working-context'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
manifest.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'sourceCommit':None,'workingTree':True})
(out/'source-manifest-initial.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
inventory=[]
files=git('ls-tree','-r','--name-only',base,'--','docs/knowledge').decode().splitlines()
for path in files:
 b=git('show',base+':'+path);t=git('show',target+':'+path);now=(root/path).read_bytes();assert b==t==now,path
 inventory.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'targetAndCurrentIdentical':True})
assert len(inventory)==350
(out/'knowledge-fingerprint-inventory-initial.json').write_text(json.dumps(inventory,indent=2)+'\n')
baseline={'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':base,'uncommittedContractPaths':[],'observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0 / in-progress','knowledgeFiles':len(files),'contractsIdenticalSourceTarget':not git('diff','--name-only',base,target,'--','AGENTS.md','codeplzreadme.md','docs/agents').strip(),'gitStatus':git('status','--porcelain').decode().splitlines()}
(out/'baseline.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n');print(json.dumps(baseline,ensure_ascii=False,indent=2))
