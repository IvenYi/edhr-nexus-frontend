from pathlib import Path
import json,shutil,xml.etree.ElementTree as ET,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-page-names-ontology-20261106')
reports=list((root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'))
totals=dict(tests=0,failures=0,errors=0,skipped=0);rows=[]
for f in reports:
 a=ET.parse(f).getroot().attrib;values={k:int(a.get(k,0)) for k in totals}
 for k,v in values.items():totals[k]+=v
 rows.append({'class':a['name'],**values,'mtimeUTC':datetime.datetime.fromtimestamp(f.stat().st_mtime,datetime.timezone.utc).isoformat()})
 assert f.stat().st_mtime>datetime.datetime.fromisoformat('2026-11-06T06:43:28+00:00').timestamp()
 shutil.copy2(f,out/f.name)
assert totals==dict(tests=89,failures=0,errors=0,skipped=0)
(out/'knowledge-test-summary.json').write_text(json.dumps({'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test','totals':totals,'classes':rows,'executedBy':'audit_page_names_ontology','scope':'knowledge validator only, not product runtime'},indent=2)+'\n')
print(json.dumps(totals))
