from pathlib import Path
import subprocess,json,hashlib,shutil,difflib,xml.etree.ElementTree as ET,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-page-names-ontology-20261106');parent=Path('/tmp/edhr-audit-page-names-20261106')
def git(*a):return subprocess.check_output(['git',*a],cwd=root)
run=json.loads((parent/'final/run.json').read_text());analysis=json.loads((parent/'analysis.json').read_text())
assert analysis['runs']['final']['totals']==dict(tests=134,failures=0,errors=0,skipped=0)
assert analysis['runs']['baseline']['totals']==dict(tests=18,failures=16,errors=0,skipped=0)
assert analysis['sql']['final']['completedEvents']==45 and analysis['sql']['final']['completedBusinessSelects']==90
assert analysis['sql']['final']['exactShapesMatch']
same=[];deltas=[];manifest=[]
for x in run['sourceFingerprints']:
 path=x['path'];data=(root/path).read_bytes();sha=hashlib.sha256(data).hexdigest();f=out/'final-source'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 manifest.append({'path':path,'bytes':len(data),'sha256':sha,'observedHead':git('rev-parse','HEAD').decode().strip(),'workingTreeSnapshot':True})
 if sha==x['sha256']:same.append(path)
 else:
  assert path in ['docs/development/branch-review-20261106-audit-page-names/decision-package.yaml','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditPaginationBoundaryTest.java'],path
  deltas.append({'path':path,'runSha256':x['sha256'],'currentSha256':sha})
  old=(parent/'final/source'/path).read_text();(out/(Path(path).name+'.post-run.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),data.decode().splitlines(True),fromfile='primary-final-run',tofile='current-read')))
assert len(same)==20 and len(deltas)==2
extra='docs/knowledge/evidence/production.yaml';b=(root/extra).read_bytes();f=out/'final-source'/extra;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);manifest.append({'path':extra,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'workingTreeSnapshot':True})
(out/'final-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
inventory=json.loads((out/'knowledge-fingerprint-inventory-initial.json').read_text())
for x in inventory:assert hashlib.sha256((root/x['path']).read_bytes()).hexdigest()==x['sha256']
(out/'knowledge-fingerprint-inventory-final.json').write_text(json.dumps(inventory,indent=2)+'\n')
copied=[]
for phase in ['baseline','final','pagination-hygiene']:
 files=list((parent/phase).glob('TEST-*.xml'))
 files +=[f for f in (parent/phase).glob('*.json') if f.name in ['run.json','test-summary.json','summary.json']]
 if phase=='pagination-hygiene':files.append(parent/phase/'AuditPaginationBoundaryTest.java')
 for f in files:
  dst=out/'parent-generated-evidence'/phase/f.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst);copied.append(str(f.relative_to(parent)))
for name in ['names_shared_5000','names_distinct_5000','names_missing_5000','names_blank_5000','names_large_first','names_large_second','names_fallbacks','names_historical_filter','names_current_filter_empty','names_off_page','profile','fallback_selective']:
 f=parent/'final/observations'/(name+'.json');dst=out/'parent-generated-evidence/final/observations'/f.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst);copied.append(str(f.relative_to(parent)))
shutil.copy2(parent/'analysis.json',out/'parent-generated-evidence/analysis.json')
assert (parent/'pagination-hygiene/AuditPaginationBoundaryTest.java').read_bytes()==(root/'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditPaginationBoundaryTest.java').read_bytes()
xml=ET.parse(parent/'pagination-hygiene/TEST-com.zencas.edhr.compliance.controller.AuditPaginationBoundaryTest.xml').getroot().attrib
assert {k:int(xml[k]) for k in ['tests','failures','errors','skipped']}==dict(tests=6,failures=0,errors=0,skipped=0)
provenance={'readAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'producedBy':'parent primary implementation role; ontology role only read/copied','parentRoot':str(parent),'copied':copied,'sameFinalRunInputs':same,'postRunDeltas':deltas,'postRunNotes':'Pagination test removes obsolete single-person mock/import; six assertions preserved and fresh6/6 source copied. DP affectedFiles appended. Product/native sources unchanged.','baselineFixtureProvenance':analysis['baselineFixtureProvenance'],'knowledge350Unchanged':True,'productRuntimeExecutedByOntologyRole':False,'independentSQLRecomputedByOntologyRole':False}
(out/'parent-generated-evidence/provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']:
 assert (root/path).read_bytes()==git('show','3c8e46943dbc3d02673d342e501b0884cb0c76dd:'+path)
proof={'knowledgeFiles':len(inventory),'sameFinalRunInputs':len(same),'postRunDeltas':len(deltas),'knowledgeTests':89,'parentFinalProductTests':134,'hygieneRerun':6,'baselineNewTests':18,'baselineRealFailures':16,'runtimeAndNativeInputsUnchanged':True}
(out/'final-review-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
