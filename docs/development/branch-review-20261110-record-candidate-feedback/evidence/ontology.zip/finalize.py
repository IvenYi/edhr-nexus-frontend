import copy
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile
import yaml

ROOT = Path('/workspace/edhr-nexus-frontend')
RAW = Path('/tmp/edhr-record-candidate-feedback-ontology-20261110')
BASE = '670040fb7d24abf629baa53d60f6fe922c7e7714'
CANDIDATE = '6f03c7e565d309ed6630db7ab336a378cbadbe65'
PRIOR = '7e43939b519b743e73ca993d66632b1316655fed'
PREVIOUS = ROOT / 'docs/development/branch-review-20261110-record-change-async'
DP = 'docs/development/branch-review-20261110-record-candidate-feedback/decision-package.yaml'
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
sha = lambda data: hashlib.sha256(data).hexdigest()
dump = lambda path, value: path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

fetch = subprocess.run(['git', 'fetch', 'origin', 'edhr-dev'], cwd=ROOT, capture_output=True, text=True)
assert fetch.returncode == 0, fetch.stderr
assert git('rev-parse', 'origin/edhr-dev').decode().strip() == BASE
assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert not git('diff', BASE, CANDIDATE, '--', 'AGENTS.md', 'codeplzreadme.md', 'docs/agents')
paths = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md',
 'docs/agents/business-knowledge-modeler.md', 'docs/agents/quality-verifier.md',
 'docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml',
 'docs/knowledge/schema.yaml', 'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
 'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
 'docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
 'docs/knowledge/decisions/DEC-0085-shared-login-cross-tab-isolation.yaml',
 'docs/knowledge/rules/record-change.yaml', 'docs/knowledge/facts/record-control.yaml',
 'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
 'gmp-platform/frontend/src/api/record-control.ts', 'gmp-platform/frontend/src/api/record-control-workflow.ts',
 'gmp-platform/frontend/src/api/client.ts', 'gmp-platform/frontend/src/components/workflow/ButtonSignatureCredentials.tsx',
 'gmp-platform/frontend/src/components/ConfirmDialog.tsx', 'gmp-platform/frontend/src/components/AppDialog.tsx',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs', DP]
source_inputs = []
for path in paths:
    data = (ROOT / path).read_bytes()
    assert data == git('show', CANDIDATE + ':' + path), path
    snapshot = RAW / 'final-source' / path
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(data)
    source_inputs.append({'path': path, 'sourceCommit': CANDIDATE, 'bytes': len(data), 'sha256': sha(data),
      'scope': 'Whole bytes loaded/captured; semantic conclusions limited to named8 items,not whole-file completion'})
entry_map = []
for path in ['docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml']:
    content = (ROOT / path).read_text()
    entry_map.append({'path': path, 'completeByteCountLoaded': len(content.encode()),
      'sha256': sha(content.encode()), 'headings': [line for line in content.splitlines() if line.startswith('#')],
      'scope': 'Complete entrypoint loaded; current record-control/policy boundaries inspected,not all-history semantic completion'})
dump(RAW / 'entrypoint-read-map.json', entry_map)
changes = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
assert set(changes) == {DP, 'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
 'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs'}
protected = ['docs/knowledge', 'docs/architecture', 'gmp-platform/backend', 'gmp-platform/frontend/src/api',
 'gmp-platform/frontend/src/components', 'AGENTS.md', 'docs/agents', 'codeplzreadme.md', 'DESIGN.md']
assert not git('diff', BASE, CANDIDATE, '--', *protected)
(RAW / 'candidate.diff').write_bytes(git('diff', BASE, CANDIDATE))
knowledge_names = git('ls-tree', '-r', '--name-only', CANDIDATE, '--', 'docs/knowledge').decode().splitlines()
assert len(knowledge_names) == 353
knowledge = []
for path in knowledge_names:
    data = (ROOT / path).read_bytes()
    assert data == git('show', CANDIDATE + ':' + path) == git('show', BASE + ':' + path) == git('show', PRIOR + ':' + path)
    knowledge.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'status': 'pending',
      'scope': 'Inventory/unchanged bytes only;no inferred semantic pass'})
dump(RAW / 'knowledge-inventory.json', {'sourceCommit': CANDIDATE, 'targetCommit': BASE, 'files': knowledge,
 'fileCount': len(knowledge), 'yamlCount': sum(p['path'].endswith('.yaml') for p in knowledge),
 'markdownCount': sum(p['path'].endswith('.md') for p in knowledge), 'wholeSemanticCompletion': False,
 'old931SubsetComparable': False, 'assetIds2848': 'Carried previous same-input inventory,not recounted or semantic completion'})
package_index = json.loads((PREVIOUS / 'evidence-packages.json').read_text())
packages = {p['name']: p for p in package_index['packages']}
for name in ['ontology', 'independent']:
    package = packages[name]
    assert sha((PREVIOUS / package['path']).read_bytes()) == package['sha256']
    assert sha((PREVIOUS / package['manifest']).read_bytes()) == package['manifestSha256']
with zipfile.ZipFile(PREVIOUS / packages['ontology']['path']) as archive:
    original_finite = archive.read('finite-review-records.json')
    old_finite = json.loads(original_finite)
    validation = json.loads(archive.read('knowledge-validation-reuse.json'))
    (RAW / 'historical-finite19-original.json').write_bytes(original_finite)
    (RAW / 'historical-ontology-result-original.yaml').write_bytes(archive.read('ontology-result.yaml'))
assert old_finite['summary']['count'] == 19
assert old_finite['summary']['conclusions'] == {'consistent': 15, 'evidence-gap': 2, 'needs-decision': 1, 'superseded': 1}
old_finite = copy.deepcopy(old_finite)
old_finite['currentReuseScope'] = 'Prior19 evidence preserved;not recounted as current8 or newly reviewed completion.All originals byte-checked in current files.'
def find_id(value, ident):
    if isinstance(value, dict):
        if value.get('id') == ident: return value
        for child in value.values():
            found = find_id(child, ident)
            if found is not None: return found
    if isinstance(value, list):
        for child in value:
            found = find_id(child, ident)
            if found is not None: return found
    return None
for row in old_finite['records']:
    current = find_id(yaml.safe_load((ROOT / row['sourcePath']).read_text()), row['id'])
    assert current == row['originalRecord'], row['id']
dump(RAW / 'historical-finite19-reuse.json', old_finite)
validator_inputs = []
for row in validation['sourceInputs']:
    path = row['path']; data = (ROOT / path).read_bytes()
    assert sha(data) == row['sha256'] and data == git('show', PRIOR + ':' + path) == git('show', CANDIDATE + ':' + path)
    validator_inputs.append({'path': path, 'bytes': len(data), 'sha256': sha(data)})
assert len(validator_inputs) == 359
reuse_files = []
with zipfile.ZipFile(PREVIOUS / packages['independent']['path']) as archive:
    expected = {r['path']: r for r in json.loads((PREVIOUS / packages['independent']['manifest']).read_text())['files']}
    for name in ['knowledge-run.json', 'knowledge.log', 'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml', 'quality-result.yaml']:
        data = archive.read(name); assert sha(data) == expected[name]['sha256']
        dest = RAW / 'reused-knowledge-7e' / name
        dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
        reuse_files.append({'path': str(dest.relative_to(RAW)), 'bytes': len(data), 'sha256': sha(data)})
    actual = json.loads(archive.read('knowledge-run.json'))
    suite = ET.fromstring(archive.read('TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'))
    totals = {k: int(suite.attrib[k]) for k in ['tests', 'failures', 'errors', 'skipped']}
assert actual['head'] == PRIOR and actual['exitCode'] == 0
assert totals == {'tests': 89, 'failures': 0, 'errors': 0, 'skipped': 0}
trees = []
for path in ['docs/knowledge', 'tools/knowledge-model', 'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge']:
    old, new = (git('rev-parse', h + ':' + path).decode().strip() for h in [PRIOR, CANDIDATE])
    assert old == new
    trees.append({'path': path, 'priorGitTree': old, 'currentGitTree': new, 'same': True})
reuse = {'sourceCommit': CANDIDATE, 'priorActuallyTestedCommit': PRIOR, 'actuallyExecutedByThisRole': False,
 'priorActualCommand': actual['command'], 'priorActualStartedAt': actual['startedAt'],
 'priorActualFinishedAt': actual['finishedAt'], 'totals': totals, 'trees': trees,
 'sourceInputs': validator_inputs, 'reusedArtifacts': reuse_files,
 'originalZip': str((PREVIOUS / packages['independent']['path']).relative_to(ROOT)),
 'originalZipSha256': packages['independent']['sha256'],
 'scope': 'Reused actual prior independent89 only after359 source inputs and trees match;not current runtime/PG/whole semantic proof'}
dump(RAW / 'knowledge-validation-reuse.json', reuse)
reviews = [
 ('DEC-0087-03','direct','最终来源/修订/活动申请及认证在事务内复核，页面反馈不取代后台检查。'),
 ('DEC-0087-04','direct','继续明确选择类型匹配的已发布版本，原因/真实签名及内容差异规则不变；候选读取失败不能伪装成无流程。'),
 ('rule.record-control-source-eligibility-v1','direct','来源COMPLETED/current revision/无活动申请规则不变，错误显示不授予申请资格。'),
 ('DEC-0094-02','direct','候选仅匹配PUBLISHED具体版本，读取成功或错误呈现不意味着可发起/审批。'),
 ('DEC-0074-03','direct','现有签署认证失败须就地提示并保留输入；把已有错误显示在当前Dialog落实既有失败恢复，不推导真实网络503一定未写入。'),
 ('DEC-0074-01','neighbor','A登录/B真实签署的凭证和动作资格不变，未自动切账号或借用权限。'),
 ('DEC-0085-03','neighbor','会话代际及迟到结果仍由原API client保护，局部candidate错误状态不清除新会话凭据。'),
 ('DEC-0096-04','neighbor','超管详情只读不授予申请/签署或审批动作；错误提示修复不扩权。')]
current_rows = []
for ident, scope, conclusion in reviews:
    old = next(r for r in old_finite['records'] if r['id'] == ident)
    row = {k: copy.deepcopy(old[k]) for k in ['id','recordType','sourcePath','sourceLocator','originalMaturity','originalVisibility','originalRecord']}
    row.update({'scope': scope, 'semanticReviewStatus': 'reviewed', 'conclusion': 'consistent',
      'reviewConclusion': conclusion, 'runtimeVerificationByOntology': False,
      'evidence': ['final-source/gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
       'final-source/gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
       'final-source/gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java']})
    current_rows.append(row)
dump(RAW / 'finite-review-records.json', {'summary': {'count': 8, 'direct': 5, 'neighbor': 3,
 'conclusions': {'consistent': 8}, 'scope': 'Finite current8 only,overlaps prior19,not8 new unique completed assets',
 'wholeFileCompleted': 0, 'historicalUnique': 'unknown'}, 'records': current_rows})
observations = []
parent_raw = Path('/tmp/edhr-record-candidate-feedback-20261110')
for phase, expected in [('baseline', (12, 2, 10)), ('focused', (34, 34, 0))]:
    file = parent_raw / phase / 'result.json'; data = file.read_bytes(); report = json.loads(data)
    assert tuple(report[k] for k in ['tests','passed','failed']) == expected
    dest = RAW / 'parent-readonly' / phase / 'result.json'
    dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
    observations.append({'phase': phase, 'tests': expected[0], 'passed': expected[1], 'failed': expected[2],
     'sha256': sha(data), 'actuallyExecutedByOntology': False,
     'scope': 'Parent synthetic API component run read-only;not independent runtime or separate defect count'})
dump(RAW / 'source-binding.json', {'status': 'FINAL', 'sourceCommit': CANDIDATE, 'targetCommit': BASE,
 'contractReadCommit': BASE, 'timestamp': datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'fetchOutput': fetch.stdout + fetch.stderr, 'contractDiff': '', 'changedPaths': changes,
 'sourceInputs': source_inputs, 'knowledgeFiles': 353, 'knowledgeInventorySha256': sha((RAW / 'knowledge-inventory.json').read_bytes()),
 'knowledgeValidation': reuse, 'parentRunsReadOnly': observations,
 'parentRuntimeMeaning': 'baseline12=2P10F;focused34P atdirty670 then same staged bytes committed6f;not ontology execution',
 'semanticCoverage': 'current8=5direct3neighbor consistent scoped;prior19 preserved not recounted;not all2848/old931',
 'knowledgeOrPolicyChanged': False, 'backendApiSchemaOrSharedComponentsChanged': False,
 'workingTreeAtObservation': git('status','--porcelain=v1').decode(), 'noChildren': True,
 'wholeFileCompleted': 0, 'historicalUnique': 'unknown', 'qualityResultNotSuppliedByOntology': True})
result = {'ontologyResult': {'result': 'not-applicable', 'baselineBefore': '0.3.25', 'baselineAfter': '0.3.25',
 'contractBaseline': {'sourceCommit': CANDIDATE, 'targetBranch': 'edhr-dev', 'targetCommit': BASE,
                      'contractReadCommit': BASE, 'uncommittedContractPaths': []},
 'reason': '候选读取失败与真实空态区分、按当前页面/Dialog显示已有错误属于工程反馈修正；不新增或替代来源资格、流程版本、签署/权限/幂等/事务/快照/审计政策。知识及后端/API/schema/共享组件不变，保持既有DEC0087/0094/0074/0085/0096范围，不为本轮创建重复知识或改写历史。',
 'changedArtifacts': [], 'knowledgeSync': [], 'conflicts': [], 'questions': [],
 'validationEvidence': [
  {'id':'validation.source-and-contract','checkType':'evidence-path','command':'python3 finalize.py: independent fetch,current29 source hashes/Git snapshots and exact3 changed paths','outcome':'passed','evidence':['source-binding.json','final-source','candidate.diff']},
  {'id':'validation.finite-scope','checkType':'projection','command':'Inspect current8 scoped statements and preserve prior19 unchanged original records with outstanding boundaries','outcome':'passed','evidence':['finite-review-records.json','historical-finite19-original.json','historical-finite19-reuse.json','REVIEW.md']},
  {'id':'validation.same-knowledge-inputs','checkType':'reference','command':'Compare353 knowledge files and359 validator/POM inputs,three Git trees against prior actual7e','outcome':'passed','evidence':['knowledge-inventory.json','knowledge-validation-reuse.json']},
  {'id':'validation.reused-knowledge89','checkType':'schema','command':'REUSED ONLY: original independent Maven knowledge clean test at7e;not executed by this role','outcome':'passed','evidence':['reused-knowledge-7e/knowledge-run.json','reused-knowledge-7e/knowledge.log','reused-knowledge-7e/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','knowledge-validation-reuse.json']}],
 'roadmapProgress': {'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(RAW / 'ontology-result.yaml').write_text(yaml.safe_dump(result, allow_unicode=True, sort_keys=False))
dump(RAW / 'result.json', {'status':'FINAL','result':'not-applicable','candidate':CANDIDATE,'target':BASE,
 'currentFinite':8,'prior19CarriedNotRecounted':True,'knowledgeFiles':353,'validatorInputs':359,
 'knowledge89':'Prior7e original reused;not rerun','repoChangesByRole':False,'children':[]})
print(json.dumps({'candidate':CANDIDATE,'sourceInputs':len(source_inputs),'finite':8,'knowledgeFiles':353,'validatorInputs':359,'result':'not-applicable'}))
