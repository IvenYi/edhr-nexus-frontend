from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

root=Path('/tmp/edhr-record-candidate-feedback-qa-worktree-20261110')
out=Path('/tmp/edhr-record-candidate-feedback-final-qa-20261110')
parent=Path('/tmp/edhr-record-candidate-feedback-20261110')
base='670040fb7d24abf629baa53d60f6fe922c7e7714'
head='6f03c7e565d309ed6630db7ab336a378cbadbe65'
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda name:json.loads((out/name).read_text())
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
assert git('rev-parse','HEAD').decode().strip()==head
tasks={'record-ui':0,'workflow-ui':0,'build':0,'list-style':0,'fonts':0,'lint':2,'premium':2}
inputs=load('record-ui-run.json')['sourceFingerprints']
assert len(inputs)==27
for name,code in tasks.items():
    run=load(name+'-run.json')
    assert run['head']==head and run['exitCode']==code
    assert run['sourceFingerprints']==inputs
    assert run['workingTreeStatus']=='?? gmp-platform/frontend/node_modules\n'
for row in inputs:
    data=(root/row['path']).read_bytes()
    assert sha(data)==row['sha256']==sha(git('show',head+':'+row['path']))
    assert sha((out/'source'/row['path']).read_bytes())==row['sha256']
record=load('record-ui/result.json');workflow=load('workflow-ui/result.json');knowledge=load('knowledge/run.json')
assert (record['tests'],record['passed'],record['failed'])==(34,34,0)
assert (workflow['tests'],workflow['passed'],workflow['failed'])==(58,58,0)
assert knowledge['head']==head and knowledge['exitCode']==0
assert knowledge['totals']==dict(tests=89,failures=0,errors=0,skipped=0)
for case in record['results']:
    assert case['writeCount']==(1 if case['scenario'].startswith('refresh-') or case['scenario']=='submit-current-error' else 0)
expected={'lookup-success','lookup-error','lookup-loading','candidate-success','candidate-error','candidate-source','candidate-empty','candidate-current-error','refresh-success','refresh-error','discard-cancel','discard-confirm','ime','candidate-error-before-dialog','candidate-error-reopen','candidate-error-rechoose','submit-current-error'}
assert {r['scenario'] for r in record['results']}==expected
assert {r['width'] for r in record['results']}=={390,1440}
baseline=load('premium-baseline-reused.json');current=load('premium-final.json')
key=lambda f:json.dumps({k:v for k,v in f.items() if k!='line'},sort_keys=True)
a,b=Counter(map(key,baseline['findings'])),Counter(map(key,current['findings']))
assert a==b and sum(b.values())==86
assert current['summary']==dict(errors=86,total=86,unresolved=14,violations=72,warnings=0)
static={'distinctIdentities':len(b),'occurrences':sum(b.values()),'added':sum((b-a).values()),'removed':sum((a-b).values()),'qualification':'Full Counter multiset ignores source line relocation,preserves duplicates;baseline is original scan reused after exact frontend tree identity,not independently rerun'}
(out/'static-delta.json').write_text(json.dumps(static,indent=2)+'\n')
assert "ESLint couldn't find a configuration file" in (out/'lint.log').read_text()
archive=root/'docs/development/branch-review-20261110-record-change-async/evidence/main.zip'
with zipfile.ZipFile(archive) as z:
    old_tool=z.read('audit_project.py')
assert (out/'audit_project.py').read_bytes()==old_tool
official={'skillResource':'skill://plugins_6a7039f8e9708191bde88207b1919bf4/frontend-design-premium/scripts/audit_project.py','executedSha256':sha((out/'audit_project.py').read_bytes()),'originalBaselineToolSha256':sha(old_tool),'byteMatches':True,'scope':'Exact cloud tool fetched independently and executed;original baseline tool has identical bytes'}
assert official['executedSha256']=='67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68'
(out/'official-tool-binding.json').write_text(json.dumps(official,indent=2)+'\n')
delta=git('diff','--name-only',base,head).decode().splitlines()
assert set(delta)=={'docs/development/branch-review-20261110-record-candidate-feedback/decision-package.yaml','gmp-platform/frontend/scripts/test-record-change-async-browser.mjs','gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx'}
assert not git('diff',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','gmp-platform/backend','gmp-platform/frontend/src/api','gmp-platform/frontend/src/components','DESIGN.md')
for name in ['baseline','focused']:
    target=out/'main-history'/name;target.mkdir(parents=True,exist_ok=True)
    data=(parent/name/'result.json').read_bytes();(target/'result.json').write_bytes(data)
    (out/'main-history'/f'{name}.log').write_bytes((parent/f'{name}.log').read_bytes())
    for image in sorted((parent/name).glob('*.png')):
        shutil.copyfile(image,target/image.name)
old=json.loads((out/'main-history/baseline/result.json').read_text())
assert (old['tests'],old['passed'],old['failed'])==(12,2,10)
assert all(not row.get('pageErrors') for row in old['results'])
binding={'baseCommit':base,'headCommit':head,'independentlyFetchedTarget':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':head,'contractDiff':[],'runtimeDependencyLink':'All seven command records explicitly show only our own untracked node_modules symlink;tracked source/test bytes remain fixed','runnerSourceFingerprints':inputs,'additionalReviewedSources':load('additional-reviewed-inputs.json'),'knowledgeFileCount':load('knowledge-inventory.json')['fileCount'],'candidateDelta':delta,'parentHistoryQualification':'Parent original12=2P10F and34P copied with hashes;read by QA,not independently rerun old source','timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert binding['independentlyFetchedTarget']==base
(out/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
result={'candidate':head,'target':base,'actualRecordBrowser':34,'actualWorkflowBrowser':58,'actualKnowledge':89,'sourceInputFingerprints':len(inputs),'static':static,'scope':'No product/test repair;actual maintained components with synthetic API,no nativePG/backend127/productionE2E claim','blockingFindings':0}
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
