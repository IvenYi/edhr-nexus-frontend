import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

root=Path('/tmp/edhr-record-candidate-feedback-qa-worktree-20261110')
out=Path('/tmp/edhr-record-candidate-feedback-final-qa-20261110/knowledge')
out.mkdir(exist_ok=True)
command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','--file','tools/knowledge-model/pom.xml','clean','test']
record={'command':command,'cwd':str(root),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runtimeStatus':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).decode()}
with (out/'maven.log').open('w') as log:
    run=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update({'exitCode':run.returncode,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
reports=list((root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'))
assert reports
totals=dict(tests=0,failures=0,errors=0,skipped=0)
for file in reports:
    shutil.copyfile(file,out/file.name)
    xml=ET.parse(file).getroot()
    for key in totals: totals[key]+=int(xml.attrib[key])
record['totals']=totals
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
assert run.returncode==0 and totals==dict(tests=89,failures=0,errors=0,skipped=0)
