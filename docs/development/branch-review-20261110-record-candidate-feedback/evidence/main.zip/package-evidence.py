import hashlib
import json
from pathlib import Path
import shutil
import zipfile
import yaml

repo = Path('/workspace/edhr-nexus-frontend')
out = repo / 'docs/development/branch-review-20261110-record-candidate-feedback'
evidence = out / 'evidence'
sources = {'main': Path('/tmp/edhr-record-candidate-feedback-20261110'),
           'ontology': Path('/tmp/edhr-record-candidate-feedback-ontology-20261110'),
           'independent': Path('/tmp/edhr-record-candidate-feedback-final-qa-20261110')}
sha = lambda data: hashlib.sha256(data).hexdigest()
dump = lambda path, value: path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
assert yaml.safe_load((sources['independent'] / 'quality-result.yaml').read_text())['qualityResult']['result'] == 'passed'
assert yaml.safe_load((sources['ontology'] / 'ontology-result.yaml').read_text())['ontologyResult']['result'] == 'not-applicable'
evidence.mkdir(exist_ok=True)
packages = []
for name, source in sources.items():
    verified_role = None
    if name != 'main':
        role_manifest = json.loads((source / 'manifest.json').read_text())
        rows = role_manifest.get('files', role_manifest.get('artifacts', []))
        assert rows
        for row in rows:
            data = (source / row['path']).read_bytes()
            assert sha(data) == row['sha256']
            if 'bytes' in row:
                assert len(data) == row['bytes']
        verified_role = len(rows)
    paths = sorted(source.rglob('*'))
    assert not any(p.is_symlink() for p in paths), name
    files = [p for p in paths if p.is_file()]
    assert all('node_modules' not in p.parts and '.git' not in p.parts for p in files)
    rows = []
    archive_path = evidence / (name + '.zip')
    with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for file in files:
            data = file.read_bytes(); relative = file.relative_to(source).as_posix()
            rows.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
            archive.write(file, relative)
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [r['path'] for r in rows]
        for row in rows:
            data = archive.read(row['path'])
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
    manifest_path = evidence / (name + '-manifest.json')
    dump(manifest_path, {'root': str(source), 'files': rows, 'fileCount': len(rows),
                         'originalRoleManifestMembersVerified': verified_role,
                         'excluded': [], 'totalBytes': sum(r['bytes'] for r in rows)})
    packages.append({'name': name, 'path': str(archive_path.relative_to(out)), 'bytes': archive_path.stat().st_size,
                     'sha256': sha(archive_path.read_bytes()), 'manifest': str(manifest_path.relative_to(out)),
                     'manifestSha256': sha(manifest_path.read_bytes()), 'members': len(rows),
                     'roleManifestMembersVerified': verified_role})
copied = []
for role, name, dest in [('main', 'main-analysis.json', 'main-analysis.json'),
                        ('ontology', 'ontology-result.yaml', 'ontology-result.yaml'),
                        ('ontology', 'REVIEW.md', 'ontology-review.md'),
                        ('independent', 'quality-result.yaml', 'quality-result.yaml'),
                        ('independent', 'independent-review.md', 'independent-review.md')]:
    shutil.copyfile(sources[role] / name, out / dest)
    copied.append({'path': dest, 'source': role + '/' + name, 'sha256': sha((out / dest).read_bytes())})
dump(out / 'evidence-packages.json', {'baseCommit': '670040fb7d24abf629baa53d60f6fe922c7e7714',
     'testedCandidate': '6f03c7e565d309ed6630db7ab336a378cbadbe65', 'packages': packages, 'copiedFormalArtifacts': copied,
     'scope': 'Separate complete owned raw histories, including initial tool and intermediate failures; no result rewriting'})
print(json.dumps({'packages': packages, 'members': sum(p['members'] for p in packages)}, ensure_ascii=False))
