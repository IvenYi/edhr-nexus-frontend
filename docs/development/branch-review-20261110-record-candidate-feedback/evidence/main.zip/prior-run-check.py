import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

repo = Path(os.environ.get('EDHR_ASYNC_REPO', '/workspace/edhr-nexus-frontend'))
raw = Path(os.environ.get('EDHR_ASYNC_RAW', '/tmp/edhr-record-change-async-20261110'))
frontend = repo / 'gmp-platform/frontend'
task = sys.argv[1]
raw.mkdir(parents=True, exist_ok=True)
env = os.environ.copy()
env['CHROME_PATH'] = '/usr/bin/chromium'
env['WORKFLOW_LIST_ARTIFACTS'] = str(raw / 'workflow-ui')
env['RECORD_CHANGE_ARTIFACTS'] = str(raw / 'record-ui')
commands = {
    'workflow-ui': ['node', 'scripts/test-workflow-list-ui-browser.mjs'],
    'record-ui': ['node', 'scripts/test-record-change-async-browser.mjs'],
    'build': ['npm', 'run', 'build'],
    'list-style': ['npm', 'run', 'verify:list-table-style'],
    'fonts': ['npm', 'run', 'verify:no-external-fonts'],
    'lint': ['npm', 'run', 'lint'],
    'premium': ['python3', str(raw / 'audit_project.py'), str(repo), '--mode', 'strict', '--output', str(raw / 'premium-final.json')],
    'premium-baseline': ['python3', str(raw / 'audit_project.py'), '/tmp/edhr-record-change-baseline-20261110', '--mode', 'strict', '--output', str(raw / 'premium-baseline.json')],
}
paths = ['AGENTS.md', 'codeplzreadme.md', 'DESIGN.md', 'docs/agents/agent-handoff-contract.md',
 'docs/agents/quality-verifier.md', 'docs/agents/business-knowledge-modeler.md',
 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml', 'docs/knowledge/rules/record-change.yaml',
 'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
 'docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml',
 'gmp-platform/frontend/package.json', 'gmp-platform/frontend/package-lock.json',
 'gmp-platform/frontend/src/App.tsx', 'gmp-platform/frontend/src/index.css',
 'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
 'gmp-platform/frontend/src/pages/record-control/RecordRequestListPage.tsx',
 'gmp-platform/frontend/src/components/AppDialog.tsx', 'gmp-platform/frontend/src/components/ConfirmDialog.tsx',
 'gmp-platform/frontend/src/components/workflow/ButtonSignatureCredentials.tsx',
 'gmp-platform/frontend/src/api/client.ts', 'gmp-platform/frontend/src/api/record-control.ts',
 'gmp-platform/frontend/src/api/record-control-workflow.ts',
 'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs',
 'gmp-platform/frontend/scripts/test-workflow-list-ui-browser.mjs',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java']
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo).decode().strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=repo).decode()
inputs = []
for name in paths:
    file = repo / name
    assert file.is_file(), name
    data = file.read_bytes()
    inputs.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    snapshot = raw / 'source' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(data)
record = {'task': task, 'command': commands[task], 'cwd': str(frontend), 'head': head,
          'workingTreeStatus': status, 'sourceFingerprints': inputs,
          'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(raw / (task + '-run.json')).write_text(json.dumps(record, indent=2) + '\n')
with (raw / (task + '.log')).open('w') as log:
    result = subprocess.run(commands[task], cwd=frontend, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update({'exitCode': result.returncode, 'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat()})
(raw / (task + '-run.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'task': task, 'exitCode': result.returncode, 'head': head}))
sys.exit(result.returncode)
