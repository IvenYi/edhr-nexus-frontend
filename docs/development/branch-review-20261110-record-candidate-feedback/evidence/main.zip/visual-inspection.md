# 主侧有限视觉检查

已实际查看focused/candidate-current-error-390.png与focused/submit-current-error-1440.png：失败提示位于当前Dialog内，候选错误不显示“暂无流程”，提交错误旁保留原选择与输入；合成密码为遮罩。部分截图在Dialog打开过渡阶段，不声称完整动画/读屏或全WCAG验证。维护组件+synthetic API，非真实生产签署。共享控件/主题/设计token及用户暂停的生产管理弹窗未改。
