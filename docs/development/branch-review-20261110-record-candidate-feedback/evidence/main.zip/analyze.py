from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/edhr-nexus-frontend')
raw = Path('/tmp/edhr-record-candidate-feedback-20261110')
base = '670040fb7d24abf629baa53d60f6fe922c7e7714'
candidate = '6f03c7e565d309ed6630db7ab336a378cbadbe65'
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda name: json.loads((raw / name).read_text())
assert git('rev-parse', 'HEAD').decode().strip() == candidate
old, new, adjacent = [load(n) for n in ['baseline/result.json', 'focused/result.json', 'workflow-ui/result.json']]
assert (old['tests'], old['passed'], old['failed']) == (12, 2, 10)
assert all(not r.get('pageErrors') for r in old['results'])
assert all(r['passed'] == (r['scenario'] == 'candidate-empty') for r in old['results'])
assert (new['tests'], new['passed'], new['failed']) == (34, 34, 0)
assert (adjacent['tests'], adjacent['passed'], adjacent['failed']) == (58, 58, 0)
inputs = load('build-run.json')['sourceFingerprints']
assert len(inputs) == 27
for task, code in [('build', 0), ('workflow-ui', 0), ('list-style', 0), ('fonts', 0), ('lint', 2), ('premium', 2)]:
    run = load(task + '-run.json')
    assert run['head'] == candidate and run['exitCode'] == code
    assert run['sourceFingerprints'] == inputs
for row in inputs:
    assert sha((repo / row['path']).read_bytes()) == row['sha256'] == sha(git('show', candidate + ':' + row['path']))
    assert sha((raw / 'source' / row['path']).read_bytes()) == row['sha256']
baseline_tree = git('rev-parse', base + ':gmp-platform/frontend').decode().strip()
assert baseline_tree == git('rev-parse', '7e43939b:gmp-platform/frontend').decode().strip()
assert load('baseline-static-original-run.json')['head'] == '7e43939b519b743e73ca993d66632b1316655fed'
key = lambda f: json.dumps({k: v for k, v in f.items() if k != 'line'}, sort_keys=True)
a = Counter(map(key, load('premium-baseline-reused.json')['findings']))
b = Counter(map(key, load('premium-final.json')['findings']))
assert a == b and sum(a.values()) == 86
assert 'ESLint couldn\'t find a configuration file' in (raw / 'lint.log').read_text()
assert sha((raw / 'audit_project.py').read_bytes()) == '67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68'
protected = ['gmp-platform/backend', 'docs/knowledge', 'docs/agents', 'AGENTS.md', 'codeplzreadme.md',
 'DESIGN.md', 'gmp-platform/frontend/src/api', 'gmp-platform/frontend/src/components']
assert not git('diff', '--name-only', base, candidate, '--', *protected)
assert len(git('ls-tree', '-r', '--name-only', candidate, '--', 'docs/knowledge').decode().splitlines()) == 353
result = {'baseCommit': base, 'candidate': candidate, 'sourceFingerprints': inputs,
 'actualMainBrowser': {'focused': '34/34', 'adjacent': '58/58', 'total': 92,
   'qualification': 'Maintained React/API client with intercepted synthetic API,not production signing or nativePG'},
 'baseline': {'tests': 12, 'passed': 2, 'failed': 10, 'sourceCommit': base,
   'qualification': 'Two real-empty positives pass;10 active-dialog error assertions fail,no pageErrors;not10 independent defects'},
 'binding': 'Main34 ran before commit at dirty670;unchanged staged bytes became6f. Build/58/static actually ran atclean6f;independent QA validates fixed candidate separately.',
 'checks': {'build': 'passed', 'listStyle': 'passed', 'noExternalFonts': 'passed',
   'strict': 'exit2;86 existing=72violations/14unresolved;Counter multiset0delta,duplicates retained',
   'lint': 'exit2;existing missingESLint configuration;not passed'},
 'staticBaselineReuse': {'actualOriginalHead': '7e43939b519b743e73ca993d66632b1316655fed',
   'baselineFrontendGitTree': baseline_tree, 'sameFullFrontendTreeAtCurrentBase': True,
   'originalPackage': 'docs/development/branch-review-20261110-record-change-async/evidence/main.zip',
   'reusedReportSha256': sha((raw / 'premium-baseline-reused.json').read_bytes()),
   'scope': 'Reuse original actual official-script result after source identity proof;not a new baseline scan'},
 'passwordScope': 'Tests confirm existing in-memory fields unchanged on failure;not new credential-retention/storage policy.No confirm/password-cleanup change.',
 'unchanged': ['backend', 'API', 'schema', 'knowledge353', 'sharedcomponents', 'policy', 'DESIGN', 'contracts'],
 'a23': 'Separate candidate error belongs to a distinct async lifetime;no extra cache,fallback authorization,retry or framework',
 'wholeFileCompleted': 0, 'historicalUnique': 'unknown', 'completeOverallAudit': False,
 'remaining': ['W2-W7/fullsemantic/UI86/A12/highrisk/fullmatrices/A23 including already reviewed',
   'Original request-listSQL and audit-eventDB paging proposals still unanswered/unimplemented',
   'Candidate-versionN+1 remains source signal,not measured;quantify before discussion/optimization',
   'Family4N/optionfull-load/capacityUNKNOWN/paused generic-signature and production-dialog queue']}
(raw / 'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'candidate': candidate, 'browserPassed':92,'baselinePassed':2,'baselineFailed':10,'sourceInputs':27,'staticAdded':0},ensure_ascii=False))
