from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
raw=Path(__file__).parent;wt=Path('/tmp/edhr-impact-qa-20261111')
def git(*args):return subprocess.check_output(['git',*args],cwd=wt,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
candidate='72d3bac42a759ceb415f4592b67c903c0cdfa49d';target='7629506c6a067252e4f6a7b1e3f26b9f523d2489'
assert git('rev-parse','HEAD')==candidate and git('rev-parse','origin/edhr-dev')==target and git('status','--porcelain')==''
for item in json.loads((raw/'source-binding.json').read_text())['inputs']:
 assert item['sha256']==sha((wt/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=wt))
quality=yaml.safe_load((raw/'quality-result.yaml').read_text())['qualityResult']
assert quality['result']=='passed' and len(quality['checks'])==14 and all(x['outcome']=='passed' for x in quality['checks'])
assert not quality['findings'] and not quality['blockingConditions']
end={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'workingTreeFinal':git('status','--porcelain'),
 'qualityResult':'passed','requiredChecks':14,'sourceInputsVerified':406,'allOwnExecutionsFinished':True,'mainDependenciesPreserved':Path('/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules').is_dir()}
(raw/'final-check.json').write_text(json.dumps(end,indent=2)+'\n')
items=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file() or p.name in ['manifest.json','SHA256SUMS'] and p.parent==raw:continue
 data=p.read_bytes();items.append({'path':str(p.relative_to(raw)),'bytes':len(data),'sha256':sha(data)})
manifest={'scope':'Independent L2 final QA;manifest and SHA256SUMS excluded from payload list;SHA256SUMS separately includes manifest','baseCommit':target,'headCommit':candidate,'qualityResult':'passed','files':items}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
lines=[x['sha256']+'  '+x['path'] for x in items]
lines.append(sha((raw/'manifest.json').read_bytes())+'  manifest.json')
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for item in items:
 data=(raw/item['path']).read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
print(json.dumps({'qualityResult':'passed','requiredChecks':14,'payloadFiles':len(items),'hashChecks':len(lines),'manifestSha256':sha((raw/'manifest.json').read_bytes())},indent=2))
