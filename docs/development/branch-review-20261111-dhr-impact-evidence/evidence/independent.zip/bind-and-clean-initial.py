from pathlib import Path
import datetime,hashlib,json,shutil,subprocess
import yaml
raw=Path(__file__).parent;root=Path('/tmp/edhr-impact-qa-20261111');main=Path('/workspace/edhr-nexus-frontend')
candidate='72d3bac42a759ceb415f4592b67c903c0cdfa49d';target='7629506c6a067252e4f6a7b1e3f26b9f523d2489'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
def sha(data):return hashlib.sha256(data).hexdigest()
assert git('rev-parse','HEAD')==candidate
subprocess.run(['git','fetch','origin','refs/heads/edhr-dev:refs/remotes/origin/edhr-dev'],cwd=root,check=True)
assert git('rev-parse','origin/edhr-dev')==target
paths=set(x['path'] for x in json.loads((raw/'final_verified/run.json').read_text())['sourceFingerprints'])
knowledge=json.loads((raw/'knowledge/run.json').read_text())
assert knowledge['head']==candidate and knowledge['exitCode']==0
assert json.loads((raw/'knowledge/test-summary.json').read_text())==dict(tests=89,failures=0,errors=0,skipped=0)
for item in knowledge['sourceFingerprints']:
 assert item['sha256']==sha((root/item['path']).read_bytes())==sha(blob(candidate,item['path']))==sha(blob(target,item['path']))
 paths.add(item['path'])
assert len(knowledge['sourceFingerprints'])==359
paths.update(['docs/architecture/business-knowledge-model.md','docs/development/branch-review-20261026-capacity-audit/audit-charter.md',
 'docs/development/branch-review-20261026-capacity-audit/risk-register.yaml','docs/development/branch-review-20261026-capacity-audit/findings.md',
 'docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/dhr-fill-and-review-user-confirmed.md',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrSummaryController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java'])
inputs=[]
for path in sorted(paths):
 data=(root/path).read_bytes();assert data==blob(candidate,path)
 dest=raw/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':path,'bytes':len(data),'sha256':sha(data)})
changed=git('diff','--name-only',target,candidate).splitlines()
assert changed==['docs/development/branch-review-20261111-dhr-impact-evidence/decision-package.yaml','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java']
assert git('diff','--name-only',target,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','docs/agents')==''
before=git('status','--porcelain');assert before=='?? gmp-platform/frontend/node_modules'
link=root/'gmp-platform/frontend/node_modules';assert link.is_symlink() and link.resolve()==(main/'gmp-platform/frontend/node_modules').resolve()
link.unlink();assert git('status','--porcelain')=='' and (main/'gmp-platform/frontend/node_modules').is_dir()
cleanup={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedPgRemoved':json.loads((raw/'final_verified/cleanup.json').read_text())['removed'],
 'runtimeUntracked':before,'onlyOwnedDependencySymlinkRemoved':True,'mainDependenciesPreserved':True,'finalWorkingTreeState':git('status','--porcelain'),'repositoryModified':False}
(raw/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
inventory=[]
for p in sorted((root/'docs/knowledge').rglob('*')):
 if p.is_file():inventory.append({'path':str(p.relative_to(root)),'sha256':sha(p.read_bytes())})
assert len(inventory)==353
binding={'role':'Independent final QA;read-only product/test/config;no children','baseCommit':target,'headCommit':candidate,'testedCommit':candidate,'contractReadCommit':candidate,'actualTargetCommit':git('rev-parse','origin/edhr-dev'),
 'workingTreeFinal':git('status','--porcelain'),'changedFiles':changed,'knowledgeCount':len(inventory),'knowledgeUnchanged':True,'inputs':inputs,'knowledgeInventory':inventory}
(raw/'source-binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
(raw/'candidate.diff').write_bytes(subprocess.check_output(['git','diff',target,candidate],cwd=root))
ontology=Path('/tmp/edhr-dhr-impact-ontology-20261111');result=yaml.safe_load((ontology/'ontology-result.yaml').read_text())['ontologyResult']
assert result['result']=='not-applicable' and result['contractBaseline']['sourceCommit']==candidate and result['contractBaseline']['targetCommit']==target
assert not result['conflicts'] and not result['questions'] and not result['changedArtifacts']
manifest=json.loads((ontology/'manifest.json').read_text())
for item in manifest['files']:
 data=(ontology/item['path']).read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
for line in (ontology/'SHA256SUMS').read_text().splitlines():
 checksum,path=line.split('  ',1);assert sha((ontology/path).read_bytes())==checksum
copies=['ontology-result.yaml','REVIEW.md','finite-review-records.json','finite-review-summary.json','candidate-binding.json','risk-deduplication.json','manifest.json','SHA256SUMS']
for p in copies:
 dest=raw/'reviewed-ontology'/p;dest.parent.mkdir(exist_ok=True);shutil.copyfile(ontology/p,dest)
(raw/'ontology-original-verification.json').write_text(json.dumps({'result':'not-applicable','candidate':candidate,'originalManifestPayloadFilesVerified':len(manifest['files']),
 'originalManifestSha256':sha((ontology/'manifest.json').read_bytes()),'copiedSubsetForReview':copies,'qualification':'Original complete role directory hashes verified;subset copied,not pretending this copied subset alone contains all role payloads'},indent=2)+'\n')
print(json.dumps({'protectedInputs':len(inputs),'mainRunInputs':49,'knowledgeFiles':353,'knowledgeValidatorInputs':359,'ontology':'not-applicable','cleanup':cleanup},indent=2))
