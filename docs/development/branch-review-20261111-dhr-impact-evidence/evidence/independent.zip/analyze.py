from pathlib import Path
from collections import Counter,defaultdict
import datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET

raw=Path(__file__).parent;root=Path('/tmp/edhr-impact-qa-20261111');phase=raw/'final_verified';obs=phase/'observations'
candidate='72d3bac42a759ceb415f4592b67c903c0cdfa49d';target='7629506c6a067252e4f6a7b1e3f26b9f523d2489'
def read(path):return json.loads(path.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
run=read(phase/'run.json');assert run['head']==candidate and run['exitCode']==0
assert run['workingTreeStatus']=='?? gmp-platform/frontend/node_modules'
assert read(phase/'test-summary.json')['totals']==dict(tests=72,failures=0,errors=0,skipped=0)
assert read(phase/'cleanup.json')['removed'] is True
for item in run['sourceFingerprints']:
 assert item['sha256']==sha((root/item['path']).read_bytes())==sha(blob(candidate,item['path']))==sha((phase/'source'/item['path']).read_bytes())
jfr=defaultdict(list)
for line in (raw/'jfr-recomputed.tsv').read_text().splitlines():
 name,thread,events,bytes_,path=line.split('\t',4);jfr[name[:-4]].append(dict(thread=int(thread),events=int(events),bytes=int(bytes_),path=path))
observations={}
for p in obs.glob('*.json'):
 item=read(p)
 if 'measuredThreadId' in item:observations[item['name']]=item
assert len(observations)==50 and len(jfr)==50
for name,item in observations.items():
 records=[x for x in jfr[name] if x['thread']==item['measuredThreadId'] or x['thread']==0]
 assert sum(x['bytes'] for x in records)==item['trackedLogicalReadBytes'],name
 assert sum(x['events'] for x in records)==item['trackedReadEvents'],name
 item['independentJfrBytes']=sum(x['bytes'] for x in records)
 item['independentJfrEvents']=sum(x['events'] for x in records)
 assert item['selectStatements']==sum(x.lstrip().lower().startswith('select') for x in item['jdbcSql']+item['hibernateSql']),name
states=[]
for p in obs.glob('*-state.json'):
 state=read(p);assert len(state['before'])==len(state['after'])==11 and state['identical'] and state['before']==state['after'],p
 states.append(p.name)
assert len(states)==29
for count in [0,1,100,300]:
 for lock in ['false','true']:
  item=observations[f'impact_count_{count}_{lock}']
  assert item['selectStatements']==6 and item['trackedLogicalReadBytes']==count*68
  assert not item['result']['evidenceChanges'] and item['rejection'] is None
for change in ['tampered','missing','pending','new','unlinked','metadata','outside','source_changed']:
 for lock in ['false','true']:
  item=observations[f'impact_change_{change}_{lock}'];changes=item['result']['evidenceChanges']
  if change=='outside':assert not changes
  elif change=='source_changed':assert len(changes)==1 and changes[0]['recordId']=='500001'
  else:assert len(changes)==1 and changes[0]['attachmentId']==('1002' if change=='new' else '1000')
for name,sql,bytes_ in [('impact_50mib_version',12,52428800),('impact_50mib_review',19,104857600),('impact_50mib_approve',29,52428800)]:
 item=observations[name];assert item['selectStatements']==sql and item['trackedLogicalReadBytes']==bytes_ and item['rejection'] is None
assert observations['impact_50mib_review']['result']['canAct'] is True
assert observations['impact_50mib_approve']['result']['outcome']=='APPROVED'
assert '不能按过时证据批准' in observations['impact_stale_approve']['rejection']
for suffix in ['detail','approve','stale_hash']:
 item=observations['impact_denied_'+suffix];assert item['trackedLogicalReadBytes']==0 and item['rejection']
frozen=read(obs/'impact-frozen-review.json')
assert frozen['submitted']['status']=='PENDING_REVIEW' and frozen['approved']['outcome']=='APPROVED'
assert frozen['configuredSignatureRequired'] is False and frozen['frozenAttachmentsBefore']==frozen['frozenAttachmentsAfter']
assert frozen['frozenAttachmentsAfter'][0]['size']==52428800

# Count actual successful server EXECUTEs, not parse/bind events. SQL continuation lines stay in each log record.
records=re.split(r'(?=^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+ UTC \[\d+\])',(phase/'postgres.log').read_text(),flags=re.M)
server=defaultdict(list)
for record in records:
 match=re.search(r' audit_summary_([a-z0-9_]+) \d+ LOG:  duration: [0-9.]+ ms  execute [^:]+: (.*)',record,re.S)
 if match:server[match[1]].append(match[2].strip())
def normalize(sql):return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql)).strip().lower()
sql_checks=[]
for name,item in observations.items():
 selects=[x for x in server[name] if x.lstrip().lower().startswith('select')]
 client=[x for x in item['jdbcSql']+item['hibernateSql'] if x.lstrip().lower().startswith('select')]
 # Driver type resolution can issue its own uninstrumented catalog SELECTs; report separately.
 difference=Counter(map(normalize,selects))-Counter(map(normalize,client))
 missing=Counter(map(normalize,client))-Counter(map(normalize,selects))
 assert not missing,(name,missing)
 extras=list(difference.elements())
 assert all('pg_catalog' in x or 'pg_type' in x for x in extras),(name,extras)
 sql_checks.append({'name':name,'clientBusinessSelects':len(client),'serverSelects':len(selects),'driverCatalogSelects':extras,
  'otherServerStatements':[x for x in server[name] if not x.lstrip().lower().startswith('select')]})
assert len(sql_checks)==50
(raw/'server-sql-review.json').write_text(json.dumps({'qualification':'Actual successful execute log records;client SQL normalized only whitespace/placeholder numbering;driver catalog separately counted','observations':sql_checks},ensure_ascii=False,indent=2)+'\n')
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':target,'headCommit':candidate,
 'tests':dict(tests=72,failures=0,errors=0,skipped=0),'nativePostgres':34,'otherBackend':38,'otherQualification':'6 H2 workflow/signature plus24 H2 persistence plus8 Mockito unit;not72 native or HTTP/browser',
 'protectedInputs':len(run['sourceFingerprints']),'jfrIndependentRecomputed':50,'statesCompared':len(states),'tablesPerState':11,'sqlObservationsVerified':len(sql_checks),
 'largeOriginal':{n:{k:observations[n][k] for k in ['selectStatements','trackedLogicalReadBytes','trackedReadEvents','threadAllocatedBytes','elapsedNanos']} for n in ['impact_50mib_version','impact_50mib_review','impact_50mib_approve']},
 'constantAttachmentSql':{'counts':[0,1,100,300],'lockModes':[False,True],'selects':6},
 'scope':'Existing risk PERF-DHR-REVIEW-REPEAT-001 quantified;product/knowledge/policy unchanged;no production capacity/physical disk/peak heap claim;controller audit/download scope inspected but not full HTTP measured'}
(raw/'independent-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
