import java.nio.file.*;
import java.util.*;
import jdk.jfr.consumer.*;

class VerifyJfr {
    public static void main(String[] args) throws Exception {
        Path directory=Path.of(args[0]);
        try(var paths=Files.list(directory)) {
            for(Path path:paths.filter(p->p.toString().endsWith(".jfr")).sorted().toList()) {
                String name=path.getFileName().toString();
                Map<Long,Map<String,long[]>> threads=new TreeMap<>();
                try(var input=new RecordingFile(path)) {
                    while(input.hasMoreEvents()) {
                        RecordedEvent event=input.readEvent();
                        if(!event.getEventType().getName().equals("jdk.FileRead")) continue;
                        String file=event.getString("path");
                        if(file==null || !Path.of(file).getFileName().toString().matches("original-[0-9]+\\.png")) continue;
                        long id=event.getThread().getJavaThreadId();
                        long[] totals=threads.computeIfAbsent(id, k->new TreeMap<>()).computeIfAbsent(file,k->new long[2]);
                        totals[0]++;totals[1]+=event.getLong("bytesRead");
                    }
                }
                for(var thread:threads.entrySet()) for(var file:thread.getValue().entrySet()) {
                    System.out.println(name+"\t"+thread.getKey()+"\t"+file.getValue()[0]+"\t"+file.getValue()[1]+"\t"+file.getKey());
                }
                if(threads.isEmpty()) System.out.println(name+"\t0\t0\t0\t");
            }
        }
    }
}
