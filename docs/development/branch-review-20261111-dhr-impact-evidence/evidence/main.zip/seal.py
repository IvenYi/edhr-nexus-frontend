from pathlib import Path
import datetime,hashlib,json,shutil,zipfile
repo=Path('/workspace/edhr-nexus-frontend');report=repo/'docs/development/branch-review-20261111-dhr-impact-evidence';out=report/'evidence';out.mkdir(exist_ok=True)
roots={'main':Path(__file__).parent,'ontology':Path('/tmp/edhr-dhr-impact-ontology-20261111'),'independent':Path('/tmp/edhr-dhr-impact-final-qa-20261111')}
role_manifests={'ontology':'179ca3cccbbf37c27ee351fff36cf94bccab140f3adb1fb62efef3a56e372294','independent':'a02e880999c4fe5893bffcc2d34f73652661cec62f3947d19509aa5d4d9e45c5'}
def sha(b):return hashlib.sha256(b).hexdigest()
packages=[]
for label,root in roots.items():
 if label!='main':
  assert sha((root/'manifest.json').read_bytes())==role_manifests[label]
  for item in json.loads((root/'manifest.json').read_text())['files']:
   data=(root/item['path']).read_bytes();assert len(data)==item['bytes'] and sha(data)==item['sha256']
  for line in (root/'SHA256SUMS').read_text().splitlines():
   checksum,path=line.split('  ',1);assert sha((root/path).read_bytes())==checksum
 members=[];archive=out/(label+'.zip')
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(root.rglob('*')):
   if not p.is_file():continue
   data=p.read_bytes();relative=str(p.relative_to(root));members.append({'path':relative,'bytes':len(data),'sha256':sha(data)});z.writestr(relative,data)
 with zipfile.ZipFile(archive) as z:
  assert set(z.namelist())=={x['path'] for x in members}
  for item in members:
   data=z.read(item['path']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
 manifest=out/(label+'-manifest.json');manifest.write_text(json.dumps({'package':label,'files':members},ensure_ascii=False,indent=2)+'\n')
 packages.append({'name':label,'path':str(archive.relative_to(report)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'members':len(members),'manifest':str(manifest.relative_to(report)),'manifestSha256':sha(manifest.read_bytes())})
for name in ['main-analysis.json','inventory-summary.json','sql-multiset-verification.json']:shutil.copyfile(roots['main']/name,report/name)
shutil.copyfile(roots['ontology']/'ontology-result.yaml',report/'ontology-result.yaml');shutil.copyfile(roots['ontology']/'REVIEW.md',report/'ontology-review.md')
shutil.copyfile(roots['independent']/'quality-result.yaml',report/'quality-result.yaml');shutil.copyfile(roots['independent']/'review.md',report/'independent-review.md')
index={'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':'72d3bac42a759ceb415f4592b67c903c0cdfa49d','packages':packages,'roleFinalManifestSha256':role_manifests,'allArchiveMemberHashesVerified':True,'originalRoleManifestsAndSha256SumsVerified':True,'scope':'Test-only candidate;actual canonical native34+H2/mock38 and knowledge89;50 JFR/SQL observations and29x11 content digests;no performance implementation;next-batch user authorization is an L0 overlay in performance-next.md'}
(report/'evidence-packages.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n');print(json.dumps(index,ensure_ascii=False,indent=2))
