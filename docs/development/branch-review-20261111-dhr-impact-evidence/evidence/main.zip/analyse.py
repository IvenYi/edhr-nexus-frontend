from pathlib import Path
import collections,datetime,hashlib,json,re,subprocess

repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;phase=raw/'final';out=phase/'observations'
candidate='72d3bac42a759ceb415f4592b67c903c0cdfa49d';target='7629506c6a067252e4f6a7b1e3f26b9f523d2489'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
run=read(phase/'run.json');assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
for item in run['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha((phase/'source'/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=repo))
assert len(run['sourceFingerprints'])==49
summary=read(phase/'test-summary.json');assert summary['totals']==dict(tests=72,failures=0,errors=0,skipped=0)
assert not summary['missingFreshReports']
assert subprocess.check_output(['git','diff','--name-only',target,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents'],cwd=repo,text=True)==''
observations={p.stem:read(p) for p in out.glob('*.json') if p.with_suffix('.jfr').exists()}
assert len(observations)==50
jfr_tool='/workspace/.edhr-cloud-tools/jdk-21.0.12.1+1/bin/jfr'
jfr_results=[]
for name,ob in sorted(observations.items()):
 command=[jfr_tool,'print','--json','--events','jdk.FileRead',str(out/(name+'.jfr'))]
 data=json.loads(subprocess.check_output(command));events=[]
 for event in data['recording']['events']:
  value=event['values'];path=value.get('path','')
  if value['eventThread']['javaThreadId']==ob['measuredThreadId'] and re.search(r'/original-\d+\.png$',path):
   events.append({'path':path,'bytesRead':value['bytesRead']})
 assert sum(x['bytesRead'] for x in events)==ob['trackedLogicalReadBytes'],name
 assert len(events)==ob['trackedReadEvents'],name
 count=sum(sql.lstrip().lower().startswith('select') for sql in ob['jdbcSql']+ob['hibernateSql'])
 assert count==ob['selectStatements'],name
 jfr_results.append({'name':name,'command':command,'events':events,'bytesRead':ob['trackedLogicalReadBytes'],'eventCount':len(events),'sqlSelects':count})
(raw/'external-jfr-verification.json').write_text(json.dumps(jfr_results,indent=2)+'\n')
states=[read(p) for p in out.glob('impact*-state.json')]
assert len(states)==29
assert all(s['identical'] and s['before']==s['after'] and len(s['before'])==11 for s in states)
frozen=read(out/'impact-frozen-review.json');assert frozen['frozenAttachmentsBefore']==frozen['frozenAttachmentsAfter']
assert frozen['submitted']['status']=='PENDING_REVIEW' and frozen['approved']['outcome']=='APPROVED'
assert frozen['configuredSignatureRequired'] is False
for count in [0,1,100,300]:
 for lock in [False,True]:
  x=observations[f'impact_count_{count}_{str(lock).lower()}'];assert x['selectStatements']==6 and x['trackedLogicalReadBytes']==count*68
  assert x['result']['evidenceChanges']==[]
for entry in ['detail','approve','stale_hash']:
 x=observations['impact_denied_'+entry];assert x['trackedLogicalReadBytes']==0 and x['rejection']
for entry,byte_count in [('version',52428800),('review',104857600),('approve',52428800)]:
 assert observations['impact_50mib_'+entry]['trackedLogicalReadBytes']==byte_count
# Parse successful server executions, preserving complete multiline SQL and parameter DETAIL.
lines=(phase/'postgres.log').read_text().splitlines();server=collections.defaultdict(list)
header=re.compile(r'^\d{4}-\d\d-\d\d .*?\[\d+\] \S+ (\S+) \d+ LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)$')
current=None
for line in lines:
 match=header.match(line)
 if match:
  app,sql=match.groups();current=None
  if app.startswith('audit_summary_'):
   item={'sql':sql};server[app].append(item);current=item
 elif line.startswith('\t') and current is not None:current['sql']+='\n'+line[1:]
 elif re.match(r'^\d{4}-\d\d-\d\d ',line):current=None
server_counts=[]
for name,ob in observations.items():
 rows=server[ob['applicationName']]
 actual=[r['sql'] for r in rows if r['sql'].lstrip().lower().startswith('select')]
 expected=ob['jdbcSql']+ob['hibernateSql']
 assert len(actual)>=ob['selectStatements'],(name,len(actual),ob['selectStatements'])
 for sql in expected:
  normalized=re.sub(r'\s+',' ',sql.strip()).lower()
  normalized=re.sub(r'\$\d+','?',normalized)
  assert any(re.sub(r'\$\d+','?',re.sub(r'\s+',' ',a['sql'].strip()).lower())==normalized for a in rows), (name,sql)
 server_counts.append({'name':name,'instrumentedSelects':ob['selectStatements'],'serverSelects':len(actual),'extraServerSelects':len(actual)-ob['selectStatements']})
(raw/'server-executions.json').write_text(json.dumps(dict(server),ensure_ascii=False,indent=2)+'\n')
(raw/'server-count-verification.json').write_text(json.dumps(server_counts,indent=2)+'\n')
knowledge=read(raw/'knowledge/test-summary.json');assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
kr=read(raw/'knowledge/run.json');assert kr['head']==candidate and kr['workingTreeState']=='' and kr['exitCode']==0
for item in kr['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',target+':'+item['path']],cwd=repo))
assert len(kr['sourceFingerprints'])==359
assert read(phase/'cleanup.json')['removed'] is True
performance={name:{k:x[k] for k in ['selectStatements','trackedLogicalReadBytes','trackedReadEvents','threadAllocatedBytes','elapsedNanos','rejection']} for name,x in observations.items() if name.startswith('impact')}
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'protectedInputsMatch':49,'knowledgeInputsMatch':359,
 'tests':summary['totals'],'nativePostgres':34,'h2Supplemental':30,'mockUnit':8,'knowledge':knowledge,'observations':len(observations),'externalJfrVerified':len(jfr_results),
 'readStateComparisons':29,'readStateTablesEach':11,'serverSqlShapesAndReadCountsVerified':True,'extraServerSelects':sum(x['extraServerSelects'] for x in server_counts),'performance':performance,'riskIds':['PERF-DHR-REVIEW-REPEAT-001'],
 'limits':['No product change or performance fix','Counters are cumulative operation-thread allocation/logical file reads,not peak/RSS/physical IO/SLA','Direct service plus native PG,not HTTP/browser/initial START/signed-native approval;explicit fixture button has no signing event','Existing H2 signed/return/concurrent approval regression remains supplemental','Controller audit/download first call heavy detail:source-only transfer scope,not measured end-to-end totals','Global strict86/lint config gap and whole audit remain open','Earlier focused16 uses earlier evidence-output test bytes;final72 binds final candidate;initial missing-runner-path ran zero tests']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='performance'},ensure_ascii=False,indent=2))
