from pathlib import Path
import collections,json,re
raw=Path(__file__).parent;server=json.loads((raw/'server-executions.json').read_text());rows=[]
def norm(sql):return re.sub(r'\$\d+','?',re.sub(r'\s+',' ',sql.strip()).lower())
for p in sorted((raw/'final/observations').glob('*.json')):
 if not p.with_suffix('.jfr').exists():continue
 ob=json.loads(p.read_text())
 expected=collections.Counter(norm(s) for s in ob['jdbcSql']+ob['hibernateSql'] if s.lstrip().lower().startswith('select'))
 actual=collections.Counter(norm(s['sql']) for s in server[ob['applicationName']] if s['sql'].lstrip().lower().startswith('select'))
 missing=expected-actual;extra=actual-expected;assert not missing,(p.name,missing)
 assert sum(expected.values())==ob['selectStatements']
 for sql,count in extra.items():assert 'from pg_catalog.pg_type' in sql and count==1,(p.name,extra)
 if p.stem.startswith('impact_'):assert actual==expected,(p.name,extra)
 rows.append({'name':p.stem,'expectedSelects':sum(expected.values()),'actualServerSelects':sum(actual.values()),'missing':list(missing.items()),'extraDriverCatalog':list(extra.items())})
assert len(rows)==50 and sum(sum(c for _,c in r['extraDriverCatalog']) for r in rows)==1
result={'observations':len(rows),'newImpactObservations':sum(r['name'].startswith('impact_') for r in rows),'allSelectMultisetsMatchApartFromOneDriverCatalog':True,'rows':rows,'totalInstrumentedSelects':sum(r['expectedSelects'] for r in rows),'totalServerSelects':sum(r['actualServerSelects'] for r in rows)}
(raw/'sql-multiset-verification.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='rows'})
