from pathlib import Path
from collections import Counter
import datetime,hashlib,json,subprocess,sys,zipfile,yaml

repo=Path('/workspace/edhr-nexus-frontend');out=Path(__file__).parent
target='7629506c6a067252e4f6a7b1e3f26b9f523d2489'
dp='docs/development/branch-review-20261111-dhr-impact-evidence/decision-package.yaml'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def blob(commit,path):return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=repo)
def write(name,data):
 (out/name).parent.mkdir(parents=True,exist_ok=True)
 (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/agents/quality-verifier.md']
background=['docs/architecture/business-knowledge-model.md',dp,
 'docs/development/branch-review-20261026-capacity-audit/risk-register.yaml',
 'docs/development/branch-review-20261026-capacity-audit/findings.md',
 'docs/development/branch-review-20261026-capacity-fixes/scope-review.md',
 'docs/development/branch-review-20261110-record-reference-context/review.md']
sources=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/'+name+'.java' for name in ['DhrEvidenceImpactService','DhrReviewService','DhrSummaryService','DhrAttachmentService','DhrFrozenEvidenceIntegrity']]
sources+=['gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrSummaryController.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrReviewLifecycleIntegrationTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrEvidenceBatchPostgresTest.java']
knowledge=git('ls-files','docs/knowledge').splitlines()
assert len(knowledge)==353
for p in knowledge:
 assert (repo/p).read_bytes()==blob(target,p),p
 if p.endswith('.yaml'):
  assert yaml.safe_load((repo/p).read_text())['knowledgeModelVersion']=='0.3.25',p

selections={
 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml': {
  'DEC-0063-02': ('按生产对象完整归集、身份逐实例，附件不是第四类表单实例。','DhrSummaryService.candidates/submit;DhrEvidenceImpactService.changes'),
  'DEC-0063-05': ('同版冻结、详情和审批的历史基准不混用当前值；新变化只作提示。','DhrSummaryService.submit/version;DhrEvidenceImpactService.changes'),
  'DEC-0063-06': ('NONE/REQUIRED与已发布流程引用保持，真实冻结DHR字段fixture不等于本批重跑首次START。','DhrSummaryService.submit;WorkflowEngine.createDhrSummaryInstance'),
  'DEC-0063-10': ('50MiB含边界、原件SHA与解除保留；本批观察摘要读取，不代替七格式上传/核验全矩阵。','DhrAttachmentService.MAX_BYTES/forSubmission/verifiedFile;DhrEvidenceImpactService.changes'),
  'DEC-0063-14': ('人工三项确认不是自动判质量或签名有效；确认随checkResult冻结。','DhrSummaryService.submit;DhrReviewService.hasCompleteManualReview')},
 'docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml': {
  'DEC-0068-04': ('源变更作废归记录控制；在审非生效，DHR读时提示不修改来源。','RecordControlService.submit/applyResult;DhrEvidenceImpactService.requireNoPendingApplications/sourceEffective'),
  'DEC-0068-05': ('有效变化阻断过时批准，人工退回而非自动状态回退；读详情不能代替写时锁内重核。','DhrReviewService.detail/act/evidenceChanges'),
  'DEC-0068-06': ('旧批准和快照保持；下一版由人工新建草稿/重新提交，不就地修旧证据。','DhrSummaryService.version/prepareNextDraft;DhrReviewService.act'),
  'DEC-0068-11': ('任务资格和该冻结版附件身份/摘要双边界；本轮无新增下载授权。','DhrReviewService.detail;DhrReviewController.attachment;DhrAttachmentService.downloadableFile'),
  'DEC-0068-13': ('活动申请阻断汇总提交和批准，原有效修订仍可查看，结束不自动批准。','DhrSummaryService.submit;DhrReviewService.act;DhrEvidenceImpactService.requireNoPendingApplications'),
  'DEC-0068-14': ('关联DHR待审阻断新申请，最终服务在父锁内重核；只局部替代13中未确认发起资格。','RecordControlService.submit;DhrEvidenceImpactService.requireRecordControlAllowed')},
 'docs/knowledge/rules/dhr-summary.yaml': {
  'rule.dhr-summary-freeze-version': ('冻结成员、快照、附件、人工核查和流程同版；读调用/失败不应净化历史。','DhrSummaryService.submit/version;DhrFrozenEvidenceIntegrity.verify'),
  'rule.dhr-summary-block-stale-approval': ('变化提示和批准阻断保持，不能为降低IO跳过SHA或锁内来源比较。','DhrEvidenceImpactService.changes;DhrReviewService.act'),
  'rule.dhr-summary-controlled-attachment-upload': ('附件上限和原件SHA现行规范合理；数值不是本轮新政策或总附件数量上限。','DhrAttachmentService.MAX_BYTES/upload;DhrEvidenceImpactService.changes'),
  'rule.dhr-review-task-frozen-attachment-download': ('任务授权不由通用DHR查看权限替代，性能观察不扩展文件范围。','DhrReviewController.attachment;DhrReviewService.detail;DhrAttachmentService.downloadableFile')}
}
records=[]
for path,ids in selections.items():
 doc=yaml.safe_load((repo/path).read_text())
 def walk(v):
  if isinstance(v,dict):
   if v.get('id') in ids:
    reason,scope=ids[v['id']]
    lines=(repo/path).read_text().splitlines();line=next(i for i,x in enumerate(lines,1) if x.strip()=='- id: '+v['id'])
    records.append({'id':v['id'],'recordType':'rule' if v['id'].startswith('rule.') else 'decisionStatement','sourcePath':path,'sourceLocator':f'{path}:{line}',
     'assetMaturity':{'status':v['status'],'visibility':v['visibility']},'auditScope':'current;finite source/semantic review','reviewStatus':'reviewed','conclusion':'consistent',
     'conclusionScope':reason,'implementationRange':scope,'normativeRecord':v,'evidenceTypes':['user-confirmed versioned source','original-evidence source inspection'],
     'evidenceReferences':['docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/dhr-filling-review-confirmed.md'],
     'runtimeQualification':'This ontology role does not execute or certify Maven/PostgreSQL/browser;current runtime outcomes belong to main/QA originals'})
   for w in v.values():walk(w)
  elif isinstance(v,list):
   for w in v:walk(w)
 walk(doc)
 assert len([x for x in records if x['sourcePath']==path])==len(ids)

path='docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml';doc=yaml.safe_load((repo/path).read_text())
for v in doc['decisions'][0]['implementationDiscrepancies']:
 records.append({'id':v['id'],'recordType':'implementationDiscrepancy','sourcePath':path,'sourceLocator':v['id'],
  'assetMaturity':{'status':v['status'],'visibility':v['visibility']},'auditScope':'existing out-of-scope remaining high;not newly counted','reviewStatus':'reviewed','conclusion':'evidence-gap',
  'conclusionScope':'保留当前声明已收窄的剩余范围，本批附件容量/原子性观察不关闭通用质量/异常/源签名自动判读或提醒组合矩阵。','normativeRecord':v,
  'evidenceTypes':['original-evidence versioned current boundary','secondary-reference previous runtime descriptions'],
  'evidenceReferences':['docs/knowledge/evidence/workflow-record-dhr-closure-20261102.md']})
path='docs/knowledge/open-questions.yaml';q=next(x for x in yaml.safe_load((repo/path).read_text())['questions'] if x['id']=='question.multi-tenant-workflow-isolation')
records.append({'id':q['id'],'recordType':'question','sourcePath':path,'sourceLocator':q['id'],'assetMaturity':{'visibility':'internal'},
 'auditScope':'existing non-MVP boundary;not blocking current default tenant','reviewStatus':'reviewed','conclusion':'needs-decision',
 'conclusionScope':'沿当前默认单租户fixture只能验证既有来源范围过滤，不推导完整多租户隔离或关闭此待决。','normativeRecord':q,'evidenceTypes':['original-evidence versioned open question'],'evidenceReferences':[path]})
assert len(records)==18 and Counter(x['conclusion'] for x in records)==Counter({'consistent':15,'evidence-gap':2,'needs-decision':1})
write('finite-review-records.json',records)
write('finite-review-summary.json',{'records':18,'reviewed':18,'conclusions':dict(Counter(x['conclusion'] for x in records)),'knowledgeFilesInventory':353,'newUniqueGlobalSemanticCount':'not asserted;overlaps earlier audits','wholeAuditComplete':False})

payloads=[]
for path in sorted(set(contracts+background+sources+knowledge)):
 data=(repo/path).read_bytes();dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 payloads.append({'path':path,'bytes':len(data),'sha256':sha(data),'equalsTargetGit':data==blob(target,path) if path!=dp else False})
write('initial-source-binding.json',{'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':git('rev-parse','HEAD'),'target':target,'contractReadCommit':target,'workingTreeState':git('status','--porcelain'),
 'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeInventoryFiles':353,'knowledgeUnchanged':True,'scope':'Initial only;test bytes may continue changing before fixed candidate;no final runtime claim','inputs':payloads})
write('knowledge-inventory.json',[x for x in payloads if x['path'] in knowledge])
write('risk-deduplication.json',{'sourceRisk':'PERF-DHR-REVIEW-REPEAT-001','firstRepositoryReference':'docs/development/branch-review-20261026-capacity-audit/findings.md:9',
 'priorSourceAndH2Observation':'DhrReviewLifecycleIntegrationTest.reviewDetailCurrentlyComparesTheSameFrozenVersionTwice',
 'currentSource':['DhrReviewService.detail -> DhrSummaryService.version -> changes(false);then evidenceChanges(false)','DhrEvidenceImpactService.changes attachment SHA uses Files.readAllBytes and scans frozen attachment array for each current item'],
 'disposition':'Same known risk;canonical/native IO and allocation evidence increments are not a new unique defect or approval to optimize',
 'otherRisksPreserved':['PERF-DHR-EVIDENCE-NPLUS1-001 old per-form lookup already separately fixed;do not reopen as present unchanged code defect','PDF/export/verification/upload resource costs and family/query risks remain separately scoped'],
 'businessConstraints':['Never skip authorization/SHA/frozen membership','No cross-request cached eligibility','Approval keeps its own parent/record locks and fresh comparison','Do not rewrite old approvals/frozen signatures or auto-return','No production capacity/SLA from cumulative thread allocation or logical file read bytes']})
print(json.dumps({'finiteRecords':len(records),'sourceInputs':len(payloads),'knowledgeFiles':353,'resultSoFar':'not-applicable;pending final candidate binding,not FINAL'}))
