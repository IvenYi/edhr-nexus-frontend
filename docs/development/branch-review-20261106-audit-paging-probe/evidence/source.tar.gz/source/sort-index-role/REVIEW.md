# 审计分页候选：sort、调用参数与索引DDL只读核对

正式子项结论：**completed / FINAL**。固定基线`f2646c9a098291883434b7e6a7db628fe631ebd6`，知识0.3.25/schema1.2.0；项目/交接契约按该提交实际读取。只读有限源码和DDL，没有修改仓库、没有执行应用测试、PostgreSQL/EXPLAIN、HTTP、浏览器或CI。原始源码副本从固定Git提交读取并与当前文件逐字节核对；不能把此子项当最终质量或运行通过。

## 实际可达入口与参数

| 入口 | 固定源码证据 | 确切参数/读取行为 |
| --- | --- | --- |
| 系统审计日志 | `frontend/src/pages/system/AuditLogPage.tsx:750–762`，页大小82–83，表头982–1000 | 发page/size；有值时发operatorName/operatorAccount/action/moduleName/menuName。不发sort/order，故用后端createdAt/desc。表头本区仅标签/拖宽，未见排序交互；`sortAuditEntries`是审计详情对象字段的本地排列，不是请求排序。全局默认20，可选20/50/100/200。 |
| 个人设置→数据审计 | `frontend/src/pages/account/PersonalSettingsPage.tsx:863–872`，95、805–806及1405–1407 | 显式createdAt/desc，page/size由组件续页，默认1/20，大小20/50/100/200。后端`AuditController:75–95`固定USER_ACCOUNT及当前账户ID，是该用户被修改的记录，不是operator=self。 |
| 工单详情审计 | `frontend/src/pages/production/WorkOrderPage.tsx:418–426` | WORK_ORDER+对象ID，page1/size100，未发sort/order/派生筛选；只消费content。 |
| 批次详情审计 | `frontend/src/pages/production/BatchManagementPage.tsx:270–280` | PRODUCTION_OBJECT+对象ID，page1/size100，未发sort/order/派生筛选；只消费content。 |

上述路径均以`gmp-platform/`为公共根目录缩写。`frontend/src/api/audit.ts:28–35`接受`Record<string, unknown>`，原样传请求参数，没有枚举sort字段或额外排序转换。不能因目前四个页面主要只用createdAt，就声称API从来只支持createdAt或静默缩窄接口。

对实际调用方的有限邻接检索还发现：`FormFillingPage:140–147`、`FormReviewPage:97–104`、`FormInstanceListPage:173–180`从page1开始按firstPage.totalPages逐页请求PRODUCTION_EXECUTION历史，每页200。它们不传sort/order，依赖准确totalPages才能读取后续页；若数据库分页导致总数不正确、重复/漏项或新上限，影响不限于全局审计页。对象详情中的“请求100”不是后端总数上限，也不能借本子项修改用户暂停的生产弹窗样式。

WorkTemplateList:458–487、FormProcessList:633–642、RolePage:1027–1034、OrganizationPage:973–980、BusinessDictionaryPage:543–550、ProductFamilyModelingPage:442–448、ProcessModelingPage:1226–1236显式createdAt/desc；UserPage:977–982、DocumentManagementPage:412–417、TemplateModelingPage:783–798省略并沿默认。此为有限调用/参数核对，不是这些整页面的审查完成或所有消费者清单完备证明。

## sort接口、并列与稳定次序

`AuditController:33–49`只有一个String sort参数，直接`Sort.by(direction, sort)`；`asc`不分大小写为ASC，其他order沿DESC。没有字段白名单、显式转换为DTO排序，也没有自动id次序。PageRequest目前固定page0/Integer.MAX_VALUE；修改为真分页应保留已映射实体属性的现有sort能力，不能在本批未经论证改为只允许createdAt。

`AuditEvent.java:18–58`的映射属性包括`id, tenantId, entityType, entityId, action, contentBefore, contentAfter, snapshotHash, snapshotHashVersion, operatorId, operatorName, operatorAccount, source, moduleName, menuName, functionName, dataSummary, reason, ipAddress, createdAt`。例如id/createdAt/operatorAccount是实际属性；`operatorDisplayName`、`operationTime`、`actionLabel`、`triggerMethodLabel`是DTO派生名称，不能仅凭前端列名认为现有JpaRepository搜索可按它们排序。具体每个值的JPA验证/SQL排序代价尚未运行；不存在白名单也不等于任意字符串可成功或存在SQL注入。当前单String参数亦不构成多个排序字段的公开请求协议。

默认只有createdAt排序，而created_at并不唯一，`@PrePersist`新自动事件按微秒截断(`AuditEvent:60–65`)，不能假设同一微秒只有一条。原全量排序与LIMIT/OFFSET真分页可能采用不同计划，对并列键的顺序原来就没有唯一承诺。新分页实验必须包含相同createdAt数据；仅在时间全部唯一的数据上ID全等不足以证明任意数据全等。对任意非唯一主排序键，包括可空的名字等字段，均存在同类问题。

候选工程措施是保留请求主排序，必要时追加唯一id为次序（主排序已经id时不用重复）；这会明确原先未定义的并列顺序，应作为方案/测试边界说明，不冒充已存在的业务规范。`created_at,id`的正向/反向组合应实际验证；索引与SQL都不能以“Java后切页所以天然稳定”替代证据。即使每个请求追加稳定id，并发新插入仍会移动后续OFFSET页；单请求REPEATABLE_READ也不冻结跨请求的整个翻页集合。游标/跨页快照是另一范围，本子项不建议自动实施。

## canonical索引事实与边界

`backend/src/main/resources/db/changelog/db.changelog-master.yaml:3–17`纳入当前baseline及0092。`baseline/0001-current-schema.sql:59–79`建audit_event，id为NOT NULL，created_at为NOT NULL默认CURRENT_TIMESTAMP；1482–1483为PK(id)。1824–1832只列以下二级btree：

- `idx_audit_action(action)`
- `idx_audit_created(created_at)`
- `idx_audit_entity(entity_type, entity_id)`
- `idx_audit_operator(operator_id)`
- `idx_audit_snapshot_hash(snapshot_hash)`

0092只加nullable snapshot_hash_version，无索引。上述事实不等于在生产数据库实际检查或EXPLAIN。created_at索引具备服务同一键ASC/DESC扫描的结构条件，真LIMIT有机会提前停止，但是否选择它、COUNT如何执行、是否有足够可见性支持index-only，均需主侧实际查询计划/分布验证。

`AuditEventRepository:18–35`以lower(entity_type)、动作CASE/trim/upper/lower及可选OR参数构造条件。原始(entity_type,entity_id)不等同lower(entity_type)表达式索引；仍可能利用entity_id部分，不能在未跑计划时断言完全失效或必然最优。raw action索引也不直接等同“生产非CREATE皆UPDATE”的CASE类别；低选择度UPDATE与包含文本过滤的COUNT成本不能靠索引存在消失。contains/`%...%`条件不由普通btree自动获得高效检索。

添加id次序并不表示现有created_at索引和独立PK天然构成同一组合顺序；可能需要排序/增量排序，具体仍依实际计划。未来若考虑`(created_at,id)`或`(lower(entity_type),entity_id,created_at,id)`，必须证明完整内容/COUNT查询收益、代表性分布、写放大和既有索引重叠，不能凭本只读DDL扫描新增、删除或替换索引。原snapshot_hash索引不能因本入口不用就删除。

## 对有限候选的判断与限制

moduleName/menuName/dataKeyword三项都没有`StringUtils.hasText`时，当前`matchesAuditText`立即返回true，故不存在必须在分页前计算的这三类派生过滤。该分支可使用原repository所有既有SQL条件，并在DB正确分页后沿原DTO和页内补名；若有任一有效派生关键词，继续原controller过滤再切页，不能先LIMIT再Java过滤。此判断是源码等价条件，不是运行验证，也不覆盖真实COUNT事务一致性；后者归父角色/主侧试验。

即使候选成功，它也只改善符合三项空条件的读取；其他派生筛选仍全量加载，完整COUNT还可能扫描所有匹配项。不得把查20条称全链恒定时间或承诺所有页面/筛选已改DB分页。应复用既有资格/姓名/动作含义，不加新上限、sort白名单、跨请求缓存或通用防御层。后续如需要拆分，Controller只收参数和个人身份，QueryService负责既有谓词/分页/总数，Presenter只处理原纯投影和页内姓名上下文；不要以搬类和统计行数代替性能证明。

本子项无确定性代码缺陷整改结论，不新增发现ID，不重开已关闭姓名N+1。PERF-AUDIT-LIST-MATERIALIZATION-001的事件全载子项仍open，生产方案待讨论。完整权限/姓名搜索政策、多租户、W2-W7/931知识/86UI/A12/高风险/容量/UNKNOWN/A23及暂停项保持；整文件完成0、历史unique未知。
