from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
from zoneinfo import ZoneInfo
repo=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-paging-source-20261106');base='f2646c9a098291883434b7e6a7db628fe631ebd6'
def cmd(args):return subprocess.run(args,cwd=repo,capture_output=True,text=True)
def git(*args):
 p=cmd(['git',*args]);assert p.returncode==0,p.stderr;return p.stdout
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','gmp-platform/backend/pom.xml','gmp-platform/backend/src/main/resources/application.yml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/dto/AuditLogItem.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/dto/PageResult.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/DocumentListReadService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceQueryService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorklistService.java','docs/knowledge/schema.yaml','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/rules/production.yaml','docs/development/branch-review-20261026-w4-lifecycle/findings.md','docs/development/branch-review-20261026-w4-lifecycle/structure-plan.md','docs/development/branch-review-20261106-audit-read/performance-and-structure.md','docs/development/branch-review-20261106-audit-read/source-review.md','docs/development/branch-review-20261106-audit-read/source-followup.md','docs/development/branch-review-20261106-audit-page-names/README.md']
sources=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=repo);p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 sources.append({'path':path,'sourceCommit':base,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'currentIdentical':(repo/path).read_bytes()==b})
dp='docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml';b=(repo/dp).read_bytes();p=out/'context'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
sources.append({'path':dp,'sourceKind':'uncommitted working-tree decision package, not a Git source snapshot','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'source-manifest.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2)+'\n')
dependencies=[];javap='/workspace/.edhr-cloud-tools/jdk-21/bin/javap'
classes=[('spring-data-jpa','org.springframework.data.jpa.support.PageableUtils'),('spring-data-jpa','org.springframework.data.jpa.repository.query.ParameterBinder'),('spring-data-jpa','org.springframework.data.jpa.repository.query.JpaQueryExecution$PagedExecution'),('spring-data-commons','org.springframework.data.support.PageableExecutionUtils'),('spring-data-commons','org.springframework.data.repository.core.support.TransactionalRepositoryProxyPostProcessor$RepositoryAnnotationTransactionAttributeSource')]
for artifact,cls in classes:
 jar=Path('/workspace/.pr6-m2/org/springframework/data')/artifact/'3.3.0'/(artifact+'-3.3.0.jar');a=[javap,'-classpath',str(jar),'-c','-p',cls];p=cmd(a);assert p.returncode==0,p.stderr;f=out/'dependency-bytecode'/(cls+'.txt');f.parent.mkdir(exist_ok=True);f.write_text(p.stdout)
 dependencies.append({'class':cls,'jar':str(jar),'jarSha256':hashlib.sha256(jar.read_bytes()).hexdigest(),'command':a,'exitCode':p.returncode,'output':str(f.relative_to(out))})
(out/'dependency-evidence.json').write_text(json.dumps(dependencies,indent=2)+'\n')
queries=[['rg','-n',r'isolation\s*=|transaction-isolation|default_transaction_isolation|setIsolationLevel|setDefaultIsolation|default-isolation','gmp-platform/backend/src/main/java','gmp-platform/backend/src/main/resources'],['rg','-n','EnableJpaRepositories|JpaRepositoryFactory|JpaTransactionManager|RepositoryFactoryBean','gmp-platform/backend/src/main/java'],['rg','-n','PERF-AUDIT-LIST-MATERIALIZATION-001','docs/development/branch-review-20261026-w4-lifecycle/findings.md','docs/development/branch-review-20261026-w4-lifecycle/structure-plan.md']]
results=[]
for a in queries:
 p=cmd(a);assert p.returncode in [0,1];results.append({'command':a,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
(out/'search-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
child=Path('/tmp/edhr-audit-paging-sort-index-20261106');m=json.loads((child/'manifest.json').read_text())
for x in m:
 b=(child/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
shutil.copytree(child,out/'sort-index-role',dirs_exist_ok=True)
(out/'baseline.json').write_text(json.dumps({'observedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'sourceCommit':base,'targetObserved':git('rev-parse','origin/edhr-dev').strip(),'headObserved':git('rev-parse','HEAD').strip(),'statusObserved':git('status','--porcelain').splitlines(),'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','contractReadCommit':base,'allFixedTrackedSourceCurrentlyIdentical':all(x.get('currentIdentical',True) for x in sources),'sourceChild':'completed / FINAL; no product runtime','sourceChildManifestSha256':hashlib.sha256((child/'manifest.json').read_bytes()).hexdigest()},ensure_ascii=False,indent=2)+'\n')
print('captured',len(paths),'fixed source files, working DP,',len(dependencies),'dependency classes, source child',len(m),'raw files')
