from pathlib import Path
import re,json,collections,hashlib,tarfile
o=Path('/tmp/edhr-audit-paging-qa-20261106');r=Path('/tmp/edhr-audit-paging-qa-worktree-20261106')
def parse(log):
 records=[];last={}
 for line in log.splitlines():
  pid=re.search(r'\[(\d+)\]',line)
  if not pid:continue
  pid=pid[1]
  if ' LOG:' in line:
   last[pid]=None
   m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*((?:audit_read_|paging_snapshot_|paging_fixture_writer_)[^*]+)\*/ (.*)$',line)
   if m:
    row={'marker':m[1],'sql':re.sub(r'\$\d+','?',m[2]),'parameters':None};records.append(row);last[pid]=row
  elif ' DETAIL:' in line and 'parameters:' in line and last.get(pid) is not None:
   vals=re.findall(r"\$(\d+) = '((?:''|[^'])*)'",line);last[pid]['parameters']={int(k):v.replace("''", "'") for k,v in vals}
 return records
def verify(log,observations):
 records=parse(log);actual=collections.defaultdict(collections.Counter)
 for x in records:
  if x['marker'].startswith('audit_read_'):actual[x['marker'][11:]][x['sql']]+=1
 cases=[];byname={}
 for name,data in observations.items():
  if 'sqlShapes' not in data:continue
  expected=collections.Counter({x['sql']:x['count'] for x in data['sqlShapes']});assert actual[name]==expected,name
  assert sum(expected.values())==data['prepareStatements'];assert all(sql.startswith('select ') for sql in expected)
  assert data['entityInserts']==data['entityUpdates']==data['entityDeletes']==0
  cases.append({'name':name,'selects':data['prepareStatements'],'entityLoads':data['entityLoads'],'total':data['total'],'returned':len(data['ids']),'idsSha256':hashlib.sha256(json.dumps(data['ids']).encode()).hexdigest()});byname[name]=data
 assert set(actual)==set(byname) and len(cases)==98;assert sum(x['selects'] for x in cases)==210
 representative={};bindings=[]
 for name in ['rc','rr']:
  reads=[x for x in records if x['marker']=='paging_snapshot_'+name];writes=[x for x in records if x['marker']=='paging_fixture_writer_'+name]
  assert len(reads)==2 and len(writes)==1
  assert reads[0]['sql'].startswith('SELECT id ') and reads[1]['sql'].startswith('SELECT count(*) ')
  assert reads[0]['parameters']=={1:'USER_ACCOUNT',2:'20'};assert reads[1]['parameters']=={1:'USER_ACCOUNT'};assert writes[0]['parameters']=={1:'100001'}
  result=observations['snapshot_'+name]['result'];assert result['count']==(41 if name=='rc' else 40) and result['ids']==list(range(40,20,-1))
  representative[name]={'readSelects':2,'fixtureInserts':1,'actualBindings':[x['parameters'] for x in reads+writes],'count':result['count'],'pageIds':result['ids']}
 for count,width in [(100,0),(1000,0),(5000,0),(1000,1024),(1000,131072)]:
  for path in ['current','prototype']:
   name=f'paging_scale_{path}_{count}_{width}';a=byname[name]
   assert a['prepareStatements']==(2 if path=='current' else 3)
   assert a['entityLoads']==(count+1 if path=='current' else 21)
   assert a['ids']==list(range(count,count-20,-1)) and a['total']==count
   events=[x for x in records if x['marker']=='audit_read_'+name and 'from audit_event' in x['sql'] and not x['sql'].startswith('select count(')]
   assert len(events)==1;values=events[0]['parameters'];assert values is not None
   assert [values[i] for i in range(1,17)]==['']*16;assert values[17]=='0';assert values[18]==('2147483647' if path=='current' else '20')
   bindings.append({'case':name,'offset':values[17],'limit':values[18],'eventEntityLoads':a['entityLoads']-(1),'selects':a['prepareStatements']})
 ties=observations['tied_order'];assert ties['stableFirstIds']==list(range(1000,980,-1));assert ties['stableSecondIds']==list(range(980,960,-1))
 return {'measuredEvents':len(cases),'businessSelectExecutions':210,'exactShapesAndCountsMatch':True,'cases':cases,'scaleActualOffsetLimitBindings':bindings,'representativeSnapshots':representative,'representativeReadSelects':4,'separateFixtureInserts':2,'tiedOrderResult':ties,'limits':['Only tagged execute business SQL; parse/bind, initialization, control and unmarked cases excluded','Snapshots are representative JDBC two-stage experiments, not repository count interception or production transactions','Tied same-key ordering may differ by actual plan; equality is not required','Allocated bytes include statistics/observer/SessionMetrics; not peak/RSS/SLA']}
obs={f.stem:json.loads(f.read_text()) for f in (o/'final/observations').glob('*.json')};own=verify((o/'final/postgres.log').read_text(),obs)
with tarfile.open(r/'docs/development/branch-review-20261106-audit-paging-probe/evidence/main.tar.gz') as t:
 parentObs={Path(m.name).stem:json.loads(t.extractfile(m).read()) for m in t.getmembers() if m.isfile() and m.name.startswith('main/final/observations/') and m.name.endswith('.json')}
 parent=verify(t.extractfile('main/final/postgres.log').read().decode(),parentObs)
 ownBy={x['name']:x for x in own['cases']};parentBy={x['name']:x for x in parent['cases']}
 for name,a in ownBy.items():
  if name.startswith('paging_ties_'):continue
  assert a==parentBy[name],name
(o/'reconciliation.json').write_text(json.dumps({'independent':own,'parentGenerated':parent,'nonTieResultsCountsLoadsIdentical':True},ensure_ascii=False,indent=2)+'\n');print(json.dumps({'independentEvents':98,'independentSelects':210,'representativeReads':4,'fixtureWrites':2,'actualScaleBindingsVerified':len(own['scaleActualOffsetLimitBindings']),'parentOriginalsReconciled':True},indent=2))
