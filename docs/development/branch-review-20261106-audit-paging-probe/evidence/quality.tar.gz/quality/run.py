from pathlib import Path
import subprocess,os,sys,time,json,datetime,hashlib,shutil,xml.etree.ElementTree as ET
root=Path(os.environ.get('EDHR_AUDIT_ROOT','/workspace/edhr-nexus-frontend'));raw=Path(os.environ.get('EDHR_AUDIT_RAW','/tmp/edhr-audit-paging-probe-20261106'));phase=sys.argv[1];assert phase in ['unit_negative','baseline','final','retry']
out=raw/phase;out.mkdir(parents=True,exist_ok=False);name='edhr-audit-paging-probe-qa-'+phase.replace('_','-')+'-20261106';db='edhr_audit_read_test_paging_qa_'+phase;created=False;code=1
selected='AuditDatabasePagingProbePostgresTest,AuditPageNamesPostgresTest'
if phase in ['final','retry']:selected+=',AuditReadObservationPostgresTest,AuditActionFilterPostgresTest,AuditActionWhitespacePostgresTest,AuditPaginationBoundaryTest,AuditControllerTest,AuditEventHashTest,AuditEventTest,AuditAspectTest,DhrAuditReadTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 env=os.environ.copy();env.update(PGUSER='postgres',PGPASSWORD='')
 if phase!='unit_negative':
  run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a ']);created=True
  for _ in range(120):
   if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
   time.sleep(.25)
  else:raise RuntimeError('own PG unavailable')
  port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env['AUDIT_READ_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/{db}'
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.readObservation=true','-Dedhr.audit.readOutput='+str(out/'observations'),'-DargLine=-Xmx1536m','-Dtest='+selected,'test']
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/dto/PageResult.java']
 for test in selected.split(','):
  found=list((root/'gmp-platform/backend/src/test/java').rglob(test+'.java'));assert len(found)==1;paths.append(str(found[0].relative_to(root)))
 fps=[]
 for path in paths:
  b=(root/path).read_bytes();fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 start=datetime.datetime.now(datetime.timezone.utc)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'run.json').write_text(json.dumps({'command':command,'head':run(['git','rev-parse','HEAD'],cwd=root),'status':run(['git','status','--porcelain'],cwd=root),'startedAt':start.isoformat(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fps},indent=2)+'\n')
 totals={k:0 for k in ['tests','failures','errors','skipped']};classes=[];missing=[]
 for test in selected.split(','):
  reports=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not reports:missing.append(test)
  for p in reports:
   shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;values={k:int(a.get(k,0)) for k in totals};classes.append({'class':a['name'],**values})
   for k in totals:totals[k]+=values[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-2000:]);code=0 if result.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n');print('owned PG cleanup',removed)
sys.exit(code)
