# 分页试验只读源码/范围复核

结论 **passed / FINAL**，无本范围需修复发现。本角色只执行固定Git/源码与报告对照，未运行应用测试、PostgreSQL、浏览器或CI，也未修改仓库产品、测试、配置、知识或证据原件。父质量实例的162/89与SQL复验不属于本角色执行。本报告是子项，不替代父实例的最终质量门禁。

固定base f2646c9a098291883434b7e6a7db628fe631ebd6，candidate 6daaafe9b4207b8e44b61368ae2ad521d768022a。已核实际项目/交接/质量契约、当前DP、知识README/open-questions/架构及DEC-0013/0095边界，知识0.3.25/schema1.2.0/P0保持。350知识路径只核内容变动为空，不声明本角色全盘语义核对。精确输入见source-manifest.json及source/固定提交副本。

新增28个参数化/普通试验与报告范围吻合：12种过滤、6种page/sort、5种规模/宽度、1个实际JPA offset拒绝、1个个人目标对象、1个同时间排序观察、2个JDBC代表性隔离场景。与base比仅新增该测试和本批报告/归档，没有生产实现、schema、UI、权限、事务、排序、历史或摘要改动；没有删除或放宽原134个测试的断言。

`prototype`（新增测试136行起）只有无派生文本且long offset不超过Integer.MAX_VALUE时调用真实repository.search；其余直接走原controller。U+2000/NBSP沿StringUtils.hasText，与现有matchesAuditText资格一致，没有换成trim().isEmpty或直接原列过滤。派生回退两侧本来就是同一路径，该对照用于证明回退选择，不应描述成已实现SQL派生投影。

正常路径仍按原Sort.Direction/实体字段sort构造Sort，不新增白名单或把DTO字段当可直接JPA排序的列。超大页回退是安装依赖实际拒绝边界的候选应对，不是新页数cap；PageResult仍回显传入page/size，totalPages由原工厂计算。6个边界包含offset等于int上界与超过上界、超尾空页；未在报告中把这些有限案例说成所有sort属性的运行穷举。

完整DTO比较通过原`loadOperatorNames`和`toAuditLogItem`私有方法反射复用，不复制姓名/动作/模块/菜单/摘要规则；AuditLogItem为Lombok Value，sameResult比较完整content列表、totalElements、page、size和totalPages。个人候选继续调用原findCurrentUser，并固定USER_ACCOUNT/currentUser.id这个目标，测试数据包含管理员更改和当前操作者对他人的更改，未改operator=self。生产CREATE/UPDATE投影及非生产原分类依旧由真实仓储与原投影负责；既有Decisions保持，不从DEC-0095人员选择直接推导审计资格。

同时间测试明确不对旧单字段排序与LIMIT结果断言相等，而是记录其结果与跨页交集，只断言测试显式ID次排序下的确定两页。主侧README中1..20与1000..981是其固定实验观测，不是规范或所有PG计划保证；候选排序仍未进入生产。单请求稳定次序亦不意味着并发增量下跨页OFFSET冻结。

隔离试验（116行起）明确使用JdbcTemplate内容和COUNT两阶段，在另一线程/连接插入一个合成事件，READ_COMMITTED/RR分别设置TransactionTemplate；不是对真实repository内部COUNT的拦截，不是生产事务验收或DHR START冻结政策。另连接fixture INSERT与只读观测应由父QA独立在日志中分列，不能把“测量读区零Hibernate写”扩大成整个测试数据库无写入。报告当前已明确这些限制。

A23/方案边界合理：派生回退保护现有Java展示筛选，offset回退对应真实依赖限制，未为假想情况增加产品防御、吞错或结果上限。只读源码可确认/me在同controller内部调用list，所以未来仅在list或private辅助函数加RR事务注解不能覆盖self-invocation；public查询Service代理提案有具体依据，但现在没有实现。Presenter纯投影/Service查询职责是明确的小步拆分建议，不等同已重构或整文件审完。新稳定排序及COUNT索引必要性仍需实际计划，报告没有冒称已做新的完整EXPLAIN。

剩余风险保持：当前生产仍全量加载事件和宽JSON；权限/当前与历史姓名搜索政策、完整租户、真实HTTP/UI/生产并发峰值、W2-W7/931知识/86UI候选/A12/高风险/矩阵/历史ZIP/text-ID/上传PDFOffice/UNKNOWN/A23含已审及用户暂停项未关闭。性能工程方案仍待用户决定，不把PR68 merge或本试验通过视为产品优化授权。
