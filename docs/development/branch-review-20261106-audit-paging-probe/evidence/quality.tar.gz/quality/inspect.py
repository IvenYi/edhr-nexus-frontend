from pathlib import Path
import subprocess,json,hashlib,tarfile,xml.etree.ElementTree as ET
r=Path('/tmp/edhr-audit-paging-qa-worktree-20261106');o=Path('/tmp/edhr-audit-paging-qa-20261106');base='f2646c9a098291883434b7e6a7db628fe631ebd6';head='6daaafe9b4207b8e44b61368ae2ad521d768022a';d=r/'docs/development/branch-review-20261106-audit-paging-probe';e=d/'evidence'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==head
result={'base':base,'head':head,'target':git('rev-parse','origin/edhr-dev'),'packages':[],'checksums':[]}
for line in (e/'SHA256SUMS').read_text().splitlines():
 sha,name=line.split('  ',1);assert hashlib.sha256((e/name).read_bytes()).hexdigest()==sha;result['checksums'].append({'path':name,'sha256':sha})
main_members={}
for name in ['main','source']:
 manifest=json.loads((e/(name+'-manifest.json')).read_text());expected={x['path']:x for x in manifest}
 with tarfile.open(e/(name+'.tar.gz')) as t:
  actual={}
  for member in t.getmembers():
   if not member.isfile():continue
   assert member.name.startswith(name+'/');rel=member.name[len(name)+1:];assert not rel.startswith('/') and '..' not in Path(rel).parts
   b=t.extractfile(member).read();x=expected[rel];assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'];actual[rel]=b
  assert set(actual)==set(expected)
  if name=='main':main_members=actual
 result['packages'].append({'name':name,'fileCount':len(expected),'allPathsLengthsAndHashesMatch':True})
 (o/'parent-evidence'/name).mkdir(parents=True,exist_ok=True)
 for rel,b in actual.items():
  if rel in ['run.py','analysis.json','final/run.json','final/test-summary.json','final/cleanup.json','knowledge/summary.json','source-manifest.json','result.json','REVIEW.md'] or rel.startswith('final/TEST-'):
   p=o/'parent-evidence'/name/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
run=json.loads(main_members['final/run.json']);same=[]
for x in run['sourceFingerprints']:
 assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'];same.append(x['path'])
result['allParentRunInputsIdenticalToCandidate']=same
summary=json.loads(main_members['final/test-summary.json']);assert summary['totals']==dict(tests=162,failures=0,errors=0,skipped=0);result['parentTestTotals']=summary['totals']
assert json.loads(main_members['final/cleanup.json'])['removed']
knowledge=[]
for p in git('ls-tree','-r','--name-only',head,'--','docs/knowledge').splitlines():
 b=(r/p).read_bytes();old=subprocess.check_output(['git','show',base+':'+p],cwd=r);assert b==old
 knowledge.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
assert len(knowledge)==350;(o/'knowledge-file-manifest.json').write_text(json.dumps(knowledge,indent=2)+'\n');result['knowledge']={'files':len(knowledge),'allIdenticalToBase':True}
protected=['gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','docs/architecture','AGENTS.md','codeplzreadme.md','docs/agents'];assert not git('diff','--name-only',base,head,'--',*protected)
result['protectedScopeUnchanged']=protected
(o/'inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'packages':result['packages'],'sourceInputs':len(same),'knowledgeFiles':len(knowledge)},indent=2))
