from pathlib import Path
import json,re,collections,hashlib,shutil
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-audit-paging-probe-20261106');p=raw/'final'
summary=json.loads((p/'test-summary.json').read_text());assert summary['totals']==dict(tests=162,failures=0,errors=0,skipped=0)
sql=collections.defaultdict(collections.Counter);snap=collections.defaultdict(list);writers=[]
for line in (p/'postgres.log').open():
 m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*audit_read_([^*]+)\*/ (.*)$',line)
 if m:sql[m[1]][re.sub(r'\$\d+','?',m[2])]+=1
 s=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*paging_snapshot_(rc|rr)\*/ (.*)$',line)
 if s:snap[s[1]].append(re.sub(r'\$\d+','?',s[2]))
 w=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*paging_fixture_writer_(rc|rr)\*/ (.*)$',line)
 if w:writers.append({'case':w[1],'sql':re.sub(r'\$\d+','?',w[2])})
cases=[]
for f in sorted((p/'observations').glob('*.json')):
 a=json.loads(f.read_text())
 if 'sqlShapes' not in a:continue
 expected=collections.Counter({x['sql']:x['count'] for x in a['sqlShapes']});assert expected==sql[a['name']],a['name']
 assert sum(expected.values())==a['prepareStatements'];assert all(x.startswith('select ') for x in expected)
 assert a['entityInserts']==a['entityUpdates']==a['entityDeletes']==0
 cases.append({k:a[k] for k in ['name','prepareStatements','entityLoads','total','ids','threadAllocatedBytes','elapsedNanos']})
assert len(cases)==98 and set(sql)=={a['name'] for a in cases}
assert set(snap)=={'rc','rr'} and all(len(v)==2 for v in snap.values()) and len(writers)==2
for isolation in ['rc','rr']:
 a=json.loads((p/'observations'/f'snapshot_{isolation}.json').read_text());assert a['fixtureWriterInserted']==1
 assert a['result']['count']==(41 if isolation=='rc' else 40)
unchanged=[]
for x in json.loads((p/'run.json').read_text())['sourceFingerprints']:
 assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path'];unchanged.append(x['path'])
assert json.loads((p/'cleanup.json').read_text())['removed']
out={'sourceAndTarget':'f2646c9a098291883434b7e6a7db628fe631ebd6','tests':summary,'sql':{'completedMeasuredEvents':len(cases),'taggedBusinessSelects':sum(a['prepareStatements'] for a in cases),'exactShapesAndCountsMatch':True,'cases':cases},
 'representativeSnapshots':{'readSelects':dict(snap),'fixtureWriters':writers,'scope':'JDBC representative content/count with separate-connection fixture insert, not actual repository-count interception; not product mutation'},
 'allRunInputsStillIdentical':unchanged,'ownedContainerRemoved':True,'limitations':['test-only proposal; production code unchanged','ROW/DTO equivalence only tested supplied fixed-data cases, tied-order difference explicitly recorded','resource allocation includes Hibernate statistics/observer/SessionMetrics logging, not peak/RSS/SLA','production transaction and actual repository concurrent count not changed or claimed validated','98 tagged measurements exclude initialization/control/unmarked cases; representative reads/writes separate']}
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');shutil.copy2(raw/'analysis.json',r/'docs/development/branch-review-20261106-audit-paging-probe/main-analysis.json')
print(json.dumps({'tests':summary['totals'],'events':len(cases),'selects':out['sql']['taggedBusinessSelects'],'representativeSelects':sum(map(len,snap.values())),'fixtureInserts':len(writers),'unchangedRunInputs':len(unchanged)},indent=2))
