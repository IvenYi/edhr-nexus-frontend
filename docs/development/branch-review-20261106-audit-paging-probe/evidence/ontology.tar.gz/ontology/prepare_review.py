from pathlib import Path
import yaml,json

r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-paging-ontology-20261106')
def locator(path,needle):
 lines=(r/path).read_text().splitlines()
 return f'line {next(i for i,s in enumerate(lines,1) if needle in s)}: {needle}'
rows=[]
def add(id,kind,path,maturity,classification,conclusion,note,evidence):
 rows.append({'id':id,'recordType':kind,'sourcePath':path,'sourceLocator':locator(path,id),'originalMaturity':maturity,'scopeClass':classification,'semanticReviewStatus':'reviewed','conclusion':conclusion,'reviewedScope':note,'originalEvidenceReferences':evidence,'evidenceTypes':['original-evidence','user-confirmed' if id.startswith('DEC-0013') else 'original-evidence']})
prod='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java'
repo='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java'
d13='docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml'
d95='docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml'
ontology='docs/knowledge/ontology.yaml'
add('DEC-0013-03','decision-statement',d13,'implemented','current-direct','consistent','生产客户动作仍只CREATE/UPDATE；本批测试复用原repository与当前投影，未替代动作类别或重写原action。',[d13,prod,repo])
add('rule.production.audit-action-projection','rule','docs/knowledge/rules/production.yaml','implemented','current-direct','consistent','当前生产动作投影和筛选规则原文保留，试验仅比较已有读路径，不由SQL性能实验新增业务动作。',[d13,prod,repo])
add('relation.audit-event-projects-action-category','relationship',ontology,'implemented','current-direct','consistent','原事件与客户类别保持分层；原始记录、hash和投影来源未改变。',[ontology,prod,repo])
add('concept.audit-event','concept',ontology,'implemented','current-direct','consistent','审计事件仍为原持久事实；COUNT/分页原型及隔离实验不是事件写入政策或历史数据回填。',[ontology,prod,'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java'])
add('concept.data-audit-action-category','concept',ontology,'implemented','current-direct','consistent','类别定义不因分页方式变化；不把原action的生命周期类别扩成客户额外分类。',[ontology,d13,prod])
add('DEC-0013-04','decision-statement',d13,'implemented','current-adjacent','consistent','生产行级追溯及实际冻结配置解释不受影响；MVCC读视图/排序候选只是列表工程，不替代执行冻结或版本引用。',[d13,prod,'docs/architecture/business-knowledge-model.md'])
add('DEC-0095-01','decision-statement',d95,'specified','current-adjacent','consistent','直接政策仍限人员选择完整集合；本批只保留单批不等于总量的边界，不把该规则虚构为审计记录新增资格。',[d95,'docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml'])
add('DEC-0095-03','decision-statement',d95,'specified','current-adjacent','consistent','页号/批量/工程实现与已确认业务及运行证据分开；不由试验推断新索引、生产容量或完整多租户。',[d95,'docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml'])
add('scenario.production-audit-action-projection','acceptance-scenario',d13,'inherited implemented decision; scenario has no status field','current-adjacent','evidence-gap','本轮没有执行真实审计UI/HTTP；原生方法/仓储与完整DTO对照不能自动关闭规范内完整UI验证。',[d13,prod])
add('question.multi-tenant-workflow-isolation','open-question','docs/knowledge/open-questions.yaml','unresolved, internal','current-adjacent','evidence-gap','完整租户隔离仍原未决；本批不新加租户筛选或授权政策，不把默认MVP查询试验称全域隔离通过。',['docs/knowledge/open-questions.yaml',prod,'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java'])
(out/'finite-audit-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
(out/'finite-audit-summary.json').write_text(json.dumps({'finiteRecords':len(rows),'semanticReviewed':len(rows),'conclusions':{'consistent':8,'evidence-gap':2},'knowledgeFilesInventoried':350,'wholeFileCompletions':0,'historicalUniqueCoverage':'unknown','notClaimed':['350 files semantically consistent','whole audit complete','UI/HTTP/concurrency or production acceptance executed by ontology role']},ensure_ascii=False,indent=2)+'\n')
print('finite records',len(rows))
