from pathlib import Path
import subprocess,hashlib,json,datetime

r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-paging-ontology-20261106')
base='f2646c9a098291883434b7e6a7db628fe631ebd6'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
assert git('rev-parse','HEAD')==base
knowledge=git('ls-files','docs/knowledge').splitlines();assert len(knowledge)==350
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md',*knowledge,
'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/dto/AuditLogItem.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/common/dto/PageResult.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditReadObservationPostgresTest.java',
'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditPageNamesPostgresTest.java']
manifest=[];knowledge_manifest=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=r);assert (r/path).read_bytes()==b,path
 p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 rec={'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()};manifest.append(rec)
 if path in knowledge:knowledge_manifest.append(rec)
dp='docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml';b=(r/dp).read_bytes();p=out/'initial-working-tree'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
record={'capturedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':base,'targetCommitObserved':git('rev-parse','origin/edhr-dev'),'contractReadCommit':base,'initialWorkingTreeStatus':git('status','--porcelain'),'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeFileCount':len(knowledge),'knowledgeAllIdenticalToBase':True,'contractsUncommitted':[],'initialDecisionPackage':{'path':dp,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}}
(out/'baseline.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(out/'knowledge-fingerprint-inventory-initial.json').write_text(json.dumps(knowledge_manifest,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False,indent=2))
