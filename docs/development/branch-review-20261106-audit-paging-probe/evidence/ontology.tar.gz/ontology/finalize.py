from pathlib import Path
import subprocess,json,hashlib,shutil,sys,xml.etree.ElementTree as ET,datetime,yaml

r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-audit-paging-ontology-20261106')
raw=Path(sys.argv[1]);candidate=sys.argv[2];phase=sys.argv[3] if len(sys.argv)>3 else 'final'
base='f2646c9a098291883434b7e6a7db628fe631ebd6'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
working=candidate=='WORKTREE'
if working:candidate=git('rev-parse','HEAD')
assert len(candidate)==40 and git('rev-parse',candidate)==candidate
fetched=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=r,capture_output=True,text=True,check=True)
(out/'final-fetch.log').write_text(fetched.stdout+fetched.stderr)
assert git('rev-parse','origin/edhr-dev')==base,'Target advanced; report to main for incremental scope before finalizing'
initial=json.loads((out/'source-manifest.json').read_text());source=[]
for rec in initial:
 p=rec['path'];b=(r/p).read_bytes();assert hashlib.sha256(b).hexdigest()==rec['sha256'],p
 assert subprocess.check_output(['git','show',candidate+':'+p],cwd=r)==b,p
 f=out/'final-source'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);source.append(rec)
dp='docs/development/branch-review-20261106-audit-paging-probe/decision-package.yaml'
test='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditDatabasePagingProbePostgresTest.java'
for p in [dp,test]:
 b=(r/p).read_bytes()
 if not working:assert subprocess.check_output(['git','show',candidate+':'+p],cwd=r)==b,p
 f=out/'final-source'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);source.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'final-source-manifest.json').write_text(json.dumps(source,indent=2)+'\n')
knowledge=[x for x in initial if x['path'].startswith('docs/knowledge/')];assert len(knowledge)==350
(out/'knowledge-fingerprint-inventory-final.json').write_text(json.dumps(knowledge,indent=2)+'\n')
e=out/'parent-generated-evidence';e.mkdir(exist_ok=True)
copied=[]
for p in sorted((raw/phase).rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(raw)
 if p.name in ['run.json','test-summary.json','cleanup.json'] or p.name.startswith('TEST-') and p.suffix=='.xml' or 'observations' in rel.parts and p.suffix=='.json':
  q=e/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);copied.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'provenance':'parent-generated evidence; read by ontology role, not independently rerun'})
for name in ['analysis.json']:
 if (raw/name).exists():shutil.copy2(raw/name,e/name);copied.append({'path':name,'bytes':(raw/name).stat().st_size,'sha256':hashlib.sha256((raw/name).read_bytes()).hexdigest(),'provenance':'parent-generated analysis, not independent SQL reconciliation by ontology role'})
run=json.loads((raw/phase/'run.json').read_text());matches=[];deltas=[]
for rec in run['sourceFingerprints']:
 actual=(r/rec['path']).read_bytes();now=hashlib.sha256(actual).hexdigest()
 item={'path':rec['path'],'runSha256':rec['sha256'],'currentSha256':now}
 (matches if now==rec['sha256'] else deltas).append(item)
provenance={'readAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parentEvidenceRoot':str(raw),'parentPhase':phase,'candidate':candidate,'parentRunReportedHead':run['head'],'filesRead':copied,'sameRunInputFingerprints':matches,'postRunInputDeltas':deltas,'runtimeExecutedByOntologyRole':False,'sqlReconciledByOntologyRole':False,'knowledgeTestsExecutedByOntologyRole':True}
(e/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
proof={'sourceHead':candidate,'includedWorkingTreePaths':[dp,test] if working else [],'workingTreeStateAtFinalRead':git('status','--porcelain'),'targetObserved':git('rev-parse','origin/edhr-dev'),'sourceAndKnowledgeSameAsInitial':True,'knowledgeFileCount':350,'finalSourceCopiesMatch':('fixed-head source plus explicit working-tree test/DP snapshots' if working else 'clean candidate source'),'sameParentRunInputCount':len(matches),'postRunDeltaPaths':[x['path'] for x in deltas],'readContractCommit':base,'contractPathsChangedFromInitial':git('diff','--name-only',base,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents'),'productionPathsChangedFromInitial':git('diff','--name-only',base,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend')}
assert proof['contractPathsChangedFromInitial']==''
assert proof['productionPathsChangedFromInitial']==''
(out/'final-review-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(proof,ensure_ascii=False,indent=2))
