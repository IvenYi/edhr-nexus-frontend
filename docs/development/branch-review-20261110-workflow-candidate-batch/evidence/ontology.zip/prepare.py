from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile
import yaml

root = Path('/workspace/edhr-nexus-frontend')
out = Path('/tmp/edhr-workflow-candidate-batch-ontology-20261110')
out.mkdir(exist_ok=False)
base = '3b7e4d9a35503020e0baef2a91bb3e9a663fcb05'
def sha(b): return hashlib.sha256(b).hexdigest()
def command(args): return subprocess.run(args, cwd=root, text=True, capture_output=True, check=True).stdout.strip()
def write(name, data):
    p=out/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=root,text=True,capture_output=True,check=True)
(out/'independent-fetch.log').write_text(fetch.stdout+fetch.stderr)
assert command(['git','rev-parse','origin/edhr-dev']) == base
prior_zip=root/'docs/development/branch-review-20261110-workflow-candidate-capacity/evidence/ontology.zip'
with zipfile.ZipFile(prior_zip) as z:
    old_records=json.loads(z.read('finite-review-records.json'))
    old_reuse=json.loads(z.read('knowledge-validation-reuse.json'))
    prior_binding=json.loads(z.read('source-binding.json'))
    for name in ['finite-review-records.json','knowledge-validation-reuse.json','entry-read-receipt.json']:
        p=out/'prior-original'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
    for name in z.namelist():
        if name.startswith('reused-knowledge-6f/'):
            p=out/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(name))
    prior_inventory=json.loads(z.read('knowledge-inventory.json'))
paths=[x['path'] for x in prior_binding['sourceInputs']]
paths.remove('docs/development/branch-review-20261110-workflow-candidate-capacity/decision-package.yaml')
paths.extend(['docs/development/branch-review-20261110-workflow-candidate-batch/decision-package.yaml',
              'docs/development/branch-review-20261110-workflow-candidate-capacity/next-batch-authorization.json',
              'docs/development/branch-review-20261110-workflow-candidate-capacity/performance-next.md',
              'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/RecordControlWorkflowServiceTest.java'])
entries=[]
for path in paths:
    data=(root/path).read_bytes();dest=out/'entry-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    item={'path':path,'bytes':len(data),'sha256':sha(data)}
    if path.startswith('docs/development/branch-review-20261110-workflow-candidate-batch/'):
        item['gitCommit']=None;item['state']='actual uncommitted decision package; no fabricated SHA'
    else:
        git_data=subprocess.check_output(['git','show',base+':'+path],cwd=root)
        item['matchesBaseGit']=data==git_data
        item['gitCommit']=base if data==git_data else None
    entries.append(item)
write('entry-read-receipt.json',{'loadedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':command(['git','rev-parse','HEAD']),
    'target':base,'actualWorkingTreeStatus':command(['git','status','--porcelain=v1']),
    'files':entries,'scope':'Full entry bytes loaded/saved; only finite named clauses and source symbols semantically reviewed,not whole-file completion'})
def find_id(value,identifier):
    if isinstance(value,dict):
        if value.get('id')==identifier:return value
        for v in value.values():
            hit=find_id(v,identifier)
            if hit is not None:return hit
    elif isinstance(value,list):
        for v in value:
            hit=find_id(v,identifier)
            if hit is not None:return hit
    return None
records=[]
for old in old_records['records']:
    parsed=yaml.safe_load((root/old['sourcePath']).read_text())
    row=find_id(parsed,old['id']);assert row==old['originalRecord'],old['id']
    records.append({**old,'originalRecord':row,'originalEvidenceReferences':[old['sourcePath']+'#'+old['sourceLocator']],
                    'currentReviewState':'provisional; implementation to be reread at actual final candidate; no runtime executed'})
write('finite-review-records.provisional.json',{'summary':old_records['summary'],'records':records})
knowledge=[]
for p in sorted((root/'docs/knowledge').rglob('*')):
    if p.is_file():
        rel=p.relative_to(root).as_posix();data=p.read_bytes();git_data=subprocess.check_output(['git','show',base+':'+rel],cwd=root)
        assert data==git_data,rel
        knowledge.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
assert len(knowledge)==353
validator=[]
for row in old_reuse['validatorInputs']:
    data=(root/row['path']).read_bytes();assert sha(data)==row['sha256'];validator.append(row)
trees=[]
for path in ['docs/knowledge','tools/knowledge-model','gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge']:
    current=command(['git','rev-parse',base+':'+path]);prior=command(['git','rev-parse',old_reuse['originalRun']['head']+':'+path]);assert current==prior
    trees.append({'path':path,'base':current,'originalRun':prior})
old_inv=prior_inventory.get('files',prior_inventory.get('knowledgeFiles'))
write('knowledge-inventory.json',{'baseCommit':base,'files':knowledge,'knowledgeFileCount':len(knowledge),'validatorInputs':validator,
    'schemaVersion':'1.2.0','knowledgeModelVersion':'0.3.25','stage':'P0 in-progress','scope':'Byte inventory,not semantic coverage'})
write('knowledge-validation-reuse.json',{'actuallyExecutedByThisRole':False,'originalRun':old_reuse['originalRun'],
    'knowledgeFiles':353,'inputCount':359,'validatorInputs':validator,'treeIdentity':trees,
    'scope':'Only reuse actual original89 after same-input proof; no fresh knowledge or runtime tests by this role'})
(out/'prepare.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'out':str(out),'head':command(['git','rev-parse','HEAD']),'knowledgeFiles':353,'validatorInputs':6,'finiteRecords':len(records),'state':'PRELIMINARY-await-final-candidate'},ensure_ascii=False))
