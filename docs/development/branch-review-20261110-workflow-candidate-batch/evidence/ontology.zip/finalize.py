from pathlib import Path
import collections, datetime, hashlib, json, subprocess
import yaml

root=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-workflow-candidate-batch-ontology-20261110')
base='3b7e4d9a35503020e0baef2a91bb3e9a663fcb05'
candidate='c2691bf711ceb8f7033dae23e28dfaa8104344a5'
def sha(b):return hashlib.sha256(b).hexdigest()
def cmd(args):return subprocess.run(args,cwd=root,text=True,capture_output=True,check=True).stdout.strip()
def git_bytes(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
def write(path,data):
    p=out/path;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert cmd(['git','rev-parse','HEAD'])==candidate
fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=root,text=True,capture_output=True,check=True)
(out/'final-independent-fetch.log').write_text(fetch.stdout+fetch.stderr)
target=cmd(['git','rev-parse','origin/edhr-dev']);assert target==base
entry=json.loads((out/'entry-read-receipt.json').read_text())
source=[]
for item in entry['files']:
    path=item['path'];data=(root/path).read_bytes();assert data==git_bytes(candidate,path),path
    dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    source.append({'path':path,'bytes':len(data),'sha256':sha(data),'gitCommit':candidate})
contract_paths=['AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md']
assert cmd(['git','diff','--name-only',base,candidate,'--',*contract_paths])==''
changed=cmd(['git','diff','--name-only',base,candidate]).splitlines()
assert len(changed)==5
assert not cmd(['git','diff','--name-only',base,candidate,'--','docs/knowledge','docs/architecture','gmp-platform/frontend','gmp-platform/backend/src/main/resources'])
service_path='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java'
repository_path='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionRepository.java'
service=(root/service_path).read_text();old=git_bytes(base,service_path).decode();repo=(root/repository_path).read_text()
start_header='    @Override\n    @Transactional\n    public StartResult start('
assert service[service.index(start_header):service.index('    private void validateStartCommand')]==old[old.index(start_header):old.index('    private java.util.Optional<PublishedCandidate>')]
assert service[service.index('    private void validateStartCommand'):]==old[old.index('    private void validateStartCommand'):]
assert service.index('if (!seen.add(version.getDefinitionId()))') < service.index('if (PUBLISHED.equals(version.getVersionStatus()))')
assert 'throw new IncorrectResultSizeDataAccessException(1)' in service
query=repo[repo.index('    @Query("""'):repo.index('    List<CandidateVersion>')]
assert 'version.isCurrent = true' in query
assert 'definition.type = :type and definition.businessType = :businessType' in query
assert 'and definition.status = :status' in query
assert 'order by definition.name asc' in query
assert 'version.status =' not in query
assert all(x not in query for x in ['nodesJson','edgesJson','description','createdAt','updatedAt','limit '])
unchanged=[
'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/contract/RecordControlWorkflowContracts.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionVersionRepository.java',
'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']
for path in unchanged:assert git_bytes(base,path)==git_bytes(candidate,path),path
inventory=json.loads((out/'knowledge-inventory.json').read_text())
for row in inventory['files']+inventory['validatorInputs']:
    data=(root/row['path']).read_bytes();assert sha(data)==row['sha256'],row['path']
    assert data==git_bytes(candidate,row['path']),row['path']
reuse=json.loads((out/'knowledge-validation-reuse.json').read_text())
for tree in reuse['treeIdentity']:
    tree['candidate']=cmd(['git','rev-parse',candidate+':'+tree['path']]);assert tree['candidate']==tree['base']==tree['originalRun']
reuse['candidateCommit']=candidate
write('knowledge-validation-reuse.json',reuse)
inventory['candidateCommit']=candidate;write('knowledge-inventory.json',inventory)
records=json.loads((out/'finite-review-records.provisional.json').read_text())
conclusions={
'DEC-0094-01':'Controller仍isAuthenticated；CHANGE/OBSOLETE不要求create权限，读取不授予申请或审批。角色未执行HTTP或方法安全。',
'DEC-0094-02':'联合查询匹配RECORD_CONTROL/业务类型/定义PUBLISHED及current=true；service先检查所有current重复再过滤version PUBLISHED。缺current不回退历史，全量返回且DB name排序。',
'DEC-0087-03':'submit来源COMPLETED、有效修订、活动申请、真实签署及同事务复核原字节不变；候选读取不取代最终确认。',
'DEC-0087-04':'仍显式选择明确版本，start与校验原字节不变，不自动挑最新或默认选版；候选目录元数据不代表完整可执行发布/新签署。',
'rule.record-control-source-eligibility-v1':'来源COMPLETED/current revision/无活动申请规则保持，submit和引擎未改。',
'rule.record-control-authenticated-access-v1':'认证读取与原数据范围保持；未按tenant筛选的默认目录不被认作完整多租户。',
'evidence.record-control-workflow-stage1-candidate-service':'窄字段批读改变SQL形状但保留当前类型/状态筛选和显式start语义，原证据描述仍准确，无需改写来源。',
'scenario.record-control-authenticated-candidate-read':'原Controller和公开契约逐字不变；测试仍以普通无create权限JWT+MockMvc两类型完整200及匿名401为目标，运行结果取主侧/独立质量。',
'evidence.record-control-workflow-stage1-candidate-api':'只将旧create权限描述按stage1历史保留；现行认证读取由DEC0094-01精确收敛，不把整份原证据作废，不改历史provenance。',
'question.multi-tenant-workflow-isolation':'原非MVP、非本批阻断的完整多租户needs-decision保留；本次工程授权不关闭它。'}
for row in records['records']:
    row.pop('currentReviewState',None)
    row['recordType']='decision-statement' if row['id'].startswith('DEC-') else 'rule' if row['id'].startswith('rule.') else 'evidence' if row['id'].startswith('evidence.') else 'acceptance-scenario' if row['id'].startswith('scenario.') else 'open-question'
    row['reviewConclusion']=conclusions[row['id']]
    row['sourceCommit']=candidate
records['summary']['scope']='Finite same10 rereview;overlaps prior10/prior8/prior19,not10 new unique assets or whole semantic completion'
records['summary']['conclusions']=dict(collections.Counter(r['conclusion'] for r in records['records']))
write('finite-review-records.json',records)
dp=yaml.safe_load((root/'docs/development/branch-review-20261110-workflow-candidate-batch/decision-package.yaml').read_text())['decisionPackage']
required=['id','scope','knowledgeBaselineVersion','contractBaseline','summary','confirmed','inferred','unresolved','replacementScopes','impactAnalysis','extensionStrategy','affectedFiles','acceptanceScenarios']
assert all(k in dp for k in required)
assert dp['knowledgeBaselineVersion']=='0.3.25' and dp['unresolved']==dp['replacementScopes']==[]
for name in ['concepts','relationships','rules','executionContracts']:assert dp['confirmed'][name]==[]
(out/'candidate.diff').write_text(cmd(['git','diff','--no-ext-diff',base,candidate])+'\n')
boundaries={'businessPolicyChanged':False,'authorization':'Actual PR78 next-batch answer: 下一批批量读取并精简字段（推荐）',
    'candidateSource':candidate,'requiredCandidateFields':7,'fullReturnWithoutCap':True,
    'publishedCurrentUniqueness':'Existing list failure only,not new whole-domain cardinality policy;check all current rows before status filter',
    'missingCurrent':'Inner join omission matches old Optional.empty exclusion,no historical fallback',
    'mixedStates':'Native test source has6 PUBLISHED/PUBLISHED or PUBLISHED/DRAFT two-business permutations;doubleDRAFT2 assert original schema rejection,not illegal fixture',
    'wideGraph':'Synthetic JSON test checks narrow SQL;role does not claim wide workload capacity',
    'snapshotMeaning':'One SELECT configuration view;explicit command realtime revalidation and immutable history unchanged',
    'sourceChecks':['DB name order retained','No versionStatus SQL predicate','Seven scalar fields,no graph/description/timestamps','Duplicate guard precedes PUBLISHED condition','start+validation exact base bytes','Controller/DTO/engine/submit/schema exact base bytes'],
    'runtimeExecutedByThisRole':False,'wholeFileCompleted':0,'historicalUnique':'unknown','children':[],
    'notAuthorizedByThisSlice':['record-list qualificationSQL','audit-event DB paging','new index without plan evidence','100 total cap','automatic newest choice','cross-request cache','business-policy change','merge/deploy/restore']}
write('engineering-boundaries.json',boundaries)
binding={'status':'FINAL','sourceCommit':candidate,'targetCommit':target,'contractReadCommit':base,
    'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independentTargetFetch':target,
    'entryHead':entry['head'],'entryDirtyPackageRecorded':True,'finalWorkingTreeStatus':cmd(['git','status','--porcelain=v1']),
    'contractDiff':[],'sourceInputs':source,'candidateChangedPaths':changed,'unchangedVerifiedPaths':unchanged,
    'knowledgeFiles':353,'knowledgeValidationInputs':359,'knowledgeSchema':'1.2.0','knowledgeModel':'0.3.25','stage':'P0 in-progress',
    'runtimeExecutedByThisRole':False,'knowledge89ReexecutedByThisRole':False,'repoModifiedByThisRole':False,
    'wholeFileCompleted':0,'historicalUnique':'unknown','children':[]}
write('source-binding.json',binding)
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
    'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':base,'uncommittedContractPaths':[]},
    'reason':'用户只授权候选current批读及必要字段精简；实际联合投影与service保持全部结果、名称排序、类型/发布/current、原多current失败及普通认证边界，原start/submit/签名/快照/审计/公开契约/UI/schema均未改。没有新的概念/政策/替代或客户解释，不因工程优化新建重复本体资产或改历史provenance。',
    'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
    'validationEvidence':[
      {'id':'validation.source-contract-candidate','checkType':'evidence-path','command':'python3 finalize.py: independent target fetch,candidate source byte/Git binding and unchanged command/contract/UI/schema proof','outcome':'passed','evidence':['source-binding.json','candidate.diff','source']},
      {'id':'validation.finite-semantics','checkType':'projection','command':'Read same10 current original records plus exact historical permission replacement and existing nonMVP question;inspect candidate joint query/duplicate-before-status/start boundaries','outcome':'passed','evidence':['finite-review-records.json','engineering-boundaries.json','REVIEW.md']},
      {'id':'validation.knowledge-input-byte-identity','checkType':'reference','command':'Compare353 knowledge and6 validator/POM inputs against base/candidate and original6f trees','outcome':'passed','evidence':['knowledge-inventory.json','knowledge-validation-reuse.json']},
      {'id':'validation.reused-original-knowledge89','checkType':'schema','command':'REUSED ONLY original6f actual89;not executed by this role','outcome':'passed','evidence':['reused-knowledge-6f/knowledge/run.json','reused-knowledge-6f/knowledge/maven.log','reused-knowledge-6f/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']}],
    'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
provisional=(out/'REVIEW.provisional.md').read_text()
review=provisional.replace('# 候选流程批读与窄字段：有限本体核对（等待候选绑定）','# 候选流程批读与窄字段：有限本体核对')
review=review.replace('本角色已独立 fetch 并确认',f'正式结果 **not-applicable / FINAL**，实际候选 `{candidate}`。本角色已独立 fetch 并确认',1)
review=review.replace('尚不以计划代表已实现或最终运行通过。','入口原件与最终候选分开保存；本角色不以源码审查代表最终运行通过。')
review=review.replace('预期ontologyResult为not-applicable；必须在实际候选完成后再核实现差异、文件字节与Git绑定并正式FINAL。','正式ontologyResult为not-applicable。最终已核实际5文件候选差异、Set重复检查在PUBLISHED前、联合SQL不提前过滤版本状态、无数量上限、原start与validation逐字一致，以及Controller/DTO/engine/submit/schema/UI/知识不变；源码输入逐字绑定Git。')
review += '\n主侧告知旧服务同字节14项=8正6预算失败、0E/S，先前双DRAFT夹具2E已单列保留；该消息只是parent-relayed，不计本角色独立运行。当前主侧final及后续独立质量不由NA代替，运行、SQL计划/计数、性能与merge判断应取各自原件。本角色未读取或背书尚未完成的主侧final运行结果。\n'
(out/'REVIEW.md').write_text(review)
files=[]
excluded={'manifest.json','SHA256SUMS','manifest.sha256'}
for p in sorted(out.rglob('*')):
    if p.is_file() and p.relative_to(out).as_posix() not in excluded:
        data=p.read_bytes();files.append({'path':p.relative_to(out).as_posix(),'bytes':len(data),'sha256':sha(data)})
write('manifest.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':candidate,'files':files})
manifest_data=(out/'manifest.json').read_bytes()
(out/'manifest.sha256').write_text(sha(manifest_data)+'  manifest.json\n')
(out/'SHA256SUMS').write_text(''.join(f"{r['sha256']}  {r['path']}\n" for r in files)+sha(manifest_data)+'  manifest.json\n')
for row in files:assert sha((out/row['path']).read_bytes())==row['sha256']
print(json.dumps({'result':'not-applicable','status':'FINAL','sourceCommit':candidate,'targetCommit':target,'files':len(files),'manifestSha256':sha(manifest_data),'out':str(out)},ensure_ascii=False))
