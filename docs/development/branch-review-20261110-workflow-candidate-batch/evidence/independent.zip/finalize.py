from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, xml.etree.ElementTree as ET
import yaml

raw=Path(__file__).resolve().parent
root=Path('/tmp/edhr-workflow-candidate-batch-qa-worktree-20261110')
main=Path('/tmp/edhr-workflow-candidate-batch-20261110')
base='3b7e4d9a35503020e0baef2a91bb3e9a663fcb05'
head='c2691bf711ceb8f7033dae23e28dfaa8104344a5'
def dump(path,obj): (raw/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def checked(args):return subprocess.check_output(args,cwd=root,text=True).strip()
analysis=json.loads((raw/'independent-sql-analysis.json').read_text())
summary=json.loads((raw/'final_verified/test-summary.json').read_text())
knowledge=json.loads((raw/'knowledge/test-summary.json').read_text())
assert summary['totals']=={'tests':103,'failures':0,'errors':0,'skipped':0}
assert knowledge=={'tests':89,'failures':0,'errors':0,'skipped':0}
krun=json.loads((raw/'knowledge/run.json').read_text())
assert krun['head']==head and krun['exitCode']==0 and len(krun['sourceFingerprints'])==359
for row in krun['sourceFingerprints']:
    assert hashlib.sha256((root/row['path']).read_bytes()).hexdigest()==row['sha256']
assert json.loads((raw/'final_verified/cleanup.json').read_text())['removed']
link=root/'gmp-platform/frontend/node_modules'
assert link.is_symlink() and str(link.resolve())=='/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules'
link.unlink()
assert checked(['git','status','--porcelain=v1'])==''
assert checked(['git','rev-parse','HEAD'])==head
assert checked(['git','rev-parse','origin/edhr-dev'])==base
resource={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownedContainer':json.loads((raw/'final_verified/cleanup.json').read_text()),'ownedDependencyLinkRemoved':True,'runtimeWorkingTreeStatus':'?? gmp-platform/frontend/node_modules','finalWorkingTreeStatus':'clean','worktreeRetainedForReproduction':str(root),'testProcessesCompleted':True,'childAgents':[],'sharedDatabaseOr8081Touched':False,'ciQueriedOrTriggered':False,'mergeDeployRestore':False}
dump('resources-cleanup.json',resource)

test='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
service='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java'
for p in [test,service]:
    src=main/'focused_old_valid/source'/p;dest=raw/'main-negative-evidence/focused_old_valid/source'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name in ['run.json','test-summary.json','cleanup.json']:
    dest=raw/'main-current-evidence'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(main/'final'/name,dest)
oldxml=ET.parse(raw/'main-negative-evidence/focused_old_valid/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml').getroot()
failures=[case.attrib['name'] for case in oldxml.findall('testcase') if case.find('failure') is not None]
assert len(failures)==6 and sum(n.startswith('publishedCandidateCapacity') for n in failures)==5 and 'wideCurrentVersionDoesNotLoadWorkflowGraph' in failures
assert all(case.find('error') is None for case in oldxml.findall('testcase'))
dump('old-budget-failure-cases.json',{'failures':failures,'expectedFailures':True,'fixtureErrorsInCorrectedOldRun':0})

ontology=Path('/tmp/edhr-workflow-candidate-batch-ontology-20261110')
ores=yaml.safe_load((ontology/'ontology-result.yaml').read_text())['ontologyResult']
assert ores['result']=='not-applicable' and ores['contractBaseline']['sourceCommit']==head
shutil.copy2(ontology/'ontology-result.yaml',raw/'reviewed-ontology-result.yaml')

def check(id,category,description,method,command,evidence):
    return {'id':id,'required':True,'category':category,'description':description,'method':method,'command':command,'outcome':'passed','evidence':evidence}
checks=[
check('check.actual-candidate-baseline','requirements','实际基线、契约、授权与5文件最小范围一致','inspection','Independent fetch;git base/head diff and source byte binding',['source-binding.json','final_verified/run.json']),
check('check.knowledge-policy-scope','ontology','DEC0094/0087、有限历史权限替代及非MVP多租户边界合理；工程优化无政策漂移','inspection','Read current decisions/original evidence/open question and actual user authorization',['read-source/docs/knowledge','reviewed-ontology-result.yaml','review.md']),
check('check.native-complete-projection','integration','两类0/1/10/100/1000完整7字段/排序/末项可达，无数量上限或历史版回退','automated-test','Independent full103 native subset and own JSON row oracle',['final_verified/test-summary.json','final_verified/candidate-observations','independent-sql-analysis.json']),
check('check.native-one-narrow-query','database','20实际调用=20SELECT=20原生计划，3参数/7标量，不读取图JSON或逐行查询','query','Independent parse PostgreSQL execute/bind/auto_explain and compare StatementInspector',['independent-analysis.py','independent-sql-analysis.json','actual-plans','final_verified/postgres.log']),
check('check.existing-ambiguity-and-constraint','regression','6个混合current原异常及2个原双草稿唯一约束拒绝保持，宽JSON读取不物化','automated-test','Native PG test mixed-current6/draft-constraint2/wide-projection1',['final_verified/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml','final_verified/source']),
check('check.authenticated-http-no-expansion','security','普通无创建权限JWT完整200与匿名401各10；真实方法安全3项及原写资格回归','automated-test','Independent JWT+MockMvc+nativePG response checks;real method-security proxy tests',['final_verified/http.jsonl','independent-sql-analysis.json','final_verified/TEST-com.zencas.edhr.workflow.controller.RecordControlCandidateAuthorizationTest.xml']),
check('check.readonly-evidence-and-command-retention','audit','五档十表摘要原值相等、标签下0写，start及命令验证/引擎/签名/快照代码保持','inspection','Independent state digest comparison,executed SQL classification and command slice byte comparison',['independent-sql-analysis.json','source-binding.json','final_verified/candidate-observations']),
check('check.same-byte-old-budget-negative','regression','最终同PG测试字节旧服务14=8正6真实预算失败/0E/S，首轮2夹具错误分列保留','inspection','Bind native test and old service to Git;inspect all old XML failures and original schema',['old-negative-binding.json','old-budget-failure-cases.json','main-negative-evidence']),
check('check.independent-current-regression','regression','独立实际103/103，其中83原生PG与20其他；严格guard/canonical0092/两optin，无跳过','automated-test','EDHR_CANDIDATE_ROOT=ownWT EDHR_CANDIDATE_RAW=ownRaw EDHR_CANDIDATE_CONTAINER_PREFIX=ownedQA python3 run.py final_verified',['final_verified/run.json','final_verified/test-summary.json','final_verified/maven.log']),
check('check.actual-knowledge89','ontology','本实例实际89知识校验通过，353知识/6校验输入未改，不表示全语义完成','automated-test','mvn-edhr -f gmp-platform/backend/pom.xml -Dtest=BusinessKnowledgeModelTest -DargLine=-Xmx1024m test',['knowledge/run.json','knowledge/test-summary.json','knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']),
check('check.index-and-a23-boundaries','documentation','实际两表各一次扫描/hash join、内存排序无临时块；无过度兜底/缓存/重试/默认值，拆分建议有职责边界','inspection','Inspect implementation and actual plans,scoped robustness/A23 and concrete ownership review',['actual-plans','independent-sql-analysis.json','review.md']),
check('check.resources-and-honest-scope','documentation','自有PG和依赖软链清理，受测输入绑定；无UI新改/无旧结果冒充/原全审余项仍开放','inspection','Inspect raw source fingerprints,cleanup,unchanged trees and stage boundaries',['source-binding.json','resources-cleanup.json','review.md'])]
residual=[
{'id':'risk.synthetic-capacity-boundary','description':'本机热缓存带采集的合成目录最大每类1000；累计线程分配不是峰值/生产SLA/并发吞吐，宽图只验证投影不物化。','impact':'不能据此宣称生产容量闭环或所有大目录成本消除。','mitigation':'保留完整结果；真实容量与前端全量选项渲染按原W6队列另量化。'},
{'id':'risk.existing-audit-backlog','description':'原W2余项/W3-W5跨链/W6健壮性性能与已审A23/W7、全知识语义、A12/高风险/完整矩阵/family剩余4N及选项全载/容量UNKNOWN继续；全量整文件完成数/historyUnique未因本批增加。','impact':'本批只验证候选批读局部优化，不等于全仓审计或生产发布完成。','mitigation':'继续仓库NEXT原队列及增量拉取；未答方案和暂停模块不扩张。'},
{'id':'risk.existing-ui-static-boundary','description':'本批无UI改动，未重跑浏览器/全站strict/lint；既有strict86和lint缺配置不关闭。','impact':'没有本轮端到端页面延迟或全站静态绿灯证据。','mitigation':'保留旧问题台账与各轮验证范围，不冒用旧浏览器通过。'}]
result={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':head,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':residual,'blockingConditions':[]}}
(raw/'quality-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
assert all(c['required'] and c['outcome']=='passed' for c in result['qualityResult']['checks'])

members=[]
for p in sorted(raw.rglob('*')):
    if p.is_file() and p.name not in ['manifest.json','SHA256SUMS']:
        data=p.read_bytes();members.append({'path':str(p.relative_to(raw)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
dump('manifest.json',{'role':'workflow_candidate_batch_final_qa','finalStatus':'FINAL','head':head,'base':base,'files':members})
lines=[m['sha256']+'  '+m['path'] for m in members]
lines.append(hashlib.sha256((raw/'manifest.json').read_bytes()).hexdigest()+'  manifest.json')
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for m in members:assert hashlib.sha256((raw/m['path']).read_bytes()).hexdigest()==m['sha256']
print(json.dumps({'result':'passed','requiredChecks':len(checks),'nativeAndAdjacent':103,'knowledge':89,'files':len(members),'manifestSha256':hashlib.sha256((raw/'manifest.json').read_bytes()).hexdigest(),'resources':resource},ensure_ascii=False))
