from pathlib import Path
from collections import defaultdict, Counter
import datetime, hashlib, json, re, shutil, subprocess, xml.etree.ElementTree as ET

raw=Path(__file__).resolve().parent
root=Path('/tmp/edhr-workflow-candidate-batch-qa-worktree-20261110')
main=Path('/tmp/edhr-workflow-candidate-batch-20261110')
base='3b7e4d9a35503020e0baef2a91bb3e9a663fcb05'
head='c2691bf711ceb8f7033dae23e28dfaa8104344a5'
phase=raw/'final_verified'
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
def dump(path,value): (raw/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def sha(value): return hashlib.sha256(value).hexdigest()
def nodes(plan):
    yield plan
    for child in plan.get('Plans',[]): yield from nodes(child)

assert git('rev-parse','HEAD').decode().strip()==head
assert git('rev-parse','origin/edhr-dev').decode().strip()==base
changes=git('diff','--name-only',base,head).decode().splitlines()
assert len(changes)==5
assert not git('diff',base,head,'--','docs/knowledge','gmp-platform/frontend','gmp-platform/backend/src/main/resources','AGENTS.md','codeplzreadme.md','docs/agents')
service='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java'
def command_part(data):
    # The removed helper was after start in the old source; compare the actual start and remaining command helpers separately.
    first=data.index('    @Override\n    @Transactional\n    public StartResult start(')
    end=data.index('    private ',first)
    validate=data.index('    private void validateStartCommand(')
    return data[first:end],data[validate:]
assert command_part(git('show',base+':'+service).decode())==command_part(git('show',head+':'+service).decode())
run=json.loads((phase/'run.json').read_text())
assert run['head']==head and run['exitCode']==0
bindings=[]
for inp in run['sourceFingerprints']:
    p=inp['path']; data=(root/p).read_bytes()
    assert sha(data)==inp['sha256']==sha(git('show',head+':'+p))==sha((phase/'source'/p).read_bytes())
    bindings.append(inp)
assert len(bindings)==30
protected=set(x['path'] for x in bindings)
knowledge=git('ls-tree','-r','--name-only',head,'docs/knowledge').decode().splitlines()
assert len(knowledge)==353
extra=git('ls-tree','-r','--name-only',head,'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').decode().splitlines()+['gmp-platform/backend/pom.xml']
assert len(extra)==6
snapshots=[]
for p in sorted(set(knowledge+extra+['docs/architecture/business-knowledge-model.md','docs/knowledge/evidence/record-control-authenticated-candidate-read.yaml','docs/knowledge/evidence/record-control-workflow-stage1.yaml'])):
    data=(root/p).read_bytes()
    assert data==git('show',head+':'+p)==git('show',base+':'+p)
    dest=raw/'read-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    snapshots.append({'path':p,'sha256':sha(data),'bytes':len(data)})
dump('source-binding.json',{'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'head':head,'contractReadCommit':head,'changes':changes,'runtimeWorkingTreeStatus':run['workingTreeStatus'],'protectedInputs':bindings,'knowledgeFileCount':len(knowledge),'validatorInputCount':len(extra),'additionalSnapshots':snapshots,'commandPartIdentical':True,'frontendSchemaKnowledgeContractsIdentical':True})

summary=json.loads((phase/'test-summary.json').read_text())
assert summary['totals']=={'tests':103,'failures':0,'errors':0,'skipped':0}
assert not summary['missingFreshReports']
for row in summary['classes']:
    xml=phase/('TEST-'+row['name']+'.xml')
    attrs=ET.parse(xml).getroot().attrib
    assert all(int(attrs[k])==row[k] for k in ('tests','failures','errors','skipped'))

old=json.loads((main/'focused_old_valid/test-summary.json').read_text())
assert old['totals']=={'tests':14,'failures':6,'errors':0,'skipped':0}
old_run=json.loads((main/'focused_old_valid/run.json').read_text())
test='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
assert (main/'focused_old_valid/source'/test).read_bytes()==git('show',head+':'+test)
assert (main/'focused_old_valid/source'/service).read_bytes()==git('show',base+':'+service)
initial=json.loads((main/'focused_old/test-summary.json').read_text())
assert initial['totals']=={'tests':14,'failures':6,'errors':2,'skipped':0}
old_preserved=[]
for label in ['focused_old','focused_old_valid']:
    for name in ['run.json','test-summary.json','cleanup.json','TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml']:
        data=(main/label/name).read_bytes(); dest=raw/'main-negative-evidence'/label/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        old_preserved.append({'path':str(dest.relative_to(raw)),'sha256':sha(data)})
dump('old-negative-binding.json',{'oldServiceAtBase':True,'nativeTestsSameFinalBytes':True,'initialFixtureFailure':initial['totals'],'correctedOldBudgetRun':old['totals'],'copiedOriginals':old_preserved})

text=(phase/'postgres.log').read_text()
pattern=re.compile(r'\b(wf-candidates-(\d+)-(change|obsolete)-(\d+))\b')
executed=defaultdict(list);plans=defaultdict(list);parameters=defaultdict(list)
offset=0;decoder=json.JSONDecoder()
for line in text.splitlines(keepends=True):
    offset+=len(line)
    m=pattern.search(line)
    if not m: continue
    label=m[1]
    hit=re.search(r'LOG:\s+duration:\s+([\d.]+) ms\s+(?:execute [^:]+|statement):\s*(.*)',line)
    if hit and re.match(r'\s*(select|insert|update|delete)\b',hit[2],re.I): executed[label].append(hit[2].strip())
    if 'DETAIL:  parameters:' in line: parameters[label].append(line.split('parameters:',1)[1].strip())
    if 'plan:' in line:
        at=offset
        while text[at].isspace(): at+=1
        plan,_=decoder.raw_decode(text,at);plans[label].append(plan)

reports=list((phase/'candidate-observations').glob('catalog-*.json'))
assert len(reports)==5
observations=[]
for file in sorted(reports):
    report=json.loads(file.read_text());size=report['catalogSizePerType']
    assert report['beforeStateDigest']==report['afterStateDigest']
    assert len(re.findall(r'[a-z_]+:[a-f0-9]{32};',report['beforeStateDigest']))==10
    for obs in report['observations']:
        label=obs['label'];sql=executed[label]
        assert len(sql)==len(plans[label])==len(obs['sql'])==1,(label,sql)
        expectedtype=obs['businessType']
        assert len(re.findall(r'\?',obs['sql'][0]))==3
        normalized=re.sub(r'\$\d+','?',sql[0])
        assert normalized==obs['sql'][0]
        assert len(sql[0].lower().split(' from ',1)[0].split(','))==7
        assert ' join workflow_definition_version ' in sql[0]
        assert not any(col in sql[0] for col in ['nodes_json','edges_json','description','created_at','updated_at'])
        assert any("$1 = 'RECORD_CONTROL'" in p and f"$2 = '{expectedtype}'" in p and "$3 = 'PUBLISHED'" in p for p in parameters[label]),(label,parameters[label])
        first=10000000 if expectedtype=='CHANGE' else 20000000
        expected=[{'workflowDefinitionId':str(first+i),'workflowVersionId':str(first+1000000+i),'templateName':'容量流程-'+str(i).zfill(6),'templateCode':f'CAP-{expectedtype}-{i}','versionNumber':3,'businessType':expectedtype,'status':'PUBLISHED'} for i in range(1,size+1)]
        assert obs['rows']==expected and obs['returned']==size
        allnodes=list(nodes(plans[label][0]['Plan']))
        planpath=raw/'actual-plans'/(label+'.json');planpath.parent.mkdir(exist_ok=True);planpath.write_text(json.dumps(plans[label][0],ensure_ascii=False,indent=2)+'\n')
        observations.append({'label':label,'size':size,'type':expectedtype,'iteration':obs['iteration'],'businessSelects':1,'elapsedNanos':obs['elapsedNanos'],'threadAllocatedBytes':obs['threadAllocatedBytes'],'sql':sql[0],'parameters':parameters[label],'planPath':str(planpath.relative_to(raw)),'scanShapes':[{'node':n['Node Type'],'relation':n['Relation Name'],'loops':n.get('Actual Loops'),'rows':n.get('Actual Rows'),'index':n.get('Index Name')} for n in allnodes if 'Relation Name' in n],'sort':[{'method':n.get('Sort Method'),'spaceKB':n.get('Sort Space Used'),'spaceType':n.get('Sort Space Type')} for n in allnodes if n['Node Type']=='Sort'],'temporaryReadBlocks':sum(n.get('Temp Read Blocks',0) for n in allnodes),'temporaryWrittenBlocks':sum(n.get('Temp Written Blocks',0) for n in allnodes)})
assert len(observations)==20 and sum(len(v) for v in executed.values())==sum(len(v) for v in plans.values())==20
http=[json.loads(line) for line in (phase/'http.jsonl').read_text().splitlines()]
candidate=[r for r in http if r['path'].startswith('/api/v1/workflow/record-control/candidates?')]
assert len(candidate)==20
assert Counter(r['actualStatus'] for r in candidate)=={200:10,401:10}
for r in candidate:
    assert r['actualStatus']==r['expectedStatus']
    if r['actualStatus']==200:
        m=re.fullmatch(r'candidate-(\d+)-(CHANGE|OBSOLETE)',r['case']);assert m,r['case']
        match=next(o for f in reports for o in json.loads(f.read_text())['observations'] if o['businessType']==m[2] and o['iteration']==2 and o['returned']==int(m[1]))
        assert r['body']['data']==match['rows']
dump('independent-sql-analysis.json',{'base':base,'head':head,'serviceCalls':20,'businessSelects':20,'actualPlans':20,'writesUnderLabels':0,'candidateHttpStatusCounts':dict(Counter(r['actualStatus'] for r in candidate)),'tenTableDigestsEqual':5,'allSevenFieldsAndLast1000Reachable':True,'observations':observations,'scope':'Actual original SQL/parameters/auto_explain from isolated PG;local instrumented calling-thread allocation is not peak/production SLA;JWT+MockMvc,not socket/browser/signing'})
print(json.dumps({'protectedInputs':len(bindings),'knowledgeFiles':len(knowledge),'validatorInputs':len(extra),'tests':summary['totals'],'oldNegative':old['totals'],'observations':len(observations),'actualSelects':20,'actualPlans':20,'http':20},ensure_ascii=False))
