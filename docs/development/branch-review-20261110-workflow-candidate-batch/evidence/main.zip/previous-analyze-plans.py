from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import sys

raw = Path(__file__).resolve().parent
phase = sys.argv[1]
out = raw / phase
text = (out/'postgres.log').read_text()
decoder = json.JSONDecoder()
marker = re.compile(r'\b(wf-candidates-(\d+)-(change|obsolete)-(\d+))\b')
statements = defaultdict(list)
plans = defaultdict(list)
offset = 0


def nodes(plan):
    return [plan] + [n for child in plan.get('Plans',[]) for n in nodes(child)]


folder = raw / ('plans-'+phase)
folder.mkdir(exist_ok=True)
for line in text.splitlines(keepends=True):
    offset += len(line)
    match = marker.search(line)
    if not match:
        continue
    label = match[1]
    executed = re.search(r'LOG:.*?duration: ([\d.]+) ms\s+(?:execute [^:]+|statement):\s*(.*)',line,re.I)
    if executed and re.match(r'\s*(select|insert|update|delete)\b',executed[2],re.I):
        statements[label].append({'sql':executed[2].strip(),'durationMs':float(executed[1])})
    if 'plan:' in line:
        at = offset
        while text[at].isspace():
            at += 1
        obj, _ = decoder.raw_decode(text,at)
        relations=[{k:n[k] for k in ['Node Type','Relation Name','Index Name','Actual Loops','Actual Rows','Rows Removed by Filter','Filter','Index Cond','Shared Hit Blocks','Shared Read Blocks'] if k in n}
                   for n in nodes(obj['Plan']) if 'Relation Name' in n]
        plans[label].append({'durationMs':float(re.search(r'duration: ([\d.]+) ms',line)[1]),'query':obj['Query Text'],'relations':relations,'raw':obj})

observations=[]
for file in sorted((out/'candidate-observations').glob('catalog-*.json')):
    report=json.loads(file.read_text())
    size=report['catalogSizePerType']
    assert report['beforeStateDigest']==report['afterStateDigest']
    assert len(report['observations'])==4
    for item in report['observations']:
        label=item['label']; sql=statements[label]; actual_plans=plans[label]
        expected=size+3
        assert len(sql)==len(actual_plans)==expected,(label,len(sql),len(actual_plans),expected)
        assert all(re.match(r'select\b',s['sql'],re.I) for s in sql)
        assert sum('from workflow_definition ' in s['sql'] for s in sql)==1
        assert sum('from workflow_definition_version ' in s['sql'] for s in sql)==size+2
        assert len(item['rows'])==item['returned']==size
        first=10000000 if item['businessType']=='CHANGE' else 20000000
        assert [r['workflowDefinitionId'] for r in item['rows']]==[str(first+i) for i in range(1,size+1)]
        # Preserve the actual definition plan and representative first/last version plans.
        selected=sorted(set([0,1,len(actual_plans)-1]))
        representatives=[]
        for index in selected:
            plan=actual_plans[index]
            path=folder/(label+'-'+str(index)+'.json')
            path.write_text(json.dumps(plan['raw'],ensure_ascii=False,indent=2)+'\n')
            representatives.append({'path':str(path.relative_to(raw)),'queryIndex':index,'durationMs':plan['durationMs'],'relations':plan['relations']})
        observations.append({'label':label,'catalogSizePerType':size,'type':item['businessType'],'iteration':item['iteration'],
          'returned':item['returned'],'matchedDefinitions':item['matchedDefinitions'],'businessSelects':len(sql),
          'definitionSelects':1,'versionSelects':size+2,'writes':0,
          'serviceElapsedNanos':item['elapsedNanos'],'callingThreadAllocatedBytes':item['threadAllocatedBytes'],
          'sumLoggedStatementMs':sum(s['durationMs'] for s in sql),
          'fullEntityColumns':{'versionJsonSelected':all('nodes_json' in s['sql'] and 'edges_json' in s['sql'] for s in sql[1:])},
          'planShapes':dict(Counter(n['Node Type']+' '+n['Relation Name'] for p in actual_plans for n in p['relations'])),
          'representativePlans':representatives})
assert len(observations)==20,len(observations)
assert sum(x['businessSelects'] for x in observations)==4504
result={'scope':'Original service executed SQL and auto_explain;20 read-only calls,not rewritten EXPLAIN;local warm/instrumented,not production SLA',
 'observations':observations,'totalServiceBusinessSelects':sum(x['businessSelects'] for x in observations),
 'totalCapturedActualPlans':sum(len(v) for v in plans.values()),'representativeRawPlans':60,
 'qualification':'M returned candidates plus2 matching definitions without a published current;SQL=1+D=M+3;100 is a sample,not cap;1000 all returned'}
(raw/('plan-analysis-'+phase+'.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
for item in observations:
    if item['iteration']==2:
        print(json.dumps({k:item[k] for k in ['catalogSizePerType','type','returned','businessSelects','serviceElapsedNanos','callingThreadAllocatedBytes','planShapes']},ensure_ascii=False))
