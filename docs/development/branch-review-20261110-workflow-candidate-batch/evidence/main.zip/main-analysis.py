from pathlib import Path
import datetime, hashlib, json, re, subprocess, xml.etree.ElementTree as ET, zipfile

raw=Path(__file__).parent
repo=Path('/workspace/edhr-nexus-frontend')
candidate='c2691bf711ceb8f7033dae23e28dfaa8104344a5'
target='3b7e4d9a35503020e0baef2a91bb3e9a663fcb05'
def read(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
def git_blob(commit,path): return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=repo)
run=read(raw/'final/run.json')
assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
for item in run['sourceFingerprints']:
    path=item['path']; expected=item['sha256']
    assert expected==sha((raw/'final/source'/path).read_bytes())==sha((repo/path).read_bytes())==sha(git_blob(candidate,path)),path
totals=read(raw/'final/test-summary.json')['totals']
assert totals==dict(tests=103,failures=0,errors=0,skipped=0)
assert read(raw/'focused_old_valid/test-summary.json')['totals']==dict(tests=14,failures=6,errors=0,skipped=0)
assert read(raw/'focused_old/test-summary.json')['totals']==dict(tests=14,failures=6,errors=2,skipped=0)
native='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
service='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java'
assert sha((raw/'focused_old_valid/source'/native).read_bytes())==sha((raw/'final/source'/native).read_bytes())
assert sha((raw/'focused_old_valid/source'/service).read_bytes())==sha(git_blob(target,service))
negative_xml=ET.parse(next((raw/'focused_old_valid').glob('TEST-*.xml'))).getroot()
assert len([t for t in negative_xml.findall('testcase') if t.find('failure') is not None])==6
assert all(t.attrib['name'].startswith(('publishedCandidateCapacityPreservesCompleteCurrentVersionSelection','wideCurrentVersionDoesNotLoadWorkflowGraph')) for t in negative_xml.findall('testcase') if t.find('failure') is not None)
assert sum(t.find('error') is not None for t in negative_xml.findall('testcase'))==0

plans=read(raw/'plan-analysis-final.json')
assert plans['totalServiceBusinessSelects']==plans['totalCapturedActualPlans']==20
log=(raw/'final/postgres.log').read_text()
all_plans=[]
for item in plans['observations']:
    label=item['label']; btype=item['type']
    params=[line for line in log.splitlines() if label+' ' in line and 'DETAIL:  parameters:' in line]
    assert len(params)==2,(label,len(params)) # auto_explain's LOG and completed execute both carry original bindings
    expected=f"parameters: $1 = 'RECORD_CONTROL', $2 = '{btype}', $3 = 'PUBLISHED'"
    assert all(line.endswith(expected) for line in params),(label,params)
    plan=read(raw/item['representativePlans'][0]['path'])
    assert 'nodes_json' not in plan['Query Text'] and 'edges_json' not in plan['Query Text']
    all_plans.append(plan)
def nodes(n): return [n]+[x for c in n.get('Plans',[]) for x in nodes(c)]
for plan in all_plans:
    assert all(n.get('Temp Read Blocks',0)==n.get('Temp Written Blocks',0)==0 for n in nodes(plan['Plan']))
    assert all(n.get('Actual Loops')==1 for n in nodes(plan['Plan']) if 'Relation Name' in n)

prior_dir=repo/'docs/development/branch-review-20261110-workflow-candidate-capacity/evidence'
with zipfile.ZipFile(prior_dir/'main.zip') as z:
    prior_plans=json.loads(z.read('plan-analysis-final.json'))
    for size in [0,1,10,100,1000]:
        current=read(raw/f'final/candidate-observations/catalog-{size}.json')
        prior=json.loads(z.read(f'final/candidate-observations/catalog-{size}.json'))
        assert current['beforeStateDigest']==current['afterStateDigest']
        assert len(re.findall(r'[a-z_]+:[a-f0-9]{32};',current['beforeStateDigest']))==10
        assert [x['rows'] for x in current['observations']]==[x['rows'] for x in prior['observations']]

http=[json.loads(line) for line in (raw/'final/http.jsonl').read_text().splitlines()]
candidate_http=[x for x in http if x['case'].startswith('candidate-')]
assert len(candidate_http)==20,(len(candidate_http),list(http[0]))
assert sum(x['actualStatus']==200 for x in candidate_http)==10
assert sum(x['actualStatus']==401 for x in candidate_http)==10
assert all(x['expectedStatus']==x['actualStatus'] for x in candidate_http)
knowledge=read(raw/'knowledge/test-summary.json')
assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
for item in read(raw/'knowledge/run.json')['sourceFingerprints']:
    assert sha((repo/item['path']).read_bytes())==item['sha256']==sha(git_blob(target,item['path']))
for phase in ['focused_old','focused_old_valid','final']:
    assert read(raw/phase/'cleanup.json')['removed'] is True

knowledge_paths=subprocess.check_output(['git','ls-tree','-r','--name-only',target,'docs/knowledge'],cwd=repo,text=True).splitlines()
assert len(knowledge_paths)==353
assert all(git_blob(candidate,p)==git_blob(target,p) for p in knowledge_paths)
assert subprocess.check_output(['git','diff','--name-only',target,candidate,'gmp-platform/frontend','gmp-platform/backend/src/main/resources','docs/agents','AGENTS.md','codeplzreadme.md','docs/knowledge'],cwd=repo,text=True)==''
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'testedCandidate':candidate,
 'protectedInputsMatch':len(run['sourceFingerprints']),'nativeTestBytesMatchOldServiceProbe':True,
 'mainTotals':totals,'nativePostgres':83,'otherUnitMethodSecurityStatic':20,'knowledgeActual':knowledge,
 'oldServiceSameNativeTestBytes':dict(tests=14,passed=8,failures=6,errors=0,skipped=0),
 'initialFixtureFailurePreserved':dict(tests=14,failures=6,errors=2,skipped=0),
 'all7FieldsEqualPriorFor20Observations':True,'readOnlyTenTableDigestsUnchanged':5,
 'candidateMockMvcRequests':20,'actualBusinessSelects':20,'actualPlans':20,'originalParameterDetailLines':40,
 'allRelationScanLoops':1,'allPlansTempBlocks':0,'knowledgeFilesUnchanged':353,
 'indexConclusion':'No additional index justified by observed0..1000 single-pass hash join/sort; no migration',
 'userApproval':'Explicit next-batch bulk current-version+necessary field projection; not a policy change',
 'limitations':['Local warm instrumented timings and cumulative calling-thread allocation are not SLA or peak',
 'Full candidate response still O(M); larger UI catalog rendering and concurrency not measured',
 'No browser/strict/lint rerun; existing86/missinglint and whole audit queues remain',
 'Old-service probe retains newly added unused repository query; executed listing service is exact target bytes']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
