# W3 新写入口只读源码核对

本材料为源码辅助，非正式 ontologyResult / qualityResult；未参与修复、未运行测试、构建、API、数据库、浏览器或 Actions。只写 `/tmp`，未改仓库。用户授权仍为 edhr-dev 全分支 W0→W7 审查，本轮只覆盖下述 W3 配置写链，不重开 PR5/6、H003/H004/H005，不变更条件运行政策或恢复历史数据。

## 基线与来源

- 固定 sourceCommit / targetCommit / contractReadCommit：`a8285be9b91fb76bcb27ccb16a5258bda1fb5077`，targetBranch `edhr-dev`，uncommittedContractPaths `[]`。读取初始 HEAD 为该提交、工作树 clean；后续生产源文均用 `git show` 固定原文，避免根侧并行编辑混入。
- 知识 `0.3.25 / schema 1.2.0`。已读 AGENTS、codeplzreadme、统一交接契约、知识 README 当前基线/治理段、open-questions 的三项条件运行问题、DEC-0009/0010/0011。既有决策是仓库权威规范，不冒充本次用户重新逐字确认。
- 代码和决策原文为 original-evidence；旧 `edhr-w3b-legacy-config-paths.md` 为 secondary-reference，仅用于定位，全部关键结论回到 a828 源码。
- UI 调用链核对加载 frontend-design 与 premium，并读完整 DESIGN.md、canonical-ui-resolution 和 verification-checklist。目标为中文既有 MUI 管理工具，没有视觉设计变更。按父交接不执行技能运行命令；本材料不声称 UI 合规、视觉验收或运行通过。
- 精确 path、Git blob、原字节 SHA、有限方法范围见 `/tmp/edhr-w3-write-entry-source-map.json`。范围有交叉，不是整文件或整个 W3 已审计。

## 结论

**H009 和 H010 在 a828 仍有明确源码差异。** 未发现必须先由用户作新的政策决定才能开展这两个有限写门禁修复的冲突。当前正常新建 UI 不生成这些旧字段；合法 API 可直接带入字段，旧/外部配置也可能被新写命令复制。没有证据证明真实库中存在这种旧源，不得声称所有新建操作必现或存量库已受影响。

H009 按 DEC-0010-02：FORM 的 `completionCondition` 不属于当前配置、后续不写。saveGraph 只做 config 形状、已提供 fillMode 和活动绑定引用检查，随后完整序列化，未拒绝此键。发布也未查该 FORM 键；保存后发布及自动后继草稿均可继续携带。问题是明确不支持的字段结构写入，不是缺少运行条件求值器。

H010 按 DEC-0011 的 canonical 保存/发布场景：CONDITION 顶层四旧键 `conditionRule / conditionFieldCatalogVersion / conditionFieldSnapshot / conditionExpression` 仅在发布的 hasLegacyConditionConfiguration 拒绝。只要 canonical branches/default 形状正确，草稿可混入任意一个旧键；`null` 也属于键存在，不能借 canonical 值掩盖。分支 `rule` 和固定出口已有基础连线拒绝，不能把混合多个错误的旧测试当作顶层旧键门禁证据。

DEC-0009 的不完整草稿政策继续成立：缺表单引用、无连通、未配置分支 AST/目录/快照，不应因此被新 guard 阻断。不得把完整发布校验搬到 save/copy/newDraft；也不自动禁止任意未知 JSON 键、改变非 FORM/CONDITION 节点含义、剥除键后保存或批量改历史。

## 全部 WORK 图新写入口及副作用顺序

行号以下均为固定 `WorkTemplateController.java`。

| 入口 | 锁与前置条件 | 校验和赋值/写入先后 | 当前差异与失败边界 |
| --- | --- | --- | --- |
| PUT saveGraph 183–218 | 187 lockWorkDefinition；188 版本属于该定义；189 必须 DRAFT | 192 before；194 载荷转 JSON；195–204 只检查 FORM；205 序列化；206 一个 START/END；208 基础连线；209/210 两 setter；214 save；215 rebuild；216 UPDATE audit | 明确旧键未查。现有校验抛错在 setter 前，因此可加同层纯结构 guard 保持原对象/边/投影/审计零写。 |
| POST createDraftVersion 222–235 | 223 同定义锁；224 已有 DRAFT 拒绝 | 228 最新版本作 previous；230 newDraft；231 save；232 rebuild；233 CREATE audit | 无源用 INITIAL START/END 空边；有源直接继承。既存 unsupported 源有前提，必须守 newDraft，不能只守 PUT。 |
| POST publishVersion 239–269 | 240 同定义锁；241 同属版本；242 必须 DRAFT | 243 boundaries；244 基础出口；245 条件完整；246 表单有效；247 填报设置完整；248 全图连通；随后250–257 清 old current 并 save/audit；258/259 PUBLISHED/current/save；262 flush；263 UPDATE audit；264 rebuild；265 newDraft + save；266 rebuild；267 CREATE audit | H010 旧键在245被拒；H009 FORM键未查。**只在 newDraft 加 guard 太晚**：publish 的状态/save/flush/audit/rebuild 已发生；应在现有前置校验段同步拒绝，不能仅依赖事务最终回滚满足直接编排零副作用。 |
| POST copyPublishedVersionToDraft 273–317，已有 DRAFT | 277 同定义锁；278 版本同属；279 source 必须 PUBLISHED；284 找当前草稿；286 createIfMissing=true 时冲突拒绝 | 292 before；293/294 直接拷贝源 nodes/edges；295 save；296 rebuild；297 UPDATE copiedFrom audit | 完全不经过 saveGraph/newDraft；guard 应在 target setter 之前。失败保留 source 和 target 原图、status/current/版本号。 |
| 同 copy，无 DRAFT | 同锁、同属和 PUBLISHED；300 createIfMissing=false 时拒绝 | 305–310 从全部版本计算 next number；311 newDraft(source)+save；312 rebuild；313 CREATE copiedFrom audit | 同样绕过 PUT，newDraft 的共享结构 guard 必须覆盖此路径；不能为修保留键默认开启发布完整性要求。 |
| private newDraft 403–414 | 只在上述事务写命令内部被调用，函数本身不保存 | 404 builder，405 分配 ID；410/411 复制源 nodes/edges 或 INITIAL fallback；412 时间；413 build | 当前不检查源结构。最小共享纯 guard 可在分配 ID/赋值前查明确保留字段，保留源原字节及现有 null fallback；读取历史并不等于赋予旧字段语义。 |

lockWorkDefinition 379–386 使用 repository.findByIdForUpdate，仓储 49–51 是 PESSIMISTIC_WRITE；空值 fallback findById 是测试双兼容路径。所有图写命令有 @Transactional，审计失败 1329–1331 抛 IllegalStateException。以上只能证明源码编排和声明，未运行 JPA、SQL锁或提交/回滚，不称其运行已验。

create/update/delete 模板、applicability-rule 写和 deleteVersion 不承接图 payload；deleteVersion 明确拒绝单独删除。这些未作为本批业务 CRUD 全审或 H005 重开。附查其它图控制器：WorkflowTemplateController.findReviewDefinition 626–630 仅 RECORD_CONTROL；FormProcessController.findDefinition 247–255 仅 FORM_PROCESS。它们不是当前 WORK 图写旁路，不能因共用 WorkflowDefinitionVersion 实体而套用 WORK 保留键政策。

## 基础形状、完整性、投影与历史边界

- validateFlowBoundaries 416–439 只查数组和恰一 START/END。
- validateOrdinaryNodeOutgoingEdges 447–505 保持引用、自环、重复、每出口基数和条件入口方向；conditionHandlesForNode 507–528 检查 branches 数组/对象/唯一动态 ID、拒 branch.rule、检查默认 id/name，但未查顶层四旧键。
- validatePublishableConditionRules 550–585 才用 hasLegacyConditionConfiguration 619–624，并验证每个分支 AST/目录/字段快照。validateConditionDefaultBranch 608–617 还要求默认对象恰两个键。此次 shape guard 不等于完成求值/审计契约。
- FormProcessReferenceService.rebuildForWorkVersion 27–65 先删旧投影、再从 FORM config 提取 process 引用；不会净化完整 nodesJson。将 guard 放在 rebuild 前才能保持被拒写命令无投影副作用。
- WorkflowDefinitionVersion nodesJson/edgesJson 是 jsonb 字符串属性（21–26），实体无键白名单；versionSnapshot/recordAudit 保存完整图原文。修复不应改持久化映射、历史快照、审计内容或原始 sources。
- ExecutionSnapshotBuilder 114–132 把当前 PUBLISHED WORK nodes/edges 完整读入新执行快照，再为 FORM 选表单并 attachFillSettings（139–160）。旧字段可以随图冻结，但未见 completionCondition 语义读取。ProductionExecutionEngine.advanceWork 752–774/conditionOutlet 776–792 读取自身 frozen work.nodes，只按 canonical branches 顺序求值及默认出口；evaluate 794–816 是既有受限字符串求值。不得在引擎、旧快照读者或原 source_json 上新加写结构 guard。
- 三个 open question 的完整来源/取值时点、异常、执行结果版本和审计契约继续保留；未因本写入形状修复而闭环或提升成熟度。

## 前端真实可达入口

`WorkTemplateEditor.tsx` persistentFlowGraph 366–378 只移除 selected/dragging；FORM load 655–750 保留 config（705）并透传。CONDITION load 会过滤带顶层四旧键/branch.rule 的节点（655–683），并过滤不再存在的关联边（733–748）。这不是服务端拒绝，也不是该问题当前正常新建 UI 的复现。

当前新增三路径 2339–2348、2432–2441、2776–2795 均为 FORM `{}` / CONDITION normalizedConditionConfig({})；canonical 初始化 429–441 只添加当前 branches/default，因此新建 UI 自身未见生成 completionCondition 或四旧键的正常入口。

载入/版本切换 1697/1700 与2519使用 normalizeFlowGraph。保存 4509–4542 经 persistentFlowGraph 发 PUT；saveDraft 4721–4725 在 virtual 下先 create，再 PUT。发布 4552–4572 先 PUT 再 POST publish，virtual 发布4606–4624为 create→PUT→publish；这不是跨 HTTP 单事务。复制4625–4656可以先保存当前草稿再 POST copy，覆盖路径/无草稿路径由 createIfMissing区分，正是服务端两个写入口。当前 backend 新 guard 可由既有错误通道反馈，无需重设计界面或做自动清理。

API 定义位于 `frontend/src/api/workflow-work.ts` 33–66：create POST versions，save PUT graph，publish POST publish，copy POST copy-to-draft/createIfMissing。前端预检和目录成功加载不能代替各独立 server 命令门禁。

## 相邻线索与必要反例

默认分支额外字段在 draft 的 id/name检查与 publish 的 size==2 检查间仍有差异，DEC-0011-02 已明确默认分支不存 AST/目录/快照。这里只记相邻线索，不因未运行的推导自动新增 finding 或扩大本批。其它未知键也不纳入 blanket 拒绝。

建议主审以相同 canonical、不完整但形状合法图建立正反矩阵：H009 FORM presence(null/有值)；H010四顶层键各 presence(null/有值)，并用已有 branch.rule/固定出口反例作相邻保护。每类覆盖 PUT、create-with-previous、copy-existing、copy-create、publish；非法源先拒绝且源/目标 nodes/edges/status/current/versionNumber、save/flush/rebuild/audit保持。无键的相同草稿允许，发布缺 AST 仍按原精确诊断失败；完整合法 AST/目录/快照、有序分支及发布后继复制正向保留。不剥键、不清库、不把假无权源或 malformed JSON 当合法新建反例。

若声明持久化与回滚，须另跑真实数据库/HTTP集成，Mockito调用0不替代原生PG。现有测试源码覆盖见只读子辅助 `/tmp/edhr-w3-write-existing-test-scopes.md`，SHA256 `d4f7fb55978c9e6178e49cbf0aff1b930eca3393fc6b7eba710b0f54202ef1c2`；该子实例已 FINAL，也未执行测试。其确认 completionCondition 专项0，canonical+单旧键 PUT矩阵缺失，copy两个正向夹具只是简化字符串，不能作为完整图合法或事务证据。

大模块后续拆分方案维持：可提取无仓储副作用的图基础/保留键 validator，由 save/copy/create/publish 编排显式调用；发布完整性继续独立，控制器保留锁、仓储、投影、审计事务。本批无需以缺陷修复名义实施模块拆分。

本实例及只读测试辅助均结束；最终政策、修复、运行和质量判断由根侧负责，收尾正式质量必须另用未参与修复实例。
