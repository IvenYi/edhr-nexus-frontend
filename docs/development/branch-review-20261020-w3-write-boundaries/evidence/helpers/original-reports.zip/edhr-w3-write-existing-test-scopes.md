# W3 写入边界现有测试源码范围

本材料仅为只读源码辅助，不是正式 qualityResult，未执行测试、构建、API、浏览器、数据库或 Actions，未修改仓库。测试存在及其断言不等于本次运行通过，也不证明真实持久化或事务回滚。

## 固定基线与来源

- fixedCommit/sourceCommit/targetCommit/contractReadCommit：`a8285be9b91fb76bcb27ccb16a5258bda1fb5077`；targetBranch：`edhr-dev`；uncommittedContractPaths：`[]`。
- 读取时 HEAD 为上述提交，初始工作树 clean。为避免并行修复影响，本报告的测试原文来自 `git show <fixedCommit>:<path>`，不是随后变动的工作树。
- 读取 AGENTS.md、codeplzreadme.md、统一交接契约适用部分，以及 DEC-0009/0010/0011。知识版本 `0.3.25`。本材料没有创建业务政策或更新知识成熟度。
- 主来源 path：`gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/controller/WorkTemplateControllerTest.java`。
- Git blob：`4f36cfbe19b9fe52174adb82270184de8768ccaf`。
- 原字节 SHA-256：`978660d98def059f9e557b8daada393a2b7b999a04e894809de031777224dc91`；104,898 bytes，1,514 行。
- readDepth：列明的方法及相邻夹具断言逐读；不是全文件人工审查。实际阅读范围：1–240、406–477、673–916、919–934、1056–1186、1272–1379、1455–1468、1504–1514；其余方法仅名称索引，不算完成。
- 来源性质：当前 Git 测试源码为 original-evidence；决策中的规范条款为仓库权威既有规定。未将历史报告当作当前运行证据。

第 42 行为 MockitoExtension；第 48–55 行仓储、投影服务、ID 生成器、ObjectMapper 为 mocks。第 59–68 行设置部分有效引用夹具。此类断言可以证明直接 controller 编排和对象变更边界，不能单独证明 HTTP 授权、原生 PostgreSQL、真实 JPA dirty checking、锁竞争、提交或回滚。

## 已有范围与真实断言

| 范围 / 固定方法行号 | 实际已有断言 | 对当前审查的价值与限制 |
| --- | --- | --- |
| `rejectsSavingStaleActiveBindingReferencesBeforeGraphOrAuditWrites` 88–109；`rejectsMalformedPublishedProcessMetadataBeforeGraphOrAuditWrites` 112–126 | DIRECT/PROCESS 的活动引用或错误 JSON 被拒绝；draft.nodesJson 保持 before；version save、audit save、reference rebuild 均 0 调用 | 可作为新增旧字段拒绝的零写断言模式。只覆盖绑定/元数据，不覆盖 completionCondition、条件旧顶层键或复制继承；未核 edges 原值。 |
| `savesCurrentBindingReferencesAndDormantSettingsWithoutRequiringCompletedSignatureConfiguration` 129–142；`savesUnresolvedBindingContextAsAnIncompleteDraftWithoutCleaningProvidedConfiguration` 145–155 | 保存活动或休眠设置、未解决引用/缺配置的草稿；config JSON 与输入相同、保持 DRAFT | 防止把发布级完整性前移到草稿，或偷偷清理/归一化既存配置。并不赋予已明确不支持保留字段兼容资格。 |
| `savesUnconfiguredModeAsAnIncompleteDraftWithoutAddingDirect` 186–200 | saveGraph 后 getVersion 仍未补 fillMode，DRAFT 且 edges `[]` | 当前缺失模式合法草稿正向。 |
| `rejectsPublishingAFormWithNoModeBeforeWritingAnyVersionOrAudit` 203–216；`rejectsPublishingProcessModeWithoutAnExplicitProcessBeforeWritingAnyVersionOrAudit` 219–234 | 发布拒绝缺填写模式/PROCESS 缺引用，保持 DRAFT；版本和审计写 0 | 发布完整性和零写相邻回归；不是 H009 字段存在检查。 |
| `rejectsCreatingAnotherDraftWhileOneIsAlreadyEditable` 406–415 | createDraftVersion 遇已有 DRAFT 拒绝，版本 save 0 | 当前草稿唯一性正向边界，无非法继承源输入。 |
| `createsAnEmptyDraftWithoutAnInitialConnection` 418–431 | 无历史时 createDraftVersion 创建版本 1，有 START/END，edges `[]` | 空源新建正向；没有覆盖有历史的 createDraftVersion/newDraft 复制源。 |
| `publishesDraftAndCreatesTheNextInheritedDraft` 434–461 | 合法 FORM 流程发布为 PUBLISHED/current；2 次版本 save、flush；继承草稿版本号 2/DRAFT/非 current，nodes/edges 含原节点/边 | publish 后继 newDraft 的间接正向覆盖。没有非法旧键源，不证明失败后对 current 标记、状态、flush、审计完全无副作用。 |
| `allowsPublishingAFlowWithoutConditionNodes` 464–477；`allowsPublishingMultipleConditionsUsingTheConfirmedWorkRuntimeFields` 673–695 | 合法 FORM 或带 AST/目录/快照的规范动态条件发布成功 | 应保留正常发布正向，不证明整个运行字段政策已闭环。 |
| `publishesOrderedDynamicConditionBranchesAndTheirDefaultBranch` 698–718 | 两条带 AST/目录/快照分支及否则出口，最后仅断言发布状态 | 提供完整 canonical 夹具；方法名含 ordered，但当前未逐字/逐元素断言保存及后继草稿中顺序和快照不变。 |
| `rejectsPublishingDynamicConditionBranchesWhenOneBranchIsMissing` 721–738 | 缺出口连线发布拒绝，版本 save 0 | 发布连通性，不是保留字段形状门禁。 |
| `rejectsMalformedConditionBranchesInsteadOfFallingBackToLegacyRule` 741–758 | branches 非数组、同时含旧 config.conditionRule/conditionFieldCatalogVersion/conditionFieldSnapshot 和固定 condition-true 出口；期望“流程连线数据格式不正确”、版本 save 0 | 多个同时非法条件，首先中图格式/固定出口；不能证明 canonical+单一旧顶层键的 save 或特定旧字段 publish 拒绝。 |
| `rejectsConditionBranchHandleCollisionsAtPublish` 761–781 | 归一化后出口冲突被拒、版本 save 0 | 独立端点边界；不应因加保留字段检查而消失。 |
| `keepsAnUnconfiguredConditionNodeInDraftButRejectsPublishingIt` 784–801 | 构造 canonical 分支 conditionRule:null，只调用 publish，期望“尚未配置结构化条件规则”、版本 save 0 | 只证明发布拒绝；虽方法名提及 draft，未调用 saveGraph，因此不能把它当保存正向。 |
| `rejectsConditionAstWithEmptyGroupsAtPublish` 804–816；`rejectsConditionAstWithAnUnknownOperatorAtPublish` 819–832；`rejectsConditionOperatorsOutsideTheFirstReleaseContract` 835–849 | 空 AST / 未知 operator / 首版外 operator 发布拒绝；末项另核版本 save 0 | 完整性仍应仅在发布；缺失 AST 的草稿允许，不等于允许旧顶层字段。 |
| `rejectsConditionAstWhenFirstReleaseFieldCatalogIsUnavailable` 852–865；`rejectsAnUnregisteredConditionFieldCatalogVersionAtPublish` 868–882 | 不可用/未知字段目录发布拒绝；后项核版本 save 0 | 目录回归，非输入保留字段写门禁。 |
| `rejectsLegacyFreeTextConditionAsTheOnlyPublishFact` 885–897 | canonical 分支、默认分支与顶层 conditionExpression 并存，publish 报“不支持的旧配置字段” | 当前有明确单旧键 publish 反例；未对 saveGraph、其他三旧键、null、有值覆盖；未核版本/投影/审计零写。 |
| `saveGraphPersistsExplicitDirectModeWithoutInferringDormantProcess` 900–916；`saveGraphRebuildsFormProcessReferenceProjection` 919–934 | 显式 DIRECT 与休眠 process ID 保存保持；正常图保存触发一次引用重建 | 应保护休眠配置及正常保存投影，不允许把不相关字段一概禁掉。 |
| `copiesPublishedHistoryOverTheCurrentDraft` 1056–1078 | copy(false) 覆盖现有 DRAFT，保留其 ID/版本号，nodes/edges 等于源；UPDATE 审计 | copy 覆盖路径正向；源只是 `[{"id":"published"}]`，边只是 `[{"id":"edge"}]`，不是完整规范流程。没有旧保留字段拒绝或源/目标失败不变断言。 |
| `createsTheNextDraftWhenCopyingPublishedFlowWithoutAnEditableDraft` 1081–1101 | copy(true) 无现有草稿时创建下一 DRAFT/版本号，nodes 等于源，CREATE 审计 | 另一 copy/newDraft 间接正向；源仍是简化 `[{"id":"published"}]`。不证明合法完整流程校验，未核 edges 或失败副作用。 |
| `rejectsSavingAGraphWithoutExactlyOneStartAndEndBoundary` 1130–1139 | 空 nodes 的 saveGraph 拒绝，版本 save 0 | 基础格式反例；未核对象/edges/投影/审计 0。 |
| `savesDraftGraphAndRecordsTheUpdatedSnapshot` 1142–1166 | saveGraph 写 nodes/edges，版本 save(draft)、UPDATE 审计 | 当前写编排正向；只是 contains，不是原字节精确保持，更不是数据库快照事务验证。 |
| `savesAnIncompleteDraftWithoutPublishValidation` 1169–1186 | START/FORM/END、无 FORM config/引用且无连线可保存，edges `[]`，版本 save | DEC-0009 关键草稿正向，须保护。 |
| `rejectsTwoOutgoingEdgesFromAnOrdinaryNode` 1272–1290 | 普通 FORM 第二出口 saveGraph 拒绝，版本 save 0 | 基础图格式仍适用草稿。 |
| `allowsConditionNodeToHaveMultipleConfiguredBranchEdges` 1293–1318 | 两个 canonical 分支不带 AST/目录/快照，有默认出口，saveGraph 成功 | 缺条件配置但形状正确的实际保存正向。 |
| `rejectsConnectingToAConditionBranchOutlet` 1321–1338；`rejectsConnectingToAConditionWithoutItsUnifiedInputHandle` 1341–1358；`allowsConnectingToAConditionInput` 1361–1379 | 条件出口不能作 target、统一入口要求和合法入口保存 | 动态方向相邻回归，拒绝时只核版本 save 0。 |
| `rejectsCopyingAsNewDraftWhenAnotherRequestCreatedTheDraftFirst` 1455–1468 | copy(true) 遇现有 DRAFT 拒绝，版本 save 0 | 并发已出现草稿的直接编排守卫，不是实际并发或非法图源校验。 |
| `keepsWorkTemplateAndRuleAuditWritesInTheSameTransaction` 1504–1513 | 反射断言 create/update/createRule/updateRule 有 @Transactional | 未覆盖 saveGraph/createDraft/copy/publish，不能称其事务或实际回滚已测试。 |

## 结论与最小必要补充建议

1. 固定测试原文中 `completionCondition` 为 0 次，缺 H009 的实际新写拒绝矩阵。建议以明确 FORM kind、现行形状和合法不完整草稿为底，分别测试该键 `null` 与有值存在；无键正向保留。不要把未知任意键或其他节点同名键推为新政策。
2. H010 缺 `saveGraph` 的 canonical branches/default + 单个旧顶层键反例。建议四旧键逐一存在（含 null/有值），隔离旧形状与缺 AST；移除旧键的同一不完整草稿须能保存，但发布仍因缺 AST 拒绝。完整 canonical AST/目录/快照也应有正向及混旧键反向，保持原分支顺序和冻结内容。
3. 写入口至少分别覆盖 saveGraph、createDraftVersion 有 previous/newDraft、copy(false) 覆盖现有草稿、copy(true)/无草稿新建，以及 publish 后继 newDraft。现有 copy 两正向夹具不是完整图，不能由其成功推断所有源合法；仅新增纯保留字段 guard 与把整套发布校验套到复制是不同改动。
4. 每条拒绝至少检查源和目标 nodes/edges、status/current/版本号不被修改，以及版本 save/flush、reference rebuild、audit save 无调用；现有 H004 零写断言是局部参考。原生 PostgreSQL/JPA 事务回滚及 HTTP 安全必须另用实际运行证据，不从 Mockito 断言外推。
5. 这些是测试源码覆盖缺口，不单独构成产品缺陷判定；产品因果和最终技术判断由主审亲读真实写链、实际红绿及新实例正式 QA 决定。没有运行结果，测试数为 0 executed。

本实例完成后结束；不继续充当正式验收实例。
