# Generic workflow PostgreSQL test seed: source assistance only

- Read-only supporting task; no application tests, Maven, database, browser or Git mutations executed.
- HEAD / source baseline: `84c5b6d6af15f4f9d684c99e8eb8d110ae039954`.
- Target remote-tracking baseline observed: `a8285be9b91fb76bcb27ccb16a5258bda1fb5077`.
- Read AGENTS.md and codeplzreadme.md. Source includes the root's explicitly supplied dirty transfer implementation; the transfer methods are not claimed to exist in the fixed HEAD.
- No semantic policy decision or formal quality result is made here.

## Minimal real completion seed

The existing `WorkflowEngine.completeTask` generic path finds the task and locks the instance/task, validates the current effective `candidateSnapshot.userIds`, saves the task completion, logs `TASK_COMPLETE`, resolves node 30, and calls `progressFromNode`.

`progressFromNode` reads outgoing edges for node 30 and nodes for version 51. A single edge from approval node 30 to END node 31 is enough. The END branch logs `NODE_ENTER`, calls `completeInstance`, sets instance status `COMPLETED`, completedAt and currentNodeIds=null, saves the instance, and logs `INSTANCE_COMPLETE`.

This approval→END path calls neither `StateMachineService` nor `SubjectResolver`. Both may be explicit mock dependencies when tasks are seeded rather than created. That boundary must be disclosed: this does not execute subject resolution or task creation.

Suggested rows (all synthetic):

```sql
INSERT INTO workflow_definition(id,tenant_id,name,code,type,status)
VALUES(50,'9','Synthetic delegated approval','W3-TRANSFER','FORM_PROCESS','ACTIVE');

INSERT INTO workflow_definition_version(id,definition_id,version_number,status,is_current,nodes_json,edges_json)
VALUES(51,50,1,'PUBLISHED',true,'[]','[]');

INSERT INTO workflow_node(id,version_id,node_type,name,properties)
VALUES(30,51,'APPROVAL','Synthetic approval','{}'),
      (31,51,'END','Synthetic end','{}');

INSERT INTO workflow_edge(id,version_id,source_node_id,target_node_id)
VALUES(40,51,30,31);

INSERT INTO workflow_instance(id,definition_id,version_id,business_type,business_id,status,current_node_ids,initiator_id,started_at)
VALUES(20,50,51,'SYNTHETIC_TRANSFER','synthetic-20','RUNNING','30','1',current_timestamp);

INSERT INTO workflow_task(id,instance_id,node_id,task_type,status,assignee_id,candidate_snapshot,created_at)
VALUES(10,20,30,'APPROVAL','PENDING','1',
 '{"userIds":["1","7"],"sources":{"1":[{"type":"ROLE","id":"7"}],"7":[{"type":"ROLE","id":"7"}]},"unresolvedSubjects":[{"type":"DEPARTMENT","id":"8"}]}',
 current_timestamp);
```

For users, provide all actual non-null fields: id, tenant_id, username, password_hash, display_name, status. Use tenant9 users1/2/3/7; user6 tenant10; user4 INACTIVE; user5 ACTIVE with locked_until in the future. No real account or secret is necessary. A constant synthetic password_hash string is enough because no login/password authentication is executed in this controller/engine fixture.

## Entity non-null and JSON boundaries

- `WorkflowDefinition`: id plus name, type, status are explicit @Column non-null constraints. tenant_id is a String, separate from `UserAccount.tenantId` Long. Runtime transfer tenant resolution reads the initiator's stored UserAccount tenantId.
- `WorkflowNode`: name is explicitly non-null; supply id/version_id/node_type/name/properties.
- `WorkflowTask`, `WorkflowInstance`, `WorkflowEdge`, `WorkflowActionLog`: identifiers and business fields above should be supplied even though their scalar @Column annotations mostly permit null. Hibernate-generated schema does not add migration foreign keys automatically to these scalar IDs.
- candidate_snapshot, properties, nodes_json, edges_json and action-log snapshot are JSONB. Use JDBC parameter casts `?::jsonb` for arbitrary synthetic JSON.
- Compare the actually stored pre-transfer `candidate_snapshot::text` against the string in new `originSnapshot`; JSONB may canonicalize the seed's original whitespace/key order before the runtime first sees it.

## Minimal Boot/JPA scope

Reuse the `@EnableAutoConfiguration(exclude = JpaRepositoriesAutoConfiguration.class)` plus `PersistenceManagedTypes` and `JpaRepositoryFactory` pattern already used by WorkTemplateWritePostgresTest.

Import the real `WorkflowEngine` and `WorkflowTaskController`. Expose actual JPA repositories and their managed types for:

- WorkflowInstance / WorkflowInstanceRepository
- WorkflowTask / WorkflowTaskRepository
- WorkflowActionLog / WorkflowActionLogRepository
- WorkflowBindingRule / WorkflowBindingRuleRepository
- WorkflowDefinition / WorkflowDefinitionRepository
- WorkflowDefinitionVersion / WorkflowDefinitionVersionRepository
- WorkflowNode / WorkflowNodeRepository
- WorkflowEdge / WorkflowEdgeRepository
- UserAccount / UserAccountRepository
- AuditEvent / AuditEventRepository

Also expose real SnowflakeIdGenerator, ObjectMapper (Boot's registered module instance is sufficient), and explicit mock StateMachineService/SubjectResolver beans. All repository declared JPQL examined here refers to managed entities within this list; UserAccountRepository has only UserAccount derived queries and JpaSpecificationExecutor.

Use a dedicated loopback database `edhr_w3_transfer_test`, never the parent's other test databases. The new class should validate that exact URL before create/drop. Standalone MockMvc can invoke the actual controller and its real transactional engine proxy with SecurityContext principal set to the actor. It does not claim full SecurityConfig/JWT/filter validation.

## Transaction and evidence assertions

- Before each rejected command, snapshot actual task/instance/log/audit rows; on rejection compare the same stored representations. IDs consumed only in-memory are not database mutations.
- On 1→2 and 2→3, the same task id/node id and unchanged RUNNING instance/current node prove no workflow progress. `findTodoForUser` and `findPendingByCandidateUserId` are real native JSONB queries.
- After 1→2→3, old users1/7/2 must lose effective processing and task visibility; user3 can APPROVE and reach END.
- `AuditEvent` stored fingerprint presence and immutable data are within this fixture's scoped assertions. Do not assert existing AuditEvent JSONB/time rehash consistency or claim it passed: the parent has separately preserved that known gap.
- A synthetic BEFORE INSERT trigger on audit_event that raises can prove actual transaction rollback of task + action log; ensure finally drops trigger/function, only within this owned database.

## Source references read

- WorkflowEngine.java: `completeTask`, `progressFromNode`, `completeInstance`, `resolveInstanceTenant`, `transferTask`.
- WorkflowTask.java; WorkflowInstance.java; WorkflowNode.java; WorkflowEdge.java; WorkflowDefinition.java; WorkflowActionLog.java.
- StateMachineService.java; SubjectResolver.java constructor and resolve entry.
- UserAccountRepository.java; WorkflowInstanceRepository.java; WorkflowDefinitionRepository.java.

These notes provide a finite seed/design map only, not runtime acceptance or whole-file review.
