# H012 消费者只读源码核对

范围：固定 `a8285be9b91fb76bcb27ccb16a5258bda1fb5077` 的任务收件箱、完成/转办授权及 DHR 邻接读取。本辅助不修改仓库、不运行应用、测试、数据库或浏览器，不是正式 qualityResult。知识基线 `0.3.25`；读取 AGENTS、codeplzreadme 和 DEC-0031。来源 blob/SHA 与精确范围见 `edhr-w3-transfer-consumers.json`。

## 结论

不能仅删除 `transferTask` 中覆盖 candidateSnapshot 的语句来修复原始来源丢失。当前完成/转办授权及待办 SQL 均将候选快照当作当前可执行集合；保留原快照而只更新 assigneeId，会使旧候选继续具有待办和处理权；对原候选范围之外的新受让人，还会产生“能看到待办却不能完成”的不一致。这里是对现有源码分支的确定性推演，未执行运行反例。

同样不能把“assignee 非空时优先该单人”作为无条件替代：`createTaskForNode:394–409` 初建多候选任务时本来就把首位候选写进 assigneeId。任一原候选均可完成的 DEC-0031-02/03 仍必须保留。需由主审选择明确区分转办责任投影与创建来源快照的最小实现，并统一所有当前有效集合读者；本辅助不制定新政策或实现方案。

## 当前消费者

| 路径/范围 | 实际消费与边界 |
| --- | --- |
| WorkflowTaskRepository.java:21–26 findTodoForUser | PENDING/PROCESSING、排除 DHR_SUMMARY 后以 `assignee_id=user OR candidate.userIds contains user OR unrestricted=true` 判定。assignee 不覆盖原候选，unrestricted 会继续让所有用户命中。 |
| WorkflowTaskRepository.java:28–31 findDoneForUser | 仅按最终 assignee 及 COMPLETED/REJECTED/TRANSFERRED 判已办。当前 transfer 将任务留 PENDING，故不会因为转办形成原用户的 done 行；本辅助不将此解释为新缺陷。 |
| WorkflowTaskRepository.java:33–36 findPendingByCandidateUserId | 只看候选快照/unrestricted、不看 assignee；全局文本检索仅找到声明，没有找到生产代码调用，不据此宣称有当前可达使用者。 |
| WorkflowEngine.java:247–278 completeTask | 锁实例/任务及检查运行状态后，先 unrestricted，再非空 candidate.userIds，最后仅当集合空时 fallback assignee。完成者会回写 assignee。原快照保留时，旧候选仍可执行；原集合外目标不会因 assignee 已更新而获权。 |
| WorkflowEngine.java:656–684 transferTask 与 709–715 isTaskOperator | 操作者授权同样先 unrestricted、再非空候选、最后 assignee；当前通过改成目标单人快照收紧后续责任，因此不能只删除该覆盖而不修授权读者。 |
| WorkflowTaskController.java:88–103 todo / 108–122 done | 取认证 principal，忽略来参 assigneeId；调用以上 SQL 后内存分页，直接返回 WorkflowTask。身份伪造保护保留。 |
| WorkflowTaskController.java:50–55 getById / 153–164 transfer | 详情返回实体（含 candidateSnapshot）；转办 HTTP 可达，目标必填且操作者取认证 principal；DHR 拒绝由 engine 保证。泛列表/详情权限不在本辅助重新裁定。 |
| DhrReviewService.java:39–47、50–83、98–120、192–200 | DHR 独立查询 candidate_snapshot；eligible 同样 unrestricted→userIds→assignee，控制待办、详情、canAct、签署者资格。泛 transferTask 先 assertNotDhrTask，当前路径不能转办 DHR；不能将 H012 自动扩大为 DHR 转办问题。 |
| DashboardTaskList.tsx:27–39、48–61 | 首页实际 GET `/workflow/tasks/todo` 或 done 并直显接口结果，待办给 `/workflow/tasks/{id}` 处理链接；没有前端候选身份修正或二次过滤。 |
| router/index.tsx:93–103；TaskDetail.tsx:9–25、78–85 | 路由可达真实任务处理页，按钮 POST 任务动作。当前 transfer 按钮请求仅传 opinion/password，不提供 newAssigneeId，会被后端目标必填拒绝；H012 的成功转办必须以明确目标的直接 API/引擎调用复现，不能声称该现有 UI 按钮可成功复现。 |
| api/workflow-tasks.ts:3–9 | getTodo/getDone/getTask/approve/reject/transfer/submit 均是相同 GET `/workflow/tasks` 的占位包装；本次检索未找到调用导入，当前实际首页/详情直接用 client，不以此包装证明转办可达性。 |

## 应保留的测试与缺口

- WorkflowEngineTest:247 unrestrictedTaskCanBeCompletedByAnyAuthenticatedOperator、286 candidateCanCompleteAndActualActorIsPersisted、386 rejectsUserOutsideFrozenCandidateSnapshot：分别覆盖原开放、任一候选及非候选拒绝，均为相邻规则，不应因修转办而弱化。
- WorkflowEngineTest:412 transferKeepsOneLogicalTaskAndUpdatesTargetSnapshot 目前明确断言单人目标快照（429）。这是现有覆盖来源丢失行为的测试，尚未覆盖转后旧候选拒绝、目标完成、连续转办或原来源留存。
- WorkflowTaskControllerTest:26/37 仅验证认证身份用于 todo/done 和一次 mock 仓储查询，不运行 JSONB SQL，不能替代真实 PostgreSQL 收件箱范围验收。
- DhrReviewServiceTest:152 signedReviewChecksNamedSignerAndRecordsBothIdentities 验证命名签署人必须有候选资格；本辅助未运行该测试，也不扩大为转办验收。

建议主审对修复候选验证的最小矩阵：未转办多候选任一可完成；转后旧候选无待办且完成/再转办拒绝；新目标有待办且可完成/再转办；unrestricted 初始任务与转后责任区分；创建来源 sources/unresolvedSubjects 原字节保留；单逻辑任务和节点/实例身份不变；连续转办保留最初解析来源；SQL 使用真实 PostgreSQL；DHR 通用转办仍拒绝。是否允许转给原候选外人员属于泛工作流现有 target 校验边界，不能套用普通生产表单 DEC-0055 的候选范围规则来悄改。

本报告仅为 original-evidence 源码准备材料。所有运行结果、事务持久化、浏览器效果和正式独立验收仍未执行。
