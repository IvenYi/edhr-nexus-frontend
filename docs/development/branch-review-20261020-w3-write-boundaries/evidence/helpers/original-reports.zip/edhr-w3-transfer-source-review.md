# W3 H012 创建候选来源与转办消费链源码核对

固定 source/target/contractReadCommit：`a8285be9b91fb76bcb27ccb16a5258bda1fb5077`，目标 `edhr-dev`，知识 `0.3.25 / schema 1.2.0`。开始时实际核对 HEAD、工作树 clean；先读 AGENTS、codeplzreadme、统一交接契约及知识基线、相关未决和 DEC-0030/0031。仅只读源码辅助，不是正式本体或质量验收；没有修改仓库，没有执行应用、测试、数据库、浏览器、Actions、合并或部署。

## 结论与权威边界

`AUD-H012 / discrepancy.workflow-transfer-overwrites-candidate-origin-snapshot` 在固定源码上仍成立。实际运行所有者是 `WorkflowEngine.transferTask`，不是名为 WorkflowTaskService 的独立服务。任务创建时完整保存解析候选、逐用户主体来源、未解析主体及开放标志；转办在同一逻辑任务上把整个 candidateSnapshot 替换为新目标的单人 TRANSFER 来源快照。原创建主体来源并未另存到本任务或 TASK_TRANSFER 日志 snapshot 字段。日志只有前后处理人文本，不足以恢复全部原候选及命中来源。此结论来自源码，尚无本辅助运行红绿证据。

DEC-0031-01/02/03/04 以及 `workflow-task-multi-candidate-user-confirmed.md` 原始记录明确：每节点一个逻辑任务，任一创建候选可完成，非创建候选不得完成，创建时解析及来源供审计，普通组织关系变化不改写候选。DEC-0030 负责按调用时关系解析及保留全部命中来源，不制定转办授权。`WorkflowTask.candidateSnapshot` 现有注释也明确称 immutable runtime resolution snapshot。

**没有查到“泛工作流允许转给原候选之外同租户 ACTIVE 用户”的权威确认。** 当前泛 transfer 的 target 校验只要求非空数字用户 ID、存在、ACTIVE、与发起人同租户；现有单测也允许原候选之外目标。这是实现行为和测试行为，不能反推出已确认政策。DEC-0031-03 的创建候选约束是否允许显式转办例外，当前相关决策/原始确认未说明。普通生产表单 DEC-0055 的范围内转办和记录控制 DEC-0037/0041 的规划授权范围都属不同调用方，不能静默跨用。

最小可回答业务问题：**通用工作流的受限任务，转办目标是否必须来自任务创建时冻结的候选集合，还是允许转给集合之外符合指定资格的人？** 开放任务和受限任务需区分；若允许集合外，仍应明确例外范围。主审负责集中确认；本辅助不新增问题文件、授权规则或默认值。

## 当前完整链与消费者

| 固定源码方法/范围 | 实际行为 |
| --- | --- |
| SubjectResolver.resolve + 各主体展开 | 调用时查用户/部门/角色；最终用户去重且保留全部来源，失效引用进 unresolved。解析器本身不决定转办策略。 |
| WorkflowEngine.resolveAssignees:496–529 | 读取 node/config 审批主体和 permissionGroupRules；组装 userIds/sources/unresolvedSubjects。无主体写 unrestricted=true，记录控制任务排除发起人来源。 |
| createTaskForNode:394–417 | 一个节点只建一条逻辑 task；assigneeId 初始就是首位候选，candidateSnapshot 保存上述完整结果。未转办多候选并非 assignee 为空。 |
| WorkflowTaskController.transfer:153–164 | POST `/api/v1/workflow/tasks/{id}/transfer`，newAssigneeId 必填，operator 用认证 principal，不信任 request.operatorId。 |
| WorkflowEngine.transferTask:656–685 | 拒绝 DHR；锁实例与任务；需 RUNNING、PENDING/PROCESSING；用 isTaskOperator 校验当前可办人，再校验目标。保存同一 task ID/instance/node，仅责任及目标快照改变，不推进节点。 |
| validateTransferTarget:727–740 + singleUserSnapshot:742–752 | 同租户 ACTIVE 是当前代码边界；单人快照为 userIds=[目标]、sources={目标:[TRANSFER]}、unresolvedSubjects=[]，不含原始完整解析快照或原 unrestricted。 |
| completeTask:247–300 / isTaskOperator:709–715 | 先 unrestricted，再非空 snapshot.userIds，最后空集合才 fallback assignee。完成者回写 assignee。 |
| WorkflowTaskRepository.findTodoForUser:21–26 | 当前待办是 assignee OR candidate.userIds OR unrestricted；不是 assignee 覆盖候选。findPendingByCandidateUserId 同样直接读候选，本次检索只找到声明。 |
| logAction:638–652 / WorkflowActionLog | 实体存在 snapshot 字段，但此 logAction builder 未设置它。TASK_CREATE 仅记数量，TASK_TRANSFER 仅记前后人，不能恢复原 sources/unresolved。 |
| DhrReviewService 及 assertNotDhrTask/Instance | DHR 资格也读候选，但泛转办显式拒绝 DHR；不将 H012 外推为已有 DHR 转办。 |
| TaskDetail.handleAction:16–25 / 转办按钮:78–85 | 当前任务页只 POST opinion/password，没提供目标，会被目标必填拒绝。成功复现必须用明确目标的 API 或 engine，不能宣称现有 UI 按钮成功触发。 |
| ProductionExecutionEngine.transferForm:382–397 | 普通生产表单把当前责任另放 transferAssignees，保留原 approvers，是另一套已确认路径；仅作边界对照，不把其规则套给泛 workflow。 |

消费侧只读子辅助已经 FINAL，原件 `/tmp/edhr-w3-transfer-consumers.md` 与 `.json`，有 13 个文件的固定 Git blob/SHA，未运行测试。其正文另列首页路由/待办与 DHR 读者，不构成独立 qualityResult。

## 不能直接采用的简化修复

1. 只删除 setCandidateSnapshot：旧候选或原 unrestricted 仍能看到、完成和再次转办。原集合之外目标虽因 assignee 命中 todo，completeTask 却会拒绝，产生显示/动作不一致。
2. assignee 非空就以 assignee 为唯一处理人：初建多候选已设置首人，会破坏未转办任一候选可完成规则。
3. 改用最新组织关系重算：违背 DEC-0031-04 且不能重建原始来源。
4. 把普通表单范围规则直接套过来：没有泛工作流的声明级替代依据；也不能以主审源码发现替代用户政策确认。

## 可与目标资格歧义解耦的最小整改方向

仅对未来成功转办保留**转办前最初解析快照完整原件**，后续转办不覆盖该原件；当前有效 userIds/sources/unrestricted/目标校验和所有动作/SQL 继续使用原有层级，可独立修证据丢失而不新增或收紧授权目标。可在现有 candidate_snapshot 中显式区分创建原件与当前责任投影，或使用已存在的审计存储；具体工程所有权和可查询性由主审选择，不由本辅助实施。

该方向只保留本来应留的来源事实，不解析新业务含义、不恢复历史、不放开额外目标。它**不能证明现有集合外授权符合业务，也不自动关闭该范围的疑义**。若另加 transfer 责任字段并让原 userIds 保持创建集合，则必须同步所有上述授权/SQL读者；那会比单纯附加来源证据扩大实现范围，应明确记录。旧代码已经丢掉的来源不能从当前单人快照或日志推测补齐。

## 最小必要验证设计（均尚未执行）

1. 以原创建候选 A/B、含多个角色/部门来源及 unresolvedSubjects 的真实解析快照创建一条 task；A 转给原候选 B。该例无需假定集合外转办合法，就能证明原 sources/unresolved 丢失。候选完整原件与任务 ID/instance/node 应保留。
2. 连续 B→A 转办，最初来源保持；当前只有受让人可完成/再转办，旧人没有待办。开放快照转办后的有效责任不能继续因原 unrestricted 开放。
3. 未转办多候选 B 仍能完成，非候选拒绝；未转办开放任务仍按原开放规则。原状态终态、实例终止、无效/非ACTIVE/不同租户目标、DHR通用入口拒绝均保持。
4. 用 PostgreSQL 执行实际 findTodoForUser/候选 JSONB 查询，不能只用 mock controller 证明待办一致。若要声称真实事务回滚和持久化原字节，另需真实集成用例。
5. 原始来源已经丢失的历史任务只保留现状并披露缺口，不从最新关系或当前目标伪造创建来源。
6. 目标范围政策未定前，集合外行为仅可标实际实现/保留范围，不能作为业务授权通过的正向验收。普通生产表单/DHR另路径相邻回归不等于泛转办完成。

现有 WorkflowEngineTest 的 createsOneLogicalTaskForOneHundredResolvedCandidates、unrestrictedTaskCanBeCompletedByAnyAuthenticatedOperator、candidateCanCompleteAndActualActorIsPersisted、rejectsUserOutsideFrozenCandidateSnapshot、transferKeepsOneLogicalTaskAndUpdatesTargetSnapshot 均已读源码；最后一个只断言目标单人，并未核对原来源、连续转办或真实 JSONB 待办。本辅助未执行这些方法，不能统计 passed。

本报告是 original-evidence 源码准备材料；历史 discrepancy 仅作 secondary-reference。最终根因、最小实现、知识同步与正式独立运行验收仍归主审负责。
