# AuditEvent 指纹消费者有限源码核对

本实例仅作只读来源辅助，不是正式质量验收，未修改仓库，未运行应用、测试、数据库、浏览器或 Actions。固定 source/target/contractReadCommit 均为 `a8285be9b91fb76bcb27ccb16a5258bda1fb5077`，知识基线 `0.3.25 / schema 1.2.0`。AGENTS、codeplzreadme 与统一交接契约已读取。下面是列明方法/片段的源码结论，不构成整文件、全审计系统或业务运行通过。

## 结论

固定基线的生产源码中，`AuditEvent.computeSnapshotHash()` 唯一调用者是该实体自己的 `@PrePersist sealSnapshotHash()`。没有读回 `audit_event` 后重新计算并与 `snapshot_hash` 比较的 API 或导出门禁。不能把新 PG 测试的“读回后重算不一致”描述成当前审计页面或 DHR ZIP 必然报错。

该新断言是对已有公开实体方法与持久化可重算性的额外验证。若父级实际 PG 运行已证明不一致，它可以支持指纹可验证性缺口，但当前消费者不会主动拒绝，因此“业务查询/导出可继续”与“指纹可复核”必须分别报告。不能由消费者未校验推断指纹一致，也不能由此直接授权改写历史审计或更换摘要算法。

## 当前读取/导出链

| 原始来源与范围 | 核对结果 |
| --- | --- |
| `compliance/entity/AuditEvent.java:57-75` `sealSnapshotHash/computeSnapshotHash` | 指纹为空时，在持久化前计算 SHA-256。`git grep computeSnapshotHash(` 对固定基线只命中此调用及方法定义。 |
| `compliance/controller/AuditController.java:29-67,113-142,307-313` `list/toAuditLogItem/getById` | list 经 repository/search 后直接投影 `event.getSnapshotHash()`；详情直接返回实体。没有重算/比较或失配异常。 |
| `compliance/repository/AuditEventRepository.java:16-39` | 查询按实体、动作和人员/文字过滤；无指纹校验条件。 |
| `compliance/dto/AuditLogItem.java:9-32` | 仅一个字符串 `snapshotHash` 字段，无校验结果、算法版本或原始封存载荷字段。 |
| `production/service/DhrArchiveService.java:155-167,212-245` `auditsFor/sourceAuditEvents` | JDBC 读取 `audit_event.snapshot_hash` 并原样放入 manifest。选定范围可去掉 before/after/dataSummary；没有验证这些审计摘要。 |
| `production/service/DhrArchiveService.java:247-289` `sourceSignatures/signaturesFor` | 这里确实执行 SHA-256 并可能阻断导出，但校验对象是 `signature.snapshot_data/snapshot_hash`，不是 AuditEvent。不能合并成同一检查。 |
| `production/service/DhrSummaryService.java:155-184` `versionAudit/auditPage` | DHR 审计页面返回事件身份、时间、原因和 before/after；此查询没有取出 audit_event.snapshot_hash，也没有校验。 |
| `frontend/src/api/audit.ts:4-37` | 前端 DTO 接收可选字符串，API 客户端只发 GET。`exportAuditLogs` 的客户端声明本身不能证明服务端存在验签接口。 |
| `frontend/src/pages/system/AuditLogPage.tsx:750-780,1060-1090` | 快照指纹仅显示在操作数据及环境详情；未做密码学运算、比较或“验签通过”判定。本次只核对数据消费，不做 UI/视觉通过声明。 |

其他 `getSnapshotHash()` 生产命中（`AuthController:395`、`ExecutionAccess:299`）接收者均为 `Signature`，不能当成 AuditEvent 的验证消费者。DHR 冻结版本/终止原件有各自摘要门禁，同名 `snapshotHash` 不等于相同摘要范围。

## 既有测试的实际声明范围

- `AuditEventTest:14-40`：构造一个内存对象，调用 seal 两次，检查 64 字符且第二次不变；没有数据库 round trip 或读回后重新计算。
- `AuditControllerTest:119-128`：仅断言 DTO 指纹等于原实体指纹，未调用 computeSnapshotHash。
- `EquipmentControllerIntegrationTest:116-121`：保存审计后检查 `[0-9a-f]{64}` 和 before/after 的语义内容；没有证明存储后重算一致。
- `DhrAttachmentAndArchiveTest:158-175,210-213`：断言 ZIP 带来源审计/签名；将签名行摘要设错后阻断，覆盖的是 Signature，不是 audit_event 指纹。

本实例未运行这些测试；只报告源码断言覆盖。工作树中父级新增 `WorkTemplateWritePostgresTest` 的 compute 调用不在固定基线，不将其写成既有通过证据。

## 保留边界

本报告不选择新摘要规范，不定义旧审计回填/重封存，不判断合规法规后果。父级应以独立 PG 红证和准确摘要范围定位缺口，再决定有限整改或登记为跨域独立批次；不应为了当前 W3 新写 guard 造绿而声称旧指纹机制已验证。

以下收据由固定 Git 对象生成。读取范围见上表；文件摘要不代表整文件已审。

| Path | Git blob | SHA-256 |
| --- | --- | --- |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java` | `52f8cb650e0afdfda19b724aeb50cd70fa791f30` | `61932bd33d0c0cb8d1886335c5aab0229753e3d5f4022fdeead5f0e075a0ad6e` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java` | `c529a3a2f6e2d30e47a9e4054da062eb9f502204` | `4ba853d52c1fe59cb86209cb70952f3a19733ed676a57badf3232fc786851154` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java` | `756816a21ecdff6aca7b5410636829cc4de10c5b` | `1e0006a97a4bb745de780902b689407307d1eab7f9aabf168762dc9f806625bf` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/dto/AuditLogItem.java` | `b1aba4ff918fbfac9d0b5959a4ffe32e5a670bf5` | `b178b0a33c14e93889230d7aab411adcdf4e2dfffb7e5b9094d9837e7f005021` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java` | `46c2f16d8857d1aaaa42865779f57c85959bd7a6` | `bf1d938746ebd3d4c4df7f94b54c0892647639cedefcc85633d6fa28cf402e08` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java` | `3307bdf7f2891f1218f1fc7051da5abbafca66e1` | `362f27fd9c84fccda347a312916ce790f32a6b99c1cf0ba53038c14ee4d03b13` |
| `gmp-platform/frontend/src/api/audit.ts` | `fa26fc50cd56c4afee1d7037a6014bca911157d8` | `85bc26559c4cde92a7da4bf2c08d3361f795bc839825de20368e549e2a2538dc` |
| `gmp-platform/frontend/src/pages/system/AuditLogPage.tsx` | `f565e246a2ce22de1dc26ec9f342b6d2c875d8d0` | `575e8e3c6b93882e4642eb6b823afea7bae65e5995934c8a2748cfe270ef690d` |
| `gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTest.java` | `6e43a395c7b1888ed727e71e5bcacde561139719` | `a9dee9a5c3a7b0fa04a2cee5044b1ded733beb9b10755944d49bcf2862cbd1aa` |
| `gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditControllerTest.java` | `9c1e74dfcdc162f18e0c7aae0151e0e315a6869d` | `a59ba7015c4b597df682667dddf39817d7001e31619b5a02fdce2cae2c578d9c` |
| `gmp-platform/backend/src/test/java/com/zencas/edhr/masterdata/controller/EquipmentControllerIntegrationTest.java` | `9e92e80ab6dc0bfe3e2a76c1fd134674e8ba68a9` | `f885b6d6253981ef92258a96a8a0af3ec32add2c288da40adb9a3598ca4e120d` |
| `gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentAndArchiveTest.java` | `5148f3414118a4c36664910d0334388c949961ba` | `0c97af7b8707ebe68b0bfe4c442cdd3d433fe811b8aa3e087b3aaf695bb0dd73` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/AuthController.java` | `d6c03a7e95dbd6934f00c7efc821b839bacbf3e0` | `94adac4633eafd8dfed9d69824bde687e2d7e18c7c905cbbd9cc27cf9128bf26` |
| `gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java` | `11cbf604a28ad8e4c091e259d2c53ea8fef4247c` | `c2239947ee6053ed2731030b67d0f8c84cee6f2aed57716b11938797803e8c9c` |
