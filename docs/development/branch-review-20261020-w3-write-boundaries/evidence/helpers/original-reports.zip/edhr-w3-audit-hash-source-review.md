# W3 相邻 AuditEvent 摘要可重算性：只读来源核对

本辅助不是正式 QA，没有运行应用、测试、数据库、浏览器或迁移，没有修改仓库。固定源码/目标/契约读取提交均为 `a8285be9b91fb76bcb27ccb16a5258bda1fb5077`，知识 `0.3.25 / schema 1.2.0`。当前工作树有根侧 WorkTemplateController guard 和新测试，相关 AuditEvent、消费者及原迁移与该固定提交字节相同。列明范围和 Git blob/SHA 见相邻 map。

## 判断

这是既有 AuditEvent 摘要**可重算性**的真实工程缺口，未发现它会使当前正常工作流保存、审计查询或 DHR ZIP 因审计摘要校验而失败的运行消费者。新 PG 断言比既有 W3 形状拒绝、审计同事务和原值保持要求多验证了一项能力；不能把断言失败归因于本轮 guard，也不能因本轮聚焦而改称该能力通过。是否作为当前交付阻断由主审和正式 QA 决定，本辅助不发布 merge 判断。

根侧提供的 `/tmp/edhr-w3-write-postgres-primary-summary.json` 记载真实 PG 新正向方法 `incompleteDraftsPersistAndReadBackWithRealReferenceRefreshAndSealedAudit` 的读回重算断言失败。该运行由根侧执行，本辅助只读安全摘要，不声称独立重跑。另一 unique-current 错误不属于本报告裁定。

## 原始源码因果

`AuditEvent` 的 `@PrePersist sealSnapshotHash` 在缺少摘要时调用 `computeSnapshotHash`。名为 canonicalAuditPayload 的方法对字段做长度前缀拼接，但 `contentBefore`、`contentAfter` 直接使用原 String，`createdAt` 直接经 `String.valueOf` 进入摘要；它没有将 JSON 解析成稳定表示，也没有定义持久化时间精度。这个“canonical”只防止字段拼接歧义，不等于跨数据库规范化。

这三个字段分别映射为 PostgreSQL `JSONB`、`JSONB`、`TIMESTAMP`，原 `0001-init-schema.sql` 与实体一致。合法 JSONB round-trip 可改变对象键序和空白；例如紧凑 `{"a":1}` 与 PG 读回表示 `{"a": 1}` 语义相同，进入当前长度前缀摘要的文本却不同。即使将 createdAt 固定为整秒来隔离时间因素，JSON 差异仍足以导致原 payload 与读回 payload 不同。时间字段未定义 Java 纳秒到数据库精度的策略，是另一个需用独立反例隔离的风险；本辅助不据根侧一个失败断言宣称已经分别实测两种因果。

合法入口不是人工篡改：固定 `WorkTemplateController.recordAudit/toJson` 使用 ObjectMapper 序列化真实前后快照，设置 `LocalDateTime.now`，再通过 AuditEventRepository 保存。H009/H010 guard 不改变这些方法、AuditEvent、列类型或消费者。其他采用同一实体的写入也可能受影响，具体运行覆盖仍待后续 W5 实测，不能从一个方法外推全部审计都失败。

## 真实读取/导出边界

| 来源 | 实际行为 |
| --- | --- |
| `AuditEvent.sealSnapshotHash` | 唯一生产 `computeSnapshotHash` 调用，发生在新实体持久化前 |
| `AuditController.list/toAuditLogItem/getById`、`AuditLogItem` | 返回存储的 contentBefore/contentAfter/snapshotHash；未重算比较 |
| `AuditLogPage`、`api/audit.ts` | 将原 hash 作为“快照指纹”展示，无前端摘要验证 |
| `DhrArchiveService.auditsFor/sourceAuditEvents` | 将数据库审计内容及原 snapshot_hash 放入追溯资料，不对 AuditEvent 重算 |
| 同服务的 `sourceSignatures/signaturesFor` | 实际 SHA 比较针对 signature.snapshot_data；属于另一种证据，不能当作审计摘要校验 |
| `DhrInstanceService.detail` | 终止冻结快照有自己的 SHA 校验，不是 AuditEvent payload |

全源码检索没有找到审计 hash 读时匹配判定。因此可以说明导出的审计指纹目前无法保证由导出列值重算复核，不能说明当前导出会因这一审计摘要差异被阻断，也不能将签名/DHR 快照的 SHA 路径一起判坏。

## 既有测试与知识的范围

`AuditEventTest` 两项只检查同一内存对象重复 seal 产生稳定 64 位摘要，以及 `@PreUpdate` 拒绝修改；没有存储往返。`AuditControllerTest` 对构造并 seal 的内存事件做 DTO 原 hash 传递断言，没有重算验证或数据库。原 DEC-0015 及主数据审计规则强调真实前后状态、统一 AuditEvent、历史不回填；它们没有确认一个跨 JSONB/时间格式的摘要协议，也不支持把“保存 hash”扩张为“全部历史可重算验证已闭环”。

## 历史与最小后续证据

原 `0023` 仅添加 nullable snapshot_hash，不回填。`0059` 历史 BASELINE 和 `0104` MIGRATE 直接 SQL 写审计，没有该列，不经过实体 @PrePersist；合法既有审计可无摘要。`@PreUpdate preventMutation` 明确保护已有实体。JSONB 通常不会保存原 JSON 文本的空白/键序，因此不能假定只凭已有数据库列就可恢复旧 hash 输入；不应重算覆盖旧 hash 或伪造过去校验。

如后续修复，应先明确新事件的稳定摘要表示、时间精度、算法/格式版本或原始受封 payload 的保存方式，再独立设计旧记录的可验证性标记和读取边界。单独将新 canonical 算法套到历史，不代表旧摘要恢复。这里的缺陷定位本身不需要新业务政策；若范围扩大到历史重建、回填或新增合规完成承诺，超出本轮授权边界，不能由实现者自行扩大。

最小独立验证设计（本辅助未运行）：固定整秒时间，仅非空 JSON，真实 JPA 保存/独立会话读回，比较原 payload 与读回 payload；再用 contentBefore/contentAfter=null、纳秒时间单独验证时间精度。保留 null hash 历史正例、原记录与 hash 不变断言、正常审计查询和 ZIP 原 hash 传递正例，以及故意改一项业务内容的新事件负例。随后按单独工程切片决定整改，不把本轮 guard 的通过记录替代它。

本实例及消费者子辅助均只读、不参与修复。消费者的更细原件为 `/tmp/edhr-w3-audit-hash-consumers.md`。
