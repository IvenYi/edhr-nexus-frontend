from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/edhr-nexus-frontend')
raw = Path('/tmp/edhr-record-change-async-20261110')
base = '8be9b78b41644693864a9429b5c5741d18d52edf'
candidate = '7e43939b519b743e73ca993d66632b1316655fed'
git = lambda *args: subprocess.check_output(['git', *args], cwd=repo)
sha = lambda data: hashlib.sha256(data).hexdigest()
load = lambda name: json.loads((raw / name).read_text())
assert git('rev-parse', 'HEAD').decode().strip() == candidate
main = load('corrected/result.json')
old = load('old-full/result.json')
assert (main['tests'], main['passed'], main['failed']) == (26, 26, 0)
assert (old['tests'], old['passed'], old['failed']) == (26, 0, 26)
assert all(not case.get('pageErrors') for case in old['results'])
assert all(case['writeCount'] == (1 if case['scenario'].startswith('refresh-') else 0) for case in main['results'])
workflow = load('workflow-ui/result.json')
assert (workflow['tests'], workflow['passed'], workflow['failed']) == (58, 58, 0)
inputs = load('workflow-ui-run.json')['sourceFingerprints']
assert len(inputs) == 27
for name, code in [('workflow-ui', 0), ('list-style', 0), ('fonts', 0), ('lint', 2), ('premium', 2), ('premium-baseline', 2)]:
    run = load(name + '-run.json')
    assert run['head'] == candidate and run['exitCode'] == code, name
    assert run['sourceFingerprints'] == inputs
for row in inputs:
    assert sha((repo / row['path']).read_bytes()) == row['sha256'] == sha(git('show', candidate + ':' + row['path']))
    assert sha((raw / 'source' / row['path']).read_bytes()) == row['sha256']
before = load('premium-baseline.json')
after = load('premium-final.json')
key = lambda f: json.dumps({k: v for k, v in f.items() if k != 'line'}, sort_keys=True)
a, b = Counter(key(f) for f in before['findings']), Counter(key(f) for f in after['findings'])
assert a == b and sum(a.values()) == 86
assert after['summary'] == {'errors': 86, 'total': 86, 'unresolved': 14, 'violations': 72, 'warnings': 0}
assert 'ESLint couldn\'t find a configuration file' in (raw / 'lint.log').read_text()
assert 'built in' in (raw / 'build.log').read_text()
protected = ['gmp-platform/backend', 'docs/knowledge', 'AGENTS.md', 'codeplzreadme.md', 'docs/agents',
             'DESIGN.md', 'gmp-platform/frontend/src/components', 'gmp-platform/frontend/src/api']
assert not git('diff', '--name-only', base, candidate, '--', *protected)
knowledge = git('ls-tree', '-r', '--name-only', candidate, '--', 'docs/knowledge').decode().splitlines()
assert len(knowledge) == 353
result = {
    'baseCommit': base, 'candidate': candidate, 'sourceFingerprints': inputs,
    'actualMainBrowserChecks': {'new': '26/26', 'adjacent': '58/58', 'total': 84,
        'qualification': 'Maintained React components and API client with synthetic intercepted API, not live backend/signature E2E'},
    'new26AndBuildRuntimeBinding': 'Ran at dirty8be before commit; same staged changed files committed to7e. No retroactive claim of clean7e execution; independent QA actually validates fixed clean candidate.',
    'adjacent58AndStaticRuntimeBinding': 'Actually ran at clean7e,27 captured inputs match Git/current/source snapshots',
    'oldControl': {'tests': 26, 'passed': 0, 'failed': 26, 'sourceCommit': base,
                   'qualification': 'Same final harness points to own untouched8be worktree; failures are assertion matrix/confirmation-contract mismatches,not26 independent defects;no pageErrors'},
    'build': 'Actual exit0 from exec session31821,TypeScript+Vite;log retained',
    'static': {'strictExitCode': 2, 'findings': 86, 'violations': 72, 'unresolved': 14,
               'comparison': 'Exact multiset ignoring line relocation; multiplicity preserved', 'added': 0, 'removed': 0,
               'lint': 'exit2;existing missingESLint configuration;not passed'},
    'scopedStatic': {'listStyle': 'passed', 'noExternalFonts': 'passed'},
    'history': {'initial': 'Tool0 checks: missing bundle.css from no stylesheet import,log preserved;harness corrected to import actual index.css',
                'baseline': 'Core12 actual failing assertions at old source',
                'focused': '22pass4fail: keyboard opened confirmation then default keyup cancelled;subsequently preventDefault',
                'confirmation': '0pass4fail:waiting showed dialog gone,not fixed by waiting',
                'confirmation-keyboard': '2pass2fail:correct cancel focus/Escape;confirm assertion preceded dialog closing transition,added waitFor unchanged final control assertion',
                'corrected': '26pass;unchanged expectations', 'old-full': 'same final harness26fail'},
    'readOnlyScope': 'No shared database,real business write,CI query/trigger,merge,deploy or restore',
    'unchanged': ['backend', 'API', 'schema', 'knowledge353', 'policy', 'sharedConfirmDialog/AppDialog', 'DESIGN', 'contracts'],
    'a23': 'Request generation protects actual out-of-order completions;effect cleanup protects actual mode/source lifecycle.No generic cache,retry,sharedframework or fallback authorization added.',
    'wholeFileCompleted': 0, 'historicalUnique': 'unknown', 'completeOverallAudit': False,
    'remaining': ['W2-W7 cross-chain/fullsemantic/UI86/A12/high-risk/fullmatrices',
                  'A23 including already reviewed and user-paused modules',
                  'Record-list qualificationSQL and audit-eventDB paging proposals remain unanswered/unimplemented',
                  'Candidate-version N+1 is source signal only,not yet measured;deduplicate and quantify later',
                  'Existing capacity/fault/UNKNOWN/family4N and option-full-load queue'],
}
(raw / 'main-analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
(raw / 'premium-delta.json').write_text(json.dumps(result['static'], ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'candidate': candidate, 'mainBrowser': 84, 'oldFail': 26, 'inputs': len(inputs), 'staticAdded': 0, 'staticRemaining': 86}, ensure_ascii=False))
