from pathlib import Path
import json
import yaml

ROOT=Path('/workspace/edhr-nexus-frontend')
OUT=Path('/tmp/edhr-record-change-async-ontology-20261110')
records={}
for path in sorted((ROOT/'docs/knowledge').rglob('*.yaml')):
    doc=yaml.safe_load(path.read_text())
    def walk(value):
        if isinstance(value,dict):
            if isinstance(value.get('id'),str):
                records[value['id']]={'path':str(path.relative_to(ROOT)),'value':value}
            for child in value.values():walk(child)
        elif isinstance(value,list):
            for child in value:walk(child)
    walk(doc)

POLICY='gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java'
WORKFLOW='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java'
PAGE='gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx'
CLIENT='gmp-platform/frontend/src/api/client.ts'
items=[
('DEC-0087-01','direct','consistent','首期按表单实例流水号检索并同页发起CHANGE/OBSOLETE；最新请求归属不增加批次/SN、DHR或记录本检索。',[PAGE+'#search/loadRecord',POLICY+'#findRecord']),
('DEC-0087-03','direct','consistent','页面编辑不占业务锁；最终后端事务仍复核COMPLETED、有效修订及同实例活动申请。取消或忽略旧UI响应不是撤销已执行写入。',[POLICY+'#submit',PAGE+'#confirm']),
('DEC-0087-04','direct','consistent','原因/真实拟数据差异、类型匹配已发布具体流程版本、真实签名及一次确认不变；只防旧候选覆盖当前类型。',[POLICY+'#submit',WORKFLOW+'#listPublishedCandidates/start',PAGE+'#chooseMode/confirm']),
('rule.record-change-search-scope-v1','direct','consistent','仅约束首期流水号范围，不规定某种控件；IME Enter及既有确认改用应用组件属于技术实现，不反写成新业务规则。',[PAGE+'#search', 'docs/knowledge/evidence/record-change-search-scope-user-confirmed.md']),
('rule.record-control-source-eligibility-v1','direct','consistent','来源已完成、当前修订存在和无活动申请三个条件仍属后端实时门禁；新查询清旧UI上下文不改变资格。',[POLICY+'#findRecord/submit']),
('DEC-0094-01','direct','consistent','CHANGE/OBSOLETE候选仍调用既有认证API，不新增岗位/角色检查；模式生命周期仅决定当前响应可消费性。',['gmp-platform/frontend/src/api/record-control-workflow.ts#listPublishedRecordControlWorkflowCandidates']),
('DEC-0094-02','direct','consistent','后端按类型/PUBLISHED和当前具体版本查询，最终来源/流程/签署实时复核；候选只读不等于申请或审批授权。',[WORKFLOW+'#listPublishedCandidates/toPublishedCandidate',POLICY+'#submit']),
('DEC-0074-01','neighbor','consistent','A登录/B本人按钮签署身份边界保持，未将前端请求归属键用作业务签署身份；confirm原account/password仍传入原API。',[PAGE+'#confirm',POLICY+'#submit']),
('DEC-0074-02','neighbor','consistent','受保护admin凭证例外与业务资格不改变；新UI加载/确认逻辑未添加任何认证豁免。',[POLICY+'#submit',PAGE+'#confirm']),
('DEC-0074-03','neighbor','consistent','签署失败仍就地错误并保留当前上下文输入，不自动跳设置/推进；只有已经被用户替代的旧响应不得污染新表单。',[PAGE+'#confirm',CLIENT]),
('DEC-0085-02','neighbor','consistent','共享会话在请求发出前由原client再次检查，页面query序号不替代会话保护或服务端授权。',[CLIENT+'#request-interceptor']),
('DEC-0085-03','neighbor','consistent','原client迟到会话拒绝与本页迟到记录/模式拒绝是不同边界，不据前端取消宣称服务器撤回写入或增加自动重试。',[CLIENT+'#response-interceptor',PAGE+'#loadRecord/confirm']),
('DEC-0085-06','neighbor','consistent','实际签署人不同不等于登录变化；本轮无登录/签名策略变更，通用任务密码页面原暂停不被顺带恢复。',[PAGE+'#confirm',CLIENT]),
('DEC-0096-01','neighbor','consistent','超管在审详情只读例外与普通参与人/终态范围保持；本页响应归属不扩展详情资格。',[POLICY+'#canViewRequestDetail',PAGE+'#canViewSubmittedRequest']),
('DEC-0096-04','neighbor','consistent','可读详情不推定可审批、撤回或签署，RECORD_CONTROL_REQUEST隔离和DHR规则保持；本批未改后端这些边界。',[POLICY+'#canViewRequestDetail/submit',PAGE+'#confirm']),
('DEC-0087-09','neighbor','superseded','仅IN_REVIEW详情原无超管例外的子范围已由DEC0096-01替代；签名隔离、普通参与人及终态历史保留。不替代整决策。',['docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml#DEC-0096-01',POLICY+'#canViewRequestDetail']),
('question.multi-tenant-workflow-isolation','neighbor','needs-decision','已有非MVP问题：当前默认租户不能证明完整多租户隔离，不阻塞本轮页面工程修复，不关闭该问题或扩展跨租户权限。',['docs/knowledge/open-questions.yaml#question.multi-tenant-workflow-isolation']),
('fact.record-control-source-status','neighbor','evidence-gap','定义与submit内COMPLETED复核一致；旧采集locator含RecordControlService.lookup而当前符号为findRecord，保留历史来源，当前源码以本批绑定补充。属于既有粗locator/P1边界，无新业务冲突。',[POLICY+'#findRecord/submit','docs/knowledge/README.md#Schema驱动结构']),
('fact.record-control-active-application-present','neighbor','evidence-gap','活动申请实际来源/锁内复核可查；旧locator用lookup，当前是findRecord。仅符号级定位不精确，未改历史provenance，也不把新UI序号解释为活动申请锁。',[POLICY+'#findRecord/submit','docs/knowledge/README.md#Schema驱动结构']),
]
output=[]
for identity,scope,conclusion,reason,evidence in items:
    original=records[identity]
    output.append({'id':identity,'recordType':'decision-statement' if identity.startswith('DEC-') else identity.split('.')[0],
        'sourcePath':original['path'],'sourceLocator':identity,
        'originalMaturity':original['value'].get('status','not-declared'),
        'originalVisibility':original['value'].get('visibility','not-declared'),
        'scope':scope,'semanticReviewStatus':'reviewed','conclusion':conclusion,
        'reviewConclusion':reason,'evidence':evidence,
        'runtimeVerificationByOntology':False,
        'originalRecord':original['value']})
summary={'count':len(output),'direct':sum(r['scope']=='direct' for r in output),'neighbor':sum(r['scope']=='neighbor' for r in output),
    'conclusions':{c:sum(r['conclusion']==c for r in output) for c in sorted({r['conclusion'] for r in output})},
    'scope':'Finite statement review only; not all353 files/2848 asset IDs/old931 subset; no business policy or knowledge edits',
    'wholeFileCompleted':0,'historicalUnique':'unknown'}
(OUT/'finite-review-records.json').write_text(json.dumps({'summary':summary,'records':output},ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
