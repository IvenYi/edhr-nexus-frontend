from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import yaml

ROOT=Path('/workspace/edhr-nexus-frontend')
OUT=Path('/tmp/edhr-record-change-async-ontology-20261110')
BASE='8be9b78b41644693864a9429b5c5741d18d52edf'
CANDIDATE='7e43939b519b743e73ca993d66632b1316655fed'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=ROOT,capture_output=True,text=True)
assert fetch.returncode==0,fetch.stderr
head=git('rev-parse','HEAD').decode().strip()
target=git('rev-parse','origin/edhr-dev').decode().strip()
assert head==CANDIDATE and target==BASE,(head,target)
expected={
 'docs/development/branch-review-20261110-record-change-async/decision-package.yaml',
 'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs',
 'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx'}
assert set(git('diff','--name-only',BASE,head).decode().splitlines())==expected
nochange=['docs/knowledge','docs/architecture','AGENTS.md','codeplzreadme.md','docs/agents',
          'gmp-platform/backend','gmp-platform/frontend/src/api','gmp-platform/frontend/src/components',
          'gmp-platform/frontend/package.json','gmp-platform/frontend/package-lock.json']
assert not git('diff','--name-only',BASE,head,'--',*nochange)
baseline=json.loads((OUT/'baseline-source-inputs.json').read_text())
inputs=[]
paths=[x['path'] for x in baseline['inputs']]+list(expected-set(x['path'] for x in baseline['inputs']))
for name in sorted(paths):
 data=git('show',head+':'+name)
 assert (ROOT/name).read_bytes()==data,name
 destination=OUT/'final-source'/name
 destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
 inputs.append({'path':name,'sourceCommit':head,'bytes':len(data),'sha256':sha(data),
    'scope':'Captured input, finite named-symbol/statement review; not whole-file completion'})
dp=yaml.safe_load((ROOT/'docs/development/branch-review-20261110-record-change-async/decision-package.yaml').read_text())['decisionPackage']
assert dp['confirmed']=={'concepts':[],'relationships':[],'rules':[],'executionContracts':[]}
assert not dp['unresolved'] and not dp['replacementScopes']
assert all(x['changeType'] in ['create','update','delete','read-only'] for x in dp['affectedFiles'])
inventory=json.loads((OUT/'knowledge-inventory.json').read_text())
for row in inventory['files']:
 data=(ROOT/row['path']).read_bytes()
 assert sha(data)==row['sha256']==sha(git('show',head+':'+row['path'])),row['path']
reuse=json.loads((OUT/'knowledge-validation-reuse.json').read_text())
for row in reuse['sourceInputs']:
 data=(ROOT/row['path']).read_bytes()
 assert sha(data)==row['sha256']==sha(git('show',head+':'+row['path'])),row['path']

parent=Path('/tmp/edhr-record-change-async-20261110')
parent_copies=[]
for name in ['old-full/result.json','old-full.log','corrected/result.json','corrected.log']:
 original=parent/name
 destination=OUT/'parent-readonly'/name
 destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(original,destination)
 parent_copies.append({'path':str(destination.relative_to(OUT)),'originalPath':str(original),
  'bytes':original.stat().st_size,'sha256':sha(original.read_bytes()),'actuallyExecutedByOntology':False})
old=json.loads((parent/'old-full/result.json').read_text())
new=json.loads((parent/'corrected/result.json').read_text())
assert (old['tests'],old['passed'],old['failed'])==(26,0,26)
assert (new['tests'],new['passed'],new['failed'])==(26,26,0)
binding={
 'status':'FINAL','sourceCommit':head,'targetCommit':target,'contractReadCommit':BASE,
 'timestamp':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'fetchOutput':fetch.stdout+fetch.stderr,'contractDiff':git('diff','--name-only',BASE,head,'--','AGENTS.md','docs/agents','codeplzreadme.md').decode(),
 'changedPaths':sorted(expected),'sourceInputs':inputs,
 'knowledgeFiles':len(inventory['files']),'knowledgeYaml':inventory['yamlCount'],'knowledgeMarkdown':inventory['markdownCount'],
 'knowledgeInventorySha256':sha((OUT/'knowledge-inventory.json').read_bytes()),
 'knowledgeValidation':{'mode':'same-input reuse','actuallyExecutedByOntology':False,
  'priorActualCommit':reuse['priorActuallyTestedCommit'],'priorActualTotals':reuse['totals'],
  'unchangedCanonicalInputCount':len(reuse['sourceInputs']),'currentTreesEqualPriorActual':True,
  'noClaim':'Not rerun at candidate; schema/reference/projection only, no semantic or product runtime completion'},
 'parentRunsReadOnly':parent_copies,
 'parentRuntimeMeaning':'26 failures/26 passes are scenario-width observations, not26 independent product defects; actual maintained component + synthetic API, not real backend signature or database writes',
 'semanticCoverage':json.loads((OUT/'finite-review-records.json').read_text())['summary'],
 'knowledgeOrPolicyChanged':False,'backendApiSchemaOrSharedConfirmDialogChanged':False,
 'workingTreeAtObservation':git('status','--porcelain=v1').decode(),
 'noChildren':True,'wholeFileCompleted':0,'historicalUnique':'unknown',
 'qualityResultNotSuppliedByOntology':True,
 'performanceSignal':'Candidate current-version query per definition is source-only/unquantified; no optimization or new confirmed defect'}
write(OUT/'source-binding.json',binding)

formal={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,
   'contractReadCommit':BASE,'uncommittedContractPaths':[]},
 'reason':'本轮仅修复记录控制页面异步响应归属、加载反馈和既有草稿丢弃确认/IME边界。没有新增或替代业务概念、事实、资格、流程类型/版本、签署、审计或历史语义；既有DEC0087/0094/0096及0074/0085适用范围保持，不为前端工程选择建立重复规则或回写历史。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.current-source-binding','checkType':'evidence-path','command':'python3 finalize.py: independent fetch and29 captured current input hashes/Git comparison','outcome':'passed','evidence':['source-binding.json','final-source','baseline-source-inputs.json']},
  {'id':'validation.same-knowledge-validator-inputs','checkType':'reference','command':'Compare353 knowledge files and359 canonical knowledge/validator/POM inputs to8be/7e and prior actual0f5','outcome':'passed','evidence':['knowledge-inventory.json','knowledge-validation-reuse.json']},
  {'id':'validation.reused-knowledge-89','checkType':'schema','command':'REUSED ONLY: prior actual bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress --file tools/knowledge-model/pom.xml clean test at0f5; not rerun by this role','outcome':'passed','evidence':['reused-knowledge-0f5/knowledge/run.json','reused-knowledge-0f5/knowledge/maven.log','reused-knowledge-0f5/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','knowledge-validation-reuse.json']},
  {'id':'validation.finite-policy-review','checkType':'projection','command':'Finite19 statements:15 scoped consistent/1 precise partial historical supersession/1 existing nonblocking tenant question/2 historical coarse-locator evidence gaps','outcome':'passed','evidence':['finite-review-records.json','REVIEW.md','source-binding.json']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
}}
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(formal,allow_unicode=True,sort_keys=False))
review='''# 记录控制页面异步归属：最终本体有限核对

正式结果 **not-applicable / FINAL**。当前 clean 候选 `7e43939b519b743e73ca993d66632b1316655fed`，独立再次 fetch 的目标为 `edhr-dev@8be9b78b41644693864a9429b5c5741d18d52edf`，契约原读基线8be且与候选逐字相同。当前变化恰为 RecordChangePage、专用浏览器脚本和决策包三文件；知识、后端/API/schema、共享 ConfirmDialog、签名和权限实现均无变化。主侧DP的create枚举已核。

这是页面响应归属的工程修正：旧查询成功、错误和收尾不得替代新查询；候选依当前模式及来源生命周期消费；提交后刷新也受当前上下文约束。既有未提交拟数据确认复用应用 ConfirmDialog，取消焦点/Escape与放弃后查询保留；输入法组字Enter不查询、普通Enter的preventDefault避免keyup误触新打开弹窗的取消按钮。序号/effect清理不是新业务身份、事务锁或规则引擎。没有引入自动重试，前端忽略旧响应也不宣称撤销已收到或执行的服务端写入。

既有业务政策合理并保持：DEC0087-01/03/04要求按实例流水号定位已完成且有有效修订来源、最终来源/活动申请复核、明确选类型匹配已发布具体流程版本和真实签名。DEC0094的认证候选可读不等于申请/审批授权；DEC0096只增加在审详情超管只读例外，不能扩展业务动作。DEC0074的A登录/B本人按钮签署与DEC0085实际会话变化继续区分；原API client的请求前/响应后会话门禁未被页面序号替代。

有限语义19项=7直接/12相邻：**15范围一致、1精确历史子范围替代、1既有非阻断多租户待决、2既有粗locator证据边界**，不是19全一致。DEC0087-09仅原在审详情无超管例外的部分被0096-01替代，签名隔离/普通参与人/终态保留；不废弃整决策。两个fact说明的历史lookup符号与当前findRecord不精确，当前状态/活动申请实际含义仍与submit一致；保留11-03来源/capturedAt，当前7e/8be源码绑定补充，不回写历史制造绿色。本轮无新政策冲突或必须问用户的业务歧义，不需要修改知识定义。

353知识文件=261YAML/92MD全部与8be、当前7e及先前实际受测0f5逐字相同，盘点状态仍pending。没有重新枚举2848或把旧931子集作同一分母，也没有把whole-file完成提升：本批整文件0，历史唯一数未知。必读入口/架构/README/契约完整字节已装载捕获；人工语义只覆盖逐ID记录的声明和明确符号，捕获历史文档不等于全文件语义审计。

知识校验采用明确复用：三棵树（全部知识、tools/knowledge-model、backend知识测试）和359输入与0f5相同；从仓库PR75独立v2不可改写原件包提取其真实89/0F/0E/0S的命令、时间、日志和XML，原包SHA与每项摘要保留。**本体没有在新候选重跑89，也没有执行浏览器、数据库或产品回归**。复用只支持相同结构/引用/投影校验，不是全语义、业务或运行时知识发布通过。知识0.3.25/schema1.2.0/P0 in-progress及原成熟度保持，无新增试点或执行契约。

只读核对父侧最终相同脚本的旧源26F与修正后26P原件；26是场景×宽度观察，不是26独立缺陷。实际维护组件加延迟合成API不能证明真实后端签署、PG审计或主环境E2E，本体读取原件不算亲自执行。原始用户确认整理是user-confirmed内部来源，固定源码属original-evidence，旧报告仅secondary-reference；工程响应归属/未来性能建议是inference，未写入权威业务规范。

RecordControlWorkflowService逐定义查当前版本仅为待去重/量化的源码性能信号，未确认新性能缺陷或优化。列表资格SQL、事件DB分页未答仍不实施；朋友负责通用任务签名密码页、生产管理弹窗样式继续暂停。W2–W7、A12/高风险/完整矩阵、UI strict86/lint配置、容量/UNKNOWN及已审A23集中复查仍在原队列。NA不构成quality passed或merge许可，最终独立质量与全部FINAL后的实际PR前漂移复核由父侧承担。

本角色未改仓库文件，未访问共享DB/8081，未查询或触发CI，未merge/deploy/restore，无子实例。正式来源和全部原件清单见 source-binding.json 与 manifest.json。
'''
(OUT/'REVIEW.md').write_text(review)
members=[]
for path in sorted(OUT.rglob('*')):
 if path.is_file() and path.name!='manifest.json':
  assert not path.is_symlink(),path
  data=path.read_bytes();members.append({'path':str(path.relative_to(OUT)),'bytes':len(data),'sha256':sha(data)})
manifest={'status':'FINAL','sourceCommit':head,'targetCommit':target,
 'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':members,
 'fileCount':len(members),'children':[],'wholeFileCompleted':0,'historicalUnique':'unknown',
 'note':'All own raw files except manifest self; no repository or product mutation by ontology role'}
write(OUT/'manifest.json',manifest)
for row in members:
 data=(OUT/row['path']).read_bytes();assert sha(data)==row['sha256'] and len(data)==row['bytes']
print(json.dumps({'result':'not-applicable','sourceCommit':head,'target':target,
 'currentInputs':len(inputs),'knowledgeFiles':353,'reusedKnowledgeInputs':359,
 'finite':binding['semanticCoverage'],'manifestArtifacts':len(members),
 'workingTree':binding['workingTreeAtObservation']},ensure_ascii=False))
