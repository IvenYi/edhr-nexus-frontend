from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

ROOT=Path('/workspace/edhr-nexus-frontend')
OUT=Path('/tmp/edhr-record-change-async-ontology-20261110')
BASE='8be9b78b41644693864a9429b5c5741d18d52edf'
PRIOR='0f5d4354ed381adb07650548a2ec417969d2416d'

def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(data): return hashlib.sha256(data).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=ROOT,capture_output=True,text=True)
assert fetch.returncode==0,fetch.stderr
target=git('rev-parse','origin/edhr-dev').decode().strip()
assert target==BASE,target
knowledge=git('ls-tree','-r','--name-only',BASE,'--','docs/knowledge').decode().splitlines()
inventory=[]
for name in knowledge:
    original=git('show',BASE+':'+name)
    current=(ROOT/name).read_bytes()
    prior=git('show',PRIOR+':'+name)
    assert original==current==prior,name
    row={'path':name,'bytes':len(original),'sha256':sha(original),'status':'pending',
         'scope':'File inventory and unchanged bytes only; no automatic semantic conclusion'}
    inventory.append(row)
assert len(inventory)==353
write(OUT/'knowledge-inventory.json',{'baseCommit':BASE,'priorTestedCommit':PRIOR,
    'files':inventory,'fileCount':353,'yamlCount':sum(r['path'].endswith('.yaml') for r in inventory),
    'markdownCount':sum(r['path'].endswith('.md') for r in inventory),
    'wholeSemanticCompletion':False,'old931SubsetComparable':False})

paths=['AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md',
       'docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md',
       'docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
       'docs/knowledge/rules/record-change.yaml','docs/knowledge/facts/record-control.yaml',
       'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
       'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
       'docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml',
       'docs/knowledge/decisions/DEC-0085-shared-login-cross-tab-isolation.yaml',
       'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
       'docs/knowledge/evidence/record-control-v1-user-confirmed.md',
       'docs/knowledge/evidence/record-change-search-scope-user-confirmed.md',
       'docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md',
       'docs/knowledge/evidence/shared-login-cross-tab-2026-10-27.md',
       'docs/knowledge/evidence/record-history-detail-access-20261109.md',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java',
       'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
       'gmp-platform/frontend/src/api/record-control.ts',
       'gmp-platform/frontend/src/api/record-control-workflow.ts',
       'gmp-platform/frontend/src/api/client.ts',
       'gmp-platform/frontend/src/components/ConfirmDialog.tsx']
sources=[]
for name in paths:
    data=git('show',BASE+':'+name)
    destination=OUT/'baseline-source'/name
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
    sources.append({'path':name,'sourceCommit':BASE,'bytes':len(data),'sha256':sha(data),
        'scope':'Whole file loaded/captured; semantic review limited to named statements/symbols, not whole-file completion'})
write(OUT/'baseline-source-inputs.json',{'sourceCommit':BASE,'inputs':sources,
    'readMethod':'Complete original bytes captured, with finite manual semantic inspection and explicit named-source locators'})

tree_paths=['docs/knowledge','tools/knowledge-model','gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge']
trees=[]
for name in tree_paths:
    old=git('rev-parse',PRIOR+':'+name).decode().strip()
    new=git('rev-parse',BASE+':'+name).decode().strip()
    assert old==new,name
    trees.append({'path':name,'priorGitTree':old,'currentGitTree':new,'same':True})
oldzip=ROOT/'docs/development/branch-review-20261110-record-access-increment/evidence/independent-v2-final.zip'
reused=[]
with zipfile.ZipFile(oldzip) as z:
    for name in ['knowledge/run.json','knowledge/maven.log','knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','source-binding.json']:
        data=z.read(name);destination=OUT/'reused-knowledge-0f5'/name
        destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
        reused.append({'path':str(destination.relative_to(OUT)),'originalZipEntry':name,'bytes':len(data),'sha256':sha(data)})
    run=json.loads(z.read('knowledge/run.json'))
assert run['head']==PRIOR and run['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
testinputs=[]
for name in git('ls-tree','-r','--name-only',BASE,'--',*tree_paths).decode().splitlines():
    data=git('show',BASE+':'+name);current=(ROOT/name).read_bytes()
    assert data==current,name
    testinputs.append({'path':name,'bytes':len(data),'sha256':sha(data)})
write(OUT/'knowledge-validation-reuse.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceCommit':BASE,'priorActuallyTestedCommit':PRIOR,'actuallyExecutedByThisRole':False,
    'priorActualCommand':run['command'],'priorActualStartedAt':run['startedAt'],'priorActualFinishedAt':run['finishedAt'],
    'totals':run['totals'],'trees':trees,'sourceInputs':testinputs,'reusedArtifacts':reused,
    'originalZip':str(oldzip.relative_to(ROOT)),'originalZipSha256':sha(oldzip.read_bytes()),
    'scope':'Same canonical knowledge files, validator sources and POM; reused actual schema/reference/projection test only, not whole semantic or product runtime validation'})
write(OUT/'initial-binding.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head':git('rev-parse','HEAD').decode().strip(),'target':target,'sourceCommit':BASE,
    'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0 in-progress',
    'contractDiff':git('diff','--name-only',PRIOR,BASE,'--','AGENTS.md','codeplzreadme.md','docs/agents').decode(),
    'workingTree':git('status','--porcelain=v1').decode(),
    'fetchOutput':fetch.stdout+fetch.stderr,'children':[],
    'noRuntimeClaim':'No browser, database or product tests executed by ontology role'})
print(json.dumps({'target':target,'knowledgeFiles':len(inventory),'inputCount':len(sources),
    'knowledgeTestReuse':'89/0/0/0 from0f5,not rerun','testInputCount':len(testinputs)},ensure_ascii=False))
