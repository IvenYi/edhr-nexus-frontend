import datetime
from collections import Counter
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

ROOT=Path('/tmp/edhr-record-change-async-qa-worktree-20261110')
RAW=Path('/tmp/edhr-record-change-async-final-qa-20261110')
BASE='8be9b78b41644693864a9429b5c5741d18d52edf'
HEAD='7e43939b519b743e73ca993d66632b1316655fed'

def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,data):(RAW/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

assert git('rev-parse','HEAD').decode().strip()==HEAD
jobs=['record-ui','workflow-ui','build','list-style','fonts','lint','premium']
runs={name:json.loads((RAW/(name+'-run.json')).read_text()) for name in jobs}
inputs=runs['record-ui']['sourceFingerprints']
assert len(inputs)==27
for name,run in runs.items():
    assert run['head']==HEAD and run['sourceFingerprints']==inputs
    assert run['exitCode']==(2 if name in ['lint','premium'] else 0),(name,run)
for item in inputs:
    data=(ROOT/item['path']).read_bytes()
    assert sha(data)==item['sha256']==sha(git('show',HEAD+':'+item['path']))
    assert data==(RAW/'source'/item['path']).read_bytes()
delta=git('diff','--name-only',BASE,HEAD).decode().splitlines()
assert delta==[
 'docs/development/branch-review-20261110-record-change-async/decision-package.yaml',
 'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs',
 'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx']
assert not git('diff','--name-only',BASE,HEAD,'--','gmp-platform/backend','docs/knowledge','docs/architecture',
               'AGENTS.md','codeplzreadme.md','docs/agents',
               'gmp-platform/frontend/src/api','gmp-platform/frontend/src/components',
               'gmp-platform/frontend/src/utils','gmp-platform/frontend/package.json','gmp-platform/frontend/package-lock.json')
record=json.loads((RAW/'record-ui/result.json').read_text())
workflow=json.loads((RAW/'workflow-ui/result.json').read_text())
assert [record[k] for k in ['tests','passed','failed']]==[26,26,0]
assert [workflow[k] for k in ['tests','passed','failed']]==[58,58,0]
assert all(row['passed'] for row in record['results']+workflow['results'])
assert sum(row['writeCount'] for row in record['results'])==4
knowledge=[]
for p in RAW.glob('TEST-*.xml'):
    s=ET.parse(p).getroot()
    knowledge.append({'file':p.name,**{k:int(s.attrib[k]) for k in ['tests','failures','errors','skipped']}})
assert len(knowledge)==1 and [knowledge[0][k] for k in ['tests','failures','errors','skipped']]==[89,0,0,0]
assert json.loads((RAW/'knowledge-run.json').read_text())['exitCode']==0
current=json.loads((RAW/'premium-final.json').read_text())
baseline=json.loads((RAW/'premium-baseline.json').read_text())
keys=['file','ruleId','message','category','severity','remediation']
identity=lambda r:tuple(r[k] for k in keys)
old=Counter(identity(row) for row in baseline['findings']);new=Counter(identity(row) for row in current['findings'])
assert sum(old.values())==sum(new.values())==86 and old==new
assert current['summary']['violations']==72 and current['summary']['unresolved']==14
write('static-delta.json',{'identityKeys':keys,'lineRelocationsExcluded':True,'baselineSummary':baseline['summary'],
 'currentSummary':current['summary'],'distinctIdentities':len(new),'comparison':'Multiset equality including duplicate occurrence counts',
 'added':[],'removed':[],'wholeUiPassed':False,
 'lint':'Actually exited2: repository ESLint configuration missing; not passed'})
knowledge_files=git('ls-tree','-r','--name-only',HEAD,'--','docs/knowledge').decode().splitlines()
assert len(knowledge_files)==353
knowledge_manifest=[]
for name in knowledge_files:
    data=(ROOT/name).read_bytes()
    assert data==git('show',BASE+':'+name)==git('show',HEAD+':'+name)
    knowledge_manifest.append({'path':name,'bytes':len(data),'sha256':sha(data)})
write('knowledge-inventory.json',{'fileCount':353,'files':knowledge_manifest,'semantics':'Byte inventory only; no whole-knowledge semantic completion claim'})
extra=['docs/development/branch-review-20261110-record-change-async/decision-package.yaml',
 'docs/architecture/business-knowledge-model.md','docs/frontend/list-page-guidelines.md',
 'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
 'docs/knowledge/decisions/DEC-0085-shared-login-cross-tab-isolation.yaml',
 'gmp-platform/frontend/src/utils/sessionPolicy.ts',
 'gmp-platform/frontend/src/utils/queryClient.ts']
extra_inputs=[]
for name in extra:
    data=(ROOT/name).read_bytes();assert data==git('show',HEAD+':'+name)
    p=RAW/'additional-reviewed-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    extra_inputs.append({'path':name,'bytes':len(data),'sha256':sha(data)})
history=Path('/tmp/edhr-record-change-async-20261110')
dest=RAW/'main-history';dest.mkdir(exist_ok=True)
history_bound=[]
for name in ['old-full/result.json','baseline/result.json','corrected/result.json','initial.log',
             'focused/result.json','confirmation/result.json','confirmation-keyboard/result.json',
             'old-full/lookup-success-1440-failed.png','old-full/candidate-success-390-failed.png']:
    data=(history/name).read_bytes();p=dest/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    history_bound.append({'path':str(p.relative_to(RAW)),'original':str(history/name),'bytes':len(data),'sha256':sha(data),
                          'scope':'Parent original read/copy; not executed by independent QA'})
old_run=json.loads((dest/'old-full/result.json').read_text());assert [old_run[k] for k in ['tests','passed','failed']]==[26,0,26]
write('source-binding.json',{'baseCommit':BASE,'headCommit':HEAD,'contractReadCommit':HEAD,
 'independentlyFetchedTarget':git('rev-parse','origin/edhr-dev').decode().strip(),
 'sourceFingerprints':inputs,'extraReviewedSource':extra_inputs,'trackedDelta':delta,
 'backendApiKnowledgeContractUnchanged':True,'knowledgeFilesUnchanged':353,
 'temporaryRuntimeUntrackedPath':'gmp-platform/frontend/node_modules: own dependency symlink only',
 'mainHistoryOriginalsReadOnly':history_bound,'independentChildren':[],
 'wholeFileCompleted':0,'historicalUnique':'unknown'})
write('analysis.json',{'candidate':HEAD,'target':BASE,'sourceInputs':len(inputs),'extraReadInputs':len(extra_inputs),
 'independentBrowser':{'recordChange':26,'workflow':58,'total':84,'failed':0,'syntheticPostCount':4,
 'qualification':'Actual maintained React components+API clients with synthetic interceptedAPI; not production HTTP or real signing'},
 'independentKnowledge':knowledge,'build':'passed','listStyle':'passed','fonts':'passed',
 'strict':'exit2;86 inherited findings=72violations/14unresolved;new0/removed0','lint':'exit2:existing missing config',
 'old26':'Parent original26 failures preserved/read-only, not rerun independently; scenarios are not26 unique bugs',
 'policyReview':'DEC0087 source/explicit matching version, DEC0094 candidate read, DEC0096 read-only, DEC0074 signer identity and DEC0085 shared-session boundaries retained',
 'newBlockingFindings':[],'remaining':['W2-W7/semantic/A12/highrisk/full matrices/A23 including already reviewed',
 'Pending record list/event paging performance choices; no SQL/index change',
 'Pre-existing candidate current-error is outside Dialog and Dialog also shows no-candidates; no blanket error-a11y claim',
 'Candidate service per-definition version lookup is source signal only, not measured in this slice',
 'Real PG/current production E2E not rerun; backend unchanged'],
 'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'inputs':len(inputs),'browser84':True,'knowledge89':True,'staticDelta':0,'newBlockers':0}))
