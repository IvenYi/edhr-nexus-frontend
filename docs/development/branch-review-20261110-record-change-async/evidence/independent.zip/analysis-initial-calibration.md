# Analysis tool calibration retained

The first independent analysis command failed at its own assertion `len(old)==len(new)==86`.
The static auditor has 86 finding occurrences but only 29 distinct identities when line
positions are excluded. Both baseline and candidate have the same 86 occurrences and
29 identities. The tool was corrected to compare `Counter` multisets, preserving
duplicate occurrence counts; no product/test/expected UI assertion was changed.

The initial failure is orchestration evidence, not a failed product browser case.
Actual strict exit2 and lint exit2 remain failures for whole-project compliance.
