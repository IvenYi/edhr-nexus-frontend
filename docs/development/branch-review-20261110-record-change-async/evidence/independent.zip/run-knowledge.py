import datetime,json,os,shutil,subprocess
from pathlib import Path
r=Path('/tmp/edhr-record-change-async-qa-worktree-20261110')
o=Path('/tmp/edhr-record-change-async-final-qa-20261110')
cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','--file',str(r/'tools/knowledge-model/pom.xml'),'clean','test']
record={'command':cmd,'cwd':str(r),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r).decode().strip(),'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
env=os.environ.copy();env['MAVEN_OPTS']='-Xmx768m'
with (o/'knowledge.log').open('w') as log:
    result=subprocess.run(cmd,cwd=r,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update({'exitCode':result.returncode,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):shutil.copyfile(p,o/p.name)
(o/'knowledge-run.json').write_text(json.dumps(record,indent=2)+'\n')
print(record)
raise SystemExit(result.returncode)
