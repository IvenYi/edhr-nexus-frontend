from pathlib import Path
from zoneinfo import ZoneInfo
import collections,datetime,hashlib,json,yaml

raw=Path(__file__).parent
binding=json.loads((raw/'final-source-knowledge-binding.json').read_text())
assert binding['mainRunResult']=='passed' and binding['knowledgeTestcases']==89 and not binding['knowledgeOrContractChanged']
finite=[json.loads(l) for l in (raw/'finite-review-records.jsonl').read_text().splitlines()]
summary=json.loads((raw/'finite-review-summary.json').read_text());base=binding['target'];candidate=binding['candidate']
assert summary['finiteRecords']==8 and collections.Counter(x['conclusion'] for x in finite)=={'consistent':5,'evidence-gap':1,'needs-decision':2}
main=raw/'read-evidence/final-main';node=json.loads((main/'node-summary.json').read_text())
assert node['pass']==node['tests'] and node['fail']==node['skipped']==node['cancelled']==0
browser=[]
for path in sorted(main.glob('*/result.json')):
    d=json.loads(path.read_text());results=d.get('results',[]);assert results and all(x.get('outcome',x.get('status'))=='passed' for x in results)
    browser.append({'group':path.parent.name,'executions':len(results)})
java=json.loads((main/'java-summary.json').read_text());assert all(x['failures']==x['errors']==x['skipped']==0 for x in java)
runtime={'source':'Main actually executed results,read and bound by ontology only','node':node,'browser':browser,'java':java,'ownRuntimeExecuted':False}
(raw/'runtime-evidence-inspection.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n')
sync=[{'id':r['id'],'disposition':r['disposition'],'scope':r['conclusionDetail'],'sourceReferences':r['evidenceReferences']} for r in finite if r['recordType']!='selectedMarkdownExplanation']
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
    'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':binding['contractReadCommit'],'uncommittedContractPaths':[]},
    'reason':'本轮仅补读ExcelJS已经提供为像素的单锚点图片ext，使新导入图片不再误用缺失br的24x24回退。原双锚点差值、最小24像素、媒体身份/内容、布局坐标、原配置保存撤销及使用时快照不改；无新业务概念、数量政策、格式协议、生命周期、权限、签署、审计、历史迁移或知识发布。353知识文件和2849资产ID与目标及候选逐字节/按schema清单保持，无必要新增同义业务规则。',
    'changedArtifacts':[],'knowledgeSync':sync,'conflicts':[],'questions':[],
    'validationEvidence':[
        {'id':'validation.w2-import-finite-records','checkType':'reference','command':'python3 build-finite-records.py','outcome':'passed','evidence':['finite-review-records.jsonl','finite-review-summary.json','knowledge-file-inventory.jsonl','knowledge-id-inventory.jsonl','有限8条=6个既有ID和2个选定说明，5consistent/1原evidence-gap/2原needs-decision；机械353文件/2849唯一schema资产保持pending，不把目录或原成熟度当语义通过。']},
        {'id':'validation.w2-import-source-and-knowledge-preserved','checkType':'status-transition','command':f'python3 bind-final-inputs.py {candidate} <main-final-run.json>','outcome':'passed','evidence':['baseline-inputs.json','final-source-knowledge-binding.json','read-evidence/import-excel-candidate.diff','知识0.3.25/schema1.2.0/P0 in-progress和全部成熟度及投影保持；契约与知识相对目标无差异；range.ext像素单位依据已锁定ExcelJS源码，不定义新业务规则。']},
        {'id':'validation.w2-import-main-knowledge-89','checkType':'schema','command':'主侧实际Java命令见final-source-knowledge-binding.json.mainJavaCommand；本体仅核对原件','outcome':'passed','evidence':['read-evidence/final-main/java-summary.json','read-evidence/final-main/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','read-evidence/final-main/knowledge-inputs-before.json','read-evidence/final-main/knowledge-inputs.json','实际XML89个testcase且0失败/错误/skip；原XML时间在主侧本轮Java步骤内，前后知识/测试输入和候选一致。']},
        {'id':'validation.w2-import-main-runtime-binding','checkType':'evidence-path','command':'python3 bind-final-inputs.py；读取主侧实际运行输出，不执行浏览器或业务测试','outcome':'passed','evidence':['runtime-evidence-inspection.json','final-source-knowledge-binding.json','read-evidence/main-probe/initial-image-probe.json','read-evidence/installed-exceljs/lib/xlsx/xform/drawing/ext-xform.js','主侧当前测试、浏览器和构建证据按实际来源记录，不由本体阅读升级为独立质量或完整HTTP/PG/Office容量认证。']}
    ],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(raw/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=120))
node_n=node['pass'];browser_n=sum(x['executions'] for x in browser)
text=f'''# W2 Excel 图片尺寸适配本体核对

正式结果：not-applicable / FINAL。受测候选 `{candidate}`，目标 `{base}`。实际读取契约采用目标基线；最终逐字节核对契约、知识与候选一致。知识保持0.3.25/schema1.2.0，P0 in-progress，无成熟度或发布投影变化。

本轮是格式适配缺陷修复：合法oneCellAnchor只有tl和ext，ExcelJS已将ext从EMU转换为px。旧导入只计算br与tl差值，使180×72误成24×24。补读ext不是新增图片尺寸业务政策；既有双锚点、最小24、媒体身份和存储路径保持。原图probe由主侧实际执行，本体仅读取原件和依赖源码核对；没有声称本体重新运行浏览器、Node、Java、数据库或CI，也没有声称手动视觉检查。

DEC-0077-12使用时冻结/不回写历史，22同一配置保存撤销归属，30草稿免业务完整性但保留格式/权限/证据安全均保留。原确认中的DEC-0075编号依2026-10-15集成映射到现DEC-0077，历史原话不改写。当前代码仅更新Excel适配层，不修改服务API/执行/实例/DHR、签署、权限或审计，也不创建新数据迁移。

有限8记录=6个既有ID和2段选定说明；5consistent、1保留evidence-gap、2保留needs-decision。原通用质量/异常/源签署有效性变化high、A12历史视图和非MVP完整多租户未决保留，不依赖本图片切片，不需要为本轮重问用户。没有新增历史unique覆盖，不声称全库语义通过。353文件、2849唯一schema资产仅机械盘点，清单全部pending，和有限语义记录分开。

已核对主侧正式证据：Node{node_n}、浏览器{browser_n}次执行，以及Java各组`{json.dumps(java,ensure_ascii=False)}`。知识XML实际89个testcase及源时间/摘要和前后输入已核验。来源指纹数{len(binding['sourceInputs'])}、知识/知识测试输入{binding['knowledgeInputs']}与候选/当前相同。测试读取是证据核对，不替代未参与修复的独立QA。

300行/75列clamp与24像素最小值只作为既有工程行为保留，不写成用户业务上限；物料/作业数据导入中的MAX_IMPORT_ROWS属于另一个入口，不机械外推。PERF-DESIGNER-OFFICE-EXPANSION-001沿原条目，Word重复表解析及全Office载入容量仍须量化讨论，不由局部适配修复默认授权优化或证明生产SLA。完整W2/W3–W7、全知识语义、A23已审补查及原用户暂停保持。

没有知识文件更新，changedArtifacts为空；当前切片无conflicts/questions，不新增试点、运行知识引擎或P1–P3阶段完成结论。原件清单、源快照、有限逐条记录和正式结果由manifest及SHA256SUMS封存。
'''
(raw/'review.md').write_text(text)
def sha(b):return hashlib.sha256(b).hexdigest()
files=[]
for p in sorted(raw.rglob('*')):
    if p.is_file() and p.name not in ('manifest.json','SHA256SUMS'):
        b=p.read_bytes();files.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
(raw/'manifest.json').write_text(json.dumps({'sealedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'candidate':candidate,'target':base,'result':'not-applicable','files':files},ensure_ascii=False,indent=2)+'\n')
checks=files+[{'path':'manifest.json','sha256':sha((raw/'manifest.json').read_bytes())}]
(raw/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in checks))
for x in files:
    b=(raw/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
for line in (raw/'SHA256SUMS').read_text().splitlines():
    digest,path=line.split('  ',1);assert sha((raw/path).read_bytes())==digest
print(json.dumps({'result':'not-applicable','candidate':candidate,'manifestFiles':len(files),'manifestSha256':sha((raw/'manifest.json').read_bytes()),'sha256SumsSha256':sha((raw/'SHA256SUMS').read_bytes())},ensure_ascii=False))
