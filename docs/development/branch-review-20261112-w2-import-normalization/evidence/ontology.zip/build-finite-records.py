from pathlib import Path
from zoneinfo import ZoneInfo
import collections,datetime,hashlib,json,shutil,subprocess,yaml

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='8a415040babc1cc91ca9f5683bf0db46829eea76'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
raw.mkdir(parents=True,exist_ok=True)
schema=yaml.safe_load((root/'docs/knowledge/schema.yaml').read_text());records=[];file_rows=[];by_id={}
for p in sorted((root/'docs/knowledge').rglob('*')):
    if not p.is_file():continue
    name=str(p.relative_to(root));b=p.read_bytes()
    assert b==subprocess.check_output(['git','show',base+':'+name],cwd=root)
    file_rows.append({'path':name,'bytes':len(b),'sha256':sha(b),'scope':'inventory-only','semanticReview':'pending','conclusion':'pending'})
    if p.suffix not in ('.yaml','.yml'):continue
    d=yaml.safe_load(b)
    if not isinstance(d,dict):continue
    def add(r,t,loc):
        item={'id':r['id'],'recordType':t,'sourcePath':name,'sourceLocator':loc,'originalStatus':r.get('status'),'originalVisibility':r.get('visibility'),'scope':'inventory-only','semanticReview':'pending','conclusion':'pending'}
        records.append(item);by_id[r['id']]=(item,r)
    for coll,kind in schema['collectionTypes'].items():
        for i,r in enumerate(d.get(coll,[]) or []):
            if not isinstance(r,dict) or not isinstance(r.get('id'),str):continue
            add(r,kind,f'/{coll}/{i}')
            for nested,nkind in schema['nestedCollectionTypes'].items():
                for j,rr in enumerate(r.get(nested,[]) or []):
                    if isinstance(rr,dict) and isinstance(rr.get('id'),str):add(rr,nkind,f'/{coll}/{i}/{nested}/{j}')
assert len(file_rows)==353 and len(records)==2849 and len(by_id)==2849
for name,data in [('knowledge-file-inventory.jsonl',file_rows),('knowledge-id-inventory.jsonl',records)]:
    (raw/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data))
baseline={'observedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'sourceCommitAtRead':git('rev-parse','HEAD'),'targetCommit':base,'actualRemoteTarget':git('ls-remote','origin','refs/heads/edhr-dev').split()[0],'contractReadCommit':base,'uncommittedContractPaths':[],
    'contractAndKnowledgeDeltaFromTarget':git('diff','--name-status',base,'HEAD','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge'),
    'knowledgeModelVersion':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion'],'knowledgeFiles':len(file_rows),'schemaSelectedAssetIds':len(records),'uniqueIds':len(by_id),
    'byRecordType':dict(collections.Counter(x['recordType'] for x in records)),'qualification':'Schema top/nested collections only;all mechanical inventory pending;finite semantic records are separate,not whole-catalog certification or historical unique coverage.'}
assert baseline['actualRemoteTarget']==base and baseline['contractAndKnowledgeDeltaFromTarget']==''
(raw/'baseline-inputs.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n')
front='gmp-platform/frontend/src/pages/master-data/template-designer-react/'
sources=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml','docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md','docs/development/branch-review-20261028-designer-import/findings.md',front+'utils/importExcel.ts',front+'utils/importGrid.ts',front+'utils/document.ts',front+'types/canvas.ts',front+'store/useTemplateDesignerStore.ts',front+'TemplateDesignerReactShell.tsx','gmp-platform/frontend/package-lock.json']
source_rows=[]
for name in sources:
    b=subprocess.check_output(['git','show',base+':'+name],cwd=root);dest=raw/'read-evidence/target-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
    source_rows.append({'path':name,'sha256':sha(b),'readCommit':base})
for name in ['lib/doc/image.js','lib/xlsx/xform/drawing/ext-xform.js','lib/xlsx/xform/drawing/one-cell-anchor-xform.js','package.json']:
    src=root/'gmp-platform/frontend/node_modules/exceljs'/name;b=src.read_bytes();dest=raw/'read-evidence/installed-exceljs'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
    source_rows.append({'path':'installed-exceljs/'+name,'sha256':sha(b),'readCommit':'installed dependency;version pinned in target package-lock'})
(raw/'source-inputs.json').write_text(json.dumps(source_rows,ensure_ascii=False,indent=2)+'\n')
for name in ['initial-image-probe.json','one-cell-180x72.xlsx']:
    src=Path('/tmp/edhr-w2-import-normalization-20261112')/name;dest=raw/'read-evidence/main-probe'/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
main_probe=json.loads((raw/'read-evidence/main-probe/initial-image-probe.json').read_text());assert main_probe['source'][0]['range']['ext']=={'width':180,'height':72} and main_probe['imported'][0]['layout']['width']==main_probe['imported'][0]['layout']['height']==24
checks=[
 ('DEC-0077-12','consistent','retained','仅新导入格式适配，模板仍按原编辑规则，新使用冻结、旧实例/执行/DHR不回写；未创造发布或图片快照新状态。',[front+'utils/importExcel.ts','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md#同切片纠正使用时冻结来源配置']),
 ('DEC-0077-22','consistent','retained','沿原CanvasPage/store/序列化和同一配置的保存/撤销；不创建第二套图片存储或历史，也不把导入自动保存。',[front+'store/useTemplateDesignerStore.ts#replaceCurrentPageFromImport',front+'utils/document.ts#serializeTemplateDesignerDocument']),
 ('DEC-0077-30','consistent','retained','读标准ext不新增字段完整性或投影业务门禁；不收紧正常草稿，来源权限/格式/证据和签署安全边界保持。',[front+'utils/importExcel.ts','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md#2026-10-10-第三轮注释草稿缺上下文可空批号单位与保存后追溯']),
 ('discrepancy.dhr-review-complete-evidence-impact-gap','evidence-gap','deferred','原通用质量/异常/源签署有效性自动变化比较high保持open；图片几何适配与其无依赖，未将本轮原件当作关闭依据。',['docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml']),
 ('question.form-projection-trace-index-effective-scope','needs-decision','deferred','原A12失效/修订历史视图未决保持；本轮不迁移旧图或实现历史视图，不重问已确认当前过程检索。',['docs/knowledge/open-questions.yaml']),
 ('question.multi-tenant-workflow-isolation','needs-decision','deferred','原非MVP完整租户隔离未决保持；前端图片解析不构成后台权限或多租户隔离验收。',['docs/knowledge/open-questions.yaml']),
]
finite=[]
for ident,conclusion,disposition,meaning,refs in checks:
    item,record=by_id[ident]
    finite.append({**item,'scope':'finite-current-slice','semanticReview':'reviewed','conclusion':conclusion,'disposition':disposition,'conclusionDetail':meaning,'originalRecord':record,'checkedDecisionIds':['DEC-0077-12','DEC-0077-22','DEC-0077-30'],'evidenceReferences':refs,'knowledgeChangeRequired':False})
mds=[
 ('selection.business-knowledge-model.current-boundaries','docs/architecture/business-knowledge-model.md','当前0.3.25/schema1.2.0以及使用时冻结/历史与共享配置说明','原模型不把Excel 300行/75列或图片min24设为业务政策。本轮技术修复无新术语/生命周期，不能据此提升P0、原asset成熟度或全库语义。'),
 ('selection.office-import.previous-review','docs/development/branch-review-20261028-designer-import/findings.md','性能与大模块方案','作为历史审查索引；已回源码核对importGrid工程clamp和Office库全量载入，旧PERF-DESIGNER-OFFICE-EXPANSION-001保持未优化/待讨论。不把其源码风险改写成已证实OOM或生产性能故障。'),
]
for ident,path,loc,meaning in mds:
    finite.append({'id':ident,'recordType':'selectedMarkdownExplanation','sourcePath':path,'sourceLocator':loc,'originalStatus':None,'originalVisibility':None,'scope':'finite-current-slice','semanticReview':'reviewed','conclusion':'consistent','disposition':'retained','conclusionDetail':meaning,'checkedDecisionIds':['DEC-0077-12','DEC-0077-22','DEC-0077-30'],'evidenceReferences':[path,front+'utils/importGrid.ts',front+'utils/importExcel.ts'],'knowledgeChangeRequired':False})
(raw/'finite-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in finite))
summary={'targetCommit':base,'finiteRecords':len(finite),'selectedAssetIds':len(checks),'selectedMarkdownExplanations':len(mds),'conclusions':dict(collections.Counter(x['conclusion'] for x in finite)),'knowledgeChangeRequired':False,'historicalUniqueCoverageAdded':False,'wholeKnowledgeSemanticAuditCompleted':False,'pendingInventorySeparate':True}
(raw/'finite-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'baseline':baseline,'finite':summary},ensure_ascii=False))
