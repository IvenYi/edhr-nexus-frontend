from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,re,shutil,subprocess,xml.etree.ElementTree as ET,yaml

root=Path('/tmp/edhr-import-normalization-qa-20261112');raw=Path(__file__).parent;final=raw/'final'
head='38aae69e345ca1505873bb47c7456e02ec4783ff';base='8a415040babc1cc91ca9f5683bf0db46829eea76'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
run=json.loads((final/'run.json').read_text());assert run['head']==head and run['result']=='passed' and run['target']==base
assert git('rev-parse','HEAD')==head
for item in run['sourceFingerprints']:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256'] and b==(final/'source'/item['path']).read_bytes()
    assert b==subprocess.check_output(['git','show',head+':'+item['path']],cwd=root)
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for item in after:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',head+':'+item['path']],cwd=root)
assert len(run['sourceFingerprints'])==48 and len(after)==359
node=json.loads((final/'node-summary.json').read_text());assert node==dict(tests=101,**{'pass':101,'fail':0,'skipped':0,'cancelled':0})
browser=[]
for width in [1440,390]:
    for group,count in [('images',4),('document',8),('save',13),('import',15)]:
        d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count
        assert all(x.get('outcome',x.get('status'))=='passed' for x in d['results'])
        browser.append({'group':group,'width':width,'passed':count,'failed':0})
(raw/'browser-summary.json').write_text(json.dumps(browser,indent=2)+'\n')
java=json.loads((final/'java-summary.json').read_text());assert [j['tests'] for j in java]==[41,89]
javaStep=next(x for x in run['steps'] if x['name']=='java');xml=[]
for label,count in [('template.controller.TemplateModelingControllerTest',41),('knowledge.BusinessKnowledgeModelTest',89)]:
    p=final/('TEST-com.zencas.edhr.'+label+'.xml');suite=ET.parse(p).getroot();assert len(suite.findall('testcase'))==count
    assert int(suite.attrib['failures'])==int(suite.attrib['errors'])==int(suite.attrib['skipped'])==0
    xml.append({'path':p.name,'testcases':count,'sha256':sha(p.read_bytes()),'step':javaStep})
(raw/'inputs-verified.json').write_text(json.dumps({'candidate':head,'base':base,'sourceInputs':48,'knowledgeInputs':359,'sourceCurrentSnapshotAndGitEqual':True,'knowledgeBeforeAfterCurrentGitEqual':True,'freshJavaXml':xml,'functionalExecutions':222,'knowledgeExecutionsSeparate':89,'node':node,'browserExecutions':80,'java':java},indent=2)+'\n')
visual={'inspectedBy':'this independent QA instance','screenshots':['final/images-1440/one-cell.png','final/images-390/one-cell.png','final/images-390/saved-reopen-reopened.png'],'observations':['Actual source image loaded with correct frame geometry','390 initial image reachable after existing sidebar-close and horizontal scroll','Saved reopen resets sidebar to default;only restored data asserted after reopen,not full narrow layout certification'],'noUiTokenOrLayoutChanges':True}
(raw/'visual-review.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2)+'\n')
readpaths=['docs/architecture/business-knowledge-model.md','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md','docs/development/branch-review-20261028-designer-import/findings.md']
for name in readpaths:
    b=(root/name).read_bytes();assert b==subprocess.check_output(['git','show',head+':'+name],cwd=root)
    p=raw/'read-source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
link=root/'gmp-platform/frontend/node_modules';assert link.is_symlink() and link.resolve()==Path('/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules')
link.unlink();assert not git('status','--porcelain=v1')
clean={'observedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'head':git('rev-parse','HEAD'),'status':git('status','--porcelain=v1'),'temporaryDependencyLinkRemoved':True,'duringExecutionUntrackedExcluded':['gmp-platform/frontend/node_modules'],'productOrTestEditsByQa':[]}
(raw/'final-working-tree.json').write_text(json.dumps(clean,ensure_ascii=False,indent=2)+'\n')
o=yaml.safe_load((raw/'ontology-final/ontology-result.yaml').read_text())['ontologyResult'];assert o['result']=='not-applicable'
checks=[]
def check(id,category,description,method,evidence,command='',required=True,outcome='passed'):
    checks.append(dict(id='quality.'+id,required=required,category=category,description=description,method=method,command=command,outcome=outcome,evidence=evidence))
check('baseline-scope','requirements','独立核对base/head/当前远端及四文件切片，无后台/政策/依赖/知识扩展','inspection',['baseline.json','scope-verification.json','target-remote-check.json'])
check('ontology','ontology','有限现行规则与本体NA正式结果相符，原未决/全审计范围保持','inspection',['source-review.md','ontology-final/ontology-result.yaml','ontology-final-inspection.json'])
check('old-counterexamples','regression','复核主侧同最终脚本旧实现真尺寸反例，非本人重跑；原夹具错误不计产品红','inspection',['negative-evidence-inspection.json','main-negative-evidence/commands.json','main-negative-evidence/node.log','main-negative-evidence/browser-1440/result.json','main-negative-evidence/browser-390/result.json'])
check('image-node','unit','新10项真实Excel写出/重读/布局/媒体摘要/双锚点/min24/store历史及保存重读','automated-test',['final/node.log','final/node-summary.json'],'node --test --test-reporter=tap scripts/test-designer-excel-images.mjs (included in actual101 run)')
check('adjacent-node','regression','原91项设计读取/保存状态/子列/共享选项和两类预览回归','automated-test',['final/node.log','final/node-summary.json'],'actual101 node command in final/run.json')
check('guards','regression','原设计器/列表样式/外部字体检查真实通过，原断言未动','command',['final/verify-template-designer-react.log','final/verify-list-table-style-contract.log','final/verify-no-external-fonts.log','scope-verification.json'],'node scripts/verify-template-designer-react.mjs;node scripts/verify-list-table-style-contract.mjs;node scripts/verify-no-external-fonts.mjs')
check('build','integration','npm构建含tsc -b和Vite实际通过','command',['final/build.log','final/run.json'],'npm run build')
check('images-browser','e2e','真实Shell/Canvas和xlsx两宽8项，CSS尺寸/已加载图片、撤销重做/保存重开及身份保持','browser',['final/images-1440/result.json','final/images-390/result.json'],'node scripts/test-designer-excel-images-browser.mjs (1440 and390)')
check('document-browser','regression','原持久源读取失败保护两宽16项保持','browser',['final/document-1440/result.json','final/document-390/result.json'],'node scripts/test-designer-document-read-browser.mjs (1440 and390)')
check('save-browser','regression','原保存上下文两宽26项保持','browser',['final/save-1440/result.json','final/save-390/result.json'],'node scripts/test-designer-save-context-browser.mjs (1440 and390)')
check('import-browser','regression','原Excel/Word及过期导入两宽30项保持','browser',['final/import-1440/result.json','final/import-390/result.json'],'node scripts/test-designer-import-browser.mjs (1440 and390)')
check('controller','api','原mock/directController41项实际重跑，新鲜XML，不冒称HTTP/PG','automated-test',['final/java.log','final/java-summary.json','final/TEST-com.zencas.edhr.template.controller.TemplateModelingControllerTest.xml'],'bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress -f gmp-platform/backend/pom.xml -Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest test')
check('knowledge','ontology','知识89项独立实际重跑，359输入前后及Git相同，非全部语义通过','automated-test',['final/java-summary.json','final/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','inputs-verified.json'],'same actual Java command;BusinessKnowledgeModelTest=89')
check('visual','visual','本人实际看两屏图和窄屏重开，明确原画布/侧栏空间限制','inspection',['visual-review.json','final/images-1440/one-cell.png','final/images-390/one-cell.png','final/images-390/saved-reopen-reopened.png'])
check('robustness-a23','security','最小原适配器修复，无新防御框架/政策/SQL/跨请求缓存或页面重复原语','inspection',['source-review.md','anti-pattern-scan.json','dependency-source.json'])
check('premium-increment','regression','精确官方脚本两scope基线/当前完整finding多重集相同，仅忽略行号，无新增','command',['premium-commands.json','premium-comparison.json'],'python3 audit_project.py <baseline/current repo/frontend> --mode strict --output <recorded>')
check('inputs-cleanup','documentation','48源码及359知识输入对照当前/原件/Git，依赖临时软链排除且最终清理worktreeclean','inspection',['inputs-verified.json','final-working-tree.json','baseline.json','final/run.json'])
check('premium-whole','visual','strict仓库86/前端28原债务未关闭，包含关系不相加','command',['premium-comparison.json'],'recorded official strict commands',required=False,outcome='blocked')
check('eslint','regression','基线/候选均因既有ESLint缺配置exit2，未计通过','command',['lint-commands.json','baseline-lint.log','candidate-lint.log'],'recorded installed ESLint command',required=False,outcome='blocked')
risks=[
    ('controlled-not-full-e2e','浏览器真实组件使用受控API/保存回调，Controller为mock/direct','不能认证真实HTTP权限、PG事务或生产端到端','后续按对应链补真实集成；本批后台和DB未改'),
    ('existing-static-debt','strict86/28及lint缺配置仍保留','不宣称全仓静态合规或lint通过','本批完整finding多重集无新增，原债务续审不降低标准'),
    ('narrow-layout','390通过关闭原侧栏及滚动可看图片；保存重开恢复默认侧栏','不是完整响应式/无障碍/全UI矩阵认证','原组件布局字节保持；后续UI专项继续'),
    ('format-scope','非所有Office格式/叶子语义/历史/打印PDF验证；xlsm只测试同OOXML扩展路由','不证明旧xls/doc、宏、全部锚点和图片变换完整保留','继续W2余项，历史问题/容量单列'),
    ('capacity-pending','Office容量及主侧Word重复解析仅另行取证，未在本实例测量或优化','不能推定生产内存/CPU/最大文件SLA','保留用户先量化讨论要求和原PERF-DESIGNER-OFFICE-EXPANSION-001'),
    ('overall-incomplete','完整W2/W3—W7/A23已审补查、全知识语义及原high/A12等仍未完成','311用例执行不等于整体审计百分比','继续有限源码/语义/测试台账，新提交按基线增量审查')]
quality={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':head,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[dict(id='risk.'+i,description=d,impact=p,mitigation=m) for i,d,p,m in risks],'blockingConditions':[]}}
q=quality['qualityResult'];assert sum(c['required'] for c in checks)==17 and all(c['outcome']=='passed' for c in checks if c['required'])
(raw/'quality-result.yaml').write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False,width=120))
review=f'''# 独立质量验收

正式结论：passed / FINAL。受测候选 `{head}`，base/最新核对目标 `{base}`。本实例未参与产品或测试修复、未派生子角色；独立隔离worktree实际执行。

实际 **222项功能执行 + 89项知识检查**：Node101，浏览器80（每宽新图片4/读取8/保存13/导入15），mock/directController41，另知识89；零失败/错误/跳过。构建含tsc和原3guard真实通过。17必需检查通过，无findings/blocking。全部新鲜日志、XML、输入和截图在final目录。

独立核对48受保护输入及359知识/知识测试输入前后、当前、候选Git和原件一致；XML实际41/89个testcase。执行时仅临时依赖软链未跟踪并明确排除，结束已移除，最终worktreeclean；没有产品/测试/DP修改。

仅importExcel产品5+/4−补读range.ext像素尺寸；保持双锚点、min24、坐标/媒体和既有渲染/撤销/保存。源码、依赖单位、规则和测试内容详见source-review.md。知识0.3.25/schema1.2.0/P0不变；本体NA FINAL的原manifest与摘要已自行验证，8条有限核对不等于全库语义通过。

旧实现反例是本人复核主侧最终原件（非本人重跑）：Node4P6F，每宽1P3F，真实24x24错误而非夹具失败。早期错误不计产品红；旧浏览器失败后不再执行保存，当前保存重开实际执行通过。

官方精确SHA脚本四组实跑，基线/候选仓库86及frontend28完整finding多重集相同，仅忽略行号，新增0；strict仍exit2。ESLint两侧缺配置exit2不记通过。

本人查看两宽图片及窄屏重开截图，原图片加载、几何正确；390通过原侧栏关闭/滚动可达，重开侧栏恢复默认是原空间限制，未宣称整个设计器响应式或所有UI已认证。受控API组件、回调与mockController不是HTTP/PG完整E2E；xlsm用例非宏认证，未认证所有格式、历史、打印PDF或生产容量。原W2余项、W3—W7、A23含已审、全知识语义及原high/A12等继续。

本片建议主审实际执行全部角色FINAL后的PR前漂移门禁，再交付人工合并；不据本次结果自动merge/deploy或查询触发CI。
'''
(raw/'review.md').write_text(review)
manifest=[]
for p in sorted(raw.rglob('*')):
    if p.is_file() and p.name not in ['manifest.json','SHA256SUMS']:
        b=p.read_bytes();manifest.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
# Nested ontology manifest is evidence and must remain covered.
for p in [raw/'ontology-final/manifest.json',raw/'ontology-final/SHA256SUMS']:
    if p.is_file():
        b=p.read_bytes();manifest.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
manifest.sort(key=lambda x:x['path']);assert len({x['path'] for x in manifest})==len(manifest)
(raw/'manifest.json').write_text(json.dumps({'sealedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'candidate':head,'base':base,'files':manifest},ensure_ascii=False,indent=2)+'\n')
(raw/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in manifest)+sha((raw/'manifest.json').read_bytes())+'  manifest.json\n')
for x in manifest:assert len((raw/x['path']).read_bytes())==x['bytes'] and sha((raw/x['path']).read_bytes())==x['sha256']
print(json.dumps({'result':q['result'],'candidate':head,'requiredChecks':17,'functional':222,'knowledge':89,'manifestFiles':len(manifest),'manifestSha256':sha((raw/'manifest.json').read_bytes()),'sumsSha256':sha((raw/'SHA256SUMS').read_bytes()),'worktreeClean':True}))
