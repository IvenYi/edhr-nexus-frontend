from pathlib import Path
import datetime,hashlib,json,re,statistics,subprocess
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;final=raw/'final'
candidate='38aae69e345ca1505873bb47c7456e02ec4783ff';base='8a415040babc1cc91ca9f5683bf0db46829eea76'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((final/'run.json').read_text());assert run['result']=='passed' and run['head']==candidate and not run['workingTreeState']
for item in run['sourceFingerprints']:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']==sha((final/'source'/item['path']).read_bytes())
    assert b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for item in after:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
node=json.loads((final/'node-summary.json').read_text());assert node['pass']==101 and not node['fail'] and not node['skipped']
browsers=[]
for width in [1440,390]:
    for group,count in [('images',4),('document',8),('save',13),('import',15)]:
        d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count and all(x.get('outcome',x.get('status'))=='passed' for x in d['results'])
        browsers.append({'group':group,'width':width,'passed':count,'failed':0})
java=json.loads((final/'java-summary.json').read_text());assert [x['tests'] for x in java]==[41,89]
negative=json.loads((raw/'negative/commands.json').read_text());assert negative['result']=='expected-counterexamples-confirmed' and negative['node']['pass']==4 and negative['node']['fail']==6
for name,digest in negative['scriptSha256'].items():assert sha((root/'gmp-platform/frontend/scripts'/name).read_bytes())==digest
for width in [1440,390]:
    d=json.loads((raw/('negative/browser-'+str(width))/'result.json').read_text());assert len(d['results'])==4 and sum(x['outcome']=='passed' for x in d['results'])==1
    assert all(not x['errors'] for x in d['results'])
premium=json.loads((raw/'exact-premium-summary.json').read_text());assert all(x['fullMultisetEqualIgnoringOnlyLine'] for x in premium)
dependencies=json.loads((raw/'dependency-inputs.json').read_text())
for item in dependencies['inputs']:assert sha((root/'gmp-platform/frontend'/item['path']).read_bytes())==item['sha256']
probe=json.loads((raw/'word-capacity/result.json').read_text());perf=[]
for rows,images in [(30,0),(300,0),(300,1),(300,10),(300,50)]:
    samples=[x for x in probe['samples'] if x['rowCount']==rows and x['imageCount']==images];assert len(samples)==3 and all(x['tableParseCalls']==images+2 and x['outputImages']==images and x['outputTableCells']==rows*2 for x in samples)
    perf.append({'rows':rows,'images':images,'tableParseCalls':samples[0]['tableParseCalls'],'compressedBytes':samples[0]['compressedBytes'],'documentXmlBytes':samples[0]['documentXmlBytes'],'durationMs':[x['durationMs'] for x in samples],'medianMs':statistics.median(x['durationMs'] for x in samples)})
result={'analysedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':candidate,'target':base,'result':'passed','protectedSourceInputs':len(run['sourceFingerprints']),'protectedSourceCurrentGitAndSnapshotEqual':True,'knowledgeInputs':len(after),'knowledgeBeforeAfterCurrentGitEqual':True,'node':node,'browserExecutions':browsers,'java':java,'functionalExecutions':222,'knowledgeChecksSeparate':89,
 'negativeSameFinalScripts':{'node':negative['node'],'browserEachWidth':{'passed':1,'failed':3,'pageErrors':0},'scriptSha256':negative['scriptSha256'],'selectedProductCommit':base,'scope':'Only new scripts against old exact importExcel module;not all old suites'},
 'findings':[{'id':'W2-IMPORT-EXCEL-IMAGE-EXTENT-001','severity':'medium','resolutionStatus':'resolved','commit':candidate,'evidence':['initial-image-probe.json','negative/','final/images-1440/result.json','final/images-390/result.json'],'scope':'One-cell explicit pixel dimensions,existing minimum and double-anchor coordinates retained'}],
 'performanceEvidence':[{'id':'PERF-W2-WORD-TABLE-REPARSE-001','parentId':'PERF-DESIGNER-OFFICE-EXPANSION-001','status':'pending-discussion','productChanged':False,'samples':perf,'limits':'Synthetic XML package accepted by actual JSZip/Word parser;entry-count observer only;not production SLA,full Office conformance,UI latency or heap peak. Sample counts are not limits.'}],
 'premium':premium,'officialScriptSha256':sha((raw/'skill/audit_project.py').read_bytes()),'lint':{'baselineExit':2,'candidateExit':2,'reason':'Existing missing configuration;not passed'},
 'processEvidence':{'initialNode':'3 passed/7 failed includes five genuine extent assertion failures,one wrong test store method TypeError and one random-byte fixture accepted as text by XLSX. Not seven product failures. Correct original store methods and actual truncated PK ZIP in final tests;no product policy changed.','oldNodeBeforeFix':'Exploratory only;formal negative binds immutable selected base and exact final scripts.','firstStaticMaterialization':'One extra trailing newline;preserved under static-initial;exact native script rerun separately.'},
 'visualInspected':['final/images-390/one-cell.png','final/images-1440/shared-media.png'],'limits':['Actual component/controlledGETAPI and callbacks not real HTTP/PG/database E2E','Controller41 uses existing mock/direct suite','xlsm extension case does not certify real macros or legacy XLS/DOC','Original300row/75col engineeringclamp and min24 retained,not new user businesspolicy','No all-format,all-style,wholeW2/W3-W7/A23/allknowledge/productioncapacity certification','Strict86/28 debt,missinglintconfig and narrowcanvas/reopenedsidebar existing layout limitations remain']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['testedCandidate','result','protectedSourceInputs','knowledgeInputs','functionalExecutions','knowledgeChecksSeparate']}))
