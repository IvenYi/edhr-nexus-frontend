from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,xml.etree.ElementTree as ET
root=Path(os.environ.get('EDHR_CANDIDATE_ROOT','/workspace/edhr-nexus-frontend'))
raw=Path(os.environ.get('EDHR_CANDIDATE_RAW',str(Path(__file__).parent)))
out=raw/os.environ.get('EDHR_RUN_PHASE','final');out.mkdir(parents=True,exist_ok=False);shutil.copyfile(__file__,out/'runner-source.py')
front=root/'gmp-platform/frontend';base='8a415040babc1cc91ca9f5683bf0db46829eea76'
nodes=['test-designer-excel-images.mjs','test-designer-document-read.mjs','test-designer-save-state.mjs','test-designer-subfield-sync.mjs','test-designer-choice-options.mjs','test-form-document-preview.mjs','test-execution-document-viewer.mjs']
browsers=['test-designer-excel-images-browser.mjs','test-designer-document-read-browser.mjs','test-designer-save-context-browser.mjs','test-designer-import-browser.mjs']
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/agents/quality-verifier.md','DESIGN.md',
 'docs/frontend/list-page-guidelines.md','docs/development/branch-review-20261112-w2-import-normalization/decision-package.yaml',
 'gmp-platform/frontend/package.json','gmp-platform/frontend/package-lock.json',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/templateImport.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importExcel.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importWord.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/store/useTemplateDesignerStore.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/tabs/model/ModelTab.tsx',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/types/document.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/types/canvas.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/tabs/model/FormInstanceDetailDrawer.tsx',
 'gmp-platform/frontend/src/pages/master-data/TemplateModelingPage.tsx',
 'gmp-platform/frontend/src/pages/workflow-center/WorkTemplateEditor.tsx','gmp-platform/frontend/src/components/AppDialog.tsx','gmp-platform/frontend/src/components/SnackbarProvider.tsx',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/controller/TemplateModelingController.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/template/controller/TemplateModelingControllerTest.java',
 'gmp-platform/backend/pom.xml','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml','docs/knowledge/decisions/DEC-0080-shared-choice-field-options.yaml']
paths += ['gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importGrid.ts','gmp-platform/frontend/src/pages/master-data/template-designer-react/components/canvas/CanvasSheetWorkspace.tsx','gmp-platform/frontend/scripts/fixtures/template-designer-react/sample-badge.png']
paths += ['gmp-platform/frontend/scripts/'+s for s in nodes+browsers+['verify-template-designer-react.mjs','verify-list-table-style-contract.mjs','verify-no-external-fonts.mjs']]
inputs=[]
for name in paths:
 b=(root/name).read_bytes();inputs.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 p=out/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'workingTreeState':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True),'target':base,
 'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceFingerprints':inputs,'steps':[]}
def save(): (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
save()
knowledgePaths=sorted(p for p in (root/'docs/knowledge').rglob('*') if p.is_file())+sorted((root/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java'))+[root/'gmp-platform/backend/pom.xml']
knowledgeBefore=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in knowledgePaths]
(out/'knowledge-inputs-before.json').write_text(json.dumps({'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':record['head'],'inputs':knowledgeBefore},indent=2)+'\n')
def run(label,command,cwd=front,env=None,expected=0):
 started=datetime.datetime.now(datetime.timezone.utc);entry={'name':label,'command':command,'startedAt':started.isoformat()}
 with (out/(label+'.log')).open('w') as log:r=subprocess.run(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
 entry.update(exitCode=r.returncode,expectedExitCode=expected,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());record['steps'].append(entry);save()
 print(json.dumps(entry),flush=True);assert r.returncode==expected,label
 return (out/(label+'.log')).read_text()
tap=run('node',['node','--test','--test-reporter=tap',*['scripts/'+s for s in nodes]])
summary={k:int(re.search(r'^# '+k+r' (\d+)',tap,re.M).group(1)) for k in ['tests','pass','fail','skipped','cancelled']};assert summary==dict(tests=101,**{'pass':101,'fail':0,'skipped':0,'cancelled':0})
(out/'node-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for script in ['verify-template-designer-react.mjs','verify-list-table-style-contract.mjs','verify-no-external-fonts.mjs']:run(script[:-4],['node','scripts/'+script])
run('build',['npm','run','build'])
for width in [1440,390]:
 for label,script,prefix in [('images','test-designer-excel-images-browser.mjs','EXCEL_IMAGES'),('document','test-designer-document-read-browser.mjs','DOCUMENT_READ'),('save','test-designer-save-context-browser.mjs','SAVE_CONTEXT'),('import','test-designer-import-browser.mjs','IMPORT')]:
  env=os.environ.copy();env.update(NODE_PATH='/workspace/.edhr-browser-tools/node_modules',CHROME_PATH='/usr/bin/chromium')
  artifacts=out/(label+'-'+str(width));env.update({prefix+'_WIDTH':str(width),prefix+'_ARTIFACTS':str(artifacts)})
  run(label+'-'+str(width),['node','scripts/'+script],env=env)
  d=json.loads((artifacts/'result.json').read_text());assert d['results'] and all(x.get('outcome',x.get('status'))=='passed' for x in d['results'])
started=datetime.datetime.now(datetime.timezone.utc)
run('java',['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','-f','gmp-platform/backend/pom.xml','-Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest','test'],cwd=root)
java=[]
for c in ['TemplateModelingControllerTest','BusinessKnowledgeModelTest']:
 hits=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+c+'.xml') if p.stat().st_mtime>=started.timestamp()];assert len(hits)==1,c
 p=hits[0];shutil.copyfile(p,out/p.name);a=ET.parse(p).getroot().attrib;s={k:int(a[k]) for k in ['tests','failures','errors','skipped']};assert s['tests']>0 and s['failures']==s['errors']==s['skipped']==0;java.append({'class':c,**s})
knowledgeAfter=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in knowledgePaths]
assert knowledgeBefore==knowledgeAfter
(out/'knowledge-inputs.json').write_text(json.dumps(knowledgeAfter,indent=2)+'\n')
(out/'java-summary.json').write_text(json.dumps(java,indent=2)+'\n')
record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();record['result']='passed';save()
