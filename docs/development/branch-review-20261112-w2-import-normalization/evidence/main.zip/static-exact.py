from pathlib import Path
import collections,datetime,hashlib,json,subprocess,shutil
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;base=Path('/tmp/edhr-import-normalization-baseline-20261112');script=raw/'skill/audit_project.py'
assert hashlib.sha256(script.read_bytes()).hexdigest()=='67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68'
initial=raw/'static-initial';initial.mkdir(exist_ok=False)
for p in list(raw.glob('*-premium.json'))+list(raw.glob('*-premium.log'))+[raw/'static-commands.json',raw/'premium-summary.json']:shutil.copyfile(p,initial/p.name)
initialScript=script.read_bytes()+b'\n';assert hashlib.sha256(initialScript).hexdigest()=='b56ca0495ace4aaac2bfa779dc707b04baab0f7d4537e6856b6348c63230661c'
(initial/'materialized-with-extra-final-newline.py').write_bytes(initialScript)
(raw/'skill/source-receipt.json').write_text(json.dumps({'nativeResource':'skill://plugins_6a7039f8e9708191bde88207b1919bf4/frontend-design-premium/scripts/audit_project.py','exactSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'firstMaterializationExtraTrailingNewline':True,'firstRunSha256':hashlib.sha256(initialScript).hexdigest(),'firstResultsPreservedIn':'static-initial','finalResults':'exact-baseline/candidate-repo/frontend-premium.json'},indent=2)+'\n')
commands=[]
for label,path in [('baseline-repo',base),('candidate-repo',root),('baseline-frontend',base/'gmp-platform/frontend'),('candidate-frontend',root/'gmp-platform/frontend')]:
    args=['python3',str(script),str(path),'--mode','strict','--output',str(raw/('exact-'+label+'-premium.json'))];started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (raw/('exact-'+label+'-premium.log')).open('w')as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    commands.append({'label':label,'command':args,'scriptSha256':hashlib.sha256(script.read_bytes()).hexdigest(),'startedAt':started,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode});assert r.returncode==2
summary=[]
for scope in ['repo','frontend']:
    b=json.loads((raw/('exact-baseline-'+scope+'-premium.json')).read_text());c=json.loads((raw/('exact-candidate-'+scope+'-premium.json')).read_text())
    def key(d):return collections.Counter(json.dumps({k:v for k,v in row.items()if k!='line'},sort_keys=True)for row in d['findings'])
    assert key(b)==key(c)
    summary.append({'scope':scope,'baseline':b['summary'],'candidate':c['summary'],'fullMultisetEqualIgnoringOnlyLine':True,'added':[],'removed':[]})
(raw/'exact-static-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(raw/'exact-premium-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
