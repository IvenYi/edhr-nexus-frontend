from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
root=Path('/workspace/edhr-nexus-frontend');front=root/'gmp-platform/frontend';raw=Path(__file__).parent/'negative';raw.mkdir(exist_ok=False)
env=os.environ.copy();env.update(NODE_PATH='/workspace/.edhr-browser-tools/node_modules',CHROME_PATH='/usr/bin/chromium',EXCEL_IMAGES_BASELINE_COMMIT='8a415040babc1cc91ca9f5683bf0db46829eea76')
record={'selectedProductCommit':env['EXCEL_IMAGES_BASELINE_COMMIT'],'testHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scriptSha256':{p:hashlib.sha256((front/'scripts'/p).read_bytes()).hexdigest() for p in ['test-designer-excel-images.mjs','test-designer-excel-images-browser.mjs']},'commands':[]}
def run(label,args,localenv):
    item={'label':label,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    with (raw/(label+'.log')).open('w') as f:r=subprocess.run(args,cwd=front,env=localenv,stdout=f,stderr=subprocess.STDOUT)
    item.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());record['commands'].append(item);(raw/'commands.json').write_text(json.dumps(record,indent=2)+'\n');assert r.returncode==1,label;print(json.dumps(item),flush=True)
run('node',['node','--test','--test-reporter=tap','scripts/test-designer-excel-images.mjs'],env)
tap=(raw/'node.log').read_text();counts={k:int(re.search(r'^# '+k+r' (\d+)',tap,re.M).group(1)) for k in ['tests','pass','fail','skipped','cancelled']};assert counts==dict(tests=10,**{'pass':4,'fail':6,'skipped':0,'cancelled':0});record['node']=counts
for width in [1440,390]:
    e=env.copy();e.update(EXCEL_IMAGES_WIDTH=str(width),EXCEL_IMAGES_ARTIFACTS=str(raw/('browser-'+str(width))))
    run('browser-'+str(width),['node','scripts/test-designer-excel-images-browser.mjs'],e)
    d=json.loads((raw/('browser-'+str(width))/'result.json').read_text());assert len(d['results'])==4 and sum(x['outcome']=='passed' for x in d['results'])==1
record['result']='expected-counterexamples-confirmed';(raw/'commands.json').write_text(json.dumps(record,indent=2)+'\n')
