import pathlib,json,subprocess,hashlib,shutil,xml.etree.ElementTree as ET
root=pathlib.Path('/tmp/edhr-central-reuse-quality-20261105/worktree');out=root.parent
base='b52138259111dd5a0d99299087913500eff627f4';head='d32b99c54b0d65bd2717274ee39135927b423acb';old='82786ee87cb2d18d748711691611212d0e8703ca'
def git(*args):
 value=subprocess.check_output(['git',*args],cwd=root,text=True)
 return value if args[0]=='show' else value.strip()
assert git('rev-parse','HEAD')==head and not git('status','--porcelain')
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/open-questions.yaml','docs/knowledge/README.md','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/rules/workflow-central-entry.yaml','docs/knowledge/rules/personnel-target-selection.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/WorkflowOperationsController.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java','gmp-platform/frontend/src/pages/workflow-center/InstanceList.tsx','gmp-platform/frontend/src/api/workflow-operations.ts','docs/development/branch-review-20261105-central-list/decision-package.yaml','docs/development/branch-review-20261105-central-json-reuse/user-confirmed.md']
fp=[]
for p in paths:
 b=(root/p).read_bytes();d=out/'read-snapshots'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 fp.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
product=git('diff','--name-only',base,head,'--','gmp-platform/backend/src/main').splitlines();assert len(product)==2
protected=git('diff','--name-only',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture','gmp-platform/frontend','gmp-platform/backend/src/main/resources').splitlines();assert not protected,protected
p='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java';before=git('show',old+':'+p);after=(root/p).read_text()
guard1=before.split('    private static final String FROM = """',1)[1].split('        """;',1)[0]==after.split('    private static final String FROM = """',1)[1].split('        """;',1)[0]
guard2=before.split('    private String visibility() {',1)[1]==after.split('    private String visibility() {',1)[1];assert guard1 and guard2
p='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java'
guard3=git('show',old+':'+p).split('    public Map<String, Object> detail(Long id) {',1)[1]==(root/p).read_text().split('    public Map<String, Object> detail(Long id) {',1)[1];assert guard3
meta={'baseCommit':base,'headCommit':head,'testedMergeCandidate':head,'targetCommit':git('rev-parse','origin/edhr-dev'),'contractReadCommit':head,'uncommittedContractPaths':[],'workingTreeStateAfterDependencyRemoval':'clean','duringRunDependencyLink':'dependency-cleanup.json explicitly records excluded untracked verifier resource','changedProductPaths':product,'changedProtectedPaths':protected,'sharedFormFromIdentical':guard1,'formVisibilityAndFollowingMethodsIdentical':guard2,'workflowDetailAndFollowingMethodsIdentical':guard3,'knowledgeFiles':len(git('ls-tree','-r','--name-only',head,'--','docs/knowledge').splitlines()),'sourceFingerprints':fp,'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','readScopes':'finite changed list, adjacent protection and stated decision records; file fingerprints do not imply whole-file semantic review'}
(out/'contract-and-source.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
p=root/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml';shutil.copy2(p,out/p.name);d=ET.parse(p).getroot();ks={k:int(d.attrib[k]) for k in ['tests','failures','errors','skipped']};assert ks=={'tests':89,'failures':0,'errors':0,'skipped':0}
(out/'knowledge-summary.json').write_text(json.dumps({'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test','cwd':str(root),'commit':head,'exitCode':0,'totals':ks,'reportSha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n')
events=[json.loads(l) for l in (out/'native/observations.jsonl').read_text().splitlines()]
def walk(n):
 yield n
 for c in n.get('Plans',[]):yield from walk(c)
plans=[]
for e in events:
 for q in e['data'].get('statements',[]):
  if 'plan' not in q:continue
  p=q['plan'][0];nodes=list(walk(p['Plan']));expanded=sum(n.get('Actual Rows',0)*n.get('Actual Loops',0) for n in nodes if n['Node Type']=='Function Scan' and n.get('Alias')=='f')
  plans.append({'kind':e['kind'],'input':{k:v for k,v in e['data'].items() if k!='statements'},'query':'count' if q['sql'].startswith('SELECT count(*)') else 'content','executionMs':p['Execution Time'],'expandedFormCandidates':expanded,'tempReadBlocks':p['Plan'].get('Temp Read Blocks',0),'tempWrittenBlocks':p['Plan'].get('Temp Written Blocks',0)})
(out/'native-performance.json').write_text(json.dumps({'plans':plans,'limits':'own single synthetic native run; warm EXPLAIN replays separate from request time; no production SLA or memory guarantee'},ensure_ascii=False,indent=2)+'\n')
print('source guards pass; knowledge',ks,'own plans',len(plans))
for p in plans:
 if p['kind']=='central-list-scale' and p['input']['formsPerObject']>=100:print(p)
