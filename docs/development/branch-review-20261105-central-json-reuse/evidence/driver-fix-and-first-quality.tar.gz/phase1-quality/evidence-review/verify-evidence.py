import pathlib,json,hashlib,subprocess,xml.etree.ElementTree as ET,collections,re,datetime
repo=pathlib.Path('/workspace/edhr-nexus-frontend')
raw=pathlib.Path('/tmp/edhr-central-reuse-evidence-raw-20261105')
out=pathlib.Path('/tmp/edhr-central-reuse-quality-20261105/evidence-review')
candidate='d32b99c54b0d65bd2717274ee39135927b423acb';base='b52138259111dd5a0d99299087913500eff627f4';old='82786ee87cb2d18d748711691611212d0e8703ca'
folder=repo/'docs/development/branch-review-20261105-central-json-reuse'
checks=[]
def load(p):return json.loads(pathlib.Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo).decode().strip()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
def passed(id,detail,evidence):checks.append({'id':id,'outcome':'passed','detail':detail,'evidence':evidence})
metadata=load(folder/'evidence/primary-manifest.json');archive=repo/metadata['path']
assert len(archive.read_bytes())==metadata['bytes'] and sha(archive.read_bytes())==metadata['sha256']
counts={}
for name,location in [('outer',raw),('ontology',raw/'ontology'),('design',raw/'design-review')]:
 manifest=load(location/'manifest.json');counts[name]=len(manifest['files'])
 for f in manifest['files']:
  b=(location/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],(name,f['path'])
assert counts['outer']==416 and metadata['archiveMemberCount']==417
passed('archive-hashes',counts,['manifest.json','ontology/manifest.json','design-review/manifest.json'])
snapshots=list((raw/'primary/final-source').rglob('*'));snapshots=[p for p in snapshots if p.is_file()]
for p in snapshots:assert p.read_bytes()==blob(candidate,str(p.relative_to(raw/'primary/final-source'))),p
native=load(raw/'primary/native-full/run.json');assert native['commit']==old and native['exitCode']==0
for f in native['sourceFingerprints']:
 b=(raw/'primary/native-full/source'/f['path']).read_bytes();assert sha(b)==f['sha256'] and b==blob(candidate,f['path'])
source_registry=load(folder/'source-review.json')
for f in source_registry['sourceFingerprints']:assert sha(blob(candidate,f['path']))==f['sha256']
assert source_registry['wholeFileComplete']==0 and source_registry['historicalUniqueCoverage'] is None
passed('dirty-run-to-candidate-source',{'finalSourceSnapshots':len(snapshots),'runtimeFingerprints':len(native['sourceFingerprints']),'registryFingerprints':len(source_registry['sourceFingerprints']),'actualRunHead':old,'candidate':candidate},['primary/native-full/run.json','primary/final-source/'])
def xml_totals(path):
 totals={k:0 for k in ['tests','failures','errors','skipped']}
 for p in path.glob('TEST-*.xml'):
  doc=ET.parse(p).getroot()
  for k in totals:totals[k]+=int(doc.attrib.get(k,0))
 return totals
full=xml_totals(raw/'primary/native-full');negative=xml_totals(raw/'primary/native-negative');focused=xml_totals(raw/'primary/native-focused')
assert full=={'tests':200,'failures':0,'errors':0,'skipped':0}
assert negative=={'tests':4,'failures':3,'errors':0,'skipped':0}
assert focused=={'tests':23,'failures':0,'errors':2,'skipped':0}
assert load(raw/'primary/native-full/test-summary.json')['totals']==full
failed_xml=next((raw/'primary/native-focused').glob('TEST-*.xml')).read_text()
assert 'sync_deletion_form_references' in failed_xml and 'not-json' in failed_xml
passed('fresh-xml-totals-and-failure-history',{'full':full,'negative':negative,'firstFocused':focused},['primary/native-full/TEST-*.xml','primary/native-negative/TEST-*.xml','primary/native-focused/TEST-*.xml'])
test_path='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
negative_test=(raw/'primary/native-negative/source'/test_path).read_text();final_test=blob(candidate,test_path).decode();guards=load(raw/'primary/negative-selected-byte-guards.json')
def method(source,name):
 match=re.search(r'(?m)^    (?:private(?: static)? [^\n]+|void) '+re.escape(name)+r'\(',source);assert match,name
 start=match.start();begin=source.index('{',match.end());depth=0
 for i in range(begin,len(source)):
  if source[i]=='{':depth+=1
  elif source[i]=='}':
   depth-=1
   if depth==0:return source[start:i+1]
 raise AssertionError(name)
for guard in guards['selectedMethods']:
 a=method(negative_test,guard['method']);b=method(final_test,guard['method']);assert a==b and sha(b.encode())==guard['sha256']
assert negative_test!=final_test and not guards['wholeTestFileIdentical']
for f in load(raw/'primary/native-negative/run.json')['sourceFingerprints']:
 if '/src/main/' in f['path']:assert (raw/'primary/native-negative/source'/f['path']).read_bytes()==blob(old,f['path'])
assert '90000L' in next((raw/'primary/native-negative').glob('TEST-*.xml')).read_text()
passed('negative-control-exact-selected-scope',{'selectedMethods':len(guards['selectedMethods']),'wholeClassIdentical':False,'oldProductExact':True},['primary/negative-selected-byte-guards.json','primary/native-negative/source/'])
events=[json.loads(l) for l in (raw/'primary/native-full/observations.jsonl').read_text().splitlines()];central=[e for e in events if e['kind'].startswith('central-list-')]
assert len(events)==137 and sum(e['totalStatements'] for e in events)==388
assert len(central)==47 and sum(e['totalStatements'] for e in central)==92
assert sum(sum(s.startswith('SELECT count(*)') for s in e['jdbcSql']) for e in central)==46
plans=[s['plan'][0] for e in central for s in e['data'].get('statements',[]) if 'plan' in s];assert len(plans)==70
def nodes(n):
 yield n
 for c in n.get('Plans',[]):yield from nodes(c)
for e in central:
 if 'formsPerObject' not in e['data']:continue
 budget=e['data']['objects']*e['data']['formsPerObject']
 for statement in e['data'].get('statements',[]):
  if 'plan' not in statement:continue
  nlist=list(nodes(statement['plan'][0]['Plan']));expanded=sum(n.get('Actual Rows',0)*n.get('Actual Loops',0) for n in nlist if n['Node Type']=='Function Scan' and n.get('Alias')=='f');assert expanded<=budget,(e['kind'],budget,expanded)
report=load(folder/'performance-report.json');assert report['allObservationEvents']==137 and report['centralCountSelects']==46 and report['separateExplainReplays']==70
passed('actual-plan-expansion-and-counting',{'events':137,'logicalSelects':388,'centralEvents':47,'centralSelects':92,'centralCountSelects':46,'separateExplain':70},['primary/native-full/observations.jsonl','performance-report.json'])
comparisons=load(raw/'primary/experiment/comparison.json');assert len(comparisons)==20
for row in comparisons:
 index=0 if row['query']=='count' else 1;prefix=f"{row['objects']}-{row['formsPerObject']}-{row['case']}-{index}"
 a=load(raw/'primary/experiment'/(prefix+'-baseline-result.stdout'));b=load(raw/'primary/experiment'/(prefix+'-per-object-result.stdout'));assert a==b and row['resultIdentical']
 old_plan=load(raw/'primary/experiment'/(prefix+'-baseline-plan.stdout'))[0];new_plan=load(raw/'primary/experiment'/(prefix+'-per-object-plan.stdout'))[0]
 assert old_plan['Execution Time']==row['baselineMs'] and new_plan['Execution Time']==row['optimizedMs']
for i in [0,1]:
 p=load(raw/f'primary/experiment/low-work-mem-{i}.stdout')[0]['Plan'];assert p['Temp Read Blocks']==900 and p['Temp Written Blocks']==1289
passed('prototype-equivalence-and-plans',{'comparisons':20,'narrowCaseNames':sorted(set(r['case'] for r in comparisons))},['primary/experiment/comparison.json','primary/experiment/*-result.stdout','primary/experiment/*-plan.stdout'])
memory=load(raw/'primary/memory/summary.json');assert memory==load(folder/'memory-report.json') and len(memory['results'])==8
for row in memory['results']:
 label=f"{row['objects']}-{row['formsPerObject']}-{row['runningOnly']}-{row['variant']}";samples=load(raw/'primary/memory'/(label+'-samples.json'))
 assert row['samples']==len(samples) and row['kernelPeakRssKiB']==max(s.get('VmHWM',0) for s in samples)
 assert row['peakSampledPrivateKiB']==max(s.get('Private_Clean',0)+s.get('Private_Dirty',0) for s in samples)
 script=(raw/'primary/memory'/(label+'.sql')).read_text();assert '1..3 LOOP' in script and 'SET work_mem=\'4MB\'' in script
deltas=[]
for oldrow in memory['results']:
 if oldrow['variant']!='baseline':continue
 newrow=next(r for r in memory['results'] if r['variant']=='optimized' and all(r[k]==oldrow[k] for k in ['objects','formsPerObject','runningOnly']))
 deltas.append(newrow['kernelPeakRssKiB']-oldrow['kernelPeakRssKiB'])
assert sum(d<0 for d in deltas)==3 and max(deltas)==224
workmem=[e for e in central if e['kind']=='central-list-work-memory'];assert {e['data']['workMem'] for e in workmem}=={'64kB','4MB'}
assert '@org.springframework.transaction.annotation.Transactional\n    void centralListKeepsResultsWithSmallAndDefaultWorkMemory' in final_test and 'SHOW work_mem' in final_test
passed('memory-samples-and-transaction-scoping',{'groups':8,'kernelPeakRssDeltasKiB':deltas,'privatePeakIsSampledLowerBound':True,'nativeWorkMemCases':2},['primary/memory/summary.json','primary/memory/*-samples.json','primary/native-full/observations.jsonl'])
for folder_name in ['experiment','native-negative','native-focused','native-full','memory']:
 clean=load(raw/f'primary/{folder_name}/cleanup.json');assert clean.get('removed') is True,folder_name
assert load(raw/'primary/memory/cleanup-first-observation.json')['removed'] is False
passed('resource-cleanup-and-original-history',{'allOwnedMainContainersRemoved':True,'firstRaceReceiptKept':True},['primary/*/cleanup.json','primary/memory/cleanup-first-observation.json'])
records=[json.loads(l) for l in (raw/'ontology/audit-records.jsonl').read_text().splitlines()];assert len(records)==13
conclusions=dict(collections.Counter(r['conclusion'] for r in records));assert conclusions=={'consistent':11,'superseded':1,'evidence-gap':1}
assert all(r['reviewStatus']=='reviewed' for r in records)
for row in records:assert row['id'].encode() in blob(candidate,row['sourcePath']),row['id']
assert not git('diff','--name-only',base,candidate,'--','docs/knowledge','docs/architecture')
knowledge=git('ls-tree','-r','--name-only',candidate,'docs/knowledge').splitlines();assert len(knowledge)==350
baseline=load(folder/'baseline-review.json');assert baseline['wholeFileComplete']==0 and baseline['historicalUniqueCoverage'] is None and baseline['pendingKnowledgeIncrementCandidates']==931 and baseline['priorUiDiagnosticCandidatesPending']==86 and not baseline['wholeAuditComplete']
passed('finite-ontology-and-audit-honesty',{'records':13,'conclusions':conclusions,'knowledgeFilesUnchanged':350,'wholeFileComplete':0,'historicalUniqueCoverage':None},['ontology/audit-records.jsonl','ontology/summary.json','baseline-review.json'])
form_path='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java';query_path='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java'
form=blob(candidate,form_path).decode();form_before=blob(old,form_path).decode();query=blob(candidate,query_path).decode();query_before=blob(old,query_path).decode()
assert form.split('private static final String FROM = """',1)[1].split('        """;',1)[0]==form_before.split('private static final String FROM = """',1)[1].split('        """;',1)[0]
assert form.split('    private String visibility() {',1)[1]==form_before.split('    private String visibility() {',1)[1]
assert query.split('    public Map<String, Object> detail(Long id) {',1)[1]==query_before.split('    public Map<String, Object> detail(Long id) {',1)[1]
assert set(git('diff','--name-only',base,candidate,'--','gmp-platform/backend/src/main').splitlines())=={form_path,query_path}
assert not git('diff','--name-only',base,candidate,'--','gmp-platform/frontend','AGENTS.md','codeplzreadme.md','docs/agents')
passed('protected-regions-and-minimal-scope',{'productPaths':2,'sharedFromAndFollowingWriteHelpersIdentical':True,'frontendContractsUnchanged':True},[form_path,query_path,'source-review.json'])
result={'role':'independent-quality-evidence-subtask','status':'FINAL','result':'passed','isFinalQualityResult':False,'baseCommit':base,'headCommit':candidate,'contractReadCommit':candidate,'uncommittedContractPaths':[],'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'limits':['No native/database/browser execution by this child; final QA performs fresh runtime separately','Raw archive from canonical committed path; extracted own temporary raw directory is not a running resource','Evidence hashes and finite source checks do not prove whole-system semantic audit or production SLA'],'changedProductTestConfigFiles':[],'ownedRunningResources':[]}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'FINAL','result':'passed','checks':len(checks),'findings':[]},ensure_ascii=False))
