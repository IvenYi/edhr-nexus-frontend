import pathlib,json,re,collections,hashlib
out=pathlib.Path('/tmp/edhr-central-reuse-quality-20261105');native=out/'native';database='edhr_workflow_read_test_independent'
events=[json.loads(x) for x in (native/'observations.jsonl').read_text().splitlines()]
def normalize(sql):
 return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql.replace('??','?'))).strip().rstrip(';')
expected=collections.Counter(normalize(s) for e in events for s in e['jdbcSql']+e['hibernateSql'])
expected_explain=collections.Counter(normalize('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q['sql']) for e in events for q in e['data'].get('statements',[]) if 'plan' in q)
raw=(native/'postgres.log').read_text()
header=re.compile(r'^\d{4}-\d\d-\d\d [^\n]+?\[\d+\] db=(\S*) app=(.*?) (LOG|ERROR|DETAIL|HINT|CONTEXT|STATEMENT|FATAL|WARNING):\s*',re.M)
matches=list(header.finditer(raw));own=[];other_statements=collections.Counter();errors=[]
for i,m in enumerate(matches):
 body=raw[m.end():matches[i+1].start() if i+1<len(matches) else len(raw)].strip()
 duration=re.match(r'duration:\s+[\d.]+ ms\s+(?:execute [^:]+:|statement:)\s*(.*)',body,re.S)
 if not duration:
  if m.group(1)==database and m.group(3)=='ERROR':errors.append(body)
  continue
 sql=duration.group(1).strip()
 if m.group(1)==database:own.append(sql)
 else:other_statements[m.group(1)]+=1
selects=[s for s in own if s.upper().startswith('SELECT')];explains=[s for s in own if s.upper().startswith('EXPLAIN')];shows=[s for s in own if s.upper().startswith('SHOW')]
actual=collections.Counter(normalize(s) for s in selects);actual_explain=collections.Counter(normalize(s) for s in explains)
unmatched=collections.Counter(normalize(s) for s in selects if normalize(s) not in expected)
digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
startup=[e for e in errors if e=='relation "public.databasechangeloglock" does not exist at character 22'];unexpected=[e for e in errors if e not in startup]
summary={'database':database,'observationEvents':len(events),'logicalRequestSelects':sum(expected.values()),'logicalCountSelects':sum(v for s,v in expected.items() if s.startswith('SELECT count(*)')),'serverOwnDatabaseSuccessfulSelects':len(selects),'serverExplainReplays':len(explains),'expectedExplainReplays':sum(expected_explain.values()),'requestSignatureCount':len(expected),'requestSignatures':[{'sha256':digest(s),'expected':v,'serverActual':actual[s],'sql':s} for s,v in expected.items()],'explainSignatures':[{'sha256':digest(s),'expected':v,'serverActual':actual_explain[s],'sql':s} for s,v in expected_explain.items()],'excludedOwnSelects':[{'sql':s,'count':v,'sha256':digest(s)} for s,v in unmatched.items()],'excludedOwnSelectCount':sum(unmatched.values()),'otherDatabaseSuccessfulStatements':dict(other_statements),'ownSuccessfulShows':shows,'expectedLiquibaseEmptyLockProbeErrors':startup,'unexpectedOwnDatabaseErrors':unexpected,'requestCountersMatch':all(actual[s]==v for s,v in expected.items()),'explainCountersMatch':actual_explain==expected_explain,'normalization':'JDBC ?? JSON operator to ?; PG $n bind placeholders to ?; collapse whitespace; preserve remaining SQL','notAllNetworkSql':True}
(out/'server-crosscheck.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in summary.items() if k not in ['requestSignatures','explainSignatures','excludedOwnSelects','ownSuccessfulShows','normalization']})
assert len(events)==47 and sum(expected.values())==92 and summary['logicalCountSelects']==46
assert summary['requestCountersMatch'] and summary['explainCountersMatch'] and len(explains)==70
assert len(startup)==1 and not unexpected
assert sum(s.lower()=='show work_mem' for s in shows)==2
