import pathlib,subprocess,json,time,datetime,os
root=pathlib.Path('/tmp/edhr-central-json-reuse-20261105');out=root/'memory-driver';out.mkdir(exist_ok=False)
name='edhr-central-reuse-memory-driver-20261105';db='edhr_central_reuse_memory_test';created=False
def command(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout
def pg(sql,label):
 (out/(label+'.sql')).write_text(sql)
 p=subprocess.run(['docker','exec','-i',name,'psql','-XqAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],input=sql,text=True,capture_output=True)
 (out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr);p.check_returncode();return p.stdout
try:
 # Reuse the canonical schema export: this change has no schema/migration modifications.
 dump=(root/'memory/canonical-schema.sql').read_text()
 assert 'CREATE TABLE public.production_execution' in dump
 (out/'canonical-schema.sql').write_text(dump)
 command(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('own memory PG not ready')
 pg(dump,'schema-restore')
 pg("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(41,0,'memory-applicant','申请人','not-used','ACTIVE'); INSERT INTO workflow_definition(id,name,type,business_type,status) VALUES(900101,'读取观测','GENERAL','READ_OBSERVATION','PUBLISHED');INSERT INTO workflow_definition_version(id,definition_id,status,is_current,nodes_json,edges_json) VALUES(900102,900101,'PUBLISHED',true,'[]','[]');INSERT INTO workflow_instance(id,definition_id,version_id,business_type,business_id,initiator_id,status,started_at) VALUES(900100,900101,900102,'READ_OBSERVATION','READ-OBS-1','41','RUNNING','2026-01-03');",'generic-fixture')
 import experiment_queries
 baseline=[json.loads(l) for l in pathlib.Path('/tmp/edhr-central-list-20261105/native-focused/observations.jsonl').read_text().splitlines()]
 for _ in range(600):
  path=root/'native-full2/observations.jsonl'
  try:optimized=[json.loads(l) for l in path.read_text().splitlines()]
  except (FileNotFoundError,json.JSONDecodeError):optimized=[]
  available={(e['data']['objects'],e['data']['formsPerObject'],e['data']['runningOnly']) for e in optimized if e['kind']=='central-list-scale'}
  if all(key in available for key in [(1,300,False),(1,300,True),(30,100,False),(30,100,True)]):break
  time.sleep(.25)
 else:raise RuntimeError('final native service capture not available')
 results=[]
 for objects,forms in [(1,300),(30,100)]:
  pg((root/f'experiment/seed-{objects}-{forms}.sql').read_text(),f'seed-{objects}-{forms}')
  for running in [False,True]:
   for variant,events in [('baseline',baseline),('optimized',optimized)]:
    event=next(e for e in events if e['kind']=='central-list-scale' and e['data']['objects']==objects and e['data']['formsPerObject']==forms and e['data']['runningOnly']==running)
    statement=event['data']['statements'][1];sql=experiment_queries.numbered(statement['sql']);args=statement['parameters'];params='('+','.join(experiment_queries.literal(v) for v in args)+')' if args else ''
    label=f'{objects}-{forms}-{running}-{variant}'
    script="SELECT pg_backend_pid();SELECT pg_sleep(0.3);SET work_mem='4MB';PREPARE memory_read AS "+sql+";DO $$BEGIN FOR n IN 1..3 LOOP EXECUTE 'EXECUTE memory_read"+params.replace("'","''")+"'; END LOOP; END$$;SELECT pg_sleep(0.3);"
    (out/(label+'.sql')).write_text(script)
    with (out/(label+'.stderr')).open('w') as err:
     p=subprocess.Popen(['docker','exec','-i',name,'psql','-XqAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,text=True)
     p.stdin.write(script);p.stdin.close();pid=int(p.stdout.readline().strip());samples=[]
     while p.poll() is None:
      sample=subprocess.run(['docker','exec','--user','postgres',name,'cat',f'/proc/{pid}/status',f'/proc/{pid}/smaps_rollup'],capture_output=True,text=True)
      if sample.returncode==0:
       values={}
       for line in sample.stdout.splitlines():
        pieces=line.split()
        if len(pieces)==3 and pieces[1].isdigit() and pieces[2]=='kB':values[pieces[0].rstrip(':')]=int(pieces[1])
       values['sampleTimeNs']=time.monotonic_ns();samples.append(values)
      time.sleep(.02)
     tail=p.stdout.read();(out/(label+'.stdout')).write_text(str(pid)+'\n'+tail)
     if p.returncode:raise RuntimeError(label+' memory workload failed')
    assert samples and any('VmHWM' in s for s in samples)
    (out/(label+'-samples.json')).write_text(json.dumps(samples,indent=2)+'\n')
    row={'objects':objects,'formsPerObject':forms,'runningOnly':running,'variant':variant,'pid':pid,'repetitions':3,'samples':len(samples),'firstRssKiB':samples[0].get('VmRSS'),'kernelPeakRssKiB':max(s.get('VmHWM',0) for s in samples),'peakSampledPrivateKiB':max(s.get('Private_Clean',0)+s.get('Private_Dirty',0) for s in samples),'privateSampleAvailable':any('Private_Dirty' in s for s in samples)}
    results.append(row);(out/'summary.json').write_text(json.dumps({'results':results,'limits':['fresh backend per workload; peak RSS includes session/JIT/shared mappings','sampled private peak is a lower bound; not a production concurrency or peak-memory guarantee','three repeated captured real-service content reads, no product GUC changes','schema exported read-only from owned migrated native DB; separate owned PG container']},indent=2)+'\n');print(json.dumps(row),flush=True)
finally:
 if created:
  command(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed})+'\n')
