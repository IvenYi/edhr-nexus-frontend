PREPARE q AS SELECT COALESCE(jsonb_agg(to_jsonb(t)),'[]'::jsonb) FROM (SELECT * FROM (SELECT CAST(i.id AS VARCHAR) AS "id",d.name AS "templateName",COALESCE(q.request_no,h.dhr_no||' · V'||v.version_no,i.business_id) AS "businessKey",i.business_type AS "businessType",i.status,COALESCE(u.display_name,i.initiator_id) AS "startUserName",CAST(i.started_at AS VARCHAR) AS "startTime",CAST(i.completed_at AS VARCHAR) AS "endTime" FROM workflow_instance i LEFT JOIN workflow_definition d ON d.id=i.definition_id
LEFT JOIN record_control_request q ON q.workflow_instance_id=CAST(i.id AS VARCHAR) AND q.tenant_id='default'
LEFT JOIN dhr_summary_review r ON r.workflow_instance_id=i.id AND i.business_type='DHR_SUMMARY'
LEFT JOIN dhr_summary_version v ON v.id=r.summary_version_id AND v.tenant_id='default'
LEFT JOIN dhr_instance h ON h.id=v.dhr_instance_id AND h.tenant_id=v.tenant_id
LEFT JOIN user_account u ON CAST(u.id AS VARCHAR)=i.initiator_id
 WHERE (i.business_type IS DISTINCT FROM 'DHR_SUMMARY' OR h.id IS NOT NULL) UNION ALL SELECT projected.* FROM production_execution execution
CROSS JOIN LATERAL (
  WITH record_scope AS MATERIALIZED (
    SELECT r.id,r.tenant_id,r.object_id,r.operation_id,r.form_id,r.copy_id,r.template_name,r.instance_no,
           r.created_by,r.created_by_id,r.created_at,o.status AS object_status,w.status AS work_order_status
    FROM form_instance_record r JOIN production_object o ON o.id=r.object_id AND o.tenant_id=r.tenant_id
    JOIN work_order w ON w.id=o.work_order_id AND w.tenant_id=o.tenant_id
    WHERE r.object_id=execution.object_id AND r.tenant_id='default' 
  ), parsed_state AS MATERIALIZED (
    SELECT CAST(execution.state_json AS jsonb) AS state_json WHERE EXISTS (SELECT 1 FROM record_scope)
  ), progress_records AS MATERIALIZED (
    SELECT r.*,s.progress FROM record_scope r CROSS JOIN parsed_state e
    CROSS JOIN LATERAL (SELECT e.state_json #> ARRAY['operations',r.operation_id,'forms',r.copy_id] AS progress) s
    WHERE jsonb_typeof(s.progress)='object' 
  ), parsed_snapshot AS MATERIALIZED (
    SELECT CAST(execution.snapshot_json AS jsonb) AS snapshot_json WHERE EXISTS (SELECT 1 FROM progress_records)
  ), form_catalog AS MATERIALIZED (
    SELECT op->>'id' AS operation_id,f->>'id' AS form_id,
           jsonb_build_object('flow',f->'flow','sourceType',f->'sourceType') AS f
    FROM parsed_snapshot e CROSS JOIN LATERAL jsonb_array_elements(e.snapshot_json->'operations') op
    JOIN (SELECT DISTINCT operation_id FROM progress_records) wanted ON wanted.operation_id=op->>'id'
    CROSS JOIN LATERAL jsonb_array_elements(op->'forms') f
  )
  SELECT 'form-'||CAST(r.id AS VARCHAR) AS "id",r.template_name AS "templateName",r.instance_no AS "businessKey",
    'FORM_PROCESS' AS "businessType",CASE WHEN s.progress->>'status'='ACTIVE' THEN 'RUNNING' ELSE 'COMPLETED' END AS status,
    r.created_by AS "startUserName",CAST(r.created_at AS VARCHAR) AS "startTime",CAST(NULL AS VARCHAR) AS "endTime"
FROM progress_records r CROSS JOIN parsed_state e
JOIN form_catalog c ON c.operation_id=r.operation_id AND c.form_id=r.form_id
CROSS JOIN LATERAL (SELECT r.progress AS progress) s
WHERE jsonb_array_length(COALESCE(f->'flow'->'nodes','[]'::jsonb))>0

) projected
) sources WHERE 1=1 ORDER BY "startTime" DESC,id DESC LIMIT $1 OFFSET $2)t;EXECUTE q(20,0);