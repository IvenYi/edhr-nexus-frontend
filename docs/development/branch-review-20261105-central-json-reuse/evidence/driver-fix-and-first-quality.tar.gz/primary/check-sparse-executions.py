import pathlib,subprocess,json,time
root=pathlib.Path('/tmp/edhr-central-json-reuse-20261105');out=root/'sparse-executions';out.mkdir(exist_ok=False)
name='edhr-central-reuse-sparse-20261105';db='edhr_central_reuse_sparse_test';created=False
def command(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout
def pg(sql,label):
 (out/(label+'.sql')).write_text(sql);p=subprocess.run(['docker','exec','-i',name,'psql','-XqAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],input=sql,text=True,capture_output=True);(out/(label+'.stdout')).write_text(p.stdout);(out/(label+'.stderr')).write_text(p.stderr);p.check_returncode();return p.stdout
try:
 command(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('own PG unavailable')
 pg((root/'memory/canonical-schema.sql').read_text(),'schema')
 pg((root/'experiment/seed-1-1.sql').read_text(),'seed')
 old=[json.loads(l) for l in pathlib.Path('/tmp/edhr-central-list-20261105/native-focused/observations.jsonl').read_text().splitlines()]
 new=[json.loads(l) for l in (root/'native-full/observations.jsonl').read_text().splitlines()]
 import experiment_queries
 results=[]
 for count in [0,1000,10000]:
  if count:
   pg(f"INSERT INTO production_object(id,work_order_id,object_no,object_type,process_version_id,target_quantity,status) SELECT 8000000+n,910108,'SPARSE-'||n,'BATCH',910107,1,'IN_PROGRESS' FROM generate_series(1,{count})n ON CONFLICT(id) DO NOTHING;INSERT INTO production_execution(object_id,snapshot_json,state_json,started_at,updated_at) SELECT o.id,e.snapshot_json,'{{\"operations\":{{}}}}',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP FROM production_object o CROSS JOIN production_execution e WHERE o.id>=8000000 AND e.object_id=910109 ON CONFLICT(object_id) DO NOTHING;ANALYZE production_object;ANALYZE production_execution;ANALYZE form_instance_record;",f'add-{count}')
  for variant,events in [('baseline',old),('optimized',new),('driver-filter',new)]:
   e=next(e for e in events if e['kind']=='central-list-scale' and e['data']['objects']==1 and e['data']['formsPerObject']==1 and not e['data']['runningOnly']);s=e['data']['statements'][1];sql=experiment_queries.numbered(s['sql']);params='('+','.join(experiment_queries.literal(v) for v in s['parameters'])+')'
   if variant=='driver-filter':
    sql=sql.replace('SELECT projected.* FROM production_execution execution',"SELECT projected.* FROM (SELECT DISTINCT object_id FROM form_instance_record WHERE tenant_id='default') referenced JOIN production_execution execution ON execution.object_id=referenced.object_id")
   values=json.loads(pg("PREPARE q AS SELECT COALESCE(jsonb_agg(to_jsonb(t)),'[]'::jsonb) FROM ("+sql+")t;EXECUTE q"+params+';',f'{count}-{variant}-result'));assert len(values)==1 and values[0]['id']=='form-2000000'
   p=json.loads(pg('PREPARE q AS '+sql+';EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE q'+params+';',f'{count}-{variant}'))[0]
   row={'unrecordedExecutions':count,'variant':variant,'executionMs':p['Execution Time']};results.append(row);(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
finally:
 if created:
  command(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed})+'\n')
