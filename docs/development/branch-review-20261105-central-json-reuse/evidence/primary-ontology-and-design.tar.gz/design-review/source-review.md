# 中央列表JSON复用设计审查

状态：FINAL；只读设计/源码核对，不是最终qualityResult。未执行SQL、Maven或浏览器，未改工作树、产品、测试、配置或知识政策。基线HEAD/contractReadCommit为82786ee87cb2d18d748711691611212d0e8703ca，目标edhr-dev为b52138259111dd5a0d99299087913500eff627f4，知识0.3.25。

## 判断

查询内按对象解析一次、按对象/作业/表单形成窄目录，再关联持久化表单份，是可验证的局部方案。新路径只应进入FormWorkflowOperations.source；原FROM被detail及load/改派使用，不能把单ID详情/事务加载也改成整租户物化。暂不需要新读取服务、存储表、跨请求缓存或运行任务。

## 必须保持的边界

1. **先限定记录，再解析执行JSON。** parsed_execution只包含default租户且原production_object/work_order同租户连接有效的真实form_instance_record对应对象；object_id去重仅用于确定要解析的对象。不能无条件扫描production_execution。没有表单记录、租户不匹配、无有效父连接的执行对象不应因新CTE而被解析。
2. **防止窄筛选倒退。** 当前关键词位于UNION外，优化器可下推纯记录字段过滤。若CTE先物化全租户，精确form-ID、只命中通用workflow-ID或完全不匹配的查询可能反而全量解析。实验必须含这些正控。可在物化前传入完全等价的纯r字段关键词约束，保留form-前缀、字面%/_/!转义、大小写匹配与绑定顺序；或验证每对象correlated子查询内物化，避免无命中全租户展开。不要为了简洁偷偷取消这种过滤能力。
3. **来源及四重身份保持。** state/progress来自execution，按object/operation/copy取值；catalog按object/operation/form关联，history还须匹配copy。不要用r.status替代progress.status，不要用r.source_type替代快照f.sourceType，不要用r.snapshot_json代替执行快照查得的表单。需要普通副本、一作业多表单、多作业复用同formId的反例。
4. **保留原JSON和行语义。** catalog保留JSON数组行，不能用DISTINCT或jsonb_object_agg折叠重复operation/form ID，除非已有约束及业务依据证明等价。保留源CASE的ACTIVE→RUNNING/其他→COMPLETED、JSON缺失/JSON null/SQL NULL差异、原jsonb_array_length异常语义；不要在这次性能改动中加吞错、跳过坏JSON、补空数组等恢复政策。
5. **权限/干预不简化。** 原creator/history/当前审批候选、transferAssignees、restrictedApprovers、权限码及runningOnly对象/工单/作业/CUSTOM/DHR锁条件完整保留。无权限分支应继续零结果，计数和内容一致。只读集中列表不赋予办理资格，原写入锁/签名/资格复核保持。
6. **投影保持窄。** 每object唯一parsed_execution可以持有state/snapshot JSONB；form_catalog只保留object_id、operation_id、form_id、nodes（或flow）、sourceType。不要把整个snapshot/state或r.snapshot_json/values_json带到每张表单的物化行；eligible_records也只选列表/权限所需标量，不SELECT r.*。

## 可比较的SQL形状（仅结构示意，未运行）

```sql
WITH eligible_records AS MATERIALIZED (
  SELECT r.id, r.object_id, r.operation_id, r.form_id, r.copy_id,
         /* 列表与可见性需要的少量标量，及o/w状态 */
  FROM form_instance_record r
  JOIN production_object o ON o.id=r.object_id AND o.tenant_id=r.tenant_id
  JOIN work_order w ON w.id=o.work_order_id AND w.tenant_id=o.tenant_id
  WHERE r.tenant_id='default'
    /* 在这里保留等价纯r字段窄筛选，不能无条件先物化全租户 */
), parsed_execution AS MATERIALIZED (
  SELECT e.object_id, e.state_json::jsonb AS state,
         e.snapshot_json::jsonb AS snapshot
  FROM production_execution e
  WHERE EXISTS (SELECT 1 FROM eligible_records r WHERE r.object_id=e.object_id)
), form_catalog AS MATERIALIZED (
  SELECT e.object_id, op->>'id' AS operation_id, f->>'id' AS form_id,
         f->'flow'->'nodes' AS nodes, f->>'sourceType' AS source_type
  FROM parsed_execution e
  CROSS JOIN LATERAL jsonb_array_elements(e.snapshot->'operations') op
  CROSS JOIN LATERAL jsonb_array_elements(op->'forms') f
  /* 可在数组展开前后限制实际需要的operation/form；保留乘数 */
)
SELECT /* 原列表字段 */
FROM eligible_records r
JOIN parsed_execution e ON e.object_id=r.object_id
JOIN form_catalog f ON f.object_id=r.object_id
  AND f.operation_id=r.operation_id AND f.form_id=r.form_id
/* 按r.copy_id取progress；原可见性、状态和节点谓词仍在分页之前 */
```

另一个可比较形状是由去重后的相关对象驱动LATERAL，每对象子查询内物化state/catalog并输出最终窄列表行，避免一次保存全租户所有大JSON。是否更小/更快取决于实际优化器计划，不能只根据SQL写法断言每对象只解析一次。

## 必要反例和资源检查

- 单对象1/30/300表单、多对象累计及深页；COUNT和内容两份计划分别看Function Scan loops×rows、连接过滤、Memoize及排序，不只统计SQL条数。
- 精确表单ID、只命中通用workflow的ID、模糊名称及全无命中；加入无表单记录/非default租户的坏JSON对象作为不相关解析反例（不取消真实约束造无效数据）。选中的坏JSON仍沿原失败语义，不做恢复。
- 同form两个copy，一ACTIVE一COMPLETED；仅一个copy有本人历史；两个operation复用同formId；相同ID的多个快照条目若可持久化，行乘数保持。
- r.status/r.source_type/r.snapshot_json与执行快照有意不同，证明仍取原source字段；CUSTOM与ROUTE的对象/工单/作业结束边界、DHR已定稿/非可变状态都保留。
- 普通review/filling/查看权限/完全无权、transferAssignees覆盖及restrictedApprovers；分页前授权和总数完整。
- 测默认及较小work_mem，检查Temp Read/Written Blocks、Sort Space、Hash/Memoize内存。EXPLAIN BUFFERS和无spill不能证明峰值内存/SLA；如采样内存需说明只是采样。materialized解析JSON、目录、排序/哈希可能有多个各自资源预算，不能简单声称总内存≤work_mem。
- COUNT和内容是两条独立SQL，各自一次解析不等于整个HTTP请求只解析一次；不增加事务隔离级别或跨请求缓存。普通参与人的history数组仍可能按表单份遍历，剩余规模风险不能据本次表单目录优化一并关闭。

本结论仅覆盖source/list及对应权限/加载边界，未审完模块或全仓。具体方案通过主侧原生实验后，仍需全新独立质量实例对实际实现验收。
