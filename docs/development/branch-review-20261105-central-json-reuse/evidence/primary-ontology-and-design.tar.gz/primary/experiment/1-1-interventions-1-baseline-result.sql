PREPARE q AS SELECT COALESCE(jsonb_agg(to_jsonb(t)),'[]'::jsonb) FROM (SELECT * FROM (SELECT CAST(i.id AS VARCHAR) AS "id",d.name AS "templateName",COALESCE(q.request_no,h.dhr_no||' · V'||v.version_no,i.business_id) AS "businessKey",i.business_type AS "businessType",i.status,COALESCE(u.display_name,i.initiator_id) AS "startUserName",CAST(i.started_at AS VARCHAR) AS "startTime",CAST(i.completed_at AS VARCHAR) AS "endTime" FROM workflow_instance i LEFT JOIN workflow_definition d ON d.id=i.definition_id
LEFT JOIN record_control_request q ON q.workflow_instance_id=CAST(i.id AS VARCHAR) AND q.tenant_id='default'
LEFT JOIN dhr_summary_review r ON r.workflow_instance_id=i.id AND i.business_type='DHR_SUMMARY'
LEFT JOIN dhr_summary_version v ON v.id=r.summary_version_id AND v.tenant_id='default'
LEFT JOIN dhr_instance h ON h.id=v.dhr_instance_id AND h.tenant_id=v.tenant_id
LEFT JOIN user_account u ON CAST(u.id AS VARCHAR)=i.initiator_id
 WHERE (i.business_type IS DISTINCT FROM 'DHR_SUMMARY' OR h.id IS NOT NULL) AND i.status='RUNNING' UNION ALL SELECT 'form-'||CAST(r.id AS VARCHAR) AS "id",r.template_name AS "templateName",r.instance_no AS "businessKey",
    'FORM_PROCESS' AS "businessType",CASE WHEN s.progress->>'status'='ACTIVE' THEN 'RUNNING' ELSE 'COMPLETED' END AS status,
    r.created_by AS "startUserName",CAST(r.created_at AS VARCHAR) AS "startTime",CAST(NULL AS VARCHAR) AS "endTime"
FROM form_instance_record r JOIN production_execution e ON e.object_id=r.object_id
JOIN production_object o ON o.id=r.object_id AND o.tenant_id=r.tenant_id
JOIN work_order w ON w.id=o.work_order_id AND w.tenant_id=o.tenant_id
CROSS JOIN LATERAL (SELECT CAST(e.state_json AS jsonb) #> ARRAY['operations',r.operation_id,'forms',r.copy_id] AS progress) s
JOIN LATERAL jsonb_array_elements(CAST(e.snapshot_json AS jsonb)->'operations') op ON op->>'id'=r.operation_id
JOIN LATERAL jsonb_array_elements(op->'forms') f ON f->>'id'=r.form_id
WHERE r.tenant_id='default' AND jsonb_typeof(s.progress)='object'
  AND jsonb_array_length(COALESCE(f->'flow'->'nodes','[]'::jsonb))>0
 AND s.progress->>'status'='ACTIVE' AND o.status IN ('IN_PROGRESS','COMPLETED') AND w.status IN ('CREATED','IN_PROCESS','COMPLETED') AND ((f->>'sourceType'='CUSTOM' AND (CAST(e.state_json AS jsonb)#>>ARRAY['operations',r.operation_id,'status']) IN ('IN_PROGRESS','COMPLETED')) OR (COALESCE(f->>'sourceType','')<>'CUSTOM' AND o.status='IN_PROGRESS' AND w.status IN ('CREATED','IN_PROCESS') AND (CAST(e.state_json AS jsonb)#>>ARRAY['operations',r.operation_id,'status'])='IN_PROGRESS')) AND NOT EXISTS (SELECT 1 FROM dhr_instance d WHERE d.tenant_id=r.tenant_id AND d.production_object_id=o.id AND (d.status NOT IN ('IN_PROGRESS','COMPLETED') OR d.summary_status NOT IN ('NOT_STARTED','DRAFT'))) AND EXISTS (SELECT 1 FROM jsonb_array_elements(COALESCE(f->'flow'->'nodes','[]'::jsonb)) n WHERE n->'data'->>'kind'='APPROVAL' AND (s.progress->'active') ? (n->>'id'))) sources WHERE 1=1 ORDER BY "startTime" DESC,id DESC LIMIT $1 OFFSET $2)t; EXECUTE q(20,0);
