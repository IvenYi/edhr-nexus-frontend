
 TRUNCATE material,form_template,route,dhr_template,production_execution,production_object,work_order,product_process_version,product_process CASCADE;
 INSERT INTO material(id,code,name) VALUES(910101,'READ-PRODUCT','读取观测产品');
 INSERT INTO route(id,code,name) VALUES(910102,'READ-ROUTE','读取观测路线');
 INSERT INTO route_version(id,route_id,version,code) VALUES(910103,910102,'1','READ-RV');
 INSERT INTO dhr_template(id,code,name) VALUES(910104,'READ-DHR','读取观测目录');
 INSERT INTO dhr_template_version(id,dhr_template_id,version_label) VALUES(910105,910104,'1');
 INSERT INTO product_process(id,owner_type,owner_id) VALUES(910106,'PRODUCT',910101);
 INSERT INTO product_process_version(id,product_process_id,version_label,production_mode,production_form,route_version_id,dhr_template_version_id) VALUES(910107,910106,'1','量产','批次',910103,910105);
 INSERT INTO work_order(id,order_no,product_id,planned_quantity) VALUES(910108,'READ-WO',910101,1);
 INSERT INTO production_object(id,work_order_id,object_no,object_type,process_version_id,target_quantity,status)
 SELECT 910109+n,910108,'CENTRAL-'||n,'BATCH',910107,1,'IN_PROGRESS' FROM generate_series(0,1-1)n;
 INSERT INTO form_template(id,code,name) VALUES(910110,'READ-FORM','读取观测表单');
 INSERT INTO form_template_version(id,template_id) VALUES(910111,910110);
 WITH forms AS (
 SELECT n,'f-'||n fid,jsonb_build_object('id','f-'||n,'versionId','910111','sourceType','ROUTE',
  'flow','{"nodes":[{"id":"fill","data":{"kind":"START"}},{"id":"review","data":{"kind":"APPROVAL"}}]}'::jsonb,
  'fields',(SELECT jsonb_agg(jsonb_build_object('id','field-'||f,'type','text','label','现场记录字段'||f)) FROM generate_series(0,9)f)) f,
  '{"status":"ACTIVE","active":["review"],"approvers":{"review":["42"]},"restrictedApprovers":{"review":true}}'::jsonb progress
 FROM generate_series(0,1-1)n),payload AS (
 SELECT jsonb_build_object('operations',jsonb_build_array(jsonb_build_object('id','op','forms',jsonb_agg(f)))) snapshot,
 jsonb_build_object('operations',jsonb_build_object('op',jsonb_build_object('status','IN_PROGRESS','forms',jsonb_object_agg(fid,progress))),'history','[]'::jsonb) state FROM forms)
 INSERT INTO production_execution(object_id,snapshot_json,state_json,started_at,updated_at)
 SELECT o.id,p.snapshot::text,p.state::text,'2026-01-02','2026-01-02' FROM production_object o CROSS JOIN payload p;
 INSERT INTO form_instance_record(id,tenant_id,instance_no,object_id,operation_id,form_id,copy_id,template_id,version_id,snapshot_json,values_json,status,created_at,updated_at,template_name,created_by_id,source_type)
 SELECT 2000000+(o.id-910109)*1000+n,'default','CENTRAL-'||(o.id-910109)||'-'||n,o.id,'op','f-'||n,'f-'||n,910110,910111,'{}','{}','IN_REVIEW','2026-01-02','2026-01-02','中央列表表单','41','ROUTE'
 FROM production_object o CROSS JOIN generate_series(0,1-1)n;
 UPDATE workflow_instance SET started_at='2026-01-03' WHERE id=900100;
 ANALYZE form_instance_record;ANALYZE production_execution;ANALYZE production_object;ANALYZE work_order;ANALYZE workflow_instance;
 
