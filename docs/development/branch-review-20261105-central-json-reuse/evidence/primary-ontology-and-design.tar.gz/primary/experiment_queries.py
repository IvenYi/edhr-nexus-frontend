import pathlib,json,subprocess,re,textwrap,hashlib
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
def literal(value):
 if value is None:return 'NULL'
 if isinstance(value,bool):return 'true' if value else 'false'
 if isinstance(value,(int,float)):return str(value)
 return "'"+str(value).replace("'","''")+"'"
def numbered(sql):
 sql=sql.replace('??','__JSON_EXISTS__');index=0
 def replace(match):
  nonlocal index
  index+=1;return '$'+str(index)
 return re.sub(r'\?',replace,sql).replace('__JSON_EXISTS__','?')
def prototype(sql):
 start=sql.index("SELECT 'form-'||");end=sql.index(') sources',start)
 form=sql[start:end];old_from=form[form.index('FROM form_instance_record'):form.index(' AND s.progress',form.index('FROM form_instance_record'))] if ' AND s.progress' in form[form.index('FROM form_instance_record'):] else None
 # Preserve the complete original visibility and running-only suffix after the shared FROM.
 java=(ROOT/'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java').read_text()
 shared=textwrap.dedent(java.split('private static final String FROM = """\n',1)[1].split('        """;',1)[0])
 assert shared in form
 select,where=form.split(shared,1)
 where=where.replace('o.status','r.object_status').replace('w.status','r.work_order_status').replace('o.id','r.object_id')
 # Reuse existing prepared parameters for the identical outer keyword condition.
 match=re.search(r'\(id=(\$\d+) OR COALESCE\("businessKey",\'\'\) ILIKE (\$\d+) ESCAPE \'!\' OR "templateName" ILIKE (\$\d+)',sql)
 keyword=''
 if match:
  a,b,c=match.groups();keyword=f" AND ('form-'||CAST(r.id AS VARCHAR)={a} OR COALESCE(r.instance_no,'') ILIKE {b} ESCAPE '!' OR r.template_name ILIKE {c} ESCAPE '!')"
 lateral="""
 SELECT projected.* FROM production_execution execution
 CROSS JOIN LATERAL (
   WITH record_scope AS MATERIALIZED (
     SELECT r.id,r.tenant_id,r.object_id,r.operation_id,r.form_id,r.copy_id,r.template_name,r.instance_no,
            r.created_by,r.created_by_id,r.created_at,o.status AS object_status,w.status AS work_order_status
     FROM form_instance_record r JOIN production_object o ON o.id=r.object_id AND o.tenant_id=r.tenant_id
     JOIN work_order w ON w.id=o.work_order_id AND w.tenant_id=o.tenant_id
     WHERE r.object_id=execution.object_id AND r.tenant_id='default' KEYWORD
   ), parsed_state AS MATERIALIZED (
     SELECT CAST(execution.state_json AS jsonb) AS state_json WHERE EXISTS (SELECT 1 FROM record_scope)
   ), progress_records AS MATERIALIZED (
     SELECT r.*,s.progress FROM record_scope r CROSS JOIN parsed_state e
     CROSS JOIN LATERAL (SELECT e.state_json #> ARRAY['operations',r.operation_id,'forms',r.copy_id] AS progress) s
     WHERE jsonb_typeof(s.progress)='object'
   ), parsed_snapshot AS MATERIALIZED (
     SELECT CAST(execution.snapshot_json AS jsonb) AS snapshot_json WHERE EXISTS (SELECT 1 FROM progress_records)
   ), form_catalog AS MATERIALIZED (
     SELECT op->>'id' AS operation_id,f->>'id' AS form_id,
            jsonb_build_object('flow',f->'flow','sourceType',f->'sourceType') AS f
     FROM parsed_snapshot e CROSS JOIN LATERAL jsonb_array_elements(e.snapshot_json->'operations') op
     JOIN (SELECT DISTINCT operation_id FROM progress_records) wanted ON wanted.operation_id=op->>'id'
     CROSS JOIN LATERAL jsonb_array_elements(op->'forms') f
   )
   SELECT_PLACEHOLDER
   FROM progress_records r CROSS JOIN parsed_state e
   JOIN form_catalog c ON c.operation_id=r.operation_id AND c.form_id=r.form_id
   CROSS JOIN LATERAL (SELECT r.progress AS progress) s
   WHERE jsonb_array_length(COALESCE(f->'flow'->'nodes','[]'::jsonb))>0 WHERE_PLACEHOLDER
 ) projected
 """.replace('KEYWORD',keyword).replace('SELECT_PLACEHOLDER',select).replace('WHERE_PLACEHOLDER',where)
 return sql[:start]+lateral+sql[end:]
def run(container,db,out):
 def pg(sql,label):
  (out/(label+'.sql')).write_text(sql+'\n')
  result=subprocess.run(['docker','exec','-i',container,'psql','-XqAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],input=sql,text=True,capture_output=True)
  (out/(label+'.stdout')).write_text(result.stdout);(out/(label+'.stderr')).write_text(result.stderr)
  if result.returncode:raise RuntimeError(label+': '+result.stderr[-2000:])
  return result.stdout.strip()
 old_events=[json.loads(x) for x in pathlib.Path('/tmp/edhr-central-list-20261105/native-focused/observations.jsonl').read_text().splitlines()]
 def get_event(kind,predicate):return next(e for e in old_events if e['kind']==kind and predicate(e['data']))
 cases=[('logs',get_event('central-list-scale',lambda d:d['objects']==1 and d['formsPerObject']==1 and not d['runningOnly'])),('interventions',get_event('central-list-scale',lambda d:d['objects']==1 and d['formsPerObject']==1 and d['runningOnly']))]
 cases.extend([('exact-form',get_event('central-list-filters',lambda d:d.get('keyword')=='form-2000001')),('workflow-only',get_event('central-list-filters',lambda d:d.get('keyword')=='READ-OBS-1'))])
 all_results=[]
 for objects,forms in [(1,1),(1,300),(30,100)]:
  seed="""
 TRUNCATE material,form_template,route,dhr_template,production_execution,production_object,work_order,product_process_version,product_process CASCADE;
 INSERT INTO material(id,code,name) VALUES(910101,'READ-PRODUCT','读取观测产品');
 INSERT INTO route(id,code,name) VALUES(910102,'READ-ROUTE','读取观测路线');
 INSERT INTO route_version(id,route_id,version,code) VALUES(910103,910102,'1','READ-RV');
 INSERT INTO dhr_template(id,code,name) VALUES(910104,'READ-DHR','读取观测目录');
 INSERT INTO dhr_template_version(id,dhr_template_id,version_label) VALUES(910105,910104,'1');
 INSERT INTO product_process(id,owner_type,owner_id) VALUES(910106,'PRODUCT',910101);
 INSERT INTO product_process_version(id,product_process_id,version_label,production_mode,production_form,route_version_id,dhr_template_version_id) VALUES(910107,910106,'1','量产','批次',910103,910105);
 INSERT INTO work_order(id,order_no,product_id,planned_quantity) VALUES(910108,'READ-WO',910101,1);
 INSERT INTO production_object(id,work_order_id,object_no,object_type,process_version_id,target_quantity,status)
 SELECT 910109+n,910108,'CENTRAL-'||n,'BATCH',910107,1,'IN_PROGRESS' FROM generate_series(0,OBJECTS-1)n;
 INSERT INTO form_template(id,code,name) VALUES(910110,'READ-FORM','读取观测表单');
 INSERT INTO form_template_version(id,template_id) VALUES(910111,910110);
 WITH forms AS (
 SELECT n,'f-'||n fid,jsonb_build_object('id','f-'||n,'versionId','910111','sourceType','ROUTE',
  'flow','{"nodes":[{"id":"fill","data":{"kind":"START"}},{"id":"review","data":{"kind":"APPROVAL"}}]}'::jsonb,
  'fields',(SELECT jsonb_agg(jsonb_build_object('id','field-'||f,'type','text','label','现场记录字段'||f)) FROM generate_series(0,9)f)) f,
  '{"status":"ACTIVE","active":["review"],"approvers":{"review":["42"]},"restrictedApprovers":{"review":true}}'::jsonb progress
 FROM generate_series(0,FORMS-1)n),payload AS (
 SELECT jsonb_build_object('operations',jsonb_build_array(jsonb_build_object('id','op','forms',jsonb_agg(f)))) snapshot,
 jsonb_build_object('operations',jsonb_build_object('op',jsonb_build_object('status','IN_PROGRESS','forms',jsonb_object_agg(fid,progress))),'history','[]'::jsonb) state FROM forms)
 INSERT INTO production_execution(object_id,snapshot_json,state_json,started_at,updated_at)
 SELECT o.id,p.snapshot::text,p.state::text,'2026-01-02','2026-01-02' FROM production_object o CROSS JOIN payload p;
 INSERT INTO form_instance_record(id,tenant_id,instance_no,object_id,operation_id,form_id,copy_id,template_id,version_id,snapshot_json,values_json,status,created_at,updated_at,template_name,created_by_id,source_type)
 SELECT 2000000+(o.id-910109)*1000+n,'default','CENTRAL-'||(o.id-910109)||'-'||n,o.id,'op','f-'||n,'f-'||n,910110,910111,'{}','{}','IN_REVIEW','2026-01-02','2026-01-02','中央列表表单','41','ROUTE'
 FROM production_object o CROSS JOIN generate_series(0,FORMS-1)n;
 UPDATE workflow_instance SET started_at='2026-01-03' WHERE id=900100;
 ANALYZE form_instance_record;ANALYZE production_execution;ANALYZE production_object;ANALYZE work_order;ANALYZE workflow_instance;
 """.replace('OBJECTS',str(objects)).replace('FORMS',str(forms))
  pg(seed,f'seed-{objects}-{forms}')
  local_cases=cases if forms>1 else cases[:2]
  for label,event in local_cases:
   for index,statement in enumerate(event['data']['statements']):
    old=numbered(statement['sql']);new=prototype(old);args=statement['parameters'];params='('+','.join(literal(v) for v in args)+')' if args else ''
    results={}
    for variant,query in [('baseline',old),('per-object',new)]:
     name=f'{objects}-{forms}-{label}-{index}-{variant}'
     value=json.loads(pg('PREPARE q AS SELECT COALESCE(jsonb_agg(to_jsonb(t)),\'[]\'::jsonb) FROM ('+query+')t; EXECUTE q'+params+';',name+'-result'))
     plan=json.loads(pg('PREPARE q AS '+query+'; EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE q'+params+';',name+'-plan'))[0]
     results[variant]={'result':value,'plan':plan}
    assert results['baseline']['result']==results['per-object']['result'],name
    row={'objects':objects,'formsPerObject':forms,'case':label,'query':'count' if index==0 else 'content','resultIdentical':True,
         'baselineMs':results['baseline']['plan']['Execution Time'],'optimizedMs':results['per-object']['plan']['Execution Time'],
         'optimizedTempBlocks':{k:results['per-object']['plan']['Plan'].get(k,0) for k in ['Temp Read Blocks','Temp Written Blocks']}}
    all_results.append(row);(out/'comparison.json').write_text(json.dumps(all_results,indent=2)+'\n');print(json.dumps(row),flush=True)
 # Low work_mem replay measures bounded disk-spill behaviour without a product memory claim.
 for index,statement in enumerate(cases[0][1]['data']['statements']):
  query=prototype(numbered(statement['sql']));args=statement['parameters'];params='('+','.join(literal(v) for v in args)+')' if args else ''
  pg("SET work_mem='64kB';PREPARE q AS "+query+'; EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE q'+params+';',f'low-work-mem-{index}')
