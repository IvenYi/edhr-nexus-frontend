import json,pathlib,hashlib,collections,sys
source=pathlib.Path(sys.argv[1]); destination=pathlib.Path(sys.argv[2])
events=[json.loads(x) for x in source.read_text().splitlines()]
def nodes(n):
 yield n
 for child in n.get('Plans',[]): yield from nodes(child)
scenarios=[]
for event in events:
 if not event['kind'].startswith('central-list-'): continue
 data=event['data']; plans=[]
 for statement in data.get('statements',[]):
  if 'plan' not in statement: continue
  plan=statement['plan'][0]; ns=list(nodes(plan['Plan']))
  plans.append({'kind':'count' if statement['sql'].startswith('SELECT count(*)') else 'content',
   'executionMs':plan['Execution Time'],'planningMs':plan['Planning Time'],
   'rootBuffers':{k:plan['Plan'][k] for k in ['Shared Hit Blocks','Shared Read Blocks','Temp Read Blocks','Temp Written Blocks'] if k in plan['Plan']},
   'functionScans':[{k:n[k] for k in ['Node Type','Alias','Function Name','Actual Loops','Actual Rows','Rows Removed by Filter'] if k in n} for n in ns if n['Node Type']=='Function Scan'],
   'memoize':[{k:n[k] for k in ['Actual Loops','Cache Hits','Cache Misses','Cache Evictions','Cache Overflows','Peak Memory Usage'] if k in n} for n in ns if n['Node Type']=='Memoize'],
   'joinFilters':[{k:n[k] for k in ['Join Filter','Rows Removed by Join Filter','Actual Loops','Actual Rows'] if k in n} for n in ns if n.get('Rows Removed by Join Filter',0)>0],
   'sorts':[{k:n[k] for k in ['Actual Rows','Sort Key','Sort Method','Sort Space Used','Sort Space Type'] if k in n} for n in ns if n['Node Type']=='Sort']})
 scenarios.append({'kind':event['kind'],'input':{k:v for k,v in data.items() if k!='statements'},'requestElapsedMs':event['elapsedNanos']/1e6,'logicalSelects':event['totalStatements'],'countSelects':sum(s.startswith('SELECT count(*)') for s in event['jdbcSql']),'plans':plans})
report={'source':str(source),'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'allObservationEvents':len(events),'allLogicalSelects':sum(e['totalStatements'] for e in events),
 'centralEvents':len(scenarios),'centralLogicalSelects':sum(s['logicalSelects'] for s in scenarios),
 'centralCountSelects':sum(s['countSelects'] for s in scenarios),'separateExplainReplays':sum(len(s['plans']) for s in scenarios),
 'scenarios':scenarios,'limits':['single disposable PG16 synthetic fixture, one measured request per scenario, no percentile/SLA claim','scale fixtures have ten text-field descriptors, one operation and two flow nodes; direct persistence does not test creation/START','EXPLAIN ANALYZE executes separate warm replays, not included in logical request counts','not all network SQL, no full multi-tenant or production concurrency matrix','only list-path query-local snapshot reuse; no index, API, knowledge or UI changes; OS memory samples reported separately']}
destination.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['scenarios','limits']},ensure_ascii=False))
for s in scenarios:
 if s['kind']=='central-list-scale': print(s['input'],round(s['requestElapsedMs'],2),[p['executionMs'] for p in s['plans']])
