import pathlib,json
out=pathlib.Path('/tmp/edhr-central-reuse-driver-quality-20261105');events=[json.loads(l) for l in (out/'native/observations.jsonl').read_text().splitlines()]
def nodes(n):
 yield n
 for c in n.get('Plans',[]):yield from nodes(c)
rows=[]
for e in events:
 for statement in e['data'].get('statements',[]):
  if 'plan' not in statement:continue
  p=statement['plan'][0];ns=list(nodes(p['Plan']));f=sum(n.get('Actual Rows',0)*n.get('Actual Loops',0) for n in ns if n.get('Node Type')=='Function Scan' and n.get('Alias')=='f');contexts=sum(n.get('Actual Loops',0) for n in ns if n.get('Subplan Name')=='CTE record_scope')
  if e['kind']=='central-list-scale':assert f==e['data']['objects']*e['data']['formsPerObject']
  if e['kind']=='central-list-sparse-executions':assert contexts==1
  if e['kind']=='central-list-work-memory':
   assert f==3000
   if e['data']['workMem']=='4MB':assert p['Plan'].get('Temp Written Blocks',0)==0
   else:assert p['Plan'].get('Temp Written Blocks',0)>0
  rows.append({'kind':e['kind'],'input':{k:v for k,v in e['data'].items() if k not in ['statements','plansAreSeparateReplays']},'query':'count' if statement['sql'].startswith('SELECT count(*)') else 'content','requestElapsedMs':e['elapsedNanos']/1e6,'executionMs':p['Execution Time'],'formCandidates':f,'initializedContexts':contexts,'tempReadBlocks':p['Plan'].get('Temp Read Blocks',0),'tempWrittenBlocks':p['Plan'].get('Temp Written Blocks',0)})
assert len(rows)==76
summary={'candidate':'8a72398cbe3cf404fcddee9d1cef251f3ebc75dd','planReplays':len(rows),'allScaleBudgetsMeasuredNotJustZeroFallback':True,'sparseContextsMeasuredEqualOne':True,'workMemResultsAndSpillVerified':True,'rows':rows,'limits':['single synthetic request/plan replay, no percentile or production SLA','plan replay timings are separate from request elapsed','Buffers/temp statistics are not total peak memory; OS evidence separately reviewed','direct seeded runtime snapshots/authentication, no creation/START/browser claim']}
(out/'native-performance.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print({k:v for k,v in summary.items() if k not in ['rows','limits']})
