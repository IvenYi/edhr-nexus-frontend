# 最终 driver 候选独立验收

实际候选 `8a72398cbe3cf404fcddee9d1cef251f3ebc75dd`，目标 `b52138259111dd5a0d99299087913500eff627f4`；契约在候选实际读取，开始及结束 fetch 后目标无增量。候选已包含目标，受测合并候选即该候选。自有 detached 工作树运行前后源指纹一致，构建用依赖软链移除后全树 clean；未修改产品、测试、夹具或配置。

## 原始源码与规范核对

用户明确同意先验证资源边界再局部复用快照；当前 decisionPackage 的L2影响范围与2个产品读取文件、1个opt-in观察测试及研发证据一致。DEC0093-01/04与domain-projection规定复用既有领域运行事实，工程SQL优化不新增任务、动作或政策。DEC0092-05的旧未开放范围按DEC0093作局部替代，不能恢复历史DHR全面排除；DEC0095的完整人员续页不回退。

从原始 diff 核：共享FROM逐字相同，FormWorkflowOperations从visibility起直到文件末尾逐字相同，WorkflowOperationsQuery从detail起尾部逐字相同；前端/API控制器/迁移/初始化/索引/知识/架构/契约无改动。350知识不变不等于350语义通过。原13条有限核对与driver重核3条子集分别保留，未累计16 unique或升级0.3.25/schema1.2/P0状态。

新外层DISTINCT仅去重default表单记录的object_id以驱动执行上下文；execution对象主键使原本每个对象唯一，记录、copy和快照op/form条目仍各自保留。目录只保存ID/flow/sourceType，state/snapshot仍从同一对象的执行快照读取，未改用记录表的状态、来源或快照。记录关键词按同一转义pattern预筛，外层原两源筛选仍执行；所有值参数绑定。对象/工单、DHR摘要锁及ACTIVE只是同一SQL中前移，CUSTOM/ROUTE、当前节点及visibility保持；COUNT和内容仍由同源查询，精确总数、SQL排序/分页未删改。

## 实际独立运行

- 原生PostgreSQL16：中央26（含0/1000/10000稀疏）+记录控制55+普通转办24=105/105，0F/E/S。直接运行当前候选，fresh XML逐项复算，未累加主侧203、旧200/102或先前900质量。
- 正式知识模块89/89，0F/E/S，仅其自动校验覆盖。
- 自有观察库50事件98请求SELECT（49COUNT），16 SQL签名与数据库日志逐次计数吻合。76次EXPLAIN独立回放、25初始化SELECT与2次SHOW work_mem分列；其他库语句未混算为业务请求。Liquibase空库databasechangeloglock探测1次是已知初始化错误，无其他意外观察库错误。
- 独立实际计划确认1×300每SQL有300个f候选、30×100有3000，严格复算为真实正数而非未找到别名后的0兜底；稀疏3例每SQL的record_scope生产节点Actual Loops均为1。
- SET LOCAL work_mem的两例处于Spring测试事务中，SHOW确认64kB/4MB，COUNT/内容及EXPLAIN同连接。4MB无临时块，64kB有临时块且结果一致；没有修改生产GUC。

## 健壮性、抽取及限制

新增预算监测实际数据库工作量，业务断言覆盖同form跨作业/两个copy不同状态、execution来源、重复快照行、精确/空查询、不相关异常JSON、无记录/无进度、对象工单/CUSTOM/ROUTE与DHR摘要锁。原触发器和FK未关闭；首次夹具不能写入非法snapshot的原件保留，后续合法落库异常结构用于验证排除范围。没有通过吞错补空来绕开匹配数据的解析要求。

guard与物化分别对应实际scope/进度/宽JSON工作量，并非无限重试或跨请求缓存。原COUNT null兜底和visibilityArgs再次推导是旧维护事项，不与本修复混做清理。主审给出了Scope(sql,args)及FormWorkflowProjectionQuery的具体未来边界，本批保留局部SQL模板及写事务所有权，无大模块重构。

本次是直接服务、合成认证及持久化快照实验，不覆盖创建/START、真实登录、完整HTTP账号/并发生产/多租户矩阵或浏览器；前端字节不变所以没有新UI验证声明。实际请求与独立计划回放时间不同，单次合成耗时不能承诺生产SLA。内存原件为新后端VmHWM（含连接/JIT/共享映射）和私有采样下界，EXPLAIN缓冲/临时块不代表总峰值或生产并发容量。

精确/空关键词仍需定位default已引用对象集合；在极大历史对象、复杂history和权限分布上的扫描成本未由当前规模证明。当前SQL保持正确性与已测两个预算；完整生产分布、history逐记录成本、第三文本ID索引以及原W2-W7/931知识/86UI/高风险及暂停范围继续，不能据此宣称全仓审计完成。
