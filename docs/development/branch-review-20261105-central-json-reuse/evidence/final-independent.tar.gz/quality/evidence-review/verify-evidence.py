import pathlib,json,hashlib,tarfile,subprocess,xml.etree.ElementTree as ET,re,datetime,collections,yaml
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path(__file__).parent
BASE='b52138259111dd5a0d99299087913500eff627f4'
HEAD='8a72398cbe3cf404fcddee9d1cef251f3ebc75dd'
DOC=ROOT/'docs/development/branch-review-20261105-central-json-reuse'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=ROOT)
def load_archive(name,meta_name):
 path=DOC/'evidence'/name;meta=json.loads((DOC/'evidence'/meta_name).read_text());raw=path.read_bytes()
 assert len(raw)==meta['bytes'] and sha(raw)==meta['sha256']
 with tarfile.open(path) as tar:
  members={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
 assert len(members)==meta['archiveMemberCount']
 manifest=json.loads(members['manifest.json']);assert len(manifest['files'])==meta['rawFileCount']
 for row in manifest['files']:
  raw=members[row['path']];assert len(raw)==row['bytes'] and sha(raw)==row['sha256'],row['path']
 return members,{'name':name,'files':len(manifest['files']),'sha256':meta['sha256'],'members':len(members)}
def j(archive,path):return json.loads(archive[path])
def xml_totals(archive,prefix):
 total={k:0 for k in ['tests','failures','errors','skipped']};cases=[]
 for path,raw in archive.items():
  if path.startswith(prefix+'/TEST-') and path.endswith('.xml'):
   root=ET.fromstring(raw)
   for key in total:total[key]+=int(root.attrib.get(key,0))
   cases.extend(root.findall('testcase'))
 return total,cases
def walk(node):
 yield node
 for child in node.get('Plans',[]):yield from walk(child)
def method(source,name):
 m=re.search(r'(?m)^    (?:private(?: static)? [^\n]+|void) '+re.escape(name)+r'\(',source);assert m,name
 start=m.start();i=source.index('{',m.end());depth=0;mode=None
 while i<len(source):
  if mode=='text':
   if source.startswith('"""',i):mode=None;i+=3;continue
  elif mode in ['string','char']:
   if source[i]=='\\':i+=2;continue
   if source[i]==('"' if mode=='string' else "'"):mode=None
  elif mode=='line':
   if source[i]=='\n':mode=None
  elif mode=='comment':
   if source.startswith('*/',i):mode=None;i+=2;continue
  elif source.startswith('"""',i):mode='text';i+=3;continue
  elif source.startswith('//',i):mode='line';i+=2;continue
  elif source.startswith('/*',i):mode='comment';i+=2;continue
  elif source[i]=='"':mode='string'
  elif source[i]=="'":mode='char'
  elif source[i]=='{':depth+=1
  elif source[i]=='}':
   depth-=1
   if depth==0:return source[start:i+1]
  i+=1
 raise ValueError(name)

assert git('rev-parse','HEAD')==HEAD and git('rev-parse','origin/edhr-dev')==BASE
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md']
read_paths=contracts+['docs/development/branch-review-20261105-central-list/decision-package.yaml',
 'docs/development/branch-review-20261105-central-json-reuse/user-confirmed.md',
 'docs/development/branch-review-20261105-central-json-reuse/README.md',
 'docs/development/branch-review-20261105-central-json-reuse/review-notes.md',
 'docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/architecture/business-knowledge-model.md',
 'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
 'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
 'docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml',
 'docs/knowledge/rules/workflow-central-entry.yaml','docs/knowledge/rules/personnel-target-selection.yaml']
fp=[]
for path in read_paths:
 b=blob(HEAD,path);d=OUT/'read-snapshots'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 fp.append({'path':path,'bytes':len(b),'sha256':sha(b)})
for path in contracts:assert blob(BASE,path)==blob(HEAD,path)
package=yaml.safe_load(blob(HEAD,read_paths[4]))['decisionPackage'];assert package['impactAnalysis']['level']=='L2' and not package['unresolved']
for field in ['directImpacts','transitiveImpacts','potentialImpacts','unaffectedAreas','compatibilityAndMigration','snapshotImpacts','auditImpacts','permissionImpacts','testImpacts','evidenceGaps']:assert field in package['impactAnalysis']
assert '好的，那么按你建议的来' in blob(HEAD,read_paths[5]).decode()
A,am=load_archive('primary-ontology-and-design.tar.gz','primary-manifest.json')
B,bm=load_archive('driver-fix-and-first-quality.tar.gz','driver-manifest.json')
checks=[{'id':'check.contract-scope-and-approval','outcome':'passed','evidence':'actual candidate contracts, confirmed engineering-only scope and full L2 impact fields'},
 {'id':'check.archive-integrity','outcome':'passed','evidence':[am,bm]}]

totals,cases=xml_totals(B,'primary/native-full2');assert totals=={'tests':203,'failures':0,'errors':0,'skipped':0}
assert totals==j(B,'primary/native-full2/test-summary.json')['totals']
source=j(B,'primary/native-full2/run.json')
source_checks=[]
for row in source['sourceFingerprints']:
 raw=blob(HEAD,row['path']);assert sha(raw)==row['sha256'] and len(raw)==row['bytes'];source_checks.append({'path':row['path'],'sha256':sha(raw),'matchesFinalNative':True})
assert source['commit']=='d32b99c54b0d65bd2717274ee39135927b423acb'
checks.append({'id':'check.main203-fresh-source','outcome':'passed','evidence':{'xml':totals,'originalRunCommit':source['commit'],'sourceFingerprints':source_checks,'workingTreeSourceDiffWasFingerprinted':True}})

events=[json.loads(line) for line in B['primary/native-full2/observations.jsonl'].splitlines()]
central=[e for e in events if e['kind'].startswith('central-list-')]
assert len(events)==140 and sum(e['totalStatements'] for e in events)==394
assert len(central)==50 and sum(e['totalStatements'] for e in central)==98
assert sum(sql.startswith('SELECT count(*)') for e in central for sql in e['jdbcSql'])==49
plans=[s for e in central for s in e['data'].get('statements',[]) if 'plan' in s];assert len(plans)==76
catalog=[];sparse=[];memoryplans=[]
for e in central:
 for s in e['data'].get('statements',[]):
  if 'plan' not in s:continue
  p=s['plan'][0];nodes=list(walk(p['Plan']))
  f=sum(n.get('Actual Rows',0)*n.get('Actual Loops',0) for n in nodes if n.get('Node Type')=='Function Scan' and n.get('Alias')=='f')
  if e['kind']=='central-list-scale' and e['data']['formsPerObject'] in (100,300):
   target=e['data']['objects']*e['data']['formsPerObject'];assert f==target
   catalog.append({'objects':e['data']['objects'],'formsPerObject':e['data']['formsPerObject'],'runningOnly':e['data']['runningOnly'],'query':'count' if s['sql'].startswith('SELECT count(*)') else 'content','expanded':f})
  if e['kind']=='central-list-sparse-executions':
   n=sum(n.get('Actual Loops',0) for n in nodes if n.get('Subplan Name')=='CTE record_scope');assert n==1
   sparse.append({'unrecorded':e['data']['unrecordedExecutions'],'contextInitializations':n})
  if e['kind']=='central-list-work-memory':
   temps={key:p['Plan'].get(key,0) for key in ['Temp Read Blocks','Temp Written Blocks']}
   if e['data']['workMem']=='4MB':assert temps=={'Temp Read Blocks':0,'Temp Written Blocks':0}
   else:assert temps['Temp Written Blocks']>0
   memoryplans.append({'workMem':e['data']['workMem'],'temps':temps})
assert len(sparse)==6 and sorted(set(s['unrecorded'] for s in sparse))==[0,1000,10000]
assert len(catalog)==8 and len(memoryplans)==4
checks.append({'id':'check.observation-plan-math','outcome':'passed','evidence':{'events':140,'logicalSelects':394,'centralEvents':50,'centralSelects':98,'countSelects':49,'separateExplainReplays':76,'catalog':catalog,'sparse':sparse,'workMemory':memoryplans}})

negative,cases=xml_totals(B,'primary/native-drivernegative');assert negative=={'tests':3,'failures':2,'errors':0,'skipped':0}
failed=[c.find('failure') for c in cases if c.find('failure') is not None];assert len(failed)==2
assert all('unrecorded executions must not initialize form-query contexts' in ((f.text or '')+f.attrib.get('message','')) for f in failed)
for value in ['1001L','10001L']:assert any(value in ((f.text or '')+f.attrib.get('message','')) for f in failed)
testpath='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java'
assert B['primary/native-drivernegative/source/'+testpath]==blob(HEAD,testpath)
formpath='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java'
assert B['primary/native-drivernegative/source/'+formpath]==blob('d32b99c54b0d65bd2717274ee39135927b423acb',formpath)
old,cases=xml_totals(A,'primary/native-negative');assert old=={'tests':4,'failures':3,'errors':0,'skipped':0}
old_failed=[c.find('failure') for c in cases if c.find('failure') is not None]
assert all('form catalog expansion must grow with frozen entries, not their square' in ((f.text or '')+f.attrib.get('message','')) for f in old_failed)
for value in ['900L','90000L','300000L']:assert any(value in ((f.text or '')+f.attrib.get('message','')) for f in old_failed)
oldtest=A['primary/native-negative/source/'+testpath].decode();first=A['primary/final-source/'+testpath].decode();same=[]
for row in j(A,'primary/negative-selected-byte-guards.json')['selectedMethods']:
 n=row['method'];a=method(oldtest,n);b=method(first,n);assert a==b and sha(b.encode())==row['sha256'];same.append(n)
assert oldtest!=blob(HEAD,testpath).decode()
checks.append({'id':'check.negative-control-truth','outcome':'passed','evidence':{'driver':negative,'driverWholeFinalTestClassSame':True,'oldCatalog':old,'oldCatalogSelectedMethodsSameForD32':same,'oldCatalogWholeFinalClassSame':False}})

mem=j(B,'primary/memory-driver/summary.json');assert mem==json.loads((DOC/'memory-report.json').read_text())
pairs={}
for row in mem['results']:pairs.setdefault((row['objects'],row['formsPerObject'],row['runningOnly']),{})[row['variant']]=row
deltas=[]
for key,rows in pairs.items():
 assert set(rows)=={'baseline','optimized'} and all(r['repetitions']==3 and r['samples']>0 and r['privateSampleAvailable'] for r in rows.values())
 deltas.append(rows['optimized']['kernelPeakRssKiB']-rows['baseline']['kernelPeakRssKiB'])
assert len(pairs)==4 and sum(d<0 for d in deltas)==3 and max(deltas)==416
assert any('not a production' in text for text in mem['limits'])
sparse_comparison=j(B,'primary/sparse-executions/summary.json');assert len(sparse_comparison)==9
for p,raw in B.items():
 if p.startswith('primary/sparse-executions/') and p.endswith('-result.stdout'):
  data=json.loads(raw);assert len(data)==1 and data[0]['id']=='form-2000000'
checks.append({'id':'check.resource-and-sparse-evidence','outcome':'passed','evidence':{'rssDeltasKiB':deltas,'freshBackendPairs':len(pairs),'rssIncludesSessionAndJit':True,'privateSamplePeakIsLowerBound':True,'sparseComparisons':len(sparse_comparison),'productionSlaClaimed':False}})

before=blob(BASE,formpath).decode();after=blob(HEAD,formpath).decode()
assert before.split('private static final String FROM = """',1)[1].split('""";',1)[0]==after.split('private static final String FROM = """',1)[1].split('""";',1)[0]
assert before.split('    private String visibility() {',1)[1]==after.split('    private String visibility() {',1)[1]
querypath='gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java'
assert blob(BASE,querypath).decode().split('    public Map<String, Object> detail(Long id) {',1)[1]==blob(HEAD,querypath).decode().split('    public Map<String, Object> detail(Long id) {',1)[1]
protected=['gmp-platform/frontend','gmp-platform/backend/src/main/resources','docs/knowledge','docs/architecture','AGENTS.md','codeplzreadme.md','docs/agents','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java']
assert not git('diff','--name-only',BASE,HEAD,'--',*protected)
assert set(git('diff','--name-only',BASE,HEAD,'--','gmp-platform/backend/src/main/java').splitlines())=={formpath,querypath}
assert git('diff','--name-only',BASE,HEAD,'--','gmp-platform/backend/src/test')==testpath
checks.append({'id':'check.protected-source-regions','outcome':'passed','evidence':{'sharedFromAndFormVisibilityTailSame':True,'queryDetailTailSame':True,'frontendAndKnowledgeAndApiResourcesUnchanged':True,'personnelDirectoryUnchanged':True}})

ontology=[json.loads(l) for l in A['ontology/audit-records.jsonl'].splitlines()];delta=[json.loads(l) for l in B['ontology-driver/delta-records.jsonl'].splitlines()]
assert len(ontology)==13 and collections.Counter(x['conclusion'] for x in ontology)=={'consistent':11,'superseded':1,'evidence-gap':1}
assert len(delta)==3 and len({x['id'] for x in delta})==3 and {x['id'] for x in delta}<={x['id'] for x in ontology}
knowledge=git('ls-tree','-r','--name-only',HEAD,'docs/knowledge').splitlines();assert len(knowledge)==350
assert yaml.safe_load((DOC/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
base_review=json.loads((DOC/'baseline-review.json').read_text());assert base_review['wholeFileComplete']==0 and base_review['wholeAuditComplete'] is False and base_review['historicalUniqueCoverage'] is None
assert base_review['targetTrackedPaths']==len(git('ls-tree','-r','--name-only',BASE).splitlines())==7529
checks.append({'id':'check.finite-ontology-and-audit-scope','outcome':'passed','evidence':{'originalFiniteIds':13,'deltaExistingSubset':3,'uniqueStill13':True,'knowledgeFiles':350,'wholeFileComplete':0,'wholeAuditComplete':False}})
phase1=j(B,'phase1-quality/summary.json');assert phase1['testedCommit']=='d32b99c54b0d65bd2717274ee39135927b423acb' and phase1['result']=='passed'
assert phase1['native']==102 and phase1['knowledge']==89
checks.append({'id':'check.history-not-reused-as-final','outcome':'passed','evidence':{'phase1PassedOnlyFor':phase1['testedCommit'],'doesNotCoverCurrent':HEAD}})
result={'role':'final-driver-evidence-subcheck','status':'FINAL','result':'passed','isFinalQualityResult':False,'baseCommit':BASE,'headCommit':HEAD,'contractReadCommit':HEAD,'uncommittedContractPaths':[],'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'limits':['No native tests, knowledge tool or browser executed by this subcheck; parent final verifier owns runtime checks','Original archived measurements inspected, not independently regenerated','Only declared finite IDs/protected regions, not whole repository semantic or release audit'],'changedProductTestConfigFiles':[],'sourceReadFingerprints':fp}
(OUT/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'result':result['result'],'checks':len(checks),'findings':result['findings'],'archiveFiles':[am['files'],bm['files']]},ensure_ascii=False))
