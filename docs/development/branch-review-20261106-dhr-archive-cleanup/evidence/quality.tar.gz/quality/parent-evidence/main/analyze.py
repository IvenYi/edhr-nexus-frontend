from pathlib import Path
import json,hashlib,subprocess,re,xml.etree.ElementTree as ET,shutil
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-archive-cleanup-20261106');base='2cb85492b2dbf47f5b837c565eecc5832b62b39a';out={'baseline':base,'runs':{}}
for phase,wanted in [('negative',dict(tests=13,failures=6,errors=0,skipped=0)),('final',dict(tests=85,failures=0,errors=0,skipped=0))]:
 p=raw/phase;a=json.loads((p/'test-summary.json').read_text());assert a['totals']==wanted;out['runs'][phase]=a
 assert not json.loads((p/'temporary-archives.json').read_text())['leftovers']
out['negativeControls']={}
for name in ['DhrArchiveCleanupFailureTest.java','DhrArchiveControllerStreamingTest.java']:
 before=list((raw/'negative/source').rglob(name))[0].read_bytes();after=list((raw/'final/source').rglob(name))[0].read_bytes();assert before==after;out['negativeControls'][name]=hashlib.sha256(after).hexdigest()
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']:
 assert (raw/'negative/source'/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=r)
fingers=json.loads((raw/'final/run.json').read_text())['sourceFingerprints']
for x in fingers:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
out['finalInputsStillIdentical']=len(fingers);out['oldRuntimeMatchesGitBaseline']=True
failureTypes=[]
for f in (raw/'negative').glob('TEST-*.xml'):
 for x in ET.parse(f).getroot().iter('failure'):failureTypes.append(x.attrib['type'])
assert len(failureTypes)==6 and all('Assertion' in x for x in failureTypes);out['negativeFailureTypes']=failureTypes
p=raw/'final';a=[json.loads(x) for x in (p/'observations/observations.jsonl').read_text().splitlines()];assert len(a)==11
out['nativeObservations']={'events':len(a),'instrumentedSelects':sum(x['selectStatements'] for x in a),'eventsData':a,'scope':'Existing observer calling-thread SELECTs; no per-event server SQL marker, not an exact attribution of all network SQL.'}
sql=(p/'postgres.log').read_text();inserts=re.findall(r'execute [^:]+: (insert into audit_event[^\n]+)',sql,re.I);assert len(inserts)==3;out['serverExportAuditInsertExecutions']=len(inserts)
command=['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(raw/'ReadExportJfr.java'),str(p/'observations'),str(p/'vm-tmp')];result=subprocess.run(command,capture_output=True,text=True,check=True);(raw/'jfr-recalculation.tsv').write_text(result.stdout);(raw/'jfr-recalculation.stderr').write_text(result.stderr)
byName={x['name']:x for x in a};checks=[]
for line in result.stdout.splitlines():
 name,b,n,paths=line.split('\t');key=name.removesuffix('.jfr');obs=byName[key];assert int(b)==obs['trackedLogicalReadBytes'] and int(n)==obs['trackedReadEvents'];assert int(paths)<=1
 checks.append({'name':key,'bytes':int(b),'events':int(n),'watchedPaths':int(paths),'matchesOriginalObserver':True})
assert len(checks)==11;out['jfrIndependentRecalculation']=checks
originalCleanup=json.loads((p/'cleanup.json').read_text());out['containerCleanupInitialObservation']=originalCleanup
if not originalCleanup['removed']:
 finalCleanup=json.loads((p/'cleanup-final-verification.json').read_text());assert finalCleanup['removed'];out['containerCleanupFollowup']=finalCleanup
out['ownedResourcesClean']=True;out['limits']=['FS fault tests are opt-in real Linux owned-path replacement, not disk-loss/permission injection on other OS','New lifecycle tests mock database/renderer/qualification; native12 use actual canonical PG/frozen integrity/archive/merge/audit but renderer is mocked','No full HTTP async/timeout/cancellation/never-started body, UNKNOWN persistence reconciliation or capacity closure','No product behavior/policy/index/paging changes except primary/cleanup error propagation']
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');shutil.copy2(raw/'analysis.json',r/'docs/development/branch-review-20261106-dhr-archive-cleanup/main-analysis.json')
print(json.dumps({'negative':out['runs']['negative']['totals'],'final':out['runs']['final']['totals'],'unchangedInputs':len(fingers),'observations':len(a),'measuredSelects':out['nativeObservations']['instrumentedSelects'],'serverAuditInserts':len(inserts),'jfrRecalculated':len(checks)},indent=2))
