from pathlib import Path,PurePosixPath
import json,hashlib,tarfile,subprocess,datetime,shutil,xml.etree.ElementTree as ET
r=Path('/tmp/edhr-archive-cleanup-qa-worktree-20261106');o=Path('/tmp/edhr-archive-cleanup-qa-20261106');d=r/'docs/development/branch-review-20261106-dhr-archive-cleanup';e=d/'evidence';base='2cb85492b2dbf47f5b837c565eecc5832b62b39a';head='a4777e9f6ef7518d8684a48516c21cf5904cff01'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
out={'baseline':{'base':base,'head':git('rev-parse','HEAD'),'target':git('rev-parse','origin/edhr-dev')},'archives':[],'checksums':[]}
assert out['baseline']['head']==head and out['baseline']['target']==base
for line in (e/'SHA256SUMS').read_text().splitlines():
 sha,name=line.split('  ',1);assert hashlib.sha256((e/name).read_bytes()).hexdigest()==sha;out['checksums'].append({'path':name,'sha256':sha})
for name in ['main','source']:
 m=json.loads((e/(name+'-manifest.json')).read_text());byPath={x['path']:x for x in m}
 with tarfile.open(e/(name+'.tar.gz')) as t:
  members={str(PurePosixPath(x.name).relative_to(name)):x for x in t.getmembers() if x.isfile()};assert set(members)==set(byPath)
  for path,x in byPath.items():
   assert not PurePosixPath(path).is_absolute() and '..' not in PurePosixPath(path).parts
   b=t.extractfile(members[path]).read();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],path
   p=o/'parent-evidence'/name/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 out['archives'].append({'name':name,'files':len(m),'allPathsBytesHashesMatch':True})
neg=o/'parent-evidence/main/negative';final=o/'parent-evidence/main/final'
assert json.loads((neg/'test-summary.json').read_text())['totals']==dict(tests=13,failures=6,errors=0,skipped=0)
assert json.loads((final/'test-summary.json').read_text())['totals']==dict(tests=85,failures=0,errors=0,skipped=0)
f=[]
for xml in neg.glob('TEST-*.xml'):
 for x in ET.parse(xml).getroot().iter('failure'):f.append(x.attrib['type'])
assert len(f)==6 and all('Assertion' in x for x in f)
same=[]
for test in ['DhrArchiveCleanupFailureTest.java','DhrArchiveControllerStreamingTest.java']:
 n=list((neg/'source').rglob(test))[0];p=list((r/'gmp-platform/backend/src/test/java').rglob(test))[0];assert n.read_bytes()==p.read_bytes();same.append(test)
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']:
 assert (neg/'source'/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=r)
out['negativeControls']={'tests':13,'failures':6,'errors':0,'skipped':0,'failureTypes':f,'testSourceIdentical':same,'oldProductSourcesEqualGitBase':True}
fps=json.loads((final/'run.json').read_text())['sourceFingerprints']
for x in fps:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
out['mainRunCandidateInputsIdentical']=len(fps)
out['cleanupProvenance']={'initial':json.loads((final/'cleanup.json').read_text()),'followup':json.loads((final/'cleanup-final-verification.json').read_text()),'runnerPostRunChange':json.loads((o/'parent-evidence/main/runner-post-run-change.json').read_text())}
assert out['cleanupProvenance']['initial']['removed']==False and out['cleanupProvenance']['followup']['removed']==True
knowledge=git('ls-files','docs/knowledge').splitlines();assert len(knowledge)==350;inventory=[]
assert git('diff','--name-only',base,head,'--','docs/knowledge')==''
for path in knowledge:
 b=(r/path).read_bytes();inventory.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(o/'knowledge-file-manifest.json').write_text(json.dumps(inventory,indent=2)+'\n');out['knowledge']={'count':len(knowledge),'allIdenticalToBase':True}
changed=git('diff','--name-only',base,head,'--','gmp-platform/backend/src/main').splitlines()
assert changed==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java']
assert git('diff','--name-only',base,head,'--','gmp-platform/frontend','gmp-platform/backend/src/main/resources','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture','docs/knowledge')==''
out['protectedScope']={'runtimeChanged':changed,'frontendSchemaKnowledgeContractsUnchanged':True}
k=o/'knowledge';start=json.loads((k/'started.json').read_text());stamp=datetime.datetime.fromisoformat(start['startedAt']).timestamp();totals=dict(tests=0,failures=0,errors=0,skipped=0)
for f in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 assert f.stat().st_mtime>=stamp;a=ET.parse(f).getroot().attrib
 for key in totals:totals[key]+=int(a[key])
 shutil.copy2(f,k/f.name)
assert totals==dict(tests=89,failures=0,errors=0,skipped=0);(k/'test-summary.json').write_text(json.dumps(totals,indent=2)+'\n');out['freshKnowledgeTotals']=totals
(o/'inspection.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archives':out['archives'],'negative':out['negativeControls'],'sameInputs':len(fps),'knowledge':totals},ensure_ascii=False,indent=2))
