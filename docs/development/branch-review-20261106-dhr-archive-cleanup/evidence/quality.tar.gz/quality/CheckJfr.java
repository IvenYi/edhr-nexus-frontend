import java.nio.file.*;
import java.util.*;
import jdk.jfr.consumer.*;
class CheckJfr {
 public static void main(String[] args)throws Exception{
  Path folder=Path.of(args[0]),root=Path.of(args[1]);
  for(Path file:Files.list(folder).filter(p->p.toString().endsWith(".jfr")).sorted().toList()){
   boolean zip=file.getFileName().toString().startsWith("archive-");long bytes=0,reads=0;Set<String> paths=new HashSet<>();
   try(var recording=new RecordingFile(file)){
    while(recording.hasMoreEvents()){
     RecordedEvent event=recording.readEvent();if(!event.getEventType().getName().equals("jdk.FileRead"))continue;
     String s=event.getString("path");if(s==null)continue;Path p=Path.of(s);
     boolean match=zip ? p.getParent().equals(root)&&p.getFileName().toString().startsWith("dhr-archive-")&&s.endsWith(".zip") : p.startsWith(root)&&p.getFileName().toString().equals("registered.png");
     if(match){bytes+=event.getLong("bytesRead");reads++;paths.add(s);}
    }
   }
   System.out.println(file.getFileName()+"\t"+bytes+"\t"+reads+"\t"+paths.size());
  }
 }
}
