from pathlib import Path
import hashlib,json,subprocess,re,datetime
root=Path('/tmp/edhr-archive-cleanup-qa-worktree-20261106');out=Path('/tmp/edhr-archive-cleanup-qa-source-20261106');head='a4777e9f6ef7518d8684a48516c21cf5904cff01';base='2cb85492b2dbf47f5b837c565eecc5832b62b39a'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==head
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml','docs/development/branch-review-20261106-dhr-archive-cleanup/README.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/BusinessException.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrPdfRenderer.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrArchiveCleanupFailureTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java']
manifest=[]
for p in paths:
 data=subprocess.check_output(['git','show',head+':'+p],cwd=root);assert (root/p).read_bytes()==data
 target=out/'source'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);manifest.append({'path':p,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
service='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java';controller='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java'
oldService=subprocess.check_output(['git','show',base+':'+service],cwd=root,text=True);newService=(root/service).read_text()
helper='''    private static void removeFailedArchive(Path zip, Exception failure) {
        try { Files.deleteIfExists(zip); }
        catch (IOException | RuntimeException cleanupFailure) {
            failure.addSuppressed(cleanupFailure);
            log.error("Failed to remove unsuccessful DHR export archive: path={}", zip, cleanupFailure);
        }
    }

'''
assert helper in newService
reconstructed=newService.replace('import lombok.extern.slf4j.Slf4j;\n','').replace('@Slf4j\n','').replace(helper,'').replace('removeFailedArchive(zip, ex);','Files.deleteIfExists(zip);')
assert reconstructed==oldService
oldController=subprocess.check_output(['git','show',base+':'+controller],cwd=root,text=True);newController=(root/controller).read_text()
reconstructed=newController.replace('import java.io.Closeable;\n','').replace('''            try (Closeable cleanup = () -> Files.deleteIfExists(zip)) {
                Files.copy(zip, output);
            }''','''            try { Files.copy(zip, output); }
            finally { Files.deleteIfExists(zip); }''')
assert reconstructed==oldController
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java'
oldTest=subprocess.check_output(['git','show',base+':'+test],cwd=root,text=True);newTest=(root/test).read_text()
def method(text,name):
 start=text.index('    @Test void '+name);nextTest=text.find('\n    @Test',start+1);end=nextTest if nextTest>=0 else text.index('\n    private',start)
 return text[start:end].rstrip()
originalTests=['successfulStreamReturnsExactArchiveAndDeletesOwnedTemporaryFile','interruptedOutputStillDeletesOwnedArchiveAndPropagatesTheFailure','invalidSelectedIdentityIsRejectedBeforeGeneratingAnArchive']
for name in originalTests:assert method(oldTest,name)==method(newTest,name)
runtime=git('diff','--name-only',base,head,'--','gmp-platform/backend/src/main').splitlines();assert runtime==[controller,service]
protected=git('diff','--name-only',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture','docs/knowledge','gmp-platform/frontend','gmp-platform/backend/src/main/resources');assert not protected
proof={'base':base,'head':head,'observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','runtimeChangedPaths':runtime,'serviceReconstructsBaseWithOnlyDocumentedChanges':True,'controllerReconstructsBaseWithOnlyDocumentedChanges':True,'oldThreeControllerTestMethodsUnchanged':originalTests,'protectedContractsKnowledgeUiSchemaUnchanged':True,'sourceSnapshotCount':len(manifest),'performed':['fixed source inspection','Python byte-equivalence proof only'],'notPerformed':['product tests','database','HTTP','browser','CI'],'workingTreeStateObserved':git('status','--porcelain')}
(out/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(out/'proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'snapshots':len(manifest),'runtime':runtime,'equivalence':True,'oldThreeTestsUnchanged':True},indent=2))
