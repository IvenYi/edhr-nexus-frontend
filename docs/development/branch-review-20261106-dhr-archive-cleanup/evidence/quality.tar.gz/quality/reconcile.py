from pathlib import Path
import json,re,subprocess,shutil,hashlib
o=Path('/tmp/edhr-archive-cleanup-qa-20261106');out={}
def pg_value(s):
 if s=='NULL':return None
 assert s.startswith("'") and s.endswith("'")
 return s[1:-1].replace("''", "'")
def audit_inserts(path):
 lines=path.read_text().splitlines();rows=[]
 for i,line in enumerate(lines):
  m=re.search(r'execute [^:]+: insert into audit_event \(([^)]+)\) values \(([^)]+)\)',line,re.I)
  if not m:continue
  assert 'parameters:' in lines[i+1]
  bindings=lines[i+1].split('parameters: ',1)[1];parts=re.split(r', (?=\$\d+ = )',bindings)
  args={}
  for p in parts:
   n,s=p.split(' = ',1);args[n]=pg_value(s)
  cols=m[1].split(',');params=re.findall(r'\$\d+',m[2]);assert len(cols)==len(params)
  row=dict(zip(cols,[args[p] for p in params]));assert row['action']=='EXPORT' and row['entity_type']=='DHR_SUMMARY_EXPORT' and row['entity_id']=='10'
  payload=json.loads(row['content_after']);assert payload['dhrId']=='1' and payload['versionId']=='10' and payload['scope']=='FULL';assert re.fullmatch('[0-9a-f]{64}',payload['archiveSha256'])
  assert row['snapshot_hash_version']=='audit-event-v2' and re.fullmatch('[0-9a-f]{64}',row['snapshot_hash']);rows.append({'id':row['id'],'action':row['action'],'entityType':row['entity_type'],'entityId':row['entity_id'],'archiveSha256':payload['archiveSha256'],'snapshotHashVersion':row['snapshot_hash_version'],'snapshotHash':row['snapshot_hash']})
 assert len(rows)==3
 return rows
def native(root):
 observations=[json.loads(x) for x in (root/'observations/observations.jsonl').read_text().splitlines()];assert len(observations)==11
 total=sum(x['selectStatements'] for x in observations);assert total==33
 command=json.loads((root/'run.json').read_text())['command'];argline=next(x for x in command if x.startswith('-DargLine='));watched=argline.split('-Djava.io.tmpdir=',1)[1]
 cmd=['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(o/'CheckJfr.java'),str(root/'observations'),watched]
 result=subprocess.run(cmd,capture_output=True,text=True,check=True);checks=[];byName={x['name']:x for x in observations}
 for line in result.stdout.splitlines():
  f,b,n,count=line.split('\t');name=f.removesuffix('.jfr');a=byName[name];assert int(b)==a['trackedLogicalReadBytes'] and int(n)==a['trackedReadEvents'];assert int(count)<=1
  checks.append({'name':name,'bytesRead':int(b),'readEvents':int(n),'watchedPaths':int(count),'matchesObserver':True})
 assert len(checks)==11
 return {'observations':len(observations),'observerSelects':total,'jfrChecks':checks,'exportAuditBindings':audit_inserts(root/'postgres.log'),'scope':'Observer calling-thread SELECTs, not per-event server attribution or all network SQL; JFR actual reads independently recomputed. Export audit payload hashes validated in actual binding format, not independently recomputed from deleted native ZIPs.'}
out['independent']=native(o/'final');out['parent']=native(o/'parent-evidence/main/final')
assert json.loads((o/'final/cleanup.json').read_text())['removed'];assert not json.loads((o/'final/temporary-archives.json').read_text())['leftovers']
out['independentOwnedResourcesClean']=True
(o/'reconciliation.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'independentObservations':11,'observerSelects':33,'independentAuditInserts':len(out['independent']['exportAuditBindings']),'independentJfrRecalculated':len(out['independent']['jfrChecks']),'parentJfrRecalculated':len(out['parent']['jfrChecks'])},indent=2))
