from pathlib import Path
import subprocess,json,hashlib,datetime,shutil,sys,xml.etree.ElementTree as ET
r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-cleanup-ontology-20261106');raw=Path(sys.argv[1]);candidate=sys.argv[2];base='2cb85492b2dbf47f5b837c565eecc5832b62b39a'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
assert len(candidate)==40 and git('rev-parse',candidate).decode().strip()==candidate
subprocess.run(['git','fetch','origin','edhr-dev'],cwd=r,stdout=(out/'final-fetch.log').open('w'),stderr=subprocess.STDOUT,check=True)
assert git('rev-parse','origin/edhr-dev').decode().strip()==base
assert not git('diff','--name-only',base,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture','gmp-platform/frontend','gmp-platform/backend/src/main/resources')
expected=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java']
assert git('diff','--name-only',base,candidate,'--','gmp-platform/backend/src/main').decode().splitlines()==expected
negative=json.loads((raw/'negative/test-summary.json').read_text());final=json.loads((raw/'final/test-summary.json').read_text())
assert negative['totals']==dict(tests=13,failures=6,errors=0,skipped=0)
assert final['totals']==dict(tests=85,failures=0,errors=0,skipped=0)
run=json.loads((raw/'final/run.json').read_text());fps=run['sourceFingerprints'];assert len(fps)==19
source=[]
for x in fps:
 path=x['path'];data=(r/path).read_bytes();assert hashlib.sha256(data).hexdigest()==x['sha256'],path
 assert git('show',candidate+':'+path)==data,path
 target=out/'final-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 source.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'origin':'read-current-final-and-compared-to-clean-candidate:'+candidate})
(out/'final-source-manifest.json').write_text(json.dumps(source,indent=2)+'\n')
initial=json.loads((out/'knowledge-fingerprint-inventory-initial.json').read_text())
for x in initial:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
(out/'knowledge-fingerprint-inventory-final.json').write_text(json.dumps(initial,indent=2)+'\n')
parent=out/'parent-generated-evidence';provenance=[]
selected=[raw/'analysis.json',raw/'runner-post-run-change.json']
for phase in ['negative','final']:
 p=raw/phase
 for name in ['run.json','test-summary.json','maven.log','cleanup.json','cleanup-final-verification.json']:
  if (p/name).exists():selected.append(p/name)
 selected.extend(p.glob('TEST-*.xml'))
 if phase=='final':
  selected.extend((p/'observations').glob('*.jsonl'))
for p in selected:
 rel=p.relative_to(raw);target=parent/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 provenance.append({'copiedPath':str(target.relative_to(out)),'originalPath':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'origin':'parent-generated evidence, read by ontology role; not executed by ontology role'})
(parent/'provenance.json').write_text(json.dumps(provenance,ensure_ascii=False,indent=2)+'\n')
for name in ['DhrArchiveCleanupFailureTest.java','DhrArchiveControllerStreamingTest.java']:
 a=list((raw/'negative/source').rglob(name))[0].read_bytes();b=list((raw/'final/source').rglob(name))[0].read_bytes();assert a==b,name
for path in expected:assert (raw/'negative/source'/path).read_bytes()==git('show',base+':'+path),path
cleanup=json.loads((raw/'final/cleanup-final-verification.json').read_text())
proof={'observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'cleanCandidate':candidate,'targetCommit':base,'contractReadCommit':base,'finalRunInputs':len(fps),'allFinalRunInputsMatchCurrentAndCandidate':True,'postRunDeltas':[],'knowledgeFilesUnchanged':350,'ownKnowledgeActualTests':89,'parentNegativeTests':negative['totals'],'parentFinalTests':final['totals'],'sameNewTestSourcesOldAndFinal':True,'negativeRuntimeMatchesFixedGit':True,'parentCleanupFollowup':cleanup,'scope':'ontology role read parent source and original evidence; no product/FS/PG/HTTP execution or SQL/JFR recomputation by ontology role'}
(out/'final-review-proof.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
result=f'''ontologyResult:
  result: not-applicable
  baselineBefore: 0.3.25
  baselineAfter: 0.3.25
  contractBaseline:
    sourceCommit: {candidate}
    targetBranch: edhr-dev
    targetCommit: {base}
    contractReadCommit: {base}
    uncommittedContractPaths: []
  reason: >-
    本批只在原生成/审计/传输失败与临时ZIP清理也失败时保留原异常身份、附属清理错误和路径诊断；原成功清理与单独清理失败仍按原语义传播。
    未新增或替代冻结版本、证据范围、原件、审计、权限或归档生命周期政策，350知识文件及知识0.3.25/schema1.2/P0保持，知识无需修改。
    最终19个主侧运行输入已与当前及clean候选{candidate}逐字节核对一致；本角色只实际执行知识89，不冒称执行产品/文件系统/PG/HTTP或重算SQL/JFR。
  changedArtifacts: []
  knowledgeSync:
    - id: DEC-0063-11
      disposition: retained
      scope: 完整及选定ZIP继续同一显式冻结版本，缺失/损坏仍阻断；异常诊断修复不增加成功导出或省略证据。
      sourceReferences: [docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml, final-source/gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java]
    - id: rule.dhr-summary-zip-source-trace
      disposition: retained
      scope: 原正文/附件/摘要/追溯/资格保留；Service及Controller只改变双失败抑制语义，不把本片验收扩为全部HTTP/异步/容量验证。
      sourceReferences: [docs/knowledge/rules/dhr-summary.yaml, finite-audit-records.jsonl, final-source/gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java]
    - id: DEC-0063-10
      disposition: retained
      scope: 历史受控附件原件及冻结引用不物理删除；仅处理本次创建的临时ZIP，不扫描未知孤儿、恢复或删除历史数据。
      sourceReferences: [docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml, final-source/docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml]
    - id: term.dhr-archive
      disposition: retained
      scope: 继续区分放行后的受控保存生命周期与冻结版本或ZIP下载副本；本次不实现归档执行、解封、保存期限或备份恢复。
      sourceReferences: [docs/knowledge/glossary.yaml, docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml, docs/knowledge/evidence/dhr-archive-minimum-20261029.md]
    - id: question.multi-tenant-workflow-isolation
      disposition: deferred
      scope: 完整租户隔离相邻未决仍保留，不因自有文件系统故障和局部错误传播修复宣称全局隔离完成，不阻塞默认MVP本片。
      sourceReferences: [docs/knowledge/open-questions.yaml, finite-audit-records.jsonl]
  conflicts: []
  questions: []
  validationEvidence:
    - id: validation.knowledge89
      checkType: schema
      command: bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test
      outcome: passed
      evidence: [knowledge-validation.log, knowledge-run.json, knowledge-test-summary.json, TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml]
    - id: validation.finite-reference-boundary
      checkType: reference
      command: Formal knowledge validator and ten finite affected-record semantic reviews
      outcome: passed
      evidence: [finite-audit-records.jsonl, finite-audit-summary.json, knowledge-fingerprint-inventory-final.json, 350 files unchanged; finite10 is 8 consistent plus 2 explicit gaps; not whole-audit proof]
    - id: validation.failure-propagation-scope
      checkType: projection
      command: Read final product/test source and parent-generated old13/final85 XML and evidence; no product or FS runtime by ontology role
      outcome: passed
      evidence: [REVIEW.md, final-source-manifest.json, parent-generated-evidence/provenance.json, parent-generated-evidence/negative/test-summary.json, parent-generated-evidence/final/test-summary.json]
    - id: validation.fixed-provenance
      checkType: evidence-path
      command: python3 /tmp/edhr-archive-cleanup-ontology-20261106/finalize.py {raw} {candidate}
      outcome: passed
      evidence: [baseline.json, final-fetch.log, final-review-proof.json, final-source-manifest.json, parent-generated-evidence/final/cleanup.json, parent-generated-evidence/final/cleanup-final-verification.json]
  roadmapProgress:
    stage: P0
    status: in-progress
    exitCriteriaEvidence: []
    deferredStages: [P1, P2, P3]
'''
(out/'ontologyResult.yaml').write_text(result)
review=f'''# DHR导出临时ZIP清理失败：本体最终有限核对

正式结论 **not-applicable / FINAL**。固定基线/目标{base}，实际读契约也是该提交。最终源码及测试采用clean候选{candidate}：19个主侧final运行输入与当前和候选逐字节一致，无post-run差异。350知识文件与基线相同，知识0.3.25/schema1.2.0/P0 in-progress保持；本角色没有修改产品、测试、配置、知识或契约。

本次只恢复原生成、审计或输出异常为主异常，清理失败作为suppressed并保留自有路径诊断。Service两处catch调用私有removeFailedArchive：原Exception仍抛出，IO/Runtime清理失败被附属记录及日志报告；Controller用标准Closeable try-with-resources关闭清理，输出IO或Runtime主错误不被清理错误覆盖，只有清理错误时仍传播。原成功字节/头/临时文件释放与失败阻断保持。此为工程错误传播，未新增业务许可、状态、证据或政策。

DEC-0063-05/10/11/12、rule.dhr-summary-zip-source-trace、版本与附件关系和EXPORT审计保持。原AuditEvent/归档SHA生成、save位置、域权限注解及全部冻结/内容校验不变。原异常身份恢复可让既有BusinessException处理器保留原错误码和消息，不是新定义错误码或放宽失败。原件、历史附件及冻结引用不被清理；没有未知孤儿扫描、递归删除、自动重试、UNKNOWN或持久对账设计。

term.dhr-archive和DEC-0090明确最终放行后的受控保存生命周期与汇总冻结、下载指定版本副本不同。本切片处理临时下载副本，不实现归档执行、解封、保存期限、备份恢复或放行能力。原下载实现的DhrArchive类名不能被当成生命周期已经完成的证据。

实际有限10条=8 consistent/2 evidence-gap，原成熟度保留，逐项见finite-audit-records.jsonl。两个广域缺口为既有完整HTTP/异步/发布级附件归档验收范围和相邻完整多租户未决；不因本片通过计作全域一致。整文件完成0，历史unique未知，不累计为新增全审覆盖。

本角色实际知识89/89，0F/E/S，fresh XML及run时间/指令/原日志完整。已读取主侧两测试文件同字节负对照：旧13=7正/6真F、0E/S，旧两产品源与固定Git一致；最终85/85=新service7+stream6+native12+FormFiles4+Layout3+hash48+event2+aspect3，均0F/E/S。只有本角色知识89为自行运行；产品、真实Linux临时路径非空目录故障、PostgreSQL、PDF合并、SQL/JFR均为主侧原件，已读取而未冒称本角色执行或重算。

故障夹具只将本次自有临时ZIP路径替换为非空目录，获得真实DirectoryNotEmptyException；DB/renderer协作者为mock，不是生产磁盘掉线或权限事故。原生12另用当前canonical真实PG和真实冻结/ZIP/PDF merge/审计，但renderer仍mock，不是Chromium打印/servlet端到端。主侧11观察33 SELECT、3成功audit INSERT及11 JFR描述按其分析范围保留，本角色不虚称逐事件服务器归因或资源峰值/SLA。

主侧--rm后立即观察删除为false的原记录和后续inspect已删除证明分别保留；这是环境资源清理观测时点，不改写为产品/JUnit失败，也不能省略最初记录。后续runner有界轮询只属执行编排，19受测输入未变。本片不关闭异步流未启动/超时/取消、真实FS崩溃、清理失败持久对账、UNKNOWN、PDF/Office/上传容量及其余原队列。

最后独立fetch目标仍{base}，未发现契约/知识增量。全新最终质量由另一未参与修复实例承担，本体读85报告不替代该门禁。W2-W7、931知识/86UI候选、高风险/A12/完整矩阵、历史ZIP/text-ID索引、上传PDFOffice导出容量、UNKNOWN、A23含已审代码及用户暂停项全部保持；不宣称整体审计、全局权限或生产发布完成。
'''
(out/'REVIEW.md').write_text(review)
manifest=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p.name not in ['manifest.json','manifest.sha256']:
  b=p.read_bytes();manifest.append({'path':str(p.relative_to(out)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
for x in manifest:
 b=(out/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
print(json.dumps({'result':'not-applicable','candidate':candidate,'finiteRecords':10,'consistent':8,'evidenceGaps':2,'ownKnowledgeTests':89,'finalRunInputsVerified':19,'manifestFiles':len(manifest),'manifestSha256':digest},indent=2))
