from pathlib import Path
import json
out=Path('/tmp/edhr-archive-cleanup-ontology-20261106')
records=[]
def add(id,kind,path,maturity,conclusion,scope,anchors):
 records.append({'id':id,'recordType':kind,'sourcePath':path,'sourceLocator':'#'+id,'originalMaturity':maturity,'visibility':'internal','auditScope':'current-slice-only','semanticReview':'reviewed','conclusion':conclusion,'scope':scope,'originalEvidenceReferences':anchors,'remediationStatus':'not-required-in-this-slice' if conclusion=='consistent' else 'retained-gap','wholeFileCompleted':False})
d='docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml';s='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java';c='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java';dp='docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml'
add('DEC-0063-05','decision-statement',d,'specified','consistent','导出仍取显式冻结版本及candidate/attachment快照；失败后的自有临时ZIP清理不修改冻结成员、状态、内容或原摘要。',[d+'#DEC-0063-05',s+'#export',dp])
add('DEC-0063-10','decision-statement',d,'specified','consistent','受控附件原件、解除关联历史与冻结引用保持；仅清理本次生成的临时ZIP，不将其当作可物理删除历史附件的授权。',[d+'#DEC-0063-10',s+'#export',dp])
add('DEC-0063-11','decision-statement',d,'specified','consistent','FULL/SELECTED范围、正文/附件与追溯和缺失/损坏阻断保持；保留原失败身份及附属清理错误不新增成功导出或省略证据。',[d+'#DEC-0063-11',s+'#export',c+'#export'])
add('DEC-0063-12','decision-statement',d,'specified','consistent','导出仍为领域数据审计范围，既有导出资格、save次序及双层追溯不变；本次不改查看/整理/提交/审批分权。',[d+'#DEC-0063-12',s+'#export',c+'#PreAuthorize'])
add('rule.dhr-summary-zip-source-trace','rule','docs/knowledge/rules/dhr-summary.yaml','specified','consistent','只核本切片保留同一显式冻结版本、原件与摘要、选定范围不得冒充完整、原错误仍阻断；不据本次异常诊断宣称所有打印/签名/HTTP验收通过。',['docs/knowledge/rules/dhr-summary.yaml#rule.dhr-summary-zip-source-trace',s+'#export',dp])
add('relation.dhr-summary-version-contains-controlled-attachments','relation','docs/knowledge/ontology.yaml','specified','consistent','版本与受控附件关联关系不受临时ZIP生命周期影响；不修改源附件表或成员引用。',['docs/knowledge/ontology.yaml#relation.dhr-summary-version-contains-controlled-attachments',s+'#selectedAttachmentMetadata',dp])
add('term.dhr-archive','term','docs/knowledge/glossary.yaml','specified','consistent','术语仍指最终产品放行后的受控保存生命周期，与下载ZIP副本及临时清理分开；本切片不实施归档执行、解封或保存期限。',['docs/knowledge/glossary.yaml#term.dhr-archive','docs/knowledge/evidence/dhr-archive-minimum-20261029.md',c+'#export'])
add('concept.audit-event','concept','docs/knowledge/ontology.yaml','implemented','consistent','有限核本服务原EXPORT审计身份、archiveSha256与原AuditEvent持久化路径未被错误传播工程变更替代；不升级其全域审计成熟度。',['docs/knowledge/ontology.yaml#concept.audit-event',s+'#audits.save','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java'])
add('evidence.dhr-summary-attachment-archive-tests','supporting-evidence','docs/knowledge/evidence/dhr-summary.yaml','no-status-field','evidence-gap','既有资产描述对应H2与格式/ZIP源码覆盖；本角色不运行产品FS/PG/HTTP，新局部故障/回归证据由主侧与最终质量分别报告，不能替完整servlet异步未启动/超时/取消或发布级故障验收。',['docs/knowledge/evidence/dhr-summary.yaml#evidence.dhr-summary-attachment-archive-tests','docs/development/branch-review-20261105-dhr-export/review-notes.md',dp])
add('question.multi-tenant-workflow-isolation','open-question','docs/knowledge/open-questions.yaml','unresolved','evidence-gap','默认MVP与完整租户隔离仍为既有相邻边界，本次不改变鉴权/查询或通过临时文件故障验证全局隔离；不阻塞本片异常传播工程交付。',['docs/knowledge/open-questions.yaml#question.multi-tenant-workflow-isolation',c+'#PreAuthorize',dp])
(out/'finite-audit-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records))
summary={'records':len(records),'consistent':sum(x['conclusion']=='consistent' for x in records),'evidenceGap':sum(x['conclusion']=='evidence-gap' for x in records),'wholeFileCompletions':0,'historicalUniqueCoverage':'unknown','notWholeAuditProof':True}
(out/'finite-audit-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary))
