from pathlib import Path
import subprocess,json,datetime,shutil,xml.etree.ElementTree as ET
r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-cleanup-ontology-20261106');started=datetime.datetime.now(datetime.timezone.utc)
command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test']
with (out/'knowledge-validation.log').open('w') as f:run=subprocess.run(command,cwd=r,stdout=f,stderr=subprocess.STDOUT)
totals=dict(tests=0,failures=0,errors=0,skipped=0);files=[]
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 if p.stat().st_mtime>=started.timestamp():
  a=ET.parse(p).getroot().attrib
  for k in totals:totals[k]+=int(a[k])
  shutil.copy2(p,out/p.name);files.append(p.name)
result={'command':command,'startedAtUTC':started.isoformat(),'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':run.returncode,'totals':totals,'freshReports':files,'scope':'actual knowledge validation by ontology role; not product/PG/HTTP verification'}
(out/'knowledge-run.json').write_text(json.dumps(result,indent=2)+'\n');(out/'knowledge-test-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
print(json.dumps(result,indent=2));assert run.returncode==0 and totals==dict(tests=89,failures=0,errors=0,skipped=0)
