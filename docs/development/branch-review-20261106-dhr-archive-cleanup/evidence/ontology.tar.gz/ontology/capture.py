from pathlib import Path
import subprocess,json,hashlib,datetime,tarfile,io
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-cleanup-ontology-20261106');base='2cb85492b2dbf47f5b837c565eecc5832b62b39a'
out.mkdir(parents=True,exist_ok=True)
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/evidence/dhr-filling-review-confirmed.md','docs/development/branch-review-20261105-dhr-export/review-notes.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/BusinessException.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java']
manifest=[]
for path in paths:
 data=git('show',base+':'+path);p=out/'source-baseline'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 manifest.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'origin':'fixed-git:'+base})
dp='docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml';b=(root/dp).read_bytes();p=out/'initial-worktree'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);manifest.append({'path':dp,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'origin':'initial-uncommitted-worktree'})
(out/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
baselineFiles={}
with tarfile.open(fileobj=io.BytesIO(git('archive',base,'docs/knowledge'))) as t:
 for m in t.getmembers():
  if m.isfile():baselineFiles[m.name]=t.extractfile(m).read()
inventory=[]
for path,data in sorted(baselineFiles.items()):
 now=(root/path).read_bytes();same=now==data;assert same,path
 inventory.append({'path':path,'bytes':len(now),'sha256':hashlib.sha256(now).hexdigest(),'sameAsBase':same})
assert len(inventory)==350
(out/'knowledge-fingerprint-inventory-initial.json').write_text(json.dumps(inventory,indent=2)+'\n')
state={'observedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'headCommit':git('rev-parse','HEAD').decode().strip(),'targetCommit':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':base,'uncommittedContractPaths':[],'workingTreeStatus':git('status','--porcelain').decode(),'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeFiles':350,'knowledgeChanged':False,'scope':'ontology finite review only; no product/FS/PG/HTTP runtime','contractDelta':git('diff','--name-only',base,'HEAD','--','AGENTS.md','codeplzreadme.md','docs/agents').decode()}
assert state['targetCommit']==base and not state['contractDelta']
(out/'baseline.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'head':state['headCommit'],'target':state['targetCommit'],'knowledgeFiles':350,'fixedSourceFiles':len(paths)},indent=2))
