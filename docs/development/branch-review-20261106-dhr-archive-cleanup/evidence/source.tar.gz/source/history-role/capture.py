from pathlib import Path
import subprocess,json,hashlib,re,datetime

repo=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-archive-cleanup-history-20261106')
base='2cb85492b2dbf47f5b837c565eecc5832b62b39a'
areas=['branch-review-20261031-file-consistency','branch-review-20261031-upload-transactions','branch-review-20261102-file-delete','branch-review-20261102-dhr-attachment-write','branch-review-20261105-dhr-export']
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md']
for area in areas:
 for filename in ['README.md','review-notes.md','acceptance.json']:
  paths.append('docs/development/'+area+'/'+filename)
paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']
fingerprints=[];search=[];findings=[];missing=[]
pattern=re.compile(r'cleanup|suppressed|UNKNOWN|清理失败|删除失败|文件系统故障|覆盖|掩盖|ZIP生成失败|原始异常|原异常',re.I)
for path in paths:
 proc=subprocess.run(['git','show',base+':'+path],cwd=repo,capture_output=True)
 if proc.returncode:
  missing.append({'path':path,'returnCode':proc.returncode,'stderr':proc.stderr.decode()});continue
 b=proc.stdout;target=out/'fixed-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 fingerprints.append({'path':path,'sourceCommit':base,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 if path.startswith('docs/development/'):
  for lineNo,line in enumerate(b.decode().splitlines(),1):
   if pattern.search(line):search.append({'path':path,'line':lineNo,'text':line})
  if path.endswith('acceptance.json'):
   doc=json.loads(b);items=doc.get('findings',[])
   for item in items:findings.append({'path':path,**{k:item.get(k) for k in ['id','scope','summary','resolutionStatus']}})
dp='docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml'
b=(repo/dp).read_bytes();d=out/'working-context'/dp;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
(out/'decision-package-provenance.json').write_text(json.dumps({'path':dp,'source':'explicit uncommitted working tree context, not fixed Git source','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()},ensure_ascii=False,indent=2)+'\n')
(out/'source-manifest.json').write_text(json.dumps(fingerprints,ensure_ascii=False,indent=2)+'\n')
(out/'search-results.json').write_text(json.dumps({'scopeDirectories':areas,'commands':['git show <fixed base>:<explicit path>', 'line scan: '+pattern.pattern],'matches':search,'missingPaths':missing},ensure_ascii=False,indent=2)+'\n')
(out/'old-findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n')
(out/'baseline.json').write_text(json.dumps({'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[],'actualHead':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'actualStatus':subprocess.check_output(['git','status','--short'],cwd=repo,text=True).splitlines(),'knowledgeBaselineVersion':'0.3.25','role':'read-only finite history dedup, not final quality','fixedFiles':len(fingerprints),'productRuntimeExecuted':False,'databaseExecuted':False,'browserExecuted':False,'ciQueriedOrTriggered':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fixedFiles':len(fingerprints),'matchingLines':len(search),'oldFindings':findings,'missing':missing},ensure_ascii=False,indent=2))
