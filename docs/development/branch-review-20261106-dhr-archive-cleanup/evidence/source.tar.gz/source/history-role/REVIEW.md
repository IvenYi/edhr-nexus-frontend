# DHR 导出临时 ZIP 双失败：有限历史去重

正式状态：**completed / FINAL**。本子项只读固定提交 `2cb85492b2dbf47f5b837c565eecc5832b62b39a` 的五个明确历史目录，各读取 README、review-notes、acceptance，共15份历史文件；另保留三份项目/交接契约与两份当前归档源码。当前未提交 decisionPackage 单列工作树来源。没有修改仓库产品、测试、配置或知识，没有执行产品测试、PG、浏览器、网络/CI、合并或部署。知识上下文按已读DP的0.3.25记录，不冒称本子项重新做知识全审。

## 结论

本次工作直接承接 `docs/development/branch-review-20261105-dhr-export/review-notes.md:32` 的原未测队列：该报告明确区分ZIP生成失败catch与Controller流finally，并记录成功/传输中断已测，但删除失败、文件系统故障以及完整servlet异步调度拒绝/超时/取消未执行。原报告没有把这些候选记成已复现缺陷或已修复，也没有为临时ZIP双失败指定旧缺陷ID。

在上述有限15份历史文件及其59条相关匹配中，**未找到明确关闭了 DhrArchiveService / DhrArchiveController 双失败覆盖主异常的旧发现ID或验收结论**。这只说明本次有限历史去重结果，不能宣称全仓从未记录或给出历史唯一覆盖。主侧应按真实新负对照决定是否登记局部实现缺陷，不把每个catch、每个失败断言都计成独立新问题，也不重开已解决的签名图N+1。

## 相邻已修问题的范围不同

| 历史记录 | 原范围与本次差异 |
| --- | --- |
| `AUD-W5-FILE-COPY-OWNERSHIP-001` | FileController.upload预占、复制、碰撞和旧路径所有权；已把清理错误附于原异常。它不是DHR导出ZIP的catch/finally。 |
| `AUD-W4-FILE-UPLOADER-001` | HTTP上传真实主体登记；与导出临时文件错误传播无关。 |
| `AUD-W5-UPLOAD-REGISTRATION-ROLLBACK-001` | FileController上传SQL/提交/外层回滚补偿；UNKNOWN时保留可能已提交原件。它没有关闭导出ZIP失败诊断。 |
| `QF-FILE-DELETE-ORIGINAL-LOSS` | FileController.delete数据库拒绝或回滚时先删原件；修复按提交结果清理。不是当前export已拥有临时ZIP。 |
| `QF-FILE-DELETE-FALSE-SUCCESS` | 原delete吞清理IO仍报成功；当前要求失败并说明DB已提交。本次双失败需同时保持主错误，并且只有清理失败时仍失败，不能反向吞掉清理错误。 |
| 20261102 DHR附件写入已关闭子范围 | `acceptance.json` 的 `findings: []`，`closedScope`明确为拥有的新附件登记前write/close IO清理和已批准流式SHA；不是导出临时ZIP或所有文件系统故障闭环。 |

`old-findings.json`逐项保留五个明确编号记录的原scope和resolutionStatus；附件写入关闭范围及原导出报告的剩余边界保留在固定全文。旧报告中已有的suppressed处理可作工程实现参考，不能把它扩张成“所有DHR临时文件都已验收”。

## 本轮不能关闭的旧风险

- UNKNOWN/持久对账处理的是数据库提交结果不确定、进程崩溃和跨资源最终一致性。catch或try-with-resources只能处理当前进程确实收到的异常，不提供持久化重试、outbox、恢复或孤儿清扫依据。
- PDF容量风险来自保留formPdfs、合并PDDocument、整体byte[]及原件总量。保持主异常不会降低这些内存成本，不能借本修复关闭容量队列或实施未经讨论的磁盘方案。
- 生产原件保护与当前临时ZIP不同。当前修复只能操作本次导出创建并拥有的ZIP，不得删除历史文件、原受控附件、文件登记或源证据。
- stream尚未开始、构建响应期间Files.size失败、异步调度拒绝/超时/取消等仍是相邻范围；旧成功/直接回调测试不能等同完整Servlet异步资源验收。

范围继承仍为W3/W4/W5交叉与W6健壮性/A23、W7增量；不新增业务政策，不因本子项只读完成宣称本轮实现已通过质量门禁。主侧真实负对照和未参与修复的独立最终质量仍分别执行。整文件完成0，历史unique未知，原高风险/A12/知识/UI/历史/容量/UNKNOWN与用户暂停项保持。

## 原件

`source-manifest.json`固定20份Git源的字节/哈希；`search-results.json`列明确目录、路径、行号、正则与59匹配，缺失路径为空。`fixed-source/`为固定Git全文，非当前在途产品修改；`working-context/`与decision-package-provenance.json明确未提交DP来源。capture.py保留可复现采集方式。原历史报告在本子项属于待核对历史证据，已回到其固定全文；本子项没有把它们当作当前产品实际运行结果。
