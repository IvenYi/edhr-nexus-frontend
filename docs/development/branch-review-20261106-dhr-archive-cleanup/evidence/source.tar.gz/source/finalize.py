from pathlib import Path
import subprocess,json,hashlib,shutil,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-cleanup-source-20261106');base='2cb85492b2dbf47f5b837c565eecc5832b62b39a'
manifest=json.loads((out/'source-manifest.json').read_text())
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionSnapshotBuilder.java','docs/knowledge/schema.yaml']:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=root);p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 if not any(x['path']==path for x in manifest):manifest.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source':'fixed-git:'+base,'capturePhase':'final extra source reference'})
(out/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
child=Path('/tmp/edhr-archive-cleanup-history-20261106');cm=json.loads((child/'manifest.json').read_text())
for x in cm:
 b=(child/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
shutil.copytree(child,out/'history-role',dirs_exist_ok=True)
result={'status':'completed','roleState':'FINAL','role':'read-only source/history review, not final quality','knowledgeBaselineVersion':'0.3.25','knowledgeSchemaVersion':'1.2.0','contractBaseline':{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},'scope':{'fixedGitSourceFiles':30,'explicitWorkingDecisionPackage':True,'serviceFailureSites':[189,202],'controllerFailureSite':35,'wholeFileCompletions':0,'historicalUniqueCoverage':'unknown'},'sourceConclusions':['Service generation/close and audit/SHA catch cleanup may overwrite primary exception','Controller finally cleanup may overwrite transmission failure','Error mapping may change when a BusinessException is replaced by generic IO, source-only no HTTP assertion','Original authorization and completed-ZIP-before-audit order stay protected'],
 'historicalDeduplication':{'source':'history-role/result.json','fixedHistoricalFiles':15,'matchingLines':59,'matchingClosedArchiveDoubleFailureIdFound':False,'claim':'finite search only; inherited untested queue from 20261105-dhr-export/review-notes.md:32'},'runtimeEvidence':{'jdkMicroProbeExecuted':True,'jdkMicroProbeMeaning':'language semantics with a real nonempty directory deletion, not application/PG/HTTP','applicationTestsExecuted':False,'databaseExecuted':False,'browserExecuted':False,'knowledgeValidatorExecuted':False,'ciQueriedOrTriggered':False,'microFixtureRemoved':True},'repositoryChanges':[],'children':[{'role':'cleanup_history_check','status':'completed','roleState':'FINAL','copiedFiles':sum(f.is_file() for f in (out/'history-role').rglob('*')),'manifestVerifiedFiles':len(cm),'manifestSha256':hashlib.sha256((child/'manifest.json').read_bytes()).hexdigest()}],
 'retainedRisks':['Files.size/header construction after service returns and before stream body','not-started stream, async rejection/timeouts/cancellation/process loss','UNKNOWN/durable reconciliation, no historical scan or recovery','PDF/original aggregate memory, source-file protections and complete whole-audit/A23 queue'],'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
version=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-version'],capture_output=True,text=True,check=True)
(out/'jdk-run.json').write_text(json.dumps({'commands':[['/workspace/.edhr-cloud-tools/jdk-21/bin/javac',str(out/'CleanupSemanticsProbe.java')],['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-cp',str(out),'CleanupSemanticsProbe']],'exitCode':0,'javaVersion':version.stderr+version.stdout,'output':'jdk-probe.jsonl','applicationRuntime':False},indent=2)+'\n')
m=[{'path':str(f.relative_to(out)),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(out.rglob('*')) if f.is_file() and f.name not in ['manifest.json','manifest.sha256']]
(out/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');sha=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(sha+'  manifest.json\n')
for x in m:
 b=(out/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256'],x['path']
print(json.dumps({'status':'completed / FINAL','files':len(m),'manifestSha256':sha,'fixedGitSources':30,'childrenFinal':True},indent=2))
