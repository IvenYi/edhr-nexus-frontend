import java.io.Closeable;
import java.io.IOException;
import java.nio.file.*;

public final class CleanupSemanticsProbe {
    public static void main(String[] args) throws Exception {
        Path owned = Files.createTempDirectory("archive-cleanup-source-probe-");
        Path blocked = Files.createDirectory(owned.resolve("owned.zip"));
        Path child = Files.writeString(blocked.resolve("fixture-only"), "owned fixture");
        try {
            test("catch-delete-then-rethrow", blocked, 1);
            test("finally-delete", blocked, 2);
            test("jdk-closeable-resource", blocked, 3);
        } finally {
            Files.delete(child); Files.delete(blocked); Files.delete(owned);
        }
        System.out.println("{\"cleanup\":\"owned fixture directory and child removed\"}");
    }
    private static void test(String name, Path blocked, int shape) {
        RuntimeException primary = new IllegalArgumentException("primary-fixture");
        Throwable actual;
        try {
            if (shape == 1) {
                try { throw primary; }
                catch (Exception ex) { Files.deleteIfExists(blocked); throw ex; }
            } else if (shape == 2) {
                try { throw primary; }
                finally { Files.deleteIfExists(blocked); }
            } else {
                try (Closeable cleanup = () -> Files.deleteIfExists(blocked)) { throw primary; }
            }
        } catch (Throwable failure) { actual = failure; }
        if (shape < 3 && (!(actual instanceof DirectoryNotEmptyException) || actual == primary || actual.getSuppressed().length != 0)) throw new AssertionError(name);
        if (shape == 3 && (actual != primary || actual.getSuppressed().length != 1 || !(actual.getSuppressed()[0] instanceof DirectoryNotEmptyException))) throw new AssertionError(name);
        System.out.println("{\"case\":\""+name+"\",\"actualType\":\""+actual.getClass().getName()+"\",\"originalIdentityPreserved\":"+(actual==primary)+",\"suppressedCount\":"+actual.getSuppressed().length+"}");
    }
}
