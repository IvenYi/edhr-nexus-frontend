import datetime
import hashlib
import json
from pathlib import Path
import subprocess

root=Path('/workspace/edhr-nexus-frontend')
raw=Path('/tmp/edhr-workflow-candidate-capacity-20261110')
git=lambda *args:subprocess.check_output(['git',*args],cwd=root)
sha=lambda data:hashlib.sha256(data).hexdigest()
load=lambda name:json.loads((raw/name).read_text())
candidate='e173d4022079cb77b3eb53cd44d26c09935bbd27'
base='68861c2ab0291fc8f20271c2d2cae37d1eca66fd'
assert git('rev-parse','HEAD').decode().strip()==candidate
run=load('final/run.json');summary=load('final/test-summary.json')
assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
assert summary['totals']==dict(tests=94,failures=0,errors=0,skipped=0) and not summary['missingFreshReports']
assert load('focused/test-summary.json')['totals']==dict(tests=6,failures=0,errors=0,skipped=0)
for phase in ['focused','final']:
    assert load(phase+'/cleanup.json')['removed'] is True
for row in run['sourceFingerprints']:
    assert sha((root/row['path']).read_bytes())==row['sha256']==sha(git('show',candidate+':'+row['path']))
    assert sha((raw/'final/source'/row['path']).read_bytes())==row['sha256']
assert len(run['sourceFingerprints'])==30
plans=load('plan-analysis-final.json')
assert plans['totalServiceBusinessSelects']==plans['totalCapturedActualPlans']==4504
assert len(plans['observations'])==20
for size in [0,1,10,100,1000]:
    report=load('final/candidate-observations/catalog-'+str(size)+'.json')
    assert report['beforeStateDigest']==report['afterStateDigest']
    assert len(report['beforeStateDigest'].split(';'))==11
    assert len(report['observations'])==4
    for obs in report['observations']:
        assert obs['returned']==len(obs['rows'])==size
        assert obs['matchedDefinitions']==size+2
http=[json.loads(line) for line in (raw/'final/http.jsonl').read_text().splitlines()]
success=[r for r in http if r['case'].startswith('candidate-') and not r['case'].startswith('candidate-anonymous-')]
anonymous=[r for r in http if r['case'].startswith('candidate-anonymous-')]
assert len(success)==len(anonymous)==10
assert all(r['actualStatus']==200 and r['method']=='GET' for r in success)
assert all(r['actualStatus']==401 and r['method']=='GET' for r in anonymous)
for row in success:
    size=int(row['case'].split('-')[1]);assert len(row['body']['data'])==size
protected=['gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents']
assert not git('diff','--name-only',base,candidate,'--',*protected)
knowledge=git('ls-tree','-r','--name-only',candidate,'--','docs/knowledge').decode().splitlines()
assert len(knowledge)==353
for name in knowledge:
    assert (root/name).read_bytes()==git('show',base+':'+name)
decision={'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source':'Actual current user reply to request_user_input_async call_84451e820b654e04a987e1173747241a',
 'question':'记录变更／作废页面加载审批流程选项时，已实测100个可选流程需103次查询、1000个需1003次（均完整返回，非数量上限）。是否同意下一批改为批量读取当前版本、只取选项所需字段，保留全部候选、原筛选及异常处理？当前只读取证和审计继续完成。',
 'answer':'下一批批量读取并精简字段（推荐）','authorization':'Next batch only: batch current versions and necessary candidate fields;all candidates/filtering/existing failure behavior retained',
 'implementedInCurrentCandidate':False,
 'otherPerformanceQuestions':'Original request-list qualificationSQL and audit-eventDB paging remain unanswered,not covered by this approval'}
(raw/'user-decision.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2)+'\n')
result={'baseCommit':base,'candidate':candidate,'sourceFingerprints':run['sourceFingerprints'],
 'actualTests':summary,'focusedHistory':'6/6 atdirty688;actual captured inputs now bound toe173;final94 actually atclean e173',
 'qualification':'75 nativePG +19 unit/method-security/static;JWT+MockMvc with canonicalPG,not socket/browser/production signing',
 'candidateServiceCalls':20,'actualTaggedBusinessSelects':4504,'actualAutoExplainPlans':4504,'representativePlans':60,
 'sizeToQueries':{'0':3,'1':4,'10':13,'100':103,'1000':1003},
 'explanation':'D matched definitions includes two unreturnable controls per type;SQL=1+D=M+3,not a100 result cap',
 'candidateHttp':{'authenticatedWithoutCreatePermission200':10,'anonymous401':10,'totalSize1000ReturnedPerType':1000},
 'readIntegrity':'Five actual10-table before/after full row aggregates match and raw digest strings preserved;measurement labels have0 writes',
 'measuredRisk':'PERF-WORKFLOW-CANDIDATE-CURRENT-VERSION-001: actual per-definition versionSELECTs and full entity JSON columns',
 'indexBoundary':'At1000 existing definition_id/version_number index used by version reads;small catalogs chose seq scan;no new index justified by this sample',
 'limitations':['Local warm instrumentedPG,not production latency/throughput/SLA/peak','Calling-thread cumulative allocation excludes fixture/HTTP/serialization,not peak','Catalog JSON arrays are small;wide nodes/edges cost selected but not quantified','TwoPUBLISHEDcurrent negative proves current Optional failure only,not domain-wide policy or mixedstatus corrupted matrix','No UI change/browser rerun;prior strict86/lint debt remains,not newly green','353 knowledge inventory and old2848 IDs are not whole semantic completion;old931 subset not comparable'],
 'nextBatchAuthorization':decision,'noProductUiKnowledgePolicySchemaOrIndexChanges':True,
 'wholeFileCompleted':0,'historicalUnique':'unknown','completeOverallAudit':False,
 'remaining':['Next batch candidate batch/projection now explicitly approved,not implemented yet','Other request-listSQL/auditDBpaging unanswered','W2-W7/semantic/UI86/A12/highrisk/fullmatrices/A23 including already reviewed/capacityUNKNOWN/family4N/options/paused']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'tests':summary['totals'],'inputs':len(run['sourceFingerprints']),'actualSelects':4504,'httpSuccess':10,'httpAnonymous':10,'nextBatch':'approved,not implemented'},ensure_ascii=False))
