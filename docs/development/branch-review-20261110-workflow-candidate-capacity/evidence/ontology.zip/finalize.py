from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
import yaml

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-workflow-candidate-capacity-ontology-20261110')
BASE = '68861c2ab0291fc8f20271c2d2cae37d1eca66fd'
HEAD = 'e173d4022079cb77b3eb53cd44d26c09935bbd27'
PRIOR = '6f03c7e565d309ed6630db7ab336a378cbadbe65'
DP = 'docs/development/branch-review-20261110-workflow-candidate-capacity/decision-package.yaml'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
sha = lambda data: hashlib.sha256(data).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT)
dump = lambda path, data: path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
OUT.mkdir(parents=True, exist_ok=True)
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
fetch = subprocess.run(['git', 'fetch', 'origin', 'edhr-dev'], cwd=ROOT, capture_output=True, text=True)
assert fetch.returncode == 0, fetch.stderr
(OUT/'independent-fetch.log').write_text(fetch.stdout+fetch.stderr)
assert git('rev-parse', 'origin/edhr-dev').decode().strip() == BASE
delta = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
assert delta == [DP, TEST], delta
assert not git('diff', '--name-only', BASE, HEAD, '--', 'docs/knowledge', 'docs/architecture', 'docs/agents',
               'AGENTS.md', 'codeplzreadme.md', 'gmp-platform/backend/src/main', 'gmp-platform/frontend')
(OUT/'candidate.diff').write_bytes(git('diff', BASE, HEAD))
paths = ['AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md',
         'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
         'docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
         'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','docs/knowledge/rules/record-change.yaml',
         'docs/knowledge/evidence/record-control-workflow-stage1.yaml',
         'docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md',DP,TEST,
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionRepository.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionVersionRepository.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/entity/WorkflowDefinitionVersion.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/contract/RecordControlWorkflowContracts.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java',
         'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
         'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']
inputs = []
for name in paths:
    data = (ROOT/name).read_bytes()
    assert data == git('show', HEAD+':'+name), name
    dst=OUT/'source'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    inputs.append({'path':name,'bytes':len(data),'sha256':sha(data),'gitCommit':HEAD})
entry_paths = ['docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml']
dump(OUT/'entry-read-receipt.json',{'loadedFullBytes':True,'loadedAt':now(),
     'files':[p for p in inputs if p['path'] in entry_paths],
     'scope':'All entry bytes loaded/saved;only finite clauses recorded below were semantically reconciled,not whole-file completion'})
knowledge_paths = git('ls-tree','-r','--name-only',HEAD,'--','docs/knowledge').decode().splitlines()
assert len(knowledge_paths)==353
knowledge=[]
for name in knowledge_paths:
    data=(ROOT/name).read_bytes()
    assert data==git('show',BASE+':'+name)==git('show',PRIOR+':'+name),name
    knowledge.append({'path':name,'bytes':len(data),'sha256':sha(data),'semanticStatus':'pending-except-finite-records'})
validators=['tools/knowledge-model/pom.xml']+git('ls-tree','-r','--name-only',HEAD,'--','gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').decode().splitlines()
assert len(validators)==6
validator_inputs=[]
for name in validators:
    data=(ROOT/name).read_bytes();assert data==git('show',PRIOR+':'+name)==git('show',HEAD+':'+name),name
    validator_inputs.append({'path':name,'bytes':len(data),'sha256':sha(data)})
dump(OUT/'knowledge-inventory.json',{'fileCount':353,'yaml':sum(p.endswith('.yaml') for p in knowledge_paths),
    'markdown':sum(p.endswith('.md') for p in knowledge_paths),'files':knowledge,
    'assetIdDenominator':'2848 prior unchanged-input inventory only;not re-enumerated or comparable to old931 subset'})
old=ROOT/'docs/development/branch-review-20261110-record-candidate-feedback/evidence/independent.zip'
old_manifest=json.loads((ROOT/'docs/development/branch-review-20261110-record-candidate-feedback/evidence/independent-manifest.json').read_text())
old_hashes={x['path']:x['sha256'] for x in old_manifest['files']}
copied=[]
with zipfile.ZipFile(old) as z:
    for name in ['knowledge/run.json','knowledge/maven.log','knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','knowledge-inventory.json']:
        data=z.read(name);assert sha(data)==old_hashes[name]
        dst=OUT/'reused-knowledge-6f'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
        copied.append({'path':str(dst.relative_to(OUT)),'sha256':sha(data),'bytes':len(data)})
    old_run=json.loads(z.read('knowledge/run.json'));old_inventory=json.loads(z.read('knowledge-inventory.json'))
assert old_run['head']==PRIOR and old_run['exitCode']==0 and old_run['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
assert [(r['path'],r['sha256']) for r in knowledge]==[(r['path'],r['sha256']) for r in old_inventory['files']]
xml=ET.parse(OUT/'reused-knowledge-6f/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml').getroot()
assert {k:int(xml.attrib[k]) for k in ['tests','failures','errors','skipped']}==old_run['totals']
tree_paths=['docs/knowledge','tools/knowledge-model','gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge']
trees=[]
for path in tree_paths:
    current=git('rev-parse',HEAD+':'+path).decode().strip();prior=git('rev-parse',PRIOR+':'+path).decode().strip()
    assert current==prior;trees.append({'path':path,'current':current,'prior':prior})
dump(OUT/'knowledge-validation-reuse.json',{'actuallyExecutedByThisRole':False,'originalRun':old_run,
    'inputCount':359,'knowledgeFiles':353,'validatorInputs':validator_inputs,'treeIdentity':trees,'copiedOriginals':copied,
    'scope':'Reuse original89 schema/reference/projection checks after input-byte proof;not semantic completion or fresh execution'})
prior_ontology=ROOT/'docs/development/branch-review-20261110-record-candidate-feedback/evidence/ontology.zip'
with zipfile.ZipFile(prior_ontology) as z:
    for name,dst in [('finite-review-records.json','prior8-original.json'),('historical-finite19-original.json','prior19-original.json')]:
        (OUT/dst).write_bytes(z.read(name))

def find_id(value, wanted):
    if isinstance(value,dict):
        if value.get('id')==wanted:return value
        for child in value.values():
            found=find_id(child,wanted)
            if found:return found
    elif isinstance(value,list):
        for child in value:
            found=find_id(child,wanted)
            if found:return found
    return None
specs=[
 ('DEC-0094-01','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','direct','consistent','认证只读，不需要两类create权限；HTTP/方法安全结论按父与质量实际范围，角色只核源码。'),
 ('DEC-0094-02','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','direct','consistent','匹配RECORD_CONTROL与业务类型、定义PUBLISHED、current版本PUBLISHED；读候选不授予业务操作。'),
 ('DEC-0087-03','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','neighbor','consistent','来源状态/修订/活动申请和真实签署仍由原submit事务复核，测量不改锁或写入。'),
 ('DEC-0087-04','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','neighbor','consistent','CHANGE/OBSOLETE继续显式选择明确发布版本，不自动挑最新；目录fixture不等于完整可执行流程或新签署。'),
 ('rule.record-control-source-eligibility-v1','docs/knowledge/rules/record-change.yaml','neighbor','consistent','COMPLETED/current revision/无活动申请规则不变，读取不替代最终确认。'),
 ('rule.record-control-authenticated-access-v1','docs/knowledge/rules/record-change.yaml','neighbor','consistent','默认MVP认证边界保留，不把未按tenant筛选的定义目录认作完整多租户能力。'),
 ('evidence.record-control-workflow-stage1-candidate-service','docs/knowledge/evidence/record-control-workflow-stage1.yaml','direct','consistent','当前service源仍按类型/定义状态/current版本状态过滤；query次数增长是性能观察不推导规则变化。'),
 ('scenario.record-control-authenticated-candidate-read','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','direct','consistent','普通认证且无create权限读取与匿名拒绝，与新增JWT+MockMvc目标一致；不是角色运行或真实socket认证。'),
 ('evidence.record-control-workflow-stage1-candidate-api','docs/knowledge/evidence/record-control-workflow-stage1.yaml','neighbor','superseded','仅旧create权限描述按stage1历史保存，现行权限由DEC0094-01精确收敛；其他业务复核/接口范围保留，不改历史provenance。'),
 ('question.multi-tenant-workflow-isolation','docs/knowledge/open-questions.yaml','neighbor','needs-decision','既有非MVP、非本批阻断的完整租户隔离待决，本轮不关闭。')]
records=[]
for id,path,scope,conclusion,review in specs:
    original=find_id(yaml.safe_load((ROOT/path).read_text()),id);assert original,id
    records.append({'id':id,'sourcePath':path,'sourceLocator':id,'originalRecord':original,
        'originalMaturity':original.get('status'),'originalVisibility':original.get('visibility'),
        'scope':scope,'semanticReviewStatus':'reviewed','conclusion':conclusion,'reviewConclusion':review,
        'runtimeVerificationByOntology':False})
dump(OUT/'finite-review-records.json',{'summary':{'count':len(records),'direct':4,'neighbor':6,
    'conclusions':dict(collections.Counter(r['conclusion'] for r in records)),
    'scope':'Finite rereview,overlaps prior8/prior19;not10 new unique assets or whole semantic completion'},'records':records})
dump(OUT/'engineering-boundaries.json',{'notBusinessPolicies':[
 'Optional repository selects is_current before status filtering;multiple matching current rows can throw before choosing published.',
 'Native negative fixture covers two PUBLISHED current rows;not every mixed-status corruption combination.',
 'Explicit start validates suppliedversionId/current/status separately;list failure is not a global business ban on all multiple-current states.',
 'Catalog fixture has empty topology JSON and is metadata only,not1000 new signed or executable published workflows.',
 '100/1000 are samples,not employee count,personnel-limit policy or a new total candidate cap.',
 'Observed select growth/index or full-entityJSON reading is a performance issue only after actual logs;no optimization authorized by merge/continue.']})

parent=Path('/tmp/edhr-workflow-candidate-capacity-20261110/focused')
parent_names=['run.json','test-summary.json','cleanup.json','maven.log','http.jsonl',
 'TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml']
for name in parent_names:
    dst=OUT/'parent-readonly'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(parent/name,dst)
for file in sorted((parent/'candidate-observations').glob('*.json')):
    dst=OUT/'parent-readonly/candidate-observations'/file.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,dst)
parent_run=json.loads((parent/'run.json').read_text())
assert parent_run['head']==BASE and parent_run['exitCode']==0
assert json.loads((parent/'test-summary.json').read_text())['totals']=={'tests':6,'failures':0,'errors':0,'skipped':0}
for row in parent_run['sourceFingerprints']:
    assert row['sha256']==sha(git('show',HEAD+':'+row['path'])),row['path']
observations=[]
for file in sorted((parent/'candidate-observations').glob('*.json')):
    d=json.loads(file.read_text());size=d['catalogSizePerType'];assert d['beforeStateDigest']==d['afterStateDigest']
    assert len(d['observations'])==4
    assert all(o['returned']==size and len(o['rows'])==size for o in d['observations'])
    observations.append({'file':file.name,'sizePerType':size,'serviceCalls':4,'recordedDigestEqual':True})
assert len(observations)==5
binding={'status':'FINAL','sourceCommit':HEAD,'targetCommit':BASE,'contractReadCommit':BASE,'independentTargetFetch':BASE,
 'contractDiff':[],'sourceInputs':inputs,'knowledgeFiles':353,'knowledgeValidationInputs':359,
 'knowledgeSchema':'1.2.0','knowledgeModel':'0.3.25','stage':'P0 in-progress',
 'parentFocusedEvidence':{'actuallyExecutedByThisRole':False,'actualRunHead':parent_run['head'],
   'actualWorkingTreeStatus':parent_run['workingTreeStatus'],'result':'6/6,0F/E/skip',
   'binding':'Captured parent focused inputs match cleane173;not a clean-head execution claim',
   'observationFilesRead':observations,'scope':'Parent full94 still separate;no result claimed here;not independent runtime or performance acceptance'},
 'wholeFileCompleted':0,'historicalUnique':'unknown','children':[],'repoModifiedByThisRole':False,
 'sourceReadScope':'Full byte snapshots preserved;only named symbols/schema clauses/finite IDs semantically reviewed',
 'fetchedAt':now()}
approval_path=OUT/'next-batch-approval-received.json'
if approval_path.exists():binding['nextBatchApprovalReceived']=json.loads(approval_path.read_text())
dump(OUT/'source-binding.json',binding)
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[]},
 'reason':'本批只增加隔离PG候选目录读取观察及当前异常的工程边界，不修改产品SQL/API/schema/索引/UI或候选资格/明确版本/来源/签署/幂等/快照/审计政策；不把多current目录异常升级为业务新规则，不因测量新建重复知识或改历史provenance。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.source-and-contract','checkType':'evidence-path','command':'python3 finalize.py:independent fetch,candidate diff and source byte/Git binding','outcome':'passed','evidence':['source-binding.json','candidate.diff','source']},
  {'id':'validation.finite-semantics','checkType':'projection','command':'Inspect finite10 records and engineering current-version boundary,retain prior8/19 originals','outcome':'passed','evidence':['finite-review-records.json','engineering-boundaries.json','prior8-original.json','prior19-original.json','REVIEW.md']},
  {'id':'validation.knowledge-byte-identity','checkType':'reference','command':'Compare353 knowledge plus6 validator/POM inputs and three Git trees against prior actual6f','outcome':'passed','evidence':['knowledge-inventory.json','knowledge-validation-reuse.json']},
  {'id':'validation.reused-knowledge89','checkType':'schema','command':'REUSED ONLY:prior6f actual Maven knowledge89;not executed by this role','outcome':'passed','evidence':['reused-knowledge-6f/knowledge/run.json','reused-knowledge-6f/knowledge/maven.log','reused-knowledge-6f/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']}
 ],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
files=[]
for p in sorted(OUT.rglob('*')):
    if not p.is_file() or p.name in ['manifest.json','manifest.sha256']:continue
    data=p.read_bytes();files.append({'path':str(p.relative_to(OUT)),'bytes':len(data),'sha256':sha(data)})
dump(OUT/'manifest.json',{'status':'FINAL','createdAt':now(),'sourceCommit':HEAD,'targetCommit':BASE,
 'artifacts':files,'fileCount':len(files),'wholeFileCompleted':0,'historicalUnique':'unknown','children':[]})
(OUT/'manifest.sha256').write_text(sha((OUT/'manifest.json').read_bytes())+'  manifest.json\n')
for row in files:
    data=(OUT/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
print(json.dumps({'result':'not-applicable','source':HEAD,'target':BASE,'finite':10,'knowledgeFiles':353,
 'validationInputs':359,'reused89':True,'actuallyExecutedByThisRole':False,'artifacts':len(files),
 'manifestSha256':sha((OUT/'manifest.json').read_bytes())},ensure_ascii=False))
