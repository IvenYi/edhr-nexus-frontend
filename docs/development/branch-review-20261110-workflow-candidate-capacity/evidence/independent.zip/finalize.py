from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, yaml
raw=Path(__file__).resolve().parent
root=Path('/tmp/edhr-workflow-candidate-qa-worktree-20261110')
base='68861c2ab0291fc8f20271c2d2cae37d1eca66fd'
head='e173d4022079cb77b3eb53cd44d26c09935bbd27'
sha=lambda data:hashlib.sha256(data).hexdigest()
assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==head
q=yaml.safe_load((raw/'quality-result.yaml').read_text())['qualityResult']
assert q['result']=='passed' and q['headCommit']==head and q['baseCommit']==base
assert q['workingTreeState']['status']=='clean' and not q['findings'] and not q['blockingConditions']
assert all(x['outcome']=='passed' and x['required'] is True for x in q['checks'])
binding=json.loads((raw/'source-binding.json').read_text())
cleanup=json.loads((raw/'final-cleanup.json').read_text())
assert cleanup['finalWorkingTreeStatus']=='' and cleanup['targetRecheck']['targetCommit']==base
parent=Path('/tmp/edhr-workflow-candidate-capacity-20261110')
assert (raw/'run-independent.py').read_bytes()==(parent/'run.py').read_bytes()
assert (raw/'analyze-plans.py').read_bytes()==(parent/'analyze-plans.py').read_bytes()
shutil.copyfile(parent/'user-decision.json',raw/'user-decision-parent-capture.json')
ledger={
 'scope':'Independent actual execution and inspection; commands in run.json are authoritative arrays, not a fabricated shell transcript',
 'candidate':head,'base':base,'readOnlyInspections':['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md',
 'docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md',
 'docs/knowledge/open-questions.yaml','DEC0094-01/02','DEC0087-03/04','decision-package.yaml',
 'candidate diff','RecordControlWorkflowService.java','RecordControlWorkflowController.java',
 'WorkflowDefinitionRepository.java','WorkflowDefinitionVersionRepository.java','workflow entities/contracts',
 'canonical schema/indexes/master through0092','RecordControlPostgresIntegrationTest.java and regression classes'],
 'actualRuns':['final/run.json','final_verified/run.json','knowledge/run.json'],
 'sourceAndEvidenceChecks':['python3 verify-evidence.py','python3 analyze-plans.py final_verified','python3 final-cleanup.py','python3 finalize.py'],
 'environmentRecovery':'Initial failed final log and zero reports retained; own dependency symlink added only for runtime, removed after actual original94 passed',
 'runnerByteIdenticalToParent':True,'planParserByteIdenticalToParent':True,
 'userDecisionSource':'Parent captured actual current user reply; independently read and copied, not a question issued by this child',
 'notExecuted':['frontend browser/previous92','frontend strict86/lint','production socket/e-signature flow','Actions/CI settings','merge/deploy/restore'],
 'worktreeRetainedClean':str(root)}
(raw/'command-ledger.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')
entries=[]
for path in sorted(raw.rglob('*')):
 if not path.is_file() or path.name in ['manifest.json','SHA256SUMS']: continue
 assert not path.is_symlink(),path
 data=path.read_bytes();entries.append({'path':str(path.relative_to(raw)),'bytes':len(data),'sha256':sha(data)})
manifest={'format':'edhr-independent-final-qa-manifest-v1','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'candidate':head,'base':base,'qualityResult':'passed','knowledgeBaselineVersion':'0.3.25','independent':True,
 'protectedInputs':binding['protectedInputs'],'results':{'backend':binding['backendTotals'],'knowledge':binding['knowledgeTotals'],
 'candidateObservations':20,'actualSelects':4504,'actualPlans':4504,'representativePlans':60,'candidateHttp':binding['candidateHttpStatusCounts']},
 'sourceBinding':'source-binding.json','resultFile':'quality-result.yaml','reviewFile':'independent-review.md','cleanup':'final-cleanup.json',
 'initialFailedEnvironmentAttempt':'final/','successfulActualAttempt':'final_verified/','residualRisks':[x['id'] for x in q['residualRisks']],
 'files':entries,'ordinaryFileCount':len(entries),'totalBytes':sum(x['bytes'] for x in entries),
 'exclusion':'manifest.json cannot hash itself; SHA256SUMS includes its SHA alongside every ordinary file. SHA256SUMS excludes itself.'}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for item in entries: assert sha((raw/item['path']).read_bytes())==item['sha256']
manifest_sha=sha((raw/'manifest.json').read_bytes())
lines=[f"{x['sha256']}  {x['path']}" for x in entries]+[f'{manifest_sha}  manifest.json']
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
print(json.dumps({'result':'passed','manifestSha256':manifest_sha,'ordinaryFileCount':len(entries),
 'protectedInputCount':len(binding['protectedInputs']),'qualityResultSha256':sha((raw/'quality-result.yaml').read_bytes()),
 'sourceBindingSha256':sha((raw/'source-binding.json').read_bytes()),'totalBytes':manifest['totalBytes']},indent=2))
