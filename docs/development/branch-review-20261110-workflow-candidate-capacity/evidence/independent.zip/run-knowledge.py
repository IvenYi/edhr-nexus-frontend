import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET

root=Path('/tmp/edhr-workflow-candidate-qa-worktree-20261110')
raw=Path('/tmp/edhr-workflow-candidate-capacity-final-qa-20261110/knowledge')
raw.mkdir(exist_ok=False)
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD','--','docs/knowledge','tools/knowledge-model'],cwd=root).decode().splitlines()
inputs=[]
for p in paths:
    b=(root/p).read_bytes()
    inputs.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','-f','tools/knowledge-model/pom.xml','clean','test']
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root).decode().strip(),
 'workingTreeStatus':subprocess.check_output(['git','status','--porcelain=v1'],cwd=root).decode(),
 'command':command,'cwd':str(root),'sourceFingerprints':inputs,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(raw/'run.json').write_text(json.dumps(record,indent=2)+'\n')
with (raw/'maven.log').open('w') as f:r=subprocess.run(command,cwd=root,stdout=f,stderr=subprocess.STDOUT)
record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
reports=list((root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'))
assert r.returncode==0 and reports
totals=dict(tests=0,failures=0,errors=0,skipped=0)
for p in reports:
    shutil.copyfile(p,raw/p.name)
    a=ET.parse(p).getroot().attrib
    for k in totals:totals[k]+=int(a.get(k,0))
assert totals==dict(tests=89,failures=0,errors=0,skipped=0),totals
record['totals']=totals
(raw/'run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'task':'knowledge','exitCode':r.returncode,'totals':totals}))
