from pathlib import Path
import collections, datetime, hashlib, json, re, subprocess, xml.etree.ElementTree as ET

raw = Path(__file__).resolve().parent
root = Path('/tmp/edhr-workflow-candidate-qa-worktree-20261110')
candidate = 'e173d4022079cb77b3eb53cd44d26c09935bbd27'
base = '68861c2ab0291fc8f20271c2d2cae37d1eca66fd'
phase = raw / 'final_verified'
def git(*args): return subprocess.check_output(['git',*args],cwd=root)
def sha(data): return hashlib.sha256(data).hexdigest()
assert git('rev-parse','HEAD').decode().strip() == candidate
run = json.loads((phase/'run.json').read_text())
assert run['head']==candidate and run['exitCode']==0
summary = json.loads((phase/'test-summary.json').read_text())
assert summary['totals']==dict(tests=94,failures=0,errors=0,skipped=0)
assert not summary['missingFreshReports']
assert len(summary['classes'])==6
assert next(x for x in summary['classes'] if x['name'].endswith('.RecordControlPostgresIntegrationTest'))['tests']==75
for row in summary['classes']:
    file=phase/('TEST-'+row['name']+'.xml')
    attrs=ET.parse(file).getroot().attrib
    assert all(int(attrs[k])==row[k] for k in ['tests','failures','errors','skipped'])
knowledge=json.loads((raw/'knowledge/run.json').read_text())
assert knowledge['head']==candidate and knowledge['exitCode']==0
assert knowledge['totals']==dict(tests=89,failures=0,errors=0,skipped=0)
ktotals=collections.Counter()
for file in (raw/'knowledge').glob('TEST-*.xml'):
    attrs=ET.parse(file).getroot().attrib
    ktotals.update({k:int(attrs.get(k,0)) for k in ['tests','failures','errors','skipped']})
assert dict(ktotals)==knowledge['totals']
bindings=[]
for source,inputs in [('backend',run['sourceFingerprints']),('knowledge',knowledge['sourceFingerprints'])]:
    for item in inputs:
        data=(root/item['path']).read_bytes()
        committed=git('show',candidate+':'+item['path'])
        assert data==committed and sha(data)==item['sha256'] and len(data)==item['bytes']
        if source=='backend': assert (phase/'source'/item['path']).read_bytes()==data
        bindings.append({'inputGroup':source,**item,'matchesCandidateGitBlob':True,'runtimeBytesUnchanged':True})
for path in sorted((root/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java')):
    relative=str(path.relative_to(root)); data=path.read_bytes()
    assert data==git('show',candidate+':'+relative)
    snapshot=raw/'knowledge/source'/relative
    snapshot.parent.mkdir(parents=True,exist_ok=True); snapshot.write_bytes(data)
    bindings.append({'inputGroup':'knowledge-validator-post-run','path':relative,'bytes':len(data),'sha256':sha(data),
        'matchesCandidateGitBlob':True,'captureTiming':'Post-run snapshot; candidate tree fixed; before-run and final git status prove no tracked modifications'})
analysis=json.loads((raw/'plan-analysis-final_verified.json').read_text())
assert analysis['totalServiceBusinessSelects']==analysis['totalCapturedActualPlans']==4504
assert len(analysis['observations'])==20 and len(list((raw/'plans-final_verified').glob('*.json')))==60
digests=[]
for size in [0,1,10,100,1000]:
    report=json.loads((phase/f'candidate-observations/catalog-{size}.json').read_text())
    assert report['catalogSizePerType']==size
    assert report['beforeStateDigest']==report['afterStateDigest']
    tables=re.findall(r'([a-z_]+):[a-f0-9]{32};',report['beforeStateDigest'])
    assert len(tables)==10 and len(set(tables))==10, tables
    for item in report['observations']:
        assert item['returned']==len(item['rows'])==size and item['matchedDefinitions']==size+2
        first=10000000 if item['businessType']=='CHANGE' else 20000000
        expected=[dict(workflowDefinitionId=str(first+i),workflowVersionId=str(first+1000000+i),
            templateName=f'容量流程-{i:06d}',templateCode=f"CAP-{item['businessType']}-{i}",versionNumber=3,
            businessType=item['businessType'],status='PUBLISHED') for i in range(1,size+1)]
        assert item['rows']==expected
    digests.append({'catalogSizePerType':size,'tables':tables,'beforeAfterEqual':True,
                    'beforeDigest':report['beforeStateDigest'],'afterDigest':report['afterStateDigest']})
http=[json.loads(x) for x in (phase/'http.jsonl').read_text().splitlines()]
candidates=[x for x in http if x.get('case','').startswith('candidate-')]
assert len(candidates)==20, list(http[0])
statuses=collections.Counter()
for item in candidates:
    label=item['case']; expected=401 if label.startswith('candidate-anonymous-') else 200
    actual=item.get('status',item.get('actualStatus'))
    assert actual==expected,(label,actual,item.keys())
    statuses[actual]+=1
assert statuses=={200:10,401:10}
for name in ['final','final_verified']:
    assert json.loads((raw/name/'cleanup.json').read_text())['removed'] is True
initial=json.loads((raw/'final/run.json').read_text())
initial_summary=json.loads((raw/'final/test-summary.json').read_text())
assert initial['exitCode']!=0 and initial_summary['totals']['tests']==0
assert 'vite: not found' in (raw/'final/maven.log').read_text()
changed=git('diff','--name-only',base,candidate).decode().splitlines()
assert changed==['docs/development/branch-review-20261110-workflow-candidate-capacity/decision-package.yaml',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java']
out={'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'base':base,
     'runtimeStatus':run['workingTreeStatus'],'changedFiles':changed,'protectedInputs':bindings,
     'backendTotals':summary['totals'],'backendClassBreakdown':summary['classes'],'knowledgeTotals':dict(ktotals),
     'catalogDigests':digests,'candidateHttpStatusCounts':dict(statuses),'allHttpRecords':len(http),
     'candidateObservations':20,'candidateSelects':4504,'actualAutoExplainPlans':4504,'representativePlanFiles':60,
     'initialEnvironmentFailurePreserved':True,'environmentRecoveryOnly':'Owned node_modules dependency symlink; no source/test/config changes'}
(raw/'source-binding.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['protectedInputs','catalogDigests']},ensure_ascii=False,indent=2))
