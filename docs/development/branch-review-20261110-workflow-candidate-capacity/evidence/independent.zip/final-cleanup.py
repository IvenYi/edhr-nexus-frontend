from pathlib import Path
import datetime, hashlib, json, os, subprocess
root=Path('/tmp/edhr-workflow-candidate-qa-worktree-20261110')
raw=Path(__file__).resolve().parent
link=root/'gmp-platform/frontend/node_modules'
target='/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules'
before=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
assert link.is_symlink() and os.readlink(link)==target
node_modules_stat={'path':str(link),'target':target,'ownership':'Created by this QA instance for runtime dependency resolution only',
                  'runtimeStatus':before,'targetPackageLockSha256':hashlib.sha256((root/'gmp-platform/frontend/package-lock.json').read_bytes()).hexdigest()}
link.unlink()
node_modules_stat['ownSymlinkRemoved']=not link.exists() and not link.is_symlink()
after=subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=root,text=True)
assert after==''
containers=[]
for phase in ['final','final_verified']:
    d=json.loads((raw/phase/'cleanup.json').read_text())
    r=subprocess.run(['docker','inspect',d['ownedContainer']],capture_output=True,text=True)
    assert d['removed'] and r.returncode!=0
    containers.append({**d,'independentFinalInspectExitCode':r.returncode,'independentFinalInspectStderr':r.stderr})
cmd=['git','fetch','origin','edhr-dev']
r=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
assert r.returncode==0
target_head=subprocess.check_output(['git','rev-parse','refs/remotes/origin/edhr-dev'],cwd=root,text=True).strip()
assert target_head=='68861c2ab0291fc8f20271c2d2cae37d1eca66fd',target_head
data={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'dependency':node_modules_stat,'containers':containers,
      'finalWorkingTreeStatus':after,'candidate':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
      'targetRecheck':{'command':cmd,'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'targetCommit':target_head},
      'processes':'Maven runner sessions completed; no product server was launched by this instance; own PG removed',
      'retainedWorktree':str(root),'retainedEvidence':str(raw)}
(raw/'final-cleanup.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(data,ensure_ascii=False,indent=2))
