from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
raw=Path(__file__).parent;repo=Path('/tmp/edhr-impact-reuse-qa-20261111')
def sha(b):return hashlib.sha256(b).hexdigest()
q=yaml.safe_load((raw/'quality-result.yaml').read_text())['qualityResult']
assert q['result']=='passed' and len(q['checks'])==16 and all(x['required'] and x['outcome']=='passed' for x in q['checks'])
assert not q['findings'] and not q['blockingConditions']
assert subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)==''
binding=json.loads((raw/'source-binding.json').read_text())
for item in binding['inputs']:assert sha((repo/item['path']).read_bytes())==item['sha256']
items=[]
for p in sorted(raw.rglob('*')):
 if p.is_file() and p.relative_to(raw).as_posix() not in ['manifest.json','SHA256SUMS']:
  b=p.read_bytes();items.append({'path':p.relative_to(raw).as_posix(),'bytes':len(b),'sha256':sha(b)})
manifest={'scope':'Independent L2 final QA;manifest and SHA256SUMS excluded from payload list;SHA256SUMS separately includes manifest','baseCommit':q['baseCommit'],'headCommit':q['headCommit'],'qualityResult':'passed','sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':items}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
lines=[item['sha256']+'  '+item['path'] for item in items]
lines.append(sha((raw/'manifest.json').read_bytes())+'  manifest.json')
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for line in (raw/'SHA256SUMS').read_text().splitlines():
 checksum,path=line.split('  ',1);assert sha((raw/path).read_bytes())==checksum
print(json.dumps({'quality':'passed','requiredChecks':len(q['checks']),'payloadFiles':len(items),'shaChecks':len(lines),'manifestSha256':sha((raw/'manifest.json').read_bytes()),'finalWorktreeStatus':'clean'},ensure_ascii=False,indent=2))
