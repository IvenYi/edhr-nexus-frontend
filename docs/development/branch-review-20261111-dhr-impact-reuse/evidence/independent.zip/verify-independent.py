from pathlib import Path
import collections,csv,datetime,hashlib,json,re,subprocess

raw=Path(__file__).parent;repo=Path('/tmp/edhr-impact-reuse-qa-20261111');phase=raw/'final_verified';obsdir=phase/'observations'
candidate='ff93b4598d91413b96c3b79d958c4d4c61cf10d5';base='b12a29f053184220ce88c086fb763f4318ea3c71'
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
summary=load(phase/'test-summary.json');assert summary['totals']==dict(tests=76,failures=0,errors=0,skipped=0)
run=load(phase/'run.json');assert run['head']==candidate and run['exitCode']==0
assert run['workingTreeStatus']=='?? gmp-platform/frontend/node_modules'
for x in run['sourceFingerprints']:
 assert x['sha256']==sha((repo/x['path']).read_bytes())==sha((phase/'source'/x['path']).read_bytes())
assert len(run['sourceFingerprints'])==50
observations={p.stem:load(p) for p in obsdir.glob('*.json') if p.with_suffix('.jfr').is_file()};assert len(observations)==58
jfr=collections.defaultdict(list)
with (raw/'jfr-events.tsv').open() as f:
 for name,thread,bytes_read,path in csv.reader(f,delimiter='\t'):
  assert path.startswith(str(phase/'vm-tmp')+'/'),path
  jfr[Path(name).stem].append({'thread':int(thread),'bytesRead':int(bytes_read),'path':path})
file_checks=[]
for name,x in sorted(observations.items()):
 selected=[v for v in jfr[name] if v['thread']==x['measuredThreadId']]
 assert sum(v['bytesRead'] for v in selected)==x['trackedLogicalReadBytes'],name
 assert len(selected)==x['trackedReadEvents'],name
 file_checks.append({'name':name,'thread':x['measuredThreadId'],'eventCount':len(selected),'logicalReadBytes':sum(v['bytesRead'] for v in selected)})
(raw/'jfr-independent-verification.json').write_text(json.dumps(file_checks,indent=2)+'\n')
server=collections.defaultdict(list)
blocks=re.split(r'(?=^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)',(phase/'postgres.log').read_text(),flags=re.M)
for block in blocks:
 if not block.strip():continue
 first,*rest=block.splitlines()
 match=re.search(r' (audit_summary_[a-z0-9_]+) \d+ LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',first)
 if not match:continue
 tag,sql=match.groups()
 for line in rest:
  if line.startswith('\t'):sql+='\n'+line[1:]
 server[tag].append(sql)
def norm(sql):return re.sub(r'\$\d+','?',re.sub(r'\s+',' ',sql.strip()).lower())
sql_checks=[]
for name,x in sorted(observations.items()):
 expected=collections.Counter(norm(s) for s in x['jdbcSql']+x['hibernateSql'] if s.strip().lower().startswith('select'))
 actual=collections.Counter(norm(s) for s in server[x['applicationName']] if s.strip().lower().startswith('select'))
 missing=expected-actual;extra=actual-expected
 assert not missing,(name,missing)
 assert sum(expected.values())==x['selectStatements'],name
 for sql,count in extra.items():assert 'from pg_catalog.pg_type' in sql and count==1,(name,extra)
 if name.startswith('impact_'):assert actual==expected,(name,extra)
 sql_checks.append({'name':name,'applicationName':x['applicationName'],'instrumentedSelects':sum(expected.values()),'serverSelects':sum(actual.values()),'extraDriverCatalog':list(extra.items()),'expectedMultiset':dict(expected),'actualMultiset':dict(actual)})
(raw/'sql-independent-verification.json').write_text(json.dumps(sql_checks,ensure_ascii=False,indent=2)+'\n')
states=[load(p) for p in obsdir.glob('impact*-state.json')];assert len(states)==36
for state in states:assert state['identical'] and state['before']==state['after'] and len(state['before'])==11
frozen=load(obsdir/'impact-frozen-review.json')
assert frozen['frozenAttachmentsBefore']==frozen['frozenAttachmentsAfter']
assert frozen['submitted']['status']=='PENDING_REVIEW' and frozen['approved']['outcome']=='APPROVED'
assert frozen['configuredSignatureRequired'] is False
performance={}
for suffix,expected_select in [('version',12),('review',13),('approve',29)]:
 x=observations['impact_50mib_'+suffix]
 assert x['trackedLogicalReadBytes']==52428800 and x['threadAllocatedBytes']<26214400 and x['selectStatements']==expected_select
 performance[suffix]={k:x[k] for k in ['selectStatements','trackedLogicalReadBytes','threadAllocatedBytes','elapsedNanos']}
v=observations['impact_50mib_version']['result'];d=observations['impact_50mib_review']['result'].copy()
for key in ['task','buttons','canAct']:d.pop(key)
assert v==d
for count in [0,1,100,300]:
 for lock in ['false','true']:
  x=observations[f'impact_count_{count}_{lock}'];assert x['selectStatements']==6 and x['trackedLogicalReadBytes']==count*68 and x['result']['evidenceChanges']==[]
for offset in [8191,8192,32768]:
 for lock in ['false','true']:
  x=observations[f'impact_boundary_{offset}_{lock}'];assert x['trackedLogicalReadBytes']==32769 and x['result']['evidenceChanges'][0]['attachmentId']=='1000'
assert observations['impact_uncached_first']['result']['evidenceChanges']==[]
assert observations['impact_uncached_second']['result']['evidenceChanges'][0]['attachmentId']=='1000'
for key in ['detail','approve','stale_hash']:
 x=observations['impact_denied_'+key];assert x['trackedLogicalReadBytes']==0 and x['rejection']
assert observations['impact_stale_approve']['rejection'] and '不能按过时证据批准' in observations['impact_stale_approve']['rejection']
knowledge=load(raw/'knowledge/test-summary.json');assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
kr=load(raw/'knowledge/run.json');assert kr['head']==candidate and kr['exitCode']==0 and len(kr['sourceFingerprints'])==359
for x in kr['sourceFingerprints']:
 assert x['sha256']==sha((repo/x['path']).read_bytes())==sha(subprocess.check_output(['git','show',base+':'+x['path']],cwd=repo))
assert load(phase/'cleanup.json')['removed'] is True
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'base':base,'tests':summary['totals'],'nativePostgres':38,'h2Supplemental':30,'mockUnit':8,'knowledge':knowledge,'protectedRunInputs':50,'knowledgeValidationInputs':359,'observations':58,'independentJfrCount':len(file_checks),'sqlObservationCount':len(sql_checks),'totalInstrumentedSelects':sum(x['instrumentedSelects'] for x in sql_checks),'totalServerSelects':sum(x['serverSelects'] for x in sql_checks),'extraDriverCatalog':sum(x['serverSelects']-x['instrumentedSelects'] for x in sql_checks),'readStateComparisons':36,'stateTablesEach':11,'performance':performance,'detailVersionDtoEqual':True,'newRequestsRecheck':True,'boundaryAndLastByteTamperDetected':True,'approvalLockedFreshnessPreserved':True,'limits':['Operation-thread cumulative allocation and logical reads,not peak/RSS/physicalIO/SLA','Native summary fixture has configured no-signature approval;H2 signed/concurrency regression is supplemental','API controller audit/download benefit is source-only;no full HTTP/browser claims','Source change scope remains two product files,two tests,DP;global strict86/lint gap and whole audit remain open']}
(raw/'independent-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
