from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,yaml
raw=Path(__file__).parent;repo=Path('/tmp/edhr-impact-reuse-qa-20261111');ontology=Path('/tmp/edhr-dhr-impact-reuse-ontology-20261111')
base='b12a29f053184220ce88c086fb763f4318ea3c71';candidate='ff93b4598d91413b96c3b79d958c4d4c61cf10d5'
def sha(b):return hashlib.sha256(b).hexdigest()
expected='a99ff4fa5da25e3510fb964ae70316cc9fed669e3941c21bf57cea0a8afbd173'
assert sha((ontology/'manifest.json').read_bytes())==expected
manifest=json.loads((ontology/'manifest.json').read_text())
for item in manifest['files']:
 b=(ontology/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
for line in (ontology/'SHA256SUMS').read_text().splitlines():
 checksum,p=line.split('  ',1);assert sha((ontology/p).read_bytes())==checksum
for name in ['ontology-result.yaml','REVIEW.md','finite-review-records.json','finite-review-summary.json','manifest.json','SHA256SUMS','authorization-scope.json','risk-deduplication.json']:
 dest=raw/'reviewed-ontology'/name;dest.parent.mkdir(exist_ok=True);shutil.copyfile(ontology/name,dest)
o=yaml.safe_load((ontology/'ontology-result.yaml').read_text())['ontologyResult']
assert o['result']=='not-applicable' and o['contractBaseline']['sourceCommit']==candidate and o['contractBaseline']['targetCommit']==base
subprocess.run(['git','fetch','origin','refs/heads/edhr-dev:refs/remotes/origin/edhr-dev'],cwd=repo,check=True)
actual_target=subprocess.check_output(['git','rev-parse','origin/edhr-dev'],cwd=repo,text=True).strip();assert actual_target==base
link=repo/'gmp-platform/frontend/node_modules';assert link.is_symlink()
target=link.resolve();assert target==Path('/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules').resolve()
before=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True);assert before=='?? gmp-platform/frontend/node_modules\n'
link.unlink();assert target.is_dir()
after=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True);assert after==''
run=json.loads((raw/'final_verified/run.json').read_text());container=run['ownedContainer']
assert subprocess.run(['docker','inspect',container],capture_output=True).returncode!=0
binding=json.loads((raw/'source-binding.json').read_text());binding['workingTreeFinal']=after;binding['actualTargetCommit']=actual_target
for item in binding['inputs']:assert sha((repo/item['path']).read_bytes())==item['sha256']
(raw/'source-binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
cleanup={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownWorktree':str(repo),'duringTestStatus':run['workingTreeStatus'],'beforeSymlinkCleanup':before,'finalStatus':after,'onlyOwnSymlinkRemoved':True,'mainDependenciesPreserved':target.is_dir(),'ownContainer':container,'containerRemoved':True,'allProtectedInputsMatch':len(binding['inputs']),'ontologyOriginalManifestVerified':expected,'ontologyPayloadFilesVerified':len(manifest['files']),'actualTargetCommit':actual_target}
(raw/'cleanup.json').write_text(json.dumps(cleanup,ensure_ascii=False,indent=2)+'\n');print(json.dumps(cleanup,ensure_ascii=False,indent=2))
