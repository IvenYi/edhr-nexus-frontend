from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET

repo=Path('/tmp/edhr-impact-reuse-qa-20261111');raw=Path(__file__).parent
base='b12a29f053184220ce88c086fb763f4318ea3c71';candidate='ff93b4598d91413b96c3b79d958c4d4c61cf10d5'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def blob(commit,p):return subprocess.check_output(['git','show',commit+':'+p],cwd=repo)
assert git('rev-parse','HEAD')==candidate
assert git('rev-parse','origin/edhr-dev')==base
assert git('rev-parse',base+'^{tree}')==git('rev-parse','6975f64763e4725505f134c04318d8a8fc47ec8b^{tree}')
changed=git('diff','--name-only',base,candidate).splitlines();assert len(changed)==5
assert git('diff','--name-only',base,candidate,'--','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents','gmp-platform/frontend')==''
(raw/'candidate.diff').write_text(git('diff',base,candidate)+'\n')
run=json.loads((raw/'final_verified/run.json').read_text())
paths={item['path'] for item in run['sourceFingerprints']}
paths.update(['docs/architecture/business-knowledge-model.md','docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/dhr-filling-review-confirmed.md','docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml','docs/development/branch-review-20261111-dhr-impact-evidence/performance-next.md'])
knowledge=sorted(str(p.relative_to(repo)) for p in (repo/'docs/knowledge').rglob('*') if p.is_file());assert len(knowledge)==353
paths.update(knowledge);inputs=[]
for path in sorted(paths):
 data=(repo/path).read_bytes();assert data==blob(candidate,path)
 if path in knowledge:assert data==blob(base,path)
 dest=raw/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':path,'bytes':len(data),'sha256':sha(data)})
review='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java'
old=blob(base,review).decode();new=blob(candidate,review).decode()
removed='        result.set("evidenceChanges", evidenceChanges(number(row, "version_id"), false));\n'
assert old.count(removed)==1 and new==old.replace(removed,'')
impact='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java'
old_impact=blob(base,impact).decode();new_impact=blob(candidate,impact).decode()
assert old_impact.split('    ArrayNode changes(')[0]==new_impact.split('    ArrayNode changes(')[0]
assert new_impact.count('byte[] digestBuffer = new byte[8192];')==1
assert 'Files.readAllBytes(path)' not in new_impact
main=Path('/tmp/edhr-dhr-impact-reuse-20261111/focused_old');copy=raw/'reviewed-main-negative/focused_old'
shutil.copytree(main,copy)
oldrun=json.loads((copy/'run.json').read_text());assert oldrun['head']==base and oldrun['exitCode']!=0
assert json.loads((copy/'test-summary.json').read_text())['totals']==dict(tests=6,failures=2,errors=0,skipped=0)
testpaths=[p for p in changed if p.startswith('gmp-platform/backend/src/test/')]
for path in testpaths:assert (copy/'source'/path).read_bytes()==blob(candidate,path)
for path in [review,impact]:assert (copy/'source'/path).read_bytes()==blob(base,path)
failures=[]
for xml in sorted(copy.glob('TEST-*.xml')):
 tree=ET.parse(xml).getroot()
 for case in tree.findall('testcase'):
  f=case.find('failure')
  if f is not None:failures.append({'class':case.attrib['classname'],'case':case.attrib['name'],'type':f.attrib.get('type'),'message':f.attrib.get('message'),'text':f.text})
assert len(failures)==2
assert {x['case'] for x in failures}=={'largeOriginalReadCostsAreObservedThroughRealFrozenReviewTask','reviewDetailReusesTheFrozenVersionComparison'}
negative={'base':base,'candidate':candidate,'tests':6,'positive':4,'failures':failures,'errors':0,'skipped':0,'exactFinalTestBytes':testpaths,'oldProductFilesMatchBase':[review,impact],'qualification':'Read-only verification of main original negative run;QA did not rerun old source'}
(raw/'old-negative-binding.json').write_text(json.dumps(negative,ensure_ascii=False,indent=2)+'\n')
result={'role':'new independent final QA;no implementation/test/config modifications','baseCommit':base,'headCommit':candidate,'testedCommit':candidate,'contractReadCommit':candidate,'actualTargetCommit':git('rev-parse','origin/edhr-dev'),'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workingTreeDuringTests':run['workingTreeStatus'],'changedFiles':changed,'knowledgeCount':353,'knowledgeUnchanged':True,'inputs':inputs,'productionChangeReview':'Review service exactly one read-time duplicate comparison removed;act unchanged byte-for-byte. Impact service uses local8KiB reusable buffer,fullSHA,resource close;sourceEffective untouched.'}
(raw/'source-binding.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'inputCount':len(inputs),'knowledgeCount':353,'oldNegative':{'tests':6,'positive':4,'failureCount':2,'errors':0,'skipped':0},'candidate':candidate}))
