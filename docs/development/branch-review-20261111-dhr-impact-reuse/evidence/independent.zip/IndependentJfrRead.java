import java.nio.file.*;
import java.io.*;
import java.util.*;
import jdk.jfr.consumer.*;

public final class IndependentJfrRead {
    public static void main(String[] args) throws Exception {
        Path directory = Path.of(args[0]);
        try (var paths = Files.list(directory); var out = Files.newBufferedWriter(Path.of(args[1]))) {
            for (Path p : paths.filter(p -> p.toString().endsWith(".jfr")).sorted().toList()) {
                for (var event : RecordingFile.readAllEvents(p)) {
                    if (!event.getEventType().getName().equals("jdk.FileRead")) continue;
                    String path = event.getString("path");
                    if (path == null || !path.matches(".*/original-[0-9]+\\.png")) continue;
                    if (path.contains("\t") || path.contains("\n")) throw new IllegalArgumentException("Unexpected fixture path");
                    out.write(p.getFileName() + "\t" + event.getThread().getJavaThreadId() + "\t" + event.getLong("bytesRead") + "\t" + path + "\n");
                }
            }
        }
    }
}
