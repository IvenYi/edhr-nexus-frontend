from pathlib import Path
import datetime,hashlib,json,re,subprocess,sys,yaml
repo=Path('/workspace/edhr-nexus-frontend');out=Path(__file__).parent
target='b12a29f053184220ce88c086fb763f4318ea3c71';candidate=sys.argv[1]
assert re.fullmatch('[0-9a-f]{40}',candidate)
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
def sha(b):return hashlib.sha256(b).hexdigest()
subprocess.run(['git','fetch','origin','refs/heads/edhr-dev:refs/remotes/origin/edhr-dev'],cwd=repo,check=True)
assert git('rev-parse','origin/edhr-dev')==target
assert git('rev-parse',target+'^{tree}')==git('rev-parse','6975f64763e4725505f134c04318d8a8fc47ec8b^{tree}')
initial=json.loads((out/'initial-source-binding.json').read_text());inputs=[]
for item in initial['inputs']:
 rel=item['path'];data=blob(candidate,rel);assert data==(repo/rel).read_bytes(),rel
 dest=out/'candidate-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':rel,'bytes':len(data),'sha256':sha(data),'initialSha256':item['sha256']})
assert len(inputs)==376
for item in json.loads((out/'knowledge-inventory.json').read_text()):assert item['sha256']==sha(blob(candidate,item['path']))==sha(blob(target,item['path']))
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/agents/quality-verifier.md','docs/architecture/business-knowledge-model.md']
for rel in contracts:assert blob(candidate,rel)==blob(target,rel)
changed=git('diff','--name-only',target,candidate).splitlines()
assert len(changed)==5 and sum('/src/main/' in p for p in changed)==2 and sum('/src/test/' in p for p in changed)==2
assert git('diff','--name-only',target,candidate,'--','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents','gmp-platform/frontend')==''
protected_files=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java']
protected=[]
for rel in protected_files:
 assert blob(candidate,rel)==blob(target,rel);protected.append({'path':rel,'scope':'whole-file unchanged','sha256':sha(blob(candidate,rel))})
rel='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java'
def act(b):
 t=b.decode();a=t.index('    @Transactional\n    public ObjectNode act(');b=t.index('    /** Read-time comparison;',a);return t[a:b].encode()
assert act(blob(candidate,rel))==act(blob(target,rel))
protected.append({'path':rel,'scope':'act including original locks,eligibility,signature,audit and changes(true)','sha256':sha(act(blob(candidate,rel)))})
bind={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':candidate,
 'contractReloadedFromCandidateGit':True,'priorContractSemanticReadCommit':target,'contractBytesUnchangedFromPriorRead':True,
 'actualSourceHeadAtBinding':git('rev-parse','HEAD'),'workingTreeStatus':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True),
 'changedFiles':changed,'knowledgeCount':353,'knowledgeUnchanged':True,'inputCount':len(inputs),'inputs':inputs,'protectedSemanticOwners':protected,
 'qualification':'Final candidate Git and actual working bytes bound;no business/PG/browser/Maven execution by ontology role'}
(out/'candidate-binding.json').write_text(json.dumps(bind,ensure_ascii=False,indent=2)+'\n')
(out/'candidate.diff').write_bytes(subprocess.check_output(['git','diff','--binary',target,candidate],cwd=repo))
records=json.loads((out/'finite-review-records.json').read_text())
for record in records:record['reviewedAtCommit']=candidate
(out/'finite-review-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':candidate,'uncommittedContractPaths':[]},
 'reason':'用户已明确授权同请求比较结果复用和流式摘要；实现只删除detail第二次changes并将同次原件完整SHA改8192B局部缓冲，仍按已有version比较时点提供提示，独立请求和审批锁内fresh保持。冻结、资格、签署、状态、事务、审计、历史与原件完整性规则不变。有限18项核对无需新增或修订知识；两既有high证据缺口和非MVP待决不由本批关闭。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.dhr-impact-reuse-final-source-binding','checkType':'evidence-path','command':'Actual git fetch/show/diff and complete final source/current-byte comparison;see candidate-binding.json','outcome':'passed','evidence':['candidate-binding.json','candidate.diff','candidate-source/']},
  {'id':'validation.dhr-impact-reuse-finite-semantics','checkType':'reference','command':'Read original current DEC0063/0068 and dhr-summary rules plus versioned user confirmations;finite18','outcome':'passed','evidence':['finite-review-records.json','finite-review-summary.json','authorization-scope.json','REVIEW.md']},
  {'id':'validation.dhr-impact-reuse-knowledge-structure-reuse','checkType':'schema','command':'REUSED_PR82_ORIGINAL_ACTUAL89;359 exact matching current/base inputs;this role did not execute Maven','outcome':'passed','evidence':['knowledge-validation-reuse.json','knowledge-inventory.json','reused-pr82-main/knowledge/test-summary.json','reused-pr82-main/knowledge/run.json']},
  {'id':'validation.dhr-impact-reuse-projection-boundary','checkType':'projection','command':'353 knowledge files unchanged;finite maturity and historical/out-of-scope rules retained,not new global semantic or runtime pass','outcome':'passed','evidence':['candidate-binding.json','finite-review-records.json','risk-deduplication.json','REVIEW.md']}],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=110))
review=f'''# 本体有限复核：DHR 同请求结果复用与完整流式 SHA

正式结论：`not-applicable/FINAL`。候选`{candidate}`，目标`edhr-dev@{target}`；再次fetch目标未变，PR82真实合入整树等6975f647。实际重新读取候选Git与工作字节，376输入绑定，353知识不改；初始dirty测试字节仅保留时点，不冒称最终受测。契约候选与先读b12字节相同，知识0.3.25/schema1.2.0/P0保持。

本角色只读仓库、只写自身/tmp；未修改业务代码、测试、知识、配置、迁移或UI，未运行Maven、业务数据库或浏览器、查询触发CI、合并部署或恢复历史，未创建子角色。

有限语义18项：15一致、2既有证据缺口、1既有非MVP多租户待决。与上批和历史覆盖有交叉，不增加新unique、不把353文件盘点或结构校验当全库语义通过。规则合理：同版冻结证据、完整SHA和成员/版本/状态变化比对、批准前写时fresh、人工退回或新版本重审及旧历史不变。原规则不要求同一只读详情比较两次或整文件数组；这两项为已明确授权的工程优化，不是新的业务政策或试点。用户原话“下一批做结果复用和流式摘要（推荐）”及PR82版本化记录已核；不扩大到其他未答方案、附件IDmap/索引或跨请求缓存。

实际两产品差异已逐行核：detail仍先requireTask及eligible/handled，再调用同一任务DHR/version的summaries.version，该方法已返回evidenceChanges；只删除第二次覆盖，task/buttons/canAct照旧。读取结果表达version比较发生时的观察，不承诺连续监控其后的外部变化；独立详情调用仍进version，审批act的workflow→对象→DHR锁、当前资格/expected hash/在审申请/人工确认/未完成份、changes(true)、原件/签署及审计代码整块与目标字节相同。不能从读页结果直接批准。

changes中的8192B缓冲是本次调用局部变量，每份原件新建SHA-256 digest并读至EOF，按实际count更新，关闭流后比较完整摘要；复用字节数组不复用摘要状态，不跨文件/请求缓存结果。失败仍进入原catch并标记变化，元数据失配/未VERIFIED/新增/解除等检查、顺序和冻结身份保持。输出和错误字段、原消息、SQL/schema/UI不改。原件在读中受外部修改时仍受完整摘要判断；此实现不声称OS级原子文件快照，也不改变已存在的不可变原件所有权。

只读版本、下载、控制器和WorkflowEngine五个相邻所有者文件，以及act整块，均与目标字节相同。audit/download仍先detail取得任务与版本资格，继承少一次完整比较；本角色未测完整HTTP总成本，不能把detail的查询/字节数外推成整个下载或审计请求数字。仍完整读取附件，元数据/宽JSON与嵌套身份扫描等其他容量成本并未归零。

测试源码核对到实际saveDraft/submit、已发布冻结流程产生真实待审任务，新增完整版本DTO对照、50MiB全读与累计分配预算、8191/8192/末字节篡改、独立请求重核和原陈旧批准无写/恢复本fixture原件后批准链。原H2两次调用观测更新为一次，保留never锁内比较的读侧约束，写侧回归另行覆盖；这是已批准性能行为的新期望，不是降低原证据、权限或锁内fresh标准。上述只是源码核对，不代表本角色运行测试；最终SQL/JFR/资源/正反实际结果由主侧与全新独立QA原件证明。服务+隔离PG、H2、HTTP/浏览器/首次START及签署全矩阵须分开；累计分配不是峰值/RSS，逻辑读不是物理IO，50MiB不是新附件总量上限。

本角色仅复用PR82主侧原89项知识结构测试，359输入与当前候选/目标逐字节相同；未亲自执行Maven，不拿该结果证明修改后的业务或性能。原始规范、用户确认和当前源码为本次依据，历史报告只作secondary-reference及去重索引；未重获外部客户原附件，不伪造客户验收。

沿原PERF-DHR-REVIEW-REPEAT-001收束两个已授权子项，不重复算新风险；旧逐表单N+1已由先前批读处理，不凭旧说明复活。保留两DHR high的精确剩余：通用质量/异常/源签名在内容未变时的自动判读和变化比较；通知改派后当前处理人、多/无限制候选和无法唯一恢复旧提交身份组合。A12历史、归档/放行、非MVP多租户、用户暂停、其他未答性能、完整W2–W7/A23已审复看、strict86/lint缺配置与生产容量UNKNOWN仍未由本批关闭。当前切片无新业务歧义或知识冲突。
'''
(out/'REVIEW.md').write_text(review)
files=[]
for p in sorted(out.rglob('*')):
 if not p.is_file() or p.name in ['manifest.json','SHA256SUMS']:continue
 data=p.read_bytes();files.append({'path':str(p.relative_to(out)),'bytes':len(data),'sha256':sha(data)})
manifest={'scope':'Ontology final finite review;payload list excludes manifest and SHA256SUMS;no runtime execution by this role','sourceCommit':candidate,'targetCommit':target,'result':'not-applicable','files':files}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
sums=[f"{item['sha256']}  {item['path']}" for item in files];sums.append(sha((out/'manifest.json').read_bytes())+'  manifest.json')
(out/'SHA256SUMS').write_text('\n'.join(sums)+'\n')
for line in sums:
 checksum,rel=line.split('  ',1);assert sha((out/rel).read_bytes())==checksum
print(json.dumps({'result':'not-applicable','candidate':candidate,'target':target,'inputCount':len(inputs),'payloadFiles':len(files),'checksumsVerified':len(sums),'manifestSha256':sha((out/'manifest.json').read_bytes())},ensure_ascii=False))
