from pathlib import Path
import collections,datetime,hashlib,json,subprocess,zipfile,yaml
repo=Path('/workspace/edhr-nexus-frontend');out=Path(__file__).parent
target='b12a29f053184220ce88c086fb763f4318ea3c71'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
def locate(data,wanted):
 if isinstance(data,dict):
  if data.get('id')==wanted:return data
  for value in data.values():
   result=locate(value,wanted)
   if result is not None:return result
 elif isinstance(data,list):
  for value in data:
   result=locate(value,wanted)
   if result is not None:return result
 return None
knowledge=sorted(str(p.relative_to(repo)) for p in (repo/'docs/knowledge').rglob('*') if p.is_file());assert len(knowledge)==353
validators=sorted(str(p.relative_to(repo)) for p in (repo/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java'))
validation_inputs=knowledge+validators+['gmp-platform/backend/pom.xml'];assert len(validation_inputs)==359
extras=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/agents/quality-verifier.md','docs/architecture/business-knowledge-model.md',
 'docs/development/branch-review-20261111-dhr-impact-reuse/decision-package.yaml','docs/development/branch-review-20261111-dhr-impact-evidence/performance-next.md',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrReviewLifecycleIntegrationTest.java']
inputs=[]
for rel in sorted(set(validation_inputs+extras)):
 data=(repo/rel).read_bytes();dest=out/'initial-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
assert len(inputs)==376
binding={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'target':git('rev-parse','origin/edhr-dev'),'contractReadCommit':target,
 'workingTreeStatus':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True),'inputs':inputs,
 'qualification':'Initial working bytes;may include in-development tests;not final candidate or runtime certification'}
(out/'initial-source-binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
inventory=[]
for rel in knowledge:
 data=(repo/rel).read_bytes();old=subprocess.check_output(['git','show',target+':'+rel],cwd=repo);assert data==old
 inventory.append({'path':rel,'bytes':len(data),'sha256':sha(data),'targetIdentical':True})
(out/'knowledge-inventory.json').write_text(json.dumps(inventory,ensure_ascii=False,indent=2)+'\n')
previous=json.loads((out/'previous-finite-review-records.json').read_text());records=[]
scope_updates={
 'DEC-0063-05':'冻结证据基准不改。同请求复用version的已有比较结果是读取工程选择，不要求两次比较；之后独立请求和写时检查仍须读取实际来源。',
 'DEC-0063-10':'保留全部原件字节及完整SHA-256、受控核验和50MiB含边界。8192B缓冲只改变摘要内存策略，不改变格式/容量/权限/历史及异常判定。',
 'DEC-0068-05':'来源有效变化仍阻断过时批准；detail一次读不承诺持续监控。act独立锁内重核和人工退回保持，不以先前详情的结果批准。',
 'DEC-0068-06':'性能复用不改写旧冻结或批准；只在一个详情请求内复用，不跨请求保留实时比较结果。',
 'rule.dhr-summary-block-stale-approval':'完整变化检测和锁内fresh批准阻断保留，整数组改完整流读不是豁免校验；新请求须重核。',
 'rule.dhr-review-task-frozen-attachment-download':'任务资格和冻结版附件范围仍由原入口核验；audit/download继承一次detail的效果，不新增授权解析旁路。'}
for old in previous:
 data=yaml.safe_load((repo/old['sourcePath']).read_text());normative=locate(data,old['id']);assert normative is not None,old['id']
 record=dict(old);record['normativeRecord']=normative;record['reviewedAtCommit']=target
 record['evidenceReferences']=list(dict.fromkeys(old.get('evidenceReferences',[])+['docs/development/branch-review-20261111-dhr-impact-evidence/performance-next.md']))
 record['reviewStatus']='reviewed';record['auditScope']='Finite re-review for authorized same-request result reuse and full streaming SHA;overlaps prior18,not new unique coverage'
 if old['id'] in scope_updates:record['conclusionScope']=scope_updates[old['id']]
 if old['conclusion']=='evidence-gap':record['conclusionScope']='保留当前声明的精确剩余范围；只读重复与摘要优化不关闭通用质量/异常/源签名自动判读，亦不关闭通知改派/多候选/无法唯一恢复旧提交身份组合。'
 record['runtimeQualification']='Ontology role executes no Maven/PG/browser. New main and fresh independent QA must certify final candidate;source interpretation does not certify capacity/runtime.'
 lines=(repo/old['sourcePath']).read_text().splitlines();hits=[i+1 for i,line in enumerate(lines) if ('id: '+old['id'])==line.strip().removeprefix('- ')]
 if len(hits)==1:record['sourceLocator']=old['sourcePath']+':'+str(hits[0])
 records.append(record)
assert len(records)==18
(out/'finite-review-records.json').write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
summary={'finiteRecords':len(records),'conclusions':dict(collections.Counter(r['conclusion'] for r in records)),'newUniqueCoverage':None,'wholeKnowledgeSemanticAudit':'not complete;353-file inventory is not semantic pass','knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','roadmapStage':'P0/in-progress'}
(out/'finite-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
authorization={'source':'user-confirmed in current inherited conversation;versioned record independently read','quote':'下一批做结果复用和流式摘要（推荐）','record':'docs/development/branch-review-20261111-dhr-impact-evidence/performance-next.md','recordGitBaseline':target,'scope':['one comparison per detail using version result','full SHA via bounded stream buffer'],'notAuthorizedByThisChoice':['skip locked approval recheck','cross-request cache','remove original/task qualification','attachment identity map/index redesign','other pending performance or paused policy changes']}
(out/'authorization-scope.json').write_text(json.dumps(authorization,ensure_ascii=False,indent=2)+'\n')
risk={'carriedId':'PERF-DHR-REVIEW-REPEAT-001','newUniqueRisk':False,'priorSources':['docs/development/branch-review-20261026-capacity-audit/findings.md','docs/development/branch-review-20261111-dhr-impact-evidence/review.md'],'scope':'Current authorization addresses same-request double comparison and whole-file digest arrays;not blanket closure of all old performance/high findings','otherRisks':['PERF-DHR-EVIDENCE-NPLUS1-001 fixed by prior batch read,not reopened','wide JSON residency/chunking choice remains separate','frozen-attachment nested identity search remains separate','audit/download complete HTTP cost not measured by this ontology role']}
(out/'risk-deduplication.json').write_text(json.dumps(risk,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'inputs':len(inputs),'knowledgeUnchanged':len(inventory),**summary},ensure_ascii=False))
