from pathlib import Path
import collections,datetime,hashlib,json,re,subprocess

repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;phase=raw/'final';out=phase/'observations'
candidate='ff93b4598d91413b96c3b79d958c4d4c61cf10d5';target='b12a29f053184220ce88c086fb763f4318ea3c71'
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
run=read(phase/'run.json');assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
for item in run['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha((phase/'source'/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=repo))
assert len(run['sourceFingerprints'])==50
summary=read(phase/'test-summary.json');assert summary['totals']==dict(tests=76,failures=0,errors=0,skipped=0)
assert not summary['missingFreshReports']
product_changes=subprocess.check_output(['git','diff','--name-only',target,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents'],cwd=repo,text=True).splitlines()
assert product_changes==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java']
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=repo)
review_path=product_changes[1]
removed=b'        result.set("evidenceChanges", evidenceChanges(number(row, "version_id"), false));\n'
assert blob(target,review_path).count(removed)==1 and blob(target,review_path).replace(removed,b'')==blob(candidate,review_path)
assert read(raw/'focused_old/test-summary.json')['totals']==dict(tests=6,failures=2,errors=0,skipped=0)
assert read(raw/'focused_new/test-summary.json')['totals']==dict(tests=6,failures=0,errors=0,skipped=0)
for name in ['DhrSummaryAttachmentObservationPostgresTest','DhrReviewLifecycleIntegrationTest']:
 p='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/'+name+'.java'
 assert (raw/'focused_old/source'/p).read_bytes()==blob(candidate,p)
for p in product_changes:assert (raw/'focused_old/source'/p).read_bytes()==blob(target,p)
observations={p.stem:read(p) for p in out.glob('*.json') if p.with_suffix('.jfr').exists()}
assert len(observations)==58
jfr_tool='/workspace/.edhr-cloud-tools/jdk-21.0.12.1+1/bin/jfr'
jfr_results=[]
for name,ob in sorted(observations.items()):
 command=[jfr_tool,'print','--json','--events','jdk.FileRead',str(out/(name+'.jfr'))]
 data=json.loads(subprocess.check_output(command));events=[]
 for event in data['recording']['events']:
  value=event['values'];path=value.get('path','')
  if value['eventThread']['javaThreadId']==ob['measuredThreadId'] and re.search(r'/original-\d+\.png$',path):
   events.append({'path':path,'bytesRead':value['bytesRead']})
 assert sum(x['bytesRead'] for x in events)==ob['trackedLogicalReadBytes'],name
 assert len(events)==ob['trackedReadEvents'],name
 count=sum(sql.lstrip().lower().startswith('select') for sql in ob['jdbcSql']+ob['hibernateSql'])
 assert count==ob['selectStatements'],name
 jfr_results.append({'name':name,'command':command,'events':events,'bytesRead':ob['trackedLogicalReadBytes'],'eventCount':len(events),'sqlSelects':count})
(raw/'external-jfr-verification.json').write_text(json.dumps(jfr_results,indent=2)+'\n')
states=[read(p) for p in out.glob('impact*-state.json')]
assert len(states)==36
assert all(s['identical'] and s['before']==s['after'] and len(s['before'])==11 for s in states)
frozen=read(out/'impact-frozen-review.json');assert frozen['frozenAttachmentsBefore']==frozen['frozenAttachmentsAfter']
assert frozen['submitted']['status']=='PENDING_REVIEW' and frozen['approved']['outcome']=='APPROVED'
assert frozen['configuredSignatureRequired'] is False
for count in [0,1,100,300]:
 for lock in [False,True]:
  x=observations[f'impact_count_{count}_{str(lock).lower()}'];assert x['selectStatements']==6 and x['trackedLogicalReadBytes']==count*68
  assert x['result']['evidenceChanges']==[]
for entry in ['detail','approve','stale_hash']:
 x=observations['impact_denied_'+entry];assert x['trackedLogicalReadBytes']==0 and x['rejection']
for entry,sql in [('version',12),('review',13),('approve',29)]:
 x=observations['impact_50mib_'+entry]
 assert x['trackedLogicalReadBytes']==52428800 and x['selectStatements']==sql and x['threadAllocatedBytes']<25*1024*1024
v=observations['impact_50mib_version']['result'];d=observations['impact_50mib_review']['result']
assert {k:x for k,x in d.items() if k not in ['task','buttons','canAct']}==v
assert not observations['impact_uncached_first']['result']['evidenceChanges'] and len(observations['impact_uncached_second']['result']['evidenceChanges'])==1
for offset in [8191,8192,32768]:
 for lock in ['false','true']:
  x=observations[f'impact_boundary_{offset}_{lock}'];assert x['trackedLogicalReadBytes']==32769 and len(x['result']['evidenceChanges'])==1
# Parse successful server executions, preserving complete multiline SQL and parameter DETAIL.
lines=(phase/'postgres.log').read_text().splitlines();server=collections.defaultdict(list)
header=re.compile(r'^\d{4}-\d\d-\d\d .*?\[\d+\] \S+ (\S+) \d+ LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)$')
current=None
for line in lines:
 match=header.match(line)
 if match:
  app,sql=match.groups();current=None
  if app.startswith('audit_summary_'):
   item={'sql':sql};server[app].append(item);current=item
 elif line.startswith('\t') and current is not None:current['sql']+='\n'+line[1:]
 elif re.match(r'^\d{4}-\d\d-\d\d ',line):current=None
server_counts=[]
for name,ob in observations.items():
 rows=server[ob['applicationName']]
 actual=[r['sql'] for r in rows if r['sql'].lstrip().lower().startswith('select')]
 expected=ob['jdbcSql']+ob['hibernateSql']
 assert len(actual)>=ob['selectStatements'],(name,len(actual),ob['selectStatements'])
 for sql in expected:
  normalized=re.sub(r'\s+',' ',sql.strip()).lower()
  normalized=re.sub(r'\$\d+','?',normalized)
  assert any(re.sub(r'\$\d+','?',re.sub(r'\s+',' ',a['sql'].strip()).lower())==normalized for a in rows), (name,sql)
 server_counts.append({'name':name,'instrumentedSelects':ob['selectStatements'],'serverSelects':len(actual),'extraServerSelects':len(actual)-ob['selectStatements']})
(raw/'server-executions.json').write_text(json.dumps(dict(server),ensure_ascii=False,indent=2)+'\n')
(raw/'server-count-verification.json').write_text(json.dumps(server_counts,indent=2)+'\n')
knowledge=read(raw/'knowledge/test-summary.json');assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
kr=read(raw/'knowledge/run.json');assert kr['head']==candidate and kr['workingTreeState']=='' and kr['exitCode']==0
for item in kr['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',target+':'+item['path']],cwd=repo))
assert len(kr['sourceFingerprints'])==359
assert read(phase/'cleanup.json')['removed'] is True
performance={name:{k:x[k] for k in ['selectStatements','trackedLogicalReadBytes','trackedReadEvents','threadAllocatedBytes','elapsedNanos','rejection']} for name,x in observations.items() if name.startswith('impact')}
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'protectedInputsMatch':50,'knowledgeInputsMatch':359,
 'tests':summary['totals'],'nativePostgres':38,'h2Supplemental':30,'mockUnit':8,'knowledge':knowledge,'observations':len(observations),'externalJfrVerified':len(jfr_results),
 'readStateComparisons':36,'readStateTablesEach':11,'serverSqlShapesAndReadCountsVerified':True,'extraServerSelects':sum(x['extraServerSelects'] for x in server_counts),'performance':performance,'riskIds':['PERF-DHR-REVIEW-REPEAT-001'],
 'oldSameFinalTestBytes':{'tests':6,'passed':4,'failures':2,'errors':0,'skipped':0},'actAndAllOtherReviewCodeByteIdentical':True,'fullVersionDtoReusedWithoutFieldChange':True,
 'limits':['Only authorized request-local reuse and streaming hash implemented;other performance proposals unchanged','Counters are cumulative operation-thread allocation/logical file reads,not peak/RSS/physical IO/SLA','Direct service plus native PG,not HTTP/browser/initial START/signed-native approval;explicit fixture button has no signing event','Existing H2 signed/return/concurrent approval regression remains supplemental','Controller audit/download first call detail:source-only transfer scope,not measured end-to-end totals','Global strict86/lint config gap and whole audit remain open','focused_old/new use dirty base plus actual captured files;only final76 and knowledge89 ran clean final candidate']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='performance'},ensure_ascii=False,indent=2))
