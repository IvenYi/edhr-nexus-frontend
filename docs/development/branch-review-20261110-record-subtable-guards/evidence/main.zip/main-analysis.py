from pathlib import Path
import datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET

raw=Path(__file__).parent; repo=Path('/workspace/edhr-nexus-frontend')
candidate='ab5b44d2292a8a7a08cbeb6aba502b30f50df8f0'; target='0701b3d5d99787195e9d4c33935ae36da370839d'
def read(p):return json.loads(p.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(commit,path):return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=repo)
run=read(raw/'final/run.json');assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
for item in run['sourceFingerprints']:
 p=item['path'];assert item['sha256']==sha((raw/'final/source'/p).read_bytes())==sha((repo/p).read_bytes())==sha(blob(candidate,p)),p
totals=read(raw/'final/test-summary.json')['totals'];assert totals==dict(tests=123,failures=0,errors=0,skipped=0)
assert read(raw/'focused_old/test-summary.json')['totals']==dict(tests=16,failures=8,errors=0,skipped=0)
for name in ['RecordControlDiffTest','RecordControlPostgresIntegrationTest']:
 p=next((repo/'gmp-platform/backend/src/test/java').rglob(name+'.java')).relative_to(repo)
 assert (raw/'focused_old/source'/p).read_bytes()==(raw/'final/source'/p).read_bytes()
p='gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java'
assert (raw/'focused_old/source'/p).read_bytes()==blob(target,p)
for phase in ['focused_old','final']:
 assert read(raw/phase/'cleanup.json')['removed'] is True

def signature_inserts(phase):
 lines=(raw/phase/'postgres.log').read_text().splitlines(); rows={}
 for i,line in enumerate(lines[:-1]):
  found=re.search(r'LOG:.*?duration: [\d.]+ ms\s+(?:execute [^:]+|statement):\s*insert into signature\s*\(([^)]+)\)',line,re.I)
  if not found:continue
  # Fixture INSERTs mix literals and placeholders; only fully bound JPA rows carry these action signatures.
  if not re.fullmatch(r'\s*values\s*\(\$\d+(?:,\s*\$\d+)*\)\s*',line[found.end():],re.I):continue
  columns=[c.strip() for c in found[1].split(',')]
  detail=lines[i+1]
  assert 'DETAIL:  parameters:' in detail
  values={int(n):None if val=='NULL' else val[1:-1].replace("''", "'") if val.startswith("'") else val for n,val in re.findall(r"\$(\d+) = (NULL|'(?:[^']|'')*'|[^,]+)(?:, |$)",detail.split('parameters: ',1)[1])}
  assert len(columns)==len(values),(columns,values)
  row=dict(zip(columns,[values[n] for n in range(1,len(columns)+1)]))
  rows[row['id']]=row
 return rows

checks=[];signed_payloads=[]
for phase,removed in [('focused_old',False),('final',True)]:
 inserts=signature_inserts(phase)
 reports=sorted((raw/phase/'signature-observations').glob('*.json'));assert len(reports)==4
 for p in reports:
  x=read(p);sig=json.loads(x['signatureBefore']);request=x['request'];history=x['history'];current=x['current']
  assert x['signatureBefore']==x['signatureAfter'] and x['oldValuesBefore']==x['oldValuesAfter'] and x['oldHashBefore']==x['oldHashAfter']
  assert sha(x['oldValuesBefore'].encode())==x['oldHashBefore']
  assert sha(sig['snapshot_data'].encode())==sig['snapshot_hash']
  assert sig['target_type']=='PRODUCTION_EXECUTION' and sig['target_id']=='109' and sig['auth_method']=='SIGNATURE_PASSWORD'
  original=json.loads(x['oldValuesBefore'])['rows'][0]['signed']
  assert original['signatureId']==str(x['fieldSignatureId'])
  assert original==request['sourceValues']['rows'][0]['signed']==history[1]['fieldValues']['rows'][0]['signed']
  assert len(history)==2 and str(history[0]['revision_no'])=='2' and str(history[1]['revision_no'])=='1'
  execution=json.loads(x['executionStateAfter'])
  for row in [request['proposedValues']['rows'][0],current['fieldValues']['rows'][0],history[0]['fieldValues']['rows'][0],execution['operations']['op']['forms']['guarded-form']['values']['rows'][0]]:
   assert ('signed' not in row)==removed,(phase,p.name,row)
   if not removed:assert row['signed']==original
   assert row['__rowId']=='11111111-1111-4111-8111-111111111111' and row['note']=='original'
  assert '__recordRowId' not in current['fieldValues']['rows'][0]
  assert execution['operations']['op']['forms']['form']['values']['value']=='old'
  proposal=json.dumps(request['proposedValues'],ensure_ascii=False,separators=(',',':'))
  assert sha(proposal.encode())==history[0]['content_hash']
  assert len(request['diff'])==1 and request['diff'][0]['fieldId']=='value'
  submit=inserts[str(request['applicant_signature_id'])]
  field=inserts[str(x['fieldSignatureId'])]
  assert field['snapshot_data']==sig['snapshot_data'] and field['snapshot_hash']==sig['snapshot_hash']
  assert submit['target_type']=='RECORD_CONTROL_REQUEST' and submit['target_id']==x['requestId'] and submit['signer_id']=='41'
  payload=json.loads(submit['snapshot_data']);assert payload['signerId']==payload['sessionOperatorId']=='41'
  assert payload['values']['sourceValues']==request['sourceValues'] and payload['values']['proposedValues']==request['proposedValues']
  approvals=[s for s in inserts.values() if s['target_type']=='RECORD_CONTROL_REQUEST' and s['target_id']==x['requestId'] and s['meaning'].startswith('APPROVE')]
  assert len(approvals)==1 and approvals[0]['signer_id']=='42'
  approval_payload=json.loads(approvals[0]['snapshot_data']);assert approval_payload['signerId']=='42' and approval_payload['sessionOperatorId']=='41'
  for row in [field,submit,approvals[0]]:
   assert sha(row['snapshot_data'].encode())==row['snapshot_hash']
   signed_payloads.append({'phase':phase,'case':x['case'],'signatureId':row['id'],'targetType':row['target_type'],'targetId':row['target_id'],
    'signerId':row['signer_id'],'snapshotSha256':row['snapshot_hash'],'source':'actual PostgreSQL INSERT bound parameters'})
  checks.append({'phase':phase,'case':x['case'],'newValuesWithoutHistoricalSignature':removed,'oldSignatureAndRevisionUnchanged':True,
                 'originalAndNewHashesIndependentlyRecomputed':True,'actualApprovalAndHistoryRead':True,'signedPayloadMatchesProposal':True})
 http=[read_line for line in (raw/phase/'http.jsonl').read_text().splitlines() if (read_line:=json.loads(line))['case'].startswith('locked-parent-')]
 assert len(http)==12 and all(x['actualStatus']==x['expectedStatus']==200 for x in http)
knowledge=read(raw/'knowledge/test-summary.json');assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
for item in read(raw/'knowledge/run.json')['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha(blob(target,item['path']))
assert len(subprocess.check_output(['git','ls-tree','-r','--name-only',candidate,'docs/knowledge'],cwd=repo,text=True).splitlines())==353
assert subprocess.check_output(['git','diff','--name-only',target,candidate,'docs/knowledge','docs/agents','AGENTS.md','codeplzreadme.md','gmp-platform/frontend','gmp-platform/backend/src/main/resources'],cwd=repo,text=True)==''
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'testedCandidate':candidate,
 'protectedInputsMatch':len(run['sourceFingerprints']),'mainTotals':totals,'nativePostgres':87,'otherUnitMethodSecurityStatic':36,
 'oldSameTestBytes':dict(tests=16,passed=8,failures=8,errors=0,skipped=0),'knowledgeActual':knowledge,
 'checks':checks,'actualBoundSignaturePayloadsIndependentlyVerified':len(signed_payloads),'signatureBindings':signed_payloads,
 'knownUnaffectedCurrentBehavior':'Original field locks,IDs,diffs,void,action signatures/transactions/API/UI/schema retained',
 'compatibilityLimit':'Only newly prepared applications;preexisting IN_REVIEW proposals or historical revisions are not automatically cleaned or migrated',
 'pendingSignals':['Reference validation/selector context needs separate focused reproduction;not fixed here',
 'DhrEvidenceImpact attachment array digest remains existing capacity-scope source signal;not quantified or optimized here'],
 'scope':'Synthetic sources;actual signature-password signField andJWT+MockMvc/nativePG chain;not browser or production signing rollout'}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['checks','signatureBindings']},ensure_ascii=False,indent=2))
