from pathlib import Path
import datetime, hashlib, json, shutil, zipfile

repo=Path('/workspace/edhr-nexus-frontend')
report=repo/'docs/development/branch-review-20261110-record-subtable-guards'
out=report/'evidence'
out.mkdir(exist_ok=True)
roots={
    'main':Path(__file__).parent,
    'ontology':Path('/tmp/edhr-record-subtable-signature-ontology-20261110'),
    'independent':Path('/tmp/edhr-record-subtable-signature-final-qa-20261110')}
def sha(data): return hashlib.sha256(data).hexdigest()
packages=[]
for label,root in roots.items():
    if label!='main':
        manifest=json.loads((root/'manifest.json').read_text())
        for item in manifest['files']:
            data=(root/item['path']).read_bytes()
            assert len(data)==item['bytes'] and sha(data)==item['sha256'],(label,item['path'])
        for line in (root/'SHA256SUMS').read_text().splitlines():
            checksum,path=line.split('  ',1)
            assert sha((root/path).read_bytes())==checksum,(label,path)
    members=[]
    archive=out/(label+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(root.rglob('*')):
            if not p.is_file(): continue
            data=p.read_bytes(); rel=str(p.relative_to(root))
            members.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
            z.writestr(rel,data)
    with zipfile.ZipFile(archive) as z:
        assert set(z.namelist())=={m['path'] for m in members}
        for m in members:
            data=z.read(m['path']);assert len(data)==m['bytes'] and sha(data)==m['sha256']
    manifest_path=out/(label+'-manifest.json')
    manifest_path.write_text(json.dumps({'package':label,'files':members},ensure_ascii=False,indent=2)+'\n')
    packages.append({'name':label,'path':str(archive.relative_to(report)),'bytes':archive.stat().st_size,
                     'sha256':sha(archive.read_bytes()),'members':len(members),
                     'manifest':str(manifest_path.relative_to(report)),'manifestSha256':sha(manifest_path.read_bytes())})
shutil.copyfile(roots['main']/'main-analysis.json',report/'main-analysis.json')
shutil.copyfile(roots['ontology']/'ontology-result.yaml',report/'ontology-result.yaml')
shutil.copyfile(roots['ontology']/'REVIEW.md',report/'ontology-review.md')
shutil.copyfile(roots['independent']/'quality-result.yaml',report/'quality-result.yaml')
qa_review=roots['independent']/'REVIEW.md'
if not qa_review.exists(): qa_review=roots['independent']/'review.md'
shutil.copyfile(qa_review,report/'independent-review.md')
index={'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':'ab5b44d2292a8a7a08cbeb6aba502b30f50df8f0',
       'packages':packages,'allArchiveMemberHashesVerified':True,
       'originalRoleManifestsAndSha256SumsVerified':True,
       'scope':'Immutable point-in-time original evidence including old-source 16-case red/green probe and signed revision payloads'}
(report/'evidence-packages.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(index,ensure_ascii=False,indent=2))
