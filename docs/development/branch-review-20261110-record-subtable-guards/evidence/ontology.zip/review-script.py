from pathlib import Path
import datetime, hashlib, json, subprocess, xml.etree.ElementTree as ET, zipfile
import yaml

repo=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-record-subtable-signature-ontology-20261110')
out.mkdir(exist_ok=False)
base='0701b3d5d99787195e9d4c33935ae36da370839d'
candidate='ab5b44d2292a8a7a08cbeb6aba502b30f50df8f0'
dp_path='docs/development/branch-review-20261110-record-subtable-guards/decision-package.yaml'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def dump(name,value):
    p=out/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def copy_source(path):
    data=(repo/path).read_bytes();dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    assert data==git('show',f'{candidate}:{path}'),path
    return {'path':path,'bytes':len(data),'sha256':sha(data)}

assert git('rev-parse','HEAD').decode().strip()==candidate
assert git('rev-parse','origin/edhr-dev').decode().strip()==base
entry_status=git('status','--porcelain=v1').decode()
paths=[
 'AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',dp_path,
 'docs/knowledge/schema.yaml','docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml',
 'docs/knowledge/decisions/DEC-0041-record-control-start-node-confirmation.yaml',
 'docs/knowledge/decisions/DEC-0042-record-control-workflow-stage1-contract.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
 'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
 'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
 'docs/knowledge/rules/record-change.yaml','docs/knowledge/rules/production-field-signature.yaml',
 'docs/knowledge/evidence/record-control-v1.yaml','docs/knowledge/evidence/record-control-v1-user-confirmed.md',
 'docs/knowledge/evidence/record-control-workflow-stage1.yaml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlTaskActionService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/controller/RecordControlController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceRecordService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/contract/RecordControlWorkflowContracts.java',
 'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlDiffTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java']
# Use the real current filename for each numbered decision; no assumed path is an evidence claim.
for i,p in enumerate(paths):
    if not (repo/p).exists() and '/decisions/DEC-' in p:
        number=Path(p).name[:8]
        actual=list((repo/'docs/knowledge/decisions').glob(number+'*.yaml'))
        assert len(actual)==1,p
        paths[i]=str(actual[0].relative_to(repo))
inputs=[copy_source(p) for p in paths]
dp=yaml.safe_load((repo/dp_path).read_text())['decisionPackage']
for key in ['confirmed','inferred','unresolved','replacementScopes','impactAnalysis','extensionStrategy','affectedFiles','acceptanceScenarios']:
    assert key in dp,key
assert dp['contractBaseline']==dict(sourceCommit=base,targetBranch='edhr-dev',targetCommit=base,contractReadCommit=base,uncommittedContractPaths=[])
assert dp['knowledgeBaselineVersion']=='0.3.25' and dp['impactAnalysis']['level']=='L2'
assert dp['unresolved']==[] and dp['replacementScopes']==[]
changed=git('diff','--name-only',base,candidate).decode().splitlines()
expected={dp_path,
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlDiffTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'}
assert set(changed)==expected
for p in paths:
    if p not in expected: assert git('show',f'{base}:{p}')==git('show',f'{candidate}:{p}'),p
diff=git('diff',base,candidate).decode();(out/'candidate.diff').write_text(diff)
old_service=git('show',base+':gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java')
(out/'baseline-RecordControlDiff.java').write_bytes(old_service)
new_service=(repo/'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java').read_text()
assert 'clearHistoricalSignatures(snapshot.path("fields"), proposed);' in new_service
assert new_service.index('clearHistoricalSignatures(snapshot.path("fields"), proposed);')>new_service.index('拟变更数据包含未知字段')
assert 'ObjectNode proposed = ((ObjectNode) source).deepCopy();' in new_service
assert 'if ("signature".equals(field.path("type").asText())) values.remove(id);' in new_service

inventory=[]
for p in git('ls-tree','-r','--name-only',base,'docs/knowledge').decode().splitlines():
    data=(repo/p).read_bytes();assert data==git('show',f'{base}:{p}')==git('show',f'{candidate}:{p}'),p
    inventory.append({'path':p,'bytes':len(data),'sha256':sha(data)})
assert len(inventory)==353
dump('knowledge-inventory.json',{'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','files':inventory,'scope':'Byte inventory only;not353 semantic passes'})
validator_paths=sorted(str(p.relative_to(repo)) for p in (repo/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java'))
validator_paths.append('gmp-platform/backend/pom.xml')
assert len(validator_paths)==6
validator_inputs=[]
for p in validator_paths:
    assert (repo/p).read_bytes()==git('show',f'{base}:{p}')==git('show',f'{candidate}:{p}')
    validator_inputs.append({'path':p,'sha256':sha((repo/p).read_bytes())})
prior_report=repo/'docs/development/branch-review-20261110-workflow-candidate-batch'
prior_packages=json.loads((prior_report/'evidence-packages.json').read_text())
prior=next(x for x in prior_packages['packages'] if x['name']=='main')
archive=prior_report/prior['path'];assert sha(archive.read_bytes())==prior['sha256']
with zipfile.ZipFile(archive) as z:
    for name in ['knowledge/run.json','knowledge/test-summary.json','knowledge/maven.log','knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']:
        dest=out/'reused-pr79-main'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(name))
original_run=json.loads((out/'reused-pr79-main/knowledge/run.json').read_text())
assert len(original_run['sourceFingerprints'])==359
assert original_run['exitCode']==0
original_xml=ET.parse(out/'reused-pr79-main/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml').getroot()
assert {k:int(original_xml.attrib[k]) for k in ['tests','failures','errors','skipped']}==dict(tests=89,failures=0,errors=0,skipped=0)
for item in original_run['sourceFingerprints']:
    assert sha((repo/item['path']).read_bytes())==item['sha256']
dump('knowledge-validation-reuse.json',{'roleExecutedKnowledgeTests':False,'originalActualTests':89,
 'originalHead':original_run['head'],'sourceArchive':str(archive.relative_to(repo)),'sourceArchiveSha256':prior['sha256'],
 'knowledgeFilesUnchanged':353,'additionalValidatorAndPomInputsUnchanged':validator_inputs,
 'original359InputFingerprintsMatch':True,'qualification':'Reused original actual89;this role did not execute Maven or semantic-check353 files'})

def locate(path,wanted):
    doc=yaml.safe_load((repo/path).read_text())
    def walk(value,location):
        if isinstance(value,dict):
            if value.get('id')==wanted:return value,location
            for key,child in value.items():
                hit=walk(child,location+'.'+key)
                if hit:return hit
        if isinstance(value,list):
            for i,child in enumerate(value):
                hit=walk(child,f'{location}[{i}]')
                if hit:return hit
        return None
    found=walk(doc,'$');assert found,(path,wanted);return found
d87='docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml'
d74=next(p for p in paths if '/DEC-0074' in p)
records=[]
def record(identifier,path,kind,status,conclusion,evidence):
    asset,locator=locate(path,identifier)
    records.append({'id':identifier,'recordType':kind,'sourcePath':path,'sourceLocator':locator,
      'originalMaturity':asset.get('status'),'originalVisibility':asset.get('visibility'),
      'scopeClassification':'current-limited-slice' if status=='consistent' else 'historical-or-existing-question',
      'semanticReviewStatus':status,'conclusion':conclusion,'originalRecord':asset,'originalEvidenceReferences':evidence})
common=['docs/knowledge/evidence/record-control-v1-user-confirmed.md',d87,
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java']
record('DEC-0087-02',d87,'decision-statement','consistent','模板与实例修订独立；新拟值不回写旧有效值，旧修订和快照保持。',common)
record('DEC-0087-04',d87,'decision-statement','consistent','冻结fieldId/行ID/fileId差异与真实内容变化要求保持；清除旧签名不是新的内容差异。',common)
record('DEC-0087-06',d87,'decision-statement','consistent','Rev1签名归旧修订；Rev2不继承，父表只读/停用没有例外；申请/审批签名仍各归动作，本期不新增原签署人重签。',common)
record('scenario.record-control-v1-revision-approval',d87,'acceptance-scenario','consistent','规范要求新修订唯一生效、旧修订/签名只读；运行是否通过由本批主侧和独立质量原件分别证明。',common)
record('term.form-instance-revision','docs/knowledge/glossary.yaml','term','consistent','同实例内容修订与模板版本独立；清除只在新拟值，不改历史定义/成熟度。',common)
record('concept.form-instance-revision','docs/knowledge/ontology.yaml','concept','consistent','概念保持specified/internal；局部代码修复不提升verified/runtime。',common)
record('relation.form-instance-current-revision','docs/knowledge/ontology.yaml','relation','consistent','one-to-zero-or-one保持；本批不改批准生效与唯一约束。',common)
record('relation.form-instance-has-revisions','docs/knowledge/ontology.yaml','relation','consistent','历史多修订关系保持，不删除旧签名或旧修订。',common)
record('evidence.record-control-v1-user-confirmed','docs/knowledge/evidence/record-control-v1.yaml','evidence','consistent','原确认明确新修订不继承签名；该来源本身不是运行证明，权限/DHR历史时点不得整篇当当前实现。',common)
record('rule.record-control-final-result-delivery','docs/knowledge/rules/record-change.yaml','rule','consistent','原同步结果/事务回滚保留；清除在提交拟值阶段，不拆审批事务。',common)
record('DEC-0087-09',d87,'decision-statement','consistent','受控申请签名仍与原业务字段签名分开，通用隔离未改；其详情范围仅按已明确DEC0096只读例外解释。',common)
record('DEC-0074-01',d74,'decision-statement','consistent','共享终端按钮真实签署人认证与动作资格保持，登录人/签署人不混用。',common+[d74])
record('DEC-0074-04',d74,'decision-statement','consistent','SIGN_FIELD仍按当前会话与个人签名认证；拟值清除不扩按钮admin或跨账号例外。',common+[d74])
record('rule.production-inline-signature','docs/knowledge/rules/production-field-signature.yaml','rule','consistent','普通生产份内内容修改重签与记录控制受控新修订不要求原签署人重签分属动作；历史保存原则一致，无冲突。',common+[d74])
record('evidence.record-control-workflow-stage1-candidate-api','docs/knowledge/evidence/record-control-workflow-stage1.yaml','evidence','superseded','仅旧REST创建权限叙述由DEC0094精确替代；保留原阶段证据，其余来源资格/显式版本启动不废弃。本批候选代码不改。',['docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',common[2]])
record('question.multi-tenant-workflow-isolation','docs/knowledge/open-questions.yaml','open-question','needs-decision','已有非MVP多租户未决，不阻断当前默认单租户切片，不由本批关闭。',['docs/knowledge/open-questions.yaml'])
record('question.record-control-active-form-void-boundary','docs/knowledge/open-questions.yaml','open-question','needs-decision','未来活动记录作废边界仍待定；本批已完成来源的CHANGE签名归属不依赖此选择。',['docs/knowledge/open-questions.yaml',d87])
dump('finite-review-records.json',{'scope':'Finite17 existing records for this slice;overlaps historical reviews,not additive unique or whole-corpus semantics',
 'counts':{'consistent':14,'superseded':1,'needs-decision':2},'records':records})
assert len(records)==17

main_raw=Path('/tmp/edhr-record-subtable-guards-20261110/focused_old')
negative=json.loads((main_raw/'test-summary.json').read_text())
assert negative['totals']==dict(tests=16,failures=8,errors=0,skipped=0)
for name in ['test-summary.json','run.json']:
    dest=out/'reviewed-main-negative'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((main_raw/name).read_bytes())
old_run=json.loads((main_raw/'run.json').read_text())
for item in old_run['sourceFingerprints']:
    if item['path'].endswith('/RecordControlDiffTest.java') or item['path'].endswith('/RecordControlPostgresIntegrationTest.java'):
        assert item['sha256']==sha(git('show',f"{candidate}:{item['path']}"))
copied_observations=[]
for file in sorted((main_raw/'signature-observations').glob('*.json')):
    evidence=json.loads(file.read_text());request=evidence['request'];current=evidence['current'];history=evidence['history']
    assert request['proposedValues']['rows'][0]['signed']
    assert current['fieldValues']['rows'][0]['signed']
    assert history[0]['fieldValues']['rows'][0]['signed']
    assert evidence['signatureBefore']==evidence['signatureAfter']
    assert evidence['oldValuesBefore']==evidence['oldValuesAfter'] and evidence['oldHashBefore']==evidence['oldHashAfter']
    dest=out/'reviewed-main-negative'/file.name;dest.write_bytes(file.read_bytes());copied_observations.append(file.name)
assert len(copied_observations)==4
dump('reviewed-negative-evidence.json',{'source':'Main-side original negative evidence inspected,not executed by this role',
 'mainTotals':negative['totals'],'sameFinalNativeAndUnitTestBytes':True,'observations':copied_observations,
 'finding':'All four locked-parent cases carry original signature into proposed/current/revision2;old original rows/hash remain',
 'qualification':'Synthetic distinct completed source through saved and actual signField;does not prove browser source-creation reachability or production rollout'})

dump('source-binding.json',{'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'sourceCommit':candidate,'targetCommit':base,'contractReadCommit':base,'bindingWorkingTreeStatus':entry_status,
 'uncommittedContractPaths':[],'decisionPackageOriginallyReadAsUncommitted':dp_path,
 'decisionPackageNowCommittedAt':candidate,'candidateChangedPaths':changed,'sourceFingerprints':inputs,
 'unchangedCommandAuthSchemaUiAndKnowledge':True,
 'roleExecutedMavenPgHttpBrowser':False,'roleModifiedRepository':False,'children':[]})
dump('engineering-boundaries.json',{
 'confirmedPolicy':'DEC0087-06: new controlled revision does not inherit original business signatures;historical source signatures retained',
 'noNewPolicyOrReplacement':True,'existingInputGuardsAndDiffsBeforeClearing':True,'clearOnlyDeepCopyByFrozenSignatureFieldType':True,
 'ordinaryProductionResignRuleScopeRetained':True,
 'storedRequestsAndHistoricalRevisionData':'No cleanup/migration;already IN_REVIEW proposals or prior Rev2 are not sanitized by this prepare-only change',
 'scopeSignalOnly':['reference context may be missing','another digest path uses full arrays','formula string does not prove supported runtime type'],
 'wholeAuditBacklog':'W2-W7/full semantic/A12/high-risk/matrices/capacityUNKNOWN/strict86/lint/paused retain original scope'})
ontology={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':dict(sourceCommit=candidate,targetBranch='edhr-dev',targetCommit=base,contractReadCommit=base,uncommittedContractPaths=[]),
 'reason':'本批依据既有DEC0087-02/04/06及原用户证据修复新拟修订签名继承遗漏；父表只读/停用不构成继承例外。统一清除仅消费冻结字段结构及deepCopy拟值，原签名/修订/快照、真实签署/权限/事务/UI/schema保持，无新概念、政策、替代或成熟度变化，故不新建重复本体资产。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  dict(id='validation.actual-source-contract',checkType='evidence-path',command='Read required contracts/DP and bind candidate/target/source bytes;independently fetch target0701',outcome='passed',evidence=['source-binding.json','candidate.diff','source']),
  dict(id='validation.finite-signature-semantics',checkType='projection',command='Review17 existing original records;preserve14 current-scope meanings,1 exact historical replacement,2 existing out-of-scope questions',outcome='passed',evidence=['finite-review-records.json','engineering-boundaries.json','REVIEW.md']),
  dict(id='validation.unchanged-knowledge-inputs',checkType='reference',command='Compare353 knowledge and6 validator/POM inputs against base/candidate and original actual89 fingerprints',outcome='passed',evidence=['knowledge-inventory.json','knowledge-validation-reuse.json']),
  dict(id='validation.reused-actual-knowledge89',checkType='schema',command='REUSED originalPR79 main actual89 only;this role did not execute Maven or tests',outcome='passed',evidence=['reused-pr79-main/knowledge/run.json','reused-pr79-main/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']),
  dict(id='validation.review-original-negative',checkType='evidence-path',command='Inspect main16=8P8F/0E/S and4 native persisted-signature original JSON;no role test execution',outcome='passed',evidence=['reviewed-negative-evidence.json','reviewed-main-negative'])],
 'roadmapProgress':dict(stage='P0',status='in-progress',exitCriteriaEvidence=[],deferredStages=['P1','P2','P3'])}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(ontology,allow_unicode=True,sort_keys=False))
print(json.dumps({'source':candidate,'protectedInputs':len(inputs),'finite':len(records),'knowledgeFiles':353,'result':'not-applicable','raw':str(out)},ensure_ascii=False))
