from pathlib import Path
from collections import defaultdict
import datetime,hashlib,json,re,shutil,subprocess,xml.etree.ElementTree as ET

raw=Path(__file__).parent
repo=Path('/workspace/edhr-nexus-frontend')
wt=Path('/tmp/edhr-record-subtable-signature-qa-worktree-20261110')
head='ab5b44d2292a8a7a08cbeb6aba502b30f50df8f0';base='0701b3d5d99787195e9d4c33935ae36da370839d'
def read(p):return json.loads(p.read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(commit,path):return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=repo)
run=read(raw/'final_verified/run.json')
assert run['head']==head and run['exitCode']==0
assert run['workingTreeStatus']=='?? gmp-platform/frontend/node_modules'
for item in run['sourceFingerprints']:
    data=(raw/'final_verified/source'/item['path']).read_bytes()
    assert item['sha256']==sha(data)==sha(blob(head,item['path']))==sha((wt/item['path']).read_bytes())
assert read(raw/'final_verified/test-summary.json')['totals']==dict(tests=123,failures=0,errors=0,skipped=0)
assert read(raw/'knowledge/test-summary.json')==dict(tests=89,failures=0,errors=0,skipped=0)
for item in read(raw/'knowledge/run.json')['sourceFingerprints']:
    assert item['sha256']==sha(blob(head,item['path']))==sha(blob(base,item['path']))

negative=raw/'main-negative-evidence'
if not negative.exists():shutil.copytree('/tmp/edhr-record-subtable-guards-20261110/focused_old',negative)
old=read(negative/'run.json')
assert old['head']==base
for path in ['gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlDiffTest.java',
             'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java']:
    assert sha((negative/'source'/path).read_bytes())==sha(blob(head,path))
product='gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java'
assert sha((negative/'source'/product).read_bytes())==sha(blob(base,product))
assert read(negative/'test-summary.json')['totals']==dict(tests=16,failures=8,errors=0,skipped=0)
failures=[]
for p in negative.glob('TEST-*.xml'):
    for t in ET.parse(p).getroot().findall('testcase'):
        assert t.find('error') is None
        if t.find('failure') is not None:
            assert t.attrib['name'].startswith(('lockedParentDoesNotCarryHistoricalSignaturesIntoProposal','lockedParentSignatureIsHistoricalAfterApprovedChange'))
            failures.append({'class':t.attrib['classname'],'case':t.attrib['name'],'message':t.find('failure').attrib.get('message')})
assert len(failures)==8
(raw/'old-negative-binding.json').write_text(json.dumps({'sameNativeAndUnitTestBytes':True,'oldProductExactBase':True,'failures':failures},ensure_ascii=False,indent=2)+'\n')

def signature_inserts(folder):
    lines=(folder/'postgres.log').read_text().splitlines();records=[]
    for i,line in enumerate(lines):
        if not re.search(r'LOG:.*\bexecute\b',line):continue
        m=re.search(r'insert into signature \(([^)]+)\) values \(([^)]+)\)',line,re.I)
        if not m:continue
        columns=m[1].split(',');positions=m[2].split(',')
        if not all(re.fullmatch(r'\$\d+',p) for p in positions):continue
        assert len(columns)==len(positions)
        param=lines[i+1];assert 'DETAIL:  parameters:' in param
        binds={int(n):None if value=='NULL' else value[1:-1].replace("''", "'")
               for n,value in re.findall(r"\$(\d+) = (NULL|'.*?')(?=, \$\d+ =|$)",param)}
        assert len(binds)==len(positions)
        records.append(dict(zip(columns,[binds[int(p[1:])] for p in positions])))
    return records

payloads=[]
for name,folder,want_signature in [('old',negative,True),('independent',raw/'final_verified',False)]:
    inserts=signature_inserts(folder)
    reports=sorted((folder/'signature-observations').glob('*.json'))
    assert len(reports)==4
    http=[json.loads(line) for line in (folder/'http.jsonl').read_text().splitlines()]
    relevant=[x for x in http if x['case'].startswith('locked-parent-')]
    assert len(relevant)==12 and all(x['actualStatus']==x['expectedStatus']==200 for x in relevant)
    for p in reports:
        x=read(p);sig=json.loads(x['signatureBefore']);signature=json.loads(sig['snapshot_data'])['signature']
        assert x['signatureBefore']==x['signatureAfter']
        assert sha(sig['snapshot_data'].encode())==sig['snapshot_hash']
        assert x['oldValuesBefore']==x['oldValuesAfter']
        assert sha(x['oldValuesBefore'].encode())==x['oldHashBefore']==x['oldHashAfter']
        assert x['history'][1]['revision_no']=='1' and x['history'][1]['status']=='SUPERSEDED'
        assert x['history'][0]['revision_no']=='2' and x['history'][0]['status']=='EFFECTIVE'
        assert x['history'][1]['fieldValues']['rows'][0]['signed']==signature
        assert x['request']['sourceValues']['rows'][0]['signed']==signature
        contexts=[x['request']['proposedValues'],x['current']['fieldValues'],x['history'][0]['fieldValues'],
                  json.loads(x['executionStateAfter'])['operations']['op']['forms']['guarded-form']['values']]
        assert all(('signed' in c['rows'][0])==want_signature for c in contexts)
        for c in contexts:
            assert c['value']=='new' and c['rows'][0]['note']=='original'
            assert c['rows'][0]['__rowId']=='11111111-1111-4111-8111-111111111111'
        assert sha(json.dumps(x['history'][0]['fieldValues'],ensure_ascii=False,separators=(',',':')).encode())==x['history'][0]['content_hash']
        assert x['current']['snapshot']==x['request']['snapshot']
        assert x['request']['diff']==[{'fieldId':'value','fieldType':'text','fieldPath':'value','changeType':'FIELD_CHANGED','before':'old','after':'new'}]
        field=[s for s in inserts if s['id']==str(x['fieldSignatureId'])]
        submit=[s for s in inserts if s['id']==str(x['request']['applicant_signature_id'])]
        approval=[s for s in inserts if s['target_id']==x['requestId'] and s['meaning'].startswith('APPROVE')]
        assert len(field)==len(submit)==len(approval)==1
        for kind,s,signer in [('field',field[0],'41'),('submit',submit[0],'41'),('approve',approval[0],'42')]:
            data=json.loads(s['snapshot_data']);assert sha(s['snapshot_data'].encode())==s['snapshot_hash']
            assert s['signer_id']==signer and s['auth_method']=='SIGNATURE_PASSWORD'
            if kind=='field':
                assert s['target_type']=='PRODUCTION_EXECUTION' and s['target_id']=='109'
                assert data['signature']==signature and data['rowId']=='11111111-1111-4111-8111-111111111111'
            else:
                assert s['target_type']=='RECORD_CONTROL_REQUEST' and s['target_id']==x['requestId']
                assert data['sessionOperatorId']=='41' and data['signerId']==signer
                assert data['values']['requestId']==x['requestId']
                if kind=='submit':
                    assert data['values']['sourceValues']==x['request']['sourceValues']
                    assert data['values']['proposedValues']==x['request']['proposedValues']
                else:assert data['values']['action']=='APPROVE'
            payloads.append({'phase':name,'case':x['case'],'kind':kind,'id':s['id'],'signer':signer,'sha256':s['snapshot_hash']})
assert len(payloads)==24

# Retained candidate-query regression: independently count executed original SQL and actual plans.
log=(raw/'final_verified/postgres.log').read_text();counts=defaultdict(lambda:dict(selects=0,plans=0))
for line in log.splitlines():
    m=re.search(r'\b(wf-candidates-\d+-(?:change|obsolete)-[12])\b',line)
    if not m:continue
    if re.search(r'LOG:.*\bexecute\b.*:\s*select\b',line,re.I):counts[m[1]]['selects']+=1
    if 'plan:' in line:counts[m[1]]['plans']+=1
assert len(counts)==20 and all(v==dict(selects=1,plans=1) for v in counts.values())
for p in (raw/'final_verified/candidate-observations').glob('*.json'):
    x=read(p);assert x['beforeStateDigest']==x['afterStateDigest']
    for item in x['observations']:
        assert item['returned']==x['catalogSizePerType'] and len(item['sql'])==1
        assert 'nodes_json' not in item['sql'][0] and 'edges_json' not in item['sql'][0]
assert read(raw/'final_verified/cleanup.json')['removed']

result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'base':base,'candidate':head,
 'mainIndependentRun':dict(tests=123,failures=0,errors=0,skipped=0),'nativePG':87,'otherTests':36,
 'knowledgeActual':dict(tests=89,failures=0,errors=0,skipped=0),'protectedRuntimeInputs':len(run['sourceFingerprints']),
 'oldSourceSameTestBytes':dict(tests=16,passed=8,failures=8,errors=0,skipped=0),'oldNativeApprovedWithInheritedSignature':4,
 'independentNativeApprovedWithoutInheritedSignature':4,'bothPhaseHttp200':24,
 'originalSignatureRowAndRevision1RawBytesAndHashPreserved':8,'revision2HashesIndependentlyRecomputed':8,
 'actualParameterizedSignatureInsertPayloadHashesVerified':payloads,'retainedCandidateActualQueriesAndPlans':dict(counts),
 'scope':'New prepare applications only;no stored in-review/history cleanup;synthetic fixtures and real password/signField/JWT+MockMvc,not browser/production rollout'}
(raw/'independent-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['actualParameterizedSignatureInsertPayloadHashesVerified','retainedCandidateActualQueriesAndPlans']},ensure_ascii=False,indent=2))
