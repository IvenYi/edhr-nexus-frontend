from pathlib import Path
import datetime,hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
root=Path('/tmp/edhr-record-subtable-signature-qa-worktree-20261110')
out=Path(__file__).parent/'knowledge';out.mkdir()
paths=sorted(p for p in (root/'docs/knowledge').rglob('*') if p.is_file())
paths+=sorted((root/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java'))
paths+=[root/'gmp-platform/backend/pom.xml']
inputs=[]
for p in paths:
    data=p.read_bytes();rel=p.relative_to(root)
    inputs.append({'path':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    dest=Path(__file__).parent/'read-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','-f','gmp-platform/backend/pom.xml','-Dtest=BusinessKnowledgeModelTest','-DargLine=-Xmx1024m','test']
started=datetime.datetime.now(datetime.timezone.utc)
record={'command':cmd,'startedAt':started.isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'workingTreeState':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'sourceFingerprints':inputs}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'maven.log').open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat());(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
xml=root/'gmp-platform/backend/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
assert xml.stat().st_mtime>=started.timestamp();shutil.copyfile(xml,out/xml.name)
x=ET.parse(xml).getroot().attrib;counts={k:int(x[k]) for k in ['tests','failures','errors','skipped']}
(out/'test-summary.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps(counts))
assert r.returncode==0 and counts==dict(tests=89,failures=0,errors=0,skipped=0)
