import pathlib,subprocess,json,hashlib,tarfile,csv,io,collections,re,datetime,xml.etree.ElementTree as ET
repo=pathlib.Path('/workspace/edhr-nexus-frontend');scope=repo/'docs/development/branch-review-20261102-dhr-attachment-query';out=pathlib.Path('/tmp/edhr-dhr-query-final-qa-artifacts-20261102');out.mkdir(exist_ok=True)
base='8ec8391721858a7f96d73a5d293d93f43679118a';head='ec72883796766eba1c693b2d023bf8d112d86564'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def digest(data):return hashlib.sha256(data).hexdigest()
def emit(name,data):(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD').decode().strip()==head
changes=git('diff','--name-status',base,head).decode()
contracts=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md']
emit('baseline.json',{'headCommit':head,'baseCommit':base,'workingTreeStatus':git('status','--porcelain').decode(),'contractReadCommit':head,'contractFiles':[{'path':p,'bytes':len((repo/p).read_bytes()),'sha256':digest((repo/p).read_bytes()),'equalToBase':git('show',base+':'+p)==(repo/p).read_bytes()} for p in contracts],'changedPaths':changes.splitlines()})

manifest=json.loads((scope/'evidence-manifest.json').read_text());archive=scope/manifest['archive']['path'];raw=archive.read_bytes();assert len(raw)==manifest['archive']['bytes'];assert digest(raw)==manifest['archive']['sha256']
with tarfile.open(archive,'r:gz') as tar:
    names=tar.getnames();assert len(names)==len(set(names))
    assert all(m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts for m in tar.getmembers())
    data={n:tar.extractfile(n).read() for n in names}
rows=manifest['artifacts'];assert manifest['artifactCount']==len(rows)==32
assert set(data)=={r['member'] for r in rows}|{'manifest.json'}
checked=[]
for item in rows:
    b=data[item['member']];assert len(b)==item['bytes'];assert digest(b)==item['sha256'];checked.append({'member':item['member'],'bytes':len(b),'sha256':digest(b)})
inner=json.loads(data['manifest.json']);assert inner=={k:v for k,v in manifest.items() if k!='archive'}
ontology=json.loads(data['ontology/manifest.json']);assert ontology['count']==len(ontology['rawArtifacts'])==10
for item in ontology['rawArtifacts']:
    b=data['ontology/'+item['path']];assert len(b)==item['rawBytes'];assert digest(b)==item['sha256']
emit('artifact-byte-check.json',{'archive':{'bytes':len(raw),'sha256':digest(raw)},'regularSafeUniqueMembers':len(data),'manifestedRawArtifacts':len(rows),'innerManifestEqualTopExceptArchive':True,'ontologyOriginalManifestSha256':digest(data['ontology/manifest.json']),'ontologyRawArtifactsVerified':10,'allArtifacts':checked})

source=json.loads((scope/'source-review.json').read_text());assert source['wholeFileCompletion']==0 and source['historicalUniqueIncrement'] is None and source['performanceImplementation'] is False
fingerprints=[]
for item in source['sourceFingerprints']:
    p=item['path'];b=git('show',head+':'+p)
    assert b==(repo/p).read_bytes()==data['source-snapshot/'+p]
    assert len(b)==item['bytes'] and digest(b)==item['sha256'];fingerprints.append({'path':p,'bytes':len(b),'sha256':digest(b)})
assert len(fingerprints)==7
osource=json.loads(data['ontology/source-manifest.json']);assert len(osource['files'])==23
for item in osource['files']:
    b=git('show',head+':'+item['path']);assert len(b)==item['rawBytes'] and digest(b)==item['sha256']
emit('source-fingerprint-check.json',{'currentSnapshotAndRecordedHashesMatch':True,'mainFingerprints':fingerprints,'ontologySourcesVerified':23,'sourceReviewWholeFileComplete':0,'historicalUniqueIncrement':None,'productOptimizationImplemented':False})

kmanifest=json.loads(data['ontology/knowledge-file-manifest.json']);knowledge=git('ls-tree','-rz','--name-only',head,'--','docs/knowledge').decode().strip('\0').split('\0');assert len(knowledge)==330
assert {p['path'] for p in kmanifest['files']}==set(knowledge)
kchecked=[]
for item in kmanifest['files']:
    p=item['path'];b=git('show',head+':'+p)
    assert b==git('show',base+':'+p)==(repo/p).read_bytes();assert len(b)==item['rawBytes'] and digest(b)==item['sha256'];kchecked.append({'path':p,'bytes':len(b),'sha256':digest(b)})
emit('knowledge-byte-check.json',{'sourceCommit':head,'baseCommit':base,'knowledgeFiles':len(kchecked),'allEqualBaseAndHeadAndRecordedRawHashes':True,'knowledgeModelVersion':kmanifest['knowledgeModelVersion'],'schemaVersion':kmanifest['schemaVersion'],'files':kchecked})

tree={}
for item in git('ls-tree','-rz','-l',base).split(b'\0'):
    if not item:continue
    meta,p=item.split(b'\t',1);mode,kind,blob,size=meta.decode().split();tree[p.decode()]={'mode':mode,'kind':kind,'blob':blob,'bytes':int(size) if size!='-' else None}
summary=json.loads((scope/'inventory/inventory-summary.json').read_text());coverage=list(csv.DictReader(io.StringIO((scope/'inventory/coverage.csv').read_text())))
assert len(tree)==len(coverage)==6785;assert {r['path'] for r in coverage}==set(tree)
assert len({r['path'] for r in coverage})==len(coverage)
assert summary['tree']==git('rev-parse',base+'^{tree}').decode().strip()
assert summary['trackedPaths']==summary['scopeCount']==len(tree) and summary['excludedPaths']==[] and summary['semanticReviewComplete'] is False
for row in coverage:
    assert row['baseline_commit']==base and row['source_evidence']==tree[row['path']]['blob']
    assert row['review_depth']=='inventory-only' and row['review_status']=='pending' and row['in_scope']=='true'
    assert row['exclusion_reason']==row['reviewer']==row['finding_ids']==row['tested_commit']==''
    assert row['notes'].startswith('Inventory only; no semantic conclusion.')
assert dict(collections.Counter(r['asset_type'] for r in coverage))==summary['assetTypes']
assert dict(collections.Counter(r['work_package'] for r in coverage))==summary['workPackages']
assert digest((scope/'inventory/coverage.csv').read_bytes())==summary['coverageSha256']
migrations=list(csv.DictReader(io.StringIO((scope/'inventory/migrations.csv').read_text())))
expectedMigrations={p for p in tree if '/db/changelog/' in p};assert {r['path'] for r in migrations}==expectedMigrations and len(migrations)==135==summary['migrationFiles']
assert all(r['baseline_commit']==base and r['blob']==tree[r['path']]['blob'] and r['status']=='inventory-only' for r in migrations)
entries=list(csv.DictReader(io.StringIO((scope/'inventory/entrypoints.csv').read_text())))
actual=[]
patterns={'http-annotation':re.compile(r'@(RequestMapping|GetMapping|PostMapping|PutMapping|PatchMapping|DeleteMapping)\b'),'background-candidate':re.compile(r'@(Scheduled|EventListener|TransactionalEventListener|Async|KafkaListener)\b|\bimplements\s+(?:ApplicationRunner|CommandLineRunner|SmartLifecycle)\b|\bnew(?:SingleThread|FixedThread|ScheduledThread)Pool\b|\bnewSingleThreadExecutor\b'),'state-definition-candidate':re.compile(r'\benum\s+\w*(?:State|Status)\b|\bclass\s+\w*(?:State|Status)Machine\b'),'frontend-route-candidate':re.compile(r'<Route\b|createBrowserRouter\b|\bpath\s*:')}
candidatePaths=[p for p in tree if p.startswith('gmp-platform/backend/src/main/') and p.endswith('.java') or p.startswith('gmp-platform/frontend/src/')]
for p in candidatePaths:
    b=git('cat-file','blob',tree[p]['blob'])
    try:text=b.decode('utf-8')
    except UnicodeDecodeError:continue
    if '\0' in text:continue
    kinds=['frontend-route-candidate'] if p.startswith('gmp-platform/frontend/') else ['http-annotation','background-candidate','state-definition-candidate']
    for num,line in enumerate(text.splitlines(),1):
        for kind in kinds:
            if patterns[kind].search(line):actual.append((base,kind,p,str(num),line.strip(),'candidate-needs-call-chain-review'))
asTuples=[tuple(r[k] for k in ['baseline_commit','kind','path','line','source','status']) for r in entries]
assert sorted(asTuples)==sorted(actual)
counts=dict(collections.Counter(r['kind'] for r in entries));assert counts==summary['entrypointCandidates'];assert counts['http-annotation']==464 and counts['frontend-route-candidate']==216
emit('inventory-check.json',{'sourceCommit':base,'trackedTreePaths':len(tree),'coveragePaths':len(coverage),'allPathSetsAndBlobsMatchGitTree':True,'allCoverageInventoryOnlyPending':True,'noExclusionsOrSemanticCompletion':True,'allMigrationPathsAndBlobsMatch':True,'migrationFiles':len(migrations),'actualEntrypointCandidates':counts,'entrypointRowsMatchedActualSourceLines':len(actual),'assetTypesFromVerifiedCoverage':dict(collections.Counter(r['asset_type'] for r in coverage)),'workPackagesFromVerifiedCoverage':dict(collections.Counter(r['work_package'] for r in coverage)),'fixedFileFingerprints':[{'path':str(p.relative_to(repo)),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted((scope/'inventory').iterdir())]})

xmls=[]
for n,b in data.items():
    if n.endswith('.xml'):
        doc=ET.fromstring(b);xmls.append({'member':n,'class':doc.attrib['name'],**{k:int(doc.attrib.get(k,0)) for k in ['tests','failures','errors','skipped']}})
assert len(xmls)==5 and sum(r['tests'] for r in xmls)==123 and all(r['failures']==r['errors']==r['skipped']==0 for r in xmls)
observation=json.loads(data['main/summary-prefix.json']);observed=[(x['attachments'],x['queries']) for x in observation['observations']];assert observed==[(0,5),(1,7),(10,25),(100,205),(300,605)]
assert all(len(x['sql'])==x['queries'] and '<unknown>' not in x['sql'] for x in observation['observations'])
lock=json.loads(data['main/parent-lock.json']);assert all(lock[k] is True for k in ['actualPgLockWaitObserved','historicalOriginalRetained','activeWhileParentLocked','unlinkCommittedAfterRelease'])
emit('archived-run-inspection.json',{'note':'Inspection only; independent runtime is performed by parent QA, not claimed by this child. Archived primary2+32 and ontology89 are distinct groups, not unique test coverage.','xmls':xmls,'primaryObservedAttachmentQueries':observed,'primaryLockOutput':lock,'mavenRunMetadata':[json.loads(data[n]) for n in ['main/run.json','neighbors/run.json']]})
emit('result.json',{'result':'passed','status':'FINAL','scope':'read-only artifact bytes, provenance/inventory/source-preservation subset; no runtime or full semantic judgment','baseCommit':base,'headCommit':head,'contractReadCommit':head,'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','checks':['32 raw artifacts+root manifest compressed archive','10 ontology raw originals+original manifest','7 source snapshot fingerprints','23 ontology source fingerprints','330 knowledge raw files head/base equality','6785 fixed tree paths exact/135 migration paths exact/689 actual candidate entrypoints','5 archived XMLs/primary SQL and lock outputs inspection'],'findings':[],'blockingConditions':[],'residualRisks':['Parent must run and conclude actual34+89 independently. Byte/pending inventory audit is not all-library semantic review/full lifecycle or production SLA.'],'repositoryWrites':[]})
print(json.dumps({'result':'passed','rawArtifacts':32,'tarMembers':len(data),'sourceFingerprints':7,'ontologySources':23,'knowledgeFiles':330,'paths':len(tree),'migrations':135,'entrypointCandidates':counts},ensure_ascii=False))
