import pathlib,subprocess,os,time,json,datetime,hashlib,shutil,xml.etree.ElementTree as ET
repo=pathlib.Path('/workspace/edhr-nexus-frontend');wt=pathlib.Path('/tmp/edhr-dhr-query-final-qa-wt-20261102');out=pathlib.Path('/tmp/edhr-dhr-query-final-qa-20261102');out.mkdir(exist_ok=True)
head='ec72883796766eba1c693b2d023bf8d112d86564';base='8ec8391721858a7f96d73a5d293d93f43679118a';name='edhr-dhr-query-final-qa-20261102';created=False;linked=False;worktree=False
def run(args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout.strip()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(name,data):(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
try:
    run(['git','worktree','add','--detach',str(wt),head],cwd=repo);worktree=True
    status=run(['git','status','--porcelain'],cwd=wt);assert not status
    paths=run(['git','ls-files'],cwd=wt).splitlines()
    protected=[p for p in paths if p.startswith(('gmp-platform/backend/src/','gmp-platform/frontend/src/','docs/knowledge/','tools/knowledge-model/','docs/agents/','docs/development/branch-review-20261102-dhr-attachment-query/')) or p in ('AGENTS.md','codeplzreadme.md','docs/architecture/business-knowledge-model.md')]
    fingerprints=[{'path':p,'bytes':len((wt/p).read_bytes()),'sha256':hashlib.sha256((wt/p).read_bytes()).hexdigest()} for p in protected]
    write('protected-manifest.json',{'headCommit':head,'baseCommit':base,'initialStatus':status,'artifacts':fingerprints})
    frontend=wt/'gmp-platform/frontend/node_modules';frontend.symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True);linked=True
    cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
    for i in range(120):
        if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('TCP PostgreSQL not ready')
    port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
    env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_dhr_attachment_transaction_test',EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',EDHR_ATTACHMENT_QUERY_OUTPUT=str(out))
    write('database.json',{'containerId':cid,'name':name,'url':env['EDHR_DHR_ATTACHMENT_TX_DATABASE_URL'],'version':run(['docker','exec',name,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT version()']),'collation':run(['docker','exec',name,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc',"SELECT datcollate FROM pg_database WHERE datname=current_database()"]),'tcpReady':True})
    commands=[('backend',['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest=DhrAttachmentQueryObservationPostgresTest,DhrSummaryServiceTest,DhrAttachmentTransactionPostgresTest,DhrAttachmentAndArchiveTest','test']),('knowledge',['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test'])]
    records=[]
    for label,command in commands:
        start=now()
        with (out/(label+'.log')).open('w') as log:r=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
        records.append({'label':label,'command':command,'cwd':str(wt),'started':start,'finished':now(),'exitCode':r.returncode,'baseCommit':base,'headCommit':head})
        folder=wt/('gmp-platform/backend/target/surefire-reports' if label=='backend' else 'tools/knowledge-model/target/surefire-reports')
        dest=out/(label+'-surefire');dest.mkdir(exist_ok=True)
        for file in folder.glob('TEST-*.xml'):shutil.copy2(file,dest/file.name)
    write('commands.json',records)
    counts={}
    for label,_ in commands:
        totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[]
        for xml in sorted((out/(label+'-surefire')).glob('TEST-*.xml')):
            doc=ET.parse(xml).getroot();entry={k:int(doc.attrib.get(k,0)) for k in totals}
            for k in totals:totals[k]+=entry[k]
            classes.append({'class':doc.attrib['name'],**entry})
        counts[label]={'totals':totals,'classes':classes}
    write('test-summary.json',counts)
    changed=[p['path'] for p in fingerprints if hashlib.sha256((wt/p['path']).read_bytes()).hexdigest()!=p['sha256']]
    write('source-preservation.json',{'protectedPaths':len(fingerprints),'changed':changed,'statusWithTooling':run(['git','status','--porcelain'],cwd=wt),'headCommit':run(['git','rev-parse','HEAD'],cwd=wt)})
    assert all(c['exitCode']==0 for c in records)
    assert counts['backend']['totals']=={'tests':34,'failures':0,'errors':0,'skipped':0}
    assert counts['knowledge']['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
    assert not changed
    print(json.dumps(counts,ensure_ascii=False))
finally:
    clean={}
    if created:clean['containerStop']=run(['docker','stop',name]);clean['dockerAfter']=run(['docker','ps','-a','--filter','name=^/'+name+'$','--format','{{.Names}}'])
    if linked:frontend.unlink();clean['toolSymlinkRemoved']=not frontend.exists()
    if worktree:
        clean['statusBeforeRemoval']=run(['git','status','--porcelain'],cwd=wt)
        run(['git','worktree','remove',str(wt)],cwd=repo);clean['worktreeRemoved']=not wt.exists()
    write('cleanup.json',clean)
