import hashlib
import json
import shutil
import subprocess
from pathlib import Path
import yaml

root = Path('/workspace/edhr-nexus-frontend')
out = Path('/tmp/edhr-dhr-query-ontology-20261102')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
target = subprocess.check_output(['git', 'rev-parse', 'origin/edhr-dev'], cwd=root, text=True).strip()
def digest(path):
    data = (root / path).read_bytes()
    return {'path': path, 'rawBytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
knowledge = sorted(subprocess.check_output(['git', 'ls-files', 'docs/knowledge'], cwd=root, text=True).splitlines())
knowledge_rows = [digest(path) for path in knowledge]
(out / 'knowledge-file-manifest.json').write_text(json.dumps({'sourceCommit': head, 'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0', 'files': knowledge_rows, 'count': len(knowledge_rows), 'semanticCoverageClaim': 'Byte inventory only; not all-library semantic audit completion.'}, ensure_ascii=False, indent=2) + '\n')

def records(value, path, locator='$'):
    result = []
    if isinstance(value, dict):
        if isinstance(value.get('id'), str):
            result.append((value['id'], value, path, locator))
        for key, item in value.items():
            result += records(item, path, locator + '.' + key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            result += records(item, path, locator + '[' + str(index) + ']')
    return result

summaries = {
    'term.dhr-controlled-attachment': '受控附件有来源/摘要/核验和关联历史；查询观测不改变附件身份。',
    'concept.dhr-controlled-attachment': '运行事实身份不变；未改为表单第四来源或提升成熟度。',
    'relation.dhr-summary-version-contains-controlled-attachments': '冻结版零到多附件引用保留；诊断不建立或删除成员。',
    'DEC-0063-05': '重核范围/阻断陈旧提交及冻结后不改写仍由实际submit执行；本诊断在人工guard停止，不证明成功冻结。',
    'DEC-0063-10': '七格式、52428800字节含边界、原件SHA和解除不删保持；本批无上传政策改动。',
    'DEC-0063-11': '冻结ZIP按显式版本及完整/选定范围输出；Archive额外冻结size/SHA比较不能被下载复用提案取消。',
    'DEC-0063-14': '诊断刻意缺三项确认并在原guard拒绝；不是移除人工确认或系统判定质量合格。',
    'rule.dhr-summary-only-after-production-complete': '实际submit在父锁后检查COMPLETED；fixtureCOMPLETED只定位观测前缀，不放宽资格。',
    'rule.dhr-summary-freeze-version': '无新增版本写入；版本不可变及重核完整范围均未改。',
    'rule.dhr-summary-manual-review-confirmation': '三项人工确认及说明要求不变；失败guard观测不构成成功提交验收。',
    'rule.dhr-summary-controlled-attachment-upload': '格式/容量、原件及冻结引用/历史保留保持；测试文件不改变生产限制。',
    'rule.dhr-review-task-frozen-attachment-download': 'review detail先授权任务，随后id+SHA校验冻结成员，仍以完整原件摘要校验通过后输出。',
    'rule.dhr-summary-zip-source-trace': 'Archive按冻结成员校验原件size+SHA并输出来源追溯，未将其套用无锁上下文复用。',
    'fact.dhr-summary.production-complete': 'lockedCompletedDhr有真实FOR UPDATE及COMPLETED守卫；测试不重定义状态。',
    'fact.dhr-summary.manual-review-confirmed': '当前sourceLocator与真实guard/冻结字段核对；保留specified状态，不据诊断提升verified。',
    'fact.dhr-summary.review-task-attachment-authorized': '任务资格与成员资格分别检查，不由普通DHR查看权替代。',
    'fact.dhr-summary.version-frozen': '本批诊断不产生版本；冻结行存在仍不等于已完成合规核查。',
    'DEC-0090-01': 'ZIP副本、汇总冻结和生命周期归档三者有别，查询观测不实现归档。',
    'DEC-0090-04': '归档/解封/放行未纳本批，不借有限诊断关闭归档TODO。',
}
lookup = {}
for path in knowledge:
    if path.endswith(('.yaml', '.yml')) and not path.endswith('schema.yaml'):
        for identity, record, source, locator in records(yaml.safe_load((root / path).read_text()), path):
            if identity in summaries:
                lookup[identity] = (record, source, locator)
assert set(lookup) == set(summaries), set(summaries) - set(lookup)
references = [
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
]
reviews = []
for identity, summary in summaries.items():
    record, source, locator = lookup[identity]
    reviews.append({'id': identity, 'recordType': 'decisionStatement' if identity.startswith('DEC-') else identity.split('.')[0],
                    'sourcePath': source, 'sourceLocator': locator, 'originalMaturity': record.get('status'),
                    'visibility': record.get('visibility'), 'auditScopeClass': 'finite-current-policy-boundary-only',
                    'reviewStatus': 'reviewed', 'conclusion': 'consistent', 'disposition': 'retained', 'summary': summary,
                    'evidence': references, 'limit': 'Consistent only for unchanged-policy diagnostics scope; no complete rule/runtime/all-library closure.'})
(out / 'id-disposition.jsonl').write_text(''.join(json.dumps(row, ensure_ascii=False) + '\n' for row in reviews))
(out / 'selected-records.yaml').write_text(yaml.safe_dump({'sourceCommit': head, 'selectedRecords': [lookup[i][0] for i in summaries]}, allow_unicode=True, sort_keys=False))
read_files = sorted(set([
    'AGENTS.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/business-knowledge-modeler.md',
    'docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml', 'docs/knowledge/schema.yaml',
    'docs/development/branch-review-20261102-dhr-attachment-query/decision-package.yaml',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentQueryObservationPostgresTest.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentTransactionPostgresTest.java',
    'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
    'tools/knowledge-model/pom.xml',
] + references + [lookup[i][1] for i in summaries]))
(out / 'source-manifest.json').write_text(json.dumps({'sourceCommit': head, 'targetCommit': target, 'contractReadCommit': head,
    'uncommittedContractPaths': [], 'files': [digest(p) for p in read_files], 'count': len(read_files),
    'workingTreeScope': ['new diagnostic test', 'decision package only; production/knowledge unchanged'],
    'inventoryNotSemanticCoverage': True}, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'knowledgeFiles': len(knowledge_rows), 'reviewedFiniteIds': len(reviews), 'sourceFiles': len(read_files), 'sourceCommit': head, 'targetCommit': target}))
