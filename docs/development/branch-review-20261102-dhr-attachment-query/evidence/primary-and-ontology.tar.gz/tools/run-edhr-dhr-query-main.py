import json, os, pathlib, subprocess, time, datetime, hashlib, sys
root=pathlib.Path('/workspace/edhr-nexus-frontend')
label=sys.argv[1] if len(sys.argv)>1 else 'main'
tests=sys.argv[2] if len(sys.argv)>2 else 'DhrAttachmentQueryObservationPostgresTest'
assert label in ('main','neighbors')
out=pathlib.Path('/tmp/edhr-dhr-query-'+label+'-20261102'); out.mkdir(exist_ok=True)
name='edhr-dhr-query-'+label+'-20261102'
def run(args, **kw):
    return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout.strip()
created=False
try:
    cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
    for _ in range(120):
        ready=subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True)
        if ready.returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('postgres not ready')
    port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
    env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_dhr_attachment_transaction_test',EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',EDHR_ATTACHMENT_QUERY_OUTPUT=str(out))
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+tests,'test']
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (out/'maven.log').open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    for test in tests.split(','):
        xml=root/('gmp-platform/backend/target/surefire-reports/TEST-com.zencas.edhr.production.service.'+test+'.xml')
        if xml.exists(): (out/xml.name).write_bytes(xml.read_bytes())
    metadata={'command':command,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceCommit':run(['git','rev-parse','HEAD'],cwd=root),'database':env['EDHR_DHR_ATTACHMENT_TX_DATABASE_URL'],'container':cid,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-Atc','SELECT version()'])}
    (out/'run.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(metadata,ensure_ascii=False)); print((out/'maven.log').read_text()[-7500:])
finally:
    if created:print('cleanup:',run(['docker','stop',name]))
