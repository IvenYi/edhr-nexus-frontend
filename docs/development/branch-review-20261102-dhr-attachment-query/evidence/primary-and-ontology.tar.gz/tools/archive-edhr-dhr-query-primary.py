import pathlib,json,hashlib,tarfile,xml.etree.ElementTree as ET,shutil
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=root/'docs/development/branch-review-20261102-dhr-attachment-query'
evidence=out/'evidence';evidence.mkdir(exist_ok=True)
stage=pathlib.Path('/tmp/edhr-dhr-query-primary-archive-20261102');stage.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
groups={'main':pathlib.Path('/tmp/edhr-dhr-query-main-20261102'),'neighbors':pathlib.Path('/tmp/edhr-dhr-query-neighbors-20261102'),'ontology':pathlib.Path('/tmp/edhr-dhr-query-ontology-20261102')}
for label,folder in groups.items():shutil.copytree(folder,stage/label,dirs_exist_ok=True)
tools=stage/'tools';tools.mkdir(exist_ok=True)
for name in ['run-edhr-dhr-query-main.py','build-edhr-dhr-query-source.py','archive-edhr-dhr-query-primary.py']:shutil.copy2('/tmp/'+name,tools/name)
for item in json.loads((out/'source-review.json').read_text())['sourceFingerprints']:
    path=item['path'];data=(root/path).read_bytes();assert sha(data)==item['sha256']
    dest=stage/'source-snapshot'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
summaries={}
for label in ('main','neighbors'):
    run=json.loads((stage/label/'run.json').read_text());assert run['exitCode']==0
    counts={k:0 for k in ('tests','failures','errors','skipped')};cases=[]
    for xml in sorted((stage/label).glob('TEST-*.xml')):
        doc=ET.parse(xml).getroot()
        for k in counts:counts[k]+=int(doc.attrib.get(k,0))
        cases.append({'class':doc.attrib['name'],**{k:int(doc.attrib.get(k,0)) for k in counts}})
    assert counts['failures']==counts['errors']==counts['skipped']==0
    assert counts['tests']==(2 if label=='main' else 32)
    summaries[label]={'counts':counts,'classes':cases}
(stage/'primary-test-summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
artifacts=[]
for file in sorted(stage.rglob('*')):
    if file.is_file():
        b=file.read_bytes();artifacts.append({'member':str(file.relative_to(stage)),'bytes':len(b),'sha256':sha(b)})
manifest={'baseCommit':'8ec8391721858a7f96d73a5d293d93f43679118a','artifactCount':len(artifacts),'artifacts':artifacts,'note':'Raw originals retained as tar members; main runner generalized with optional labels after initial default run, commands/run.json and exact source snapshots retained. Summary prefix and native parent lock are not full submit/HTTP/full migration/production SLA.'}
(stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
archive=evidence/'primary-and-ontology.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for file in sorted(stage.rglob('*')):
        if file.is_file():tar.add(file,arcname=str(file.relative_to(stage)),recursive=False)
manifest['archive']={'path':str(archive.relative_to(out)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'summary':summaries,'archive':manifest['archive'],'rawArtifacts':len(artifacts)},ensure_ascii=False))
