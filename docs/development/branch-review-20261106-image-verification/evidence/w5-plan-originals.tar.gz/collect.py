import subprocess, pathlib, hashlib, json, re, datetime

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path('/tmp/edhr-w5-hash-plan-20261106')
BASE = 'cf5594947e96dcc56497997d7941da0f7a89be7e'
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)
def fixed(path):
    return git('show', BASE + ':' + path)

all_paths = git('ls-tree', '-r', '--name-only', BASE, 'gmp-platform/backend/src/main/java').decode().splitlines()
sites = []
hash_calls = []
for path in all_paths:
    if not path.endswith('.java'):
        continue
    text = fixed(path).decode()
    for match in re.finditer(r'AuditEvent\.builder\(\)', text):
        end = text.find('.build()', match.start())
        assert end >= 0, path
        block = text[match.start():end + len('.build()')]
        sites.append({
            'path': path, 'line': text[:match.start()].count('\n') + 1,
            'endLine': text[:end].count('\n') + 1,
            'explicitSnapshotHash': '.snapshotHash(' in block,
            'setsCreatedAt': '.createdAt(' in block,
            'setsContentBefore': '.contentBefore(' in block,
            'setsContentAfter': '.contentAfter(' in block,
            'classification': 'automatic-pre-persist-seal',
            'originalBuilderBlock': block,
        })
    for match in re.finditer(r'(?:snapshotHash\(|setSnapshotHash|new AuditEvent|computeSnapshotHash\()', text):
        line = text[:match.start()].count('\n') + 1
        hash_calls.append({'path': path, 'line': line, 'text': text.splitlines()[line - 1].strip()})

extras = [
    'AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md',
    'docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/dto/AuditLogItem.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/DepartmentController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/Signature.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTest.java',
    'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
    'gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml',
    'docs/development/branch-review-20261026-capacity-audit/ledger/findings.json',
    'docs/development/branch-review-20261020-w3-write-boundaries/evidence/primary/edhr-w3-audit-hash-baseline-probe-summary.json',
    'docs/development/branch-review-20261020-w3-write-boundaries/evidence/helpers/edhr-w3-audit-hash-source-map.json',
]
paths = sorted(set([s['path'] for s in sites] + extras))
manifest = []
for path in paths:
    data = fixed(path)
    destination = OUT / 'source' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    manifest.append({'path': path, 'commit': BASE, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                     'scope': 'builder-block only' if path in {s['path'] for s in sites} else 'named source/contract/schema/reference ranges; not whole-file audit completion'})
dp = 'docs/development/branch-review-20261106-image-verification/decision-package.yaml'
data = (ROOT / dp).read_bytes()
destination = OUT / 'source' / dp
destination.parent.mkdir(parents=True, exist_ok=True)
destination.write_bytes(data)
manifest.append({'path': dp, 'commit': None, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                 'scope': 'uncommitted decision package read from main worktree'})
summary = {
    'schema': 'edhr-w5-readonly-hash-plan/v1', 'issueId': 'W5-AUDIT-HASH-001',
    'status': 'preexisting-medium-open; planning-only; not-fixed',
    'contractBaseline': {'sourceCommit': BASE, 'targetBranch': 'edhr-dev', 'targetCommit': BASE, 'contractReadCommit': BASE, 'uncommittedContractPaths': []},
    'knowledgeBaselineVersion': '0.3.25', 'knowledgeSchemaVersion': '1.2.0',
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'runtimeTestsExecuted': False, 'repositoryFilesModified': False,
    'builderSites': len(sites), 'builderFiles': len({s['path'] for s in sites}),
    'explicitAuditEventHashSites': sum(s['explicitSnapshotHash'] for s in sites),
    'allBuilderSitesSetCreatedAt': all(s['setsCreatedAt'] for s in sites),
    'caveat': 'Static main/java producer-site inventory at fixed commit; not production-data provenance or whole-file completeness. Current source does not identify historical hashes.',
    'sourceSearches': [
        'all tracked main/java at fixed commit: AuditEvent.builder(), new AuditEvent, setSnapshotHash, snapshotHash(), computeSnapshotHash()',
        'main/java and current changelog: INSERT/UPDATE/DELETE audit_event; no production mutation/direct writer found outside entity save',
        'repository consumers and all main/java audit_event references; no runtime computeSnapshotHash caller except @PrePersist',
    ],
}
assert summary['builderSites'] == 49 and summary['builderFiles'] == 37
assert summary['explicitAuditEventHashSites'] == 0 and summary['allBuilderSitesSetCreatedAt']
for name, value in [('producer-inventory.json', sites), ('hash-call-inventory.json', hash_calls), ('source-manifest.json', manifest), ('summary.json', summary)]:
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(summary, ensure_ascii=False, indent=2))
