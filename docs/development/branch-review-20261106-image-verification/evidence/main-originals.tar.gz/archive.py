from pathlib import Path
import hashlib,json,tarfile,sys,datetime
out=Path('/workspace/edhr-nexus-frontend/docs/development/branch-review-20261106-image-verification/evidence');out.mkdir(exist_ok=True)
entries=[]
for name,folder in [('main-originals','/tmp/edhr-image-verification-20261106'),('ontology-originals','/tmp/edhr-image-verification-ontology-20261106'),('w5-plan-originals','/tmp/edhr-w5-hash-plan-20261106')]:
 root=Path(folder);files=[p for p in sorted(root.rglob('*')) if p.is_file()];archive=out/(name+'.tar.gz')
 with tarfile.open(archive,'w:gz') as tar:
  for p in files:tar.add(p,arcname=p.relative_to(root),recursive=False)
 manifest=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
 entries.append({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'originalRoot':str(root),'fileCount':len(files),'files':manifest})
(out/'archive-manifest.json').write_text(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':entries},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in e.items() if k!='files'} for e in entries],indent=2))
