from pathlib import Path
import json,hashlib,re,collections,subprocess,xml.etree.ElementTree as ET,shutil
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-image-verification-20261106');out=r/'docs/development/branch-review-20261106-image-verification';base='cf5594947e96dcc56497997d7941da0f7a89be7e'
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def norm(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
red=json.loads((raw/'native-budget/test-summary.json').read_text());green=json.loads((raw/'native-retry/test-summary.json').read_text())
assert red['totals']=={'tests':27,'failures':2,'errors':0,'skipped':0};assert green['totals']=={'tests':87,'failures':0,'errors':0,'skipped':0}
events=[]
for p in sorted((raw/'native-retry/observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==52
parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(raw/'native-retry/postgres.log').read_text(),flags=re.M)
server=collections.defaultdict(collections.Counter);alltagged=collections.defaultdict(collections.Counter);errors=[]
for part in parts:
 m=re.search(r'edhr_dhr_attachment_write_test_image_retry (audit_write_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if m:
  shape=norm(m.group(2).strip());alltagged[m.group(1)][shape]+=1
  if shape.startswith('select'):server[m.group(1)][shape]+=1
 error=re.search(r'edhr_dhr_attachment_write_test_image_retry (audit_write_\w+) ERROR:  (.*)',part)
 if error:errors.append({'applicationName':error.group(1),'error':error.group(2)})
matched=[];types=collections.Counter();driver=[]
for e in events:
 observed=collections.Counter(norm(s) for s in e['jdbcQuerySql']+e['hibernateAttemptSql'] if norm(s).startswith('select'));actual=server[e['applicationName']].copy()
 for sql,n in (actual-observed).items():
  assert 'pg_catalog.pg_type' in sql,(e['name'],sql)
  driver.append({'event':e['name'],'sql':sql,'count':n});actual[sql]-=n
 assert observed==+actual,(e['name'],observed-actual,actual-observed)
 matched.append({'name':e['name'],'selectStatements':e['selectStatements'],'shapesMatch':True,'selectShapes':[{'sql':s,'count':n} for s,n in actual.items() if n]})
 for s,n in alltagged[e['applicationName']].items():types[s.split()[0]]+=n
 assert e['snapshotsRemoved']
 if e['snapshotPaths']:assert e['name'].startswith('verify_') or e['name'] in ['failure_verify_audit','reject_verify_tampered','reject_verify_invalid_format']
assert len(errors)==3 and all('native_' in e['error'] for e in errors)
write('server-sql-review.json',{'events':matched,'businessSELECT':sum(e['selectStatements'] for e in events),'taggedSuccessfulStatementTypes':dict(types),'driverMetadataSelect':driver,'expectedConstraintErrors':errors,'writeSemantics':'Successful write execution is not commit: 48 executions include 4 later rolled back; 3 failed INSERT CHECKs separate. Per-action tags exclude setup/assertion/parse/bind/transaction control.'})
comparisons=[]
for name in ['verify_size_1mib_channel','verify_size_10mib_channel','verify_size_50mib_channel','verify_size_50mib_generic']:
 before=json.loads((raw/'native-budget/observations'/f'{name}.json').read_text());after=next(e for e in events if e['name']==name)
 assert after['storedReadBytes']==after['data']['bytes']==after['snapshotWriteBytes'];assert len(after['snapshotPaths'])==1
 comparisons.append({'name':name,'bytes':after['data']['bytes'],'oldThreadAllocatedBytes':before['threadAllocatedBytes'],'newThreadAllocatedBytes':after['threadAllocatedBytes'],'oldElapsedNanos':before['elapsedNanos'],'newElapsedNanos':after['elapsedNanos'],'originalReadBytes':after['storedReadBytes'],'snapshotWriteBytes':after['snapshotWriteBytes'],'snapshotReadBytes':after['snapshotReadBytes'],'snapshotRemoved':after['snapshotsRemoved']})
small=[{k:v for k,v in e.items() if k not in ['jdbcQuerySql','hibernateAttemptSql','failureStack']} for e in events]
write('performance-report.json',{'baseCommit':base,'comparisons':comparisons,'events':small,'measurementLimits':['Same native test fingerprint and fixture generator for negative budget and positive final native tests; product implementation differs.','Calling-thread cumulative Java heap allocation; not peak, retained memory, RSS, native/direct buffers, physical IO, production concurrency or SLA.','Real Spring multipart adapter over disk Part; generic InputStream is synthetic, not actual servlet-container multipart parsing/HTTP/JWT/RBAC.','Large cases are valid padded PNG; JPEG small-format regression only. Image validation remains existing header/dimensions, not full pixel decode.','JFR logical IO by action thread and exact snapshot prefix/current fixture/store; extra snapshot write is an accepted tradeoff.','Synthetic unit stream/delete/path-change faults are not native disk-full/crash; cleanup failures log retained path and block VERIFIED.','PDF/Office/upload/large export remain unchanged and their capacity limits remain open.','AuditEvent hash presence/identity/action/atomicity tested, not old W5 recomputation.']})
knowledge=[]
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,raw/'knowledge'/p.name);a=ET.parse(p).getroot().attrib;knowledge.append({'class':a['name'],**{k:int(a[k]) for k in ['tests','failures','errors','skipped']}})
assert sum(e['tests'] for e in knowledge)==89 and all(e['failures']==e['errors']==e['skipped']==0 for e in knowledge)
write('main-validation.json',{'negativeBudget':red,'finalRegression':green,'knowledge':knowledge,'actions':52,'businessSELECT':sum(e['selectStatements'] for e in events),'serverTypes':dict(types),'constraintErrors':len(errors),'intermediateAttempt':{'phase':'native-optimized','outcome':'test compile failed on AssertJ ObjectAssert.hasMessage; main fixed assertion typing without lowering requirement; zero fresh tests, raw retained'},'scope':'27 native + 54 adjacent + 6 new lifecycle unit tests =87. Not all87 PostgreSQL or full-system/UI acceptance.'})
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines();changed=subprocess.check_output(['git','diff','--name-only',base],cwd=r,text=True).splitlines()
production=[p for p in changed if p.startswith('gmp-platform/') and '/src/main/' in p];assert production==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java']
protected=[]
for path in paths:
 if path.startswith('docs/knowledge/') or path.startswith('docs/agents/') or path in ['AGENTS.md','codeplzreadme.md']:
  old=subprocess.check_output(['git','show',base+':'+path],cwd=r);assert old==(r/path).read_bytes(),path;protected.append({'path':path,'sha256':hashlib.sha256(old).hexdigest()})
write('inventory-summary.json',{'baseCommit':base,'trackedPaths':len(paths),'wholeFileCompletionThisBatch':0,'historicalUniqueCoverage':'unknown, finite method checks cannot establish whole-file completion','knowledgeAndContractsUnchanged':protected,'productionDelta':production,'scope':'Image verification resource lifecycle only; W5 compatibility planning read-only; no schema/index/history/policy/UI change. W2 remainder, W3-W5 cross-cutting, W6 robustness/performance/extraction/A23 incl reviewed code, W7 increments remain. Original 931 knowledge /86 UI candidates, high/A12/full matrices/history/text-ID index/PDF/large parser/UNKNOWN reconciliation and paused friend signature/modal queues remain.'})
ledger='docs/development/branch-review-20261026-capacity-audit/ledger/findings.json';issues=json.loads((r/ledger).read_text());old=next(x for x in issues if x['id']=='W5-AUDIT-HASH-001')
write('existing-issue-dedup.json',{'sourcePath':ledger,'sourceCommit':base,'sourceSha256':hashlib.sha256((r/ledger).read_bytes()).hexdigest(),'existingRecord':old,'disposition':'retain preexisting-medium-open; compatibility plan only, no new issue or runtime-replay claim, no old hash changes'})
print(json.dumps({'events':len(events),'businessSELECT':sum(e['selectStatements'] for e in events),'serverTypes':dict(types),'comparisons':comparisons},indent=2))
