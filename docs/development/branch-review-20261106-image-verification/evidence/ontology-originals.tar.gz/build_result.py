import collections, datetime, hashlib, json, pathlib, subprocess, yaml

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path('/tmp/edhr-image-verification-ontology-20261106')
BASE = 'cf5594947e96dcc56497997d7941da0f7a89be7e'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

# These are explicitly bounded assessments, not copied historical coverage.
assessments = {
 'term.dhr-controlled-attachment': ('consistent', '仅核工程优化保持受控附件、来源/核验/关联追溯与冻结引用含义；临时快照不是新增附件或第四种表单来源。'),
 'concept.dhr-controlled-attachment': ('consistent', '临时文件只属一次核验，不产生受控附件身份、业务状态、运行事实或知识成熟度变化；原概念specified/internal保留。'),
 'relation.dhr-summary-version-contains-controlled-attachments': ('consistent', '限附件核验分支：未写冻结attachment_snapshot或替换登记路径/SHA；不将临时快照误作DHR汇总冻结。完整跨版本矩阵未由本体角色运行。'),
 'DEC-0063-10': ('consistent', '原件字节/SHA、50MiB含边界、七格式、Office不转换及带原因解除后原件保留规范不变；小缓冲和临时IO属于用户同意的工程取舍，非新业务政策。'),
 'DEC-0063-13': ('consistent', '原tenant/DHR/active/可编辑与来源元信息保持；摘要/图片header尺寸合格不等于系统自动完成来源、对象和内容关联的人工核验。'),
 'rule.dhr-summary-controlled-attachment-upload': ('consistent', '本批仅核验PNG/JPEG，upload仍原字节数组和原七格式/52428800容量规则；不因内存优化缩小容量、取消SHA或新增允许格式。'),
 'rule.dhr-review-task-frozen-attachment-download': ('consistent', '限不变边界核对：DhrReviewController先detail授权后调用任务绑定version的downloadableFile，仍按id+SHA成员取原件，本批不增加下载或编辑权限。'),
 'rule.dhr-summary-freeze-version': ('consistent', '限不变边界：核验更新只针对dhr_attachment及VERIFY事件，不更新已有汇总版本；提交内附件元数据复用和完整原件SHA仍保留。'),
 'evidence.dhr-summary-attachment-migration': ('consistent', '证据保留历史0103的原时点；当前canonical基线mime_type128、PENDING/VERIFIED/REJECTED及active索引已源核对，本批没有schema/历史迁移。'),
 'evidence.dhr-summary-attachment-service': ('consistent', '历史25MB/三格式是明确标注时点，不解释为当前行为；当前原服务及本批diff再次核对，PNG/JPEG使用同一固定已读视图，不扩展全像素解码或病毒扫描。'),
 'evidence.dhr-summary-attachment-archive-tests': ('consistent', '限现存测试源码：七格式/50MiB/原件及部分冻结ZIP字节断言仍保留，本体未执行业务测试，不把源码或主侧报告冒称本角色完整验收。'),
 'DEC-0090-01': ('consistent', '核验的临时快照不是归档或放行，核验VERIFIED不授予归档状态；本批无归档生命周期或新留存政策。'),
 'scenario.dhr-summary-attachment-export-and-audit': ('evidence-gap', '本批图片/原件/事务回归不能覆盖整个七格式最大容量、完整/部分ZIP、冻结引用、真实HTTP权限及双层审计场景；本体角色未执行业务运行，整体场景仍不能计一致通过。'),
 'scenario.dhr-summary-printable-archive-layout': ('evidence-gap', '图片核验局部优化不认证冻结目录树/切版、总PDF与单表版式、两类附件/中文ZIP、签名审计清单及全选/部分范围；PDF容量与大解析器仍另排。'),
}
indexed = {}
def visit(node, path, pointer=''):
    if isinstance(node, dict):
        if node.get('id') in assessments:
            indexed[node['id']] = (path, pointer, node)
        for k, v in node.items(): visit(v, path, pointer + '/' + str(k))
    elif isinstance(node, list):
        for i, v in enumerate(node): visit(v, path, pointer + '/' + str(i))

for p in ROOT.glob('docs/knowledge/**/*.yaml'):
    visit(yaml.safe_load(p.read_text()), p.relative_to(ROOT).as_posix())
assert set(indexed) == set(assessments)
head = git('rev-parse', 'HEAD')
manifest = json.loads((OUT / 'final-source-manifest.json').read_text())
source_refs = [{'path': r['path'], 'sha256': r['sha256'], 'sourceRevision': 'working-tree', 'headCommit': head, 'workingTreeSnapshot': 'final-snapshot/' + r['path']} for r in manifest['files'] if r['exists'] and '/src/main/' in r['path']]
records = []
for key, (conclusion, scope) in assessments.items():
    path, pointer, original = indexed[key]
    lines = (ROOT / path).read_text().splitlines()
    line = next(i + 1 for i, text in enumerate(lines) if 'id: ' + key in text)
    records.append({'id': key, 'recordType': pointer.split('/')[1], 'sourcePath': path, 'sourceLocator': {'line': line, 'jsonPointer': pointer}, 'originalMaturity': {k: original[k] for k in ['status', 'visibility'] if k in original}, 'auditScopeClassification': 'current-defined-subscope', 'semanticReviewStatus': 'reviewed', 'conclusion': conclusion, 'reviewedScope': scope, 'decisionsActuallyCompared': ['DEC-0063-10', 'DEC-0063-13', 'DEC-0090-01'], 'implementationEvidence': source_refs, 'originalAsset': original, 'runtimeEvidenceByRole': [], 'maturityChanged': False})
for key, path, loc, conclusion, scope in [
 ('markdown.dhr-summary-user-confirmed', 'docs/knowledge/evidence/dhr-summary-user-confirmed.md', '50-67,106-139', 'consistent', '原话核对50MiB含边界/七格式/Office原件与来源核验、解除保留；解析/安全资源防护明确工程inference。旧25MB和旧59项测试按采集时点保留，不覆盖本批。'),
 ('markdown.retained-w5-audit-hash-gap', 'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md', '52', 'evidence-gap', 'W5-AUDIT-HASH-001是既有AuditEvent的JSONB/时间往返摘要缺口，与附件文件SHA和临时快照不同；本批不改AuditEvent算法、旧hash或历史，不把只读兼容方案当修复。')]:
    records.append({'id': key, 'recordType': 'markdown', 'sourcePath': path, 'sourceLocator': {'lines': loc}, 'originalMaturity': {}, 'auditScopeClassification': 'supporting-defined-subscope', 'semanticReviewStatus': 'reviewed', 'conclusion': conclusion, 'reviewedScope': scope, 'decisionsActuallyCompared': ['DEC-0063-10', 'DEC-0063-13', 'DEC-0090-01'], 'implementationEvidence': source_refs, 'runtimeEvidenceByRole': [], 'maturityChanged': False})
(OUT / 'finite-audit-records.jsonl').write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))
summary = {'scope': '16 finite records: 14 existing IDs plus 2 Markdown; explicitly bounded image-verification and unchanged adjacent edges', 'records': len(records), 'semanticReviewed': len(records), 'conclusions': dict(collections.Counter(r['conclusion'] for r in records)), 'knowledgeFiles': 350, 'runtimeExecutedByRole': False, 'knowledgeTestsExecutedByRole': 89, 'newUniqueWholeAuditIncrement': 'not inferred: overlap with prior finite reviews remains; no whole-file completion claim', 'notClosed': ['931 knowledge candidates', '86 UI diagnostics', 'original DHR high/A12/complete runtime matrices', 'W5-AUDIT-HASH-001 read-back audit digest', 'W2 remainder/W3-W5 cross-cutting/W6 robustness-performance-extraction-A23 including prior code/W7 increments', 'PDF cumulative memory/large Office parser/upload arrays/UNKNOWN-crash-persistent reconciliation', 'friend task password/signature and production modal styling pauses']}
dump('finite-audit-summary.json', summary)
knowledge = json.loads((OUT / 'knowledge-fingerprint-inventory.json').read_text())
assert knowledge['allEqualBaseline'] and knowledge['fileCount'] == 350
tests = json.loads((OUT / 'knowledge-test-summary.json').read_text())
assert tests['totals'] == {'tests': 89, 'failures': 0, 'errors': 0, 'skipped': 0}
retained = ['term.dhr-controlled-attachment', 'concept.dhr-controlled-attachment', 'relation.dhr-summary-version-contains-controlled-attachments', 'DEC-0063-10', 'DEC-0063-13', 'rule.dhr-summary-controlled-attachment-upload']
result = {'ontologyResult': {'result': 'not-applicable', 'baselineBefore': '0.3.25', 'baselineAfter': '0.3.25', 'contractBaseline': {'sourceCommit': head, 'targetBranch': 'edhr-dev', 'targetCommit': git('rev-parse', 'origin/edhr-dev'), 'contractReadCommit': BASE, 'uncommittedContractPaths': []}, 'reason': '经有限源码/现行确认核对，本批仅替换PNG/JPEG核验的整文件数组为固定缓冲和自有临时快照；完整SHA、固定同一视图、原header/尺寸检查、原件/资格/锁/更新/审计及相邻读取规则保持。没有新增或替代业务概念、状态、规则、证据范围、归档/留存政策，350份知识逐字节不变，因此不为工程优化新建知识或提升成熟度。此结果限本批，不表示全库或整体场景一致通过。', 'changedArtifacts': [], 'knowledgeSync': [{'id': key, 'disposition': 'retained', 'scope': assessments[key][1], 'sourceReferences': [indexed[key][0], 'docs/development/branch-review-20261106-image-verification/decision-package.yaml']} for key in retained], 'conflicts': [], 'questions': [], 'validationEvidence': [{'id': 'validation.image-verification-finite-semantics', 'checkType': 'evidence-path', 'command': 'Direct read current records, decision confirmations, actual DhrAttachmentService/controller and adjacent source; compare final snapshot and cf559494 baseline', 'outcome': 'passed', 'evidence': ['finite-audit-records.jsonl: 16 reviewed; 13 consistent in declared subscopes, 3 evidence-gap retained', 'final-source-manifest.json', 'knowledge-fingerprint-inventory.json: 350 files byte-identical; inventory is not semantic coverage']}, {'id': 'validation.formal-knowledge-model', 'checkType': 'schema', 'command': 'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test', 'outcome': 'passed', 'evidence': ['knowledge-validation.log: exit 0 BUILD SUCCESS', 'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml: 89 tests, zero failures/errors/skips', 'knowledge-test-summary.json; schema/reference/status/projection only, not product/PG/UI/production acceptance']}], 'roadmapProgress': {'stage': 'P0', 'status': 'in-progress', 'exitCriteriaEvidence': [], 'deferredStages': ['P1', 'P2', 'P3']}}}
(OUT / 'ontologyResult.yaml').write_text(yaml.safe_dump(result, allow_unicode=True, sort_keys=False))
(OUT / 'REVIEW.md').write_text('# PNG/JPEG 核验临时快照：有限本体核对\n\n本批 result 为 not-applicable：工程资源策略变化，业务定义不变，无知识写入。来源/目标/契约基线见 ontologyResult；源码与未提交差异以 final-source-manifest 及对应快照为准，不为工作树编造提交。\n\n实际核对 16 个有限记录（14 现存 ID＋2 Markdown）：13 个仅在明确子范围一致，3 个证据缺口保留。表内每项列当前原始资产、定位、规范依据、源码指纹和有限结论；重复核对不充当全量审计新增覆盖。正式知识测试实际 89/89，350 个知识文件与目标基线逐字节不变。\n\n小缓冲复制完整原件同时计算 SHA，匹配后对同一快照执行原有图片 header/尺寸读取；不声称全像素解码、病毒扫描、自动人工来源判断或阻止所有外部原件变化。快照自有且短期，不能解释为业务附件、新冻结版本或归档；清理失败不得吞主错误或错误更新 VERIFIED，功能/故障回归由主侧与全新独立质量另取证，本体没有代跑业务数据库或浏览器。\n\n上传/PDF/Office、下载/提交/冻结和历史不改。W5 旧 AuditEvent 摘要问题继续 open；只读兼容方案不是修复。完整附件导出和可打印档案场景仍 evidence-gap；PDF容量、大解析器、上传数组、UNKNOWN/崩溃持久对账仍未关闭。全量931候选/86 UI、旧 DHR high/A12/完整矩阵、W2余项/W3-W5/W6健壮性性能拆分及A23含旧代码/W7增量保持；全文件完成与历史唯一覆盖不由本批推算。\n\nP0 继续 in-progress，schema1.2.0/知识0.3.25保持。不新增试点，不回写旧审计/hash或提高历史成熟度。\n')
files = []
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name not in ['manifest.json', 'manifest.sha256']:
        b = p.read_bytes()
        files.append({'path': p.relative_to(OUT).as_posix(), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()})
dump('manifest.json', {'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'files': files})
(OUT / 'manifest.sha256').write_text(hashlib.sha256((OUT / 'manifest.json').read_bytes()).hexdigest() + '  manifest.json\n')
print(json.dumps({'summary': summary, 'manifestSha256': hashlib.sha256((OUT / 'manifest.json').read_bytes()).hexdigest()}, ensure_ascii=False))
