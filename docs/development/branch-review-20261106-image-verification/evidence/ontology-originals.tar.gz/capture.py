import datetime, hashlib, json, pathlib, shutil, subprocess, sys, xml.etree.ElementTree as ET

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path('/tmp/edhr-image-verification-ontology-20261106')
BASE = 'cf5594947e96dcc56497997d7941da0f7a89be7e'

def run(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

paths = run('git', 'ls-files', 'docs/knowledge').splitlines()
fingerprints = []
for path in paths:
    data = (ROOT / path).read_bytes()
    baseline = subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=ROOT)
    fingerprints.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'equalsTargetBaseline': data == baseline})
write('knowledge-fingerprint-inventory.json', {'baseline': BASE, 'files': fingerprints, 'fileCount': len(fingerprints), 'allEqualBaseline': all(x['equalsTargetBaseline'] for x in fingerprints), 'qualification': 'File fingerprint comparison only; not whole-library semantic review.'})
assert all(x['equalsTargetBaseline'] for x in fingerprints)

source_paths = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/business-knowledge-modeler.md', 'docs/architecture/business-knowledge-model.md', 'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml', 'docs/development/branch-review-20261106-image-verification/decision-package.yaml', 'docs/knowledge/glossary.yaml', 'docs/knowledge/ontology.yaml', 'docs/knowledge/rules/dhr-summary.yaml', 'docs/knowledge/facts/dhr-summary.yaml', 'docs/knowledge/evidence/dhr-summary.yaml', 'docs/knowledge/evidence/dhr-summary-user-confirmed.md', 'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md', 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml', 'docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml', 'docs/development/branch-review-20261026-capacity-audit/ledger/findings.json']
source_paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/' + p + '.java' for p in ['DhrAttachmentService', 'DhrOfficeAttachment', 'DhrSummaryService', 'DhrArchiveService']]
source_paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/' + p + '.java' for p in ['DhrAttachmentController', 'DhrReviewController']]
source_paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java']
source_paths += ['gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql', 'gmp-platform/backend/src/test/resources/db/changelog/0103-dhr-controlled-attachments.sql']
source_paths += ['gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/' + p + '.java' for p in ['DhrAttachmentAndArchiveTest', 'DhrAttachmentUploadVerifyObservationPostgresTest', 'DhrAttachmentImageVerificationTest']]
phase = sys.argv[1]
entries = []
for path in source_paths:
    p = ROOT / path
    if not p.exists():
        entries.append({'path': path, 'exists': False})
        continue
    data = p.read_bytes()
    target = OUT / (phase + '-snapshot') / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    entries.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'exists': True})
write(phase + '-source-manifest.json', {'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': run('git', 'rev-parse', 'HEAD'), 'target': run('git', 'rev-parse', 'origin/edhr-dev'), 'status': run('git', 'status', '--porcelain'), 'files': entries})

reports = list((ROOT / 'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'))
if reports:
    totals = {k: 0 for k in ['tests', 'failures', 'errors', 'skipped']}
    for report in reports:
        shutil.copy2(report, OUT / report.name)
        suite = ET.parse(report).getroot()
        for k in totals:
            totals[k] += int(suite.attrib.get(k, 0))
    write('knowledge-test-summary.json', {'totals': totals, 'reports': [p.name for p in reports], 'qualification': 'Executed formal knowledge schema/reference/status/projection checks only, not product/PG/UI acceptance.'})
