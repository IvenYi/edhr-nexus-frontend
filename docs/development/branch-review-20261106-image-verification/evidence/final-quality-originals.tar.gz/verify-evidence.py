from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections,xml.etree.ElementTree as ET,shutil,datetime
root=Path('/tmp/edhr-image-verification-quality-worktree-20261106');out=Path('/tmp/edhr-image-verification-quality-20261106');native=out/'native-retry';docs=root/'docs/development/branch-review-20261106-image-verification';base='cf5594947e96dcc56497997d7941da0f7a89be7e';head='b7f576e9a5b519ceac97b372341612c3a217c12a'
def save(name,data):(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def norm(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
assert git('rev-parse','HEAD').decode().strip()==head
archive_results=[];members={}
for archive in json.loads((docs/'evidence/archive-manifest.json').read_text())['archives']:
 path=docs/'evidence'/archive['archive'];assert sha(path.read_bytes())==archive['sha256'];assert path.stat().st_size==archive['bytes']
 with tarfile.open(path) as tar:
  content={m.name:tar.extractfile(m).read() for m in tar.getmembers() if m.isfile()}
 assert len(content)==archive['fileCount']==len(archive['files'])
 for record in archive['files']:
  b=content[record['path']];assert len(b)==record['bytes'] and sha(b)==record['sha256']
 archive_results.append({'archive':archive['archive'],'filesVerified':len(content),'archiveSha256':archive['sha256'],'allChecksumsMatch':True});members[archive['archive']]=content
save('archive-check.json',archive_results)
main=members['main-originals.tar.gz'];negative=ET.fromstring(main['native-budget/TEST-com.zencas.edhr.production.service.DhrAttachmentUploadVerifyObservationPostgresTest.xml'])
assert {k:int(negative.get(k)) for k in ['tests','failures','errors','skipped']}=={'tests':27,'failures':2,'errors':0,'skipped':0}
failures=[]
for case in negative.findall('testcase'):
 for fail in case.findall('failure'):
  assert 'large image verification must not allocate a whole-file byte array' in fail.get('message');failures.append({'name':case.get('name'),'message':fail.get('message')})
assert len(failures)==2
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java';product='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java'
assert main['native-budget/source/'+test]==main['native-retry/source/'+test]==(root/test).read_bytes()
assert main['native-budget/source/'+product]==git('show',base+':'+product)
for path in json.loads(main['native-retry/run.json'])['sourceFingerprints']:
 assert sha((root/path['path']).read_bytes())==path['sha256']
save('negative-control-check.json',{'tests':27,'genuineBudgetFailures':failures,'nativeTestFingerprint':sha((root/test).read_bytes()),'oldProductMatchesBase':True,'finalMainSourceMatchesCandidate':True,'intermediateCompileFailure':json.loads(main['native-optimized/test-summary.json'])})
events=[]
for p in sorted((native/'observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==52
text=(native/'postgres.log').read_text();lines=text.splitlines();sql_by_tag=collections.defaultdict(collections.Counter);errors=[];audit=[]
tagdb='edhr_dhr_attachment_write_test_image_quality_retry '
for i,line in enumerate(lines):
 m=re.search(tagdb+r'(audit_write_\w+) LOG:.*?execute [^:]+: (.*)',line)
 if m:
  tag,sql=m.groups();sql_by_tag[tag][norm(sql)]+=1
  if sql.lower().startswith('insert into audit_event '):
   param=lines[i+1];assert tag+' DETAIL:  parameters:' in param
   vals={int(k):(None if v=='NULL' else v[1:-1].replace("''","'")) for k,v in re.findall(r"\$(\d+) = ('(?:''|[^'])*'|NULL)(?:, |$)",param)}
   columns=re.search(r'audit_event \(([^)]+)\)',sql).group(1).split(',');values={name:vals[j+1] for j,name in enumerate(columns)}
   verify=tag.startswith('audit_write_verify_');expected={'action':'VERIFY' if verify else 'LINK','entity_type':'DHR_ATTACHMENT','operator_id':'42' if verify else '41','operator_account':'verification-observer' if verify else 'attachment-observer','operator_name':'核验观察员' if verify else '附件观察员','tenant_id':'default','source':'UI','data_summary':'1'}
   for k,v in expected.items():assert values[k]==v,(tag,k,values[k],v)
   assert re.fullmatch('[0-9a-f]{64}',values['snapshot_hash']);payload=json.loads(values['content_after']);assert payload['dhrId']=='1' and payload['attachmentId']==values['entity_id']
   audit.append({'actionName':tag,'columns':values,'laterRolledBack':tag=='audit_write_failure_outer_rollback','allExpectedParametersMatch':True})
 m=re.search(tagdb+r'(audit_write_\w+) ERROR: (.*)',line)
 if m:errors.append({'actionName':m.group(1),'message':m.group(2)})
assert len(errors)==3 and len(audit)==23 and sum(e['laterRolledBack'] for e in audit)==1
matched=[];metadata=[];statement_types=collections.Counter()
for e in events:
 observed=collections.Counter(norm(sql) for sql in e['jdbcQuerySql']+e['hibernateAttemptSql'] if norm(sql).startswith('select'));server=collections.Counter({sql:n for sql,n in sql_by_tag[e['applicationName']].items() if sql.startswith('select')})
 for sql,n in (server-observed).items():
  assert 'pg_catalog.pg_type' in sql;metadata.append({'name':e['name'],'sql':sql,'count':n});server[sql]-=n
 assert observed==+server,(e['name'],observed-server,server-observed)
 assert e['selectStatements']==sum(observed.values());matched.append({'name':e['name'],'businessSELECT':sum(observed.values()),'shapesMatch':True})
 for sql,n in sql_by_tag[e['applicationName']].items():statement_types[sql.split()[0]]+=n
save('server-sql-check.json',{'actionCount':52,'perAction':matched,'businessSELECT':sum(e['businessSELECT'] for e in matched),'successfulExecuteTypes':dict(statement_types),'driverTypeMetadataSELECT':metadata,'failedChecks':errors,'writeBoundary':'48 successful write executions include 4 later rolled back; 3 failed INSERTs separately; not committed counts'})
save('audit-parameter-check.json',{'successfulExecutions':23,'normalRoundTrips':22,'outerRollbackExecutions':1,'records':audit,'scope':'identity/action/payload/hash presence only; no old AuditEvent rehash certification'})
jfr_results=[]
for e in events:
 result=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead,jdk.FileWrite',str(native/'observations'/(e['name']+'.jfr'))],check=True,capture_output=True,text=True)
 raw=json.loads(result.stdout)['recording']['events'];sums=collections.Counter();snapshots=set();tracked=[]
 for record in raw:
  v=record['values'];path=v.get('path');thread=v.get('eventThread') or {}
  if path is None or thread.get('javaThreadId')!=e['measuredThreadId']:continue
  p=Path(path);isread=record['type']=='jdk.FileRead';amount=v['bytesRead' if isread else 'bytesWritten']
  if p.name.startswith('edhr-dhr-image-'):
   snapshots.add(path);sums['snapshotReadBytes' if isread else 'snapshotWriteBytes']+=amount;tracked.append(path)
  elif '/junit' in path:
   if '/store/' in path:sums['storedReadBytes' if isread else 'storedWriteBytes']+=amount
   elif isread:sums['fixtureReadBytes']+=amount
 for key in ['snapshotReadBytes','snapshotWriteBytes','storedReadBytes','storedWriteBytes','fixtureReadBytes']:assert sums[key]==e[key],(e['name'],key,sums[key],e[key])
 assert sorted(snapshots)==e['snapshotPaths'];assert all(not Path(p).exists() for p in snapshots) and e['snapshotsRemoved']
 if e['name'].startswith('verify_size_'):
  assert len(snapshots)==1 and sums['snapshotWriteBytes']==e['data']['bytes']==sums['storedReadBytes'] and e['threadAllocatedBytes']<25*1024*1024
 jfr_results.append({'name':e['name'],'rawJfrEvents':len(raw),'actualIo':dict(sums),'snapshotPaths':sorted(snapshots),'snapshotsAbsentAtIndependentCheck':True,'matchesTestRecorder':True,'threadAllocatedBytes':e['threadAllocatedBytes']})
save('external-jfr-check.json',{'recordings':len(jfr_results),'records':jfr_results,'scope':'CLI parsed raw JFR by Java thread / exact snapshot prefix and owned junit fixture paths; logical IO, not physical IO or peak memory'})
knowledge=[]
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/'knowledge'/p.name);a=ET.parse(p).getroot().attrib;knowledge.append({k:(a[k] if k=='name' else int(a[k])) for k in ['name','tests','failures','errors','skipped']})
assert sum(e['tests'] for e in knowledge)==89 and all(e['failures']==e['errors']==e['skipped']==0 for e in knowledge)
paths=git('ls-tree','-r','--name-only',head).decode().splitlines();protected=[]
for path in paths:
 if path.startswith('docs/knowledge/') or path.startswith('docs/agents/') or path in ['AGENTS.md','codeplzreadme.md']:
  b=git('show',base+':'+path);assert b==(root/path).read_bytes();protected.append({'path':path,'sha256':sha(b),'matchesBase':True})
save('knowledge-contract-check.json',{'knowledgeFiles':sum(p['path'].startswith('docs/knowledge/') for p in protected),'protectedFiles':protected,'actualIndependentKnowledgeTests':knowledge,'scope':'unchanged bytes and formal checks; not whole-library semantic acceptance'})
for path in ['docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/development/branch-review-20261106-image-verification/ontology-result.yaml','docs/development/branch-review-20261106-image-verification/ontology-review.md','docs/development/branch-review-20261106-image-verification/W5-COMPATIBILITY-PLAN.md','docs/development/branch-review-20261026-capacity-audit/ledger/findings.json']:
 p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/path).read_bytes())
save('validation-summary.json',{'baseCommit':base,'headCommit':head,'nativeAndAdjacent':json.loads((native/'test-summary.json').read_text()),'knowledge':knowledge,'archiveFiles':sum(e['filesVerified'] for e in archive_results),'serverStatements':dict(statement_types),'auditParameterRecords':len(audit),'rawJfrRecordings':len(jfr_results),'knowledgeFilesUnchanged':sum(p['path'].startswith('docs/knowledge/') for p in protected),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'archiveFiles':sum(e['filesVerified'] for e in archive_results),'actions':len(events),'sql':dict(statement_types),'audit':len(audit),'jfr':len(jfr_results),'knowledge':knowledge},indent=2))
