package com.zencas.edhr.production.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zencas.edhr.common.exception.BusinessException;
import com.zencas.edhr.common.exception.ErrorCode;
import com.zencas.edhr.production.entity.ProductionObject;
import com.zencas.edhr.production.entity.WorkOrder;
import com.zencas.edhr.template.service.FormProjectionInterpreter;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.*;

/** Freezes process configuration and resolves work candidates separately at operation start. */
@Component
@RequiredArgsConstructor
public class ExecutionSnapshotBuilder {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public ObjectNode processReference(Long versionId) {
        return one("""
            SELECT p.id AS "processVersionId", p.version_label AS "processVersion",
                   pp.id AS "processId", pp.owner_type AS "ownerType", pp.owner_id AS "ownerId",
                   COALESCE(m.name, f.name) AS "ownerName", p.effective_from AS "effectiveFrom", p.effective_to AS "effectiveTo"
            FROM product_process_version p JOIN product_process pp ON pp.id = p.product_process_id
            LEFT JOIN material m ON pp.owner_type = 'PRODUCT' AND m.id = pp.owner_id
            LEFT JOIN product_family f ON pp.owner_type = 'PRODUCT_FAMILY' AND f.id = pp.owner_id
            WHERE p.id = ? AND p.tenant_id = 'default'
            """, versionId);
    }

    public ObjectNode build(ProductionObject object, WorkOrder order) {
        ObjectNode root = mapper.createObjectNode();
        root.put("schemaVersion", 1);
        ObjectNode context = one("""
            SELECT m.id AS "productId", m.code AS "productCode", m.name AS "productName",
                   m.specification, m.unit, p.id AS "processVersionId", p.version_label AS "processVersion",
                   p.production_mode AS "productionMode", p.production_form AS "productionForm",
                   p.dhr_review_mode AS "dhrReviewMode",
                   p.dhr_review_workflow_definition_id AS "dhrReviewWorkflowDefinitionId",
                   p.dhr_review_workflow_version_id AS "dhrReviewWorkflowVersionId",
                   wd.name AS "dhrReviewWorkflowName", wd.code AS "dhrReviewWorkflowCode",
                   wv.version_number AS "dhrReviewWorkflowVersion",
                   r.id AS "routeVersionId", r.version AS "routeVersion", rt.name AS "routeName",
                   rt.code AS "routeCode", dt.id AS "dhrTemplateId", d.id AS "dhrTemplateVersionId",
                   d.version_label AS "dhrVersion",
                   dt.name AS "dhrName", dt.code AS "dhrCode"
            FROM product_process_version p JOIN material m ON m.id = ?
            JOIN route_version r ON r.id = p.route_version_id JOIN route rt ON rt.id = r.route_id
            JOIN dhr_template_version d ON d.id = p.dhr_template_version_id
            JOIN dhr_template dt ON dt.id = d.dhr_template_id
            LEFT JOIN workflow_definition wd ON wd.id = p.dhr_review_workflow_definition_id
            LEFT JOIN workflow_definition_version wv ON wv.id = p.dhr_review_workflow_version_id
            WHERE p.id = ? AND p.tenant_id = 'default' AND m.tenant_id = 'default'
            """, order.getProductId(), object.getProcessVersionId());
        context.put("objectId", object.getId().toString()).put("objectNo", object.getObjectNo())
                .put("objectType", object.getObjectType()).put("workOrderId", order.getId().toString())
                .put("workOrderNo", order.getOrderNo()).put("targetQuantity", object.getTargetQuantity());
        root.set("context", context);
        root.set("processReference", processReference(object.getProcessVersionId()));
        ArrayNode membership = rows("SELECT product_family_id AS id FROM product_family_member WHERE tenant_id = 'default' AND product_id = ?", order.getProductId());
        context.set("productFamilyId", membership.isEmpty() ? mapper.nullNode() : membership.get(0).path("id"));
        root.put("outputPolicyVersion", 1);
        long routeId = context.path("routeVersionId").asLong();
        ArrayNode nodes = rows("""
            SELECT node_key AS id, operation_id AS "operationId", operation_code AS code,
                   operation_name AS name, node_type AS type, config_json AS config
            FROM route_node WHERE route_version_id = ? ORDER BY sort_order, id
            """, routeId);
        ArrayNode edges = rows("""
            SELECT source_node_key AS source, target_node_key AS target, relation_type AS type,
                   rule_expression AS rule FROM route_relation WHERE route_version_id = ? ORDER BY priority, id
            """, routeId);
        root.set("routeNodes", nodes); root.set("routeEdges", edges);
        ArrayNode operations = root.putArray("operations");
        for (JsonNode node : nodes) {
            if (!Set.of("OPERATION", "REWORK").contains(node.path("type").asText())) continue;
            ObjectNode op = ((ObjectNode) node).deepCopy();
            op.set("config", json(node.path("config").asText(), mapper.createObjectNode()));
            ArrayNode bindings = rows("SELECT id, final_output AS \"finalOutput\" FROM product_process_operation_binding WHERE product_process_version_id = ? AND route_node_key = ?",
                    object.getProcessVersionId(), node.path("id").asText());
            ArrayNode forms = op.putArray("forms"); ArrayNode documents = op.putArray("documents");
            if (!bindings.isEmpty()) {
                op.put("finalOutput", bindings.get(0).path("finalOutput").asBoolean());
                long bindingId = bindings.get(0).path("id").asLong();
                for (JsonNode binding : rows("""
                    SELECT id, form_template_version_id AS "versionId", dhr_template_item_id AS "dhrItemId", required, fill_settings_json AS "fillSettings"
                    FROM product_process_operation_form_binding WHERE product_process_operation_binding_id = ? ORDER BY sort_order, id
                    """, bindingId)) {
                    ObjectNode form = form(binding.path("versionId").asText());
                    form.put("id", "form-" + binding.path("id").asText());
                    form.set("required", binding.path("required")); form.set("dhrItemId", binding.path("dhrItemId"));
                    attachFillSettings(form, json(binding.path("fillSettings").asText(), mapper.createObjectNode()));
                    forms.add(form);
                }
                documents.addAll(rows("""
                    SELECT b.id, v.id AS "versionId", s.title AS name, v.code, v.version, v.file_id AS "fileId",
                           b.page_start AS "pageStart", b.page_end AS "pageEnd"
                    FROM product_process_operation_document_binding b JOIN document_version v ON v.id = b.document_version_id
                    JOIN sop_document s ON s.id = v.document_id
                    WHERE b.product_process_operation_binding_id = ? ORDER BY b.sort_order, b.id
                    """, bindingId));
            }
            op.putArray("works");
            operations.add(op);
        }
        return root;
    }

    /** Updates only uninstantiated plans. Existing work states and their configuration remain intact. */
    public void refreshWorks(JsonNode snapshot, ObjectNode op, JsonNode opState) {
        if (!"PENDING".equals(opState.path("status").asText())) return;
        String productId = snapshot.path("context").path("productId").asText();
        ArrayNode families = rows("SELECT product_family_id AS id FROM product_family_member WHERE product_id = ? AND tenant_id = 'default'", Long.valueOf(productId));
        String family = families.isEmpty() ? "" : families.get(0).path("id").asText();
        ArrayNode rules = rows("""
            SELECT b.id, b.definition_id AS "definitionId", b.rule_type AS type,
                   b.product_id AS "productId", b.product_family_id AS "familyId", b.operation_id AS "operationId"
            FROM workflow_binding_rule b JOIN workflow_definition d ON d.id = b.definition_id
            WHERE d.type = 'WORK' AND b.is_active = true AND b.tenant_id = 'default' AND d.tenant_id = 'default'
            ORDER BY b.id
            """);
        ArrayNode works = mapper.createArrayNode(), forms = mapper.createArrayNode();
        Set<String> retained = new HashSet<>();
        for (JsonNode work : op.path("works")) {
            String id = work.path("id").asText();
            if (opState.path("works").has(id)) { works.add(work); retained.add(id); }
        }
        for (JsonNode form : op.path("forms")) {
            if (!form.has("workId") || retained.contains(form.path("workId").asText())) forms.add(form);
        }
        Map<String, List<JsonNode>> matched = new LinkedHashMap<>();
        for (JsonNode rule : rules) {
            if (matches(rule, "productId", productId) && matches(rule, "familyId", family)
                    && matches(rule, "operationId", op.path("operationId").asText())) {
                matched.computeIfAbsent(rule.path("definitionId").asText(), ignored -> new ArrayList<>()).add(rule);
            }
        }
        for (var entry : matched.entrySet()) {
            if (retained.contains(entry.getKey())) continue;
            if (entry.getValue().stream().anyMatch(rule -> "EXCEPTION".equals(rule.path("type").asText()))) continue;
            if (entry.getValue().stream().noneMatch(rule -> Set.of("GLOBAL", "SCOPED").contains(rule.path("type").asText()))) continue;
            ObjectNode work = one("""
                SELECT v.id AS "versionId", v.version_number AS version, d.id, d.name,
                       v.nodes_json AS nodes, v.edges_json AS edges
                FROM workflow_definition d JOIN workflow_definition_version v ON v.definition_id = d.id
                WHERE d.id = ? AND d.tenant_id = 'default' AND v.is_current = true AND v.status = 'PUBLISHED'
                """, Long.valueOf(entry.getKey()));
            work.set("rules", mapper.valueToTree(entry.getValue()));
            work.putObject("matchContext").put("productId", productId).put("productFamilyId", family)
                    .put("operationId", op.path("operationId").asText()).put("trigger", "OPERATION_START");
            work.set("nodes", json(work.path("nodes").asText(), mapper.createArrayNode()));
            work.set("edges", json(work.path("edges").asText(), mapper.createArrayNode()));
            for (JsonNode workNode : work.path("nodes")) {
                if (!"FORM".equals(workNode.path("data").path("kind").asText())) continue;
                JsonNode config = workNode.path("data").path("config");
                ObjectNode form = form(config.path("formTemplateVersionId").asText());
                form.put("id", "work-" + work.path("id").asText() + "-" + workNode.path("id").asText());
                form.put("workId", work.path("id").asText()).put("workNodeId", workNode.path("id").asText());
                attachFillSettings(form, config);
                forms.add(form);
            }
            works.add(work);
        }
        op.set("works", works); op.set("forms", forms);
    }

    private void attachFillSettings(ObjectNode form, JsonNode settings) {
        boolean process = com.zencas.edhr.workflow.service.FormFillSettingsService.usesProcess(settings);
        if (process) {
            String processId = settings.path("formProcessVersionId").asText();
            if (!processId.matches("[0-9]+")) throw invalid("表单尚未选择已发布流程");
            ObjectNode flow = one("""
                SELECT v.nodes_json AS nodes, v.edges_json AS edges
                FROM workflow_definition_version v JOIN workflow_definition d ON d.id=v.definition_id
                WHERE v.id=? AND v.status='PUBLISHED' AND d.type='FORM_PROCESS'
                """, Long.valueOf(processId));
            flow.put("versionId", processId);
            flow.set("nodes", json(flow.path("nodes").asText(), mapper.createArrayNode()));
            flow.set("edges", json(flow.path("edges").asText(), mapper.createArrayNode()));
            form.set("flow", flow);
            form.set("binding", settings.deepCopy());
        } else {
            JsonNode config = settings.path("directFillConfig").isObject() ? settings.path("directFillConfig") : mapper.createObjectNode();
            form.set("binding", config.deepCopy());
            ObjectNode entry = form.putObject("entryNode").put("id", "entry");
            entry.putObject("data").put("kind", "START").put("label", "填报").set("config", config.deepCopy());
        }
    }

    public ArrayNode selectableForms(String keyword) {
        String search = "%" + keyword.strip().replace("!", "!!").replace("%", "!%").replace("_", "!_") + "%";
        return rows("""
            SELECT t.id AS "templateId", v.id AS "versionId", t.name, t.code, t.category_name AS "categoryName", v.version_label AS version
            FROM form_template_version v JOIN form_template t ON t.id=v.template_id
            WHERE v.tenant_id='default' AND t.tenant_id='default' AND t.status='ACTIVE'
              AND (LOWER(t.name) LIKE LOWER(?) ESCAPE '!' OR LOWER(t.code) LIKE LOWER(?) ESCAPE '!')
            ORDER BY t.name, t.id, v.id DESC
            """, search, search);
    }

    public ObjectNode customForm(String versionId, boolean required, String id, String operator) {
        if (versionId == null || !versionId.matches("[0-9]+")) throw invalid("请选择表单模板版本");
        one("""
            SELECT v.id FROM form_template_version v JOIN form_template t ON t.id=v.template_id
            WHERE v.id=? AND v.tenant_id='default' AND t.tenant_id='default' AND t.status='ACTIVE'
            """, Long.valueOf(versionId));
        return form(versionId).put("id", id).put("sourceType", "CUSTOM").put("required", required)
                .put("attachedBy", operator).put("attachedAt", java.time.LocalDateTime.now().toString());
    }

    private ObjectNode form(String versionId) {
        if (versionId.isBlank()) throw invalid("作业表单未绑定模板版本");
        ObjectNode form = one("""
            SELECT v.id AS "versionId", t.name, t.code, t.category_name AS "categoryName", v.version_label AS version,
                   v.model_design_json AS model, v.canvas_design_json AS canvas
            FROM form_template_version v JOIN form_template t ON t.id = v.template_id WHERE v.id = ?
            """, Long.valueOf(versionId));
        JsonNode model = json(form.path("model").asText(), mapper.createObjectNode());
        JsonNode payload = model.has("payload") ? model.path("payload") : model;
        if (payload.hasNonNull("projection")) {
            FormProjectionInterpreter.validateConfiguration(payload);
            form.set("projection", payload.path("projection").deepCopy());
        }
        form.set("fields", payload.path("fields"));
        normalizeColumns(form.path("fields"));
        JsonNode canvas = json(form.path("canvas").asText(), mapper.createObjectNode());
        collectBindings(canvas, form.path("fields"));
        form.set("fields", com.zencas.edhr.template.service.FormReferenceConfig.fields(form, mapper));
        return form;
    }

    private void normalizeColumns(JsonNode fields) {
        for (JsonNode field : fields) {
            if (!"subTable".equals(field.path("type").asText())) continue;
            ObjectNode config = ((ObjectNode) field).withObject("/typeConfig");
            JsonNode raw = config.path("columns");
            if (raw.isTextual()) {
                ArrayNode columns = config.putArray("columns");
                for (String name : raw.asText().split("[\\n,，]")) {
                    if (name.isBlank()) continue;
                    ObjectNode column = columns.addObject().put("id", "sub-field-" + (columns.size())).put("name", name.trim())
                        .put("type", "text").put("status", "enabled");
                    column.putObject("typeConfig");
                }
            }
            normalizeColumns(config.path("columns"));
        }
    }

    static void collectBindings(JsonNode node, JsonNode fields) {
        if (node.isObject()) {
            String tableId = node.path("subTableId").asText();
            JsonNode targets = fields;
            if (!tableId.isBlank()) {
                targets = com.fasterxml.jackson.databind.node.MissingNode.getInstance();
                for (JsonNode field : fields) if (tableId.equals(field.path("id").asText()))
                    targets = field.path("typeConfig").path("columns");
            }
            String fieldId = node.path(tableId.isBlank() ? "fieldId" : "subTableFieldId").asText();
            for (JsonNode field : targets) if (!fieldId.isBlank() && fieldId.equals(field.path("id").asText())) {
                if (node.path("required").asBoolean()) ((ObjectNode) field).put("required", true);
                if (node.path("readonly").asBoolean()) ((ObjectNode) field).put("readOnly", true);
            }
        }
        if (node.isContainerNode()) for (JsonNode child : node) collectBindings(child, fields);
    }

    private boolean matches(JsonNode rule, String field, String value) {
        return rule.path(field).isNull() || rule.path(field).isMissingNode() || rule.path(field).asText().equals(value);
    }

    private ObjectNode one(String sql, Object... args) {
        ArrayNode result = rows(sql, args);
        if (result.size() != 1) throw invalid("生产配置缺失或版本不唯一，请检查产品配置及已发布作业流程");
        return (ObjectNode) result.get(0);
    }

    private ArrayNode rows(String sql, Object... args) {
        ArrayNode result = mapper.createArrayNode();
        jdbc.query(sql, rs -> {
            ObjectNode row = mapper.createObjectNode();
            var metadata = rs.getMetaData();
            for (int i = 1; i <= metadata.getColumnCount(); i++) {
                String key = metadata.getColumnLabel(i);
                Object value = rs.getObject(i);
                if (value == null) row.putNull(key);
                else if (value instanceof Boolean bool) row.put(key, bool);
                else row.put(key, rs.getString(i));
            }
            result.add(row);
        }, args);
        return result;
    }

    private JsonNode json(String value, JsonNode fallback) {
        if (value == null || value.isBlank()) return fallback;
        try { return mapper.readTree(value); }
        catch (Exception e) { throw invalid("配置数据格式错误，无法生成执行依据"); }
    }

    static BusinessException invalid(String message) { return new BusinessException(ErrorCode.GENERAL_001, message); }
}
