from pathlib import Path
import collections,datetime,hashlib,json,subprocess,sys,yaml
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='0dd6e8828f544aec01285e0ea140029d783ec38f'
candidate=sys.argv[1]
assert len(candidate)==40
def sha(b):return hashlib.sha256(b).hexdigest()
index={}
def walk(x,path,loc=''):
    if isinstance(x,dict):
        if isinstance(x.get('id'),str):
            assert x['id'] not in index,x['id']
            index[x['id']]=(path,loc,x)
        for k,v in x.items():walk(v,path,loc+'/'+str(k))
    elif isinstance(x,list):
        for i,v in enumerate(x):walk(v,path,loc+'/'+str(i))
for p in sorted((repo/'docs/knowledge').rglob('*.yaml')):
    if p.name!='schema.yaml':walk(yaml.safe_load(p.read_text()),str(p.relative_to(repo)))
assert len(index)==2849,len(index)
entries=[
 ('concept.form-template-version','concept','consistent','模板业务版本身份仍沿原模型与明确选定ID，序列化协议version=1不是业务版本V1上限。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/types/document.ts','gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts']),
 ('concept.form-projection-configuration','concept','consistent','当前model中的用途配置随正常三片读写保持；加载失败不是新的业务配置状态。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts']),
 ('relation.form-instance-template-version','relation','consistent','实例仍引用其来源模板版本；本轮编辑保护不将历史实例改为最新模板，也不改变只读调用。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/tabs/model/FormInstanceDetailDrawer.tsx']),
 ('relation.execution-snapshot-freezes-form-projection-configuration','relation','consistent','使用时冻结及自定义附加时复制范围保留；本轮只改编辑加载，不回写执行或投影冻结。', ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionSnapshotBuilder.java']),
 ('fact.form-projection.source-configuration','fact','consistent','保留实际配置来源与现有availability/status；UI格式防错不新增事实或运行执行契约。', ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionSnapshotBuilder.java']),
 ('fact.form-projection.formal-source-snapshot','fact','consistent','正式source_json继续由原完成事务保存，本轮不修改来源或重解释历史。', ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormProjectionService.java']),
 ('rule.form-fill-settings.snapshot-runtime-continuity','rule','consistent','既有填报设置保存/发布/运行连续性保留；本次加载保护不宣称完成该规则全部运行矩阵。', ['docs/knowledge/decisions/DEC-0067-form-fill-settings.yaml']),
 ('DEC-0067-04','decision-statement','consistent','两绑定入口共享设置和冻结连续性不替代，设计器编辑错误提示不是新的流程模式。', ['docs/knowledge/rules/form-fill-settings.yaml']),
 ('DEC-0067-05','decision-statement','consistent','取消旧兼容仅适用原填报设置切片；不得据此宣布所有设计JSON全局无兼容。当前readonly路径及后端接收能力保持。', ['gmp-platform/backend/src/main/java/com/zencas/edhr/template/controller/TemplateModelingController.java','gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts']),
 ('DEC-0077-12','decision-statement','consistent','保留原编辑版本规则与使用时冻结，不新增模板发布/冻结或禁止编辑生命周期；无法读的非空源不被空白覆盖。', ['docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md','gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx']),
 ('DEC-0077-22','decision-statement','consistent','配置保存/撤销仍归同一document；失败不换空白、不确认保存其他版本，侧栏与正常编辑来源不变。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/store/useTemplateDesignerStore.ts','gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx']),
 ('DEC-0077-30','decision-statement','consistent','草稿免阻断性完整性/投影业务校验仍保留。这里保留请求格式而非新增数值/日期/枚举/必填业务门禁；真实空白及部分当前payload可初始化。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts']),
 ('DEC-0077-42','decision-statement','consistent','一字段至多一追溯项及其删除授权保持，本批没有迁移/清理旧模板、实例或证据，也不复活旧多绑。', ['gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx']),
 ('DEC-0080-01','decision-statement','consistent','同字段共享选项、真实稳定身份不变；正常解析仍沿canonical model，不以读失败重建新字段或合并不同身份。', ['docs/knowledge/evidence/shared-choice-options-2026-10-18.md','gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts']),
 ('DEC-0074-04','decision-statement','consistent','字段签名与按钮跨账号例外继续各自原规则；本批仅前端设计加载，不改变执行、签署认证或历史证据。', ['docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml']),
 ('discrepancy.dhr-review-complete-evidence-impact-gap','implementation-discrepancy','evidence-gap','另一通用质量/异常/源签署有效性自动判读high保持open；本编辑器修复不关闭它。', ['docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml']),
 ('question.form-projection-trace-index-effective-scope','open-question','needs-decision','完整A12历史失效/修订视图仍待决；本轮不定义历史迁移或新只读解释。', ['docs/knowledge/open-questions.yaml']),
 ('question.multi-tenant-workflow-isolation','open-question','needs-decision','完整非MVP租户隔离仍未决，设计器载入源保护不等于全系统租户鉴权完成。', ['docs/knowledge/open-questions.yaml']),
]
rows=[]
for ident,kind,conclusion,scope,refs in entries:
    path,loc,record=index[ident]
    data=(repo/path).read_bytes()
    assert data==subprocess.check_output(['git','show',base+':'+path],cwd=repo)
    rows.append({'id':ident,'recordType':kind,'sourcePath':path,'sourceLocator':loc,'originalAssetMaturity':record.get('status','not-declared'),
      'scopeClassification':'current-finite-domain-preservation','reviewStatus':'reviewed','conclusion':conclusion,'actualScope':scope,
      'candidate':candidate,'sourceFileSha256':sha(data),'sourceRecordSha256':sha(json.dumps(record,ensure_ascii=False,sort_keys=True).encode()),
      'evidenceReferences':refs,'runtimeQualification':'Use final main test/browser originals separately;this ontology role executes no runtime validation.'})
for path,locator,scope in [
 ('docs/knowledge/README.md','现行知识基线/全审与历史增量说明','保持0.3.25/schema1.2.0及当前P0；本轮有限记录和机械353文件/2849ID不是全库完成。'),
 ('docs/architecture/business-knowledge-model.md','维护方式/智能体协作/使用时冻结说明','业务定义/原始实现/运行验证分层；UI错误保护不定义新业务状态或把所有旧格式设为非法。')]:
    data=(repo/path).read_bytes();assert data==subprocess.check_output(['git','show',base+':'+path],cwd=repo)
    rows.append({'id':'file-scope:'+path,'recordType':'explanatory-file-scope','sourcePath':path,'sourceLocator':locator,
      'originalAssetMaturity':'not-applicable','scopeClassification':'selected-explanation-only','reviewStatus':'reviewed','conclusion':'consistent',
      'actualScope':scope,'candidate':candidate,'sourceFileSha256':sha(data),'evidenceReferences':[path],
      'runtimeQualification':'Selected explanatory sections only;not a new complete-file semantic audit.'})
assert len(rows)==20 and len({r['id'] for r in rows})==20
(raw/'finite-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
summary={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':base,
 'records':len(rows),'idRecords':len(entries),'noIdExplanationScopes':len(rows)-len(entries),'conclusions':dict(collections.Counter(x['conclusion'] for x in rows)),
 'knowledgeInventoryIdCount':len(index),'knowledgeInventoryIsNotSemanticCompletion':True,'historicalUniqueNotIncremented':True,
 'knowledgeModificationRequired':False,'scope':'Editing-read failure protection only,not a backend format policy,not historical migration or readonly replacement'}
(raw/'finite-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps(summary,ensure_ascii=False))
