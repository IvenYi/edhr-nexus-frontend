from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
root=Path(__file__).parent;repo=Path('/workspace/edhr-nexus-frontend')
candidate='3193fc646951c0accde0fe36e494273ef4f33e06';target='0dd6e8828f544aec01285e0ea140029d783ec38f'
def sha(b):return hashlib.sha256(b).hexdigest()
r=yaml.safe_load((root/'ontology-result.yaml').read_text())['ontologyResult']
assert r['result']=='not-applicable' and r['baselineBefore']==r['baselineAfter']=='0.3.25'
assert r['contractBaseline']==dict(sourceCommit=candidate,targetBranch='edhr-dev',targetCommit=target,contractReadCommit=target,uncommittedContractPaths=[])
assert r['changedArtifacts']==[] and r['conflicts']==[] and r['questions']==[]
assert r['roadmapProgress']==dict(stage='P0',status='in-progress',exitCriteriaEvidence=[],deferredStages=['P1','P2','P3'])
assert all(x['disposition'] in ['updated','retained','historical','deferred'] for x in r['knowledgeSync'])
assert all(x['outcome']=='passed' and x['checkType'] in ['schema','reference','status-transition','projection','evidence-path'] for x in r['validationEvidence'])
rows=[json.loads(x) for x in (root/'finite-review-records.jsonl').read_text().splitlines()]
assert len(rows)==20 and len({x['id'] for x in rows})==20 and all(x['candidate']==candidate for x in rows)
summary=json.loads((root/'finite-review-summary.json').read_text());assert summary['conclusions']=={'consistent':17,'evidence-gap':1,'needs-decision':2}
binding=json.loads((root/'final-source-knowledge-binding.json').read_text());assert binding['candidate']==candidate and binding['knowledgeFilesUnchanged']==353
assert binding['exactMainKnowledge359FingerprintsMatch'] and len(binding['validationInputs'])==359
remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/edhr-dev'],cwd=repo,text=True).split()[0]
assert remote==target
observation={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'liveRemoteTarget':remote,'result':'not-applicable',
 'roleQualification':'Ontology read-only static/reference reviewer;no runtime tests,UI edits,Maven,DB,browser,CI,push,merge,deploy or children executed by this role.',
 'finalReadSources':{'mainRun':'read-evidence/knowledge/run.json','mainKnowledgeXml':'read-evidence/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'},
 'finiteRecords':20,'consistent':17,'retainedEvidenceGaps':1,'retainedNeedsDecision':2,'newHistoricalUnique':0,
 'fullSemanticAuditComplete':False,'independentQualityResultClaimed':False,'knowledgeChanged':False,'frozenAfterFinal':True}
(root/'final-observation.json').write_text(json.dumps(observation,ensure_ascii=False,indent=2)+'\n')
files=[]
for p in sorted(root.rglob('*')):
 if p.is_file() and p.name not in ['manifest.json','SHA256SUMS']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(root)),'bytes':len(b),'sha256':sha(b)})
manifest={'createdAt':observation['observedAt'],'role':'w2_designer_document_ontology','candidate':candidate,'target':target,'ontologyResult':'not-applicable',
 'qualification':observation['roleQualification'],'finiteScope':summary,'files':files}
(root/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
listed=sorted([*files,{'path':'manifest.json','bytes':(root/'manifest.json').stat().st_size,'sha256':sha((root/'manifest.json').read_bytes())}],key=lambda x:x['path'])
(root/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n' for x in listed))
for x in files:assert (root/x['path']).stat().st_size==x['bytes'] and sha((root/x['path']).read_bytes())==x['sha256']
for line in (root/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split('  ',1);assert sha((root/name).read_bytes())==digest
print(json.dumps({'rawRoot':str(root),'candidate':candidate,'manifestFiles':len(files),'manifestSha256':sha((root/'manifest.json').read_bytes()),'sha256sumsSha256':sha((root/'SHA256SUMS').read_bytes()),'checksumsVerified':True},ensure_ascii=False))
