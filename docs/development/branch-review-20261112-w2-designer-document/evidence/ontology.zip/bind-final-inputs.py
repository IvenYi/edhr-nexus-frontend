from pathlib import Path
import datetime,hashlib,json,re,shutil,subprocess,sys,yaml,xml.etree.ElementTree as ET
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='0dd6e8828f544aec01285e0ea140029d783ec38f';candidate=sys.argv[1]
knowledge_run=Path(sys.argv[2])
assert len(candidate)==40 and knowledge_run.name=='run.json'
def sha(b):return hashlib.sha256(b).hexdigest()
baseline=json.loads((raw/'baseline-inputs.json').read_text())
schema=yaml.safe_load((repo/'docs/knowledge/schema.yaml').read_text())
assert schema['knowledgeModelVersion']=='0.3.25' and schema['schemaVersion']=='1.2.0'
inputs=[]
for item in baseline['knowledgeFiles']:
    name=item['path'];b=(repo/name).read_bytes()
    assert item['sha256']==sha(b)==sha(subprocess.check_output(['git','show',candidate+':'+name],cwd=repo))
    inputs.append({'path':name,'sha256':sha(b),'bytes':len(b)})
assert len(inputs)==353
for p in sorted((repo/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java')):
    name=str(p.relative_to(repo));b=p.read_bytes()
    assert b==subprocess.check_output(['git','show',candidate+':'+name],cwd=repo)
    inputs.append({'path':name,'sha256':sha(b),'bytes':len(b)})
p=repo/'gmp-platform/backend/pom.xml';b=p.read_bytes();name=str(p.relative_to(repo))
assert b==subprocess.check_output(['git','show',candidate+':'+name],cwd=repo)
inputs.append({'path':name,'sha256':sha(b),'bytes':len(b)})
assert len(inputs)==359
run=json.loads(knowledge_run.read_text());main=knowledge_run.parent
assert run['head']==candidate and run['result']=='passed' and run['workingTreeState']==''
assert all(s['exitCode']==s['expectedExitCode']==0 for s in run['steps'])
java_step=next(s for s in run['steps'] if s['name']=='java')
summaries=json.loads((main/'java-summary.json').read_text())
summary=next(x for x in summaries if x['class']=='BusinessKnowledgeModelTest')
assert summary=={'class':'BusinessKnowledgeModelTest','tests':89,'failures':0,'errors':0,'skipped':0}
before=json.loads((main/'knowledge-inputs-before.json').read_text());after=json.loads((main/'knowledge-inputs.json').read_text())
assert before['candidate']==candidate and before['inputs']==after
expected={x['path']:x['sha256'] for x in inputs};actual={x['path']:x['sha256'] for x in after}
assert actual==expected
knowledge_xml=main/'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
xml=ET.parse(knowledge_xml).getroot()
assert {k:int(xml.attrib[k]) for k in ['tests','failures','errors','skipped']}=={k:summary[k] for k in ['tests','failures','errors','skipped']}
assert len(xml.findall('testcase'))==89 and not xml.findall('.//failure') and not xml.findall('.//error') and not xml.findall('.//skipped')
start=datetime.datetime.fromisoformat(java_step['startedAt']);end=datetime.datetime.fromisoformat(java_step['finishedAt'])
original_xml=repo/'gmp-platform/backend/target/surefire-reports'/knowledge_xml.name
assert start.timestamp() <= original_xml.stat().st_mtime <= end.timestamp()
assert sha(original_xml.read_bytes())==sha(knowledge_xml.read_bytes())
assert (main/'runner-source.py').read_text().find('p.stat().st_mtime>=started.timestamp()')>=0
runtime=[]
node=json.loads((main/'node-summary.json').read_text())
assert node=={'tests':91,'pass':91,'fail':0,'skipped':0,'cancelled':0}
tap=(main/'node.log').read_text()
for k,v in node.items():assert int(re.search(r'^# '+k+r' (\d+)',tap,re.M).group(1))==v
for width in [1440,390]:
 for label,count in [('document',8),('save',13),('import',15)]:
  p=main/(label+'-'+str(width))/'result.json';x=json.loads(p.read_text())
  assert x.get('head',x.get('sourceCommit'))==candidate
  assert len(x['results'])==count and all(y.get('outcome',y.get('status'))=='passed' for y in x['results'])
  for fingerprint in x.get('sourceFingerprints',[]):
   name='gmp-platform/frontend/'+fingerprint['path'];assert sha((repo/name).read_bytes())==fingerprint['sha256']==sha(subprocess.check_output(['git','show',candidate+':'+name],cwd=repo))
  runtime.append({'path':str(p.relative_to(main)),'cases':count,'width':width,'sha256':sha(p.read_bytes()),'qualification':x.get('boundary',x.get('callbackObservation'))})
for item in run['sourceFingerprints']:
 name=item['path'];assert item['sha256']==sha((repo/name).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+name],cwd=repo))
changes=subprocess.check_output(['git','diff','--name-only',base,candidate],cwd=repo,text=True).splitlines()
for name in changes:
    assert not name.startswith(('docs/knowledge/','docs/architecture/'))
    assert '/src/main/' not in name
    assert name not in ['AGENTS.md','codeplzreadme.md'] and not name.startswith('docs/agents/')
source_names=[
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/TemplateDesignerReactShell.tsx',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/types/document.ts',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/tabs/model/FormInstanceDetailDrawer.tsx',
 'gmp-platform/frontend/src/pages/workflow-center/WorkTemplateEditor.tsx',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/controller/TemplateModelingController.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionSnapshotBuilder.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormProjectionService.java',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/store/useTemplateDesignerStore.ts',
]
bound=[]
for name in source_names:
    b=(repo/name).read_bytes();assert b==subprocess.check_output(['git','show',candidate+':'+name],cwd=repo)
    p=raw/'candidate-snapshots'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    bound.append({'path':name,'bytes':len(b),'sha256':sha(b)})
out={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':base,
 'knowledgeFilesUnchanged':353,'validationInputs':inputs,'exactMainKnowledge359FingerprintsMatch':True,
 'knowledgeTestsObserved':summary,'knowledgeCommandObserved':java_step['command'],'sourceBindings':bound,'changedPaths':changes,
 'mainRuntimeSourceFingerprintsMatched':len(run['sourceFingerprints']),'mainNodeObserved':node,'mainBrowserObserved':runtime,
 'javaArtifactFreshness':{'startedAt':java_step['startedAt'],'finishedAt':java_step['finishedAt'],'originalXmlMtime':original_xml.stat().st_mtime,'originalCopiedXmlIdentical':True,'actualTestcaseCount':89},
 'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','roadmapPreserved':'P0 in-progress',
 'qualification':'Static/reference checks by ontology role;formal 89 executed by main and only read here;this is not independent runtime QA.'}
(raw/'final-source-knowledge-binding.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
dest=raw/'read-evidence/knowledge';dest.mkdir(exist_ok=True)
for name in ['run.json','java-summary.json','knowledge-inputs-before.json','knowledge-inputs.json','runner-source.py','java.log']:
    shutil.copyfile(main/name,dest/name)
for p in main.glob('TEST-*.xml'):shutil.copyfile(p,dest/p.name)
runtime_dest=raw/'read-evidence/final-main';runtime_dest.mkdir(exist_ok=True)
for name in ['node-summary.json','node.log','build.log','verify-template-designer-react.log','verify-list-table-style-contract.log','verify-no-external-fonts.log']:
 shutil.copyfile(main/name,runtime_dest/name)
for item in runtime:
 p=Path(item['path']);target=runtime_dest/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(main/p,target)
subprocess.run(['python3',str(raw/'build-finite-records.py'),candidate],check=True)
print(json.dumps({'candidate':candidate,'knowledgeInputs':len(inputs),'knowledgeFilesUnchanged':353,'testsObserved':summary},ensure_ascii=False))
