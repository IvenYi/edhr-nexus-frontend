# 独立源码及行为核对

本实例未参与任何实现或修复。范围是 `0dd6e8828f544aec01285e0ea140029d783ec38f..3193fc646951c0accde0fe36e494273ef4f33e06` 的五文件切片；不形成全仓完成声明。

原始源码：`document.ts` 的 safeParseJson / parsePersistedSlice / parseReactTemplateDesignerDocument / serializeTemplateDesignerDocument / normalizeCanvasState 与页面归一化；Shell 的来源生命周期、persistCurrentDocument、handleSave、handleFieldConfirmPersist、关闭、导入和渲染资格；ModelTab 的新字段确认调用；FormInstanceDetailDrawer 与 WorkTemplateEditor 的只读消费者；TemplateModelingController 的版本初始化和设计保存。新维护两测试脚本及原保存／导入回归均实际读取。

1. 编辑入口增加可选严格读取，默认二参数只读入口不改变。空白字符串/空值、后端三个空白初始化对象、空对象及当前协议不完整 payload 保留；不将协议 version=1 解释为业务模板 V1。非空无法解释的编辑源不能自动变成可写空白。
2. 先完整 parse 成功，再 setDocument / markSaved；解析失败保留旧 store、undo/redo 和保存基线原件。loadedSource 同时核对当前对象引用和保存上下文，切换待加载、失败、关闭及旧持有回调不能越过来源边界。
3. 写入链仍沿原 onSave/onAutoSave 和序列化接口，成功后的基线绑定本次 currentDocument，已有晚响应与投影目录检查保持。服务端权限、状态、签署、审计、事务、数据库、API、初始化和冻结快照未修改。
4. 失败页使用既有 MUI Alert，原 AppDialog/Snackbar，中文错误明确给出关闭重试方式；原编辑器区域不显示。正常保存、空白初始化、加载失败无写、同身份内容更新、脏旧 store 下的失败关闭和正常重开均有真实组件浏览器证据。
5. 持有旧字段自动保存回调仅是生命周期压力测试。ModelTab 当前在首次 await 前直接调用父回调，不能据此声称原页面必然存在异步晚调用入口。
6. A23：删除编辑失败的静默空白回退有确定丢失风险依据；保留真实空白/不完整草稿，未加入字段业务完整性、发布门禁、迁移框架或跨请求缓存。加载源与已有 context token 不重复提供业务授权：前者控制当前编辑来源有效，后者隔离异步保存/导入，保护目的不同。
7. 性能：编辑验证每个源至多一次 JSON.parse（三片至多三次）；未增加全副本 JSON 往返。未改查询/数据库/批量容量，也未据局部测试承诺生产内存或SLA。剩余深层 schema 归一化与导入格式分支仍待后续审计。
8. 大文件维护边界：document 工具可在后续独立维护需求中按“持久协议读取/纯归一化”分离；Shell 可按“加载源生命周期/保存导入编排”拆分。当前缺陷用局部保护解决，不为本轮扩大模块重构。不是只统计行数，也不宣称已完成拆分。

依据：DEC-0077-12 使用时冻结；22 同一配置保存撤销；30 草稿免业务完整性但请求格式/权限/证据安全继续；DEC-0080 同字段选项共享；DEC-0067-05 限填报设置切片，不外推全设计器。后台接受裸非空 JSON 是实现证据，不将这些内容称为业务非法；当前设计器不能解释时停止覆盖。readonly 原兼容输出保持不等于所有历史格式已证明正确。

独立运行 Node 91、双宽浏览器72、Controller41 与知识89 均通过；build 含 tsc，原3静态guard未改变。原基线同测试反例只检查主侧原件，不声称本实例重跑。官方 strict 同范围基线/候选 finding 多重集一致，仓库86／前端28原债务保留；ESLint缺配置两边exit2，未称通过。

本批独立发现为空。正常路径、异常与相邻回归通过不代表全站 E2E、原生PG、全UI矩阵、完整历史格式或W0—W7及全知识语义完成。
