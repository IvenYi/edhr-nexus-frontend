from pathlib import Path
import datetime, hashlib, json, shutil, subprocess
import yaml

raw = Path(__file__).parent
root = Path('/tmp/edhr-designer-document-qa-20261112')
ontology = Path('/tmp/edhr-w2-designer-document-ontology-20261112')
base = '0dd6e8828f544aec01285e0ea140029d783ec38f'
head = '3193fc646951c0accde0fe36e494273ef4f33e06'
sha = lambda data: hashlib.sha256(data).hexdigest()
run = json.loads((raw / 'final/run.json').read_text())
assert run['result'] == 'passed' and run['head'] == head
assert all(s['exitCode'] == 0 for s in run['steps'])
node = json.loads((raw / 'final/node-summary.json').read_text())
assert node == {'tests': 91, 'pass': 91, 'fail': 0, 'skipped': 0, 'cancelled': 0}
browser = json.loads((raw / 'browser-summary.json').read_text())
assert browser['total'] == 72 and all(x['failed'] == 0 for x in browser['suites'])
java = json.loads((raw / 'final/java-summary.json').read_text())
assert [(x['class'], x['tests']) for x in java] == [('TemplateModelingControllerTest', 41), ('BusinessKnowledgeModelTest', 89)]
assert all(x['failures'] == x['errors'] == x['skipped'] == 0 for x in java)
for item in run['sourceFingerprints']:
    data = (root / item['path']).read_bytes()
    assert sha(data) == item['sha256']
    assert data == subprocess.check_output(['git', 'show', head + ':' + item['path']], cwd=root)

manifest = json.loads((ontology / 'manifest.json').read_text())
for item in manifest['files']:
    data = (ontology / item['path']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
for line in (ontology / 'SHA256SUMS').read_text().splitlines():
    checksum, path = line.split('  ', 1)
    assert sha((ontology / path).read_bytes()) == checksum
onto = yaml.safe_load((ontology / 'ontology-result.yaml').read_text())['ontologyResult']
assert onto['result'] == 'not-applicable' and onto['contractBaseline']['sourceCommit'] == head
assert onto['conflicts'] == onto['questions'] == []
out = raw / 'ontology-final'
out.mkdir(exist_ok=True)
for name in ['ontology-result.yaml', 'review.md', 'finite-review-summary.json']:
    shutil.copyfile(ontology / name, out / name)
(raw / 'ontology-final-inspection.json').write_text(json.dumps({
    'inspectedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceDirectory': str(ontology), 'manifestSha256': sha((ontology / 'manifest.json').read_bytes()),
    'manifestMembersVerified': len(manifest['files']), 'allDeclaredHashesVerified': True,
    'result': onto['result'], 'candidate': head,
    'qualification': 'Independent inspection of ontology FINAL;not claimed independent whole-knowledge semantic audit'
}, indent=2) + '\n')

link = root / 'gmp-platform/frontend/node_modules'
assert link.is_symlink()
link.unlink()
status = subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=root, text=True)
assert status == ''
remote_cmd = ['git', 'ls-remote', 'origin', 'refs/heads/edhr-dev']
remote = subprocess.check_output(remote_cmd, cwd=root, text=True)
assert remote.split()[0] == base
(raw / 'final-working-tree.json').write_text(json.dumps({
    'observedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head,
    'statusCommand': ['git', 'status', '--porcelain=v1'], 'workingTreeState': status,
    'temporaryDependencySymlinkRemoved': True, 'remoteCommand': remote_cmd, 'remoteOutput': remote,
    'noProductOrTestModificationsByReviewer': True
}, indent=2) + '\n')

checks = []
def check(id, category, description, method, evidence, command='', required=True, outcome='passed'):
    checks.append(dict(id=id, required=required, category=category, description=description,
                       method=method, command=command, outcome=outcome, evidence=evidence))
check('quality.baseline-and-scope', 'requirements', '独立核对五文件切片、契约和目标基线，无业务/后台/依赖/知识扩展', 'inspection', ['baseline.json', 'scope-verification.json', 'final-working-tree.json'])
check('quality.policy-and-readonly', 'ontology', '有限业务规则、原默认只读消费者和编辑加载保护一致', 'inspection', ['source-review.md', 'ontology-final/ontology-result.yaml', 'ontology-final-inspection.json'])
check('quality.old-runtime-counterexamples', 'regression', '复核主侧同最终脚本的旧实现反例，区分产品失败与夹具失败', 'inspection', ['negative-evidence-inspection.json', 'main-negative-evidence/old-node.log', 'main-negative-evidence/browser-1440/result.json', 'main-negative-evidence/browser-390/result.json'])
check('quality.parser-unit', 'unit', '实际当前协议往返、真实空白、不完整草稿、十八类不可解释来源、只读和每片一次parse', 'automated-test', ['final/node.log', 'final/node-summary.json'], 'node --test --test-reporter=tap scripts/test-designer-document-read.mjs (included in 91-case node run)')
check('quality.adjacent-node', 'regression', '其余64项原保存状态、子列同步、共享选项、表单与执行预览回归', 'automated-test', ['final/node.log', 'final/node-summary.json'], 'node --test --test-reporter=tap scripts/test-designer-save-state.mjs scripts/test-designer-subfield-sync.mjs scripts/test-designer-choice-options.mjs scripts/test-form-document-preview.mjs scripts/test-execution-document-viewer.mjs (same recorded 91-case run)')
check('quality.existing-guards', 'regression', '原设计器、列表样式、外部字体三检查原断言未改且实际通过', 'command', ['scope-verification.json', 'final/verify-template-designer-react.log', 'final/verify-list-table-style-contract.log', 'final/verify-no-external-fonts.log'], 'node scripts/verify-template-designer-react.mjs; node scripts/verify-list-table-style-contract.mjs; node scripts/verify-no-external-fonts.mjs')
check('quality.build-typecheck', 'integration', '实际npm构建包含tsc -b与Vite', 'command', ['final/build.log', 'final/run.json'], 'npm run build')
check('quality.document-browser', 'e2e', '实际组件受控宿主：正常/空白、失败无写、同身份更新、脏旧store关闭重开及旧持有回调，两宽16项', 'browser', ['final/document-1440/result.json', 'final/document-390/result.json'], 'node scripts/test-designer-document-read-browser.mjs (DOCUMENT_READ_WIDTH=1440 and 390)')
check('quality.save-context-browser', 'regression', '实际原保存上下文两宽26项，保留目录失败重试、晚响应、撤销重做与确认恢复', 'browser', ['final/save-1440/result.json', 'final/save-390/result.json'], 'node scripts/test-designer-save-context-browser.mjs (SAVE_CONTEXT_WIDTH=1440 and 390)')
check('quality.import-browser', 'regression', '实际原Excel/Word导入与过期结果两宽30项', 'browser', ['final/import-1440/result.json', 'final/import-390/result.json'], 'node scripts/test-designer-import-browser.mjs (IMPORT_WIDTH=1440 and 390)')
check('quality.controller', 'api', '原控制器mock/direct回归41项，新鲜XML且零skip，不冒充真实PG或HTTP', 'automated-test', ['final/java.log', 'final/java-summary.json', 'final/TEST-com.zencas.edhr.template.controller.TemplateModelingControllerTest.xml'], 'bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress -f gmp-platform/backend/pom.xml -Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest test')
check('quality.knowledge', 'ontology', '知识89项自动校验实际独立重跑，359输入前后和Git一致，不等于全库语义通过', 'automated-test', ['final/java-summary.json', 'final/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml', 'inputs-verified.json'], 'same independently executed Maven command;BusinessKnowledgeModelTest=89')
check('quality.visual-keyboard', 'visual', '实际查看两宽错误及正常导入截图；中文错误不截断、关闭可达、错误不能误编辑旧画布；键盘关闭由浏览器实跑', 'inspection', ['visual-review.json', 'final/document-390/workflow-syntax.png', 'final/document-1440/workflow-syntax.png', 'final/import-1440/normal-xlsx.png', 'final/import-390/normal-xlsx.png'])
check('quality.robustness-a23', 'security', '只保护不可解释来源和旧上下文；真实空白/草稿保留，无新业务完整性、跨请求缓存或全schema框架', 'inspection', ['source-review.md', 'anti-pattern-scan.json'])
check('quality.premium-increment', 'regression', '官方脚本同范围基线/候选完整finding多重集相同，仅忽略行移位，无新增', 'command', ['premium-commands.json', 'premium-comparison.json', 'baseline-repo-premium.json', 'candidate-repo-premium.json', 'baseline-frontend-premium.json', 'candidate-frontend-premium.json'], 'python3 audit_project.py <baseline/candidate repo and frontend> --mode strict --output <recorded paths>')
check('quality.inputs-and-integrity', 'documentation', '受测43输入和359知识/测试输入对照当前及Git，结束清理软链且worktreeclean', 'inspection', ['inputs-verified.json', 'final-working-tree.json', 'final/run.json'])
check('quality.premium-whole-repo', 'visual', '既有全仓86、前端28的strict债务仍未关闭；包含关系不相加', 'command', ['premium-comparison.json', 'candidate-repo-premium.json', 'candidate-frontend-premium.json'], 'recorded official strict audit commands', required=False, outcome='blocked')
check('quality.eslint', 'regression', '基线/当前ESLint均因既有缺配置exit2，未计通过，未修改配置或标准', 'command', ['lint-commands.json', 'baseline-lint.log', 'candidate-lint.log'], 'node <installed-eslint> . --ext ts,tsx --report-unused-disable-directives --max-warnings 0', required=False, outcome='blocked')

risks = [
    dict(id='risk.controlled-component-not-db-e2e', description='72浏览器用例使用真实组件和受控API/回调；控制器41为mock/direct。', impact='未认证真实HTTP权限/数据库事务与生产端到端。', mitigation='后续按相应链继续真实集成验收；本批不改后台或DB。'),
    dict(id='risk.incomplete-format-coverage', description='本批非全schema叶子语义、所有Excel/Word/历史格式或迁移审查；readonly保留旧兼容输出。', impact='不能由本批推定全部历史正确显示或所有格式不丢信息。', mitigation='继续原W2格式解码、归一化、序列化身份/信息保留链。'),
    dict(id='risk.existing-static-lint-debt', description='strict仓库86/前端28原债务及ESLint缺配置保留。', impact='未宣称全仓静态合规或lint通过。', mitigation='本批完整finding多重集新增0；按既有后续审计队列处理，不改标准换绿。'),
    dict(id='risk.not-overall-completion', description='全W2、W3—W7、全知识语义、A23已审补查及其他原暂缓未完成。', impact='局部修复与293项通过不能换算全审计完成比例。', mitigation='台账分列盘点、有限方法审查、语义核对和运行证据，新增提交增量核对。'),
    dict(id='risk.no-production-capacity-claim', description='每片至多一次parse只是本地重复解析检查，未做最大格式/文档容量或生产SLA实验。', impact='不能据此推定大数据量响应、CPU或峰值内存安全。', mitigation='容量风险另设可复现实验并先同用户讨论。'),
    dict(id='risk.ui-matrix-limited', description='手动视觉聚焦此次错误页/头部恢复；正常窄屏复杂画布存在既有横向空间限制，未在本批改布局。', impact='不是完整设计器响应式、全站无障碍、账号/离线/权限矩阵认证。', mitigation='保留既有完整UI审计队列和用户暂停的生产管理弹窗范围。'),
]
result = dict(result='passed', baseCommit=base, headCommit=head,
              contractBaseline=dict(sourceCommit=head, targetBranch='edhr-dev', targetCommit=base,
                                    contractReadCommit=head, uncommittedContractPaths=[]),
              workingTreeState=dict(status='clean', includedPaths=[], excludedPaths=[], untrackedPaths=[]),
              knowledgeBaselineVersion='0.3.25', checks=checks, findings=[], residualRisks=risks, blockingConditions=[])
assert all(c['outcome'] == 'passed' for c in checks if c['required'])
(raw / 'quality-result.yaml').write_text(yaml.safe_dump({'qualityResult': result}, allow_unicode=True, sort_keys=False, width=120))
(raw / 'review.md').write_text(f'''# W2 设计文档加载保护：独立最终验收

本实例未参与修复，未修改任何产品、测试或配置，独立工作树 `{root}` 固定候选 `{head}`；目标 `{base}`。自行读取契约、知识0.3.25、相关决策、DESIGN与DP，契约/知识/后台/依赖差异为空。最终依赖软链已清理，工作树clean，实际远端目标仍一致。

正式 **qualityResult: passed**，16个必需检查通过，无新增findings或blockingConditions；2项可选原债务保留blocked（strict全仓、缺配置lint）。这不是全仓质量全绿或整个W2/W0—W7完成。

本人实际独立运行 **204项功能用例通过**：Node91、真实组件浏览器72（1440/390每宽读取8、保存13、导入15）、原控制器mock/direct41；另知识**89/89**。共293项通过，0失败/错误/skip。build含tsc、原3静态guard通过；43源码输入与359知识/知识测试输入的运行前后、当前与Git字节相同。新鲜JUnit XML、完整命令/开始结束时间/原截图/结果见final。

来源读取失败不再显示可写空白或暴露旧store；错误无写回调且旧document/undo/redo/savedSnapshot原件保持。真实空白、已知API初始对象、不完整当前payload与正常三片往返保留。失败键盘关闭后正常重开保存、同身份变更、保存/导入晚响应均通过。持有旧字段回调只是压力测试，不声称ModelTab当前真实在首次调用前延迟。协议version1不限制模板业务版本V1；服务端可接受裸非空JSON，本批只防止当前编辑器无法解释时错误覆盖。

已实际查看两宽错误截图和正常导入截图；中文错误可读、关闭可达、禁用态有区分，旧编辑区域隐藏；复用MUI Alert与既有AppDialog/Snackbar，不改变视觉系统。查看正常窄屏并不等于验证整个复杂画布响应式。手动检查和源码责任、A23/容量/提取边界见source-review.md与visual-review.json。

同最终测试脚本旧实现的反例是**检查主侧原件，未声称本人重跑**：Node11P16F；每宽浏览器2P6F，记录真实manual保存默认内容或结构pageerror，而非依赖失败。官方脚本由本人实际跑四组strict，仓库base/current各86、前端各28；完整finding多重集仅排除行移位后完全相同，新增0，退出码仍2。86/28包含不相加。ESLint基线/候选均缺配置exit2，不记通过。

本体正式NA FINAL已复核候选与manifest全部成员摘要，未改知识或成熟度；有限语义范围和原待决/gap见ontology-final原件，不能当全知识审计。既有DEC0077使用时冻结、单文档保存撤销、草稿边界和DEC0080共享选项保持，DEC0067切片不外推为全局格式政策。

限制：浏览器为真实组件+受控API/回调，不是原生后端/PGE2E；控制器mock/direct非HTTP鉴权认证。未执行生产DB、迁移、恢复、部署、CI。全schema叶子、格式/容量、完整UI/权限/账号矩阵、W2剩余及W3—W7/A23/全知识语义继续，不因本批零skip认定上一批条件用例已补跑。源码与说明一致，建议此批修复按主审实际PR前漂移门禁通过后人工合并。
''')

files = []
for p in sorted(raw.rglob('*')):
    if not p.is_file() or p.name in {'manifest.json', 'SHA256SUMS'}:
        continue
    data = p.read_bytes()
    files.append(dict(path=str(p.relative_to(raw)), bytes=len(data), sha256=sha(data)))
manifest_data = dict(status='FINAL', role='independent-quality', testedCandidate=head, targetCommit=base,
                     sealedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), files=files)
(raw / 'manifest.json').write_text(json.dumps(manifest_data, ensure_ascii=False, indent=2) + '\n')
sums = [f"{item['sha256']}  {item['path']}" for item in files]
sums.append(f"{sha((raw / 'manifest.json').read_bytes())}  manifest.json")
(raw / 'SHA256SUMS').write_text('\n'.join(sums) + '\n')
for item in files:
    assert sha((raw / item['path']).read_bytes()) == item['sha256']
print(json.dumps(dict(result='passed', status='FINAL', candidate=head, tests=293,
                     requiredChecks=16, optionalExistingBlocked=2, files=len(files),
                     manifestSha256=sha((raw / 'manifest.json').read_bytes())), indent=2))
