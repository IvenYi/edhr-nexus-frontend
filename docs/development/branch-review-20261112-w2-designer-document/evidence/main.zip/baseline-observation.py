from pathlib import Path
import datetime,json,subprocess
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
pr=json.loads(subprocess.check_output(['gh','pr','view','85','--json','number,state,mergedAt,mergeCommit,headRefOid,baseRefName,url'],cwd=root,text=True))
base=git('rev-parse','origin/edhr-dev');assert base=='0dd6e8828f544aec01285e0ea140029d783ec38f'
assert pr['state']=='MERGED' and pr['mergeCommit']['oid']==base
delivery='5295f40f64ebd95d8d2ac0ce830236e48d0e2a61';assert git('rev-parse',base+'^{tree}')==git('rev-parse',delivery+'^{tree}')
data={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pr85':pr,'latestFetchedTarget':base,'targetTree':git('rev-parse',base+'^{tree}'),'priorDeliveryTreeIdentical':True,'externalIncrementNameStatus':git('diff','--name-status',delivery,base),'candidate':git('rev-parse','HEAD'),'currentBranch':git('branch','--show-current'),'contractDelta':git('diff','--name-status',base,'HEAD','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge')}
(raw/'baseline-observation.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps(data,ensure_ascii=False))
