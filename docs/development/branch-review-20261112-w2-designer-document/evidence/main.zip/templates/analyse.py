from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
candidate='6e878e496189c2fdd765f9ea71b5264a3e181709';base='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
run=load(raw/'optimized_final/run.json');summary=load(raw/'optimized_final/test-summary.json');knowledge=load(raw/'knowledge/run.json')
assert run['head']==knowledge['head']==candidate and not run['workingTreeState'] and not knowledge['workingTreeState']
assert run['exitCode']==knowledge['exitCode']==0 and summary['totals']==dict(tests=208,failures=0,errors=0,skipped=3)
assert load(raw/'knowledge/test-summary.json')==dict(tests=89,failures=0,errors=0,skipped=0)
for item in run['sourceFingerprints']+knowledge['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=repo))
old=load(raw/'old_same_tests/run.json');negative=load(raw/'old_same_tests/test-summary.json')
assert old['head']==base and old['exitCode']!=0 and negative['totals']==dict(tests=11,failures=6,errors=0,skipped=0)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/ProductionFormValueBoundaryTest.java'
oldtest=next(x for x in old['sourceFingerprints'] if x['path']==test)
assert oldtest['sha256']==sha((repo/test).read_bytes())
failures=[]
for f in (raw/'old_same_tests').glob('TEST-*.xml'):
 for case in ET.parse(f).getroot().findall('testcase'):
  fail=case.find('failure')
  if fail is not None:failures.append({'name':case.attrib['name'],'message':fail.attrib.get('message'),'type':fail.attrib.get('type')})
assert len(failures)==6
cost=[]
for p in sorted((raw/'optimized_final/observations').glob('*.json')):
 d=load(p);assert d['inputUnchanged'] and d['previousUnchanged']
 assert d['actualH2Queries']==(1 if d['repeatedFile'] and d['rows'] else 0)
 assert len(d['queries'])==d['actualH2Queries']
 before=load(raw/'final_candidate/observations'/p.name)
 cost.append({'rows':d['rows'],'file':d['repeatedFile'],'inputJsonBytes':d['inputJsonBytes'],
  'beforeAllocatedBytes':before['threadAllocatedBytes'],'afterAllocatedBytes':d['threadAllocatedBytes'],
  'beforeH2Queries':before['actualH2Queries'],'afterH2Queries':d['actualH2Queries'],'afterElapsedNanos':d['elapsedNanos']})
assert len(cost)==7
changed=subprocess.check_output(['git','diff','--name-only',base,candidate],cwd=repo,text=True).splitlines()
assert len(changed)==3
assert not subprocess.check_output(['git','diff','--name-only',base,candidate,'--','docs/knowledge'],cwd=repo,text=True).strip()
out={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':base,'changedFiles':changed,
 'mainTests':summary,'passedTests':205,'conditionalNotPassed':3,'knowledgeTests':load(raw/'knowledge/test-summary.json'),
 'protectedInputs':run['sourceFingerprints'],'knowledgeInputCount':len(knowledge['sourceFingerprints']),'currentAndCandidateHashesMatch':True,
 'oldSameFinalTests':negative,'oldFailures':failures,'performanceObservations':cost,
 'beforePhase':'final_candidate at61155;same old product and fixture shape but earlier test bytes;actual same final test negative separately in old_same_tests',
 'processFailurePreserved':{'phase':'final','tests':206,'errors':9,'skipped':3,'cause':'new test JdbcTemplate SHUTDOWN teardown warning lookup on closed H2;not product failure'},
 'qualification':'Actual domain methods and H2 query execution/counter;method-local allocated bytes include JDBC/query-log overhead where files are used,not RSS/peak/full SAVE/PG plan/SLA;no business policy,UI/schema/index/knowledge change'}
(raw/'main-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
scopes=[('production/service/ProductionExecutionEngine.java',['formActionInternal','validateValues','prepareTableRows','previousRow','validateNestedEdits','applyDefaults'],'selected branches;existing source and regression,not entire engine'),
 ('production/service/ExecutionAccess.java',['validateEvidence','previousRow','canAct','permissions'],'call-local metadata and read-only shallow context;row lookup CPU unchanged'),
 ('production/service/ProductionExecutionService.java',['act'],'SAVE to saved/persistence/audit integration boundary,not all service commands'),
 ('production/service/FormInstanceRecordService.java',['saved','savedStage'],'record/trace/formal completion handoff;existing H2 integration,not native migration acceptance')]
rows=[]
for path,methods,scope in scopes:
 p='gmp-platform/backend/src/main/java/com/zencas/edhr/'+path
 rows.append({'candidate':candidate,'path':p,'sha256':sha((repo/p).read_bytes()),'methods':methods,'actualScope':scope,'fullFileComplete':False,'historicalUniqueNotRecomputed':True})
(raw/'method-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
print(json.dumps({'candidate':candidate,'protectedInputs':len(run['sourceFingerprints']),'knowledgeInputs':len(knowledge['sourceFingerprints']),'performance':cost},ensure_ascii=False,indent=2))
