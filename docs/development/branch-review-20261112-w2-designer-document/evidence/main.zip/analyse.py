from pathlib import Path
import collections,datetime,hashlib,json,re,subprocess

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;final=raw/'final_verified'
candidate='3193fc646951c0accde0fe36e494273ef4f33e06';base='0dd6e8828f544aec01285e0ea140029d783ec38f'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((final/'run.json').read_text());assert run['result']=='passed' and run['head']==candidate and not run['workingTreeState']
for item in run['sourceFingerprints']:
    name=item['path'];b=(root/name).read_bytes()
    assert sha(b)==item['sha256']==sha((final/'source'/name).read_bytes())
    assert b==subprocess.check_output(['git','show',candidate+':'+name],cwd=root)
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for item in after:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']
    assert b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
node=json.loads((final/'node-summary.json').read_text());assert node['pass']==91 and not node['fail'] and not node['skipped']
browsers=[]
for width in [1440,390]:
    for group,count in [('document',8),('save',13),('import',15)]:
        d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count
        assert all(x.get('outcome',x.get('status'))=='passed' for x in d['results'])
        browsers.append({'group':group,'width':width,'passed':count,'failed':0})
java=json.loads((final/'java-summary.json').read_text());assert [x['tests'] for x in java]==[41,89]
oldnode=(raw/'negative-final/old-node.log').read_text();oldsummary={k:int(re.search(r'^# '+k+r' (\d+)',oldnode,re.M).group(1)) for k in ['tests','pass','fail','skipped','cancelled']}
assert oldsummary==dict(tests=27,**{'pass':11,'fail':16,'skipped':0,'cancelled':0})
oldbrowser=[]
for width in [1440,390]:
    d=json.loads((raw/('negative-final/browser-'+str(width))/'result.json').read_text());p=sum(x['outcome']=='passed' for x in d['results']);assert p==2 and len(d['results'])==8
    failed=[{'case':x['case'],'writes':len(x.get('writes',[])),'pageErrors':x['errors']} for x in d['results'] if x['outcome']=='failed']
    oldbrowser.append({'width':width,'passed':p,'failed':6,'observedFailureDetails':failed})
premium=json.loads((raw/'premium-final-commands.json').read_text());assert all(x['fullFindingMultisetsEqualIgnoringLineOnly'] for x in premium)
baselineTests=[('gmp-platform/frontend/scripts/test-designer-document-read.mjs',sha((root/'gmp-platform/frontend/scripts/test-designer-document-read.mjs').read_bytes())),('gmp-platform/frontend/scripts/test-designer-document-read-browser.mjs',sha((root/'gmp-platform/frontend/scripts/test-designer-document-read-browser.mjs').read_bytes()))]
result={'analysedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':candidate,'target':base,'result':'passed',
 'protectedSourceInputs':len(run['sourceFingerprints']),'protectedSourceCurrentGitAndSnapshotEqual':True,'knowledgeInputs':len(after),'knowledgeBeforeAfterCurrentGitEqual':True,
 'node':node,'browserExecutions':browsers,'java':java,'functionalExecutions':204,'knowledgeChecksSeparate':89,
 'negativeSameFinalScripts':{'selectedProductCommit':base,'scriptSha256':dict(baselineTests),'node':oldsummary,'browser':oldbrowser,'scope':'Only new final scripts against selected old document/Shell modules;not all old suites. Actual callback writes demonstrate overwrite risk,not production persistence. Held callback is a stress probe,not proven current ModelTab delayed invocation.'},
 'premium':premium,'lint':{'baselineExit':2,'candidateExit':2,'reason':'Existing missing ESLint configuration;not counted passed'},
 'processFailuresRetained':{'final':'Original static guard only accepted literal close confirmation;91 Node passed then guard failed','candidate_final':'Same guard also required literal open expression;91 Node passed then guard failed','resolution':'Move loaded document condition to dialog rendering;retain original guard file and original dirty confirmation conditions;final_verified original guard passed'},
 'visualInspection':['final_verified/document-390/workflow-syntax.png','final_verified/document-1440/workflow-syntax.png'],
 'limits':['Real Shell/children with controlled API and save callbacks,not backend/database E2E','Controller tests are direct mock tests,not real HTTP/PG transactions','No full historical-format certification,leaf-schema semantics,production capacity or whole W2/W0-W7 completion','Official strict86/28 unchanged and missing lint configuration retained','No policy,backend API,schema,index,history/knowledge changes or new optimization authorized by this report']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['testedCandidate','result','protectedSourceInputs','knowledgeInputs','functionalExecutions','knowledgeChecksSeparate']}))
