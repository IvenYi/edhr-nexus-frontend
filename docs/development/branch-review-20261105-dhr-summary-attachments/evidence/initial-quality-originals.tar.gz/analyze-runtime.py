from pathlib import Path
import json,re,collections,subprocess,gzip,hashlib,concurrent.futures
out=Path('/tmp/edhr-summary-attachments-quality-20261105');native=out/'native-full2';obs=native/'observations'
events=[]
for p in sorted(obs.glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==16
def normalize(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
entries=[];current=[]
for line in (native/'postgres.log').read_text().splitlines():
 if re.match(r'^\d{4}-\d{2}-\d{2} \d\d:\d\d:',line):
  if current:entries.append('\n'.join(current))
  current=[line]
 else:current.append(line)
if current:entries.append('\n'.join(current))
bytag=collections.defaultdict(collections.Counter)
for line in entries:
 m=re.search(r'\b(audit_summary_\w+) LOG:\s+duration:\s+[\d.]+ ms\s+execute\s+[^:]+:\s*(.*)',line,re.S)
 if m:bytag[m.group(1)][normalize(m.group(2))]+=1
checks=[];kinds=collections.Counter();expected_select=0;hibernate_nonselect=0;driver_metadata=[]
for e in events:
 tag=e['applicationName'];observed=collections.Counter(normalize(s) for s in e['jdbcSql']+e['hibernateSql'] if normalize(s).startswith('select'))
 server=collections.Counter({s:n for s,n in bytag[tag].items() if s.startswith('select')})
 extra=server-observed
 for sql,count in extra.items():
  assert sql.startswith('select pg_type.oid, typname from pg_catalog.pg_type ') and sql.endswith('where typname = ? order by sp.r, pg_type.oid desc limit 1'),(tag,sql)
  driver_metadata.append({'applicationName':tag,'sql':sql,'count':count,'kind':'PG JDBC jsonb type resolution, actual raw parameters jsonb retained in postgres.log'})
  server[sql]-=count
 server=+server
 assert observed==server,(tag,observed-server,server-observed)
 assert sum(observed.values())==e['selectStatements']
 checks.append({'name':e['name'],'applicationName':tag,'matched':True,'selectStatements':sum(server.values()),'sqlShapes':[{'sql':s,'count':n} for s,n in sorted(server.items())]})
 for s,n in bytag[tag].items():kinds[s.split()[0]]+=n
 expected_select+=e['selectStatements'];hibernate_nonselect+=sum(not normalize(s).startswith('select') for s in e['hibernateSql'])
assert expected_select==998 and dict(kinds)=={'set':16,'select':999,'insert':22,'update':15,'delete':7},kinds
assert sum(x['count'] for x in driver_metadata)==1
assert hibernate_nonselect==8
(out/'server-sql-review.json').write_text(json.dumps({'matchedObservations':checks,'measuredBusinessSELECT':expected_select,'taggedServerTypesIncludingDriverMetadata':dict(kinds),'taggedDriverMetadataSELECT':driver_metadata,'hibernateNonSelect':hibernate_nonselect,'excludedScope':'Only per-observation application_name successful execute; tag-free init/setup/saveDraft/assert/FrozenIntegrity/EXPLAIN/runner SQL and transaction commands are not request counts; tag-internal driver jsonb type resolution is explicitly separate','method':'Independent entry parser; compare full normalized SQL counts per transaction tag, not copied application total'},ensure_ascii=False,indent=2)+'\n')

jfr=Path('/workspace/.edhr-cloud-tools/jdk-21/bin/jfr');exports=out/'jfr-json';exports.mkdir(exist_ok=True)
def parse_recording(e):
 source=obs/(e['name']+'.jfr');cmd=[str(jfr),'print','--json','--events','jdk.FileRead',str(source)]
 result=subprocess.run(cmd,check=True,capture_output=True);payload=json.loads(result.stdout)
 with gzip.open(exports/(e['name']+'.json.gz'),'wb') as f:f.write(result.stdout)
 selected=[];other_thread=0
 for raw in payload['recording']['events']:
  v=raw['values'];p=v.get('path','');is_original=bool(re.search(r'/original-\d+\.png$',p))
  if is_original and v['eventThread']['javaThreadId']!=e['measuredThreadId']:other_thread+=1
  if is_original and v['eventThread']['javaThreadId']==e['measuredThreadId']:selected.append(v)
 byte_count=sum(x['bytesRead'] for x in selected)
 assert byte_count==e['trackedLogicalReadBytes'] and len(selected)==e['trackedReadEvents'],e['name']
 return {'name':e['name'],'command':cmd,'measuredThreadId':e['measuredThreadId'],'logicalBytes':byte_count,'fileReadEvents':len(selected),'excludedOriginalEventsOtherThreads':other_thread,'paths':sorted(set(x['path'] for x in selected)),'threadAllocatedBytes':e['threadAllocatedBytes'],'elapsedNanos':e['elapsedNanos'],'heapBefore':e['heapBefore'],'heapAfter':e['heapAfter'],'data':e['data'],'rejection':e['rejection']}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:jfr_results=list(pool.map(parse_recording,events))
lookup={e['name']:e for e in jfr_results}
assert lookup['submit_50mib']['logicalBytes']==52428800 and lookup['submit_50mib']['threadAllocatedBytes']<25*1024*1024
assert [lookup['submit_'+str(n)]['logicalBytes'] for n in [0,1,10,100,300]]==[0,68,680,6800,20400]
assert lookup['lock_unlink_true']['logicalBytes']==0 and lookup['lock_unlink_false']['logicalBytes']==0
(out/'jfr-allocation-review.json').write_text(json.dumps({'recordings':jfr_results,'matchingRecords':len(jfr_results),'limits':['per-thread logical file bytes, not physical disk IO or distinct open count','calling-thread cumulative allocation, not retained heap/peak/RSS','global heap snapshots can include other threads; lock elapsed contains latch waits','50MiB fixture is directly registered verified PNG, not upload/verification/seven-format acceptance']},ensure_ascii=False,indent=2)+'\n')
plans=json.loads((obs/'existing-index-plans.json').read_text())
def flatten(plan):
 yield plan
 for p in plan.get('Plans',[]):yield from flatten(p)
active=plans['activePlan'][0];identity=plans['identityPlan'][0];nodes=list(flatten(active['Plan']));sort=next(n for n in nodes if n['Node Type']=='Sort')
assert any(n.get('Index Name')=='idx_dhr_attachment_active' for n in nodes)
assert sort['Actual Rows']==300 and sort['Sort Space Type']=='Memory' and sort['Temp Read Blocks']==sort['Temp Written Blocks']==0
assert identity['Plan']['Index Name']=='dhr_attachment_pkey'
(out/'index-plan-review.json').write_text(json.dumps({'fixture':{'sameDhrInactive':5000,'otherDhrMixed':5000,'activeInScope':300},'activePlan':active,'identityPlan':identity,'indexes':plans['indexes'],'conclusion':'Existing active-scope index and ID primary key used in this synthetic distribution; explicit linked_at,id sort has no temp blocks; no index change warranted by this evidence alone','sortKiB':sort['Sort Space Used'],'scope':'Raw EXPLAIN outputs, not request query counts or production SLA'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'runtimeEvents':len(events),'select':expected_select,'taggedTypes':dict(kinds),'jfrRecords':len(jfr_results),'fiftyMiBAllocated':lookup['submit_50mib']['threadAllocatedBytes'],'sortKiB':sort['Sort Space Used']}))
