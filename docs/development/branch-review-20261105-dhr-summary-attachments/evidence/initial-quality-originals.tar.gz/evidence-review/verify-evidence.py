from pathlib import Path
import collections, datetime, gzip, hashlib, json, re, shutil, subprocess, tarfile, xml.etree.ElementTree as ET, yaml
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-summary-attachments-quality-20261105/evidence-review')
batch=root/'docs/development/branch-review-20261105-dhr-summary-attachments';base='a429f983a7a69553753034e9306d12598fcc15be';head='7704f11267a810b2bda82e99f049a0206a5e73c7'
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
def digest(b):return hashlib.sha256(b).hexdigest()
def write(name,data): (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def norm(s):return ' '.join(re.sub(r'\$\d+','?',s).lower().split())
checks=[]
assert git('rev-parse','HEAD')==head
snapshots=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/development/branch-review-20261105-dhr-summary-attachments/decision-package.yaml','docs/development/branch-review-20261105-dhr-summary-attachments/review-notes.md']
for path in snapshots:
 p=out/'read-snapshots'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/path).read_bytes())
checks.append({'id':'current-contract-and-candidate','outcome':'passed','evidence':{'baseCommit':base,'headCommit':head,'contractReadCommit':head,'snapshots':snapshots}})
archives=[];main=None
for a in json.loads((batch/'evidence/archive-manifest.json').read_text())['archives']:
 p=batch/'evidence'/a['archive'];assert p.stat().st_size==a['bytes'] and digest(p.read_bytes())==a['sha256']
 dest=out/'unpacked'/a['archive'].removesuffix('.tar.gz')
 with tarfile.open(p) as tar:
  members={m.name:m for m in tar if m.isfile()};assert len(members)==a['fileCount']
  assert set(members)=={v['path'] for v in a['files']}
  for e in a['files']:
   b=tar.extractfile(members[e['path']]).read();assert len(b)==e['bytes'] and digest(b)==e['sha256']
   target=dest/e['path'];assert target.resolve().is_relative_to(dest.resolve());target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
 if (dest/'manifest.sha256').exists():assert digest((dest/'manifest.json').read_bytes())==(dest/'manifest.sha256').read_text().split()[0]
 archives.append({'archive':a['archive'],'files':len(members),'sha256':a['sha256']})
 if a['archive']=='main-originals.tar.gz':main=dest
assert sum(a['files'] for a in archives)==208
checks.append({'id':'all-archive-byte-integrity','outcome':'passed','evidence':archives})
phases={};failures=[]
for phase in ['focused','full','full2']:
 d=main/('native-'+phase);summary=json.loads((d/'test-summary.json').read_text());run=json.loads((d/'run.json').read_text());actual=collections.Counter()
 for p in d.glob('TEST-*.xml'):
  doc=ET.parse(p).getroot()
  for k in ['tests','failures','errors','skipped']:actual[k]+=int(doc.attrib[k])
  for c in doc.findall('testcase'):
   f=c.find('failure')
   if f is not None:
    msg=f.attrib.get('message','');m1=re.search(r'expected: "(.*?) \(ArrayNode@',msg,re.S);m2=re.search(r'but was: "(.*?) \(ArrayNode@',msg,re.S)
    assert phase=='full' and m1 and m2 and m1.group(1)==m2.group(1) and json.loads(m1.group(1))==json.loads(m2.group(1))
    failures.append({'method':c.attrib['name'],'wireJsonExactSame':True})
 if phase=='focused':assert summary['totals']['tests']==0 and summary['missingFreshReports'] and 'cannot find symbol' in (d/'maven.log').read_text()
 else:assert dict(actual)==summary['totals']
 if phase=='full':assert summary['totals']=={'tests':69,'failures':6,'errors':0,'skipped':0}
 if phase=='full2':
  assert summary['totals']=={'tests':69,'failures':0,'errors':0,'skipped':0}
  for f in run['sourceFingerprints']:assert digest((root/f['path']).read_bytes())==f['sha256']
 assert json.loads((d/'cleanup.json').read_text())['removed'] is True
 phases[phase]={'totals':summary['totals'],'missingFreshReports':summary['missingFreshReports'],'capturedSources':len(run['sourceFingerprints'])}
assert len(failures)==6
test=(root/'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java').read_text()
assert 'isEqualTo(expectedAttachments.path("items").toString())' in test and 'integrity.verify(version, mapper.readTree' in test and '25L * 1024 * 1024' in test
checks.append({'id':'xml-phases-and-candidate-source','outcome':'passed','evidence':{'phases':phases,'firstFullFailures':failures,'limits':'These are development test failures, not product defects or a performance negative control. Current exact serialized equality and frozen hash verification both retained.'}})
obs=main/'native-full2/observations';events=[]
for p in sorted(obs.glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==16
report=json.loads((batch/'performance-report.json').read_text());assert len(report['events'])==16
byname={e['name']:e for e in events};shapes={};selects=0;nonselect=0
for e in events:
 shape=collections.Counter(norm(s) for s in e['jdbcSql']+e['hibernateSql'] if norm(s).startswith('select'));assert sum(shape.values())==e['selectStatements'];shapes[e['applicationName']]=shape;selects+=sum(shape.values())
 nonselect+=sum(not norm(s).startswith('select') for s in e['hibernateSql'])
 reported=next(v for v in report['events'] if v['name']==e['name']);assert {k:v for k,v in e.items() if k not in ['jdbcSql','hibernateSql']}==reported
assert selects==998 and nonselect==8 and report['measuredSELECT']==998
chunks=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(main/'native-full2/postgres.log').read_text(),flags=re.M)
server=collections.defaultdict(collections.Counter);kinds=collections.Counter()
for chunk in chunks:
 m=re.search(r'edhr_dhr_summary_attachment_test_full2 (audit_summary_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',chunk,re.S)
 if not m:continue
 s=norm(m.group(2).strip());kinds[s.split()[0]]+=1
 if s.startswith('select'):server[m.group(1)][s]+=1
assert set(server)==set(shapes)
for key in shapes:assert shapes[key]==server[key],key
assert dict(kinds)=={'set':16,'select':998,'insert':22,'delete':7,'update':15},dict(kinds)
write('server-shape-check.json',{'events':len(events),'select':selects,'jpaOther':nonselect,'serverKinds':dict(kinds),'matchedShapesByEvent':{k:dict(v) for k,v in server.items()},'scope':'successful execute under action tags only; initialization/setup/assertions/EXPLAIN/transaction commands outside scope'})
checks.append({'id':'event-and-server-sql-math','outcome':'passed','evidence':{'events':16,'SELECT':998,'JPAOther':8,'writeTypes':dict(kinds),'fullShapeChecks':True}})
jfr=[]
for e in events:
 p=obs/(e['name']+'.jfr');target=out/'jfr-json'/(e['name']+'.json');target.parent.mkdir(exist_ok=True)
 with target.open('w') as f:subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(p)],stdout=f,stderr=subprocess.PIPE,text=True,check=True)
 data=json.loads(target.read_text());items=[];other=0
 for item in data['recording']['events']:
  values=item['values'];path=values.get('path') or '';thread=values.get('eventThread') or {}
  if re.search(r'/original-\d+\.png$',path):
   if thread.get('javaThreadId')==e['measuredThreadId']:items.append(values)
   else:other+=int(values.get('bytesRead',0))
 size=sum(int(v.get('bytesRead',0)) for v in items);assert size==e['trackedLogicalReadBytes'] and len(items)==e['trackedReadEvents'],(e['name'],size,len(items),e)
 jfr.append({'name':e['name'],'ownThreadLogicalBytes':size,'ownThreadFileEvents':len(items),'excludedOtherThreadLogicalBytes':other,'threadId':e['measuredThreadId']})
assert byname['submit_50mib']['trackedLogicalReadBytes']==52428800 and byname['submit_50mib']['threadAllocatedBytes']<25*1024*1024
for n in [0,1,10,100,300]:assert byname['submit_'+str(n)]['selectStatements']==13+2*n and byname['submit_'+str(n)]['trackedLogicalReadBytes']==68*n
write('jfr-check.json',{'jfrRecords':len(jfr),'events':jfr,'limits':['raw FileRead interpreted externally, not physical IO','allocation values checked against raw event report, not recomputed by this child; parent performs fresh runtime','elapsed lock time includes deliberate wait; heap snapshots not peak']})
checks.append({'id':'external-jfr-and-scale-resource-math','outcome':'passed','evidence':{'recordings':16,'fiftyMiBLogicalBytes':52428800,'allocationBudgetBytes':25*1024*1024,'measuredAllocationBytes':byname['submit_50mib']['threadAllocatedBytes'],'threadFilteringVerified':True}})
plans=json.loads((obs/'existing-index-plans.json').read_text());assert plans==report['indexExperiment']
def nodes(x):
 yield x
 for c in x.get('Plans',[]):yield from nodes(c)
active=plans['activePlan'][0]['Plan'];identity=plans['identityPlan'][0]['Plan'];allnodes=list(nodes(active))
assert active['Node Type']=='Sort' and active['Actual Rows']==300 and active['Sort Method']=='quicksort' and active['Sort Space Type']=='Memory' and active['Sort Space Used']==106
assert any(n.get('Index Name')=='idx_dhr_attachment_active' and n['Actual Rows']==300 for n in allnodes)
assert identity['Index Name']=='dhr_attachment_pkey' and identity['Actual Rows']==1 and all(n.get('Temp Read Blocks',0)==0 and n.get('Temp Written Blocks',0)==0 for n in allnodes+[identity])
checks.append({'id':'existing-index-plan-boundary','outcome':'passed','evidence':{'unrelatedOrInactive':plans['unrelatedOrInactive'],'activeRows':300,'sortKiB':106,'sortMemory':True,'tempBlocks':0,'identityIndex':identity['Index Name'],'newIndexAdded':False,'scope':'one synthetic complete-schema distribution, not production SLA'}})
protected=json.loads((batch/'protected-source-manifest.json').read_text());assert len(protected['files'])==1122
for e in protected['files']:
 b=(root/e['path']).read_bytes();assert digest(b)==e['sha256'] and b==subprocess.check_output(['git','show',base+':'+e['path']],cwd=root)
baseline=git('ls-tree','-r','--name-only',base).splitlines();assert len(baseline)==7591 and gzip.decompress((batch/'baseline-tracked-paths.txt.gz').read_bytes()).decode().splitlines()==baseline
assert sum(p.startswith('docs/knowledge/') for p in baseline)==350
records=[json.loads(s) for s in (batch/'finite-audit-records.jsonl').read_text().splitlines()];assert len(records)==15 and collections.Counter(e['conclusion'] for e in records)=={'consistent':13,'evidence-gap':2}
for e in records:
 p=root/e['sourcePath'];assert p.is_file()
 if e['recordType']=='markdown-evidence':assert e['id']==e['sourcePath'] and p.suffix=='.md'
 else:assert e['id'] in p.read_text()
 assert e['semanticReviewStatus']=='reviewed' and e['maturityChange']=='none'
ontology=yaml.safe_load((batch/'ontology-result.yaml').read_text())['ontologyResult'];assert ontology['result']=='not-applicable' and ontology['baselineAfter']=='0.3.25' and not ontology['changedArtifacts']
inventory=json.loads((batch/'inventory-summary.json').read_text());assert inventory['wholeFileCompletionThisBatch']==0 and inventory['trackedPaths']==7591
doc=(batch/'review-notes.md').read_text();assert all(s in doc for s in ['931','86 UI','W6','W7','尚未','当前未答','SubmissionAttachments','readSubmissionSourcesAndCheckDraftScope','verifySubmissionAttachmentOriginals','buildFrozenSummary','persistSummaryVersion'])
diff=git('diff','--name-only',base,head).splitlines();assert all(p.startswith('docs/development/') or p=='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java' for p in diff)
checks.append({'id':'protected-sources-finite-knowledge-and-a23-scope','outcome':'passed','evidence':{'protectedFiles':1122,'baselinePaths':7591,'knowledgeFiles':350,'finiteRecords':15,'consistentLimitedScope':13,'fullScenarioGaps':2,'wholeFilesCompleted':0,'uniqueHistory':'unknown','performanceReuse':'pending, unimplemented','A23':'guard meanings retained; concrete extraction/context proposals only'}})
result={'result':'passed','kind':'read-only-evidence-subcheck-not-final-quality','baseCommit':base,'headCommit':head,'contractReadCommit':head,'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[{'id':'limit.no-business-runtime','description':'Parsed original XML/PG/JFR and source bytes only; parent owns fresh runtime/final quality.'},{'id':'risk.performance-and-full-audit-open','description':'Metadata reuse and original whole-audit/full-runtime/production capacity remain open; no product fix implemented.'}],'resources':{'repositoryEdits':False,'mavenPgBrowserStarted':False,'cleanupRequired':False},'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
write('result.json',result);print(json.dumps({'result':'passed','checks':len(checks),'archives':sum(a['files'] for a in archives),'JFR':len(jfr)},indent=2))
