# 独立质量：7704取证阶段

实际来源/受测合并候选/契约读取为7704f11267a810b2bda82e99f049a0206a5e73c7；开始与结束独立fetch目标a429f983a7a69553753034e9306d12598fcc15be，无目标增量。该候选只新增测试/研发资产，产品、前端、知识、迁移及契约原字节保持；1122份保护指纹独立核对。知识0.3.25/schema1.2/P0 in-progress不变。

验证开始后，用户批准提交内元数据复用，主侧将在另一个后续候选实现。本结果只认证固定7704测试/取证阶段，不能覆盖随后产品或测试变更；新的产品最终门禁由主侧另派未参与修复的新实例承担。

## 实际运行及源码边界

自有detached工作树实际运行69/69：新真实PG15、相邻54（SummaryService8/Persistence24/WriteFailure5/Archive13/FormFiles4），均0F/E/S；独立知识89/89。canonical Liquibase当前图11保留原DDL/FK/索引，不宣称重演全部135条历史。仅后台FormProjectionWorker替身，源读取/附件/impact/冻结摘要/JPA审计服务及真实Spring事务实际执行；相邻H2/Mockito回归不冒充全部PG路径。

saveDraft/submit及提交后FrozenIntegrity校验真实；附件公开JSON按原序列化字符串逐字核对，草稿删除、单WORK候选、源证据、manual/checkResult、submitted_by_id、FORMALIZED及SUBMIT审计持久化均有断言。原始夹具直接SQL种入完成对象、单WORK源记录/空operations执行及VERIFIED PNG，不证明START/来源生成/完整生产完成、三来源/REQUIRED/签署或HTTP/RBAC。手工确认值只是测试已提供确认，不证明真实人工判断已进行。

6个拒绝动作覆盖缺失/坏原件/PENDING/保存后来源变化/人工三确认缺失/旧revision；失败后DRAFT和原草稿保留，无新冻结/SUBMIT审计。缺失和改字节保留元数据以真正进入完整SHA；PENDING在存草稿前设置以避免只测stale scope。实际pg_stat_activity看到unlink等待父DHR锁，active未变；成功提交定稿后unlink重读状态拒绝，无UNLINK审计；人工guard回滚后unlink成功且原件留存。不是任意SQL写者或全部部署并发证明。

## 服务器与JFR独立重算

按每动作application_name的成功execute逐完整SQL形状核对，16观察的998条业务SELECT完全吻合。服务器实际tag内部还多1条PG JDBC的pg_catalog.pg_type(jsonb)类型解析，原参数及SQL保留；独立原生本次SELECT服务器tag总数999=业务998+驱动1。该连接第一次在并发unlink保存jsonb审计时加载类型，不是额外业务N+1；不能因主侧运行没有这个暖连接差异就强行将全部网络SELECT写成998。44业务写为22INSERT/15UPDATE/7DELETE；16SET、事务和tag外初始化/种数/workspace/saveDraft/断言/FrozenIntegrity/EXPLAIN/runner不混为提交请求。

外部Java21 jfr工具独立解码16份记录，按measuredThreadId及实际original-N.png路径过滤，全部bytes/events吻合；并发录制中另一线程原件事件明确排除，unlink本身读取0字节。0/1/10/100/300附件逻辑字节0/68/680/6800/20400，业务SELECT13/15/33/213/613。50MiB完整读取52428800B，调用线程累计分配412656B，低于测试25MiB预算；此处不是上传/核验同样有界、七格式完整验收或生产峰值/RSS/SLA。heapBefore/After是全JVM快照；锁elapsed含人为latch等待，不作延迟性能承诺。

完整schema混合分布计划实际使用idx_dhr_attachment_active Bitmap Index/Heap，300有效行按linked_at,id内存quicksort106KiB、Temp块0；id按dhr_attachment_pkey检索，tenant/DHR过滤保留。现有索引不含排序列，不能宣称无Sort；本样本没有新增索引的依据，不推广生产计划/冷热/大行宽/并发容量。

## 原件、有限知识与A23

证据子项正式FINAL/passed7项：三归档208原件全部SHA，首focused缺imports导致编译失败无JUnit、首69六Jackson LongNode/IntNode断言F和最终69通过原XML/源码均吻合。最终要求持久化JSON与公开snapshot序列化原字节完全相同，不放宽数量/顺序/字段/摘要；这些是测试实现问题，不冒充产品负控或性能修复。

有限本体15记录为14个既有ID+1Markdown、13明确子范围一致/2广域场景gap，成熟度不升；350只是字节盘点，7591路径仅固定分母、整文件完成0/历史unique未知。不同的DHR资格、核验状态、scope hash、完整SHA、三人工确认、单源hash和整体版本hash分别保护不同依据，不能机械删去。readSubmissionSourcesAndCheckDraftScope/verifySubmissionAttachmentOriginals/buildFrozenSummary/persistSummaryVersion及SubmissionAttachments仅具体局部提案，7704未实施，不为行数大重构。

原931知识候选/86UI、W2余项/W3-W5交叉/W6健壮性性能抽取A23含已审代码/W7增量、PDF累计、history/索引/原DHR high/A12/全部矩阵与朋友签署页/生产弹窗暂停保持。NONE冻结不等于放行/DEC0090归档。本阶段回归不能关闭2N元数据性能问题，更不宣称整体审计完成。

## 独立性与资源

未修改任何仓库文件、产品/测试/夹具/配置；验证器仅建立自有detached工作树及node_modules依赖软链，并在指纹复核后清理。自有PG已删除，软链已移除，候选工作树clean后正常remove；没有查询/触发CI。

验证器初版分析程序将“所有tag内SELECT必等业务SQL”作为断言，实际暴露额外jsonb驱动元数据，随后按原始参数和完整SQL形状单列该1条，而非改业务计数或测试。子项初版分类将markdown-evidence写为markdown，已修正工具分类并留证。两者均为验证工具问题，未修改仓库或参与修复。
