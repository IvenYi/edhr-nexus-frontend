from pathlib import Path
import json,hashlib,re,collections,subprocess,xml.etree.ElementTree as ET
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-summary-attachments-20261105');out=r/'docs/development/branch-review-20261105-dhr-summary-attachments';base='a429f983a7a69553753034e9306d12598fcc15be'
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def norm(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
def events(phase):
 result=[]
 for p in sorted((raw/('native-'+phase)/'observations').glob('*.json')):
  e=json.loads(p.read_text())
  if 'applicationName' in e:result.append(e)
 return result
before=events('budget');after=events('optimized');assert len(before)==len(after)==19
parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(raw/'native-optimized/postgres.log').read_text(),flags=re.M)
server=collections.defaultdict(collections.Counter);alltagged=collections.defaultdict(collections.Counter)
for part in parts:
 m=re.search(r'edhr_dhr_summary_attachment_test_optimized (audit_summary_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if not m:continue
 shape=norm(m.group(2).strip());alltagged[m.group(1)][shape]+=1
 if shape.startswith('select'):server[m.group(1)][shape]+=1
matched=[];types=collections.Counter();driver=[]
for e in after:
 observed=collections.Counter(norm(s) for s in e['jdbcSql']+e['hibernateSql'] if norm(s).startswith('select'));actual=server[e['applicationName']].copy()
 extra=actual-observed
 for sql,n in extra.items():
  assert 'pg_catalog.pg_type' in sql and 'jsonb' in sql,(e['name'],sql)
  driver.append({'event':e['name'],'sql':sql,'count':n});actual[sql]-=n
 assert observed==+actual,(e['name'],observed-actual,actual-observed)
 matched.append({'name':e['name'],'selectStatements':e['selectStatements'],'shapesMatch':True,'shapes':[{'sql':s,'count':n} for s,n in actual.items() if n]})
 for s,n in alltagged[e['applicationName']].items():types[s.split()[0]]+=n
write('reuse-server-sql-review.json',{'events':matched,'businessSELECT':sum(e['selectStatements'] for e in after),'taggedStatementTypesIncludingDriver':dict(types),'driverMetadataSelect':driver,'hibernateNonSelect':sum(1 for e in after for s in e['hibernateSql'] if not norm(s).startswith('select')),'limits':'successful execute inside exact action tags only; parse/bind/SET/transaction, untagged initialization/setup/workspace/saveDraft/assert/frozen verification/EXPLAIN and runner SQL are separate'})
b={e['name']:e for e in before};a={e['name']:e for e in after}
keys=['selectStatements','trackedLogicalReadBytes','threadAllocatedBytes','heapBefore','heapAfter','elapsedNanos','rejection']
write('reuse-performance-report.json',{'baseCommit':base,'oldPhase':'budget: unchanged base products plus new identical final native test','finalPhase':'optimized: same native test, two product changes','events':[{k:v for k,v in e.items() if k not in ['jdbcSql','hibernateSql']} for e in after],'comparison':[{'name':n,'before':{k:b[n][k] for k in keys},'after':{k:a[n][k] for k in keys}} for n in a],'businessSELECTBefore':sum(e['selectStatements'] for e in before),'businessSELECTAfter':sum(e['selectStatements'] for e in after),'sourceReused':'same active query snapshot plus per-submit internal path/SHA, no cross-request cache or path in JSON','limits':['13 SELECT only declared one WORK source/NONE fixture, not universal request/HTTP total','JFR logical bytes filtered by recorded Java thread and original paths, not physical IO','thread allocations cumulative, not heap peak/RSS; global heap snapshots/concurrent lock timing not performance SLA','50MiB direct VERIFIED fixture proves submit streaming SHA consumer, not upload/verify/seven-format matrix','PDF/large manifest/production concurrency and all original remaining queues open']})
fps=json.loads((raw/'native-budget/run.json').read_text())['sourceFingerprints'];native='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java';oldfp=next(e for e in fps if e['path']==native);assert hashlib.sha256((r/native).read_bytes()).hexdigest()==oldfp['sha256']
failures=[]
for p in (raw/'native-budget').glob('TEST-*.xml'):
 for c in ET.parse(p).getroot().findall('testcase'):
  f=c.find('failure')
  if f is not None:failures.append({'name':c.attrib['name'],'message':f.attrib.get('message','')})
assert len(failures)==5
write('reuse-negative-control.json',{'totals':json.loads((raw/'native-budget/test-summary.json').read_text())['totals'],'nativeTestSameBytes':True,'nativeTestSha256':oldfp['sha256'],'failures':failures,'scope':'old products actual canonical successful service, same 18 native tests; five query-budget reds, 13 controls, no error/skip','originals':'second main archive preserves budget source/XML/log/JFR'})
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines();protected=[]
for p in paths:
 if not(p.startswith('docs/knowledge/') or p.startswith('gmp-platform/backend/src/main/') or p.startswith('gmp-platform/frontend/') or p in ['AGENTS.md','codeplzreadme.md'] or p.startswith('docs/agents/')):continue
 if not (r/p).is_file():continue
 old=subprocess.check_output(['git','show',base+':'+p],cwd=r);now=(r/p).read_bytes();protected.append({'path':p,'baselineSha256':hashlib.sha256(old).hexdigest(),'candidateSha256':hashlib.sha256(now).hexdigest(),'unchanged':old==now})
changed=[p['path'] for p in protected if not p['unchanged']];assert changed==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java']
oldAttachment=subprocess.check_output(['git','show',base+':'+changed[0]],cwd=r,text=True);newAttachment=(r/changed[0]).read_text();oldSummary=subprocess.check_output(['git','show',base+':'+changed[1]],cwd=r,text=True);newSummary=(r/changed[1]).read_text()
tail='    @Transactional\n    public ObjectNode upload';assert oldAttachment[oldAttachment.index(tail):]==newAttachment[newAttachment.index(tail):]
tailSummary='        // Unsaved supplemental copies';assert oldSummary[oldSummary.index(tailSummary):]==newSummary[newSummary.index(tailSummary):]
oldStart=oldSummary[:oldSummary.index('        ArrayNode attachmentSnapshot = attachments.snapshot(dhrId);',oldSummary.index('public ObjectNode submit'))];newStart=newSummary[:newSummary.index('        var submissionAttachments',newSummary.index('public ObjectNode submit'))];assert oldStart==newStart
def chain(s):
 lines=s.splitlines();start=next(i for i,l in enumerate(lines) if '.put("id", rs.getString("id"))' in l);end=next(i for i,l in enumerate(lines[start:],start) if '.put("linkedAt"' in l)
 return '\n'.join(l.strip() for l in lines[start:end+1]).replace(', dhrId);',';')
assert chain(oldAttachment)==chain(newAttachment)
write('reuse-protected-source-manifest.json',{'baseCommit':base,'files':protected,'changedProductPaths':changed,'attachmentUploadThroughFileDownloadVerifyUnlinkAndTailUnchanged':True,'summaryBeforeContextAndAfterOriginalVerificationUnchanged':True,'publicSnapshotPutChainExact':True})
write('reuse-main-validation.json',{'regression':json.loads((raw/'native-optimized/test-summary.json').read_text()),'negativeControl':json.loads((raw/'native-budget/test-summary.json').read_text()),'knowledge89ReusedReason':'350 knowledge and validation tools unchanged from initial passed run; independent final will rerun','observations':len(after),'businessSELECT':sum(e['selectStatements'] for e in after),'serverTypes':dict(types),'driverMetadataSelect':driver,'sourceScope':'actual base HEAD plus dirty product/test during main run; all source snapshots kept, not rewritten to later commit','old7704QualityScope':'test-only 69/89/16; historical only, does not cover this optimization'})
print(json.dumps({'events':len(after),'before':sum(e['selectStatements'] for e in before),'after':sum(e['selectStatements'] for e in after),'serverTypes':dict(types),'driverExtra':driver,'protectedFiles':len(protected),'changed':changed},indent=2))
