from pathlib import Path
import hashlib,json,subprocess,datetime,yaml,shutil,re
root=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-summary-attachment-ontology-20261105');out.mkdir(exist_ok=True)
base='a429f983a7a69553753034e9306d12598fcc15be'
dp='docs/development/branch-review-20261105-dhr-summary-attachments/decision-package.yaml'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def digest(b):return hashlib.sha256(b).hexdigest()
def write(name,obj): (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD')==base
required=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml',
 'docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/evidence/dhr-summary-user-confirmed.md',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrInstanceService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentQueryObservationPostgresTest.java',dp]
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java'
test_present=(root/test).is_file()
if test_present:required.append(test)
snapshots=[]
for path in required:
 p=root/path; data=p.read_bytes();s=out/'snapshot'/path;s.parent.mkdir(parents=True,exist_ok=True);s.write_bytes(data)
 try:b=subprocess.check_output(['git','show',base+':'+path],cwd=root,stderr=subprocess.DEVNULL);same=b==data
 except subprocess.CalledProcessError:same=None
 snapshots.append({'path':path,'bytes':len(data),'sha256':digest(data),'sameAsBase':same})
write('source-snapshot-manifest.json',snapshots)
knowledge=[]
for path in git('ls-tree','-r','--name-only',base,'docs/knowledge').splitlines():
 b=(root/path).read_bytes();ref=subprocess.check_output(['git','show',base+':'+path],cwd=root);assert b==ref,path
 knowledge.append({'path':path,'bytes':len(b),'sha256':digest(b)})
assert len(knowledge)==350
write('knowledge-fingerprint-inventory.json',{'scope':'byte inventory only, not semantic completion','count':len(knowledge),'files':knowledge})
package=yaml.safe_load((root/dp).read_text())['decisionPackage']
for f in ['confirmed','inferred','unresolved','replacementScopes','impactAnalysis','extensionStrategy','affectedFiles','acceptanceScenarios']:assert f in package
assert package['impactAnalysis']['level']=='L2' and package['unresolved']==[]
assert all(package['contractBaseline'][f]==base for f in ['sourceCommit','targetCommit','contractReadCommit'])
assert package['confirmed']=={'concepts':[],'relationships':[],'rules':[],'executionContracts':[]}
definitions={}
def walk(node,path,locator='',inherited=None):
 if isinstance(node,dict):
  maturity={'status':node.get('status',(inherited or {}).get('status')),'visibility':node.get('visibility',(inherited or {}).get('visibility'))}
  if 'id' in node:definitions[node['id']]={'object':node,'sourcePath':path,'sourceLocator':locator,'maturity':maturity}
  for k,v in node.items():walk(v,path,locator+'.'+k if locator else k,maturity)
 elif isinstance(node,list):
  for i,v in enumerate(node):walk(v,path,locator+'['+str(i)+']',inherited)
for p in ['docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml']:
 walk(yaml.safe_load((root/p).read_text()),p)
summary='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java'
attachment='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java'
integrity='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java'
instance='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrInstanceService.java'
scopes={
'rule.dhr-summary-only-after-production-complete':('saveDraft/submit call production-object lock then lockedCompletedDhr, disallow non-COMPLETED or already frozen edits; read visibility is a separate scope.',[summary+':185-198',summary+':410-438']),
'rule.dhr-summary-freeze-version':('Submit rechecks candidate+active attachment scopeHash against saved draft, builds one frozen version including attachments/checkResult and independent evidence rows; verify reconstructs entire digest. No change to creation/START policy.',[summary+':232-350',integrity+':25-93']),
'rule.dhr-summary-manual-review-confirmation':('Three confirmations and note length 1..500 block before freeze, persist confirmedBy/confirmedAt/note and automaticQualityConclusion=false; not automated arbitrary clinical/quality judgement.',[summary+':274-306']),
'rule.dhr-summary-auto-evidence-scope':('Real detail collects actual object source records across directory/work/custom, snapshot collects only current default-tenant DHR active attachment links ordered linked_at,id. Placement does not select evidence membership.',[instance+':244-325',attachment+':49-70',summary+':439-445']),
'rule.dhr-summary-controlled-attachment-upload':('Only format/capacity/original-byte and unlink-preservation source subrange: upload max 52428800 inclusive, existing seven formats; file streams complete SHA and unlink only toggles association. Not seven-format runtime or gateway certification.',[attachment+':39-41',attachment+':72-139',attachment+':158-177',attachment+':207-225',attachment+':269-282']),
'DEC-0063-02':('Object-bound actual-instance and controlled-attachment membership; no fourth form source or invented empty-source records, current candidates collects all three source arrays.',[instance+':244-325',summary+':439-445',attachment+':55-70']),
'DEC-0063-05':('Fresh saved scope compared before original verification, frozen candidate/attachment/check/placement/binding produced together; read-side digest checks independently stored source and version fields.',[summary+':243-350',integrity+':25-93']),
'DEC-0063-10':('Existing attachment service ownership, seven allowed original formats and inclusive 50MiB; VERIFIED status plus full SHA before summary submit, readonly frozen state forbids ordinary unlink, historical bytes retained. UI entrance/gateway not revalidated.',[attachment+':39-41',attachment+':72-177',attachment+':213-225',summary+':246-253']),
'DEC-0063-12':('Domain audit subrange only: actual save draft/submit use DHR summary audits; unlink writes attachment event. Not full instance-log UI/approval/export dual-layer matrix.',[summary+':228',summary+':348-350',attachment+':159-168',attachment+':288-301']),
'DEC-0063-14':('Manual actor/time/note confirmation frozen; preserves objective completeness, pending application, VERIFIED and SHA guards instead of replacing them with human checkbox.',[summary+':234-306']),
'DEC-0090-01':('Terminology boundary: successful summary version freeze or export copy is not controlled DHR archival lifecycle; this batch creates no archived state/action.',['docs/architecture/business-knowledge-model.md:164-166',summary+':282-350']),
'DEC-0090-02':('Only preserves declared scope separation: NONE FORMALIZED summary is not final product release or actual archival execution; archival access/save/backup delivery remains future work.',['docs/architecture/business-knowledge-model.md:166',summary+':282-350']),
}
records=[]
for id,(scope,refs) in scopes.items():
 d=definitions[id];lines=(root/d['sourcePath']).read_text().splitlines();line=next(i+1 for i,s in enumerate(lines) if re.search(r'\bid:\s*'+re.escape(id)+r'\s*$',s))
 records.append({'id':id,'recordType':'rule' if id.startswith('rule.') else 'decision-statement','sourcePath':d['sourcePath'],'sourceLocator':d['sourceLocator'],'sourceLine':line,
   'originalStatus':d['maturity']['status'],'originalVisibility':d['maturity']['visibility'],'auditScopeClassification':'current-effective/explicit-limited-subscope','semanticReviewStatus':'reviewed','conclusion':'consistent','scope':scope,
   'crosscheckedDecisions':['DEC-0063-02','DEC-0063-05','DEC-0063-10','DEC-0063-14','DEC-0090-01','DEC-0090-02'],'originalEvidenceReferences':refs,
   'runtimeValidation':'not-executed-by-this-role; main and new independent verifier own actual execution','maturityChange':'none'})
gaps={
'scenario.dhr-summary-freezes-complete-evidence':'Full scenario includes three origins/mixed statuses, same-template multiple instances, reorder/save/reopen interactions and immutable historical versions. Planned native attachment/one-source success does not cover complete UI and source matrix; no runtime executed by ontology role.',
'scenario.dhr-summary-attachment-export-and-audit':'Full scenario includes seven uploads/verifications/downloads, size edge+1 rejection, Office and FULL/SELECTED ZIP original bytes, UI selection/version switch and task/HTTP permissions+dual audits. Planned preexisting file SHA and successful submit does not certify whole scenario.'}
for id,gap in gaps.items():
 d=definitions[id];lines=(root/d['sourcePath']).read_text().splitlines();line=next(i+1 for i,s in enumerate(lines) if re.search(r'\bid:\s*'+re.escape(id)+r'\s*$',s))
 records.append({'id':id,'recordType':'acceptance-scenario','sourcePath':d['sourcePath'],'sourceLocator':d['sourceLocator'],'sourceLine':line,'originalStatus':d['maturity']['status'],'originalVisibility':d['maturity']['visibility'],
  'auditScopeClassification':'full-existing-acceptance-scenario/evidence-limit','semanticReviewStatus':'reviewed','conclusion':'evidence-gap','scope':gap,'originalEvidenceReferences':[d['sourcePath']+':'+str(line),dp],
  'runtimeValidation':'not-executed-by-this-role; planned tests are not completion evidence','maturityChange':'none'})
records.append({'id':'docs/knowledge/evidence/dhr-summary-user-confirmed.md','recordType':'markdown-evidence','sourcePath':'docs/knowledge/evidence/dhr-summary-user-confirmed.md','sourceLocator':'Office bytes/capacity and user-confirmed source/freeze/confirmation paragraphs','sourceLine':50,'originalStatus':None,'originalVisibility':None,'auditScopeClassification':'supporting-original-confirmation/limited-paragraphs','semanticReviewStatus':'reviewed','conclusion':'consistent',
 'scope':'Read user-confirmed 50MiB inclusive/original SHA+unlink preservation and full scope/manual review paragraphs; historic 25MiB/filename/migration/test notes retain their times, not current implementation truth.',
 'crosscheckedDecisions':['DEC-0063-05','DEC-0063-10','DEC-0063-14'],'originalEvidenceReferences':['docs/knowledge/evidence/dhr-summary-user-confirmed.md:50-64','docs/knowledge/evidence/dhr-summary-user-confirmed.md:114-122',attachment+':39-41',summary+':243-306'],'runtimeValidation':'none','maturityChange':'none'})
assert len(records)==15
(out/'finite-audit-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
counts={x:sum(r['conclusion']==x for r in records) for x in ['consistent','evidence-gap']}
write('finite-audit-summary.json',{'scope':'15 finite records: 14 existing IDs + 1 Markdown; only explicitly declared subscopes','records':len(records),'semanticReviewed':len(records),'conclusions':counts,'knowledgeInventoryFiles':350,'knowledgeInventoryMeaning':'byte inventory, not semantic audit of 350 files','runtimeExecutedByRole':False,'schemaMaturityPreserved':True,'notClosed':['931 knowledge candidate queue','86 UI diagnostics','all prior W2-W7, original DHR high/A12/runtime matrices','PDF cumulative memory','friend-owned signature/password task and production modal styling pause']})
baseline={'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]}
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':baseline,
 'reason':'Only native audit tests/development records planned; no confirmed semantic/policy replacement or source mutation. Current source/definitions agree in declared finite subscopes. Performance metadata reuse remains unapproved and unimplemented; full scenarios retain evidence gaps.',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[{'id':'validation.summary-attachment-package-and-result','checkType':'schema','command':'python /tmp/build-summary-attachment-ontology.py; local strict result/decision package invariant checks','outcome':'passed','evidence':['validation-result.log','finite-audit-summary.json']},
 {'id':'validation.summary-attachment-existing-records','checkType':'reference','command':'Resolve selected IDs in actual current YAML and source paths/line anchors; no new formal rule IDs','outcome':'passed','evidence':['finite-audit-records.jsonl','source-snapshot-manifest.json']},
 {'id':'validation.summary-attachment-baseline','checkType':'evidence-path','command':'git baseline/source snapshots and 350 current knowledge byte fingerprints','outcome':'passed','evidence':['baseline.json','knowledge-fingerprint-inventory.json','source-snapshot-manifest.json']}],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(out/'ontologyResult.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
write('baseline.json',{'contractBaseline':baseline,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','roadmap':'P0 in-progress','role':'bounded ontology source review; no repository modifications/runtime resources','newNativeTestExistsAtSnapshot':test_present,'testScopeStatus':'planned test absent at snapshot; parent final verifier must verify actual implementation' if not test_present else 'source captured; role will inspect its declared boundaries separately','workingTreePathsFromParent':git('status','--porcelain').splitlines(),'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
for r in records:
 assert (root/r['sourcePath']).is_file()
 for ref in r['originalEvidenceReferences']:
  p=ref.split(':')[0];assert (root/p).is_file(),ref
assert result['ontologyResult']['changedArtifacts']==[] and not result['ontologyResult']['conflicts']
(out/'validation-result.log').write_text('PASS strict ontologyResult required fields; allowed enums, empty change/question/conflict lists, P0 preserved\nPASS decision package L2 fields and exact a429f983 baseline\nPASS 15 actual finite records: 13 explicit-subscope consistent, 2 complete-scenario evidence-gap\nPASS 350 knowledge files match Git baseline; no runtime tests claimed\n')
print(json.dumps({'records':len(records),'conclusions':counts,'knowledgeFiles':len(knowledge),'newTestPresent':test_present},ensure_ascii=False))
