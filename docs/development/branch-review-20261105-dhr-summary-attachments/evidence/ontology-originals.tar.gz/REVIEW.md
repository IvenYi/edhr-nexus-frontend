# 汇总附件提交读取有限本体核对

`ontologyResult.result: not-applicable`。实际来源、目标及契约读取提交为`a429f983a7a69553753034e9306d12598fcc15be`；角色独立fetch仍同a429f983，契约及350份知识原字节不变。知识保持0.3.25/schema1.2.0/P0 in-progress。角色未修改仓库，未执行Maven、PG、JFR、浏览器、HTTP或业务测试，未创建运行资源或子实例。

实际读取当前角色/交接契约、决策包，架构及README的当前DHR、成熟度/投影与审计边界段落，open-questions当前保留事项，选定DHR规则及DEC0063/0090声明、用户原确认，以及当前Summary/Attachment/FrozenIntegrity/Instance/Impact源码。快照保存完整文件原件，但不把完整文件保存等同于整文件语义审查。新增原生测试在初始快照时尚未创建，后续已读取并捕获主审开发中的实际测试源码：除FormProjectionWorker外依赖真实，当前NONE模式、一个来源记录、0/1/10/100/300附件及50MiB原件、六拒绝边界、成功/回滚父锁双轴和混合索引计划。详见test-scope-observation.json。其编译/运行结论由主审和收尾质量实例另行验证，本角色不把源码断言当运行通过；后续测试变化按实际增量核对。

本批15条有限记录：14个既有ID及1份Markdown支撑文档，13条在明确子范围内一致、2条完整场景为evidence-gap。原status/visibility保留，scenario字段从父决策继承的specified/internal已在清单明确，不由源码或本体核对提升成熟度。350文件指纹只是字节盘点；15不与前批20或delta相加计historical unique。

关键核对：

- 普通saveDraft/submit在生产对象锁后锁DHR，要求COMPLETED及未冻结状态；detail证据可见性与编辑资格不同。实际三类来源集合与active附件集合各自按当前生产对象/DHR读取，附件不是第四种表单实例来源。
- snapshot仅收default租户、当前DHR、active附件，保持linked_at,id顺序；submit按candidate+attachment scopeHash拒绝陈旧草稿，每项要求VERIFIED并实际file完整SHA检查。snapshot已读元数据与逐项file重复读取是工程复用候选，不能据此省掉SHA、核验状态或来源集合检查，也不能把stored_path塞进公共响应。
- 人工三确认及1..500字说明与客观检查并存，checkResult保留确认人/时间/说明且不声称自动判读任意质量结论。附件元数据/证据/展示位置/检查/审批绑定同版冻结，FrozenIntegrity还重建全部版本摘要；旧scope或缺原件不得静默跳过。
- 来源受控附件允许PDF/PNG/JPEG/DOC/DOCX/XLS/XLSX、单原件52428800字节含边界；上传/核验/内容解析、HTTP网关、下载与冻结ZIP均有各自验收范围。新计划单个已存在50MiB原件读SHA不能等同完整上传含边界/超1字节与七格式矩阵。
- 正常unlink先锁DHR，带原因且不删除历史原件。并发真实submit成功并进入NONE/FORMALIZED之后，等待的unlink须重新读该状态并拒绝；原guard前缀回滚之后unlink可以成功。不能将旧rollback用例的后置成功期望照搬到新成功提交场景。
- DEC0090定义的DHR归档是最终放行后的受控保存；saveDraft、submit/NONE定稿和ZIP副本均不等于产品放行或归档，本轮不创建ARCHIVED动作或归档运行事实。

两个完整场景gap是`scenario.dhr-summary-freezes-complete-evidence`和`scenario.dhr-summary-attachment-export-and-audit`。前者含三类混合状态来源、同模板多实例、目录交互/重开/无重复及全历史边界；后者含七格式、50MiB含边界与超1字节、Office及完整/选定ZIP原字节、UI切版、任务/HTTP权限和双层审计。新的有限读取/提交测试即使成功，也不能自动关闭完整场景。上轮printable archive完整布局gap和其它旧队列同样不由本批关闭。

原931知识候选、86UI、W2余项/W3-W5交叉、W6健壮性/性能/抽取/A23含旧已审复查、W7增量、原DHR high/A12/完整运行矩阵、PDF累计内存和朋友任务签名密码页/生产管理弹窗暂停全部保持。不增加规范或工程政策，不预先批准批读、分块、索引或大模块重构；后续若产品修复范围改变，主审应按实际增量重核本结果，不把本次NA覆盖新政策。
