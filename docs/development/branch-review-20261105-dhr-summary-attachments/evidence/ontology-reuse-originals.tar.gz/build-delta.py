from pathlib import Path
import json,hashlib,subprocess,yaml,datetime,shutil
r=Path('/workspace/edhr-nexus-frontend');o=Path('/tmp/edhr-summary-attachments-reuse-ontology-20261105');o.mkdir(exist_ok=True)
prior=Path('/tmp/edhr-summary-attachment-ontology-20261105');target='a429f983a7a69553753034e9306d12598fcc15be';head='7704f11267a810b2bda82e99f049a0206a5e73c7'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,x):(o/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','HEAD')==head and git('rev-parse','FETCH_HEAD')==target
assert sha((prior/'manifest.json').read_bytes())=='36815fca094473ef7bb0b2cb2085fc11e87dde816e823c1f62c61f9d66dfcda2'
pm=json.loads((prior/'manifest.json').read_text())
for e in pm['files']:assert sha((prior/e['path']).read_bytes())==e['sha256']
assert git('diff',target,'HEAD','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge')==''
assert git('diff','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge')==''
dp='docs/development/branch-review-20261105-dhr-summary-attachments/decision-package.yaml'
package=yaml.safe_load((r/dp).read_text())['decisionPackage'];assert package['engineeringDecisions'][0]['status']=='user-confirmed'
assert '先做提交内元数据复用' in package['engineeringDecisions'][0]['source'] and package['replacementScopes']==[] and package['unresolved']==[]
required=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml',
 'docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/evidence/dhr-summary-user-confirmed.md',dp,
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrInstanceService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryPersistenceTest.java']
snap=[]
for p in required:
 b=(r/p).read_bytes();s=o/'snapshot'/p;s.parent.mkdir(parents=True,exist_ok=True);s.write_bytes(b)
 ref=subprocess.check_output(['git','show',head+':'+p],cwd=r);snap.append({'path':p,'bytes':len(b),'sha256':sha(b),'sourceHeadSha256':sha(ref),'sameAsSourceHead':b==ref})
write('source-snapshot-manifest.json',snap)
contract=[p for p in required if p=='AGENTS.md' or p=='codeplzreadme.md' or p.startswith('docs/agents/')]
assert all(e['sameAsSourceHead'] for e in snap if e['path'] in contract)
knowledge=[]
for p in git('ls-tree','-r','--name-only',head,'docs/knowledge').splitlines():
 b=(r/p).read_bytes();ref=subprocess.check_output(['git','show',head+':'+p],cwd=r);assert b==ref
 knowledge.append({'path':p,'bytes':len(b),'sha256':sha(b)})
assert len(knowledge)==350;write('knowledge-fingerprint-inventory.json',{'scope':'byte inventory only','count':350,'files':knowledge})
attachment='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java'
summary='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java'
old=subprocess.check_output(['git','show',head+':'+attachment],cwd=r,text=True);now=(r/attachment).read_text();start='    @Transactional\n    public ObjectNode upload('
assert old[old.index(start):]==now[now.index(start):]
oldsql="SELECT * FROM dhr_attachment WHERE tenant_id='default' AND dhr_instance_id=? AND active=TRUE ORDER BY linked_at,id"
assert oldsql in old and oldsql in now
oldrow=old[old.index('.put("id", rs.getString("id"))'):old.index('.put("linkedAt", rs.getTimestamp("linked_at").toLocalDateTime().toString())')+len('.put("linkedAt", rs.getTimestamp("linked_at").toLocalDateTime().toString())')]
newrow=now[now.index('.put("id", rs.getString("id"))'):now.index('.put("linkedAt", rs.getTimestamp("linked_at").toLocalDateTime().toString())')+len('.put("linkedAt", rs.getTimestamp("linked_at").toLocalDateTime().toString())')]
assert oldrow==newrow
current=(r/summary).read_text();before=subprocess.check_output(['git','show',head+':'+summary],cwd=r,text=True)
tail='        // Unsaved supplemental copies have no form_instance_record yet, but are still unfinished evidence.'
assert current[current.index(tail):]==before[before.index(tail):]
prefix='        ArrayNode candidateSnapshot = candidates(detail);'
assert current[:current.index(prefix)+len(prefix)]==before[:before.index(prefix)+len(prefix)]
write('protected-reader-checks.json',{'attachmentUploadThroughEndUnchanged':True,'attachmentActiveSqlUnchanged':True,'publicSnapshotRowExpressionUnchanged':True,'summaryBeforeAttachmentReadUnchanged':True,'summaryAfterAttachmentValidationUnchanged':True,
 'effect':'Only already-parent-locked submit uses package-local metadata context; full file verification uses original unchanged private verifiedFile and public file/download/unlink tail remains unchanged.'})
(o/'product-working-tree.patch').write_text(subprocess.check_output(['git','diff','--',attachment,summary],cwd=r,text=True))
(o/'test-working-tree.patch').write_text(subprocess.check_output(['git','diff','--','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryPersistenceTest.java'],cwd=r,text=True))
oldrecords=[json.loads(x) for x in (prior/'finite-audit-records.jsonl').read_text().splitlines()]
byid={x['id']:x for x in oldrecords}
recheck=['rule.dhr-summary-freeze-version','rule.dhr-summary-manual-review-confirmation','rule.dhr-summary-auto-evidence-scope','rule.dhr-summary-controlled-attachment-upload','DEC-0063-05','DEC-0063-10']
records=[]
for id in recheck:
 a=byid[id]
 records.append({'id':id,'recordType':a['recordType'],'sourcePath':a['sourcePath'],'sourceLocator':a['sourceLocator'],'originalStatus':a['originalStatus'],'originalVisibility':a['originalVisibility'],
  'auditScopeClassification':'current-effective/explicit-existing-subset-delta','semanticReviewStatus':'reviewed','conclusion':'consistent',
  'scope':'Only approved internal metadata reuse after existing parent lock. Same ACTIVE SQL and public row expression; one-call private stored_path/SHA list follows same order. ScopeHash remains before VERIFIED/full-SHA validation; all later confirmation/freeze/audit code and public file/download/unlink tail unchanged. No policy, authorization or archival lifecycle change.',
  'originalEvidenceReferences':[dp,attachment+':40-102',summary+':232-251','protected-reader-checks.json','product-working-tree.patch'],'runtimeValidation':'not-executed-by-this-role; main/negative-control figures are reported input, final quality must run actual candidate','maturityChange':'none'})
for id in ['scenario.dhr-summary-freezes-complete-evidence','scenario.dhr-summary-attachment-export-and-audit']:
 a=dict(byid[id]);a['auditScopeClassification']='existing-whole-scenario-gap-retained-after-engineering-delta';a['scope']+=' Current native test remains NONE/one WORK source and existing PNG originals, plus scope exclusions and ordered-error assertions; no full scenario runtime by ontology role.';records.append(a)
(o/'delta-audit-records.jsonl').write_text(''.join(json.dumps(a,ensure_ascii=False)+'\n' for a in records))
dispositions=[{'id':a['id'],'recordType':a['recordType'],'originalConclusion':a['conclusion'],'disposition':'retained','recheckedInDelta':a['id'] in recheck or a['recordType']=='acceptance-scenario','preservedScope':a['scope'],'reason':'No knowledge or policy changes; only six declared IDs rechecked for implementation equivalence; whole scenario gaps and original supporting contexts remain.'} for a in oldrecords]
(o/'original15-dispositions.jsonl').write_text(''.join(json.dumps(a,ensure_ascii=False)+'\n' for a in dispositions))
write('delta-summary.json',{'deltaRecords':8,'consistentRecheckedExistingIDs':6,'retainedFullScenarioGaps':2,'originalFiniteRecords':15,'originalDispositions':len(dispositions),'newSemanticCoverageUniqueIDs':0,'maturityChanges':0,'knowledgeByteInventory':350,'runtimeExecutedByRole':False,'previousRawManifestSha256':sha((prior/'manifest.json').read_bytes()),'allOriginalQueuesRetained':['931 knowledge candidates','86 UI diagnostics','W2 remainder/W3-W5/W6 robustness-performance-extraction-A23 including past-reviewed code/W7 increments','original DHR high/A12/full runtime matrices/printable archive gap/PDF cumulative capacity','friend task-signature and production modal style pauses']})
baseline={'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':head,'uncommittedContractPaths':[]}
write('baseline.json',{'contractBaseline':baseline,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','roadmap':'P0 in-progress','includedWorkingTreeChanges':git('status','--porcelain').splitlines(),'actualCodeEvidence':'current dirty working-tree source snapshots and exact patches; no invented commit for implementation','roleResources':{'repositoryEdits':False,'runtimeTests':False,'spawnedChildren':False,'cleanupRequired':False},'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
q={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':baseline,
 'reason':'User approved local submission metadata reuse, an engineering change preserving existing business definitions. Six already-scoped IDs rechecked: same default tenant/DHR/active membership, public snapshot/order, scopeHash-before-validation, VERIFIED-before-complete-SHA and locked transaction/freeze/audit; two whole scenarios retain evidence gaps. No ontology policy, knowledge IDs or maturity changes required.',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[{'id':'validation.summary-reuse-result','checkType':'schema','command':'python /tmp/build-summary-attachments-reuse-ontology.py plus strict result-field checks','outcome':'passed','evidence':['validation-result.log','delta-summary.json']},
 {'id':'validation.summary-reuse-definition-and-source','checkType':'reference','command':'Read actual current same-DP/source diff/tests and retain original 15 actual knowledge records; exact protected row/SQL/tail checks','outcome':'passed','evidence':['delta-audit-records.jsonl','original15-dispositions.jsonl','protected-reader-checks.json']},
 {'id':'validation.summary-reuse-baseline','checkType':'evidence-path','command':'actual source/target contract equality, 350 current knowledge fingerprints and original FINAL manifest verification','outcome':'passed','evidence':['baseline.json','source-snapshot-manifest.json','knowledge-fingerprint-inventory.json','prior-final/manifest.json']}],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(o/'ontologyResult.yaml').write_text(yaml.safe_dump(q,allow_unicode=True,sort_keys=False))
for n in ['ontologyResult.yaml','finite-audit-summary.json','manifest.json','manifest.sha256']:
 p=o/'prior-final'/n;p.parent.mkdir(exist_ok=True);shutil.copyfile(prior/n,p)
(o/'validation-result.log').write_text('PASS same-DP explicit engineering approval and unchanged business-policy lists\nPASS actual 7704 source/contract and a429 target, no contract/knowledge delta\nPASS 350 knowledge fingerprints; prior FINAL original manifest and all 30 listed files preserved\nPASS public row expression, ACTIVE SQL, upload-through-end, summary prefix/tail exact protected bytes\nPASS six existing ID rechecks + two preserved whole-scenario gaps; 15 original dispositions kept\nNo Maven/PG/JFR/HTTP/browser/business test executed by this role\n')
print(json.dumps({'result':q['ontologyResult']['result'],'deltaRecords':len(records),'originalRecordsPreserved':len(dispositions),'snapshots':len(snap),'knowledgeFiles':len(knowledge)},ensure_ascii=False))
