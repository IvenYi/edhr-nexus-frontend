from pathlib import Path
import json,hashlib,re,collections,subprocess,gzip,xml.etree.ElementTree as ET,shutil,datetime
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-summary-attachments-20261105');out=r/'docs/development/branch-review-20261105-dhr-summary-attachments';base='a429f983a7a69553753034e9306d12598fcc15be'
def write(name,obj): (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def norm(sql):return ' '.join(re.sub(r'\$\d+','?',sql).lower().split())
events=[]
for p in sorted((raw/'native-full2/observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:events.append(e)
assert len(events)==16
parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(raw/'native-full2/postgres.log').read_text(),flags=re.M)
server=collections.defaultdict(collections.Counter);alltagged=collections.defaultdict(collections.Counter)
for part in parts:
 m=re.search(r'edhr_dhr_summary_attachment_test_full2 (audit_summary_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if not m:continue
 sql=m.group(2).split('\n\tparameters:')[0].strip();sql=re.split(r'\n\d{4}-',sql)[0].strip();shape=norm(sql)
 alltagged[m.group(1)][shape]+=1
 if shape.startswith('select'):server[m.group(1)][shape]+=1
matches=[];types=collections.Counter()
for e in events:
 observed=collections.Counter(norm(s) for s in e['jdbcSql']+e['hibernateSql'] if norm(s).startswith('select'))
 actual=server[e['applicationName']];assert observed==actual,(e['name'],observed-actual,actual-observed)
 matches.append({'name':e['name'],'selectStatements':e['selectStatements'],'shapesMatch':True,'shapes':[{'sql':s,'count':n} for s,n in actual.items()]})
 for s,n in alltagged[e['applicationName']].items():types[s.split()[0]]+=n
write('server-sql-review.json',{'scope':'successful execute entries inside per-observation SET LOCAL application_name, matched by full normalized SELECT shape; parse/bind/transaction/SET and controls separate','events':matches,'taggedSuccessfulStatementTypes':dict(types),'measuredSELECT':sum(e['selectStatements'] for e in events),'hibernateNonSelect':sum(1 for e in events for s in e['hibernateSql'] if not norm(s).startswith('select')),'notes':['JDBC write commands not in query interception; server-tag write counts reported separately','outside-tag initialization/setup/saveDraft/frozen verification/assertions/EXPLAIN/runner SQL not called request totals','SET LOCAL uses fixed test names only; actual business services run through Spring proxies within real TransactionTemplate']})
plan=json.loads((raw/'native-full2/observations/existing-index-plans.json').read_text())
small=[{k:v for k,v in e.items() if k not in ['jdbcSql','hibernateSql']} for e in events]
write('performance-report.json',{'baseCommit':base,'events':small,'measuredSELECT':sum(e['selectStatements'] for e in events),'scaleFormulaScope':'13+2N only for declared one actual WORK record/NONE configuration, not a universal all-source/REQUIRED HTTP count','indexExperiment':plan,'decision':'metadata reuse proposal pending actual user reply, no product/index optimization implemented','limits':['warm-cache synthetic file bytes; JFR logical read bytes not physical IO','ThreadMXBean calling-thread cumulative allocation, not retained heap/peak/RSS or Chromium/concurrency capacity','heap snapshots global; concurrent lock cases include other threads, elapsed lock time intentionally blocked','50MiB submit fixture directly registered verified; not actual upload/verify/seven-format/50MiB acceptance','real successful saveDraft/submit plus separate frozen integrity; source and completed execution fixtures seeded via SQL, not START/generation/full production completion','NONE + one WORK source; not REQUIRED/full three-origin/signature/HTTP/RBAC matrix']})
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):shutil.copy2(p,raw/'knowledge'/p.name)
knowledge=[]
for p in (raw/'knowledge').glob('TEST-*.xml'):
 a=ET.parse(p).getroot().attrib;knowledge.append({'class':a['name'],**{k:int(a[k]) for k in ['tests','failures','errors','skipped']}})
write('main-validation.json',{'nativeAndAdjacent':json.loads((raw/'native-full2/test-summary.json').read_text()),'knowledge':knowledge,'observations':len(events),'observedSELECT':sum(e['selectStatements'] for e in events),'serverTypes':dict(types),'initialFailures':[{'phase':'focused','status':'compile failed, missing DynamicProperty imports; no JUnit execution','productDefect':False},{'phase':'full','tests':69,'failures':6,'errors':0,'skipped':0,'reason':'assert compared in-memory LongNode size to parsed JSON IntNode; exact serialized JSON strings identical, changed assertion to require exact serialized equality; full XML/source kept','productDefect':False}],'noProductEdits':True})
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines()
with gzip.open(out/'baseline-tracked-paths.txt.gz','wb') as f:f.write(('\n'.join(paths)+'\n').encode())
write('inventory-summary.json',{'baseCommit':base,'trackedPaths':len(paths),'knowledgePaths':sum(p.startswith('docs/knowledge/') for p in paths),'wholeFileCompletionThisBatch':0,'historicalUniqueCoverage':'unknown; not inferred from finite method/ID records','status':'baseline inventory only; no additional full-file semantic completion','pending':['W2 remainder, W3-W5 cross-cutting, W6 robustness/performance/concrete extraction/A23 incl prior code, W7 increments','931 knowledge candidates,86 UI, original DHR high/A12/full matrices/history/text-ID index/PDF and export capacity','friend task-password/signature and production dialog styling paused']})
protected=[]
for path in paths:
 if not (path.startswith('docs/knowledge/') or path.startswith('gmp-platform/backend/src/main/') or path.startswith('gmp-platform/frontend/') or path in ['AGENTS.md','codeplzreadme.md'] or path.startswith('docs/agents/')):continue
 p=r/path
 if not p.is_file():continue
 old=subprocess.check_output(['git','show',base+':'+path],cwd=r);assert old==p.read_bytes(),path
 protected.append({'path':path,'sha256':hashlib.sha256(old).hexdigest(),'unchanged':True})
write('protected-source-manifest.json',{'baseCommit':base,'files':protected,'allUnchanged':True})
print(json.dumps({'events':len(events),'requestSELECT':sum(e['selectStatements'] for e in events),'serverStatementTypes':dict(types),'baselinePaths':len(paths),'protected':len(protected)},indent=2))
