from pathlib import Path
import json,hashlib,tarfile,subprocess,re,collections,gzip,xml.etree.ElementTree as ET,concurrent.futures,yaml,datetime,shutil
root=Path('/tmp/edhr-summary-metadata-reuse-qa-worktree-20261105');doc=root/'docs/development/branch-review-20261105-dhr-summary-attachments';out=Path('/tmp/edhr-summary-metadata-reuse-quality-20261105/evidence-review');base='a429f983a7a69553753034e9306d12598fcc15be';head='48be11f44962b2dfe7390f7bb45b1ec833ac2bd3'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(n,v):(out/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
assert git('rev-parse','HEAD')==head
checks=[];findings=[];snapshots=[]
read_paths=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/architecture/business-knowledge-model.md']
read_paths+=['docs/development/branch-review-20261105-dhr-summary-attachments/'+s for s in ['decision-package.yaml','README.md','reuse-review-notes.md','ontology-result.yaml','ontology-initial-result.yaml','finite-audit-records.jsonl','delta-audit-records.jsonl','inventory-summary.json','reuse-negative-control.json','reuse-main-validation.json']]
read_paths+=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/'+s+'.java' for s in ['DhrAttachmentService','DhrSummaryService','DhrFrozenEvidenceIntegrity']]
read_paths+=['gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/'+s+'.java' for s in ['DhrSummaryAttachmentObservationPostgresTest','DhrSummaryPersistenceTest']]
for p in read_paths:
 b=(root/p).read_bytes();s=out/'snapshots'/p;s.parent.mkdir(parents=True,exist_ok=True);s.write_bytes(b);snapshots.append({'path':p,'bytes':len(b),'sha256':sha(b)})
checks.append({'id':'fixed-candidate-and-contracts','outcome':'passed','evidence':{'head':head,'base':base,'contractReadCommit':head,'snapshotFiles':len(snapshots)}})
archives=[];roots={};inner=[]
for manifest in ['archive-manifest.json','reuse-archive-manifest.json']:
 for a in json.loads((doc/'evidence'/manifest).read_text())['archives']:
  p=doc/'evidence'/a['archive'];assert p.stat().st_size==a['bytes'] and sha(p.read_bytes())==a['sha256'];dest=out/'unpacked'/a['archive'].removesuffix('.tar.gz');dest.mkdir(parents=True,exist_ok=True)
  with tarfile.open(p) as t:
   members={m.name:m for m in t if m.isfile()};assert len(members)==a['fileCount']==len(a['files'])
   for e in a['files']:
    rel=Path(e['path']);assert not rel.is_absolute() and '..' not in rel.parts
    b=t.extractfile(members[e['path']]).read();assert len(b)==e['bytes'] and sha(b)==e['sha256'];d=dest/rel;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
  roots[a['archive']]=dest;archives.append({k:a[k] for k in ['archive','fileCount','bytes','sha256']})
  for p in dest.rglob('manifest.json'):
   data=json.loads(p.read_text());entries=data.get('files',[]) if isinstance(data,dict) else [];verified=0;external=[]
   side=p.with_suffix('.sha256')
   if side.exists():assert side.read_text().split()[0]==sha(p.read_bytes())
   for e in entries:
    if not isinstance(e,dict) or 'path' not in e or 'sha256' not in e:continue
    x=p.parent/e['path']
    if not x.is_file():external.append(e['path']);continue
    assert sha(x.read_bytes())==e['sha256'],str(x)
    if 'bytes' in e:assert x.stat().st_size==e['bytes']
    verified+=1
   inner.append({'manifest':str(p.relative_to(out)),'verifiedLocalEntries':verified,'externalReferencesNotInvented':external})
assert len(archives)==6 and sum(a['fileCount'] for a in archives)==737
write('archive-review.json',{'archives':archives,'verifiedOriginalFiles':737,'innerManifestReview':inner})
checks.append({'id':'six-archives-and-inner-integrity','outcome':'passed','evidence':{'archives':6,'outerOriginals':737,'innerManifests':len(inner)}})
initial=roots['main-originals.tar.gz'];reuse=roots['main-reuse-originals.tar.gz']
phase_data={};event_lists={}
for phase,container in [('focused',initial),('full',initial),('full2',initial),('budget',reuse),('optimized',reuse)]:
 d=container/('native-'+phase);summary=json.loads((d/'test-summary.json').read_text());totals=collections.Counter()
 for p in d.glob('TEST-*.xml'):
  a=ET.parse(p).getroot().attrib
  for k in ['tests','failures','errors','skipped']:totals[k]+=int(a[k])
 if phase=='focused':assert summary['totals']['tests']==0 and summary['missingFreshReports'] and 'DynamicProperty' in (d/'maven.log').read_text()
 else:assert dict(totals)==summary['totals']
 if phase in ['full2','optimized']:assert totals['failures']==totals['errors']==totals['skipped']==0
 if phase=='full':assert dict(totals)=={'tests':69,'failures':6,'errors':0,'skipped':0}
 if phase=='budget':assert dict(totals)=={'tests':18,'failures':5,'errors':0,'skipped':0}
 events=[]
 for p in (d/'observations').glob('*.json'):
  e=json.loads(p.read_text())
  if 'applicationName' in e:events.append(e)
 event_lists[phase]=events
 phase_data[phase]={'totals':summary['totals'],'events':len(events),'measuredSELECT':sum(e['selectStatements'] for e in events),'cleanup':json.loads((d/'cleanup.json').read_text())}
 assert phase_data[phase]['cleanup']['removed']
assert phase_data['full2']['totals']['tests']==69 and phase_data['optimized']['totals']['tests']==72
assert len(event_lists['budget'])==len(event_lists['optimized'])==19
assert phase_data['budget']['measuredSELECT']==1035 and phase_data['optimized']['measuredSELECT']==195
fullxml=next((initial/'native-full').glob('TEST-*.DhrSummaryAttachmentObservationPostgresTest.xml'));equal_payloads=[]
for case in ET.parse(fullxml).getroot().findall('testcase'):
 f=case.find('failure')
 if f is None:continue
 m=f.attrib['message'];parts=re.search(r'expected: "(.*?) \(ArrayNode@.*?\)"\s+but was: "(.*?) \(ArrayNode@',m,re.S);assert parts and parts.group(1)==parts.group(2),case.attrib['name'];equal_payloads.append(case.attrib['name'])
assert len(equal_payloads)==6
native='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrSummaryAttachmentObservationPostgresTest.java'
native_sha=sha((root/native).read_bytes())
for phase in ['budget','optimized']:
 d=reuse/('native-'+phase);run=json.loads((d/'run.json').read_text());f=next(e for e in run['sourceFingerprints'] if e['path']==native);assert f['sha256']==native_sha
for p in ['DhrAttachmentService','DhrSummaryService']:
 rel='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/'+p+'.java';old=(reuse/'native-budget/source'/rel).read_bytes();assert old==subprocess.check_output(['git','show',base+':'+rel],cwd=root)
knowledge=next((initial/'knowledge').glob('TEST-*.xml'));ka=ET.parse(knowledge).getroot().attrib;assert {k:int(ka[k]) for k in ['tests','failures','errors','skipped']}=={'tests':89,'failures':0,'errors':0,'skipped':0}
write('xml-and-negative-review.json',{'phases':phase_data,'sixEqualSerializedFailurePayloads':equal_payloads,'nativeBudgetAndCandidateSameSha256':native_sha,'oldProductMatchesBase':True,'initialKnowledge89':True,'note':'focused compile/first full JSON-node assertion defects are preserved, not product defects or performance negative controls; fixed exact serialized JSON comparison retains all fields/order/values'})
checks.append({'id':'xml-failure-history-and-same-byte-negative','outcome':'passed','evidence':{'phaseData':phase_data,'negativeNativeSha256':native_sha,'initialKnowledge89':True}})
def norm(s):return ' '.join(re.sub(r'\$\d+','?',s).lower().split())
log=(reuse/'native-optimized/postgres.log').read_text();server=collections.defaultdict(collections.Counter);types=collections.Counter()
for part in re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',log,flags=re.M):
 m=re.search(r'edhr_dhr_summary_attachment_test_optimized (audit_summary_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if m:server[m.group(1)][norm(m.group(2))]+=1
for e in event_lists['optimized']:
 expected=collections.Counter(norm(s) for s in e['jdbcSql']+e['hibernateSql'] if norm(s).startswith('select'));actual=collections.Counter({s:n for s,n in server[e['applicationName']].items() if s.startswith('select')});assert expected==actual,e['name']
 for s,n in server[e['applicationName']].items():types[s.split()[0]]+=n
assert dict(types)=={'set':19,'select':195,'insert':25,'delete':8,'update':17},types
write('main-server-review.json',{'events':19,'businessSELECT':195,'taggedTypes':dict(types),'shapesExactlyMatched':True,'limit':'main raw source, not this child independently running PG; tag-out setup/frozen/assert/plan/runner and protocol metadata remain separate'})
checks.append({'id':'main-tagged-sql-and-allocation-math','outcome':'passed','evidence':{'businessSELECT':195,'writes':50,'SET':19,'oldSELECT':1035}})
def inspect_jfr(item):
 phase,e=item;p=reuse/('native-'+phase)/'observations'/(e['name']+'.jfr');data=json.loads(subprocess.check_output(['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(p)],text=True));events=data['recording']['events'];matched=[]
 for x in events:
  v=x['values'];path=v.get('path') or '';thread=v.get('eventThread') or {}
  if thread.get('javaThreadId')==e['measuredThreadId'] and re.search(r'/junit[^/]*/original-\d+\.png$',path):matched.append(v)
 total=sum(v['bytesRead'] for v in matched);assert total==e['trackedLogicalReadBytes'],(phase,e['name'],total,e['trackedLogicalReadBytes'])
 assert len(matched)==e['trackedReadEvents'],(phase,e['name'],len(matched),e['trackedReadEvents'])
 return {'phase':phase,'name':e['name'],'threadId':e['measuredThreadId'],'logicalReadBytes':total,'readEvents':len(matched),'paths':sorted(set(v['path'] for v in matched))}
items=[(phase,e) for phase in ['budget','optimized'] for e in event_lists[phase]]
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:jfr=list(pool.map(inspect_jfr,items))
write('main-jfr-review.json',{'recordingsParsed':len(jfr),'records':jfr,'filter':'actual event Java thread ID and /tmp/junit*/original-*.png paths; no cross-thread concurrent attribution','limits':'only parses recorded originals; physical IO, peak heap/RSS and production capacity not certified'})
checks.append({'id':'thirty-eight-main-jfr-recordings','outcome':'passed','evidence':{'parsed':len(jfr),'beforeAndAfterLogicalBytesMatch':True}})
protect=json.loads((doc/'reuse-protected-source-manifest.json').read_text());changed=[]
for e in protect['files']:
 b=(root/e['path']).read_bytes();assert sha(b)==e['candidateSha256'];old=subprocess.check_output(['git','show',base+':'+e['path']],cwd=root);assert sha(old)==e['baselineSha256']
 if old!=b:changed.append(e['path'])
assert len(protect['files'])==1122 and len(changed)==2
att='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java';summ='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java';oa=subprocess.check_output(['git','show',base+':'+att],cwd=root,text=True);na=(root/att).read_text();os=subprocess.check_output(['git','show',base+':'+summ],cwd=root,text=True);ns=(root/summ).read_text()
mark='    @Transactional\n    public ObjectNode upload';assert oa[oa.index(mark):]==na[na.index(mark):]
mark='        // Unsaved supplemental copies';assert os[os.index(mark):]==ns[ns.index(mark):]
assert os[:os.index('        ArrayNode attachmentSnapshot = attachments.snapshot(dhrId);',os.index('public ObjectNode submit'))]==ns[:ns.index('        var submissionAttachments',ns.index('public ObjectNode submit'))]
def chain(s):
 lines=s.splitlines();i=next(i for i,l in enumerate(lines) if '.put("id", rs.getString("id"))' in l);j=next(j for j,l in enumerate(lines[i:],i) if '.put("linkedAt"' in l);return '\n'.join(l.strip() for l in lines[i:j+1]).replace(', dhrId);',';')
assert chain(oa)==chain(na)
baseline_paths=git('ls-tree','-r','--name-only',base).splitlines();assert len(baseline_paths)==7591 and len([p for p in baseline_paths if p.startswith('docs/knowledge/')])==350
listed=gzip.decompress((doc/'baseline-tracked-paths.txt.gz').read_bytes()).decode().splitlines();assert listed==baseline_paths
write('protected-and-inventory-review.json',{'protectedFiles':1122,'changedProducts':changed,'attachmentTailUnchanged':True,'summaryPrefixAndTailUnchanged':True,'publicPutChainUnchanged':True,'baselinePaths':7591,'knowledgeFiles':350,'wholeFileCompletion':0,'historicalUnique':'unknown'})
checks.append({'id':'protected-regions-and-baseline-inventory','outcome':'passed','evidence':{'protected':1122,'changedProducts':changed,'basePaths':7591,'knowledgePaths':350}})
original=[json.loads(x) for x in (doc/'finite-audit-records.jsonl').read_text().splitlines()];delta=[json.loads(x) for x in (doc/'delta-audit-records.jsonl').read_text().splitlines()];assert len(original)==15 and collections.Counter(e['conclusion'] for e in original)=={'consistent':13,'evidence-gap':2};assert len(delta)==8 and collections.Counter(e['conclusion'] for e in delta)=={'consistent':6,'evidence-gap':2};assert set(e['id'] for e in delta)<=set(e['id'] for e in original)
for p in ['ontology-initial-result.yaml','ontology-result.yaml']:
 z=yaml.safe_load((doc/p).read_text())['ontologyResult'];assert z['result']=='not-applicable' and z['baselineBefore']==z['baselineAfter']=='0.3.25' and z['roadmapProgress']=={'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
for p in [x for x in baseline_paths if x.startswith('docs/knowledge/')]:assert subprocess.check_output(['git','show',base+':'+p],cwd=root)==(root/p).read_bytes()
for p in [doc/'README.md',doc/'reuse-review-notes.md']:
 text=p.read_text();assert '7704' in text and '72' in text and '931' in text and '86' in text and ('不覆盖' in text or '必须再取' in text)
checks.append({'id':'finite-ontology-history-and-honest-scope','outcome':'passed','evidence':{'original':15,'consistent':13,'gaps':2,'deltaSubset':8,'uniqueIncrease':0,'knowledge350Unchanged':True,'7704OnlyHistorical':True}})
write('source-snapshots.json',{'head':head,'files':snapshots})
write('result.json',{'result':'passed','kind':'read-only-evidence-subcheck-not-final-quality','baseCommit':base,'headCommit':head,'contractReadCommit':head,'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':findings,'residualRisks':[{'id':'limit.no-business-runtime-in-child','description':'This child parsed original XML/PG/JFR and fixed Git bytes only; parent owns independent fresh runtime/quality. No production capacity/full HTTP or broad semantic coverage claimed.'}],'resources':{'repositoryEdits':False,'mavenOrPgStarted':False,'cleanupRequired':False},'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'result':'passed','checks':len(checks),'archives':6,'originals':737,'mainJfr':len(jfr),'protected':1122},indent=2))
