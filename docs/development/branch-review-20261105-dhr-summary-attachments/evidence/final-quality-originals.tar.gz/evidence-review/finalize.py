from pathlib import Path
import json,hashlib,datetime,shutil
out=Path('/tmp/edhr-summary-metadata-reuse-quality-20261105/evidence-review');root=Path('/tmp/edhr-summary-metadata-reuse-qa-worktree-20261105');d=root/'docs/development/branch-review-20261105-dhr-summary-attachments'
p=out/'unpacked/main-reuse-originals/native-optimized/observations/existing-index-plans.json';plan=json.loads(p.read_text())
def nodes(node):
 yield node
 for child in node.get('Plans',[]):yield from nodes(child)
active=plan['activePlan'][0]['Plan'];identity=plan['identityPlan'][0]['Plan'];active_nodes=list(nodes(active))
assert active['Node Type']=='Sort' and active['Actual Rows']==300 and active['Sort Space Used']==106 and active['Sort Space Type']=='Memory'
assert any(n.get('Index Name')=='idx_dhr_attachment_active' and n['Actual Rows']==300 for n in active_nodes)
assert all(n.get('Temp Read Blocks',0)==n.get('Temp Written Blocks',0)==0 for n in active_nodes)
assert identity['Index Name']=='dhr_attachment_pkey' and identity['Actual Rows']==1
result=json.loads((out/'result.json').read_text());result['checks'].append({'id':'existing-index-a23-and-declared-runtime-boundaries','outcome':'passed','evidence':{'activeIndex':'idx_dhr_attachment_active','activeRows':300,'sortKiB':106,'tempBlocks':0,'identityIndex':'dhr_attachment_pkey','onlyLocalContextAndCommonRowMapping':True,'necessaryGuardsPreserved':True,'concreteFutureMethods':['readSubmissionSourcesAndCheckDraftScope','buildFrozenSummary','persistSummaryVersion'],'noProductionSlaOrAllSourceHttpClaim':True}})
result['resources']['ownedExtractionCopiesRemoved']=True
result['toolNotes']=[{'kind':'non-product-verifier-script-error','originalLog':'check.log','cause':'Verifier path selector initially assumed /tmp/junit- prefix; actual JUnit directories use /tmp/junit<digits>.','correction':'Only own check.py path selector changed to /junit[^/]*/original-*.png; no repo/test/fixture changes.','rerun':'check-2.log: all checks passed, 38 raw JFR reread.'}]
result['originalEvidenceLocation']='The six immutable candidate archives remain authoritative; owned unpacked byte-identical copies were removed after verification to avoid recursive duplicate archival. archive-review.json preserves all archive hashes/counts and local inner manifest checks.'
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'index-and-boundaries.json').write_text(json.dumps({'activePlan':plan['activePlan'],'identityPlan':plan['identityPlan'],'scopedDistribution':{'inactiveSameDhr':5000,'mixedOtherDhr':5000,'activeCurrentDhr':300},'interpretation':'Both indexes are existing canonical assets, active query still sorts 300 rows in memory; no added index warranted by this synthetic distribution alone.'},ensure_ascii=False,indent=2)+'\n')
shutil.rmtree(out/'unpacked')
files=sorted(p for p in out.rglob('*') if p.is_file() and p.name not in ['manifest.json','manifest.sha256']);manifest={'kind':'read-only-evidence-subcheck','baseCommit':result['baseCommit'],'headCommit':result['headCommit'],'files':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');(out/'manifest.sha256').write_text(hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()+'  manifest.json\n')
print(json.dumps({'result':result['result'],'checks':len(result['checks']),'files':len(files),'manifestSha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest()}))
