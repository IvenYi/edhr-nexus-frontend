from pathlib import Path
import collections,datetime,hashlib,json,re,subprocess,xml.etree.ElementTree as ET
out=Path('/tmp/edhr-summary-metadata-reuse-quality-20261105');native=out/'native-optimized';work=Path('/tmp/edhr-summary-metadata-reuse-qa-worktree-20261105')
def write(name,x):(out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def normalize(sql):return ' '.join(re.sub(r'\$[0-9]+','?',sql).strip().lower().split())
records=[]
for p in sorted((native/'observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'applicationName' in e:records.append(e)
assert len(records)==19
log=(native/'postgres.log').read_text();parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',log,flags=re.M)
tagged=collections.defaultdict(collections.Counter);untagged=collections.Counter();types=collections.Counter()
for part in parts:
 m=re.search(r'edhr_dhr_summary_attachment_test_optimized (.*?) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if not m:continue
 app=m.group(1);sql=normalize(m.group(2))
 if app.startswith('audit_summary_'):tagged[app][sql]+=1
 elif sql.startswith('select'):untagged[sql]+=1
events=[];drivers=[]
for e in records:
 actual=tagged[e['applicationName']];expected=collections.Counter(normalize(s) for s in e['jdbcSql']+e['hibernateSql'] if normalize(s).startswith('select'))
 selects=collections.Counter({s:n for s,n in actual.items() if s.startswith('select')});extra=selects-expected
 for sql,n in extra.items():
  assert 'pg_catalog.pg_type' in sql,(e['name'],sql)
  drivers.append({'name':e['name'],'sql':sql,'count':n,'classification':'driver catalog type resolution; absent from application query/StatementInspector'})
  selects[sql]-=n
 assert +selects==expected,(e['name'],expected-selects,selects-expected)
 for sql,n in actual.items():types[sql.split()[0]]+=n
 events.append({'name':e['name'],'businessSELECT':sum(expected.values()),'matchedShapes':len(expected),'shapes':[{'sql':sql,'count':n} for sql,n in expected.items()]})
assert sum(e['businessSELECT'] for e in events)==195
assert {k:types[k] for k in ['insert','update','delete','set']}=={'insert':25,'update':17,'delete':8,'set':19}
assert types['select']==195+sum(x['count'] for x in drivers)
write('server-sql-review.json',{'events':events,'businessSELECT':195,'successfulStatementTypesInsideActionTags':dict(types),'driverMetadataSelect':drivers,'taggedBusinessWrites':50,'untaggedSuccessfulExecuteSELECT':sum(untagged.values()),'untaggedShapes':[{'sql':s,'count':n} for s,n in untagged.items()],'controlScope':'Untagged initialization, setup/seeding/workspace/saveDraft, frozen verification/assertions/EXPLAIN/runner are excluded from measured actions. Parse/bind/transaction and SET are not SELECT. Counts are successful execute statements, not a claim of all network SQL.'})
paths=set(re.findall(r'(/tmp/junit[^\s\x27\x22,]+/original-[0-9]+\.png)',log));assert paths
jfrOut=out/'external-jfr-json';jfrOut.mkdir(exist_ok=True);jfrReports=[]
for e in records:
 p=native/'observations'/(e['name']+'.jfr');command=['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(p)]
 raw=subprocess.check_output(command,text=True);(jfrOut/(e['name']+'.json')).write_text(raw);doc=json.loads(raw);matched=[];otherThreads=0
 for v in doc['recording']['events']:
  value=v['values']
  if value.get('path') not in paths:continue
  if value['eventThread']['javaThreadId']!=e['measuredThreadId']:otherThreads+=1;continue
  matched.append(value)
 b=sum(v['bytesRead'] for v in matched);assert b==e['trackedLogicalReadBytes'],(e['name'],b,e['trackedLogicalReadBytes'])
 assert len(matched)==e['trackedReadEvents'],(e['name'],len(matched),e['trackedReadEvents'])
 jfrReports.append({'name':e['name'],'command':command,'logicalBytes':b,'events':len(matched),'excludedOriginalEventsOnOtherThreads':otherThreads,'javaThreadId':e['measuredThreadId'],'threadAllocatedBytes':e['threadAllocatedBytes'],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
scale={e['name']:e for e in records if e['name'].startswith('submit_')}
for n in [0,1,10,100,300]:assert scale['submit_'+str(n)]['selectStatements']==13 and scale['submit_'+str(n)]['trackedLogicalReadBytes']==n*68
assert scale['submit_50mib']['trackedLogicalReadBytes']==52428800 and scale['submit_50mib']['threadAllocatedBytes']<25*1048576
write('jfr-allocation-review.json',{'externalRecordings':19,'registeredOriginalPaths':len(paths),'records':jfrReports,'scale':[{'name':e['name'],'SELECT':e['selectStatements'],'logicalBytes':e['trackedLogicalReadBytes'],'threadAllocatedBytes':e['threadAllocatedBytes']} for e in scale.values()],'limits':['thread allocation is cumulative, not retained heap/peak/RSS','JFR logical reads are warm-cache and thread/path-filtered, not physical IO','50MiB registration is direct verified fixture, not upload/verify format matrix','lock elapsed includes deliberate latch waiting; no SLA claim']})
plan=json.loads((native/'observations/existing-index-plans.json').read_text())
def nodes(n):
 yield n
 for p in n.get('Plans',[]):yield from nodes(p)
active=plan['activePlan'][0]['Plan'];identity=plan['identityPlan'][0]['Plan'];activeNodes=list(nodes(active))
assert active['Actual Rows']==300 and active['Node Type']=='Sort' and active['Sort Space Type']=='Memory'
assert active['Sort Space Used']==106 and all(n.get('Temp Read Blocks',0)==n.get('Temp Written Blocks',0)==0 for n in activeNodes)
assert any(n.get('Index Name')=='idx_dhr_attachment_active' for n in activeNodes)
assert identity['Index Name']=='dhr_attachment_pkey' and identity['Actual Rows']==1
write('index-review.json',{'queryScope':'10000 unrelated/inactive +300 active after complete existing canonical migration, ANALYZE','activePlan':plan['activePlan'],'identityPlan':plan['identityPlan'],'indexes':plan['indexes'],'conclusion':'Existing active composite and primary key hit; 300-row sort uses106KiB memory/no temp. No new index required for this measured fixture; no production-wide planner/SLA guarantee.'})
for p in (work/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 (out/'knowledge'/p.name).write_bytes(p.read_bytes())
knowledge=[]
for p in (out/'knowledge').glob('TEST-*.xml'):
 d=ET.parse(p).getroot();knowledge.append({'class':d.attrib['name'],**{k:int(d.attrib[k]) for k in ['tests','failures','errors','skipped']}})
assert sum(x['tests'] for x in knowledge)==89 and not any(x[k] for x in knowledge for k in ['failures','errors','skipped'])
write('knowledge/test-summary.json',{'classes':knowledge,'totals':{k:sum(x[k] for x in knowledge) for k in ['tests','failures','errors','skipped']}})
print(json.dumps({'events':len(records),'businessSELECT':195,'driverSELECT':sum(x['count'] for x in drivers),'writes':50,'set':19,'externalJFR':len(jfrReports),'50MiBThreadAllocation':scale['submit_50mib']['threadAllocatedBytes'],'300ThreadAllocation':scale['submit_300']['threadAllocatedBytes'],'knowledge':89},indent=2))
