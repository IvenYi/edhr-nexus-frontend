import pathlib, subprocess, os, json, time, datetime, hashlib, shutil, sys, xml.etree.ElementTree as ET
root=pathlib.Path(os.environ.get('EDHR_AUDIT_ROOT','/workspace/edhr-nexus-frontend'));phase=sys.argv[1]
assert phase in ['focused','full','full2','budget','optimized']
out=pathlib.Path('/tmp/edhr-summary-metadata-reuse-quality-20261105')/('native-'+phase);out.mkdir(exist_ok=False)
name='edhr-summary-metadata-reuse-quality-'+phase+'-20261105';db='edhr_dhr_summary_attachment_test_'+phase;created=False;code=1
selected='DhrSummaryAttachmentObservationPostgresTest'
if phase not in ['focused','budget']:selected+=',DhrSummaryServiceTest,DhrSummaryPersistenceTest,DhrAttachmentWriteFailureTest,DhrAttachmentAndArchiveTest,DhrFormFilesTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('owned PG not ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 env=os.environ.copy();env.update(DHR_SUMMARY_ATTACHMENT_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',PGUSER='postgres')
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.summaryAttachments=true','-Dedhr.audit.summaryAttachmentOutput='+str(out/'observations'),'-DargLine=-Xmx1536m','-Dtest='+selected,'test']
 start=datetime.datetime.now(datetime.timezone.utc);fps=[]
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/development/branch-review-20261105-dhr-summary-attachments/decision-package.yaml']
 paths+=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/'+s+'.java' for s in ['DhrSummaryService','DhrAttachmentService','DhrInstanceService','DhrEvidenceImpactService','DhrFrozenEvidenceIntegrity','DhrFormFiles']]
 paths+=['gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/'+s+'.java' for s in selected.split(',')]
 for path in paths:
  b=(root/path).read_bytes();fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'run.json').write_text(json.dumps({'command':command,'head':run(['git','rev-parse','HEAD'],cwd=root),'workingTreeStatus':run(['git','status','--porcelain'],cwd=root),'startedAt':start.isoformat(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fps,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])},indent=2)+'\n')
 totals={k:0 for k in ['tests','failures','errors','skipped']};classes=[];missing=[]
 for test in selected.split(','):
  xml=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not xml:missing.append(test)
  for p in xml:
   shutil.copy2(p,out/p.name);doc=ET.parse(p).getroot();values={k:int(doc.attrib.get(k,0)) for k in totals};classes.append({'class':doc.attrib['name'],**values})
   for k in totals:totals[k]+=values[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-1800:])
 code=0 if result.returncode==0 and not missing and totals=={'tests':18 if phase in ['focused','budget'] else 72,'failures':0,'errors':0,'skipped':0} else 1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n');print('owned cleanup',removed)
sys.exit(code)
