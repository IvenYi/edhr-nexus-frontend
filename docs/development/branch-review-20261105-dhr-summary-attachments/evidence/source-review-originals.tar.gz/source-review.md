# DHR汇总附件提交读取：有限只读源码复核

本子项按主侧L2决策包做源码/计划边界复核，不是最终独立qualityResult。实际HEAD、重新fetch目标、契约读取均为`a429f983a7a69553753034e9306d12598fcc15be`；知识`0.3.25/schema1.2.0`保持，未改变成熟度或阶段。父侧工作树中研发台账和新决策包未提交，已按原字节捕获。本子项未改仓库、代码、测试、配置或知识，未启动PG/Maven/JFR/浏览器，不声称本轮运行或执行计划通过。

## 当前原始源码结论

`DhrSummaryService.submit:233–248`先锁生产对象、DHR、草稿，检查待审记录控制、草稿身份/修订，再读取真实detail及全部有效附件snapshot并比较source_scope_hash。`249–253`对每个已核验附件调用`DhrAttachmentService.file`；后者`173`先ensureDhr(false)查询DHR、`174`再按tenant/DHR/id查询stored_path及sha256。这是当前循环中每附件2次显式Jdbc查询的原始调用依据，不需要推测JPA一级缓存；两个调用直接使用JdbcTemplate。

`DhrAttachmentService.snapshot:57–69`的`SELECT *`在数据库已取到stored_path，但公开JSON仅返回身份、名称、类型、大小、SHA、来源/用途、核验及关联元数据，没有暴露存储路径。不能为复用把路径添加到对外响应；也不能因JSON已有id/sha便声称原路径已可由调用者直接使用。

2N是该循环的成本，不能把旧5+2N或605说成这轮完整成功请求总数。实际detail含来源实例、执行状态和布局读取，impact有记录控制检查，成功提交还会分配版本、写冻结证据/状态/审计并删除草稿。主侧应分别记录这些固定读写、预热/断言、JPA审计SQL及失败/初始化，不能把观察类回调计数称为全部网络SQL。本子项没有重跑旧局部guard观察。

## 锁、来源集合与失败保护

- `lockProductionObject:432–437`读取DHR的production_object_id后获取生产对象行锁；`lockedCompletedDhr:412–428`获取DHR行锁并检查COMPLETED、未PENDING_REVIEW/FORMALIZED；草稿随后FOR UPDATE。真实Spring代理事务是整个锁论证前提，手工new服务必须有外层真实事务才等价。
- 本轮生产Java字面SQL检索只发现附件upload INSERT、verify UPDATE、unlink UPDATE，均先`ensureDhr(dhrId,true)`锁父DHR（attachment:76/143/160、214–220），再写附件；未见修改已登记original_name/stored_path/sha256的当前接口。这是当前写者观察，不是新永久不可变政策，也不认证所有部署/任意SQL写者。
- `scopeHash:622–626`包含candidate数组及整个公开attachmentSnapshot，因此草稿后核验状态/时间、active集合或其他公开元数据改变会先使来源范围不匹配。未核验专项负例应在保存草稿前保持PENDING，避免实际上只测到stale guard。缺失或篡改磁盘字节不改元数据，适合保存后检测完整SHA失败及事务回滚。
- 真正提交成功后summary_status变FORMALIZED。等待DHR父锁的合法unlink应在解锁后重新读取状态并拒绝，active保持、冻结仍含原附件、无UNLINK审计。旧manual-guard失败回滚才允许等待的unlink随后成功。两个场景不能混作相同期望。
- DHR存在/范围、VERIFIED、草稿来源hash、完整文件SHA、人工三确认及说明、源表单原件和独立冻结摘要分别保护不同边界；不是可以机械删除的重复防御。
- `file`不要求active，服务于历史冻结附件仍可访问；当前下载入口由downloadableFile检查active或指定版成员。不能为汇总优化把所有file调用都改成active-only，否则破坏解除关联后的历史导出。`DhrArchiveService:144–147`另按冻结size/SHA比较实际输出字节，且无同一汇总写事务，不能套用submit持锁复用论证。

## 完整摘要及资源范围

`verifiedFile:206–211`先检查常规文件并以当前登记SHA核验完整原件；`sha256(Path):270–278`已有固定8192字节缓冲完整读取，不是只验前缀。每附件O(字节总量)及父锁持续时间依然存在，省metadata SQL不代表省掉完整SHA或实现固定延迟。单文件50MiB是上传上限，附件数和累计字节没有由“DHR表单≤300”自动得到上限。

`verify:149`仍以readAllBytes并检查格式，upload也获取完整数组；本轮若测submit的50MiB读取，不能据此宣称上传/核验同样内存有界。导出原件数组、PDF累计和审计载荷仍为原开放队列，不由本次取证或PR63签名图局部复用关闭。

## 冻结摘要与顺序

submit把原attachmentSnapshot.deepCopy写入frozen并保存attachment_snapshot，版本hash包含目录/来源/附件/checkResult/reviewBinding和规范化placements。DhrFrozenEvidenceIntegrity分别核对每源记录source_snapshot/hash、候选数量/身份、版本整体摘要；版本摘要包含附件元数据，但不是对磁盘文件的当前完整读取，两者不能互换。真实成功提交测试宜再调用该服务核对冻结摘要、附件顺序/元数据、草稿删除、版本状态和SUBMIT审计，并测试坏原件、来源变化、未核验时无新冻结/状态/审计落地。

## 现有索引与计划边界

canonical baseline已有：`dhr_attachment_pkey(id)`（1512–1513）、`idx_dhr_attachment_active(tenant_id,dhr_instance_id,active)`（1840）、附件父DHR FK（2283–2284）；DHR实例/生产对象主键、草稿tenant+DHR唯一约束、版本tenant+DHR+version_no唯一/实例索引也在完整schema。

按全局唯一id读附件已有主键，tenant/DHR条件仍需保留以防跨范围；索引不能消除每项两次往返。有效集合索引匹配三个等值条件，但不含`linked_at,id`，不能仅看名字声称它满足ORDER BY或没有Sort。需要完整迁移+ANALYZE及多个DHR/active-inactive/大小行分布的EXPLAIN ANALYZE确认：0/1/300活动行、同DHR很多inactive、无关DHR很多行，分列扫描/过滤/排序/缓冲/临时块。小集合的显式排序可能合理，只有真实目标规模下排序成为瓶颈再讨论追加排序键或局部索引；本子项未执行计划、不建议凭静态重复添加索引。0091只新增review/task索引，不是附件排序优化。

## 最小复用与具体抽取候选（未实施）

优先方案是一次内部附件读取生成`SubmissionAttachments`：保留原公开snapshot投影，同时在私有/包内上下文携带同一批原件路径/登记SHA。主侧原有锁顺序、来源hash比较顺序和错误优先级保持；来源hash通过后再逐文件核验VERIFIED及完整SHA，最后按原顺序冻结公开snapshot。这样不向HTTP泄漏stored_path、不跨请求缓存，不全局修改file/下载/导出资格，也不增加新的永久状态。需要测metadata上下文额外内存与全部坏文件/锁/回滚边界，不自动当成已批准。

若只做更小一步，可考虑包内“父DHR已锁定”专用原件检查省掉N次重复ensureDhr，仍保留N次路径查询；这是收益较小但少改投影的备选。不要全局删掉file的ensureDhr，普通下载/导出在不同时点仍需要自己的资格入口。

长方法拆分可先在原服务内提取`readSubmissionSourcesAndCheckDraftScope`、`verifySubmissionAttachmentOriginals`、`buildFrozenSummary`及`persistSummaryVersion`，由submit继续承担固定锁顺序/事务/检查顺序。只有真正落实内部投影复用时再提取公有snapshot的共同单行映射；无需新通用文件批处理框架、反射式校验器或为统计行数重构。本批A23只核上述方法范围，不等于整文件或全仓过度防御审完。

## 结论及保留

当前未确认新的正常业务正确性缺陷；重复metadata是已定位的性能候选，实际次数/资源/计划以主侧和最终独立原件为准。没有在本子项实施修复或发布新政策，也未为“回调未跑”、任意SQL写者或文件系统故障等未复现假设增加防御。

原931知识候选、86 UI、W2余项、W3/W4/W5交叉、W6健壮性/性能/抽取/A23含旧已审复查、W7增量、原DHR high/A12/完整矩阵及用户暂停保持；不计整文件完成或重建历史unique，不把目录/测试数量当全盘语义一致。主侧新测试如采用真实服务成功submit，也仅覆盖声明的事务/服务子范围，不认证首次START、完整HTTP/RBAC/实际多租户、七格式上传/核验、生产并发/SLA或受控DHR归档生命周期。
