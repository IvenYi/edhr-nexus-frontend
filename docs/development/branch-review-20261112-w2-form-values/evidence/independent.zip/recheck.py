from pathlib import Path
import collections, datetime, hashlib, json, subprocess, xml.etree.ElementTree as ET, yaml
repo=Path('/tmp/edhr-w2-values-qa-20261112');raw=Path(__file__).parent
candidate='6e878e496189c2fdd765f9ea71b5264a3e181709';target='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
run=json.loads((raw/'final/run.json').read_text());knowledge=json.loads((raw/'knowledge/run.json').read_text())
assert run['head']==knowledge['head']==candidate and run['exitCode']==knowledge['exitCode']==0
assert run['workingTreeState'].splitlines()==['?? gmp-platform/frontend/node_modules']
assert knowledge['workingTreeState'].splitlines()==['?? gmp-platform/frontend/node_modules']
bindings=[]
for label,record in [('runtime',run),('knowledge',knowledge)]:
 for item in record['sourceFingerprints']:
  path=item['path'];b=(repo/path).read_bytes()
  assert sha(b)==item['sha256']==sha(subprocess.check_output(['git','show',candidate+':'+path],cwd=repo))
  if label=='runtime':assert sha(b)==sha((raw/'final/source'/path).read_bytes())
 bindings.append({'group':label,'inputCount':len(record['sourceFingerprints']),'allCandidateHashesMatch':True})
summary=json.loads((raw/'final/test-summary.json').read_text())
assert summary['totals']==dict(tests=208,failures=0,errors=0,skipped=3)
assert len(summary['classes'])==11 and not summary['missingFreshReports']
expected={'formRecordsBrowserFixture','browserEvidenceFixture','firstStartFreezesOneCommittedConfigurationDuringProcessRebinding'}
assert {s['name'] for s in summary['unchangedConditionalNotExecuted']}==expected
assert json.loads((raw/'knowledge/test-summary.json').read_text())==dict(tests=89,failures=0,errors=0,skipped=0)
observations=[]
for p in sorted((raw/'final/observations').glob('*.json')):
 d=json.loads(p.read_text());assert d['inputUnchanged'] and d['previousUnchanged']
 assert d['actualH2Queries']==len(d['queries'])==(1 if d['repeatedFile'] and d['rows'] else 0)
 for q in d['queries']:
  assert q['sql']=="SELECT original_name FROM file_object WHERE id=? AND target_type='PRODUCTION_EXECUTION' AND target_id=?"
  assert q['parameters']==[9,'101']
 if d['rows']>=100:assert d['threadAllocatedBytes']<16*1024*1024
 observations.append({'path':str(p.relative_to(raw)),'sha256':sha(p.read_bytes()),**{k:v for k,v in d.items() if k!='queries'}})
assert len(observations)==7
old=Path('/tmp/edhr-w2-form-values-20261112/old_same_tests');oldrun=json.loads((old/'run.json').read_text())
assert oldrun['head']==target
oldxml=ET.parse(next(old.glob('TEST-*.xml'))).getroot()
assert {k:int(oldxml.attrib[k]) for k in ['tests','failures','errors','skipped']}==dict(tests=11,failures=6,errors=0,skipped=0)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/ProductionFormValueBoundaryTest.java'
assert sha((old/'source'/test).read_bytes())==sha((repo/test).read_bytes())
source='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java'
assert sha((old/'source'/source).read_bytes())==sha(subprocess.check_output(['git','show',target+':'+source],cwd=repo))
negative=[]
for case in oldxml.findall('testcase'):
 f=case.find('failure')
 if f is not None:negative.append({'name':case.attrib['name'],'type':f.attrib.get('type'),'message':f.attrib.get('message')})
assert len(negative)==6
for name in ['run.json','test-summary.json',next(old.glob('TEST-*.xml')).name]:
 out=raw/'observed-primary-negative'/name;out.parent.mkdir(exist_ok=True);out.write_bytes((old/name).read_bytes())
changes=git('diff','--name-only',target,candidate).splitlines()
assert changes==['docs/development/branch-review-20261112-w2-form-values/decision-package.yaml',source,test]
assert not git('diff','--name-only',target,candidate,'--','docs/knowledge','docs/architecture','docs/agents','AGENTS.md','codeplzreadme.md','gmp-platform/backend/src/main/resources','gmp-platform/frontend')
knowledgepaths=[p for p in (repo/'docs/knowledge').rglob('*') if p.is_file()]
assert len(knowledgepaths)==353
ids=[]
def walk(v):
 if isinstance(v,dict):
  if isinstance(v.get('id'),str):ids.append(v['id'])
  for c in v.values():walk(c)
 elif isinstance(v,list):
  for c in v:walk(c)
for p in knowledgepaths:
 if p.suffix in ['.yaml','.yml'] and p.name!='schema.yaml':walk(yaml.safe_load(p.read_text()))
out={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,
 'bindings':bindings,'totals':summary['totals'],'actuallyPassed':205,'oldConditionalNotExecuted':summary['unchangedConditionalNotExecuted'],
 'knowledgeTests':89,'knowledgeFiles':353,'mechanicalIdCount':len(ids),'mechanicalUniqueIdCount':len(set(ids)),
 'changedFiles':changes,'observations':observations,'primaryOldSameFinalTestBytes':{'actualTests':11,'passed':5,'failed':6,'errors':0,'skipped':0,'failures':negative},
 'qualification':'Independent actual runs;H2/domain/JWT MockMvc partial integration,not native PG or browser. Query records include client recording overhead. Unchanged-input claims bind executed precise assertions and booleans,not an exported full before/after graph. Old negative primary originals read/copied,not independently rerun.'}
(raw/'independent-recheck.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['candidate','totals','actuallyPassed','knowledgeTests','knowledgeFiles','mechanicalIdCount','mechanicalUniqueIdCount']},indent=2))
