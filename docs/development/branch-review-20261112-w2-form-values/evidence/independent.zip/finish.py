from pathlib import Path
import datetime,hashlib,json,yaml
raw=Path(__file__).parent
candidate='6e878e496189c2fdd765f9ea71b5264a3e181709';target='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
items=[
 ('contract-and-fixed-candidate','documentation','独立fetch目标、读取6e契约/DP和准确提交范围','inspection','git fetch;git diff fb68cf02 6e878e49',['role-inputs.json','diff.patch']),
 ('authorization-and-l2-scope','requirements','本轮用户明确两项一起优化，范围与DP和产品差异一致','inspection','read DP,user-confirmed reply and actual diff',['read-inputs/docs/development/branch-review-20261112-w2-form-values/decision-package.yaml','diff.patch']),
 ('minimum-product-boundary','regression','仅一个产品文件及维护测试/DP，无UI/API/schema/契约/知识差异','command','git diff --name-only fb68cf02 6e878e49',['independent-recheck.json']),
 ('new-domain-and-h2-boundaries','integration','新增11项真实引擎/ExecutionAccess及自有H2夹具通过','automated-test','run.py final',['final/TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']),
 ('draft-json-final-completion','unit','草稿、JSON重读、空/零/省略、行ID及最终完成边界保持','automated-test','ProductionFormValueBoundaryTest#draftJsonRoundTripPreservesClearsZeroAndRowIdentityUntilFinalCompletion',['final/TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']),
 ('per-occurrence-file-validation','security','元数据复用仍逐处拒绝伪造名、外对象，多个文件各自核对','automated-test','ProductionFormValueBoundaryTest file-boundary methods',['final/TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml','diff.patch']),
 ('independent-call-freshness','database','每公开校验调用新Map，删除后重新查询，DB异常继续传播','automated-test','ProductionFormValueBoundaryTest metadata/failure methods',['final/TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']),
 ('read-only-context-semantics','regression','浅层root+row容器与递归只读子图保留上下文及原输入','inspection','inspect ExecutionAccess/FormReferenceLookup plus executed context regressions',['diff.patch','final/TEST-com.zencas.edhr.production.controller.ProductionExecutionIntegrationTest.xml','final/TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']),
 ('full-selected-regression','regression','实际11类208总，205通过0F/E，精确3项原条件未执行','automated-test','run.py final',['final/run.json','final/test-summary.json']),
 ('signature-permission-audit-adjacency','audit','原JWT/MockMvc、H2资格/签署/审计/回滚相邻回归通过，未冒称全E2E','automated-test','run.py final selected existing suites',['final/TEST-com.zencas.edhr.production.controller.ProductionExecutionIntegrationTest.xml','final/TEST-com.zencas.edhr.production.service.ExecutionAccessTest.xml','final/TEST-com.zencas.edhr.production.service.ProductionExecutionEngineTest.xml']),
 ('query-and-memory-budgets','database','7观察真实查询及参数重算；300行低于16MiB，文件每校验树1查询','command','python recheck.py',['independent-recheck.json','final/observations']),
 ('old-same-test-byte-negative','regression','核主侧旧同最终测试11原件5P6F0E/S，真实资源/查询红，非亲自运行旧源','inspection','read primary old_same_tests run,source and XML;verify test SHA',['observed-primary-negative','independent-recheck.json']),
 ('formal-knowledge-89','ontology','本实例实际89知识检查通过、359输入匹配6e','automated-test','python knowledge-run.py',['knowledge/run.json','knowledge/test-summary.json','independent-recheck.json']),
 ('finite-semantic-boundary','ontology','知识353/2849未改，21有限记录16一致/1gap/4待决，不宣称全库一致','inspection','read actual selected policies/open questions and finite records',['knowledge-semantic-review.json','finite-ontology-records-observed.jsonl']),
 ('a23-and-extraction-boundary','requirements','删除无必要整图复制但保留有依据的安全核对；局部重载无新框架，原行扫描不顺带改','inspection','inspect ExecutionAccess and unchanged command/transaction owners',['review.md','diff.patch']),
 ('environment-and-evidence-truthfulness','documentation','独立运行仅依赖软链未跟踪且已清，3条件未执行/H2/局部累计指标如实列明','command','git status --porcelain;inspect fresh run metadata/cleanup',['dependency-cleanup.json','final/run.json','knowledge/run.json','review.md']),
]
checks=[{'id':'check.'+i,'required':True,'category':c,'description':d,'method':m,'command':cmd,'outcome':'passed','evidence':e} for i,c,d,m,cmd,e in items]
result={'qualityResult':{'result':'passed','baseCommit':target,'headCommit':candidate,
 'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':candidate,'uncommittedContractPaths':[]},
 'workingTreeState':{'status':'dirty','includedPaths':[],'excludedPaths':['gmp-platform/frontend/node_modules'],'untrackedPaths':['gmp-platform/frontend/node_modules']},
 'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],
 'residualRisks':[
 {'id':'risk.unchanged-three-conditional-cases','description':'两个长驻浏览器fixture及仅PG的START配置争用未执行，不计通过。','impact':'当前不证明这些可选场景；原断言和条件未改。','mitigation':'按实际新增风险/全链阶段提供相应环境，当前205通过与89知识分列。'},
 {'id':'risk.h2-and-local-allocation','description':'领域/H2和部分JWT MockMvc，非原生PG或浏览器全E2E；累计线程分配及H2查询有记录开销。','impact':'不是生产峰值/RSS/全SAVE耗时/SLA或PG索引证据。','mitigation':'仅按当前公开字段校验树及样本报告；生产容量另取证。'},
 {'id':'risk.remaining-overall-audit','description':'W2其他入口/W3-W7/A23补查、另一通用质量high/A12/完整权限及UI/多租户和既有strict/lint边界保持。','impact':'本批通过不代表整体审计或知识全盘一致。','mitigation':'持续按固定提交与具体方法/ID台账推进，原暂停/未决不自动解决。'}],
 'blockingConditions':[]}}
(raw/'quality-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=120))
files=[]
for p in sorted(raw.rglob('*')):
 if not p.is_file() or p.name in ['manifest.json','SHA256SUMS']:continue
 b=p.read_bytes();files.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
manifest={'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'files':files}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
lines=[]
for p in sorted(raw.rglob('*')):
 if p.is_file() and p.name!='SHA256SUMS':lines.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(raw)))
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for item in files:
 b=(raw/item['path']).read_bytes();assert len(b)==item['bytes'] and hashlib.sha256(b).hexdigest()==item['sha256']
print(json.dumps({'qualityResult':'passed','requiredChecks':len(checks),'manifestFiles':len(files),'manifestSha256':hashlib.sha256((raw/'manifest.json').read_bytes()).hexdigest()},indent=2))
