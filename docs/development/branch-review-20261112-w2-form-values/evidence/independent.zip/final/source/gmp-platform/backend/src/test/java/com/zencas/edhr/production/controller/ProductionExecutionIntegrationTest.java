package com.zencas.edhr.production.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.zencas.edhr.common.config.SecurityConfig;
import com.zencas.edhr.common.exception.GlobalExceptionHandler;
import com.zencas.edhr.common.util.SnowflakeIdGenerator;
import com.zencas.edhr.compliance.entity.AuditEvent;
import com.zencas.edhr.compliance.repository.AuditEventRepository;
import com.zencas.edhr.compliance.entity.Signature;
import com.zencas.edhr.compliance.entity.FileObject;
import com.zencas.edhr.compliance.repository.SignatureRepository;
import com.zencas.edhr.compliance.repository.FileObjectRepository;
import com.zencas.edhr.compliance.controller.FileController;
import com.zencas.edhr.identity.entity.UserAccount;
import com.zencas.edhr.identity.repository.*;
import com.zencas.edhr.identity.service.SubjectResolver;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.zencas.edhr.identity.security.JwtAuthenticationFilter;
import com.zencas.edhr.identity.security.JwtTokenProvider;
import com.zencas.edhr.masterdata.repository.MaterialRepository;
import com.zencas.edhr.masterdata.repository.ProductProcessVersionRepository;
import com.zencas.edhr.masterdata.service.ProductProcessResolutionService;
import com.zencas.edhr.production.entity.*;
import com.zencas.edhr.production.repository.*;
import com.zencas.edhr.production.service.*;
import com.zencas.edhr.workflow.engine.StateMachineService;
import jakarta.persistence.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.context.annotation.*;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.orm.jpa.SharedEntityManagerCreator;
import org.springframework.orm.jpa.persistenceunit.PersistenceManagedTypes;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import java.util.*;
import java.util.concurrent.*;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest(classes = ProductionExecutionIntegrationTest.Config.class, webEnvironment = SpringBootTest.WebEnvironment.DEFINED_PORT, properties = {
    "server.port=${execution.test.port:0}",
    "spring.liquibase.enabled=false",
    "spring.datasource.url=${execution.test.url:jdbc:h2:mem:production-execution;MODE=PostgreSQL;DB_CLOSE_DELAY=-1;DATABASE_TO_LOWER=TRUE}",
    "spring.datasource.driver-class-name=${execution.test.driver:org.h2.Driver}",
    "spring.datasource.username=${execution.test.user:sa}", "spring.datasource.password=",
    "spring.jpa.database-platform=${execution.test.dialect:org.hibernate.dialect.H2Dialect}",
    "spring.jpa.properties.hibernate.dialect=${execution.test.dialect:org.hibernate.dialect.H2Dialect}",
    "spring.jpa.hibernate.ddl-auto=update"
})
@AutoConfigureMockMvc
class ProductionExecutionIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper mapper;
    @Autowired JdbcTemplate jdbc;
    @Autowired JwtTokenProvider tokens;
    @MockBean MaterialRepository materials;
    @MockBean com.zencas.edhr.production.service.ProductionOutputService outputs;
    @MockBean ProductProcessVersionRepository processVersions;
    @MockBean ProductProcessResolutionService resolution;
    @MockBean StateMachineService stateMachines;
    @MockBean DhrSummaryService summaries;
    @Autowired UserAccountRepository users;
    @Autowired PasswordEncoder passwords;
    @Autowired FileObjectRepository files;
    @Autowired SignatureRepository signatures;
    @Autowired org.springframework.transaction.PlatformTransactionManager transactions;
    @Autowired ProductionService production;
    @Autowired ExecutionSnapshotBuilder snapshotBuilder;
    @MockBean DepartmentRepository departments;
    @MockBean RoleRepository roles;
    @MockBean UserDepartmentRepository userDepartments;
    @MockBean UserRoleRepository userRoles;
    @MockBean com.zencas.edhr.system.repository.IconAssetRepository icons;
    @MockBean com.zencas.edhr.system.repository.SystemSettingRepository settings;
    @SpyBean AuditEventRepository audits;

    @BeforeEach void setup() throws Exception {
        jdbc.execute("DROP TABLE IF EXISTS dhr_termination");
        jdbc.execute("DROP TABLE IF EXISTS dhr_summary_draft");
        jdbc.execute("DROP TABLE IF EXISTS dhr_summary_version");
        jdbc.execute("DROP TABLE IF EXISTS dhr_instance");
        jdbc.execute("DROP SEQUENCE IF EXISTS dhr_instance_number_seq");
        jdbc.execute("DROP TABLE IF EXISTS form_trace_value");
        jdbc.execute("DROP TABLE IF EXISTS form_instance_revision");
        jdbc.execute("DROP TABLE IF EXISTS form_instance_record");
        jdbc.execute("DROP SEQUENCE IF EXISTS form_instance_number_seq");
        var migration = new String(getClass().getResourceAsStream("/db/changelog/0082-form-instance-records.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : migration.split("--changeset codex:0082-form-instance-history")[0].split(";")) {
            if (sql.contains("CREATE")) jdbc.execute(sql);
        }
        jdbc.execute("CREATE SEQUENCE IF NOT EXISTS hibernate_sequence");
        jdbc.execute("ALTER TABLE form_instance_record ADD COLUMN current_revision_id BIGINT");
        jdbc.execute("CREATE TABLE form_instance_revision(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),record_id BIGINT,revision_no INT,status VARCHAR(32),values_json TEXT,content_hash VARCHAR(64),created_by VARCHAR(192),created_at TIMESTAMP)");
        var queryMigration = new String(getClass().getResourceAsStream("/db/changelog/0083-form-instance-query.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : queryMigration.split("--changeset codex:0083-form-instance-query-history")[0].split(";")) {
            if (sql.contains("ALTER") || sql.contains("CREATE")) jdbc.execute(sql);
        }
        var sourceMigration = new String(getClass().getResourceAsStream("/db/changelog/0086-form-instance-business-source.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : sourceMigration.split(";")) {
            if (sql.contains("ALTER") || sql.contains("CREATE")) jdbc.execute(sql);
        }
        var traceMigration = new String(getClass().getResourceAsStream("/db/changelog/0109-saved-form-trace-index.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : traceMigration.split("--changeset codex:0109-saved-form-trace-index-baseline")[0].split(";")) {
            if (sql.contains("CREATE")) jdbc.execute(sql);
        }
        jdbc.execute("ALTER TABLE form_trace_value ADD COLUMN value_type VARCHAR(16) NOT NULL DEFAULT 'text'");
        var stageMigration = new String(getClass().getResourceAsStream("/db/changelog/0111-form-instance-saved-stage.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : stageMigration.split(";")) if (sql.contains("ALTER")) jdbc.execute(sql);
        for (String ddl : List.of(
            "material(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),code VARCHAR(64),name VARCHAR(128),specification VARCHAR(128),unit VARCHAR(16),status VARCHAR(16) DEFAULT 'ACTIVE',material_type_id BIGINT DEFAULT 1)",
            "material_type(id BIGINT PRIMARY KEY,name VARCHAR(128))",
            "operation(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),code VARCHAR(64),name VARCHAR(128))",
            "department(id BIGINT PRIMARY KEY,name VARCHAR(128))",
            "user_department(user_id BIGINT,department_id BIGINT)",
            "product_process(id BIGINT PRIMARY KEY,owner_type VARCHAR(32),owner_id BIGINT)",
            "product_family(id BIGINT PRIMARY KEY,name VARCHAR(128))",
            "product_process_version(id BIGINT PRIMARY KEY,product_process_id BIGINT DEFAULT 1,effective_from TIMESTAMP,effective_to TIMESTAMP,tenant_id VARCHAR(64),version_label VARCHAR(64),production_mode VARCHAR(64),production_form VARCHAR(64),route_version_id BIGINT,dhr_template_version_id BIGINT,dhr_review_mode VARCHAR(16) DEFAULT 'NONE',dhr_review_workflow_definition_id BIGINT,dhr_review_workflow_version_id BIGINT)",
            "route(id BIGINT PRIMARY KEY,name VARCHAR(128),code VARCHAR(64))",
            "route_version(id BIGINT PRIMARY KEY,route_id BIGINT,version VARCHAR(64))",
            "dhr_template(id BIGINT PRIMARY KEY,name VARCHAR(128),code VARCHAR(64))",
            "dhr_template_version(id BIGINT PRIMARY KEY,dhr_template_id BIGINT,version_label VARCHAR(64))",
            "dhr_directory(id BIGINT PRIMARY KEY,version_id BIGINT,name VARCHAR(128),parent_id BIGINT,sort_order INT)",
            "dhr_template_item(id BIGINT PRIMARY KEY,directory_id BIGINT,form_template_id BIGINT,form_template_version_id BIGINT,display_name VARCHAR(128),sort_order INT,is_required BOOLEAN)",
            "route_node(id BIGINT PRIMARY KEY,route_version_id BIGINT,node_key VARCHAR(64),operation_id BIGINT,operation_code VARCHAR(64),operation_name VARCHAR(128),node_type VARCHAR(32),config_json TEXT,sort_order INT)",
            "route_relation(id BIGINT PRIMARY KEY,route_version_id BIGINT,source_node_key VARCHAR(64),target_node_key VARCHAR(64),relation_type VARCHAR(64),rule_expression TEXT,priority INT)",
            "product_process_operation_binding(id BIGINT PRIMARY KEY,product_process_version_id BIGINT,route_node_key VARCHAR(64),final_output BOOLEAN DEFAULT FALSE)",
            "product_process_operation_form_binding(id BIGINT PRIMARY KEY,product_process_operation_binding_id BIGINT,form_template_version_id BIGINT,dhr_template_item_id BIGINT,required BOOLEAN,sort_order INT,fill_settings_json TEXT)",
            "product_process_operation_document_binding(id BIGINT PRIMARY KEY,product_process_operation_binding_id BIGINT,document_version_id BIGINT,page_start INT,page_end INT,sort_order INT)",
            "sop_document(id BIGINT PRIMARY KEY,title VARCHAR(128))",
            "document_version(id BIGINT PRIMARY KEY,document_id BIGINT,code VARCHAR(64),version VARCHAR(64),file_id BIGINT)",
            "form_template(id BIGINT PRIMARY KEY,name VARCHAR(128),code VARCHAR(64),category_name VARCHAR(128),tenant_id VARCHAR(64) DEFAULT 'default',status VARCHAR(32) DEFAULT 'ACTIVE')",
            "form_template_version(id BIGINT PRIMARY KEY,template_id BIGINT,version_label VARCHAR(64),model_design_json TEXT,canvas_design_json TEXT,tenant_id VARCHAR(64) DEFAULT 'default',status VARCHAR(32) DEFAULT 'PUBLISHED')",
            "workflow_definition(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),type VARCHAR(32),name VARCHAR(128),code VARCHAR(64),business_type VARCHAR(32))",
            "workflow_definition_version(id BIGINT PRIMARY KEY,definition_id BIGINT,version_number INT,status VARCHAR(32),is_current BOOLEAN,nodes_json TEXT,edges_json TEXT)",
            "workflow_binding_rule(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),definition_id BIGINT,rule_type VARCHAR(32),is_active BOOLEAN,product_id BIGINT,product_family_id BIGINT,operation_id BIGINT)",
            "product_family_member(id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),product_id BIGINT,product_family_id BIGINT)")) {
            jdbc.execute("CREATE TABLE IF NOT EXISTS " + ddl);
            jdbc.update("DELETE FROM " + ddl.substring(0, ddl.indexOf('(')));
        }
        var dhrMigration = new String(getClass().getResourceAsStream("/db/changelog/0089-dhr-instance-management.sql").readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
        for (String sql : dhrMigration.split("INSERT INTO permission")[0].split(";")) {
            if (sql.contains("CREATE")) jdbc.execute(sql);
        }
        jdbc.execute("ALTER TABLE dhr_instance ADD COLUMN summary_status VARCHAR(32) DEFAULT 'NOT_STARTED' NOT NULL");
        jdbc.execute("ALTER TABLE dhr_instance ADD COLUMN dhr_review_mode VARCHAR(16) DEFAULT 'NONE' NOT NULL");
        jdbc.execute("ALTER TABLE dhr_instance ADD COLUMN dhr_review_workflow_definition_id BIGINT");
        jdbc.execute("ALTER TABLE dhr_instance ADD COLUMN dhr_review_workflow_version_id BIGINT");
        jdbc.execute("ALTER TABLE dhr_instance DROP CONSTRAINT ck_dhr_instance_status");
        jdbc.execute("ALTER TABLE dhr_instance ADD CONSTRAINT ck_dhr_instance_status CHECK (status IN ('IN_PROGRESS','COMPLETED','EARLY_TERMINATED'))");
        jdbc.execute("CREATE TABLE dhr_termination(dhr_instance_id BIGINT PRIMARY KEY,tenant_id VARCHAR(64),reason TEXT,terminated_at TIMESTAMP,terminated_by VARCHAR(192),recorded_at TIMESTAMP NOT NULL,snapshot_json TEXT,snapshot_hash VARCHAR(64),historical BOOLEAN NOT NULL)");
        jdbc.execute("CREATE TABLE dhr_summary_draft(id BIGINT PRIMARY KEY,dhr_instance_id BIGINT)");
        jdbc.execute("CREATE TABLE dhr_summary_version(id BIGINT PRIMARY KEY,dhr_instance_id BIGINT)");
        jdbc.update("DELETE FROM production_execution"); jdbc.update("DELETE FROM production_object"); jdbc.update("DELETE FROM work_order"); jdbc.update("DELETE FROM audit_event");
        jdbc.update("DELETE FROM signature"); jdbc.update("DELETE FROM user_account");
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(1,0,'operator','测试操作员',?,'ACTIVE')", passwords.encode("test-secret"));
        jdbc.update("INSERT INTO material(id,tenant_id,code,name,specification,unit) VALUES(1,'default','P01','导管','规格A','件')");
        jdbc.update("INSERT INTO material_type VALUES(1,'产成品')");
        jdbc.update("INSERT INTO operation VALUES(11,'default','O01','装配'),(12,'default','O02','检验')");
        jdbc.update("INSERT INTO product_process VALUES(1,'PRODUCT',1)");
        jdbc.update("INSERT INTO product_process_version(id,tenant_id,version_label,production_mode,production_form,route_version_id,dhr_template_version_id,dhr_review_mode) VALUES(2,'default','配置V1','量产','批次',3,4,'NONE'),(22,'default','配置V1','量产','SN',3,4,'NONE')");
        jdbc.update("INSERT INTO route VALUES(3,'导管装配','R01')"); jdbc.update("INSERT INTO route_version VALUES(3,3,'V1')");
        jdbc.update("INSERT INTO dhr_template VALUES(4,'导管生产记录','D01')");
        jdbc.update("INSERT INTO dhr_template_version(id,dhr_template_id,version_label) VALUES(4,4,'V1')");
        jdbc.update("INSERT INTO dhr_directory VALUES(40,4,'生产记录',NULL,1)");
        jdbc.update("INSERT INTO dhr_template_item VALUES(50,40,5,5,'装配记录',1,true)");
        jdbc.update("INSERT INTO route_node VALUES(11,3,'a',11,'O01','装配','OPERATION','{}',1),(12,3,'b',12,'O02','检验','OPERATION','{}',2)");
        jdbc.update("INSERT INTO route_relation VALUES(1,3,'a','b','SEQUENTIAL',NULL,1)");
        jdbc.update("INSERT INTO product_process_operation_binding(id,product_process_version_id,route_node_key) VALUES(11,2,'a'),(12,2,'b')");
        jdbc.update("INSERT INTO form_template(id,name,code,category_name) VALUES(5,'装配记录','F01','生产记录')");
        jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,model_design_json,canvas_design_json) VALUES(5,5,'V1',?,?)",
            "{\"fields\":[{\"id\":\"temperature\",\"name\":\"温度\",\"type\":\"number\",\"status\":\"enabled\"}]}",
            "{\"bindings\":{\"fieldId\":\"temperature\",\"required\":true}}");
        jdbc.update("INSERT INTO product_process_operation_form_binding VALUES(51,11,5,50,true,1,'{\"fillMode\":\"DIRECT\"}')");
        jdbc.update("INSERT INTO product_process_operation_binding(id,product_process_version_id,route_node_key) VALUES(21,22,'a'),(22,22,'b')");
        jdbc.update("INSERT INTO product_process_operation_form_binding VALUES(61,21,5,50,true,1,'{\"fillMode\":\"DIRECT\"}')");
        when(resolution.findVersionForProduct(anyLong(), anyLong())).thenAnswer(invocation -> {
            Long versionId = invocation.getArgument(1);
            return jdbc.query("SELECT production_form,effective_from,effective_to FROM product_process_version WHERE id=?", (rs, row) ->
                    com.zencas.edhr.masterdata.entity.ProductProcessVersion.builder().id(versionId).productionMode("量产")
                            .productionForm(rs.getString(1)).effectiveFrom(rs.getTimestamp(2) == null ? null : rs.getTimestamp(2).toLocalDateTime())
                            .effectiveTo(rs.getTimestamp(3) == null ? null : rs.getTimestamp(3).toLocalDateTime()).build(), versionId).stream().findFirst();
        });
        jdbc.update("INSERT INTO work_order(id,tenant_id,order_no,product_id,planned_quantity,status,created_at,updated_at) VALUES(100,'default','WO01',1,2,'CREATED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)");
        jdbc.update("INSERT INTO production_object(id,tenant_id,work_order_id,object_no,object_type,process_version_id,target_quantity,good_quantity,ng_quantity,scrap_quantity,status,created_at,updated_at) VALUES(101,'default',100,'B01','BATCH',2,1,0,0,0,'CREATED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP),(102,'default',100,'SN01','SN',22,1,0,0,0,'CREATED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)");
    }

    @Test void lifecycleAuditRecordsOnlyRealObjectChangesForBatchAndSn() throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        for (long id : List.of(101L, 102L)) {
            action(id, "START", 0, "a", Map.of()).andExpect(status().isOk());
            assertObjectStatusAudits(id, List.of("CREATED"), List.of("IN_PROGRESS"));
            action(id, "START", 0, "a", Map.of()).andExpect(status().isBadRequest());
            action(id, "COMPLETE", 1, "a", Map.of()).andExpect(status().isOk());
            action(id, "START", 2, "b", Map.of()).andExpect(status().isOk());
            assertObjectStatusAudits(id, List.of("CREATED"), List.of("IN_PROGRESS"));
            action(id, "COMPLETE", 3, "b", Map.of()).andExpect(status().isOk());
            assertObjectStatusAudits(id, List.of("CREATED", "IN_PROGRESS"), List.of("IN_PROGRESS", "COMPLETED"));
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE entity_type='PRODUCTION_EXECUTION' AND entity_id=?", Integer.class, String.valueOf(id))).isEqualTo(4);
            mvc.perform(auth(get("/api/v1/audit/logs").param("entityType", "PRODUCTION_OBJECT").param("entityId", String.valueOf(id))))
                    .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(2))
                    .andExpect(jsonPath("$.data.content[0].action").value("UPDATE"));
        }
    }

    @Test void lifecycleAuditDoesNotRecordOrdinarySavesAsObjectChanges() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 20))).andExpect(status().isOk());
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 21))).andExpect(status().isOk());
        assertObjectStatusAudits(101, List.of("CREATED"), List.of("IN_PROGRESS"));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE entity_type='PRODUCTION_EXECUTION' AND entity_id='101'", Integer.class)).isEqualTo(3);
    }

    @org.junit.jupiter.params.ParameterizedTest
    @org.junit.jupiter.params.provider.ValueSource(strings = {"PRODUCTION_OBJECT", "PRODUCTION_EXECUTION"})
    void lifecycleAuditFailureRollsBackFirstStart(String failedType) throws Exception {
        doThrow(new IllegalStateException("synthetic audit failure")).when(audits).save(argThat(event -> event != null && failedType.equals(event.getEntityType())));
        try {
            action(101, "START", 0, "a", Map.of()).andExpect(status().is5xxServerError());
        } finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("CREATED");
        assertThat(jdbc.queryForObject("SELECT status FROM work_order WHERE id=100", String.class)).isEqualTo("CREATED");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isZero();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        assertObjectStatusAudits(101, List.of("CREATED"), List.of("IN_PROGRESS"));
    }

    @org.junit.jupiter.params.ParameterizedTest
    @org.junit.jupiter.params.provider.ValueSource(strings = {"PRODUCTION_OBJECT", "PRODUCTION_EXECUTION"})
    void lifecycleAuditFailureRollsBackFinalCompletion(String failedType) throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        jdbc.update("DELETE FROM production_object WHERE id=102");
        jdbc.update("UPDATE work_order SET planned_quantity=1 WHERE id=100");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "COMPLETE", 1, "a", Map.of()).andExpect(status().isOk());
        action(101, "START", 2, "b", Map.of()).andExpect(status().isOk());
        String state = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        int auditCount = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        doThrow(new IllegalStateException("synthetic audit failure")).when(audits).save(argThat(event -> event != null && failedType.equals(event.getEntityType())));
        try {
            action(101, "COMPLETE", 3, "b", Map.of()).andExpect(status().is5xxServerError());
        } finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT status FROM work_order WHERE id=100", String.class)).isEqualTo("IN_PROCESS");
        assertThat(jdbc.queryForObject("SELECT status FROM dhr_instance WHERE production_object_id=101", String.class)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(state);
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(3L);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(auditCount);
        action(101, "COMPLETE", 3, "b", Map.of()).andExpect(status().isOk());
        assertObjectStatusAudits(101, List.of("CREATED", "IN_PROGRESS"), List.of("IN_PROGRESS", "COMPLETED"));
        assertThat(jdbc.queryForObject("SELECT status FROM work_order WHERE id=100", String.class)).isEqualTo("COMPLETED");
    }

    private void assertObjectStatusAudits(long id, List<String> before, List<String> after) throws Exception {
        var events = jdbc.queryForList("SELECT * FROM audit_event WHERE entity_type='PRODUCTION_OBJECT' AND entity_id=? ORDER BY id", String.valueOf(id));
        assertThat(events).hasSize(before.size());
        for (int index = 0; index < events.size(); index++) {
            var event = events.get(index);
            assertThat(auditJson(event.get("content_before"))).isEqualTo(mapper.createObjectNode().put("status", before.get(index)));
            JsonNode afterSnapshot = auditJson(event.get("content_after"));
            assertThat(afterSnapshot.path("status").asText()).isEqualTo(after.get(index));
            if ("CREATED".equals(before.get(index))) {
                assertThat(afterSnapshot.path("processReference").path("ownerName").asText()).isEqualTo("导管");
                assertThat(afterSnapshot.path("processSnapshot").path("operations").isArray()).isTrue();
                assertThat(afterSnapshot.path("processFrozenAt").asText()).isNotBlank();
            } else assertThat(afterSnapshot.size()).isEqualTo(1);
            assertThat(event).containsEntry("action", "UPDATE").containsEntry("tenant_id", "default")
                    .containsEntry("operator_id", "1").containsEntry("operator_account", "operator");
            assertThat(event.get("created_at")).isNotNull();
        }
    }

    private JsonNode auditJson(Object value) throws Exception {
        return value instanceof byte[] bytes ? mapper.readTree(bytes) : mapper.readTree(value.toString());
    }

    private String retiredTraceModel(String id) {
        var model = mapper.createObjectNode();
        model.putArray("fields").addObject().put("id", "value").put("name", "历史字段").put("type", "text").put("status", "enabled");
        var projection = model.putObject("projection").put("version", "form-projection-v1");
        projection.putObject("lookupItems").putObject(id).put("name", "退役含义").put("type", "text");
        projection.putArray("bindings").addObject().put("id", "old-trace").put("modelId", "formTrace").put("enabled", true)
            .putObject("sources").put(id, "value");
        return model.toString();
    }

    @Test void retiredTraceTemplateCannotCreateNewExecutionOrDhrAndScanExplainsTheConfigurationError() throws Exception {
        org.mockito.Mockito.when(materials.findByTenantIdAndId("default", 1L)).thenReturn(java.util.Optional.of(
            com.zencas.edhr.masterdata.entity.Material.builder().id(1L).tenantId("default").code("P01").name("导管").build()));
        for (String id : new String[]{"serialNumberText", "lookup_related_batch", "teamText", "documentNumberText"}) {
            jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", retiredTraceModel(id));
            Integer audits = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
            mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.configurationError").value(org.hamcrest.Matchers.containsString("追溯项已停用")));
            action(101, "START", 0, "a", Map.of()).andExpect(status().isBadRequest());
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution WHERE object_id=101", Integer.class)).isZero();
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isZero();
            assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("CREATED");
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(audits);
        }
    }

    @Test void retiredTemplateCannotBeAttachedButExistingFrozenExecutionRemainsReadable() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String frozen = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        Integer audits = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        for (String id : new String[]{"serialNumberText", "lookup_related_batch", "teamText", "documentNumberText"}) {
            jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", retiredTraceModel(id));
            mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.configurationError").doesNotExist())
                .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].fields[0].id").value("temperature"));
            action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "required", false))
                .andExpect(status().isBadRequest());
            assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(frozen);
            assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1L);
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(audits);
        }
    }

    @Test void obsoleteTestSnapshotsCannotCreateNewCopiesOrPersistMoreRetiredTraceRecords() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        var frozen = (com.fasterxml.jackson.databind.node.ObjectNode) mapper.readTree(
            jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class));
        var oldModel = mapper.readTree(retiredTraceModel("teamText"));
        var form = (com.fasterxml.jackson.databind.node.ObjectNode) frozen.at("/operations/0/forms/0");
        form.set("fields", oldModel.path("fields")); form.set("projection", oldModel.path("projection"));
        jdbc.update("UPDATE production_execution SET snapshot_json=? WHERE object_id=101", frozen.toString());
        String state = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        Integer audits = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "旧测试记录不能再增份"))
            .andExpect(status().isBadRequest());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("value", "旧班组")))
            .andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM form_instance_record WHERE object_id=101", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1L);
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(state);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(audits);
    }

    @Test void firstStartRejectsUnconfiguredOperationModesWithoutExecutionDhrOrAuditWrites() throws Exception {
        for (String settings : java.util.Arrays.asList(null, "{}", "{\"formProcessVersionId\":\"999\"}")) {
            jdbc.update("UPDATE product_process_operation_form_binding SET fill_settings_json=? WHERE id=51", settings);
            Integer audits = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
            action(101, "START", 0, "a", Map.of()).andExpect(status().isBadRequest());
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution WHERE object_id=101", Integer.class)).isZero();
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isZero();
            assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("CREATED");
            assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(audits);
        }
    }

    @Test void inspectorChoiceOptionsSaveAndSubmitAgainstTheSameFrozenCanonicalValues() throws Exception {
        JsonNode fixture;
        try (var input = Objects.requireNonNull(getClass().getResourceAsStream("/fixtures/shared-choice-options-design.json"))) {
            fixture = mapper.readTree(input);
        }
        String tableId = fixture.path("tableId").asText(), fieldId = fixture.path("fieldId").asText();
        String model = fixture.at("/design/modelDesignJson").asText(), canvas = fixture.at("/design/canvasDesignJson").asText();
        JsonNode options = mapper.readTree(model).at("/payload/fields/0/typeConfig/columns/0/typeConfig/options");
        assertThat(options.get(0).path("value").asText()).isEqualTo("pass");
        assertThat(options.get(1).path("value").asText()).isEqualTo("fail");
        assertThat(fixture.path("values").path(tableId).get(0).path(fieldId).asText()).isEqualTo("pass");
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json=? WHERE id=5", model, canvas);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String frozen = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        // Subsequent template edits cannot replace this execution's chosen option set.
        jdbc.update("UPDATE form_template_version SET model_design_json='{\"fields\":[]}',canvas_design_json='{}' WHERE id=5");
        Map<String, Object> values = mapper.convertValue(fixture.path("values"), new com.fasterxml.jackson.core.type.TypeReference<>() {});
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", values)).andExpect(status().isOk());
        String saved = jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class);
        assertThat(mapper.readTree(saved).path(tableId).get(0).path(fieldId).asText()).isEqualTo("pass");
        JsonNode forged = fixture.path("values").deepCopy();
        ((com.fasterxml.jackson.databind.node.ObjectNode) forged.path(tableId).get(0)).put(fieldId, "unknown-option");
        Integer audits = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", forged)).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(2);
        assertThat(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class)).isEqualTo(saved);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(audits);
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", values)).andExpect(status().isOk());
        // Compare all frozen JSON content; serialization may normalize numeric lexemes such as 1.00.
        assertThat(mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)))
                .isEqualTo(mapper.readTree(frozen));
        assertThat(jdbc.queryForObject("SELECT status FROM form_instance_record WHERE object_id=101", String.class)).isEqualTo("COMPLETED");
    }

    @Test void referenceLookupUsesFrozenCanvasAndValidatesCurrentRowAtSave() throws Exception {
        String model = """
            {"fields":[{"id":"lookup","name":"账号","type":"text","status":"enabled"},
              {"id":"ref","name":"人员","type":"reference","status":"enabled","typeConfig":{"sourceType":"dictionary"}},
              {"id":"rows","name":"明细","type":"subTable","status":"enabled","typeConfig":{"columns":[
                {"id":"account","type":"text","status":"enabled","typeConfig":{}},
                {"id":"person","type":"reference","status":"enabled","typeConfig":{"sourceType":"user","referenceField":"username","referenceQueryConditions":[{"sourceField":"username","operator":"eq","targetFieldId":"account"}]}}
              ]}}]}
            """;
        String canvas = """
            {"pages":[{"nodes":[{"bindings":{"fieldId":"ref","widgetConfig":{"referenceSourceType":"user","referenceField":"username","referenceQueryConditions":[{"sourceField":"username","operator":"eq","targetFieldId":"lookup"}]}}}]}]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json=? WHERE id=5", model, canvas);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        Long revision = jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class);
        Integer auditsBefore = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        jdbc.update("UPDATE form_template_version SET canvas_design_json='{}' WHERE id=5");
        mvc.perform(auth(post("/api/v1/production/execution/101/references").contentType("application/json").content("""
            {"operationId":"a","formId":"form-51","fieldId":"ref","keyword":"operator","values":{"lookup":"operator"}}
            """))).andExpect(status().isOk()).andExpect(jsonPath("$.data[0].name").value("operator"));
        mvc.perform(auth(post("/api/v1/production/execution/101/references").contentType("application/json").content("""
            {"operationId":"a","formId":"form-51","fieldId":"ref","values":{}}
            """))).andExpect(status().isOk()).andExpect(jsonPath("$.data.length()").value(0));
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(auditsBefore);
        Map<String, Object> values = new HashMap<>(Map.of("lookup", "operator", "ref", Map.of("id", "1", "name", "operator"), "rows", List.of(
            Map.of("account", "operator", "person", Map.of("id", "1", "name", "operator")),
            Map.of("account", "other", "person", Map.of("id", "1", "name", "operator")))));
        action(101, "SAVE", revision, "a", Map.of("formId", "form-51", "values", values)).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(revision);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(auditsBefore);
        values.put("rows", List.of(Map.of("account", "operator", "person", Map.of("id", "1", "name", "operator"))));
        action(101, "SAVE", revision, "a", Map.of("formId", "form-51", "values", values)).andExpect(status().isOk());
        action(101, "SAVE", revision + 1, "a", Map.of("formId", "form-51", "values", Map.of("lookup", "other"))).andExpect(status().isBadRequest());
    }

    @Test void previewReferencesRequireDesignPermissionAndDoNotWriteData() throws Exception {
        String query = "{\"config\":{\"sourceType\":\"user\",\"referenceField\":\"username\"},\"keyword\":\"operator\"}";
        String endpoint = "/api/v1/master-data/template-modeling/reference-options";
        mvc.perform(auth(post(endpoint).contentType("application/json").content(query))).andExpect(status().isForbidden());
        mvc.perform(post(endpoint).contentType("application/json").content(query).header("Authorization", "Bearer " + tokens.generateToken("1", "operator", "测试", 5, List.of("master-data.form-templates"))))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data[0].name").value("operator"));
        mvc.perform(post("/api/v1/production/execution/101/references").contentType("application/json").content("{\"operationId\":\"a\",\"formId\":\"5\",\"fieldId\":\"ref\"}")
            .header("Authorization", "Bearer " + tokens.generateToken("1", "operator", "测试", 5, List.of("master-data.form-templates")))).andExpect(status().isForbidden());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isZero();
    }

    @Test void productionReferencesSaveTypedIdentityAndNumbersWithoutChangingExecutionOwnership() throws Exception {
        String model = """
            {"fields":[{"id":"batch","type":"reference","status":"enabled","typeConfig":{"sourceType":"productionBatch","referenceField":"workOrderNo"}},
              {"id":"order","type":"reference","status":"enabled","typeConfig":{"sourceType":"workOrder"}},
              {"id":"rows","type":"subTable","status":"enabled","typeConfig":{"columns":[
                {"id":"sn","type":"reference","status":"enabled","typeConfig":{"sourceType":"serialNumber"}}]}}]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", model);
        jdbc.update("INSERT INTO production_object(id,tenant_id,work_order_id,object_no,object_type,process_version_id,target_quantity,good_quantity,ng_quantity,scrap_quantity,status,created_at,updated_at) VALUES(103,'default',100,'B02','BATCH',2,1,0,0,0,'CREATED',CURRENT_TIMESTAMP,CURRENT_TIMESTAMP)");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String endpoint = "/api/v1/production/execution/101/references";
        mvc.perform(auth(post(endpoint).contentType("application/json").content("{\"operationId\":\"a\",\"formId\":\"form-51\",\"fieldId\":\"batch\",\"keyword\":\"B02\"}")))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data[0].id").value("103"))
                .andExpect(jsonPath("$.data[0].code").value("B02")).andExpect(jsonPath("$.data[0].name").value("WO01"))
                .andExpect(jsonPath("$.data[0].sourceType").value("productionBatch"));
        Map<String, Object> batch = Map.of("id", "103", "sourceType", "productionBatch", "code", "B02", "name", "WO01");
        Map<String, Object> values = Map.of("batch", batch, "order", Map.of("id", "100", "sourceType", "workOrder", "code", "WO01", "name", "WO01"),
                "rows", List.of(Map.of("sn", Map.of("id", "102", "sourceType", "serialNumber", "code", "SN01", "name", "SN01"))));
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", values)).andExpect(status().isOk());
        JsonNode saved = mapper.readTree(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class));
        assertThat(saved.path("batch").path("code").asText()).isEqualTo("B02");
        assertThat(saved.path("batch").path("id").asText()).isEqualTo("103");
        assertThat(saved.path("rows").get(0).path("sn").path("sourceType").asText()).isEqualTo("serialNumber");
        assertThat(jdbc.queryForObject("SELECT object_id FROM form_instance_record", Long.class)).isEqualTo(101);
        var forged = new HashMap<>(values);
        forged.put("batch", Map.of("id", "102", "sourceType", "productionBatch", "code", "SN01", "name", "WO01"));
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", forged)).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(2);
        assertThat(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class)).contains("B02");
    }

    @Test void contextualReferencesPersistOnceAndUseFrozenConfigurationAcrossReopenAndNewCopies() throws Exception {
        String model = """
            {"fields":[
             {"id":"batch","name":"批次","type":"reference","typeConfig":{"sourceType":"productionBatch","referenceContextAutofill":true,"referenceDisplayFields":["code","productName"]}},
             {"id":"product","name":"产品","type":"reference","typeConfig":{"sourceType":"product","referenceContextAutofill":true,"referenceDisplayFields":["code","name","specification"]}},
             {"id":"op","name":"工序","type":"reference","typeConfig":{"sourceType":"operation","referenceContextAutofill":true}},
             {"id":"sn","name":"SN","type":"reference","typeConfig":{"sourceType":"serialNumber","referenceContextAutofill":true}}
            ]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", model);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.values.batch.id").value("101"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.values.product.name").value("导管"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.values.op.id").value("11"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.referenceContextWarnings.sn").exists());
        String initialized = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(initialized);
        jdbc.update("UPDATE form_template_version SET model_design_json='{\"fields\":[]}' WHERE id=5");
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of())).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class)).contains("导管", "productionBatch");
        action(101, "ADD_FORM_COPY", 2, "a", Map.of("formId", "form-51", "remark", "重复报工")).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].values.product.code").value("P01"));
    }

    @Test void paginatedReferenceApiUsesConfiguredSearchFieldsWithoutChangingDisplayOrWriting() throws Exception {
        String model = """
            {"fields":[{"id":"ref","type":"reference","typeConfig":{"sourceType":"material","referenceDisplayFields":["code","name"],"referenceSearchFields":["specification"]}}]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", model);
        for (int i = 2; i <= 125; i++) jdbc.update("INSERT INTO material(id,tenant_id,code,name,specification,unit) VALUES(?,'default',?,'同名物料','SPEC-X','件')", i, "M-" + i);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        String endpoint = "/api/v1/production/execution/101/references";
        mvc.perform(auth(post(endpoint).contentType("application/json").content("{\"operationId\":\"a\",\"formId\":\"form-51\",\"fieldId\":\"ref\",\"keyword\":\"SPEC-X\",\"page\":5,\"size\":20}")))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.length()").value(21))
            .andExpect(jsonPath("$.data[0].id").value("102"))
            .andExpect(jsonPath("$.data[0].name").value("同名物料"));
        mvc.perform(auth(post(endpoint).contentType("application/json").content("{\"operationId\":\"a\",\"formId\":\"form-51\",\"fieldId\":\"ref\",\"keyword\":\"M-125\",\"page\":0,\"size\":20}")))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.length()").value(0));
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
    }

    @Test void inactiveReasonCanOnlyRemainUnchangedInItsPreviouslySavedSourceRow() throws Exception {
        jdbc.execute("CREATE TABLE IF NOT EXISTS quality_reason(id BIGINT PRIMARY KEY,tenant_id VARCHAR,reason_type VARCHAR,code VARCHAR,name VARCHAR,description VARCHAR,status VARCHAR)");
        jdbc.update("DELETE FROM quality_reason");
        jdbc.update("INSERT INTO quality_reason VALUES(501,'default','DEFECT','D01','划伤','外观不良','INACTIVE')");
        String model = """
            {"fields":[{"id":"rows","name":"不良明细","type":"subTable","typeConfig":{"columns":[
             {"id":"reason","name":"原因","type":"reference","typeConfig":{"sourceType":"defectReason","referenceDisplayFields":["code","name"]}},
             {"id":"quantity","name":"数量","type":"number"}]}}]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=?,canvas_design_json='{}' WHERE id=5", model);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        Map<String, String> selected = Map.of("id", "501", "sourceType", "defectReason", "code", "D01", "name", "划伤");
        Map<String, Object> row = Map.of("reason", selected, "quantity", 2);
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("rows", List.of(row)))).andExpect(status().isBadRequest());
        jdbc.update("UPDATE quality_reason SET status='ACTIVE' WHERE id=501");
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("rows", List.of(row)))).andExpect(status().isOk());
        JsonNode saved = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).at("/operations/a/forms/form-51/values/rows");
        jdbc.update("UPDATE quality_reason SET status='INACTIVE',name='更名原因' WHERE id=501");
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("rows", saved))).andExpect(status().isOk());
        var appended = saved.deepCopy();
        ((com.fasterxml.jackson.databind.node.ArrayNode) appended).add(mapper.valueToTree(row));
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "values", Map.of("rows", appended))).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(3);
        assertThat(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE object_id=101", String.class)).contains("划伤").doesNotContain("更名原因");
    }

    @Test void batchAndSnScanAreReadOnlyAndReturnCorrectConfiguration() throws Exception {
        for (String barcode : List.of("B01", "SN01")) {
            mvc.perform(auth(get("/api/v1/production/execution/scan").param("barcode", barcode))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.snapshot.context.objectNo").value(barcode))
                .andExpect(jsonPath("$.data.snapshot.context.workOrderNo").value("WO01"))
                .andExpect(jsonPath("$.data.snapshot.context.productName").value("导管"))
                .andExpect(jsonPath("$.data.snapshot.context.processVersion").value("配置V1"))
                .andExpect(jsonPath("$.data.snapshot.context.dhrName").value("导管生产记录"))
                .andExpect(jsonPath("$.data.availability.a.canStart").value(true))
                .andExpect(jsonPath("$.data.availability.b.canStart").value(false));
        }
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
    }

    @Test void outputUsesSavedPurposeFieldsAndFrozenMappingWithoutChangingBatchCounters() throws Exception {
        String model = """
            {"fields":[
              {"id":"temperature","name":"良品","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_GOOD"}},
              {"id":"ng","name":"不良","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_NG"}},
              {"id":"scrap","name":"报废","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_SCRAP"}}
            ]}
            """;
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", model);
        for (long object : List.of(101L, 102L)) {
            action(object, "START", 0, "a", Map.of()).andExpect(status().isOk())
                    .andExpect(jsonPath("$.data.operationOutputs.a.status").value("PENDING"));
action(object, "SAVE", 1, "a", Map.of("formId", object == 101 ? "form-51" : "form-61", "values", Map.of("temperature", "0.1", "ng", "0.2", "scrap", 0)))
                    .andExpect(status().isOk()).andExpect(jsonPath("$.data.operationOutputs.a.outputQuantity").isEmpty())
                    .andExpect(jsonPath("$.data.operationOutputs.a.goodQuantity").value("0.1"))
                    .andExpect(jsonPath("$.data.operationOutputs.b.status").value("NOT_CONFIGURED"));
        }
        jdbc.update("UPDATE form_template_version SET model_design_json='{}' WHERE id=5");
        int auditsBeforeRead = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.operationOutputs.a.outputQuantity").isEmpty())
                .andExpect(jsonPath("$.data.operationOutputs.a.goodQuantity").value("0.1"))
                .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].fields[0].typeConfig.businessPurpose").value("PRODUCTION_GOOD"));
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 2, "ng", 1, "scrap", 0)))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.operationOutputs.a.outputQuantity").isEmpty())
                .andExpect(jsonPath("$.data.operationOutputs.a.goodQuantity").value("2"));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isGreaterThan(auditsBeforeRead);
        assertThat(jdbc.queryForObject("SELECT good_quantity FROM production_object WHERE id=101", java.math.BigDecimal.class)).isEqualByComparingTo("0");
        String persisted = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        assertThat(mapper.readTree(persisted).at("/operations/a/forms/form-51/values/temperature").asInt()).isEqualTo(2);
    }

    @Test void dhrFillingProjectsAndFiltersProductionStatusWithoutChangingDhrOrWriteRules() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(102, "START", 0, "a", Map.of()).andExpect(status().isOk());
        jdbc.update("UPDATE production_object SET status='EARLY_TERMINATED' WHERE id=101");
        Long dhrId = jdbc.queryForObject("SELECT id FROM dhr_instance WHERE production_object_id=101", Long.class);
        String dhrBearer = "Bearer " + tokens.generateToken("1", "operator", "操作员", 5, List.of("dhr.instances.view"));
        mvc.perform(get("/api/v1/dhr-instances").header("Authorization", dhrBearer).param("status", "IN_PROGRESS").param("productionStatus", "EARLY_TERMINATED"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].productionObjectId").value("101"))
                .andExpect(jsonPath("$.data.content[0].status").value("IN_PROGRESS"))
                .andExpect(jsonPath("$.data.content[0].productionStatus").value("EARLY_TERMINATED"));
        mvc.perform(get("/api/v1/dhr-instances").header("Authorization", dhrBearer).param("status", "IN_PROGRESS").param("productionStatus", "IN_PROGRESS"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].productionObjectId").value("102"));
        mvc.perform(get("/api/v1/dhr-instances/" + dhrId).header("Authorization", dhrBearer))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.status").value("IN_PROGRESS"))
                .andExpect(jsonPath("$.data.productionStatus").value("EARLY_TERMINATED"));
        mvc.perform(get("/api/v1/dhr-instances").header("Authorization", dhrBearer).param("productionStatus", "INVALID"))
                .andExpect(status().isBadRequest());
        String token = tokens.generateToken("1", "operator", "操作员", 5, List.of("records.dhr-filling", "dhr.filling.act", "dhr.filling.supplement"));
        String bearer = "Bearer " + token;
        mvc.perform(get("/api/v1/dhr-filling").header("Authorization", bearer).param("displayStatus", "STATUS_ERROR").param("size", "1"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].productionObjectId").value("101"))
                .andExpect(jsonPath("$.data.content[0].productionStatus").value("EARLY_TERMINATED"))
                .andExpect(jsonPath("$.data.content[0].status").value("IN_PROGRESS"));
        mvc.perform(get("/api/v1/dhr-filling").header("Authorization", bearer).param("displayStatus", "FILLING"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].productionObjectId").value("102"));
        mvc.perform(get("/api/v1/dhr-filling").header("Authorization", bearer).param("displayStatus", "STATUS_ERROR").param("page", "1").param("size", "1"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content").isEmpty());
        mvc.perform(get("/api/v1/dhr-filling").header("Authorization", bearer).param("displayStatus", "INVALID"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/api/v1/dhr-filling/" + dhrId).header("Authorization", bearer))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.objectStatus").value("EARLY_TERMINATED"))
                .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.instances.form-51.canAct").value(false));
        mvc.perform(post("/api/v1/dhr-filling/" + dhrId + "/actions").header("Authorization", bearer).contentType("application/json")
                .content(mapper.writeValueAsString(Map.of("revision", 1, "action", "SAVE", "operationId", "a", "formId", "form-51", "values", Map.of("temperature", 99)))))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/dhr-filling/" + dhrId + "/supplements").header("Authorization", bearer).contentType("application/json")
                .content(mapper.writeValueAsString(Map.of("revision", 1, "operationId", "a", "formId", "form-51", "reason", "实际记录", "occurredAt", "2026-01-01T10:00:00"))))
                .andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT status FROM dhr_instance WHERE id=?", String.class, dhrId)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1L);
    }

    @Test void dhrSupplementUsesRealExecutionAndRecordServicesWithoutReopeningProduction() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        action(101, "END_FORM", 2, "a", Map.of("formId", "form-51")).andExpect(status().isOk());
        action(101, "COMPLETE", 3, "a", Map.of()).andExpect(status().isOk());
        action(101, "START", 4, "b", Map.of()).andExpect(status().isOk());
        action(101, "COMPLETE", 5, "b", Map.of()).andExpect(status().isOk());
        Long dhrId = jdbc.queryForObject("SELECT id FROM dhr_instance", Long.class);
        String original = jdbc.queryForObject("SELECT values_json FROM form_instance_record", String.class);
        String frozen = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        String token = tokens.generateToken("1", "operator", "操作员", 5, List.of("records.dhr-filling", "dhr.filling.act", "dhr.filling.supplement"));
        String root = "/api/v1/dhr-filling/" + dhrId;
        var response = mvc.perform(post(root + "/supplements").header("Authorization", "Bearer " + token).contentType("application/json")
                .content(mapper.writeValueAsString(Map.of("revision", 6, "operationId", "a", "formId", "form-51", "reason", "补充实际记录", "occurredAt", "2026-01-01T10:00:00"))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.objectStatus").value("COMPLETED")).andReturn();
        String copyId = mapper.readTree(response.getResponse().getContentAsString()).at("/data/createdCopyId").asText();
        assertThat(copyId).startsWith("dhr-copy-");
        var command = Map.of("revision", 7, "action", "SUBMIT", "operationId", "a", "formId", "form-51", "instanceId", copyId, "values", Map.of("temperature", 23));
        mvc.perform(post(root + "/actions").header("Authorization", "Bearer " + token).contentType("application/json").content(mapper.writeValueAsString(command)))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.objectStatus").value("COMPLETED"));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM form_instance_record", Integer.class)).isEqualTo(2);
        assertThat(jdbc.queryForObject("SELECT values_json FROM form_instance_record WHERE copy_id='form-51'", String.class)).isEqualTo(original);
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM form_instance_record WHERE copy_id=?", String.class, copyId)).contains("补充实际记录", "supplement");
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(frozen);
        assertThat(jdbc.queryForObject("SELECT status FROM dhr_instance", String.class)).isEqualTo("COMPLETED");
        // Even a DHR operator cannot edit a completed original through the supplementary endpoint.
        mvc.perform(post(root + "/actions").header("Authorization", "Bearer " + token).contentType("application/json")
                .content(mapper.writeValueAsString(Map.of("revision", 8, "action", "SAVE", "operationId", "a", "formId", "form-51", "instanceId", "form-51", "values", Map.of("temperature", 99)))))
                .andExpect(status().isBadRequest());
    }

    @Test void executionPersistsSnapshotDraftAndAuditThenCompletesOnlyAfterAllOperations() throws Exception {
        for (long object : List.of(101L, 102L)) {
            action(object, "START", 0, "a", Map.of()).andExpect(status().isOk());
            if (object == 101) jdbc.update("UPDATE route SET name='新的配置名称'");
            action(object, "COMPLETE", 1, "a", Map.of()).andExpect(status().isBadRequest());
            action(object, "SAVE", 1, "a", Map.of("formId", object == 101 ? "form-51" : "form-61", "values", Map.of("temperature", 22))).andExpect(status().isOk());
            mvc.perform(auth(get("/api/v1/production/execution/" + object))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.state.operations.a.forms." + (object == 101 ? "form-51" : "form-61") + ".values.temperature").value(22));
            action(object, "SUBMIT", 2, "a", Map.of("formId", object == 101 ? "form-51" : "form-61", "values", Map.of("temperature", 22))).andExpect(status().isOk());
            action(object, "END_FORM", 3, "a", Map.of("formId", object == 101 ? "form-51" : "form-61")).andExpect(status().isOk());
            action(object, "COMPLETE", 4, "a", Map.of()).andExpect(status().isOk());
            action(object, "START", 5, "b", Map.of()).andExpect(status().isOk());
            action(object, "COMPLETE", 6, "b", Map.of()).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.objectStatus").value("COMPLETED"));
        }
        assertThat(jdbc.queryForObject("SELECT status FROM work_order WHERE id=100", String.class)).isEqualTo("COMPLETED");
        assertThat(jdbc.queryForList("SELECT status FROM dhr_instance ORDER BY object_no", String.class)).containsExactly("COMPLETED", "COMPLETED");
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).contains("导管装配").doesNotContain("新的配置名称");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE entity_type='PRODUCTION_EXECUTION'", Integer.class)).isEqualTo(14);
    }

    @Test void formInstanceNumbersAreStableSearchableAndUseFrozenSnapshots() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        String number = jdbc.queryForObject("SELECT instance_no FROM form_instance_record", String.class);
        assertThat(number).matches("FR-\\d{8}-\\d{6,}");
        assertThat(jdbc.queryForObject("SELECT source_type FROM form_instance_record", String.class)).isEqualTo("PRODUCTION_EXECUTION");
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT instance_no FROM form_instance_record", String.class)).isEqualTo(number);
        jdbc.update("UPDATE form_template SET name='修改后的模板'");
        String readToken = tokens.generateToken("1", "operator", "操作员", 5, List.of("production.execution", "master-data.form-templates"));
        var list = mvc.perform(get("/api/v1/form-instance-records").header("Authorization", "Bearer " + readToken).param("templateId", "5").param("instanceNo", number))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].fieldValues.temperature").value(23)).andReturn();
        String id = mapper.readTree(list.getResponse().getContentAsString()).path("data").path("content").get(0).path("id").asText();
        mvc.perform(get("/api/v1/form-instance-records/" + id).param("templateId", "5").header("Authorization", "Bearer " + readToken))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.snapshot.name").value("装配记录"));
        mvc.perform(get("/api/v1/form-instance-records/" + id).param("templateId", "999").header("Authorization", "Bearer " + readToken)).andExpect(status().isBadRequest());
        mvc.perform(auth(get("/api/v1/form-instance-records").param("templateId", "5"))).andExpect(status().isForbidden());
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 4, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isOk());
        action(101, "SAVE", 5, "a", Map.of("formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT count(DISTINCT instance_no) FROM form_instance_record", Integer.class)).isEqualTo(2);
        String dhrToken = tokens.generateToken("1", "operator", "操作员", 5, List.of("dhr.instances.view"));
        var dhrList = mvc.perform(get("/api/v1/dhr-instances").header("Authorization", "Bearer " + dhrToken).param("objectType", "BATCH"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
                .andExpect(jsonPath("$.data.content[0].objectNo").value("B01"))
                .andExpect(jsonPath("$.data.content[0].status").value("IN_PROGRESS")).andReturn();
        String dhrId = mapper.readTree(dhrList.getResponse().getContentAsString()).path("data").path("content").get(0).path("id").asText();
        mvc.perform(get("/api/v1/dhr-instances/" + dhrId).header("Authorization", "Bearer " + dhrToken))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.directorySnapshot.directories[0].items[0].id").value("50"))
                .andExpect(jsonPath("$.data.directorySnapshot.directories[0].items[0].records.length()").value(2))
                .andExpect(jsonPath("$.data.evidenceSummary.recordCount").value(2));
        mvc.perform(auth(get("/api/v1/dhr-instances"))).andExpect(status().isForbidden());
    }

    @Test void firstStartAndDetailKeepSnowflakeDirectoryIdsAsStrings() throws Exception {
        long rootId = 377634999500804097L;
        long childId = 377634999500804098L;
        jdbc.update("UPDATE dhr_directory SET id=? WHERE id=40", rootId);
        jdbc.update("UPDATE dhr_template_item SET directory_id=? WHERE directory_id=40", rootId);
        jdbc.update("INSERT INTO dhr_directory VALUES(?,4,'子目录',?,2)", childId, rootId);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String frozen = jdbc.queryForObject("SELECT directory_snapshot FROM dhr_instance", String.class);
        JsonNode snapshot = mapper.readTree(frozen);
        assertThat(snapshot.at("/directories/0/id").isTextual()).isTrue();
        assertThat(snapshot.at("/directories/0/id").asText()).isEqualTo(Long.toString(rootId));
        assertThat(snapshot.at("/directories/1/parentId").asText()).isEqualTo(Long.toString(rootId));
        String token = tokens.generateToken("1", "operator", "操作员", 5, List.of("dhr.instances.view"));
        Long dhrId = jdbc.queryForObject("SELECT id FROM dhr_instance", Long.class);
        mvc.perform(get("/api/v1/dhr-instances/" + dhrId).header("Authorization", "Bearer " + token))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.directorySnapshot.directories[0].id").value(Long.toString(rootId)))
                .andExpect(jsonPath("$.data.directorySnapshot.directories[1].id").value(Long.toString(childId)))
                .andExpect(jsonPath("$.data.directorySnapshot.directories[1].parentId").value(Long.toString(rootId)));
        assertThat(jdbc.queryForObject("SELECT directory_snapshot FROM dhr_instance", String.class)).isEqualTo(frozen);
    }

    @Test void concurrentFirstSavesAllocateDifferentNumbers() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(102, "START", 0, "a", Map.of()).andExpect(status().isOk());
        try (var pool = Executors.newFixedThreadPool(2)) {
            var saves = List.of(101L, 102L).stream().map(id -> pool.submit(() -> {
                action(id, "SAVE", 1, "a", Map.of("formId", id == 101 ? "form-51" : "form-61", "values", Map.of("temperature", 22))).andExpect(status().isOk());
                return true;
            })).toList();
            for (var save : saves) assertThat(save.get(10, TimeUnit.SECONDS)).isTrue();
        }
        assertThat(jdbc.queryForObject("SELECT count(DISTINCT instance_no) FROM form_instance_record", Integer.class)).isEqualTo(2);
    }

    @Test void returnAndApprovalKeepTheOriginalFormNumber() throws Exception {
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        String number = jdbc.queryForObject("SELECT instance_no FROM form_instance_record", String.class);
        action(101, "RETURN", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "opinion", "请复核温度")).andExpect(status().isOk());
        action(101, "SUBMIT", 3, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 26))).andExpect(status().isOk());
        action(101, "APPROVE", 4, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "sign-secret")).andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT instance_no FROM form_instance_record", String.class)).isEqualTo(number);
        assertThat(jdbc.queryForObject("SELECT status FROM form_instance_record", String.class)).isEqualTo("COMPLETED");
    }

    @Test void failedAuditRollsBackFormInstanceAllocation() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        try {
            action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().is5xxServerError());
            assertThat(jdbc.queryForObject("SELECT count(*) FROM form_instance_record", Integer.class)).isZero();
        } finally { reset(audits); }
    }

    @Test void staleRevisionAndTerminatedObjectsCannotAdvance() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 0, "a", Map.of("formId", "form-51", "values", Map.of())).andExpect(status().isBadRequest());
        jdbc.update("UPDATE production_object SET status='EARLY_TERMINATED' WHERE id=101");
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of())).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1);
    }

    @Test void executionMissingDhrCannotComplete() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        action(101, "END_FORM", 3, "a", Map.of("formId", "form-51")).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "a", Map.of()).andExpect(status().isOk());
        action(101, "START", 5, "b", Map.of()).andExpect(status().isOk());
        jdbc.update("DELETE FROM dhr_instance WHERE production_object_id=101");

        action(101, "COMPLETE", 6, "b", Map.of()).andExpect(status().isBadRequest());

        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(6);
    }

    // H2 does not provide PostgreSQL's database-wide MVCC snapshot at REPEATABLE_READ.
    @org.junit.jupiter.api.condition.EnabledIfSystemProperty(named = "execution.test.driver", matches = "org\\.postgresql\\.Driver")
    @Test void firstStartFreezesOneCommittedConfigurationDuringProcessRebinding() throws Exception {
        jdbc.update("UPDATE production_object SET object_type='BATCH',process_version_id=2 WHERE id=102");
        // Both configurations are valid; the writer mirrors updateVersion's atomic parent/child replacement.
        jdbc.update("INSERT INTO route VALUES(13,'新路线','R02')");
        jdbc.update("INSERT INTO route_version VALUES(13,13,'V2')");
        jdbc.update("INSERT INTO route_node VALUES(21,13,'a',21,'O03','新装配','OPERATION','{}',1),(22,13,'b',22,'O04','新检验','OPERATION','{}',2)");
        jdbc.update("INSERT INTO route_relation VALUES(2,13,'a','b','SEQUENTIAL',NULL,1)");
        jdbc.update("INSERT INTO dhr_template VALUES(14,'新生产记录','D02')");
        jdbc.update("INSERT INTO dhr_template_version VALUES(14,14,'V2')");
        jdbc.update("INSERT INTO dhr_directory VALUES(140,14,'新记录',NULL,1)");
        jdbc.update("INSERT INTO form_template(id,name,code,category_name) VALUES(15,'新装配记录','F02','生产记录')");
        jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,model_design_json,canvas_design_json) SELECT 15,15,'V2',model_design_json,canvas_design_json FROM form_template_version WHERE id=5");
        jdbc.update("INSERT INTO dhr_template_item VALUES(150,140,15,15,'新装配记录',1,true)");
        JdbcTemplate snapshotJdbc = spy(jdbc);
        var intercepted = new java.util.concurrent.atomic.AtomicBoolean();
        try (var pool = Executors.newSingleThreadExecutor()) {
            doAnswer(invocation -> {
                invocation.callRealMethod();
                if (((String) invocation.getArgument(0)).contains("FROM product_process_version p")
                        && intercepted.compareAndSet(false, true)) {
                    pool.submit(() -> {
                        var writer = new org.springframework.transaction.support.TransactionTemplate(transactions);
                        writer.executeWithoutResult(status -> {
                            jdbc.update("UPDATE product_process_version SET route_version_id=13,dhr_template_version_id=14 WHERE id=2");
                            jdbc.update("DELETE FROM product_process_operation_form_binding WHERE product_process_operation_binding_id IN (11,12)");
                            jdbc.update("DELETE FROM product_process_operation_binding WHERE product_process_version_id=2");
                            jdbc.update("INSERT INTO product_process_operation_binding(id,product_process_version_id,route_node_key) VALUES(111,2,'a'),(112,2,'b')");
                            jdbc.update("INSERT INTO product_process_operation_form_binding VALUES(151,111,15,150,true,1,'{\"fillMode\":\"DIRECT\"}')");
                        });
                        // A later composition save removes the now-unreferenced item from the old DHR version.
                        writer.executeWithoutResult(status -> jdbc.update("DELETE FROM dhr_template_item WHERE id=50"));
                    }).get(5, TimeUnit.SECONDS);
                }
                return null;
            }).when(snapshotJdbc).query(anyString(), any(org.springframework.jdbc.core.RowCallbackHandler.class), any(Object[].class));
            org.springframework.test.util.ReflectionTestUtils.setField(snapshotBuilder, "jdbc", snapshotJdbc);
            try { action(101, "START", 0, "a", Map.of()).andExpect(status().isOk()); }
            finally { org.springframework.test.util.ReflectionTestUtils.setField(snapshotBuilder, "jdbc", jdbc); }
        }
        assertThat(intercepted).isTrue();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_template_item WHERE id=50", Integer.class)).isZero();
        JsonNode frozen = mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(frozen.path("context").path("routeVersionId").asText()).isEqualTo("3");
        assertThat(frozen.path("context").path("dhrTemplateVersionId").asText()).isEqualTo("4");
        assertThat(frozen.path("operations").get(0).path("forms").get(0).path("versionId").asText()).isEqualTo("5");
        assertThat(frozen.path("operations").get(0).path("forms").get(0).path("dhrItemId").asText()).isEqualTo("50");
        JsonNode directory = mapper.readTree(jdbc.queryForObject("SELECT directory_snapshot FROM dhr_instance WHERE production_object_id=101", String.class));
        assertThat(directory.path("directories").get(0).path("items").get(0).path("id").asText()).isEqualTo("50");
        action(102, "START", 0, "a", Map.of()).andExpect(status().isOk());
        JsonNode next = mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=102", String.class));
        assertThat(next.path("context").path("routeVersionId").asText()).isEqualTo("13");
        assertThat(next.path("context").path("dhrTemplateVersionId").asText()).isEqualTo("14");
        assertThat(next.path("operations").get(0).path("forms").get(0).path("versionId").asText()).isEqualTo("15");
        assertThat(next.path("operations").get(0).path("forms").get(0).path("dhrItemId").asText()).isEqualTo("150");
        assertThat(mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class))).isEqualTo(frozen);
    }

    @Test void concurrentStartCreatesOneExecutionAndOneDhr() throws Exception {
        try (var pool = Executors.newFixedThreadPool(2)) {
            Callable<Integer> start = () -> action(101, "START", 0, "a", Map.of()).andReturn().getResponse().getStatus();
            var results = pool.invokeAll(List.of(start, start));
            assertThat(List.of(results.get(0).get(), results.get(1).get())).containsExactlyInAnyOrder(200, 400);
        }
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE entity_type='PRODUCTION_EXECUTION'", Integer.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE entity_type='DHR_INSTANCE'", Integer.class)).isEqualTo(1);
    }

    @Test void failedAuditRollsBackObjectStateAndExecutionTogether() throws Exception {
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        action(101, "START", 0, "a", Map.of()).andExpect(status().is5xxServerError());
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("CREATED");
        assertThat(jdbc.queryForObject("SELECT status FROM work_order WHERE id=100", String.class)).isEqualTo("CREATED");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isZero();
    }

    @Test void waitingExecutionSeesConcurrentTerminationAfterAcquiringLocks() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        CountDownLatch locked = new CountDownLatch(1), release = new CountDownLatch(1), submitted = new CountDownLatch(1);
        try (var pool = Executors.newFixedThreadPool(2)) {
            var termination = pool.submit(() -> new org.springframework.transaction.support.TransactionTemplate(transactions).execute(status -> {
                jdbc.queryForObject("SELECT id FROM work_order WHERE id=100 FOR UPDATE", Long.class);
                production.endObject(101L, "并发终止验收"); locked.countDown();
                try { if (!release.await(5, TimeUnit.SECONDS)) throw new IllegalStateException("test timeout"); }
                catch (InterruptedException e) { throw new RuntimeException(e); }
                return true;
            }));
            assertThat(locked.await(5, TimeUnit.SECONDS)).isTrue();
            var write = pool.submit(() -> { submitted.countDown(); return action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 25))).andReturn().getResponse().getStatus(); });
            assertThat(submitted.await(5, TimeUnit.SECONDS)).isTrue();
            try { assertThatThrownBy(() -> write.get(200, TimeUnit.MILLISECONDS)).isInstanceOf(TimeoutException.class); }
            finally { release.countDown(); }
            assertThat(termination.get(5, TimeUnit.SECONDS)).isTrue();
            assertThat(write.get(5, TimeUnit.SECONDS)).isEqualTo(400);
        }
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("EARLY_TERMINATED");
        assertThat(jdbc.queryForObject("SELECT status FROM dhr_instance WHERE production_object_id=101", String.class)).isEqualTo("EARLY_TERMINATED");
    }

    @Test void earlyTerminationFreezesSavedEvidenceAndLeavesOtherObjectRunning() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(102, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        Long dhrId = jdbc.queryForObject("SELECT id FROM dhr_instance WHERE production_object_id=101", Long.class);

        production.endObject(101L, "设备故障");

        assertThat(jdbc.queryForObject("SELECT status FROM dhr_instance WHERE id=?", String.class, dhrId)).isEqualTo("EARLY_TERMINATED");
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("EARLY_TERMINATED");
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=102", String.class)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT snapshot_hash FROM dhr_termination WHERE dhr_instance_id=?", String.class, dhrId)).hasSize(64);
        String token = "Bearer " + tokens.generateToken("1", "operator", "操作员", 5, List.of("dhr.instances.view"));
        mvc.perform(get("/api/v1/dhr-instances/" + dhrId).header("Authorization", token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.displayStatus").value("TERMINATED"))
                .andExpect(jsonPath("$.data.terminationReason").value("设备故障"))
                .andExpect(jsonPath("$.data.directorySnapshot.directories[0].items[0].records[0].fieldValues.temperature").value(22));
        jdbc.update("UPDATE form_instance_record SET values_json='{\"temperature\":99}' WHERE object_id=101");
        mvc.perform(get("/api/v1/dhr-instances/" + dhrId).header("Authorization", token)).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.directorySnapshot.directories[0].items[0].records[0].fieldValues.temperature").value(22));
        assertThatThrownBy(() -> production.endObject(101L, "第二次结束")).hasMessageContaining("只有生产中的对象");
    }

    @Test void missingDhrBlocksEarlyTerminationWithoutChangingProduction() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        jdbc.update("DELETE FROM dhr_instance WHERE production_object_id=101");
        assertThatThrownBy(() -> production.endObject(101L, "设备故障")).hasMessageContaining("DHR 实例缺失");
        assertThat(jdbc.queryForObject("SELECT status FROM production_object WHERE id=101", String.class)).isEqualTo("IN_PROGRESS");
        assertThat(jdbc.queryForObject("SELECT count(*) FROM dhr_termination", Long.class)).isZero();
    }

    @Test void missingPermissionCannotReadOrExecute() throws Exception {
        String token = tokens.generateToken("1", "operator", "操作员", 5, List.of("production.work-orders"));
        mvc.perform(get("/api/v1/production/execution/scan").param("barcode", "B01").header("Authorization", "Bearer " + token)).andExpect(status().isForbidden());
        mvc.perform(post("/api/v1/production/execution/101/actions").contentType("application/json").content("{\"action\":\"START\",\"revision\":0,\"operationId\":\"a\"}").header("Authorization", "Bearer " + token)).andExpect(status().isForbidden());
    }

    @Test void configuredAndWorkFormsUsingTheSameTemplateRemainIndependent() throws Exception {
        seedConfirmationWork();
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.status").value("WAITING_OPERATION_START"))
            .andExpect(jsonPath("$.data.availability.a.formCopies.work-7-f.status").value("WAITING_OPERATION_START"));
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.status").value("ACTIVE"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.work-7-f.status").value("ACTIVE"))
            .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].fulfilledBy").doesNotExist())
            .andExpect(jsonPath("$.data.snapshot.operations[0].forms[1].dhrItemId").doesNotExist());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "work-7-f", "remark", "追加检验")).andExpect(status().isOk());
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        action(101, "SUBMIT", 3, "a", Map.of("formId", "work-7-f", "instanceId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].active[0]").value("f"));
        action(101, "SUBMIT", 4, "a", Map.of("formId", "work-7-f", "instanceId", "work-7-f:copy:2", "values", Map.of("temperature", 26))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].active[0]").value("c"))
            .andExpect(jsonPath("$.data.availability.a.formCopies.work-7-f.canAdd").value(false));
        action(101, "COMPLETE", 5, "a", Map.of()).andExpect(status().isBadRequest());
        action(101, "CONFIRM", 5, "a", Map.of("workId", "7", "nodeId", "c")).andExpect(status().isOk());
        action(101, "COMPLETE", 6, "a", Map.of()).andExpect(status().isOk());
        var persisted = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(persisted.path("history").findValuesAsText("actionCode")).filteredOn("AUTO_END_FORM"::equals).hasSize(1);
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM form_instance_record WHERE form_id='form-51'", String.class)).contains("dhrItemId");
        assertThat(jdbc.queryForList("SELECT snapshot_json FROM form_instance_record WHERE form_id='work-7-f'", String.class))
            .allSatisfy(snapshot -> assertThat(snapshot).doesNotContain("dhrItemId"));
        assertThat(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='SUBMIT' AND entity_id='101' ORDER BY created_at DESC LIMIT 1", String.class))
            .contains("ALL_COPIES_COMPLETED", "AUTO_END_FORM", "work-7-f:copy:2");
    }

    @Test void workCandidatesUseCurrentFamilyBeforeFirstStartWithoutCreatingInstancesOnRead() throws Exception {
        seedConfirmationWork();
        jdbc.update("INSERT INTO product_family_member VALUES(1,'default',1,10)");
        jdbc.update("UPDATE workflow_binding_rule SET product_family_id=10 WHERE id=7");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].works[0].id").value("7"));
        jdbc.update("UPDATE product_family_member SET product_family_id=20 WHERE id=1");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].works").isEmpty())
            .andExpect(jsonPath("$.data.state.operations.a.works").isEmpty());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isZero();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works").isEmpty())
            .andExpect(jsonPath("$.data.snapshot.context.processVersionId").value("2"));
    }

    @Test void workFamilyChangesPreserveExistingInstancesAndOnlyRefreshFutureOperations() throws Exception {
        seedConfirmationWork();
        jdbc.update("INSERT INTO product_family_member VALUES(1,'default',1,10)");
        jdbc.update("UPDATE workflow_binding_rule SET product_family_id=10,operation_id=NULL WHERE id=7");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String frozen = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        String state = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        JsonNode originalWork = mapper.readTree(frozen).at("/operations/0/works/0");
        assertThat(mapper.readTree(state).at("/operations/a/works/7/done")).containsExactly(mapper.getNodeFactory().textNode("s"));
        assertThat(mapper.readTree(state).at("/operations/a/works/7/active/0").asText()).isEqualTo("f");
        jdbc.update("UPDATE product_family_member SET product_family_id=20 WHERE id=1");
        jdbc.update("INSERT INTO workflow_definition(id,tenant_id,type,name) VALUES(8,'default','WORK','新簇检查')");
        jdbc.update("INSERT INTO workflow_definition_version SELECT 8,8,1,'PUBLISHED',true,nodes_json,edges_json FROM workflow_definition_version WHERE id=7");
        jdbc.update("INSERT INTO workflow_binding_rule VALUES(8,'default',8,'SCOPED',true,1,20,NULL)");
        // Removing the old rule and changing its source graph must not invalidate the existing instance.
        jdbc.update("DELETE FROM workflow_binding_rule WHERE id=7");
        jdbc.update("UPDATE workflow_definition_version SET nodes_json='[]' WHERE id=7");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].works.length()").value(1))
            .andExpect(jsonPath("$.data.snapshot.operations[0].works[0].id").value("7"))
            .andExpect(jsonPath("$.data.snapshot.operations[1].works[0].id").value("8"))
            .andExpect(jsonPath("$.data.state.operations.b.works").isEmpty());
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(frozen);
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(state);
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        action(101, "CONFIRM", 2, "a", Map.of("workId", "7", "nodeId", "c")).andExpect(status().isOk());
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "a", Map.of()).andExpect(status().isOk());
        // Re-publish between preview and START: creation must re-read the current published graph.
        jdbc.update("UPDATE workflow_definition_version SET is_current=false WHERE id=8");
        jdbc.update("INSERT INTO workflow_definition_version SELECT 9,8,2,'PUBLISHED',true,nodes_json,edges_json FROM workflow_definition_version WHERE id=8");
        action(101, "START", 5, "b", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[1].works[0].versionId").value("9"))
            .andExpect(jsonPath("$.data.snapshot.operations[1].works[0].matchContext.productFamilyId").value("20"))
            .andExpect(jsonPath("$.data.state.operations.b.works['8'].active[0]").value("f"));
        JsonNode saved = mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(saved.at("/operations/0/works/0")).isEqualTo(originalWork);
        assertThat(saved.path("context")).isEqualTo(mapper.readTree(frozen).path("context"));
        assertThat(saved.path("routeNodes")).isEqualTo(mapper.readTree(frozen).path("routeNodes"));
        var audit = jdbc.queryForMap("SELECT content_before,content_after FROM audit_event WHERE entity_type='PRODUCTION_EXECUTION' AND entity_id='101' AND function_name='START' ORDER BY id DESC LIMIT 1");
        assertThat(auditJson(audit.get("content_after")).at("/snapshot/operations/1/works/0/versionId").asText()).isEqualTo("9");
        assertThat(auditJson(audit.get("content_before")).at("/snapshot/operations/1/works")).isEmpty();
        action(101, "START", 6, "b", Map.of()).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(6);
    }

    @Test void workPlanExceptionIsRecheckedAtStartAndPassedOperationsAreNeverBackfilled() throws Exception {
        seedConfirmationWork();
        jdbc.update("UPDATE workflow_binding_rule SET operation_id=12 WHERE id=7");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isOk());
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[1].works[0].id").value("7"));
        jdbc.update("INSERT INTO workflow_binding_rule VALUES(8,'default',7,'EXCEPTION',true,1,NULL,12)");
        jdbc.update("INSERT INTO workflow_binding_rule VALUES(9,'default',7,'SCOPED',true,1,NULL,11)");
        action(101, "START", 3, "b", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works").isEmpty())
            .andExpect(jsonPath("$.data.state.operations.b.works").isEmpty());
        action(101, "COMPLETE", 4, "b", Map.of()).andExpect(status().isOk());
        String frozen = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        jdbc.update("DELETE FROM workflow_binding_rule WHERE id=8");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].works").isEmpty())
            .andExpect(jsonPath("$.data.snapshot.operations[1].works").isEmpty());
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(frozen);
    }

    @Test void workRefreshAndInstanceCreationRollBackTogetherWhenAuditFails() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isOk());
        seedConfirmationWork();
        jdbc.update("UPDATE workflow_binding_rule SET operation_id=12 WHERE id=7");
        String snapshot = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        String state = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        try { action(101, "START", 3, "b", Map.of()).andExpect(status().is5xxServerError()); }
        finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(snapshot);
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(state);
        action(101, "START", 3, "b", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.b.works.size()").value(1));
    }

    @Test void legacyFutureWorkPlansAreRefreshedButRealInstancesArePreserved() throws Exception {
        seedConfirmationWork();
        jdbc.update("UPDATE workflow_binding_rule SET operation_id=NULL WHERE id=7");
        var response = action(101, "START", 0, "a", Map.of()).andExpect(status().isOk()).andReturn();
        // Old releases stored future work plans at first START, without creating their work states.
        JsonNode preview = mapper.readTree(response.getResponse().getContentAsString()).at("/data/snapshot");
        jdbc.update("UPDATE production_execution SET snapshot_json=? WHERE object_id=101", preview.toString());
        jdbc.update("DELETE FROM workflow_binding_rule");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].works[0].id").value("7"))
            .andExpect(jsonPath("$.data.snapshot.operations[1].works").isEmpty())
            .andExpect(jsonPath("$.data.snapshot.operations[1].forms").isEmpty());
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(preview.toString());
    }

    @Test void invalidFutureWorkOnlyBlocksItsOwnStartAndDoesNotBreakExistingWork() throws Exception {
        seedConfirmationWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        jdbc.update("UPDATE workflow_binding_rule SET operation_id=12 WHERE id=7");
        jdbc.update("UPDATE workflow_definition_version SET is_current=false WHERE id=7");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.b.canStart").value(false))
            .andExpect(jsonPath("$.data.availability.b.startIssues").isNotEmpty())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].active[0]").value("f"));
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        action(101, "CONFIRM", 2, "a", Map.of("workId", "7", "nodeId", "c")).andExpect(status().isOk());
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 24))).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "a", Map.of()).andExpect(status().isOk());
        action(101, "START", 5, "b", Map.of()).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(5);
    }

    @Test void growingPendingWorkPreviewRemainsReadOnly() throws Exception {
        seedConfirmationWork();
        jdbc.update("UPDATE workflow_binding_rule SET product_id=999 WHERE id=7");
        for (int i = 1; i < 40; i++) {
            jdbc.update("INSERT INTO workflow_binding_rule VALUES(?,'default',7,'SCOPED',true,999,NULL,NULL)", 100 + i);
        }
        JdbcTemplate observedJdbc = spy(jdbc);
        var ruleQueries = new java.util.concurrent.atomic.AtomicInteger();
        var ruleRows = new java.util.concurrent.atomic.AtomicInteger();
        var membershipQueries = new java.util.concurrent.atomic.AtomicInteger();
        doAnswer(invocation -> {
            String sql = invocation.getArgument(0);
            boolean ruleQuery = sql.contains("FROM workflow_binding_rule");
            if (ruleQuery) ruleQueries.incrementAndGet();
            if (sql.contains("FROM product_family_member")) membershipQueries.incrementAndGet();
            org.springframework.jdbc.core.RowCallbackHandler callback = invocation.getArgument(1);
            jdbc.query(sql, (org.springframework.jdbc.core.RowCallbackHandler) row -> {
                if (ruleQuery) ruleRows.incrementAndGet();
                callback.processRow(row);
            }, (Object[]) invocation.getRawArguments()[2]);
            return null;
        }).when(observedJdbc).query(anyString(), any(org.springframework.jdbc.core.RowCallbackHandler.class), any(Object[].class));
        org.springframework.test.util.ReflectionTestUtils.setField(snapshotBuilder, "jdbc", observedJdbc);
        try {
            int existing = 2;
            for (int operationCount : List.of(2, 10, 50)) {
                for (int i = existing; i < operationCount; i++) {
                    jdbc.update("INSERT INTO route_node VALUES(?,3,?,?,?,'容量观察工序','OPERATION','{}',?)",
                            100 + i, "capacity-" + i, 100 + i, "CAP-" + i, i + 1);
                }
                existing = operationCount;
                ruleQueries.set(0); ruleRows.set(0); membershipQueries.set(0);
                mvc.perform(auth(get("/api/v1/production/execution/101")))
                        .andExpect(status().isOk())
                        .andExpect(jsonPath("$.data.snapshot.operations.length()").value(operationCount));
                // Capacity observations are not fixed query-count requirements for future implementations.
                System.out.printf("WORK_MATCH_OBSERVATION operations=%d rules=40 ruleQueries=%d ruleRows=%d membershipQueries=%d%n",
                        operationCount, ruleQueries.get(), ruleRows.get(), membershipQueries.get());
                assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM production_execution", Integer.class)).isZero();
                assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance", Integer.class)).isZero();
                assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isZero();
            }
        } finally {
            org.springframework.test.util.ReflectionTestUtils.setField(snapshotBuilder, "jdbc", jdbc);
        }
    }

    private void seedConfirmationWork() {
        jdbc.update("INSERT INTO workflow_definition(id,tenant_id,type,name) VALUES(7,'default','WORK','装配作业')");
        jdbc.update("INSERT INTO workflow_definition_version VALUES(7,7,1,'PUBLISHED',true,?,?)", """
            [{"id":"s","data":{"kind":"START"}},
             {"id":"f","data":{"kind":"FORM","config":{"formTemplateVersionId":"5","fillMode":"DIRECT"}}},
             {"id":"c","data":{"kind":"CONFIRMATION","label":"确认外观"}},
             {"id":"e","data":{"kind":"END"}}]
            """, """
            [{"source":"s","target":"f"},{"source":"f","target":"c"},{"source":"c","target":"e"}]
            """);
        jdbc.update("INSERT INTO workflow_binding_rule VALUES(7,'default',7,'SCOPED',true,1,NULL,11)");
    }

    @Test void legacyCompletedWorkProjectsNextNodeWithoutWritingAndSettlesOnTheNextAuditedAction() throws Exception {
        seedConfirmationWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        var legacy = (com.fasterxml.jackson.databind.node.ObjectNode) mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        var form = legacy.withObject("/operations/a/forms/work-7-f");
        form.put("status", "COMPLETED").put("lastSignatureId", "legacy-evidence");
        form.withObject("/values").put("temperature", 25);
        jdbc.update("UPDATE production_execution SET state_json=? WHERE object_id=101", legacy.toString());
        int beforeAudit = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].active[0]").value("c"));
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(legacy.toString());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(beforeAudit);
        action(101, "CONFIRM", 1, "a", Map.of("workId", "7", "nodeId", "c")).andExpect(status().isOk());
        var persisted = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(persisted.at("/operations/a/forms/work-7-f")).isEqualTo(form);
        assertThat(persisted.path("history").findValuesAsText("actionCode")).filteredOn("AUTO_END_FORM"::equals).hasSize(1);
        assertThat(jdbc.queryForObject("SELECT content_before FROM audit_event WHERE function_name='CONFIRM'", String.class)).doesNotContain("AUTO_END_FORM");
        assertThat(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='CONFIRM'", String.class)).contains("AUTO_END_FORM", "legacy-evidence");
    }

    @Test void automaticWorkAdvanceRollsBackWithItsSubmissionWhenAuditFails() throws Exception {
        seedConfirmationWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        try {
            action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().is5xxServerError());
        } finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM form_instance_record", Integer.class)).isZero();
    }

    @Test void inlineSignatureSavesWithoutSubmittingAndContentChangesInvalidateIt() throws Exception {
        seedInlineSignature();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SIGN_FIELD", 1, "a", inlineSign("wrong", Map.of("temperature", 25))).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of("temperature", 25))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].status").value("ACTIVE"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.sign.signerName").value("测试操作员"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.sign.signatureImageFileId").value("901"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].instanceNo").isNotEmpty());
        String signatureSnapshot = jdbc.queryForObject("SELECT snapshot_data FROM signature WHERE target_type='PRODUCTION_EXECUTION'", String.class);
        assertThat(signatureSnapshot).contains("temperature", "fieldId", "form-51", "versionId").doesNotContain("sign-secret", "password");
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of())).andExpect(status().isBadRequest());
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("sign", Map.of("signerName", "伪造")))).andExpect(status().isBadRequest());
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 26))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.sign").doesNotExist());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT content_before FROM audit_event WHERE function_name='SAVE'", String.class)).contains("signatureImageFileId");
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of())).andExpect(status().isBadRequest());
    }

    @Test void inlineSignatureRollsBackWhenAuditFails() throws Exception {
        seedInlineSignature();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any());
        try { action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of("temperature", 25))).andExpect(status().is5xxServerError()); }
        finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM form_instance_record", Integer.class)).isZero();
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
    }

    @Test void inlineSignatureRejectsUnavailableCertificationAndInvalidTargets() throws Exception {
        seedInlineSignature();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        var command = new HashMap<>(inlineSign("sign-secret", Map.of("temperature", 25)));
        command.put("signatureTarget", Map.of("fieldId", "temperature"));
        action(101, "SIGN_FIELD", 1, "a", command).andExpect(status().isBadRequest());
        command.put("signatureTarget", Map.of("fieldId", "sign")); command.put("instanceId", "foreign-copy");
        action(101, "SIGN_FIELD", 1, "a", command).andExpect(status().isBadRequest());
        jdbc.update("UPDATE signature SET expires_at=? WHERE id=900", java.time.LocalDateTime.now().minusDays(1));
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of())).andExpect(status().isBadRequest());
        jdbc.update("UPDATE signature SET expires_at=? WHERE id=900", java.time.LocalDateTime.now().plusDays(1));
        jdbc.update("UPDATE user_account SET status='DISABLED' WHERE id=1");
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of())).andExpect(status().isBadRequest());
        jdbc.update("UPDATE user_account SET status='ACTIVE' WHERE id=1");
        jdbc.update("DELETE FROM signature WHERE id=900");
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of())).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
    }

    @Test void inlineSignaturesCoexistAndSubtableContentInvalidatesAllWithoutDeletingEvidence() throws Exception {
        seedInlineSignature();
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", """
            {"fields":[{"id":"temperature","name":"温度","type":"number"},{"id":"sign","name":"领料人","type":"signature"},
            {"id":"rows","name":"明细","type":"subTable","typeConfig":{"columns":[{"id":"amount","name":"数量","type":"number"},{"id":"rowSign","name":"确认","type":"signature"}]}}]}
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of("temperature", 25, "rows", List.of(Map.of("amount", 1))))).andExpect(status().isOk());
        var command = new HashMap<>(inlineSign("sign-secret", Map.of()));
        command.put("signatureTarget", Map.of("fieldId", "rowSign", "tableId", "rows", "rowIndex", 0));
        action(101, "SIGN_FIELD", 2, "a", command).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.sign.signatureId").isNotEmpty())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.rows[0].rowSign.signatureId").isNotEmpty());
        action(101, "SIGN_FIELD", 3, "a", command).andExpect(status().isBadRequest());
        command.put("signatureTarget", Map.of("fieldId", "rowSign", "tableId", "rows", "rowIndex", 9));
        action(101, "SIGN_FIELD", 3, "a", command).andExpect(status().isBadRequest());
        var state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        var rows = state.path("operations").path("a").path("forms").path("form-51").path("values").path("rows").deepCopy();
        ((com.fasterxml.jackson.databind.node.ObjectNode) rows.get(0)).put("amount", 2);
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "values", Map.of("rows", rows))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.sign").doesNotExist())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.rows[0].rowSign").doesNotExist());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isEqualTo(2);
    }

    @Test void inlineSignatureHonorsFrozenReadonlyAndNodePermissions() throws Exception {
        seedInlineSignature();
        jdbc.update("UPDATE form_template_version SET canvas_design_json=? WHERE id=5", "{\"bindings\":{\"fieldId\":\"sign\",\"readonly\":true}}");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.a.forms['form-51'].signaturePermissions.sign").value("READ_ONLY"));
        action(101, "SIGN_FIELD", 1, "a", inlineSign("sign-secret", Map.of())).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
    }

    @Test void deletingSignedRowsInvalidatesRemainingSignaturesAndRejectsForgery() throws Exception {
        seedInlineSignature();
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", """
            {"fields":[{"id":"rows","name":"明细","type":"subTable","typeConfig":{"columns":[{"id":"amount","type":"number"},{"id":"rowSign","type":"signature"}]}}]}
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        var command = new HashMap<String, Object>(inlineSign("sign-secret", Map.of("rows", List.of(Map.of("amount", 1), Map.of("amount", 2)))));
        command.put("signatureTarget", Map.of("fieldId", "rowSign", "tableId", "rows", "rowIndex", 0));
        action(101, "SIGN_FIELD", 1, "a", command).andExpect(status().isOk());
        command.put("values", Map.of());
        command.put("signatureTarget", Map.of("fieldId", "rowSign", "tableId", "rows", "rowIndex", 1));
        action(101, "SIGN_FIELD", 2, "a", command).andExpect(status().isOk());
        var rows = (com.fasterxml.jackson.databind.node.ArrayNode) mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class))
            .path("operations").path("a").path("forms").path("form-51").path("values").path("rows").deepCopy();
        rows.remove(0);
        var forged = rows.deepCopy();
        ((com.fasterxml.jackson.databind.node.ObjectNode) forged.get(0).path("rowSign")).put("signerName", "伪造");
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "values", Map.of("rows", forged))).andExpect(status().isBadRequest());
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "values", Map.of("rows", rows))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.rows[0].amount").value(2))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.rows[0].rowSign").doesNotExist());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isEqualTo(2);
    }

    @Test void subtableCanvasReadonlyIsEnforcedForNewAndLegacySnapshots() throws Exception {
        seedInlineSignature();
        jdbc.update("UPDATE form_template_version SET model_design_json=?, canvas_design_json=? WHERE id=5", """
            {"fields":[{"id":"rows","name":"明细","type":"subTable","typeConfig":{"columns":[{"id":"rowSign","type":"signature"}]}}]}
            """, "{\"bindings\":{\"subTableId\":\"rows\",\"subTableFieldId\":\"rowSign\",\"readonly\":true}}");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].fields[0].typeConfig.columns[0].readOnly").value(true));
        var command = new HashMap<String, Object>(inlineSign("sign-secret", Map.of("rows", List.of(Map.of()))));
        command.put("signatureTarget", Map.of("fieldId", "rowSign", "tableId", "rows", "rowIndex", 0));
        action(101, "SIGN_FIELD", 1, "a", command).andExpect(status().isBadRequest());
        var snapshot = mapper.readTree(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class));
        ((com.fasterxml.jackson.databind.node.ObjectNode) snapshot.path("operations").get(0).path("forms").get(0).path("fields").get(0).path("typeConfig").path("columns").get(0)).remove("readOnly");
        jdbc.update("UPDATE production_execution SET snapshot_json=? WHERE object_id=101", mapper.writeValueAsString(snapshot));
        action(101, "SIGN_FIELD", 1, "a", command).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
    }

    private void seedInlineSignature() {
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", """
            {"fields":[{"id":"temperature","name":"温度","type":"number","status":"enabled"},
              {"id":"sign","name":"领料人","type":"signature","required":true,"status":"enabled","typeConfig":{}}]}
            """);
        new org.springframework.transaction.support.TransactionTemplate(transactions).executeWithoutResult(status -> signatures.save(Signature.builder()
            .id(900L).targetType("USER_PROFILE").targetId("1").signerId("1").signerName("测试操作员")
            .signaturePasswordHash(passwords.encode("sign-secret")).snapshotData("{\"signatureImage\":{\"fileId\":\"901\"}}")
            .signedAt(java.time.LocalDateTime.now()).expiresAt(java.time.LocalDateTime.now().plusDays(1)).build()));
        jdbc.update("DELETE FROM file_object WHERE id=901");
        jdbc.update("INSERT INTO file_object(id,tenant_id,original_name,mime_type,stored_path,file_size) VALUES(901,'default','signature.png','image/png','test-signature.png',1)");
    }

    private Map<String, Object> inlineSign(String password, Map<String, Object> values) {
        return Map.of("formId", "form-51", "instanceId", "form-51", "values", values, "password", password, "signatureTarget", Map.of("fieldId", "sign"));
    }

    @Test void realApprovalIdentityAndSignaturePasswordPersistAtomically() throws Exception {
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].active[0]").value("f"))
            .andExpect(jsonPath("$.data.state.operations.a.formGroups.work-7-f.ended").value(false));
        String other = tokens.generateToken("2", "other", "其他人员", 5, List.of("production.execution"));
        mvc.perform(post("/api/v1/production/execution/101/actions").header("Authorization", "Bearer " + other).contentType("application/json")
            .content("{\"action\":\"APPROVE\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"))
            .andExpect(status().isBadRequest());
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "wrong")).andExpect(status().isBadRequest());
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "test-secret")).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "sign-secret")).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.works['7'].status").value("COMPLETED"))
            .andExpect(jsonPath("$.data.state.operations.a.formGroups.work-7-f.endedReason").value("ALL_COPIES_COMPLETED"));
        assertThat(jdbc.queryForObject("SELECT signer_id FROM signature WHERE target_type='PRODUCTION_EXECUTION'", String.class)).isEqualTo("1");
        assertThat(jdbc.queryForObject("SELECT snapshot_data FROM signature WHERE target_type='PRODUCTION_EXECUTION'", String.class)).contains("temperature").doesNotContain("sign-secret", "password");
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "a", Map.of()).andExpect(status().isOk());
    }

    @Test void legacyTextSubtableColumnsUseTheSameStableIdsAsTheUnifiedRenderer() throws Exception {
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", """
            {"fields":[{"id":"rows","name":"检测记录","type":"subTable","typeConfig":{"columns":"项目,结果"}}]}
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].fields[0].typeConfig.columns[0].id").value("sub-field-1"));
        action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("rows", List.of(Map.of("sub-field-1", "外观", "sub-field-2", "合格")))))
            .andExpect(status().isOk());
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isOk());
    }

    @Test void remarkEditPersistsAuditsAndPreservesSubmittedFormReceipt() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        var expected = (com.fasterxml.jackson.databind.node.ObjectNode) mapper.readTree(before).at("/operations/a/forms/form-51");
        expected.put("remark", "已提交份的补充说明");
        String recordBefore = jdbc.queryForMap("SELECT * FROM form_instance_record WHERE copy_id='form-51'").toString();
        action(101, "UPDATE_FORM_COPY_REMARK", 2, "a", Map.of("formId", "form-51", "instanceId", "form-51", "remark", "  已提交份的补充说明  "))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.availability.a.formCopies.form-51.canEditRemark").value(true));
        String after = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        assertThat(mapper.readTree(after).at("/operations/a/forms/form-51")).isEqualTo(expected);
        assertThat(jdbc.queryForMap("SELECT * FROM form_instance_record WHERE copy_id='form-51'").toString()).isEqualTo(recordBefore);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.remark").value("已提交份的补充说明"));
        assertThat(mapper.readTree(jdbc.queryForObject("SELECT content_before FROM audit_event WHERE function_name='UPDATE_FORM_COPY_REMARK'", String.class)).path("execution")).isEqualTo(mapper.readTree(before));
        assertThat(mapper.readTree(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='UPDATE_FORM_COPY_REMARK'", String.class)).path("execution")).isEqualTo(mapper.readTree(after));
        action(101, "UPDATE_FORM_COPY_REMARK", 2, "a", Map.of("formId", "form-51", "instanceId", "form-51", "remark", "过期修改")).andExpect(status().isBadRequest());
        for (Map<String, Object> body : List.<Map<String, Object>>of(
            Map.of("formId", "form-51", "instanceId", "foreign", "remark", "越界修改"),
            Map.of("formId", "form-51", "remark", "缺少份序"),
            Map.of("formId", "form-51", "instanceId", "form-51", "remark", " "),
            Map.of("formId", "form-51", "instanceId", "form-51", "remark", "x".repeat(501)))) {
            action(101, "UPDATE_FORM_COPY_REMARK", 3, "a", body).andExpect(status().isBadRequest());
        }
        int auditCount = jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class);
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        try {
            action(101, "UPDATE_FORM_COPY_REMARK", 3, "a", Map.of("formId", "form-51", "instanceId", "form-51", "remark", "不应保存")).andExpect(status().is5xxServerError());
            assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(after);
            assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(3L);
            assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class)).isEqualTo(auditCount);
        } finally { reset(audits); }
    }

    @Test void copyMetadataPersistsAndSurvivesSaveWithoutChangingItsCreationIdentity() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdById").value("1"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdAt").isNotEmpty());
        String result = action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "  留样复检  ")).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].remark").value("留样复检"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].createdByName").isNotEmpty())
            .andReturn().getResponse().getContentAsString();
        var created = mapper.readTree(result).at("/data/state/operations/a/forms/form-51:copy:2");
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].remark").value("留样复检"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].createdAt").value(created.path("createdAt").asText()))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].instanceNo").isNotEmpty());
        assertThat(jdbc.queryForObject("SELECT reason FROM audit_event WHERE function_name='ADD_FORM_COPY' AND entity_id='101'", String.class)).isEqualTo("留样复检");
        assertThat(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='ADD_FORM_COPY' AND entity_id='101'", String.class))
            .contains("留样复检", "createdById", "createdAt");
    }

    @Test void historicalCopyMetadataUsesRecordedSourcesWithoutWritingOrInventingMissingValues() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "已有备注")).andExpect(status().isOk());
        var state = (com.fasterxml.jackson.databind.node.ObjectNode) mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        for (JsonNode copy : state.at("/operations/a/forms")) ((com.fasterxml.jackson.databind.node.ObjectNode) copy).remove(List.of("createdAt", "createdById", "createdByName"));
        String legacy = state.toString();
        jdbc.update("UPDATE production_execution SET state_json=? WHERE object_id=101", legacy);
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdAt").doesNotExist())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdByName").doesNotExist())
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].createdAt").value(state.at("/operations/a/forms/form-51:copy:2/explicitCreatedAt").asText()))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].createdByName").isNotEmpty());
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(legacy);
        action(101, "SAVE", 2, "a", Map.of("formId", "form-51", "instanceId", "form-51", "values", Map.of())).andExpect(status().isOk());
        jdbc.update("UPDATE form_instance_record SET created_by='历史填报人',created_at=TIMESTAMP '2026-09-01 08:30:00' WHERE copy_id='form-51'");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdAt").value("2026-09-01T08:30"))
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdByName").value("历史填报人"));
        jdbc.update("UPDATE form_instance_record SET legacy=TRUE WHERE copy_id='form-51'");
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdAt").doesNotExist())
            .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.createdByName").doesNotExist());
    }

    @Test void invalidCopyRemarksAndFailedAuditCannotCreateCopies() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        int auditCount = jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class);
        for (Map<String, Object> body : List.<Map<String, Object>>of(Map.of("formId", "form-51"), Map.of("formId", "form-51", "remark", " \n "), Map.of("formId", "form-51", "remark", "x".repeat(501)))) {
            action(101, "ADD_FORM_COPY", 1, "a", body).andExpect(status().isBadRequest());
            assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        }
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(any(AuditEvent.class));
        try {
            action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "留样复检")).andExpect(status().is5xxServerError());
            assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
            assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(1L);
            assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class)).isEqualTo(auditCount);
        } finally { reset(audits); }
    }

    @Test void copiesPersistSeparateValuesSumOutputAndRejectStaleOrForeignWrites() throws Exception {
        jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", """
            {"fields":[{"id":"good","name":"良品","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_GOOD"}},
            {"id":"ng","name":"不良","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_NG"}},
            {"id":"scrap","name":"报废","type":"number","typeConfig":{"businessPurpose":"PRODUCTION_SCRAP"}}]}
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        jdbc.update("UPDATE form_template SET category_name='修改后的分类'");
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("good", 10, "ng", 0, "scrap", 0))).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 2, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.instanceIds.length()").value(2));
        action(101, "ADD_FORM_COPY", 2, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isBadRequest());
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "instanceId", "other-copy", "values", Map.of())).andExpect(status().isBadRequest());
        action(101, "SAVE", 3, "a", Map.of("formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of("good", 12, "ng", 0, "scrap", 0))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.operationOutputs.a.goodQuantity").value("22"));
        action(101, "END_FORM", 4, "a", Map.of("formId", "form-51", "acknowledgeIncomplete", true)).andExpect(status().isBadRequest());
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.snapshot.operations[0].forms[0].categoryName").value("生产记录"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51'].values.good").value(10))
            .andExpect(jsonPath("$.data.state.operations.a.forms['form-51:copy:2'].values.good").value(12))
            .andExpect(jsonPath("$.data.operationOutputs.a.goodQuantity").value("22"));
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).contains("form-51:copy:2", "新增表单份", "第 2 份");
        action(101, "SUBMIT", 4, "a", Map.of("formId", "form-51", "instanceId", "form-51", "values", Map.of())).andExpect(status().isOk());
        action(101, "COMPLETE", 5, "a", Map.of()).andExpect(status().isBadRequest());
        action(101, "SUBMIT", 5, "a", Map.of("formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of())).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.a.canComplete").value(true))
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.canAdd").value(true));
        action(101, "COMPLETE", 6, "a", Map.of()).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.formGroups.form-51.endedReason").value("OPERATION_COMPLETE"));
        assertThat(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='COMPLETE' AND entity_id='101'", String.class))
            .contains("OPERATION_COMPLETE", "form-51:copy:2");
    }

    @Test void optionalCopyCompletionRequiresAcknowledgementAndPersistsUnfinishedState() throws Exception {
        jdbc.update("UPDATE product_process_operation_form_binding SET required=false WHERE id=51");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isOk());
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isBadRequest());
        action(101, "COMPLETE", 2, "a", Map.of("acknowledgeIncomplete", true)).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.status").value("COMPLETED"))
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.status").value("IN_PROGRESS"))
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.canAdd").value(false))
            .andExpect(jsonPath("$.data.availability.a.formCopies.form-51.instances['form-51:copy:2'].canAct").value(false));
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of("temperature", 30))).andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).contains("第 2 份未完成", "已告知", "保持进行中");
    }

    @Test void customFormsFreezeSelectedVersionAndRequireExplicitRequiredChoice() throws Exception {
        jdbc.update("UPDATE form_template_version SET status='DRAFT' WHERE id=5");
        mvc.perform(auth(get("/api/v1/production/execution/form-templates"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data[0].versionId").value("5"));
        action(101, "ATTACH_FORM", 0, "a", Map.of("templateVersionId", "5", "required", true)).andExpect(status().isBadRequest());
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5")).andExpect(status().isBadRequest());
        action(101, "ATTACH_FORM", 1, "b", Map.of("templateVersionId", "5", "required", true)).andExpect(status().isBadRequest());
        String response = action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "required", true)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String formId = mapper.readTree(response).path("data").path("attachedFormId").asText();
        assertThat(formId).startsWith("custom-");
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).contains(formId, "CUSTOM", "attachedBy", "temperature");
        assertThat(jdbc.queryForObject("SELECT content_after FROM audit_event WHERE function_name='ATTACH_FORM'", String.class)).contains("snapshot", formId, "required");
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isBadRequest());
        jdbc.update("UPDATE form_template_version SET model_design_json='{}' WHERE id=5");
        jdbc.update("UPDATE form_template SET status='INACTIVE' WHERE id=5");
        mvc.perform(auth(get("/api/v1/production/execution/form-templates"))).andExpect(jsonPath("$.data.length()").value(0));
        action(101, "ATTACH_FORM", 2, "a", Map.of("templateVersionId", "5", "required", false)).andExpect(status().isBadRequest());
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(jsonPath("$.data.snapshot.operations[0].forms[1].fields[0].id").value("temperature"));
        action(101, "SUBMIT", 2, "a", Map.of("formId", formId, "values", Map.of("temperature", 30))).andExpect(status().isOk());
        action(101, "END_FORM", 3, "a", Map.of("formId", formId)).andExpect(status().isOk());
    }

    @Test void customFormTemplatesSearchAllVersionsWithoutPublicationAndKeepTenantBoundaries() throws Exception {
        jdbc.update("UPDATE form_template_version SET status='DRAFT' WHERE id=5");
        jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,status) VALUES(6,5,'V2','DRAFT')");
        jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,tenant_id) VALUES(7,5,'V3','other')");
        mvc.perform(auth(get("/api/v1/production/execution/form-templates")))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.length()").value(2))
            .andExpect(jsonPath("$.data[0].templateId").value("5"))
            .andExpect(jsonPath("$.data[0].categoryName").value("生产记录"))
            .andExpect(jsonPath("$.data[0].versionId").value("6"))
            .andExpect(jsonPath("$.data[1].versionId").value("5"));
        mvc.perform(auth(get("/api/v1/production/execution/form-templates").param("keyword", "no-match")))
            .andExpect(jsonPath("$.data.length()").value(0));
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "7", "required", false)).andExpect(status().isBadRequest());
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "999", "required", false)).andExpect(status().isBadRequest());
        jdbc.update("UPDATE form_template SET tenant_id='other' WHERE id=5");
        mvc.perform(auth(get("/api/v1/production/execution/form-templates")))
            .andExpect(jsonPath("$.data.length()").value(0));
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "required", false)).andExpect(status().isBadRequest());
    }

    @Test void customTemplatePickerDoesNotTruncateVersions() throws Exception {
        for (int version = 1; version <= 101; version++) {
            jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,status) VALUES(?,5,?,'DRAFT')", 1000 + version, "V" + version);
        }
        mvc.perform(auth(get("/api/v1/production/execution/form-templates")))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.length()").value(102))
            .andExpect(jsonPath("$.data[101].versionId").value("5"))
            .andExpect(jsonPath("$.data[101].templateId").value("5"));
    }

    @Test void historicalExecutionWithoutDhrCanAttachCustomFormWithoutFabricatingDhr() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        jdbc.update("DELETE FROM dhr_instance WHERE production_object_id=101");
        mvc.perform(auth(get("/api/v1/production/execution/101")))
                .andExpect(jsonPath("$.data.availability.a.canAttachScopedForm").value(true));
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "BATCH", "completionRequired", true, "reason", "历史批次补充检验"))
                .andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM dhr_instance WHERE production_object_id=101", Integer.class)).isZero();
    }

    @Test void batchCustomFormSurvivesOperationCompletionAndGatesOnlyBatch() throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String response = action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "BATCH", "completionRequired", true, "reason", "跨工序检验"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String form = mapper.readTree(response).path("data").path("attachedFormId").asText();
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.objectStatus").value("IN_PROGRESS"));
        action(101, "START", 3, "b", Map.of()).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "b", Map.of()).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.state.operations.b.status").value("COMPLETED"))
                .andExpect(jsonPath("$.data.objectStatus").value("IN_PROGRESS"))
                .andExpect(jsonPath("$.data.batchCompletionIssues.length()").value(1))
                .andExpect(jsonPath("$.data.availability.a.formCopies['" + form + "'].instances['" + form + "'].canAct").value(true));
        action(101, "SAVE", 5, "a", Map.of("formId", form, "instanceId", form, "values", Map.of("temperature", 20)))
                .andExpect(status().isOk());
        action(101, "SUBMIT", 6, "a", Map.of("formId", form, "instanceId", form, "values", Map.of("temperature", 20)))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.objectStatus").value("COMPLETED"))
                .andExpect(jsonPath("$.data.recordCompleteness").value("COMPLETE"));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM form_instance_record WHERE form_id=?", Integer.class, form)).isEqualTo(1);
        assertThat(jdbc.queryForObject("SELECT operation_name FROM form_instance_record WHERE form_id=?", String.class, form)).isEqualTo("批次补充记录");
        assertObjectStatusAudits(101, List.of("CREATED", "IN_PROGRESS"), List.of("IN_PROGRESS", "COMPLETED"));
    }

    @Test void optionalCustomFormCanBeFinishedAfterProductionWithReasonAndFrozenDhrProtection() throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String response = action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "OPERATION", "completionRequired", false, "reason", "追加说明"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String form = mapper.readTree(response).path("data").path("attachedFormId").asText();
        assertThat(mapper.readTree(response).path("data").path("availability").path("a").path("formCopies").path(form).path("canEnd").asBoolean()).isFalse();
        action(101, "COMPLETE", 2, "a", Map.of("acknowledgeIncomplete", true)).andExpect(status().isOk());
        action(101, "START", 3, "b", Map.of()).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "b", Map.of()).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.objectStatus").value("COMPLETED"))
                .andExpect(jsonPath("$.data.recordCompleteness").value("INCOMPLETE"));
        action(101, "SUBMIT", 5, "a", Map.of("formId", form, "values", Map.of("temperature", 20))).andExpect(status().isBadRequest());
        for (String summary : List.of("PENDING_REVIEW", "FORMALIZED")) {
            jdbc.update("UPDATE dhr_instance SET summary_status=?", summary);
            action(101, "SUBMIT", 5, "a", Map.of("formId", form, "values", Map.of("temperature", 20), "reason", "补齐记录")).andExpect(status().isBadRequest());
        }
        jdbc.update("UPDATE dhr_instance SET summary_status='DRAFT'");
        action(101, "SUBMIT", 5, "a", Map.of("formId", form, "values", Map.of("temperature", 20), "reason", "补齐记录"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.data.objectStatus").value("COMPLETED"))
                .andExpect(jsonPath("$.data.recordIssues.length()").value(0));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event WHERE function_name='SUBMIT' AND reason='补齐记录'", Integer.class)).isEqualTo(1);
    }

    @Test void operationCustomGateAndExplicitScopeValidationCannotBeBypassed() throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "BATCH", "completionRequired", true)).andExpect(status().isBadRequest());
        action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "unknown", "completionRequired", true, "reason", "说明")).andExpect(status().isBadRequest());
        String response = action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "scope", "OPERATION", "completionRequired", true, "reason", "检验"))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String form = mapper.readTree(response).path("data").path("attachedFormId").asText();
        action(101, "ADD_FORM_COPY", 2, "a", Map.of("formId", form, "remark", "复检")) .andExpect(status().isOk());
        action(101, "SUBMIT", 3, "a", Map.of("formId", form, "instanceId", form, "values", Map.of("temperature", 20))).andExpect(status().isOk());
        action(101, "COMPLETE", 4, "a", Map.of("acknowledgeIncomplete", true)).andExpect(status().isBadRequest());
        action(101, "SUBMIT", 4, "a", Map.of("formId", form, "instanceId", form + ":copy:2", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        action(101, "COMPLETE", 5, "a", Map.of()).andExpect(status().isOk());
    }

    @Test void presenceCountsEditorsAcrossCopiesAndRejectsReadOnlyInstances() throws Exception {
        jdbc.update("UPDATE user_account SET avatar_file_id=123 WHERE id=1");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isOk());
        for (String session : List.of("window1", "window2")) {
            mvc.perform(auth(post("/api/v1/production/execution/101/presence?operationId=a").contentType("application/json")
                .content(mapper.writeValueAsString(Map.of("sessionId", session, "formId", "form-51", "instanceId", session.equals("window1") ? "form-51" : "form-51:copy:2", "editing", true)))))
                .andExpect(status().isOk());
        }
        mvc.perform(auth(get("/api/v1/production/execution/101/presence?operationId=a")))
            .andExpect(jsonPath("$.data.form-51.length()").value(1)).andExpect(jsonPath("$.data.form-51['1'].sequences.length()").value(2))
            .andExpect(jsonPath("$.data.form-51['1'].avatarUrl").value("/api/v1/files/123/public-preview"));
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'editor2','另一操作员',?,'ACTIVE')", passwords.encode("test-secret"));
        String secondUser = tokens.generateToken("2", "editor2", "另一操作员", 5, List.of("production.execution"));
        mvc.perform(post("/api/v1/production/execution/101/presence?operationId=a").header("Authorization", "Bearer " + secondUser).contentType("application/json")
            .content("{\"sessionId\":\"window1\",\"formId\":\"form-51\",\"instanceId\":\"form-51\",\"editing\":true}"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.form-51.length()").value(2))
            .andExpect(jsonPath("$.data.form-51['2'].avatarUrl").doesNotExist());
        mvc.perform(auth(post("/api/v1/production/execution/101/presence?operationId=a").contentType("application/json")
            .content("{\"sessionId\":\"window2\",\"editing\":false}"))).andExpect(status().isOk());
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "instanceId", "form-51", "values", Map.of("temperature", 30))).andExpect(status().isOk());
        mvc.perform(auth(get("/api/v1/production/execution/101/presence?operationId=a"))).andExpect(jsonPath("$.data.length()").value(0));
        mvc.perform(auth(post("/api/v1/production/execution/101/presence?operationId=a").contentType("application/json")
            .content("{\"sessionId\":\"readonly\",\"formId\":\"form-51\",\"instanceId\":\"form-51\",\"editing\":true}"))).andExpect(status().isBadRequest());
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(jsonPath("$.data.revision").value(3));
    }

    @Test void anOperationWithoutConfiguredFormsCanAttachItsFirstOptionalForm() throws Exception {
        jdbc.update("DELETE FROM product_process_operation_form_binding");
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk()).andExpect(jsonPath("$.data.availability.a.canAttachForm").value(true));
        String response = action(101, "ATTACH_FORM", 1, "a", Map.of("templateVersionId", "5", "required", false)).andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String formId = mapper.readTree(response).path("data").path("attachedFormId").asText();
        action(101, "COMPLETE", 2, "a", Map.of()).andExpect(status().isBadRequest());
        action(101, "COMPLETE", 2, "a", Map.of("acknowledgeIncomplete", true)).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.availability.a.formCopies['" + formId + "'].status").value("IN_PROGRESS"));
        action(101, "ATTACH_FORM", 3, "a", Map.of("templateVersionId", "5", "required", true)).andExpect(status().isBadRequest());
    }

    private void seedSignedWork() {
        seedButtonCertification(900L, "1");
        jdbc.update("INSERT INTO workflow_definition(id,tenant_id,type,name) VALUES(7,'default','WORK','装配复核'),(8,'default','FORM_PROCESS','填报与复核')");
        jdbc.update("INSERT INTO workflow_definition_version VALUES(8,8,1,'PUBLISHED',true,?,?)", """
            [{"id":"s","data":{"kind":"START"}},{"id":"review","data":{"kind":"APPROVAL","label":"现场复核","config":{
              "approverSubjects":[{"type":"USER","id":"1"}],"defaultPermission":"READ_ONLY",
              "buttonEvents":[{"id":"sign","event":"BEFORE","action":"APPROVE","builtin":"NONE","signatureMethod":"ACCOUNT_PASSWORD"}]}}},
              {"id":"e","data":{"kind":"END"}}]
            """, "[{\"source\":\"s\",\"target\":\"review\"},{\"source\":\"review\",\"target\":\"e\"}]");
        jdbc.update("INSERT INTO workflow_definition_version VALUES(7,7,1,'PUBLISHED',true,?,?)", """
            [{"id":"s","data":{"kind":"START"}},{"id":"f","data":{"kind":"FORM","label":"装配记录","config":{"formTemplateVersionId":"5","formProcessVersionId":"8","fillMode":"PROCESS"}}},{"id":"e","data":{"kind":"END"}}]
            """, "[{\"source\":\"s\",\"target\":\"f\"},{\"source\":\"f\",\"target\":\"e\"}]");
        jdbc.update("INSERT INTO workflow_binding_rule VALUES(7,'default',7,'SCOPED',true,1,NULL,11)");
    }

    private void seedButtonCertification(long id, String signerId) {
        new org.springframework.transaction.support.TransactionTemplate(transactions).executeWithoutResult(status -> signatures.save(Signature.builder()
                .id(id).targetType("USER_PROFILE").targetId(signerId).signerId(signerId).signerName("签署人")
                .signaturePasswordHash(passwords.encode("sign-secret")).snapshotData("{}")
                .signedAt(java.time.LocalDateTime.now()).expiresAt(java.time.LocalDateTime.now().plusDays(1)).build()));
    }

    @Test void sharedWorkstationUsesSignerPermissionsAndDualIdentityWithoutChangingSession() throws Exception {
        seedSignedWork();
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'reviewer2','复核员B',?,'ACTIVE')", passwords.encode("other-login"));
        seedButtonCertification(902L, "2");
        var nodes = mapper.readTree(jdbc.queryForObject("SELECT nodes_json FROM workflow_definition_version WHERE id=8", String.class));
        ((com.fasterxml.jackson.databind.node.ObjectNode) nodes.get(1).path("data").path("config").path("approverSubjects").get(0)).put("id", "2");
        jdbc.update("UPDATE workflow_definition_version SET nodes_json=? WHERE id=8", nodes.toString());
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk())
                .andExpect(jsonPath("$.data.availability.a.forms.work-7-f.canAct").value(false));
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "sign-secret"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("无权")));
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 99), "account", "reviewer2", "password", "sign-secret"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("只读")));
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "reviewer2", "password", "sign-secret"))
                .andExpect(status().isOk());
        var signed = jdbc.queryForMap("SELECT signer_id,auth_method,auth_event_ref,snapshot_data FROM signature WHERE target_type='PRODUCTION_EXECUTION'");
        assertThat(signed.get("signer_id")).isEqualTo("2");
        assertThat(signed.get("auth_method")).isEqualTo("SIGNATURE_PASSWORD");
        assertThat(signed.get("auth_event_ref")).isEqualTo("902");
        assertThat(mapper.readTree(jdbc.queryForObject("SELECT snapshot_data FROM signature WHERE target_type='PRODUCTION_EXECUTION'", String.class)).path("sessionOperatorId").asText()).isEqualTo("1");
        assertThat(jdbc.queryForObject("SELECT operator_id FROM audit_event WHERE function_name='APPROVE'", String.class)).isEqualTo("1");
        var state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        JsonNode history = java.util.stream.StreamSupport.stream(state.path("history").spliterator(), false)
                .filter(item -> "APPROVE".equals(item.path("actionCode").asText())).findFirst().orElseThrow();
        assertThat(history.path("operator").asText()).isEqualTo("2");
        assertThat(history.path("sessionOperatorId").asText()).isEqualTo("1");
    }

    @Test void failedSignedActionRollsBackSignatureValuesAndAudit() throws Exception {
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        doThrow(new IllegalStateException("audit unavailable")).when(audits).save(argThat(event -> event != null && "APPROVE".equals(event.getFunctionName())));
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "sign-secret"))
                .andExpect(status().is5xxServerError());
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(2L);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature WHERE target_type='PRODUCTION_EXECUTION'", Integer.class)).isZero();
    }

    private void seedDirectButtonSignature() {
        jdbc.update("UPDATE product_process_operation_form_binding SET fill_settings_json=? WHERE id=51", """
            {"fillMode":"DIRECT","directFillConfig":{"buttonEvents":[
              {"id":"sign","action":"SUBMIT","event":"BEFORE","signatureMethod":"ACCOUNT_PASSWORD","builtin":"NONE"}]}}
            """);
    }

    @Test void directSigningBlocksMissingExpiredAndCustomerAdminLoginCredentialsWithoutLosingDraft() throws Exception {
        seedDirectButtonSignature();
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'customer-admin','客户管理员',?,'ACTIVE')", passwords.encode("other-login"));
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 25))).andExpect(status().isOk());
        var command = Map.of("formId", "form-51", "values", Map.of("temperature", 25), "account", "customer-admin", "password", "other-login");
        action(101, "SUBMIT", 2, "a", command).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("尚未完成")));
        seedButtonCertification(902L, "2");
        action(101, "SUBMIT", 2, "a", command).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("电子签名密码错误")));
        jdbc.update("UPDATE signature SET expires_at=? WHERE id=902", java.time.LocalDateTime.now().minusDays(1));
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of(), "account", "customer-admin", "password", "sign-secret"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").value(org.hamcrest.Matchers.containsString("已过期")));
        mvc.perform(auth(get("/api/v1/production/execution/101"))).andExpect(jsonPath("$.data.revision").value(2))
                .andExpect(jsonPath("$.data.state.operations.a.forms.form-51.values.temperature").value(25));
        jdbc.update("UPDATE signature SET expires_at=? WHERE id=902", java.time.LocalDateTime.now().plusDays(1));
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of(), "account", "customer-admin", "password", "sign-secret"))
                .andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT signer_id FROM signature WHERE target_type='PRODUCTION_EXECUTION'", String.class)).isEqualTo("2");
    }

    @Test void internalAdminUsesLoginPasswordOnlyForButtonAndUnsignedActionsDoNotImpersonate() throws Exception {
        seedDirectButtonSignature();
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'admin','维护账号',?,'ACTIVE')", passwords.encode("maintenance-login"));
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 25), "account", "admin", "password", "wrong"))
                .andExpect(status().isOk());
        var state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(state.path("history").get(1).path("operator").asText()).isEqualTo("1");
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature", Integer.class)).isZero();
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of(), "account", "admin", "password", "maintenance-login"))
                .andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT auth_method FROM signature", String.class)).isEqualTo("ADMIN_LOGIN_PASSWORD");
        assertThat(jdbc.queryForObject("SELECT signer_id FROM signature", String.class)).isEqualTo("2");
        action(101, "SUBMIT", 3, "a", Map.of("formId", "form-51", "values", Map.of(), "account", "admin", "password", "maintenance-login"))
                .andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM signature", Integer.class)).isEqualTo(1);
    }

    @Test
    @org.junit.jupiter.api.condition.EnabledIfSystemProperty(named = "execution.browser", matches = "true")
    void browserEvidenceFixture() throws Exception {
        seedSignedWork();
        if (Boolean.getBoolean("execution.buttonSignature")) {
            seedDirectButtonSignature();
            jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'reviewer2','复核员B',?,'ACTIVE'),(3,0,'uncertified','未认证人员',?,'ACTIVE')", passwords.encode("other-login"), passwords.encode("other-login"));
            seedButtonCertification(902L, "2");
        }
        if (Boolean.getBoolean("execution.optional")) jdbc.update("UPDATE product_process_operation_form_binding SET required=false");
        if (Boolean.getBoolean("execution.output")) {
            var model = mapper.createObjectNode(); var fields = model.putArray("fields");
            String[][] purposes = {{"temperature", "良品数量", "PRODUCTION_GOOD"}, {"ng", "不良品数量", "PRODUCTION_NG"}, {"scrap", "报废数量", "PRODUCTION_SCRAP"}};
            for (String[] purpose : purposes) fields.addObject().put("id", purpose[0]).put("name", purpose[1]).put("type", "number").put("status", "enabled")
                    .putObject("typeConfig").put("businessPurpose", purpose[2]);
            jdbc.update("UPDATE form_template_version SET model_design_json=? WHERE id=5", model.toString());
            jdbc.update("UPDATE production_object SET target_quantity=50 WHERE id=101");
        }
        java.nio.file.Path sop = java.nio.file.Files.createTempFile("production-execution-sop-", ".pdf");
        try (var pdf = new org.apache.pdfbox.pdmodel.PDDocument()) {
            var page = new org.apache.pdfbox.pdmodel.PDPage(); pdf.addPage(page);
            try (var content = new org.apache.pdfbox.pdmodel.PDPageContentStream(pdf, page)) {
                content.beginText(); content.setFont(new org.apache.pdfbox.pdmodel.font.PDType1Font(org.apache.pdfbox.pdmodel.font.Standard14Fonts.FontName.HELVETICA), 18);
                content.newLineAtOffset(50, 700); content.showText("Assembly SOP - V1"); content.endText();
            }
            pdf.save(sop.toFile());
        }
        long sopSize = java.nio.file.Files.size(sop);
        new org.springframework.transaction.support.TransactionTemplate(transactions).execute(status -> files.save(FileObject.builder().id(901L).originalName("Assembly-SOP.pdf").storedPath(sop.toString()).mimeType("application/pdf").fileSize(sopSize).targetType("DOCUMENT").build()));
        jdbc.update("INSERT INTO sop_document VALUES(901,'装配操作指导书')");
        jdbc.update("INSERT INTO document_version VALUES(901,901,'SOP01','V1',901)");
        jdbc.update("INSERT INTO product_process_operation_document_binding VALUES(901,11,901,1,1,1)");
        java.nio.file.Path ready = java.nio.file.Path.of("/tmp/production-execution-browser.json");
        java.nio.file.Path done = java.nio.file.Path.of("/tmp/production-execution-browser.done");
        java.nio.file.Files.deleteIfExists(done);
        String token = tokens.generateToken("1", "operator", "测试操作员", 30, List.of("production.execution"));
        java.nio.file.Files.writeString(ready, mapper.writeValueAsString(Map.of("token", token, "port", Integer.getInteger("execution.test.port", 18081))));
        try {
            long until = System.nanoTime() + TimeUnit.MINUTES.toNanos(20);
            while (!java.nio.file.Files.exists(done) && System.nanoTime() < until) Thread.sleep(500);
        } finally { java.nio.file.Files.deleteIfExists(ready); java.nio.file.Files.deleteIfExists(sop); }
    }

    @Test
    @org.junit.jupiter.api.condition.EnabledIfSystemProperty(named = "form.records.browser", matches = "true")
    void formRecordsBrowserFixture() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        var ready = java.nio.file.Path.of("/tmp/form-records-browser.json");
        var done = java.nio.file.Path.of("/tmp/form-records-browser.done");
        java.nio.file.Files.deleteIfExists(done);
        String token = tokens.generateToken("1", "operator", "测试操作员", 30, List.of("production.execution", "master-data.form-templates"));
        java.nio.file.Files.writeString(ready, mapper.writeValueAsString(Map.of("token", token)));
        try {
            long until = System.nanoTime() + TimeUnit.MINUTES.toNanos(15);
            while (!java.nio.file.Files.exists(done) && System.nanoTime() < until) Thread.sleep(500);
        } finally { java.nio.file.Files.deleteIfExists(ready); }
    }

    private MockHttpServletRequestBuilder auth(MockHttpServletRequestBuilder request) {
        return request.header("Authorization", "Bearer " + tokens.generateToken("1", "operator", "操作员", 5, List.of("production.execution")));
    }
    private org.springframework.test.web.servlet.ResultActions action(long id, String action, long revision, String op, Map<String, Object> extra) throws Exception {
        Map<String, Object> body = new HashMap<>(extra); body.put("action", action); body.put("revision", revision); body.put("operationId", op);
        return mvc.perform(auth(post("/api/v1/production/execution/" + id + "/actions").contentType("application/json").content(mapper.writeValueAsString(body))));
    }

    @Test void globalQueryRequiresBothPermissionsAndPreservesOldEntry() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        for (String path : List.of("/api/v1/form-instances", "/api/v1/form-instances/1", "/api/v1/form-instances/by-number/missing", "/api/v1/form-instances/1/operation-context")) {
            mvc.perform(get(path)).andExpect(status().isUnauthorized());
            for (List<String> permissions : List.of(List.of("production.execution"), List.of("form-instances.view"), List.of("master-data.form-templates", "production.execution"))) {
                mvc.perform(get(path).header("Authorization", "Bearer " + tokens.generateToken("2", "reader", "读者", 5, permissions))).andExpect(status().isForbidden());
            }
        }
        mvc.perform(queryAuth(get("/api/v1/form-instances"))).andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
            .andExpect(jsonPath("$.data.content[0].createdById").value("1"))
            .andExpect(jsonPath("$.data.content[0].source.sourceType").value("PRODUCTION_EXECUTION")); // Reader 2 sees author 1 without own/dept scope.
        mvc.perform(queryAuth(get("/api/v1/form-instance-records").param("templateId", "5"))).andExpect(status().isForbidden());
        mvc.perform(get("/api/v1/form-instance-records").param("templateId", "5").header("Authorization", "Bearer " +
            tokens.generateToken("2", "reader", "读者", 5, List.of("master-data.form-templates", "production.execution"))))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.content[0].fieldValues.temperature").value(22));
    }

    @Test void globalQueryUsesFrozenMetadataCrossTemplateFiltersAndStablePages() throws Exception {
        seedQueryRecords();
        jdbc.update("UPDATE form_template SET name='新的模板名',code='NEW'");
        int auditsBefore = jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class);
        mvc.perform(queryAuth(get("/api/v1/form-instances"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.totalElements").value(2)).andExpect(jsonPath("$.data.content[0].fieldValues").doesNotExist())
            .andExpect(jsonPath("$.data.content[0].snapshot").doesNotExist());
        var query = get("/api/v1/form-instances").param("templateId", "6").param("templateVersionId", "6")
            .param("templateCode", "F02").param("templateName", "补充").param("workOrderId", "100")
            .param("productionObjectId", "102").param("productionObjectType", "SN").param("operationId", "a")
            .param("sourceType", "PRODUCTION_EXECUTION").param("sourceId", "102").param("recordStatus", "COMPLETED", "ACTIVE")
            .param("createdById", "1").param("updatedById", "1").param("keyword", "SN01");
        mvc.perform(queryAuth(query)).andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
            .andExpect(jsonPath("$.data.content[0].templateName").value("补充记录"))
            .andExpect(jsonPath("$.data.content[0].source.workOrderNo").value("WO01"));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("templateId", "5").param("templateVersionId", "6")))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("productionObjectId", "101").param("productionObjectType", "SN")))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("productionObjectId", "101").param("workOrderId", "999")))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        jdbc.update("UPDATE form_instance_record SET created_at=TIMESTAMP '2026-09-15 10:00:00'");
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("size", "1"))).andExpect(jsonPath("$.data.content[0].formInstanceId").value("2"));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("size", "1").param("page", "1"))).andExpect(jsonPath("$.data.content[0].formInstanceId").value("1"));
        jdbc.update("UPDATE form_instance_record SET created_at=NULL WHERE id=2");
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("size", "1"))).andExpect(jsonPath("$.data.content[0].formInstanceId").value("1"));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("createdFrom", "2026-09-15T10:00:00").param("createdTo", "2026-09-15T10:00:01")))
            .andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("createdTo", "2026-09-15T10:00:00")))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("updatedTo", "2020-01-01T00:00:00")))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        for (String special : List.of("%", "_", "!", "' OR 1=1 --", "temperature")) {
            mvc.perform(queryAuth(get("/api/v1/form-instances").param("keyword", special))).andExpect(jsonPath("$.data.totalElements").value(0));
        }
        assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_event", Integer.class)).isEqualTo(auditsBefore);
    }

    @Test void globalQueryExactDetailsTenantBoundaryAndSourceControls() throws Exception {
        seedQueryRecords();
        String number = jdbc.queryForObject("SELECT instance_no FROM form_instance_record WHERE id=1", String.class);
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("instanceNo", number))).andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("instanceNo", number.substring(0, 5)))).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("instanceNoContains", "FR-"))).andExpect(jsonPath("$.data.totalElements").value(2));
        for (String path : List.of("/api/v1/form-instances/1", "/api/v1/form-instances/by-number/" + number)) {
            mvc.perform(queryAuth(get(path))).andExpect(status().isOk()).andExpect(jsonPath("$.data.formInstanceId").value("1"))
                .andExpect(jsonPath("$.data.snapshot.name").value("装配记录")).andExpect(jsonPath("$.data.fieldValues.temperature").value(22))
                .andExpect(jsonPath("$.data.source.sourceType").value("PRODUCTION_EXECUTION"));
        }
        mvc.perform(queryAuth(get("/api/v1/form-instances/1/operation-context"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.source.copyId").value("form-51")).andExpect(jsonPath("$.data.revision").value(2))
            .andExpect(jsonPath("$.data.controls.canAct").value(true));
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        mvc.perform(queryAuth(get("/api/v1/form-instances/1/operation-context"))).andExpect(jsonPath("$.data.controls.canAct").value(false));
        mvc.perform(queryAuth(post("/api/v1/production/execution/101/actions").contentType("application/json")
            .content("{\"action\":\"SAVE\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"form-51\",\"values\":{}}")))
            .andExpect(status().isBadRequest());
        jdbc.update("UPDATE form_instance_record SET source_type='UNSUPPORTED' WHERE id=2");
        mvc.perform(queryAuth(get("/api/v1/form-instances"))).andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(queryAuth(get("/api/v1/form-instances/2"))).andExpect(status().isNotFound());
        jdbc.update("UPDATE form_instance_record SET source_type='PRODUCTION_EXECUTION' WHERE id=2");
        jdbc.update("UPDATE form_instance_record SET tenant_id='other' WHERE id=1");
        mvc.perform(queryAuth(get("/api/v1/form-instances"))).andExpect(jsonPath("$.data.totalElements").value(1));
        for (String path : List.of("/api/v1/form-instances/1", "/api/v1/form-instances/1/operation-context", "/api/v1/form-instances/by-number/" + number)) {
            mvc.perform(queryAuth(get(path))).andExpect(status().isNotFound());
        }
    }

    @Test void globalQueryDoesNotGrantAnActiveApprovalNodeAndKeepsPrincipalHistory() throws Exception {
        // queryAuth signs reader #2; the authenticated subject must also exist in the identity store.
        assertThat(jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) "
                + "SELECT 2,tenant_id,'reader','读者',?,'ACTIVE' FROM user_account WHERE id=1",
                passwords.encode("reader-fixture-only"))).isEqualTo(1);
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(queryAuth(post("/api/v1/production/execution/101/actions").contentType("application/json")
            .content("{\"action\":\"SUBMIT\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{\"temperature\":23}}")))
            .andExpect(status().isOk());
        mvc.perform(queryAuth(get("/api/v1/form-instances/1"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.createdById").value("1")).andExpect(jsonPath("$.data.updatedById").value("2"));
        mvc.perform(queryAuth(get("/api/v1/form-instances/1/operation-context"))).andExpect(status().isOk())
            .andExpect(jsonPath("$.data.controls.canAct").value(false));
        mvc.perform(queryAuth(post("/api/v1/production/execution/101/actions").contentType("application/json")
            .content("{\"action\":\"APPROVE\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}")))
            .andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT status FROM form_instance_record WHERE id=1", String.class)).isEqualTo("ACTIVE");
    }

    @Test void missingQueryPrincipalCannotAdvanceApprovalOrChangePersistedEvidence() throws Exception {
        // Deliberately do not persist reader #2: a valid test token is not an identity-store record.
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        String stateBefore = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        String snapshotBefore = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        int auditsBefore = jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class);
        mvc.perform(queryAuth(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"SUBMIT\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{\"temperature\":23}}")))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("无法确定当前用户的主体解析范围"));
        assertThat(jdbc.queryForObject("SELECT revision FROM production_execution WHERE object_id=101", Long.class)).isEqualTo(2L);
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(stateBefore);
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(snapshotBefore);
        assertThat(jdbc.queryForObject("SELECT COUNT(*) FROM audit_event", Integer.class)).isEqualTo(auditsBefore);
        assertThat(jdbc.queryForObject("SELECT status FROM form_instance_record WHERE id=1", String.class)).isEqualTo("ACTIVE");
    }

    @Test void globalQueryRejectsUnsupportedAndMalformedConditions() throws Exception {
        for (var entry : Map.ofEntries(Map.entry("size", "201"), Map.entry("page", "-1"), Map.entry("templateId", "NaN"),
            Map.entry("productionObjectType", "OTHER"), Map.entry("sourceType", "STANDALONE"), Map.entry("sourceId", "101"),
            Map.entry("sort", "values_json,desc"), Map.entry("tenantId", "other"), Map.entry("activeRequestType", "NONE"),
            Map.entry("recordStatus", "VOIDED"), Map.entry("createdFrom", "2026-09-16T00:00:00Z"), Map.entry("keyword", " ")).entrySet()) {
            mvc.perform(queryAuth(get("/api/v1/form-instances").param(entry.getKey(), entry.getValue()))).andExpect(status().isBadRequest());
        }
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("templateId", "5", "6"))).andExpect(status().isBadRequest());
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("instanceNo", "FR-1").param("instanceNoContains", "FR-"))).andExpect(status().isBadRequest());
        mvc.perform(queryAuth(get("/api/v1/form-instances").param("updatedFrom", "2026-09-16T01:00:00").param("updatedTo", "2026-09-16T00:00:00")))
            .andExpect(status().isBadRequest());
        mvc.perform(queryAuth(get("/api/v1/form-instances/no-number"))).andExpect(status().isBadRequest());
        mvc.perform(queryAuth(get("/api/v1/form-instances/999"))).andExpect(status().isNotFound());
        mvc.perform(queryAuth(get("/api/v1/form-instances/1/operation-context").param("intent", "CHANGE"))).andExpect(status().isBadRequest());
    }

    private void seedQueryRecords() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        jdbc.update("INSERT INTO form_template(id,name,code,category_name) VALUES(6,'补充记录','F02','生产记录')");
        jdbc.update("INSERT INTO form_template_version(id,template_id,version_label,model_design_json,canvas_design_json) SELECT 6,6,'V1',model_design_json,canvas_design_json FROM form_template_version WHERE id=5");
        jdbc.update("UPDATE product_process_operation_form_binding SET form_template_version_id=6 WHERE id IN (51,61)");
        action(102, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(102, "SAVE", 1, "a", Map.of("formId", "form-61", "values", Map.of("temperature", 24))).andExpect(status().isOk());
    }

    private MockHttpServletRequestBuilder queryAuth(MockHttpServletRequestBuilder request) {
        return request.header("Authorization", "Bearer " + tokens.generateToken("2", "reader", "读者", 5, List.of("production.execution", "form-instances.view")));
    }

    @Test void worklistIncludesUnsavedAndSavedButFilledRequiresActualSubmit() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.totalElements").value(1))
            .andExpect(jsonPath("$.data.content[0].saved").value(false)).andExpect(jsonPath("$.data.content[0].instanceNo").isEmpty());
        mvc.perform(personal(worklistDetail("FILLABLE", "form-51", "form-51"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.controls.canAct").value(true));
        action(101, "SAVE", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param("saved", "true"), "1")).andExpect(jsonPath("$.data.totalElements").value(1));
        for (String view : List.of("FILLED", "CREATED", "REVIEW_DONE")) {
            mvc.perform(personal(get("/api/v1/form-worklists/" + view), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
        }
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/FILLED"), "1")).andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(personal(get("/api/v1/form-worklists/FILLED"), "2")).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(worklistDetail("FILLED", "form-51", "form-51"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.controls.canAct").value(false)).andExpect(jsonPath("$.data.myEvents.length()").value(1));
        mvc.perform(personal(worklistDetail("FILLED", "form-51", "form-51"), "2")).andExpect(status().isNotFound());
        mvc.perform(personal(get("/api/v1/form-instances"), "1")).andExpect(status().isForbidden());
    }

    @Test void worklistExplicitCreationIsIndependentFromFirstSaverAndSystemFirstCopy() throws Exception {
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "ADD_FORM_COPY", 1, "a", Map.of("formId", "form-51", "remark", "追加检验")).andExpect(status().isOk());
        String response = action(101, "ATTACH_FORM", 2, "a", Map.of("templateVersionId", "5", "required", false))
            .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String custom = mapper.readTree(response).path("data").path("attachedFormId").asText();
        mvc.perform(personal(get("/api/v1/form-worklists/CREATED"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(2))
            .andExpect(jsonPath("$.data.content[?(@.copyId == 'form-51:copy:2')].creationType").value("ADDED_COPY"))
            .andExpect(jsonPath("$.data.content[?(@.copyId == '" + custom + "')].creationType").value("CUSTOM_FORM"));
        mvc.perform(personal(worklistDetail("CREATED", custom, custom), "1"))
            .andExpect(jsonPath("$.data.controls.canAct").value(false)).andExpect(jsonPath("$.data.creationType").value("CUSTOM_FORM"));
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
            .content(mapper.writeValueAsString(Map.of("action", "SAVE", "revision", 3, "operationId", "a",
                "formId", "form-51", "instanceId", "form-51:copy:2", "values", Map.of("temperature", 22)))), "2")).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/CREATED").param("saved", "true"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content[0].creatorId").value("1"));
        mvc.perform(personal(get("/api/v1/form-worklists/CREATED"), "2")).andExpect(jsonPath("$.data.totalElements").value(0));
        assertThat(jdbc.queryForObject("SELECT created_by_id FROM form_instance_record", String.class)).isEqualTo("2");
    }

    @Test void worklistReturnAndResubmitKeepPersonalHistoryAndUseActualApprovalQualification() throws Exception {
        seedSignedWork();
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content[0].nodeId").value("review"));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "2")).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(worklistDetail("REVIEW_PENDING", "work-7-f", "work-7-f"), "2")).andExpect(status().isNotFound());
        action(101, "RETURN", 2, "a", Map.of("formId", "work-7-f", "values", Map.of())).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE"), "1")).andExpect(jsonPath("$.data.totalElements").value(2));
        for (String view : List.of("FILLED", "REVIEW_DONE")) {
            mvc.perform(personal(get("/api/v1/form-worklists/" + view), "1")).andExpect(jsonPath("$.data.totalElements").value(1));
        }
        action(101, "SUBMIT", 3, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        mvc.perform(personal(worklistDetail("FILLED", "work-7-f", "work-7-f"), "1")).andExpect(jsonPath("$.data.myEvents.length()").value(2));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "1")).andExpect(jsonPath("$.data.totalElements").value(1));
        action(101, "APPROVE", 4, "a", Map.of("formId", "work-7-f", "values", Map.of(), "account", "operator", "password", "sign-secret")).andExpect(status().isOk());
        mvc.perform(personal(worklistDetail("REVIEW_DONE", "work-7-f", "work-7-f"), "1"))
            .andExpect(jsonPath("$.data.myEvents.length()").value(2)).andExpect(jsonPath("$.data.controls.canAct").value(false));
        JsonNode state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        for (JsonNode event : state.path("history")) {
            if ("RETURN".equals(event.path("actionCode").asText())) ((com.fasterxml.jackson.databind.node.ObjectNode) event).put("at", "2026-09-01T10:00:00");
            if ("APPROVE".equals(event.path("actionCode").asText())) ((com.fasterxml.jackson.databind.node.ObjectNode) event).put("at", "2026-09-02T10:00:00");
        }
        jdbc.update("UPDATE production_execution SET state_json=? WHERE object_id=101", state.toString());
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("reviewResult", "RETURN").param("reviewedFrom", "2026-09-02T00:00:00"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("reviewResult", "APPROVE").param("reviewedFrom", "2026-09-02T00:00:00"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1));
    }

    @Test void formApprovalTransferMovesPendingTaskWithoutAdvancingTheFlow() throws Exception {
        seedSignedWork();
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'reviewer2','复核员2',?,'ACTIVE')", passwords.encode("test-secret"));
        jdbc.update("UPDATE workflow_definition_version SET nodes_json=? WHERE id=8", """
            [{"id":"s","data":{"kind":"START"}},
             {"id":"review","data":{"kind":"APPROVAL","label":"现场复核","config":{"approverSubjects":[],"defaultPermission":"READ_ONLY","buttons":[
               {"id":"approve","label":"通过","action":"APPROVE"},{"id":"return","label":"退回","action":"RETURN"},{"id":"transfer","label":"转办","action":"TRANSFER"}]}}},
             {"id":"e","data":{"kind":"END"}}]
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "1"))
            .andExpect(jsonPath("$.data.content[0].canTransfer").value(true))
            .andExpect(jsonPath("$.data.content[0].transferLabel").value("转办"))
            .andExpect(jsonPath("$.data.content[0].transferStyle").value("DEFAULT"));
        mvc.perform(personal(get("/api/v1/production/execution/101/transfer-targets")
                .param("operationId", "a").param("formId", "work-7-f").param("instanceId", "work-7-f"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.content[0].id").value("2")).andExpect(jsonPath("$.data.content[0].name").value("复核员2"));
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"instanceId\":\"work-7-f\",\"targetUserId\":\"2\",\"reason\":\"交由当班复核员\"}"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.revision").value(3))
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].active[0]").value("review"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].values.temperature").value(22));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "2")).andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(personal(worklistDetail("REVIEW_PENDING", "work-7-f", "work-7-f"), "2"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data.transferFrom").value("测试用户"))
            .andExpect(jsonPath("$.data.transferReason").value("交由当班复核员"))
            .andExpect(jsonPath("$.data.transferredAt").isNotEmpty());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"APPROVE\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), "1"))
            .andExpect(status().isBadRequest());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"APPROVE\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), "2"))
            .andExpect(status().isOk());
        assertThat(jdbc.queryForObject("SELECT reason FROM audit_event WHERE function_name='TRANSFER'", String.class)).isEqualTo("交由当班复核员");
    }

    @Test void tenantDelegationOutsideFrozenCandidatesPreservesSourceAndMovesOnlyCurrentResponsibility() throws Exception {
        seedTenantDelegationApproval();
        String snapshotBefore = jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class);
        var stateBefore = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        String frozenApprovers = stateBefore.at("/operations/a/forms/work-7-f/approvers").toString();
        assertThat(stateBefore.at("/operations/a/forms/work-7-f/approvers/review")).hasSize(1);
        mvc.perform(personal(get("/api/v1/production/execution/101/transfer-targets")
                .param("operationId", "a").param("formId", "work-7-f").param("instanceId", "work-7-f"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.content.length()").value(2))
            .andExpect(jsonPath("$.data.content[*].id").value(org.hamcrest.Matchers.containsInAnyOrder("2", "3")));
        for (String invalid : List.of("1", "4", "5", "6", "missing")) {
            mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                    .content(mapper.writeValueAsString(Map.of("action", "TRANSFER", "revision", 2, "operationId", "a",
                            "formId", "work-7-f", "instanceId", "work-7-f", "targetUserId", invalid, "reason", "合法委托原因"))), "1"))
                .andExpect(status().isBadRequest());
            assertThat(mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class))).isEqualTo(stateBefore);
        }
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"instanceId\":\"work-7-f\",\"targetUserId\":\"02\",\"reason\":\"集合外当班委托\"}"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.revision").value(3))
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].transferAssignees.review").value("2"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].active[0]").value("review"))
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].values.temperature").value(22));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "2")).andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(personal(get("/api/v1/production/execution/101/transfer-targets")
                .param("operationId", "a").param("formId", "work-7-f").param("instanceId", "work-7-f"), "1"))
            .andExpect(status().isBadRequest());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"instanceId\":\"work-7-f\",\"targetUserId\":\"3\",\"reason\":\"再次委托\"}"), "2"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.revision").value(4));
        var delegated = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        assertThat(delegated.at("/operations/a/forms/work-7-f/approvers").toString()).isEqualTo(frozenApprovers);
        assertThat(jdbc.queryForObject("SELECT snapshot_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(snapshotBefore);
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "2")).andExpect(jsonPath("$.data.totalElements").value(0));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_PENDING"), "3")).andExpect(jsonPath("$.data.totalElements").value(1));
        for (String oldOperator : List.of("1", "2")) mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"APPROVE\",\"revision\":4,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), oldOperator))
            .andExpect(status().isBadRequest());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"APPROVE\",\"revision\":4,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), "3"))
            .andExpect(status().isOk());
        assertThat(jdbc.queryForList("SELECT reason FROM audit_event WHERE function_name='TRANSFER' ORDER BY created_at,id", String.class))
                .containsExactly("集合外当班委托", "再次委托");
    }

    @Test void transferRechecksTheSelectedTenantUserWhenTheirAccountBecomesLocked() throws Exception {
        seedTenantDelegationApproval();
        mvc.perform(personal(get("/api/v1/production/execution/101/transfer-targets")
                .param("operationId", "a").param("formId", "work-7-f").param("instanceId", "work-7-f").param("keyword", "reviewer2"), "1"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.content[0].id").value("2"));
        jdbc.update("UPDATE user_account SET locked_until=? WHERE id=2", java.time.LocalDateTime.now().plusHours(1));
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"instanceId\":\"work-7-f\",\"targetUserId\":\"2\",\"reason\":\"选择后状态变化\"}"), "1"))
            .andExpect(status().isBadRequest());
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        assertThat(jdbc.queryForObject("SELECT count(*) FROM audit_event WHERE function_name='TRANSFER'", Long.class)).isZero();
    }

    private void seedTenantDelegationApproval() throws Exception {
        seedSignedWork();
        for (int id = 2; id <= 6; id++) jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status,locked_until) VALUES(?,?,?,?,?,?,?)",
                id, id == 6 ? 99 : 0, "reviewer" + id, "复核员" + id, passwords.encode("test-secret"),
                id == 4 ? "INACTIVE" : "ACTIVE", id == 5 ? java.time.LocalDateTime.now().plusHours(1) : null);
        jdbc.update("UPDATE workflow_definition_version SET nodes_json=? WHERE id=8", """
            [{"id":"s","data":{"kind":"START"}},
             {"id":"review","data":{"kind":"APPROVAL","label":"现场复核","config":{"approverSubjects":[{"type":"USER","id":"1"}],"defaultPermission":"READ_ONLY","buttons":[
               {"id":"approve","label":"通过","action":"APPROVE"},{"id":"return","label":"退回","action":"RETURN"},{"id":"transfer","label":"转办","action":"TRANSFER"}]}}},
             {"id":"e","data":{"kind":"END"}}]
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
    }

    @Test void transferProjectionIsNodeScopedAndReassignmentIsClearedByReturn() throws Exception {
        seedSignedWork();
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(2,0,'reviewer2','复核员2',?,'ACTIVE')", passwords.encode("test-secret"));
        jdbc.update("INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status) VALUES(3,0,'reviewer3','复核员3',?,'ACTIVE')", passwords.encode("test-secret"));
        jdbc.update("UPDATE workflow_definition_version SET nodes_json=?,edges_json=? WHERE id=8", """
            [{"id":"s","data":{"kind":"START"}},
             {"id":"review","data":{"kind":"APPROVAL","label":"初审","config":{"approverSubjects":[]}}},
             {"id":"review2","data":{"kind":"APPROVAL","label":"复审","config":{"approverSubjects":[]}}},
             {"id":"e","data":{"kind":"END"}}]
            """, """
            [{"source":"s","target":"review"},{"source":"review","target":"review2"},{"source":"review2","target":"e"}]
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":2,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"targetUserId\":\"2\",\"reason\":\"初审转办\"}"), "1"))
            .andExpect(status().isOk());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"APPROVE\",\"revision\":3,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), "2"))
            .andExpect(status().isOk());
        mvc.perform(personal(worklistDetail("REVIEW_PENDING", "work-7-f", "work-7-f"), "2"))
            .andExpect(status().isOk()).andExpect(jsonPath("$.data.nodeId").value("review2"))
            .andExpect(jsonPath("$.data.transferReason").isEmpty());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":4,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"targetUserId\":\"3\",\"reason\":\"复审第一次转办\"}"), "2"))
            .andExpect(status().isOk());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"TRANSFER\",\"revision\":5,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"targetUserId\":\"1\",\"reason\":\"复审再次转办\"}"), "3"))
            .andExpect(status().isOk());
        mvc.perform(personal(post("/api/v1/production/execution/101/actions").contentType("application/json")
                .content("{\"action\":\"RETURN\",\"revision\":6,\"operationId\":\"a\",\"formId\":\"work-7-f\",\"values\":{}}"), "1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.data.state.operations.a.forms['work-7-f'].transferAssignees").isEmpty());
    }

    @Test void worklistHistoricalNodeFiltersMatchTheSameEventBeforeSelectingTheLatest() throws Exception {
        seedSignedWork();
        jdbc.update("UPDATE workflow_definition_version SET nodes_json=?,edges_json=? WHERE id=8", """
            [{"id":"s","data":{"kind":"START"}},
             {"id":"review","data":{"kind":"APPROVAL","label":"初审","config":{"approverSubjects":[{"type":"USER","id":"1"}],"defaultPermission":"READ_ONLY"}}},
             {"id":"review2","data":{"kind":"APPROVAL","label":"复审","config":{"approverSubjects":[{"type":"USER","id":"1"}],"defaultPermission":"READ_ONLY"}}},
             {"id":"e","data":{"kind":"END"}}]
            """, """
            [{"source":"s","target":"review"},{"source":"review","target":"review2"},{"source":"review2","target":"e"}]
            """);
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        action(101, "SUBMIT", 1, "a", Map.of("formId", "work-7-f", "values", Map.of("temperature", 22))).andExpect(status().isOk());
        action(101, "APPROVE", 2, "a", Map.of("formId", "work-7-f", "values", Map.of())).andExpect(status().isOk());
        action(101, "APPROVE", 3, "a", Map.of("formId", "work-7-f", "values", Map.of())).andExpect(status().isOk());
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content[0].nodeId").value("review2"));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("nodeId", "review"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content[0].nodeId").value("review"));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("nodeName", "初审"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1)).andExpect(jsonPath("$.data.content[0].nodeId").value("review"));
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("nodeId", "review").param("nodeName", "复审"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(0));
        JsonNode state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        for (JsonNode event : state.path("history")) if ("APPROVE".equals(event.path("actionCode").asText())) {
            ((com.fasterxml.jackson.databind.node.ObjectNode) event).put("at", event.path("nodeId").asText().equals("review") ? "2026-09-01T10:00:00" : "2026-09-02T10:00:00");
        }
        jdbc.update("UPDATE production_execution SET state_json=? WHERE object_id=101", state.toString());
        mvc.perform(personal(get("/api/v1/form-worklists/REVIEW_DONE").param("nodeId", "review").param("reviewedFrom", "2026-09-02T00:00:00"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(0));
    }

    @Test void worklistFilteringPaginationAndLegacyHistoryDoNotInventParticipation() throws Exception {
        seedQueryRecords();
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param("size", "1"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(2)).andExpect(jsonPath("$.data.content[0].productionObjectId").value("102"));
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param("size", "1").param("page", "1"), "1"))
            .andExpect(jsonPath("$.data.content[0].productionObjectId").value("101"));
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param("productionObjectType", "SN").param("templateName", "补充").param("saved", "true"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(1));
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param("keyword", "temperature"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
        action(101, "SUBMIT", 2, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isOk());
        JsonNode state = mapper.readTree(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class));
        for (JsonNode event : state.path("history")) ((com.fasterxml.jackson.databind.node.ObjectNode) event).remove(List.of("actionCode", "formId", "copyId", "nodeKind"));
        jdbc.update("UPDATE production_execution SET state_json=? WHERE object_id=101", state.toString());
        mvc.perform(personal(get("/api/v1/form-worklists/FILLED"), "1"))
            .andExpect(jsonPath("$.data.totalElements").value(0)).andExpect(jsonPath("$.data.historyCoverage").value("STRUCTURED_EVENTS_ONLY"));
        jdbc.update("UPDATE production_object SET tenant_id='foreign' WHERE id=102");
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
    }

    @Test void worklistRejectsWrongPermissionsParamsAndFailedActionsCreateNoHistory() throws Exception {
        for (String view : List.of("FILLABLE", "CREATED", "FILLED", "REVIEW_PENDING", "REVIEW_DONE")) {
            String path = "/api/v1/form-worklists/" + view;
            mvc.perform(get(path)).andExpect(status().isUnauthorized());
            mvc.perform(get(path).header("Authorization", "Bearer " + tokens.generateToken("1", "operator", "测试", 5, List.of("production.execution")))).andExpect(status().isForbidden());
            mvc.perform(get(path).header("Authorization", "Bearer " + tokens.generateToken("1", "operator", "测试", 5, List.of("form-management.filling", "form-management.review")))).andExpect(status().isForbidden());
        }
        for (var entry : Map.of("actorId", "2", "size", "201", "saved", "yes", "sort", "id,desc", "reviewResult", "RETURN", "createdFrom", "2026-09-01T00:00:00Z").entrySet()) {
            mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE").param(entry.getKey(), entry.getValue()), "1")).andExpect(status().isBadRequest());
        }
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE/detail"), "1")).andExpect(status().isBadRequest());
        action(101, "START", 0, "a", Map.of()).andExpect(status().isOk());
        String before = jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class);
        doThrow(new IllegalStateException("test audit failure")).when(audits).save(any());
        try {
            action(101, "SUBMIT", 1, "a", Map.of("formId", "form-51", "values", Map.of("temperature", 23))).andExpect(status().isInternalServerError());
        } finally { reset(audits); }
        assertThat(jdbc.queryForObject("SELECT state_json FROM production_execution WHERE object_id=101", String.class)).isEqualTo(before);
        mvc.perform(personal(get("/api/v1/form-worklists/FILLED"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
        jdbc.update("UPDATE production_object SET status='COMPLETED' WHERE id=101");
        mvc.perform(personal(get("/api/v1/form-worklists/FILLABLE"), "1")).andExpect(jsonPath("$.data.totalElements").value(0));
    }

    private MockHttpServletRequestBuilder personal(MockHttpServletRequestBuilder request, String actor) {
        return request.header("Authorization", "Bearer " + tokens.generateToken(actor, actor.equals("1") ? "operator" : "reader", "测试用户", 5,
            List.of("production.execution", "form-management.filling", "form-management.review")));
    }

    private MockHttpServletRequestBuilder worklistDetail(String view, String form, String copy) {
        return get("/api/v1/form-worklists/" + view + "/detail").param("productionObjectId", "101").param("operationId", "a").param("formId", form).param("copyId", copy);
    }

    @Configuration(proxyBeanMethods = false)
    @EnableAutoConfiguration(exclude = JpaRepositoriesAutoConfiguration.class)
    @Import({DhrFillingController.class, DhrFillingService.class, FormWorklistController.class, FormWorklistService.class, FormInstanceQueryController.class, FormInstanceQueryService.class, FormInstanceRecordController.class, FormInstanceRecordService.class, FormProjectionService.class, DhrInstanceController.class, DhrInstanceService.class, ProductionExecutionController.class, ProductionExecutionService.class, ProductionExecutionEngine.class, ExecutionSnapshotBuilder.class, ExecutionPresenceRegistry.class,
        ProductionService.class, ExecutionAccess.class, SubjectResolver.class, FileController.class, GlobalExceptionHandler.class, SecurityConfig.class, JwtAuthenticationFilter.class,
        com.zencas.edhr.template.controller.FormReferenceController.class, com.zencas.edhr.template.service.FormReferenceLookup.class,
        com.zencas.edhr.compliance.controller.AuditController.class})
    static class Config {
        @Bean
        @org.springframework.boot.autoconfigure.condition.ConditionalOnProperty(name = "form.records.browser", havingValue = "true")
        org.springframework.boot.web.servlet.FilterRegistrationBean<org.springframework.web.filter.CorsFilter> browserCors() {
            var config = new org.springframework.web.cors.CorsConfiguration();
            config.setAllowedOrigins(List.of("http://localhost:3000"));
            config.setAllowedMethods(List.of("GET", "POST", "OPTIONS"));
            config.setAllowedHeaders(List.of("Authorization", "Content-Type"));
            var source = new org.springframework.web.cors.UrlBasedCorsConfigurationSource();
            source.registerCorsConfiguration("/api/v1/form-instance-records/**", config);
            source.registerCorsConfiguration("/api/v1/production/execution/**", config);
            var bean = new org.springframework.boot.web.servlet.FilterRegistrationBean<>(new org.springframework.web.filter.CorsFilter(source));
            bean.setOrder(org.springframework.core.Ordered.HIGHEST_PRECEDENCE);
            return bean;
        }
        @Bean EntityManager em(EntityManagerFactory factory) { return SharedEntityManagerCreator.createSharedEntityManager(factory); }
        @Bean PersistenceManagedTypes types() { return PersistenceManagedTypes.of(ProductionObject.class.getName(), WorkOrder.class.getName(), ProductionExecution.class.getName(), AuditEvent.class.getName(), UserAccount.class.getName(), Signature.class.getName(), FileObject.class.getName()); }
        @Bean PasswordEncoder passwords() { return new BCryptPasswordEncoder(4); }
        @Bean UserAccountRepository users(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(UserAccountRepository.class); }
        @Bean SignatureRepository signatures(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(SignatureRepository.class); }
        @Bean FileObjectRepository files(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(FileObjectRepository.class); }
        @Bean ProductionObjectRepository objects(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(ProductionObjectRepository.class); }
        @Bean WorkOrderRepository orders(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(WorkOrderRepository.class); }
        @Bean ProductionExecutionRepository executions(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(ProductionExecutionRepository.class); }
        @Bean AuditEventRepository audits(EntityManager em) { return new JpaRepositoryFactory(em).getRepository(AuditEventRepository.class); }
        @Bean SnowflakeIdGenerator ids() { return new SnowflakeIdGenerator(1); }
        @Bean JwtTokenProvider tokens() { return new JwtTokenProvider("execution-integration-test-key-at-least-32-characters", 300000); }
    }
}
