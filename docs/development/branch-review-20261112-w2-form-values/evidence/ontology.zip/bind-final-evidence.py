from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,yaml

repo=Path('/workspace/edhr-nexus-frontend'); raw=Path(__file__).parent
main=Path('/tmp/edhr-w2-form-values-20261112')
base='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
candidate='6e878e496189c2fdd765f9ea71b5264a3e181709'
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True).strip()
def load(p):return json.loads(p.read_text())
assert git('rev-parse','HEAD')==candidate
assert git('rev-parse','origin/edhr-dev')==base
phase=main/'optimized_final';run=load(phase/'run.json');summary=load(phase/'test-summary.json')
assert run['head']==candidate and not run['workingTreeState'] and run['exitCode']==0
assert summary['totals']==dict(tests=208,failures=0,errors=0,skipped=3) and not summary['missingFreshReports']
knowledge=load(main/'knowledge/run.json');knowledgeSummary=load(main/'knowledge/test-summary.json')
assert knowledge['head']==candidate and not knowledge['workingTreeState'] and knowledge['exitCode']==0
assert knowledgeSummary==dict(tests=89,failures=0,errors=0,skipped=0)
for item in run['sourceFingerprints']+knowledge['sourceFingerprints']:
 data=(repo/item['path']).read_bytes()
 assert sha(data)==item['sha256']==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=repo)),item['path']
 if item in run['sourceFingerprints']:assert sha((phase/'source'/item['path']).read_bytes())==item['sha256']
allKnowledge=[]
for path in sorted((repo/'docs/knowledge').rglob('*')):
 if not path.is_file():continue
 rel=str(path.relative_to(repo));data=path.read_bytes()
 assert sha(data)==sha(subprocess.check_output(['git','show',base+':'+rel],cwd=repo))
 allKnowledge.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
assert len(allKnowledge)==353 and len(knowledge['sourceFingerprints'])==359
copied=[]
def copy(source,dest):
 target=raw/'read-evidence'/dest;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
 copied.append({'path':str(target.relative_to(raw)),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())})
for phaseName in ['optimized_final','final_candidate','final','old_same_tests']:
 folder=main/phaseName
 for name in ['run.json','test-summary.json','maven.log','TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']:
  copy(folder/name,Path(phaseName)/name)
for source in phase.glob('TEST-*.xml'):
 if source.name!='TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml':copy(source,Path('optimized_final')/source.name)
for name in ['run.json','test-summary.json','maven.log','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']:
 copy(main/'knowledge'/name,Path('knowledge')/name)
for source in (phase/'observations').glob('*.json'):copy(source,Path('optimized_final/observations')/source.name)
for source in (main/'final_candidate/observations').glob('*.json'):copy(source,Path('final_candidate/observations')/source.name)
for name in ['initial-maven.log','initial-source-note.json','initial-test-source.java','initial-TEST-com.zencas.edhr.production.service.ProductionFormValueBoundaryTest.xml']:
 copy(main/name,Path('initial')/name)
caseCounts={};skips=[]
for source in phase.glob('TEST-*.xml'):
 root=ET.parse(source).getroot();caseCounts[source.name]={k:int(root.attrib[k]) for k in ['tests','failures','errors','skipped']}
 for test in root.findall('testcase'):
  if test.find('skipped') is not None:skips.append({'class':test.attrib['classname'],'name':test.attrib['name'],'message':test.find('skipped').attrib.get('message')})
assert {s['name'] for s in skips}=={'formRecordsBrowserFixture','browserEvidenceFixture','firstStartFreezesOneCommittedConfigurationDuringProcessRebinding'}
observations=[]
for source in sorted((phase/'observations').glob('*.json')):
 data=load(source);assert data['inputUnchanged'] and data['previousUnchanged']
 assert data['actualH2Queries']==(1 if data['repeatedFile'] and data['rows']>0 else 0)
 assert len(data['queries'])==data['actualH2Queries']
 observations.append({'path':source.name,**{k:v for k,v in data.items() if k!='queries'}})
assert len(observations)==7
changed=git('diff','--name-only',base,candidate).splitlines()
assert len(changed)==3
assert [p for p in changed if '/src/main/' in p]==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java']
assert not any(p.startswith('docs/knowledge/') for p in changed)
old=load(main/'old_same_tests/run.json');oldSummary=load(main/'old_same_tests/test-summary.json')
assert oldSummary['totals']==dict(tests=11,failures=6,errors=0,skipped=0)
testPath='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/ProductionFormValueBoundaryTest.java'
accessPath='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java'
oldInputs={x['path']:x['sha256'] for x in old['sourceFingerprints']}
assert oldInputs[testPath]==sha((repo/testPath).read_bytes())
assert oldInputs[accessPath]==sha(subprocess.check_output(['git','show',base+':'+accessPath],cwd=repo))
for rel in [testPath,accessPath]:copy(main/'old_same_tests/source'/rel,Path('old_same_tests/source')/rel)
contractPaths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md']
for rel in contractPaths:assert not git('diff',base,candidate,'--',rel)
out={'boundAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':base,
 'contractReadCommit':base,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeFiles':353,'assetIdInventoryExcludingSchemaDeclarations':2849,
 'allKnowledgeBytesUnchanged':True,'knowledgeInputCount':359,'mainInputCount':len(run['sourceFingerprints']),'currentAndCommittedInputsMatchRuns':True,
 'changedFiles':changed,'mainTests':summary['totals'],'actualPassedMainCases':205,'notExecutedExistingConditions':skips,'knowledgeTests':knowledgeSummary,
 'classes':caseCounts,'observations':observations,'copiedEvidence':copied,
 'processFailure':{'phase':'final','actualCounts':load(main/'final/test-summary.json')['totals'],'scope':'new fixture teardown errors only;not old product negative;retained original XML/log'},
 'sameFinalTestOldSource':{'actualCounts':oldSummary['totals'],'sameFinalTestBytes':True,'oldRuntimeAccessBytesMatchTarget':True,'qualification':'Old11 only;5 positive and6 actual query/resource budget failures,not all208 replayed'},
 'executionByThisOntologyRole':{'maven':False,'database':False,'browser':False},
 'qualification':'Ontology role read actual main records and checked input bytes/selected semantic definitions. This is not independent quality, native PG, full HTTP/E2E, full data rollback or complete W2/all-knowledge verification.'}
(raw/'final-source-evidence-binding.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['sourceCommit','mainInputCount','knowledgeInputCount','mainTests','knowledgeTests','allKnowledgeBytesUnchanged']},ensure_ascii=False))
