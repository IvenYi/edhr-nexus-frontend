from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
from zoneinfo import ZoneInfo

raw=Path(__file__).parent
subprocess.run(['python3',str(raw/'bind-final-evidence.py')],check=True)
subprocess.run(['python3',str(raw/'build-finite-records.py')],check=True)
binding=json.loads((raw/'final-source-evidence-binding.json').read_text())
finite=json.loads((raw/'finite-review-summary.json').read_text())
rows=[json.loads(s) for s in (raw/'finite-review-records.jsonl').read_text().splitlines()]
assert finite['candidate']==binding['sourceCommit']
sync=[{'id':x['id'],'disposition':x['knowledgeDisposition'],'scope':x['statementScope'],
       'sourceReferences':[x['path'],*x['reviewedReferences']]} for x in rows if x.get('id')]
result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':binding['sourceCommit'],'targetBranch':'edhr-dev','targetCommit':binding['targetCommit'],
                     'contractReadCommit':binding['contractReadCommit'],'uncommittedContractPaths':[]},
 'reason':'用户实际回复“两项一起优化”后，本批在ExecutionAccess局部优化行上下文复制和每个公开字段证据校验调用树内的文件元数据复用；不改变政策、术语、事实、规则、生命周期、接口、数据库、UI、审计或冻结契约。原字段/来源/签署保护保留，逐处仍比较原件名，不缓存验证成功结果、不跨调用复用。有限语义核对支持原规范合理；353知识文件及状态/投影/版本逐字节不变，无知识修订需求，不为工程优化新增同义知识或升级成熟度。',
 'changedArtifacts':[],'knowledgeSync':sync,'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.w2-values-finite-semantic-reference','checkType':'reference','command':'python3 build-finite-records.py','outcome':'passed',
   'evidence':['finite-review-records.jsonl','finite-review-summary.json','21有限记录=19 ID+2选定说明段，16 consistent/1既有evidence-gap/4既有needs-decision；非全库或历史unique通过。']},
  {'id':'validation.w2-values-knowledge-bytes-and-projection','checkType':'status-transition','command':'python3 bind-final-evidence.py','outcome':'passed',
   'evidence':['final-source-evidence-binding.json','353知识/2849资产ID与目标字节不变；schema声明不计资产ID。知识0.3.25/schema1.2.0/P0 in-progress、全部成熟度和visibility保持。']},
  {'id':'validation.w2-values-formal-main-knowledge-89','checkType':'schema','command':'主侧实际BusinessKnowledgeModelTest命令，见read-evidence/knowledge/run.json','outcome':'passed',
   'evidence':['read-evidence/knowledge/run.json','read-evidence/knowledge/test-summary.json','read-evidence/knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','主侧实际89项0失败/错误/跳过，359输入与候选相同；本体未执行Maven。']},
  {'id':'validation.w2-values-final-main-runtime-boundary','checkType':'evidence-path','command':'python3 bind-final-evidence.py','outcome':'passed',
   'evidence':['read-evidence/optimized_final/run.json','read-evidence/optimized_final/test-summary.json','final-source-evidence-binding.json',
    '实际208项中205通过、3既有条件未执行，0失败/错误。新增11项全过；本体读取原XML、7观察及35输入，不冒称运行或独立质量。',
    '同最终测试旧源11项为5正6真查询/资源预算失败，0错误/跳过；与read-evidence/final/test-summary.json早期9 teardown errors分开，旧例不冒称208全矩阵。']},
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(raw/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
report=f'''# W2有限本体核对

正式结果为 `not-applicable`，候选 `{binding['sourceCommit']}`、目标 `edhr-dev@{binding['targetCommit']}`。实际读取项目/角色/交接契约采用目标提交，候选对此无差异。全部知识保持0.3.25、schema1.2.0、P0 in-progress。本体角色没有修改仓库、运行Maven/数据库/浏览器或执行独立质量验证。

本批经主审转交用户实际授权“两项一起优化”，在ExecutionAccess局部实施浅层行上下文及调用内文件元数据复用，维护测试和DP同步。它改变工程实现而不改变业务定义，353知识文件与目标和候选逐字节相同；排除schema枚举/字段声明的资产ID为2849，没有新增或删除。有限21记录是19 ID及2个说明文件中的选定段落：16 consistent、1保留evidence-gap及4保留needs-decision。不把这21个历史交叉条目追加成新unique，不把机械库存、原implemented或测试通过当全知识审查完成。

原规则依据为DEC-0077-30及原用户“草稿不做校验”等确认的已建模适用范围：草稿免字段完整性/投影业务阻断，但认证、来源、字段权限、请求格式、证据和签署安全保持。“请求格式”不能扩张为所有草稿数值、选项、日期和必填值必须合法的新业务规则。最终完成的业务值校验单独保留。DEC-0077-31/32的投影可空批号/单位不取消普通字段自身required；示例区分数字0、空串及省略，显式null及全默认生命周期未由这些样本新增确认。

DEC-0067的显式DIRECT/PROCESS和使用时冻结、DEC-0074-04字段签名独立认证/份内失效、DEC-0080同字段共用选项及旧执行保护保持。源代码显示保存用之前值deepCopy合并请求，规范行ID、只读/签署及证据校验先于成功状态写入；最终提交校验完整值。FormInstanceRecordService及原执行服务继续拥有持久化、过程索引、正式投影和审计接续；这部分源码事实不等于本批原生PG完整事务验证。

本体已读主侧实际原件：统一clean候选208项中205通过、3既有条件未执行、0失败/错误；新增ProductionFormValueBoundaryTest十一项全部通过，另正式知识89/89通过。11份回归XML、1份知识XML、7个观察及35/359输入均与候选匹配。3个未执行为formRecordsBrowserFixture、browserEvidenceFixture、firstStartFreezesOneCommittedConfigurationDuringProcessRebinding，分别需浏览器长驻开关或专用PG竞争fixture；不能计passed或声称本轮浏览器/原生PG通过。主侧首次完整运行9个新测试出现夹具teardown错误，XML/log保留；它不是旧产品反证或业务断言失败。之后61155只取证时的206项通过203/旧跳过3也是优化前时点，不能代替当前受测提交。最终同测试旧源11项为5正6真查询/资源预算失败、0错误/跳过，与夹具关闭错误分开；旧11不冒称208旧源全矩阵。

两个新增功能例使用真实引擎/ExecutionAccess、隔离H2文件表和未使用的认证仓库mock，支持部分草稿、空串/0/省略、JSON状态重读、稳定行ID、最终必填、范围外附件拒绝不推进及本对象附件重开后提交。JSON状态往返不是设计器三片保存协议的新测试，也不是从持久数据库重新打开完整生产页面。没有把无签名夹具当电子签名全链验收。

本体对产品差异实际核对：每行仍创建独立根ObjectNode，setAll root/row共享子图；递归证据校验和FormReferenceLookup只读传入子图，没有发现把共享子图写回输入。文件metadata Map在公开五参入口新建，递归的objectId保持，所以ID键只限本对象这一调用树；SQL原target_type/target_id条件不变，逐处仍比较originalName，不缓存“已验证成功”。不同ID、同ID第二处假名称、范围外对象、删除后独立调用及DB异常传播由新增边界原件支持。不能把此局部复用表述为整个SAVE所有字段共用一次查询，也不改变独立公开调用重新读取。

7个规模观察是validateEvidence局部0/10/100/300行样本，普通及重复同文件分别核对累计分配/SQL，输入和previous原值保持。最终300行普通累计460928B、含文件527072B，后者1个真实H2 SELECT；这是调用线程累计分配，不是峰值/RSS，H2与计数记录开销不是生产SLA，样本和16MiB内部预算都不是业务行数上限。每行root+row查找上下文不等于已确认表头共享投影；原行定位循环没有顺带优化。主侧具体工程取舍由用户实际授权，不在本体里擅改政策。

保留的evidence-gap是另一通用质量/异常/源签署有效性变化自动判读high；四个needs-decision为表头共享、自由文本身份、A12失效历史视图与多租户。它们不依赖本次局部验证，不成为本批新增当前阻断，也没有被本体关闭。完整W2、W3-W7、A23含已审回查、全部UI/权限/并发及客户试用、生产容量仍非本批完成范围。

此结论是有限本体核对，不能替代全新独立质量实例。完整结构化结果见ontology-result.yaml，逐条范围见finite-review-records.jsonl，原件绑定见final-source-evidence-binding.json。manifest.json与SHA256SUMS封存本角色原件；SHA256SUMS排除自身、包含manifest。
'''
(raw/'review.md').write_text(report)
files=[]
for path in sorted(raw.rglob('*')):
 if not path.is_file() or path.name in ['manifest.json','SHA256SUMS']:continue
 data=path.read_bytes();files.append({'path':str(path.relative_to(raw)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'sealedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'candidate':binding['sourceCommit'],'files':files}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
checks=[]
for path in sorted(raw.rglob('*')):
 if path.is_file() and path.name!='SHA256SUMS':checks.append(hashlib.sha256(path.read_bytes()).hexdigest()+'  '+str(path.relative_to(raw)))
(raw/'SHA256SUMS').write_text('\n'.join(checks)+'\n')
for line in checks:
 expected,path=line.split('  ',1);assert hashlib.sha256((raw/path).read_bytes()).hexdigest()==expected
print('FINAL MANIFEST SHA256',hashlib.sha256((raw/'manifest.json').read_bytes()).hexdigest(),'FILES',len(files))
