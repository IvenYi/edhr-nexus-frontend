from pathlib import Path
from zoneinfo import ZoneInfo
import datetime, hashlib, json, subprocess, yaml

repo=Path('/workspace/edhr-nexus-frontend'); raw=Path(__file__).parent
raw.mkdir(exist_ok=True)
base='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
def command(*args):return subprocess.check_output(args,cwd=repo,text=True).strip()
def sha(data):return hashlib.sha256(data).hexdigest()
knowledge=sorted(p for p in (repo/'docs/knowledge').rglob('*') if p.is_file())
manifest=[];ids=[]
def walk(value,path,location=''):
 if isinstance(value,dict):
  if isinstance(value.get('id'),str):ids.append({'id':value['id'],'path':path,'location':location})
  for key,item in value.items():walk(item,path,location+'/'+str(key))
 elif isinstance(value,list):
  for index,item in enumerate(value):walk(item,path,location+'/'+str(index))
for path in knowledge:
 data=path.read_bytes();rel=str(path.relative_to(repo))
 assert sha(data)==sha(subprocess.check_output(['git','show',base+':'+rel],cwd=repo)),rel
 manifest.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
 if path.suffix in ['.yaml','.yml'] and rel!='docs/knowledge/schema.yaml':walk(yaml.safe_load(data),rel)
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/decisions/DEC-0067-form-fill-settings.yaml','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
 'docs/knowledge/decisions/DEC-0080-shared-choice-field-options.yaml','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml',
 'docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml','docs/knowledge/rules/form-fill-settings.yaml',
 'docs/knowledge/rules/production-field-signature.yaml','docs/knowledge/rules/production-execution.yaml',
 'docs/knowledge/rules/form-reference-runtime.yaml','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md',
 'docs/knowledge/evidence/form-fill-settings-confirmed.md','docs/knowledge/evidence/production-field-signature-confirmed.md',
 'docs/knowledge/evidence/shared-choice-options-2026-10-18.md','docs/knowledge/evidence/button-signature-confirmed.md',
 'docs/development/branch-review-20261016-w2-form-integrity/source-map.md',
 'docs/development/branch-review-20261016-w2-projection-integrity/source-map.md',
 'docs/development/branch-review-20261112-w2-form-values/decision-package.yaml',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/ProductionFormValueBoundaryTest.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionEngine.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceRecordService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceLookup.java']
inputs=[]
for rel in paths:
 data=(repo/rel).read_bytes();dest=raw/'initial-source'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
record={'capturedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'head':command('git','rev-parse','HEAD'),
 'target':command('git','rev-parse','origin/edhr-dev'),'actualRemoteBranch':command('git','ls-remote','--heads','origin','refs/heads/edhr-dev'),
 'actualContractReadCommit':base,'workingTreeStatus':command('git','status','--porcelain=v1'),'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0',
 'knowledgeFileCount':len(knowledge),'knowledgeIdCount':len(ids),'knowledgeDistinctIdCount':len({x['id'] for x in ids}),
 'knowledgeInputFingerprints':manifest,'readInputFingerprints':inputs,
 'qualification':'Whole knowledge inventory/hash only;not whole semantic audit. Source snapshots support the selected statement review only. No Maven, database or browser execution by ontology role.'}
(raw/'baseline-inputs.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
(raw/'knowledge-id-inventory.json').write_text(json.dumps(ids,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['head','target','actualRemoteBranch','knowledgeFileCount','knowledgeIdCount','knowledgeDistinctIdCount']},ensure_ascii=False))
