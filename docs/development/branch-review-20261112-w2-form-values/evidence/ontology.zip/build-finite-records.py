from pathlib import Path
import collections, hashlib, json, subprocess, yaml

repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='fb68cf02b707052eb6f5bfb85192ed711fba5e30'
candidate=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
index={}
def walk(value,path):
 if isinstance(value,dict):
  if isinstance(value.get('id'),str):
   assert value['id'] not in index,value['id']
   index[value['id']]=(path,value)
  for item in value.values():walk(item,path)
 elif isinstance(value,list):
  for item in value:walk(item,path)
for p in sorted((repo/'docs/knowledge').rglob('*.yaml')):
 if p.name!='schema.yaml':walk(yaml.safe_load(p.read_text()),str(p.relative_to(repo)))
rules='docs/knowledge/decisions/'
engine='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionEngine.java'
access='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java'
record='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceRecordService.java'
service='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionService.java'
confirmed='docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md'
specs=[
 ('DEC-0067-01','consistent','仅核对夹具明确DIRECT，不能由缺流程或无配置推导新的开放模式；发布/新实例全路径不由当前领域夹具证明。',[engine,'docs/knowledge/evidence/form-fill-settings-confirmed.md']),
 ('DEC-0067-04','consistent','保存重读/生产运行沿原冻结设置；当前JSON状态往返不是设计三片协议或所有管理发布入口的新证明。',[engine,service,'docs/knowledge/evidence/form-fill-settings-confirmed.md']),
 ('DEC-0067-05','consistent','不恢复旧模式推导/迁移，不改新快照不可变、权限和签署。',[service,engine]),
 ('rule.form-fill-settings.direct-configuration','consistent','开放DIRECT夹具不豁免字段只读、来源、按钮或原签署，直接模式和PROCESS配置不混合。',[engine,access]),
 ('rule.form-fill-settings.snapshot-runtime-continuity','consistent','只按本次传入的冻结form验证；现行模板后改不回写旧执行，当前测试不证明完整发布链。',[engine,service,record]),
 ('DEC-0074-04','consistent','字段签名仍独立于按钮；本份内容变化清除当前签名、保留历史责任，不把无签名夹具当真实签名全链验收。',[engine,access,'docs/knowledge/evidence/production-field-signature-confirmed.md']),
 ('rule.production-inline-signature','consistent','签名有效性、份内字段位置和历史保护保持，性能讨论不能跳过安全校验或改签名身份。',[engine,access]),
 ('DEC-0080-01','consistent','同身份字段共用冻结模型组选项，当前位置副本不另开允许值；不因当前多选asText兼容推导新策略或重新修旧PR。',[engine,'docs/knowledge/evidence/shared-choice-options-2026-10-18.md']),
 ('DEC-0077-12','consistent','使用时配置快照与来源记录、投影各自保留；主值上下文复用建议不能改为读最新模板或回写旧记录。',[service,record,confirmed]),
 ('DEC-0077-30','consistent','草稿免阻断性字段完整性/投影业务校验；请求格式、认证、字段权限、来源/证据和签署安全保留。“请求格式”不授权新加草稿数值/枚举/日期业务门禁。',[engine,access,confirmed]),
 ('DEC-0077-31','consistent','投影可空批号不取消普通字段自身required；本次空/省略实验不扩为全字段可空政策。',[engine,confirmed]),
 ('DEC-0077-32','consistent','投影可空单位/不换算与普通单选必填及默认值分开，不将piece默认示例推广成单位推断或全默认生命周期。',[engine,confirmed]),
 ('DEC-0077-33','consistent','已保存过程内容与最终完成正式统计分离；直接调用引擎后的状态断言不是持久化索引/事务或原生PG全链的证明。',[service,record,confirmed]),
 ('rule.production-execution-completion-check','consistent','完成仍要必填表单最终合法完成；SAVE不满足完工，普通0值不被当缺失。',[engine]),
 ('discrepancy.dhr-review-complete-evidence-impact-gap','evidence-gap','旧通用质量/异常/源签署变化自动判读high保持，当前JSON/行资源实验不关闭它。',['docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml']),
 ('question.form-projection-header-shared-fields','needs-decision','root+row查询上下文是原引用工程实现，不等于已确认业务投影表头共享/去重方案；原问题继续，仅阻塞依赖它的后续。',[access,'docs/knowledge/open-questions.yaml']),
 ('question.form-projection-free-text-identity','needs-decision','自由文字解析及最终错误身份处置未决；本轮数值/真实文件ID示例不为该身份问题给答案。',['docs/knowledge/open-questions.yaml']),
 ('question.form-projection-trace-index-effective-scope','needs-decision','保存时点已确认但A12失效历史视图/受控修订解释继续未决，不由本轮证明完整历史业务。',['docs/knowledge/open-questions.yaml']),
 ('question.multi-tenant-workflow-isolation','needs-decision','当前同对象文件target隔离不是全多租户契约，MVP范围内夹具不补此问题。',['docs/knowledge/open-questions.yaml']),
]
rows=[]
for id_,conclusion,scope,evidence in specs:
 path,value=index[id_]
 for ref in evidence:assert (repo/ref).is_file(),ref
 rows.append({'id':id_,'path':path,'candidate':candidate,'reviewStatus':'reviewed','semanticConclusion':conclusion,
  'statementScope':scope,'sourceRecordSha256':hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True).encode()).hexdigest(),
  'sourceFileSha256':hashlib.sha256((repo/path).read_bytes()).hexdigest(),'provenance':'user-confirmed and original-source;prior reports secondary only',
  'reviewedReferences':evidence,'knowledgeDisposition':'retained' if conclusion=='consistent' else 'deferred',
  'runtimeQualification':'No Maven/database/browser executed by ontology role;current main execution evidence bound separately at final. Limited claim scope, not whole record/runtime coverage.'})
for path,scope in [
 ('docs/knowledge/README.md','仅当前知识版本/P0及保留剩余边界；上轮通知high已关闭的范围不被重开，也不把当前W2批次当全审完成。'),
 (confirmed,'仅草稿/安全与保存后过程追溯原话及历史时点；保留旧maturity和旧运行原件，不反填本次测试结果。')]:
 rows.append({'path':path,'candidate':candidate,'reviewStatus':'reviewed','semanticConclusion':'consistent','statementScope':scope,
  'sourceFileSha256':hashlib.sha256((repo/path).read_bytes()).hexdigest(),'knowledgeDisposition':'retained',
  'runtimeQualification':'Selected paragraphs only;not whole-file semantic completion.'})
(raw/'finite-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
summary={'baseCommit':base,'candidate':candidate,'knowledgeFiles':353,'assetIdInventoryExcludingSchemaDeclarations':len(index),
 'finiteSemanticRecords':len(rows),'finiteIdRecords':len(specs),'finiteFileRecords':2,'byConclusion':dict(collections.Counter(x['semanticConclusion'] for x in rows)),
 'knowledgeChanges':[],'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','roadmap':'P0/in-progress',
 'wholeKnowledgeAndWholeBranchAuditCompleted':False,'historicalOverlapNotAddedToUniqueCoverage':True,
 'qualification':'Read-only finite semantic evidence. Consistent is for listed statement scope, not all implementation/runtime matrices. Performance quantification cannot create business policy.'}
(raw/'finite-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
