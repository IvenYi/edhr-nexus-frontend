from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, xml.etree.ElementTree as ET
root=Path(os.environ.get('EDHR_CANDIDATE_ROOT','/workspace/edhr-nexus-frontend'))
raw=Path(os.environ.get('EDHR_CANDIDATE_RAW',str(Path(__file__).parent)))
out=raw/sys.argv[1];out.mkdir(parents=True,exist_ok=False)
shutil.copyfile(__file__,out/'runner-source.py')
selected='ProductionFormValueBoundaryTest,ProductionExecutionFormValuesTest,ProductionExecutionEngineTest,ExecutionAccessTest,ProductionExecutionIntegrationTest,FormInstanceRecordStageTest,FormTraceIndexServiceTest,FormProjectionInterpreterTest,FormReferenceConfigTest,FormReferenceLookupTest,ReferenceContextInitializationTest'
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md',
 'docs/development/branch-review-20261112-w2-form-values/decision-package.yaml','gmp-platform/backend/pom.xml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionEngine.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceRecordService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormTraceIndexService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormProjectionService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionSnapshotBuilder.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceConfig.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceLookup.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormProjectionInterpreter.java',
 'gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/document.ts',
 'docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0067-form-fill-settings.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml',
 'docs/knowledge/decisions/DEC-0080-shared-choice-field-options.yaml']
classes=selected.split(',')
for c in classes:
 p=list((root/'gmp-platform/backend/src/test/java').rglob(c+'.java'));assert len(p)==1,c
 paths.append(str(p[0].relative_to(root)))
inputs=[]
for path in paths:
 b=(root/path).read_bytes();inputs.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
tmp=out/'vm-tmp';tmp.mkdir()
cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','-f','gmp-platform/backend/pom.xml',
 '-Dtest='+selected,'-Dedhr.audit.w2Values=true','-Dedhr.audit.w2ValueOutput='+str(out/'observations'),'-DargLine=-Xmx1536m -Djava.io.tmpdir='+str(tmp),'test']
started=datetime.datetime.now(datetime.timezone.utc)
record={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'workingTreeState':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'sourceFingerprints':inputs,
 'command':cmd,'startedAt':started.isoformat(),'environment':'Domain methods and H2 fixtures;not native PostgreSQL or browser/E2E'}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'maven.log').open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=r.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
totals=dict(tests=0,failures=0,errors=0,skipped=0);reports=[];missing=[];conditional=[]
for c in classes:
 hits=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+c+'.xml') if p.stat().st_mtime>=started.timestamp()]
 if len(hits)!=1:missing.append(c);continue
 p=hits[0];shutil.copyfile(p,out/p.name);xml=ET.parse(p).getroot();a=xml.attrib;counts={k:int(a[k]) for k in totals}
 for case in xml.findall('testcase'):
  skip=case.find('skipped')
  if skip is not None:conditional.append({'class':a['name'],'name':case.attrib['name'],'reason':skip.attrib.get('message','')})
 reports.append({'name':a['name'],**counts})
 for k in totals:totals[k]+=counts[k]
summary={'totals':totals,'classes':reports,'missingFreshReports':missing,'unchangedConditionalNotExecuted':conditional}
(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True)
assert r.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==0
assert totals['skipped']==3 and {s['name'] for s in conditional}=={'formRecordsBrowserFixture','browserEvidenceFixture','firstStartFreezesOneCommittedConfigurationDuringProcessRebinding'}
