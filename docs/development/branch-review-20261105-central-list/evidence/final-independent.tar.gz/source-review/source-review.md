# 中央流程列表源码审查回执

源码审查已完成，未确认本范围内的确定性业务缺陷。未修改任何仓库文件、未执行运行测试；本结果不替代最终独立质量验证。

```yaml
sourceReview:
  status: FINAL
  knowledgeBaselineVersion: 0.3.25
  contractBaseline:
    sourceCommit: b52138259111dd5a0d99299087913500eff627f4
    targetBranch: edhr-dev
    targetCommit: b52138259111dd5a0d99299087913500eff627f4
    contractReadCommit: b52138259111dd5a0d99299087913500eff627f4
    uncommittedContractPaths: []
  changedFiles: []
  confirmedDefects: []
  runtimeValidation: not-executed
```

已核对的链路与结论：

- **入口**：`router/index.tsx:106–107` 的“流程日志”`/workflow/instances`、“流程干预”`/workflow/interventions`，共用 `InstanceList.tsx:81–82` → `workflow-operations.ts:18–19` → `WorkflowOperationsController.java:21–26`。
- **分页与总数**：`WorkflowOperationsQuery.java:43–61` 对相同两源 UNION、权限和筛选分别 COUNT、分页查询，数据库执行 LIMIT/OFFSET，没有 Java 全量分页、逐行 SQL 或列表姓名 N+1。UI `InstanceList.tsx:131–134` 实际使用总数和总页数，不能把这次 COUNT 当“未使用查询”直接删除。
- **筛选**：状态白名单、128字限制、参数绑定及 `%/_/!` 字面转义存在；干预使用 runningOnly、日志使用状态筛选；文本ID排序稳定，但不是数字ID排序，未发现现行规范要求反向。
- **来源与身份**：普通表单使用 `form-<recordId>`，复用持久化表单份与执行事实。数据库有 execution 对象主键和 `(tenant,object,operation,copy)` 唯一约束，正常持久化记录不会因 execution JOIN 自身重复。
- **权限/知识**：源码保留 DHR有效领域关联、普通表单领域读取/干预权限、关联人员可见范围。与 `DEC-0093-01/04`、`rule.workflow-central-entry.domain-projection` 的有限范围一致；不认证完整多租户矩阵。
- **既有测试**：`RecordControlPostgresIntegrationTest.java:608` 已覆盖两源总数、跨页身份、精确ID、`%`字面查询与状态过滤。它只有两个记录，不能证明大数据性能。

需本轮 native 实验决定的风险：

1. `FormWorkflowOperations.java:41–48` 从每份表单关联的执行快照/状态文本中取 JSON，并枚举工序和表单；非管理员可见性 `:71–76` 还可能枚举历史和审批节点。**不能直接断言逐行完整扫描**：PG16可能下推筛选或使用 Memoize。
2. `WorkflowOperationsQuery.java:48,59–61` 在 UNION 外按转成文本的时间、ID排序；现有原列索引不自动保证免排序。返回20条仍可能检查很多候选记录。
3. 数据量要分成“单对象≤300份”与“长期累计对象数”两轴；每份DHR不大，并不保证中央历史列表一直小。
4. 深页OFFSET、模糊关键词、运行中列表、普通关联人员的历史权限分支应单独测，不把管理员首屏成绩外推。

建议最小实验：对象内1/30/300表单 × 历史对象1/10/100；记录真实两条SQL（**观察器需包含 queryForObject COUNT**），分别 `EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON)`，核 Function Scan loops/过滤行、Memoize命中、排序及缓冲。不得仅用SQL条数判断性能；当前无依据直接加索引或改投影表。

A23与具体拆分：

- `total == null ? 0 : total`（`WorkflowOperationsQuery.java:62`）对无GROUP的 COUNT(*)属冗余兜底，但没有当前行为危害，不建议为清理而改产品。
- `visibilityArgs()`（`FormWorkflowOperations.java:80–81`）再次调用 `visibility()` 并以SQL含`?`推断参数数量，存在维护脆弱性，当前三个分支参数一致。将来实际调整权限时可让一个私有 `Scope(sql,args)` 一次返回，避免二次推导。
- 若后续需要重写JSON查询，可将普通表单 `source/detail/visibility` 抽到 `FormWorkflowProjectionQuery`，现类保留签名改派与写事务；本轮无需先做该拆分，也无需新建通用查询框架。

审查仅覆盖上述列表调用链及相关声明，不计整文件或全仓审计完成；暂停的签名密码链、生产管理弹窗样式和第三文本ID索引项均未触碰。

## 归档补记

本文件保存前述正式 FINAL 的原意；此后未补充审查、运行测试或改变结论。伴随的 `read-file-sha256.json` 和 `read-file-sha256.txt` 记录本实例明确读取内容的文件及部分搜索定位文件的当前整文件 SHA-256，并与审查基线逐一比对；摘要仅证明原文件身份，不表示整文件语义覆盖。搜索工具扫描的整个目录不计为已读或已完成文件审计。
