import pathlib,tarfile,hashlib,json,subprocess,collections,datetime,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-central-list-quality-20261105/evidence-review')
scope=root/'docs/development/branch-review-20261105-central-list'
base='b52138259111dd5a0d99299087913500eff627f4';head='900edae735f5bd37e070a4c2f519e06e4e8728e3'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def blob(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
assert git('rev-parse','HEAD')==head
assert git('status','--porcelain')==''
pack=scope/'evidence/primary-and-ontology.tar.gz';meta=json.loads((scope/'evidence/primary-manifest.json').read_text())
assert sha(pack.read_bytes())==meta['sha256'];assert pack.stat().st_size==meta['bytes']
checks=[]
with tarfile.open(pack) as archive:
 data={m.name:archive.extractfile(m).read() for m in archive.getmembers() if m.isfile()}
 members={m.name:m for m in archive.getmembers() if m.isfile()}
 manifest=json.loads(data['manifest.json'])
 assert len(data)==87 and len(manifest['files'])==86
 assert set(data)=={f['path'] for f in manifest['files']}|{'manifest.json'}
 for f in manifest['files']:
  assert len(data[f['path']])==f['bytes'] and sha(data[f['path']])==f['sha256'],f['path']
 checks.append({'id':'outer-manifest','files':86,'members':87,'sha256':sha(pack.read_bytes()),'outcome':'passed'})
 inner=json.loads(data['ontology/manifest.json']);assert len(inner['files'])==32
 for f in inner['files']:
  value=data['ontology/'+f['path']];assert len(value)==f['bytes'] and sha(value)==f['sha256'],f['path']
 assert data['ontology/manifest.sha256'].decode().split()[0]==sha(data['ontology/manifest.json'])
 checks.append({'id':'ontology-manifest','files':32,'sha256':sha(data['ontology/manifest.json']),'outcome':'passed'})
 snapshots=[]
 for path,value in data.items():
  marker='/read-snapshots/'
  if marker in path:
   source=path.split(marker,1)[1];assert value==blob(head,source),path
   snapshots.append({'archivePath':path,'sourcePath':source,'sha256':sha(value)})
 for phase,count in [('focused',7),('full',184)]:
  prefix='primary/native-'+phase+'/';run=json.loads(data[prefix+'run.json']);start=datetime.datetime.fromisoformat(run['started']).timestamp()
  assert run['exitCode']==0 and run['commit']==base
  xmls=[(p,b) for p,b in data.items() if p.startswith(prefix+'TEST-') and p.endswith('.xml')]
  totals=collections.Counter();classes=[]
  for p,b in xmls:
   node=ET.fromstring(b);v={k:int(node.attrib[k]) for k in ['tests','failures','errors','skipped']};totals.update(v);classes.append({'class':node.attrib['name'],**v})
   assert members[p].mtime>=start,p
  summary=json.loads(data[prefix+'test-summary.json']);assert dict(totals)==summary['totals']=={'tests':count,'failures':0,'errors':0,'skipped':0}
  assert not summary['missingFreshReports']
  for f in run['sourceFingerprints']:
   value=data[prefix+'source/'+f['path']];assert len(value)==f['bytes'] and sha(value)==f['sha256'];assert value==blob(head,f['path'])
  checks.append({'id':'primary-'+phase+'-xml-and-source','totals':dict(totals),'classes':classes,'runCommit':run['commit'],'sourceMatchesCandidate':True,'outcome':'passed'})
 full=data['primary/native-full/observations.jsonl'];events=[json.loads(l) for l in full.decode().splitlines()];central=[e for e in events if e['kind'].startswith('central-list-')]
 counts={'allObservationEvents':len(events),'allLogicalSelects':sum(e['totalStatements'] for e in events),'centralEvents':len(central),'centralLogicalSelects':sum(e['totalStatements'] for e in central),'centralCountSelects':sum(s.startswith('SELECT count(*)') for e in central for s in e['jdbcSql']),'separateExplainReplays':sum('plan' in q for e in central for q in e['data'].get('statements',[]))}
 assert counts=={'allObservationEvents':115,'allLogicalSelects':344,'centralEvents':25,'centralLogicalSelects':48,'centralCountSelects':24,'separateExplainReplays':28}
 report=json.loads((scope/'performance-report.json').read_text());assert report['sourceSha256']==sha(full)
 assert all(report[k]==v for k,v in counts.items())
 for event,scenario in zip(central,report['scenarios'],strict=True):
  assert scenario['kind']==event['kind'];assert scenario['input']=={k:v for k,v in event['data'].items() if k!='statements'}
  assert scenario['requestElapsedMs']==event['elapsedNanos']/1e6 and scenario['logicalSelects']==event['totalStatements']
  plan_sources=[q for q in event['data'].get('statements',[]) if 'plan' in q]
  assert len(plan_sources)==len(scenario['plans'])
  for raw,projected in zip(plan_sources,scenario['plans'],strict=True):
   assert raw['plan'][0]['Execution Time']==projected['executionMs']
   assert raw['plan'][0]['Planning Time']==projected['planningMs']
 checks.append({'id':'observations-and-projection','counts':counts,'sourceSha256':sha(full),'outcome':'passed'})
 def nodes(n):
  yield n
  for p in n.get('Plans',[]):yield from nodes(p)
 expansion=[]
 for e in central:
  d=e['data']
  if e['kind']=='central-list-scale' and (d['objects'],d['formsPerObject']) in [(1,300),(30,100)]:
   for q in d['statements']:
    ns=list(nodes(q['plan'][0]['Plan']));scans=[n for n in ns if n.get('Alias')=='f' and n['Node Type']=='Function Scan'];assert len(scans)==1
    scan=scans[0];expected=d['objects']*d['formsPerObject']**2
    assert scan['Actual Loops']*scan['Actual Rows']==expected
    expansion.append({'objects':d['objects'],'formsPerObject':d['formsPerObject'],'runningOnly':d['runningOnly'],'query':'count' if q['sql'].startswith('SELECT count(*)') else 'content','formExpansionRows':expected,'planExecutionMs':q['plan'][0]['Execution Time']})
 checks.append({'id':'native-plan-expansion-arithmetic','samples':expansion,'outcome':'passed'})
 records=[json.loads(l) for l in data['ontology/audit-records.jsonl'].decode().splitlines()];conclusions=collections.Counter(r['conclusion'] for r in records)
 assert len(records)==len({r['id'] for r in records})==12;assert conclusions=={'consistent':10,'superseded':1,'evidence-gap':1}
 assert all(r['reviewStatus']=='reviewed' and r['runtimeValidation']=='not-executed-by-ontology' for r in records)
 assert next(r for r in records if r['conclusion']=='superseded')['id']=='DEC-0092-05'
 assert next(r for r in records if r['conclusion']=='evidence-gap')['id']=='question.multi-tenant-workflow-isolation'
 assert (scope/'ontology-result.yaml').read_bytes()==data['ontology/ontology-result.yaml']
 checks.append({'id':'finite-ontology-records','conclusions':dict(conclusions),'ids':[r['id'] for r in records],'outcome':'passed'})
 fps=json.loads(data['ontology/knowledge-fingerprints.json']);assert len(fps)==350
 for f in fps:assert sha(blob(head,f['path']))==f['sha256'] and blob(head,f['path'])==blob(base,f['path'])
 checks.append({'id':'knowledge-350-byte-preservation','outcome':'passed'})
 (out/'source-snapshots-verified.json').write_text(json.dumps(snapshots,indent=2)+'\n')
 (out/'ontology-audit-records-reviewed.jsonl').write_bytes(data['ontology/audit-records.jsonl'])
baseline=json.loads((scope/'baseline-review.json').read_text());paths=git('ls-tree','-r','--name-only',base).splitlines()
assert len(paths)==baseline['trackedPathsAtTarget']==7529
assert sum(p.startswith('docs/knowledge/') for p in paths)==baseline['knowledgeFilesAtTarget']==350
assert baseline['wholeFileComplete']==0 and baseline['historicalUniqueCoverage'] is None and baseline['wholeAuditComplete'] is False
assert baseline['pendingKnowledgeIncrementCandidates']==931 and baseline['priorUiDiagnosticCandidatesPending']==86
assert git('diff','--name-only',base,head,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','docs/architecture','AGENTS.md','codeplzreadme.md','docs/agents')==''
checks.append({'id':'baseline-and-protected-paths','trackedPaths':7529,'knowledgeFiles':350,'semanticCompletionNotAsserted':True,'outcome':'passed'})
source_review=json.loads((scope/'source-review.json').read_text())
for f in source_review['sourceFingerprints']:
 value=blob(head,f['path']);assert len(value)==f['bytes'] and sha(value)==f['sha256']
 assert f['sameAsTarget']==(value==blob(base,f['path']))
assert source_review['productFilesChanged']==0 and source_review['testFilesChanged']==1 and source_review['wholeFileComplete']==0
checks.append({'id':'source-review-projection','sourceFingerprints':len(source_review['sourceFingerprints']),'outcome':'passed'})
result={'role':'independent-quality-evidence-subcheck','status':'FINAL','result':'passed','isFinalQualityResult':False,'baseCommit':base,'headCommit':head,'contractReadCommit':head,'uncommittedContractPaths':[],'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'limits':['No Maven, PostgreSQL or browser executed by this subcheck; main final QA owns independent runtime evidence','Finite source/knowledge consistency only; no whole-repository semantic completion','Performance issue remains open; observed measurements synthetic and single-shot, no production SLA or automatic approval'],'changedProductTestConfigFiles':[]}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'result':result['result'],'checks':len(checks),'sourceSnapshots':len(snapshots),'findings':[]},ensure_ascii=False))
