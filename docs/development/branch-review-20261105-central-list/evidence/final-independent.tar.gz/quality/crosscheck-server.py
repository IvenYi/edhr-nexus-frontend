import pathlib,json,re,collections,hashlib
out=pathlib.Path('/tmp/edhr-central-list-quality-20261105');native=out/'native'
events=[json.loads(x) for x in (native/'observations.jsonl').read_text().splitlines()]
def normalize(sql):
 return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql.replace('??','?'))).strip().rstrip(';')
expected=collections.Counter(normalize(s) for e in events for s in e['jdbcSql']+e['hibernateSql'])
expected_explain=collections.Counter(normalize('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+q['sql']) for e in events for q in e['data'].get('statements',[]) if 'plan' in q)
raw=(native/'postgres.log').read_text()
header=re.compile(r'^\d{4}-\d\d-\d\d [^\n]+?\[\d+\] (\S+) (\S+) ',re.M)
matches=list(header.finditer(raw));own=[];others=collections.Counter();errors=[]
for i,m in enumerate(matches):
 body=raw[m.end():matches[i+1].start() if i+1<len(matches) else len(raw)].strip()
 duration=re.match(r'LOG:\s+duration:\s+[\d.]+ ms\s+(?:execute [^:]+:|statement:)\s*(.*)',body,re.S)
 if not duration:
  if m.group(1)=='edhr_workflow_read_test_qa' and body.startswith('ERROR:'):errors.append(body)
  continue
 sql=duration.group(1).strip()
 if m.group(1)=='edhr_workflow_read_test_qa':own.append(sql)
 else:others[m.group(1)]+=1
selects=[s for s in own if s.upper().startswith('SELECT')]
explains=[s for s in own if s.upper().startswith('EXPLAIN')]
actual=collections.Counter(normalize(s) for s in selects)
actual_explain=collections.Counter(normalize(s) for s in explains)
matched={s:actual[s] for s in expected}
unmatched_selects=collections.Counter(normalize(s) for s in selects if normalize(s) not in expected)
def digest(s):return hashlib.sha256(s.encode()).hexdigest()
summary={'observationEvents':len(events),'logicalRequestSelects':sum(expected.values()),'logicalCountSelects':sum(v for s,v in expected.items() if s.startswith('SELECT count(*)')),'serverOwnDatabaseSuccessfulSelects':len(selects),'serverOwnDatabaseSuccessfulExplainReplays':len(explains),'expectedSeparateExplainReplays':sum(expected_explain.values()),'requestSignatureCount':len(expected),'requestSignatures':[{'sha256':digest(s),'expected':v,'serverActual':actual[s],'sql':s} for s,v in expected.items()],'explainSignatures':[{'sha256':digest(s),'expected':v,'serverActual':actual_explain[s],'sql':s} for s,v in expected_explain.items()],'excludedOwnDatabaseSelects':[{'sha256':digest(s),'count':v,'sql':s} for s,v in unmatched_selects.items()],'excludedOtherDatabaseSuccessfulStatements':dict(others),'ownDatabaseErrors':errors,'normalization':'collapse whitespace; JDBC escaped ?? operator to ?; PostgreSQL $n binding placeholders to ?; preserve remaining SQL text','notAllNetworkSql':True}
expected_startup_errors=[e for e in errors if e=='ERROR:  relation "public.databasechangeloglock" does not exist at character 22']
unexpected_errors=[e for e in errors if e not in expected_startup_errors]
summary['expectedEmptyLiquibaseLockProbeErrors']=expected_startup_errors
summary['unexpectedOwnDatabaseErrors']=unexpected_errors
summary['requestCountersMatch']=dict(expected)==matched
summary['explainCountersMatch']=expected_explain==actual_explain
summary['excludedOwnDatabaseSelectCount']=sum(unmatched_selects.values())
(out/'server-crosscheck.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print({k:v for k,v in summary.items() if k not in ['requestSignatures','explainSignatures','excludedOwnDatabaseSelects','normalization']})
assert len(events)==25 and sum(expected.values())==48 and summary['logicalCountSelects']==24
assert summary['requestCountersMatch'] and summary['explainCountersMatch'] and len(explains)==28
assert len(expected_startup_errors)==1 and not unexpected_errors
