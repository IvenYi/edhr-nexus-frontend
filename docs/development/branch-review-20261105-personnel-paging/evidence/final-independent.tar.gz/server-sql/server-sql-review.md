# Independent server SQL crosscheck — FINAL

Candidate `b81b67ed7602740cda7b43cadcd3ce7bf8ba928a`; target `edhr-dev@f8638f5400356c4820d59bf26be50a79b453ca12`. Contract read from candidate, knowledge0.3.25/schema1.2/P0 retained. Actual own native run:35/35,0 failure/error/skip, PostgreSQL16.15. No candidate product/test/fixture/config/knowledge was modified.

## Result

Seven required checks passed; no finding or blocker within this child scope. Own server log verifies90 observer events/296 business SELECT across17 signatures. Each observed signature count exactly equals actual server execute/statement count; parse/bind records are not double counted. The log also contains96 other successful SELECT records (392 total):1 own database-existence probe,3 version probes,8 driver/framework metadata,11 Liquibase metadata,6 sequence initializations,65 test evidence assertions,2 fixture state reads. Failed existence probes are separately retained; this is not an all-network-SQL count.

69 personnel directory queries bind a database LIMIT of51 in9 cases or101 in60 cases, representing requested size50/100 plus one lookahead. No directory COUNT occurs. Native assertions independently ran251 same-name qualified users through6 content pages plus7th empty page:50/50/50/50/50/1/0; exact numericIDs/order/no duplicates and hasNext asserted. Original candidate5000 case ran all50 pages, each100, exact aggregateIDs40000..44999, finalhasNextfalse. The database log proves bound limits/offsets; native assertions prove returned contents.

55 candidate directory executions each bind one JSON String array with exact checked contents. Candidate0/1/100/5000 keyword first pages use8 directory/11 service bind slots; subsequent49 pages use9/12. The two no-keyword exact identity scenarios use6 directory slots. Raw/wrapped originSnapshot keep noncanonical text, invalid/overflow/SQL-like text and duplicates unchanged; only43 matches, with no snapshot write. There is no candidate-count-sized SQL placeholder list.

Current ordinary-form names use9 actual one-array executions, with source SqlArrayValue(bigint); generic workflow name lookups retain5 SqlArrayValue(varchar) executions.100 distinct or repeated-missing form assignments yield2 total SELECTs; repeated existing also2; blank-only1. Visibility failure occurs before name reads. Native history/signatureRef/raw-ID/missing-name/numeric-alias/state-preservation assertions all passed.

## Preserved non-product errors

One server ERROR at postgres.log line139 is the fresh Liquibase probe for absent public.databasechangeloglock. The next records show rollback then CREATE TABLE and completed migrations. It is retained as a bootstrap error, not reported as zero server errors or a product/JUnit failure.

The first analysis script mistakenly expected8/9 bind slots for the two no-keyword candidate identity scenarios; their actual source intentionally omits two keywordLIKE slots and binds6. Original script/AssertionError are retained in crosscheck-initial.py and crosscheck-initial-error.log; corrected analysis validates6 for those scenarios,8/9 for keyword cases. Product/test/fixture files and assertions were unchanged. Dependency-discovery root node_modules miss and post-cleanup docker-log inspection miss are recorded in inspection-and-analysis-notes.json.

## Reproduction and provenance

run-server-native.py contains the exact owned detached-worktree, existing frontend dependency link, isolated PostgreSQL16 logging and Maven orchestration. commands.json/run.json/test-summary.json/XML/maven.log/postgres.log/observations.jsonl are raw records. crosscheck.py reconstructs executed SELECTs, normalizes placeholders only, compares all signatures, verifies actual LIMIT/OFFSET/JSON-array values and categorizes exclusions. native-coverage-and-parameter-matrix.json maps events and name arrays; input-fingerprints.json identifies21 actual source/contract inputs.

All owned container/worktree/dependency link were removed before FINAL. Start/end/final fetch target remainedf8638f54; candidate remainedb81b67ed and main worktree clean. Final fingerprints match all21 candidate inputs. result.yaml is the formal scoped qualityResult. manifest.json lists every original file with byte count/SHA256; manifest.sha256 seals that manifest.

This child does not independently claim parent's177 native/89 knowledge/browser/build checks, productionSLA/physicalIO, fullHTTP/JWT/signature or whole-audit completion. Deferred textID index and prior wider audit gaps remain outside this batch.
