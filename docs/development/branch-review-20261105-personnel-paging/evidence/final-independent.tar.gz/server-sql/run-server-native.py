import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,sys,xml.etree.ElementTree as ET
repo=pathlib.Path('/workspace/edhr-nexus-frontend');work=pathlib.Path('/tmp/edhr-personnel-paging-server-wt-20261105');out=pathlib.Path('/tmp/edhr-personnel-paging-final-qa-20261105/server-sql')
candidate='b81b67ed7602740cda7b43cadcd3ce7bf8ba928a';target='f8638f5400356c4820d59bf26be50a79b453ca12';name='edhr-personnel-paging-server-cross-20261105';db='edhr_workflow_read_test_server_cross';created=False;wt=False;code=99
commands=[]
def run(args,**kw):
 result=subprocess.run(args,capture_output=True,text=True,**kw);commands.append({'command':args,'cwd':str(kw.get('cwd','')),'exitCode':result.returncode,'stdout':result.stdout,'stderr':result.stderr})
 if result.returncode:raise RuntimeError(str(args)+'\n'+result.stdout+'\n'+result.stderr)
 return result.stdout.strip()
try:
 assert run(['git','rev-parse','HEAD'],cwd=repo)==candidate
 run(['git','fetch','origin','edhr-dev'],cwd=repo);assert run(['git','rev-parse','origin/edhr-dev'],cwd=repo)==target
 run(['git','worktree','add','--detach',str(work),candidate],cwd=repo);wt=True
 dependencies=repo/'gmp-platform/frontend/node_modules';assert dependencies.is_dir();(work/'gmp-platform/frontend/node_modules').symlink_to(dependencies,target_is_directory=True)
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/rules/personnel-target-selection.yaml','docs/development/branch-review-20261105-personnel-paging/decision-package.yaml','docs/development/branch-review-20261105-personnel-paging/README.md','docs/development/branch-review-20261105-personnel-paging/review-notes.md','docs/development/branch-review-20261105-personnel-paging/performance-report.json','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']
 fps=[]
 for path in paths:
  data=(work/path).read_bytes();f=out/'source'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);fps.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 (out/'input-fingerprints.json').write_text(json.dumps(fps,indent=2)+'\n')
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=QA|%m|%p|%d|%u| ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own PG not ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);postgres=run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])
 env=os.environ.copy();env.update(WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',PGUSER='postgres')
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'observations.jsonl'),'-Dtest=WorkflowReadObservationPostgresTest','test'];start=datetime.datetime.now(datetime.timezone.utc)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=work,env=env,stdout=f,stderr=subprocess.STDOUT)
 meta={'command':command,'cwd':str(work),'candidate':candidate,'target':target,'contractReadCommit':candidate,'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'database':env['WORKFLOW_READ_TEST_DATABASE_URL'],'containerId':cid,'postgres':postgres,'existingDependenciesLinkedBeforeBuild':True}
 (out/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
 files=[p for p in (work/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml') if p.stat().st_mtime>=start.timestamp()];assert len(files)==1
 shutil.copy2(files[0],out/files[0].name);xml=ET.parse(files[0]).getroot();totals={k:int(xml.attrib.get(k,0)) for k in ('tests','failures','errors','skipped')};(out/'test-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
 for fp in fps:assert hashlib.sha256((work/fp['path']).read_bytes()).hexdigest()==fp['sha256']
 assert run(['git','diff','--name-only'],cwd=work)==''
 code=0 if result.returncode==0 and totals=={'tests':35,'failures':0,'errors':0,'skipped':0} else 1;print(json.dumps({'mavenExit':result.returncode,'totals':totals,'sourceUnchanged':True}))
finally:
 cleanup={'ownedContainer':name,'containerRemoved':False,'ownedWorktree':str(work),'worktreeRemoved':False,'dependencyLinkRemoved':False}
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr)
  run(['docker','stop',name]);
  for _ in range(50):
   if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:cleanup['containerRemoved']=True;break
   time.sleep(.1)
 if wt:
  link=work/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink();cleanup['dependencyLinkRemoved']=True
  run(['git','worktree','remove',str(work)],cwd=repo);cleanup['worktreeRemoved']=not work.exists()
 run(['git','fetch','origin','edhr-dev'],cwd=repo);cleanup['targetAtEnd']=run(['git','rev-parse','origin/edhr-dev'],cwd=repo);cleanup['mainHeadAtEnd']=run(['git','rev-parse','HEAD'],cwd=repo);cleanup['mainStatusAtEnd']=run(['git','status','--porcelain'],cwd=repo)
 (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n');(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps(cleanup))
sys.exit(code)
