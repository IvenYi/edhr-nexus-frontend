import pathlib,re,json,collections,hashlib
out=pathlib.Path('/tmp/edhr-personnel-paging-final-qa-20261105/server-sql')
def norm(sql):return re.sub(r'\s+',' ',re.sub(r'\$[0-9]+','?',sql).strip().rstrip(';')).lower()
prefix=re.compile(r'^QA\|([^|]*)\|(\d+)\|([^|]*)\|([^|]*)\|\s*(LOG|DETAIL|ERROR|NOTICE|WARNING|HINT|STATEMENT|FATAL|PANIC):\s*(.*)$')
chunks=[];current=None
for line_no,line in enumerate((out/'postgres.log').read_text().splitlines(),1):
 m=prefix.match(line)
 if m:
  if current:chunks.append(current)
  current={'time':m[1],'pid':m[2],'database':m[3],'user':m[4],'level':m[5],'text':m[6],'line':line_no}
 elif current:current['text']+='\n'+line
if current:chunks.append(current)
def params(text):
 text=text[len('parameters: '):].strip();result={};pos=0
 pattern=re.compile(r"\$(\d+) = ('(?:''|[^'])*'|NULL)(?:, |$)",re.S)
 while pos<len(text):
  m=pattern.match(text,pos)
  if not m:raise ValueError('Unparsed PG parameter tail at '+str(pos)+': '+text[pos:pos+100])
  raw=m[2];result[int(m[1])]=None if raw=='NULL' else raw[1:-1].replace("''", "'");pos=m.end()
 return result
records=[];last={};server_errors=[]
for chunk in chunks:
 if chunk['level'] in ('ERROR','FATAL','PANIC'):server_errors.append(chunk)
 if chunk['level']=='DETAIL' and chunk['text'].startswith('parameters: '):
  if chunk['pid'] in last:last[chunk['pid']]['parameters']=params(chunk['text'])
  continue
 if chunk['level']!='LOG':continue
 m=re.search(r'duration:\s*[\d.]+\s+ms\s+(parse|bind|execute)\s+[^:]+:\s*(.*)',chunk['text'],re.S)
 if m:stage=m[1];sql=m[2].strip()
 else:
  m=re.search(r'(?:duration:\s*[\d.]+\s+ms\s+)?statement:\s*(.*)',chunk['text'],re.S)
  if not m:continue
  stage='statement';sql=m[1].strip()
 record={k:chunk[k] for k in ('time','pid','database','line')};record.update(stage=stage,sql=sql,parameters={});records.append(record);last[chunk['pid']]=record
selects=[s for s in records if s['stage'] in ('execute','statement') and re.match(r'^\s*(?:/\*.*?\*/\s*)?select\b',s['sql'],re.I|re.S)]
events=[json.loads(line) for line in (out/'observations.jsonl').read_text().splitlines()]
assert len(events)==90
observed=collections.Counter(norm(sql) for e in events for sql in e['jdbcSql']+e['hibernateSql']);actual=collections.Counter(norm(s['sql']) for s in selects)
assert sum(observed.values())==296
counts=[{'signature':sig,'sha256':hashlib.sha256(sig.encode()).hexdigest(),'observed':count,'server':actual[sig]} for sig,count in sorted(observed.items())]
assert all(v['server']==v['observed'] for v in counts),[(v['signature'],v['observed'],v['server']) for v in counts if v['server']!=v['observed']]
business=[s for s in selects if norm(s['sql']) in observed]
assert len(business)==296
def is_directory(sql):return 'from user_account ' in norm(sql) and 'tenant_id=?' in norm(sql) and ('fetch first' in norm(sql) or 'limit ?' in norm(sql))
dirs=[s for s in business if is_directory(s['sql'])]
expected_dirs=[]
for event in events:
 for sql in event['hibernateSql']:
  if is_directory(sql):expected_dirs.append((event,sql))
assert len(dirs)==len(expected_dirs)==69
directory_checks=[];candidate_checks=[]
for record,(event,sql) in zip(dirs,expected_dirs):
 assert norm(record['sql'])==norm(sql)
 q=re.sub(r'\s+',' ',record['sql']).lower();bindings=record['parameters'];assert bindings
 limit=re.search(r'fetch first \$(\d+) rows only',q) or re.search(r'limit \$(\d+)',q);assert limit
 offset=re.search(r'offset \$(\d+) rows',q)
 size=50 if event['kind'] in ('personnel-directory-next-page','candidate-array-text-identities') else 100
 page=event['data'].get('page',1);actual_limit=int(bindings[int(limit[1])]);actual_offset=int(bindings[int(offset[1])]) if offset else 0
 assert actual_limit==size+1 and actual_offset==(page-1)*size
 assert 'count(' not in q
 row={'eventKind':event['kind'],'eventData':event['data'],'serverLine':record['line'],'boundParameterCount':len(bindings),'requestedPage':page,'requestedSize':size,'actualLimit':actual_limit,'actualOffset':actual_offset}
 directory_checks.append(row)
 candidate=re.search(r'jsonb_array_elements_text\(cast\(\$(\d+) as jsonb\)\)',q)
 if candidate:
  payload=bindings[int(candidate[1])];values=json.loads(payload);assert isinstance(values,list) and all(isinstance(v,str) for v in values)
  assert len(bindings)==(8 if page==1 else 9)
  if 'originalCandidates' in event['data']:
   count=event['data']['originalCandidates'];assert len(values)==count;assert values==[str(40000+i) for i in range(count)]
  else:
   assert event['kind']=='candidate-array-text-identities';assert values==['00042','+42',' 42','42 ','9223372036854775808','not-an-id',"' OR 1=1 --",'43','43']
  candidate_checks.append({**row,'singleArrayParameterIndex':int(candidate[1]),'candidateValues':len(values),'candidatePayloadSha256':hashlib.sha256(payload.encode()).hexdigest(),'exactContentsVerified':True})
assert len(candidate_checks)==55
generic_names=[s for s in business if norm(s['sql'])=='select cast(id as varchar) as id,display_name from user_account where cast(id as varchar)=any(?)']
form_names=[s for s in business if norm(s['sql'])=='select id,display_name from user_account where id=any(?)']
assert len(generic_names)==5 and len(form_names)==9
for record in generic_names+form_names:
 assert len(record['parameters'])==1 and record['parameters'][1].startswith('{') and record['parameters'][1].endswith('}')
extras=[s for s in selects if norm(s['sql']) not in observed]
def classify(sql):
 s=norm(sql)
 if s=='select version()':return 'owned-version-probe'
 if 'databasechangelog' in s:return 'liquibase-migration-metadata'
 if any(v in s for v in ('pg_catalog','information_schema','pg_type','pg_namespace','pg_class','pg_constraint','pg_attribute','pg_index','pg_collation','current_schema','current_database','current_setting')):return 'framework-or-driver-database-metadata'
 if 'select state_json from production_execution' in s:return 'fixture-state-read'
 if any(v in s for v in ('snapshot_json||state_json||revision','snapshot_json||values_json||status','candidate_snapshot::text','snapshot_data::text')):return 'test-evidence-assertion'
 return 'other-unobserved-select'
extra_groups=collections.defaultdict(list)
for record in extras:extra_groups[classify(record['sql'])].append(record)
summary={'result':'passed','candidate':'b81b67ed7602740cda7b43cadcd3ce7bf8ba928a','observerInvocations':35,'observationEvents':len(events),'logicalBusinessSelects':sum(observed.values()),'serverBusinessSelects':len(business),'matchedQuerySignatures':len(counts),'serverExecutedSelectsTotal':len(selects),'excludedSelects':len(extras),'excludedSelectGroups':{k:len(v) for k,v in extra_groups.items()},'directoryQueries':len(dirs),'directoryLimitCounts':dict(collections.Counter(v['actualLimit'] for v in directory_checks)),'directoryCountQueries':0,'candidateSingleJsonArrayQueries':len(candidate_checks),'candidateDirectoryParameterCounts':sorted(set(v['boundParameterCount'] for v in candidate_checks)),'genericSingleVarcharArrayQueries':len(generic_names),'currentFormSingleBigintArrayQueries':len(form_names),'serverErrors':len(server_errors),'scope':'Exact counts for observer SELECT signatures and actual bound LIMIT/OFFSET/array contents; excludes bootstrap/migration/driver/fixture/assertion SELECT. Native assertions prove contents, order and hasNext; duration log does not measure returned rows. Not all network SQL, full HTTP/JWT/browser/signature/SLA.'}
for filename,data in [('server-executed-selects.json',selects),('query-signature-counts.json',counts),('directory-limit-parameter-checks.json',directory_checks),('candidate-array-parameter-checks.json',candidate_checks),('excluded-selects.json',dict(extra_groups)),('server-errors.json',server_errors),('server-sql-summary.json',summary)]:
 (out/filename).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
