# Personnel paging: independent evidence and scope subitem FINAL

This is a read-only child of the final L2 quality instance. It did not implement or repair any code, test, fixture, configuration, knowledge asset, or locked candidate. It independently executed the archive/fingerprint/region/XML verification script and inspected source and business declarations. Native 177, knowledge 89, database observations and browser 11 cited below are inspected **primary originals**, not executions by this subitem. Fresh execution belongs to the parent quality instance and its database child.

## Baselines and actual ownership

- Source/contract read/candidate: `b81b67ed7602740cda7b43cadcd3ce7bf8ba928a`, clean working tree.
- Target: `origin/edhr-dev@f8638f5400356c4820d59bf26be50a79b453ca12`.
- Knowledge `0.3.25`, schema `1.2.0`, stage P0 in-progress. These do not substitute for Git baselines.
- Reviewed actual 45-path diff and all batch documents, AGENTS, quality-verifier and handoff contracts, architecture/knowledge README/open questions, DEC0081/0092/0093/0095, new rule/evidence/anchor, and source/test consumers. This scope did not inspect GitHub rulesets or run/query CI.
- No repository paths modified; no worktrees, containers, databases or browser processes created by this child. Output is confined to this evidence-scope directory.

## Policy, provenance and knowledge

The user explicitly authorized current ordinary-form assignee name batching and original-candidate parameter growth reduction, then required all personnel satisfying each entry's **existing** qualification to remain reachable. The number 100 is not a total selection ceiling. Paging/lazy batches may be an engineering choice. This does not mean every tenant member is valid for every domain: frozen candidates, record-control applicant avoidance, form/DHR dual permission requirements and the original actions still apply.

DEC0095 and the formal rule match this confirmation. The rule reuses existing `intervention.type` and returns a query projection; no new concepts, facts, runtime fact providers, execution contract or permission grants are fabricated. Its statuses remain specified/internal. `replacementScopes: []` and `supersedes: []` are appropriate because the old 100-person truncation was an implementation limit, not an authoritative former business population policy. Other declarations remain governed by their own original decisions and precise DEC0093 replacements; the old DHR manager-reassignment prohibition is not incorrectly restored.

Seven knowledge/architecture files, 12 new IDs: DEC0095 + three statements + two scenarios, one rule, four evidence IDs and one implementation anchor. Independently recomputed current 350 knowledge file hashes and baseline 345 hashes from Git: five additions, README update, 344 existing unchanged, no deletions. Schema, facts and ontology source files are unchanged; 0.3.25/schema1.2.0/P0 are not promoted. The 13 retained semantic items are 12 consistent **within their declared statements/scopes** and one retained full multi-tenant isolation evidence gap. That gap is not counted as consistency and this is not full-knowledge audit completion.

The ontology archive holds 105 raw originals plus manifest and digest (107 members). Their bytes/hashes and embedded manifest digest were independently checked. Its 36 role-time source snapshots all match those original snapshots; decision-package.yaml and PersonnelTargetSelect.tsx differ from final candidate because concurrent main-side work continued afterward. These are historical role inputs, not final-byte claims. The separate 33 final source fingerprints and nine browser-time source fingerprints match the locked candidate.

## Source semantics and protections

`TenantTransferTargets.search` applies tenant, ACTIVE, lock expiration, current-person exclusion, required permission EXISTS predicates, keyword and caller Specification before scrolling. Spring Data window consumes `size + 1` for continuation, returns at most requested size and exposes `hasNext`. Page starts at one, default batch 50, maximum single batch 100. Stable displayName then numeric ID order avoids equal-name ambiguity. Page/size validation and offset representability are request boundaries, not a total 100-person ceiling. The old List caller path has been migrated; no alternate fixed-first-100 compatibility branch was left behind. Actual SQL lookahead/no-count execution is the separate database verifier's responsibility.

`FormWorkflowOperations.detail` first succeeds at the original visibility query, then gathers only IDs involved in current active APPROVAL nodes and uses one bigint-array query for ID/display name. It preserves the original Long parsing, blank candidate label, missing-account fallback to original text, null display-name behavior and stored historical names/signature references. It does not resolve all historical people or alter generic workflow name lookup/write helpers. The 100 in the measurement is a workload size, never an employee return cap.

`WorkflowResponsibilityService.targets` reuses the already-read originSnapshot, including old `asText()` identity semantics. Its static Hibernate SQL fragment binds exactly one JSON array string; SQL text is not constructed from candidate contents. Text membership keeps `00042`, `+42`, padded, overflow and non-numeric text from silently becoming numeric 42. Duplicates do not duplicate users, and an empty restricted set stays empty rather than unrestricted. Original requester avoidance and domain permission paths remain. No textual-ID index, ID normalization, schema migration or query policy change was included.

Of ten changed Java product files, seven propagation layers only forward page/size and Page response; core behavior is in the helper and two read services above. Four controllers/routes remain protected by their original service/context gates. Nine protected entire files and five write/protection regions were independently extracted and byte-compared with target: all 14 are unchanged. This supports preserved final write qualification, signature/actual signer, reasons, state checks, lock order, transactions, immutable audit, responsibility history and frozen evidence. It is not a proof of every possible concurrent authorization scenario. DHR self-transfer, withdrawal and generic approval bypass remain prohibited.

## API and UI consumers

| HTTP directory | Actual consumer | Synchronized behavior |
| --- | --- | --- |
| `/workflow/tasks/{id}/transfer-targets` | TaskDetail | getTaskTransferTargets -> shared selector |
| `/workflow/operations/tasks/{id}/transfer-targets` | WorkflowResponsibilityDialog transfer | getResponsibilityTargets -> shared selector |
| `/workflow/operations/tasks/{id}/reassignment-targets` | WorkflowResponsibilityDialog reassignment, including form-prefixed IDs/DHR | same adapter and shared selector; original domain qualification |
| `/production/execution/{id}/transfer-targets` | ProductionExecutionPage and FormReviewPage | getExecutionTransferTargets -> shared selector |

The API intentionally changes List into content/page/size/hasNext, requiring synchronized backend/frontend delivery; all repository consumers were migrated. No database migration or historical data rewrite is required. The shared owner handles search/debounce, IME, clearing, continuation, last page, old-request isolation, error/retry, keyboard and count; the server continues to decide qualification and rechecks on submission. Actual TaskDetail and ResponsibilityDialog browser coverage is separate from two actual API-adapter/shared-widget scenarios: ProductionExecutionPage/FormReviewPage full parent-page E2E is not claimed.

SubjectSelector.fetchUsers/fetchRoles and UserPage/RolePage loaders already loop through totalPages; ReferencePersonSelector is a function inside `components/form-renderer/ReferencePickerDialog.tsx`, loops batch100 plus lookahead until the last page, then supplies the full qualified collection to SubjectSelector. Their existing behavior was inspected and is not advertised as a new implementation. Their business scope is not replaced by transfer qualification. Unrelated size100 audit queries are not personnel population caps. Eager full-page collection in those old selectors remains a separate potential future performance topic, not a newly introduced total cap.

TaskDetail's friend-owned password/signature chain is unchanged apart from the authorized target selector. Production modal ancestors/global styles/App theme and existing modal sizing are not redesigned. The new selector's placement and retry controls are within personnel selection, not resumption of the paused styling task.

## Original test evidence and failure history

All 299 archive members were independently enumerated, checked for duplicate names, and matched to the committed manifest bytes/SHA. Stored gzip is 11,327,761 bytes, SHA-256 `96fd62589fc734fd36f1da7ceb5a8020f6c2c5bc49b2c8e418cab48407f8e5d0`. XML totals were recomputed separately for all native phases:

| Primary phase | Tests | Failures | Errors | Skips | Meaning |
| --- | ---: | ---: | ---: | ---: | --- |
| native-full | 173 | 1 | 14 | 0 | old List-path assertion and interim unsupported arrayContains binding |
| native-full2 | 173 | 0 | 0 | 0 | first green intermediate implementation |
| native-full3 | 176 | 1 | 2 | 0 | new fixture wrong tenant/role PK and DHR pending-state protection |
| native-full4 | 177 | 2 | 0 | 0 | new fixture role memberships leaked into two existing qualifier tests |
| native-full5 | 177 | 0 | 0 | 0 | final isolated role8100000 fixture and own-role AfterEach cleanup |

These are separately retained implementation stages, not source-baseline negative controls. The old `formReassignmentSearchQualifiesBeforeLimitingUsers` and `dhrReassignmentSearchQualifiesBeforeLimitingUsers` qualification assertions remain; green is not obtained by removing their restrictions. The final test suite is 35 observer +55 record-control +24 transfer +63 adjacent. Archived final observations contain 90 events and 296 logical SELECTs. Workloads include 251 same-name people through six pages plus an empty seventh and 5000 original candidates across 50 pages with individual-ID comparison. Relevant query budgets are distinct names/missing names 101->2, same existing2/blank1, original5000 5007 parameters->8 initial/9 continuation for the directory (service11/12). These workloads do not justify unrelated aggregate or SLA claims.

Final browser originals contain 11 passed scenarios; nine source bytes match the candidate and were unchanged during that run. Earlier popup obstruction and uncommitted-search clear issues were product defects that were repaired; clicking an already-open empty input in the second phase was orchestration error. Intermediate runs are not final passed proof. Browser uses isolated HTTP fixtures, not actual authorization or electronic signature execution. Record-related later-page HTTP tests have JWT/filter/MockMvc coverage; the ordinary task transfer test retains standalone MVC context scope, not a new full JWT claim.

Knowledge89, frontend build, format, focused static checks and whole-premium baseline/current86 are retained as their own original evidence. Repository lint configuration absence is not disguised as full lint passing. This subitem does not independently rerun any of those suites.

## Scope boundaries and residuals

No reproducible in-scope code or knowledge defect was found. This evidence/semantic subitem can pass while the parent still must finish its fresh native/knowledge/browser/database checks.

The textual-ID full-scan/index risk remains user-deferred; small-page SQL bounds do not guarantee a particular production latency for all directory sizes. Offset paging is a current live directory, not an immutable multi-request population snapshot, and final action validation remains necessary. The duplicate available-after-SQL check remains in the old A23 queue; this batch does not remove write rechecks under an over-defensiveness rationale. FormWorkflowOperations can later separate pure node/current-task, edge and history projection methods while preserving its visibility gate and write ownership; the batch already extracts only a private read helper and one shared selector.

Old 931 knowledge/86 UI inventory, wholeFile0/historyunique unknown, W2-W7, high-risk/A12, full permission/signature/notification/ACL-concurrency matrices, other performance items and user-paused scope remain open according to the existing ledger. Finishing this finite slice does not close the overall audit, complete multi-tenant isolation, certify production SLA or authorize merge/deployment/history recovery.

## Tooling honesty

Verification executed successfully twice: initial26 and strengthened26. The second adds explicit duplicate-member detection, embedded ontology digest and Git reads for all345 baseline knowledge hashes; no failing product check was hidden. Exploratory paths initially used an incorrect Java package and guessed standalone ReferencePersonSelector paths. Empty/missing-path searches were corrected using `rg --files`/`rg -n`, then the actual `com/zencas/edhr` package and ReferencePickerDialog function were read. These are inspection-navigation errors, not product failures. Commands and source diffs are captured by the finalization script; no repository/test files were edited to accommodate tooling.
