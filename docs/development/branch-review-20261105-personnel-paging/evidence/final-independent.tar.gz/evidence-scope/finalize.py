import pathlib, subprocess, json, hashlib, yaml, datetime

repo=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-personnel-paging-final-qa-20261105/evidence-scope')
base='f8638f5400356c4820d59bf26be50a79b453ca12'
head='b81b67ed7602740cda7b43cadcd3ce7bf8ba928a'
def sha(b): return hashlib.sha256(b).hexdigest()
def command(name,args):
    process=subprocess.run(args,cwd=repo,text=True,capture_output=True)
    (out/(name+'.stdout')).write_text(process.stdout)
    (out/(name+'.stderr')).write_text(process.stderr)
    return {'command':args,'exitCode':process.returncode,'stdout':name+'.stdout','stderr':name+'.stderr'}
commands=[]
commands.append(command('candidate-source-diff',['git','diff','--unified=4',base,head,'--','gmp-platform/backend/src/main/java','gmp-platform/frontend/src']))
commands.append(command('candidate-test-diff',['git','diff','--unified=4',base,head,'--','gmp-platform/backend/src/test/java']))
commands.append(command('candidate-final-status',['git','status','--porcelain=v1']))
commands.append(command('candidate-final-refs',['git','rev-parse','HEAD','origin/edhr-dev']))
assert (out/'candidate-final-status.stdout').read_text()==''
assert (out/'candidate-final-refs.stdout').read_text().splitlines()==[head,base]
assert all(c['exitCode']==0 for c in commands)
paths=json.loads((out/'candidate-paths.json').read_text())
source_paths=[p for p in paths if p.startswith('gmp-platform/')]
source_paths += ['gmp-platform/frontend/src/components/identity/SubjectSelector.tsx','gmp-platform/frontend/src/components/form-renderer/ReferencePickerDialog.tsx','gmp-platform/frontend/src/pages/system/UserPage.tsx','gmp-platform/frontend/src/pages/system/RolePage.tsx']
fingerprints=[]
for path in source_paths:
    content=(repo/path).read_bytes()
    target=out/'manual-source-snapshots'/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(content)
    fingerprints.append({'path':path,'bytes':len(content),'sha256':sha(content)})
(out/'manual-source-fingerprints.json').write_text(json.dumps(fingerprints,ensure_ascii=False,indent=2)+'\n')
(out/'inspection-commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
(out/'tool-navigation-errors.json').write_text(json.dumps({
    'productFailures':[],
    'inspectionNavigation':[
        {'attempt':'git diff -- gmp-platform/backend/src/main/java/com/edhr/gmp/modules/...','result':'empty diff due incorrect package path','correction':'read actual git path inventory; reran diff with com/zencas/edhr path; captured candidate-source-diff.stdout'},
        {'attempt':'rg gmp-platform/frontend/src/components/form gmp-platform/frontend/src/services','result':'two nonexistent directories; other requested paths yielded matches','correction':'used current API/component path inventory and read source APIs/consumers'},
        {'attempt':'rg .../components/form-runtime/ReferencePersonSelector.tsx; rg --files ... | rg ReferencePersonSelector','result':'guessed standalone file missing; filename search no match','correction':'rg -n ReferencePersonSelector found function inside components/form-renderer/ReferencePickerDialog.tsx; full loader reviewed and snapshotted'}
    ],
    'verificationRuns':[{'log':'verify.log','result':'passed','checks':26},{'log':'verify-strengthened.log','result':'passed','checks':26,'additionalAssurance':['duplicate tar member enumeration','embedded ontology manifest digest','345 Git baseline hashes']}],
    'productTestChanges':[]
},ensure_ascii=False,indent=2)+'\n')
checks=json.loads((out/'verification-checks.json').read_text())
manual_checks=[
    ('check.manual-api-and-domain-scope','api','Read ten changed Java files and four controller/service routes; full original qualifications before bounded paging, all four frontend consumers migrated.'),
    ('check.manual-existing-personnel-loops','regression','Read SubjectSelector, UserPage/RolePage and ReferencePersonSelector loops; existing full-page behavior is retained and not falsely claimed as new work.'),
    ('check.manual-pause-and-drift-boundaries','requirements','TaskDetail password chain and production-dialog redesign remain paused; only authorized selector work, read batching and single bound candidate array are implemented.'),
    ('check.final-candidate-sources-still-clean','documentation','Final source snapshots and source/target refs remain fixed and clean; no child mutations or external resources.')
]
for ident,category,description in manual_checks:
    checks.append({'id':ident,'required':True,'category':category,'description':description,'method':'inspection','command':'Read source snapshots and candidate diffs; python3 finalize.py','outcome':'passed','evidence':['semantic-review.md','manual-source-fingerprints.json','candidate-source-diff.stdout','candidate-test-diff.stdout','candidate-final-refs.stdout','candidate-final-status.stdout']})
for item in checks:
    item['evidence'] += ['verification-checks.json', 'semantic-review.md', 'base='+base, 'head/source-reviewed-candidate='+head]
result={'qualityResult':{
    'result':'passed','baseCommit':base,'headCommit':head,
    'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},
    'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},
    'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],
    'residualRisks':[
        {'id':'risk.subitem-evidence-only','description':'This child inspected primary native177/knowledge89/browser11/XML/SQL observations but did not rerun them.','impact':'This child result alone cannot replace final parent runtime verification.','mitigation':'Parent final quality and separate independent database child must provide their own formal results.'},
        {'id':'risk.live-ui-auth-coverage','description':'Browser uses isolated HTTP fixtures; two full actual entries plus two actual API adapters/shared selector, not complete production/form-review parent E2E. Ordinary task later-page HTTP uses standalone MVC scope.','impact':'No new assertion of full real-account/signature/parent-page matrices or JWT coverage for the ordinary task route.','mitigation':'Keep explicit boundaries and existing full matrix queues; unchanged write guards and adjacent regressions remain mandatory.'},
        {'id':'risk.deferred-text-id-plan','description':'Textual ID casts and large-directory scan/index risk remain user-deferred; offset paging is a live directory and not a cross-request population freeze.','impact':'No production SLA or all-scale query-plan guarantee; concurrent account changes may alter live paging.','mitigation':'Observe production workload before index/plan changes; revalidate final action eligibility as original code does.'},
        {'id':'risk.retained-audit-queues','description':'Old931 knowledge/86 UI, wholeFile0/historyunique unknown, W2-W7/high/A12/full multi-tenant and permission/signature/notification/ACL-concurrency matrices, A23 duplication and other performance items stay open.','impact':'Finite personnel slice does not finish whole-branch audit or production readiness.','mitigation':'Continue original ledger and fresh fetch/incremental audit per delivery; preserve user-paused password-chain and production-dialog design scope.'},
        {'id':'risk-synchronized-api-shape','description':'Personnel target endpoints return Page rather than List.','impact':'A separately deployed old frontend is not covered by silent first100 compatibility.','mitigation':'Deliver repository backend and frontend together; no database/historical migration is needed.'}
    ],'blockingConditions':[]
},'verificationScope':{
    'role':'read-only-independent-quality-evidence-and-scope-child',
    'independence':'No repair or product/test/fixture/configuration/knowledge modification; no implementation participation.',
    'ownExecuted':['python3 verify.py:26 passed','python3 verify.py strengthened:26 passed','read-only Git/fingerprint/archive/XML/semantic inspections','python3 finalize.py and manifest freeze'],
    'ownNativeTestsExecuted':False,'ownKnowledgeTestsExecuted':False,'ownBrowserExecuted':False,
    'parentRuntimeResultsRequired':True,
    'resourceCleanup':{'createdContainers':[],'createdWorktrees':[],'createdDatabases':[],'createdBrowserProcesses':[],'pendingResources':[]},
    'targetFetchOwnership':'Parent final quality instance performs start/end remote fetch. This read-only child independently reads the target ref and end refs; no network/CI/merge/deploy action.'
}}
assert all(c['outcome']=='passed' for c in checks if c['required'])
category={'requirements','ontology','unit','integration','api','database','audit','security','e2e','visual','regression','documentation'}
method={'command','inspection','browser','query','automated-test'}
assert all(c['category'] in category and c['method'] in method and isinstance(c['required'],bool) for c in checks)
(out/'result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
summary=json.loads((out/'summary.json').read_text());summary['finalChecksPassed']=len(checks);summary['finalOutcome']='passed';summary['artifactScope']='evidence-and-semantic-child-only'
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
artifacts=[]
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name not in ('manifest.json','manifest.sha256','finalize.log'):
        content=path.read_bytes();artifacts.append({'path':str(path.relative_to(out)),'bytes':len(content),'sha256':sha(content)})
manifest={'candidateCommit':head,'targetCommit':base,'role':'read-only-evidence-scope-quality-child','rawArtifactCount':len(artifacts),'artifacts':artifacts,'note':'Frozen child artifact set. Own native/knowledge/browser execution not claimed; parent required. finalize.log is a non-artifact shell output redirect and excluded.'}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
digest=sha((out/'manifest.json').read_bytes())
(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
for artifact in artifacts:
    content=(out/artifact['path']).read_bytes();assert len(content)==artifact['bytes'] and sha(content)==artifact['sha256']
print(json.dumps({'result':'passed','checks':len(checks),'rawArtifactCount':len(artifacts),'manifestSha256':digest,'repositoryModified':False,'ownNativeKnowledgeBrowserExecuted':False}))
