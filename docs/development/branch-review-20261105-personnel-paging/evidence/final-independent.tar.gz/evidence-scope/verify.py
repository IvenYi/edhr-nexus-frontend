import pathlib,subprocess,json,hashlib,tarfile,xml.etree.ElementTree as ET,collections,re,yaml,datetime
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=pathlib.Path('/tmp/edhr-personnel-paging-final-qa-20261105/evidence-scope');o.mkdir(parents=True,exist_ok=True)
p=r/'docs/development/branch-review-20261105-personnel-paging';base='f8638f5400356c4820d59bf26be50a79b453ca12';candidate='b81b67ed7602740cda7b43cadcd3ce7bf8ba928a';checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def dump(n,x):(o/n).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def check(i,condition,description,category='documentation',evidence=None):
 checks.append({'id':i,'required':True,'category':category,'description':description,'method':'inspection','command':'python verify.py','outcome':'passed' if condition else 'failed','evidence':evidence or []})
 if not condition:raise AssertionError(i)
def read(path):
 b=(r/path).read_bytes();dst=o/'read-snapshots'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b);return b.decode()
inputs=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/rules/personnel-target-selection.yaml','docs/knowledge/implementation-anchors/personnel-target-selection.yaml','docs/knowledge/evidence/qualified-personnel-selection-20261105.md','docs/knowledge/evidence/qualified-personnel-selection-20261105.yaml','docs/frontend/personnel-target-selection.md']
inputs += [str(f.relative_to(r)) for f in sorted(p.glob('*')) if f.is_file() and f.suffix in ('.md','.json','.yaml')]
texts={f:read(f) for f in inputs};dump('read-input-fingerprints.json',[{'path':f,'bytes':len(t.encode()),'sha256':sha(t.encode())} for f,t in texts.items()])
check('check.fixed-clean-candidate',git('rev-parse','HEAD')==candidate and git('rev-parse','origin/edhr-dev')==base and git('status','--porcelain')=='','Candidate and target fixed, main working tree clean',evidence=[candidate,base])
changed=git('diff','--name-only',base,candidate).splitlines();dump('candidate-paths.json',changed)
check('check.45-paths-bounded-scope',len(changed)==45 and not any('/db/' in v or v.endswith('pom.xml') or v.endswith('package-lock.json') or v=='AGENTS.md' or v.startswith('docs/agents/') for v in changed),'45 paths match slice; no migration/index/dependency/project-governance mutation')
manifest=json.loads((p/'evidence-manifest.json').read_text());a=p/manifest['archive']['path'];ab=a.read_bytes()
check('check.archive-storage',len(ab)==manifest['archive']['bytes']==11327761 and sha(ab)==manifest['archive']['sha256']=='96fd62589fc734fd36f1da7ceb5a8020f6c2c5bc49b2c8e418cab48407f8e5d0','Stored gzip size and SHA match')
with tarfile.open(a) as t:
 memberList=t.getmembers();members={m.name:m for m in memberList};raw=manifest['rawArtifacts']
 check('check.299-originals',len(raw)==len(memberList)==len(members)==299 and len(set(f['member'] for f in raw))==299,'299 unique raw files with no additional members')
 for f in raw:
  assert not f['member'].startswith('/') and '..' not in pathlib.PurePosixPath(f['member']).parts
  b=t.extractfile(f['member']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['member']
 check('check.all-raw-member-digests',True,'All 299 original member bytes/SHA verified')
 def j(n):return json.loads(t.extractfile(n).read())
 onto=j('ontology/manifest.json');ontoMembers=[n for n in members if n.startswith('ontology/')]
 assert len(onto['artifacts'])==onto['rawArtifactCount']==105
 for f in onto['artifacts']:
  b=t.extractfile('ontology/'+f['path']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256']
 manifestBytes=t.extractfile('ontology/manifest.json').read()
 ontoDigest=t.extractfile('ontology/manifest.sha256').read().decode().split()[0]
 assert sha(manifestBytes)==ontoDigest=='634f4bc6cae0b483c137434f3244d74506dc731004a67ac3d0dfef0451c4a761'
 check('check.ontology-105-originals',len(ontoMembers)==107,'105 ontology originals plus manifest/digest, 107 archive members')
 ontoSummary=j('ontology/summary.json');ontoResult=yaml.safe_load(t.extractfile('ontology/ontology-result.yaml').read())['ontologyResult']
 check('check.ontology-result-honest',ontoResult['result']=='updated' and ontoSummary['parentNativeOrBrowserNotClaimed'] and ontoSummary['formalKnowledgeTests']=={'tests':89,'failures':0,'errors':0,'skipped':0},'Ontology updated; formal89 scoped, no native/browser claim','ontology')
 xml=ET.fromstring(t.extractfile('ontology/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml').read());assert {k:int(xml.attrib.get(k,0)) for k in ('tests','failures','errors','skipped')}==ontoSummary['formalKnowledgeTests']
 check('check.ontology-89-original-xml',True,'Ontology final89 original XML agrees, not re-executed by this subitem','ontology')
 roleInputs=j('ontology/input-fingerprints.json');differences=[]
 for f in roleInputs:
  b=t.extractfile('ontology/read-snapshots/'+f['path']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256']
  if sha((r/f['path']).read_bytes())!=f['sha256']:differences.append(f['path'])
 dump('ontology-snapshot-current-differences.json',{'count':len(differences),'paths':differences,'meaning':'Role-time concurrent implementation/decision snapshots are historical, not candidate byte proof; final33 input fingerprints verified separately.'})
 check('check.role-36-snapshots',len(roleInputs)==36,'36 role input fingerprints match archived role-time snapshots; later main deltas explicitly separated','ontology')
 currentKB=j('ontology/knowledge-current-fingerprints.json');baselineKB=j('ontology/knowledge-baseline-fingerprints.json')
 assert len(currentKB)==350 and len(baselineKB)==345
 for path,digest in currentKB.items():assert sha((r/path).read_bytes())==digest,path
 for path,digest in baselineKB.items():assert sha(subprocess.check_output(['git','show',base+':'+path],cwd=r))==digest,path
 delta=j('ontology/knowledge-delta.json');check('check.350-knowledge-fingerprints',len(delta['added'])==5 and delta['deleted']==[] and delta['changedExisting']==['docs/knowledge/README.md'] and delta['unchangedExisting']==344,'350 current knowledge files match; 345 baseline plus5, only README current-note update','ontology')
 protected=j('ontology/protected-source-checks.json')
 for f in protected:
  cur=(r/f['path']).read_text();old=subprocess.check_output(['git','show',base+':'+f['path']],cwd=r,text=True)
  if f['scope']=='complete file':cb=cur.encode();ob=old.encode()
  else:
   start,end=f['scope'].split(' to ',1)
   def part(s):
    s=s[s.index(start):]
    if end!='None':s=s[:s.rfind('\n',0,s.index(end))]
    return s.encode()
   cb=part(cur);ob=part(old)
  assert cb==ob and len(cb)==f['bytes'] and sha(cb)==f['sha256'],f
 check('check.14-protected-regions',len(protected)==14 and sum(f['scope']=='complete file' for f in protected)==9,'Independently re-extracted 9 full files and5 write/protection regions; same as base','security')
 retained=j('ontology/retained-semantic-audit.json');assert len(retained['records'])==13
 for f in retained['records']:assert f['id'] in (r/f['sourcePath']).read_text()
 check('check.retained-ids-gaps',collections.Counter(v['conclusion'] for v in retained['records'])=={'consistent':12,'evidence-gap':1} and retained['notWholeAuditCoverage'],'13 retained IDs/locators scoped; multi-tenant evidence gap not converted to consistency','ontology')
 totals={}
 for phase,expected in [('full',(173,1,14,0)),('full2',(173,0,0,0)),('full3',(176,1,2,0)),('full4',(177,2,0,0)),('full5',(177,0,0,0))]:
  root='primary/native-'+phase+'/';x=j(root+'test-summary.json');actual={k:0 for k in ('tests','failures','errors','skipped')}
  files=[n for n in members if n.startswith(root+'TEST-') and n.endswith('.xml')]
  for n in files:
   doc=ET.fromstring(t.extractfile(n).read())
   for k in actual:actual[k]+=int(doc.attrib.get(k,0))
  assert actual==x['totals'] and tuple(actual.values())==expected,(phase,actual)
  totals[phase]=actual
 dump('native-original-xml-totals.json',totals)
 check('check.native-history-and-final177',True,'Each phase original XML agrees including failures; final177 alone, no cumulative or old-source-red claim','integration')
 events=[json.loads(v) for v in t.extractfile('primary/native-full5/observations.jsonl').read().decode().splitlines()]
 assert len(events)==90 and sum(v['totalStatements'] for v in events)==296
 check('check.main-90-observations-296-selects',True,'90 logical observation events/296 SELECT agree; server and independent execution delegated to other quality scopes','database')
 result=j('primary/browser-final/result.json');run=j('primary/browser-final/run.json')
 assert result['result']=='passed' and len(result['cases'])==11 and all(c['result']=='passed' for c in result['cases']) and run['exitCode']==0 and run['sourcesUnchangedDuringRun']
 for f in run['sourceFingerprints']:
  b=t.extractfile('primary/browser-final/source/'+f['path']).read();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and sha((r/f['path']).read_bytes())==f['sha256']
 check('check.browser-11-and-9-source-digests',len(run['sourceFingerprints'])==9,'11 browser originals passed; nine source fingerprints match exact candidate, isolated HTTP scope retained','e2e')
 checksHistory=json.loads((p/'test-history.json').read_text());check('check.interim-errors-retained',len(checksHistory['nativePhases'])==5 and len(checksHistory['browserPhases'])==5 and 'not old-source' in manifest['note'],'Interim product, fixture, and orchestration errors separated; no original negative-control fiction')
source=json.loads((p/'source-review.json').read_text())
for f in source['sourceFingerprints']:
 b=(r/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
check('check.final-33-source-fingerprints',len(source['sourceFingerprints'])==33,'33 final candidate code/test/caller/contract fingerprints match')
def ids(v):
 result=[]
 if isinstance(v,dict):
  if isinstance(v.get('id'),str):result.append(v['id'])
  for item in v.values():result+=ids(item)
 elif isinstance(v,list):
  for item in v:result+=ids(item)
 return result
newIds=[]
for path in ontoSummary['changedPaths']:
 if path.endswith('.yaml') and path not in baselineKB:newIds+=ids(yaml.safe_load((r/path).read_text()))
check('check.seven-knowledge-files-twelve-ids',len(ontoSummary['changedPaths'])==7 and len(newIds)==len(set(newIds))==12,'Seven knowledge/architecture paths and12 unique new IDs; no new fact/concept/runtime-contract assets','ontology',newIds)
check('check.no-stage-version-promotion',git('diff',base,candidate,'--','docs/knowledge/schema.yaml','docs/knowledge/facts','docs/knowledge/ontology.yaml')=='' and all('knowledgeModelVersion: 0.3.25' in (r/path).read_text() for path in ontoSummary['changedPaths'] if path.endswith('.yaml')),'Existing fact definitions/schema/ontology unchanged; new assets stay0.3.25 specified/internal','ontology')
package=yaml.safe_load((p/'decision-package.yaml').read_text())['decisionPackage'];rule=yaml.safe_load((r/'docs/knowledge/rules/personnel-target-selection.yaml').read_text())['rules'][0];decision=yaml.safe_load((r/'docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml').read_text())['decisions'][0]
check('check.confirmed-and-rule-aligned',package['confirmed']['rules'][0]['condition']==rule['condition'] and package['confirmed']['rules'][0]['result']==rule['result'] and package['unresolved']==[] and package['replacementScopes']==[] and decision['supersedes']==[],'User-complete-selection condition/result matches formal rule; no false superseded100-person policy','requirements')
helper=(r/'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java').read_text();responsibility=(r/'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java').read_text();form=(r/'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java').read_text();widget=(r/'gmp-platform/frontend/src/components/identity/PersonnelTargetSelect.tsx').read_text()
check('check.bounded-not-total-cap',all(v in helper for v in ['.limit(size).scroll(position)','window.hasNext()','ScrollPosition.offset((long) (page - 1) * size - 1)','specification.and(scope)']) and '.limit(100)' not in helper and 'PageRequest' not in helper,'Full specification before window; per-call limit and lookahead/hasNext, no fixed total100','api')
check('check.precise-array-and-private-names',all(v in responsibility for v in ['originSnapshot','user.asText()','jsonb_array_elements_text(cast(? as jsonb))','criteria.value(mapper.valueToTree(candidates).toString())']) and all(v in form for v in ['currentAssigneeNames(c)','WHERE id=ANY(?)','SqlArrayValue("bigint"','Long.valueOf(assignee), assignee']),'One bound JSON membership preserves raw candidate strings; separate bigint current names retains numeric behavior','security')
callers=['gmp-platform/frontend/src/components/workflow/WorkflowResponsibilityDialog.tsx','gmp-platform/frontend/src/pages/workflow-center/TaskDetail.tsx','gmp-platform/frontend/src/pages/production/ProductionExecutionPage.tsx','gmp-platform/frontend/src/pages/form-management/FormReviewPage.tsx']
check('check.four-caller-migration',all('PersonnelTargetSelect' in (r/f).read_text() for f in callers) and 'getNextPageParam' in widget and 'last.hasNext' in widget and 'signal' in widget,'All four consumers share continuation widget; keyed search and abort signals remain','api')
text=(p/'README.md').read_text()+(p/'review-notes.md').read_text()
check('check.auth-browser-coverage-boundaries','standalone MVC' in text and '隔离HTTP' in text and '不是完整' in text and '第三' in text and '86' in text and '931' in text,'Standalone versus JWT, adapter versus full-parent browser, deferred index and original queues explicitly bounded')
check('check.impact-and-extension',package['impactAnalysis']['level']=='L2' and package['extensionStrategy']['selectedPaths']==['product-core'] and len(package['impactAnalysis']['permissionImpacts'])>0 and len(package['impactAnalysis']['compatibilityAndMigration'])>0,'L2 cross-layer API compatibility, permissions, snapshots and extension ownership accounted','requirements')
check('check.old-tests-preserved-source-inspection',all(v in (r/'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java').read_text() for v in ['formReassignmentSearchQualifiesBeforeLimitingUsers','dhrReassignmentSearchQualifiesBeforeLimitingUsers','DELETE FROM user_role WHERE role_id=8100000','recordControlTargetApiKeepsItsScopeOnLaterPages']),'Old qualifier tests retained and dedicated new test-role isolation explicit; source diff inspected','security')
dump('verification-checks.json',checks);dump('summary.json',{'result':'passed','checksPassed':len(checks),'archiveMembers':299,'ontologyOriginals':105,'ontologyMembersWithManifest':107,'roleInputSnapshots':36,'finalSourceFingerprints':33,'knowledgeFiles':350,'newKnowledgeIds':12,'retainedSemanticIds':13,'protectedChecks':14,'mainFinalNative':177,'mainBrowser':11,'mainObservationEvents':90,'mainLogicalSelects':296,'ownNativeKnowledgeBrowserExecuted':False,'changedRepositoryFiles':[],'resources':{'containers':[],'worktrees':[],'cleanupNeeded':False}})
print(json.dumps({'result':'passed','checks':len(checks),'ontologySnapshotVsCandidateDifferences':len(differences)},ensure_ascii=False))
