import pathlib,subprocess,json,os,datetime,hashlib
r=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-personnel-paging-20261105/browser-final');out.mkdir(exist_ok=False)
paths=['gmp-platform/frontend/src/components/identity/PersonnelTargetSelect.tsx','gmp-platform/frontend/src/types/personnel.ts','gmp-platform/frontend/src/components/workflow/WorkflowResponsibilityDialog.tsx','gmp-platform/frontend/src/pages/workflow-center/TaskDetail.tsx','gmp-platform/frontend/src/pages/production/ProductionExecutionPage.tsx','gmp-platform/frontend/src/pages/form-management/FormReviewPage.tsx','gmp-platform/frontend/src/api/workflow-operations.ts','gmp-platform/frontend/src/api/production-execution.ts','gmp-platform/frontend/scripts/test-personnel-targets-browser.mjs']
sources=[]
for path in paths:
 b=(r/path).read_bytes();sources.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
env=os.environ.copy();env.update(EDHR_PLAYWRIGHT_MODULE='/workspace/.edhr-browser-tools/node_modules/playwright/index.mjs',CHROME_PATH='/usr/bin/chromium',EDHR_PERSONNEL_OUTPUT=str(out));command=['npm','run','test:personnel-targets-browser'];start=datetime.datetime.now(datetime.timezone.utc)
with (out/'browser.log').open('w') as log:result=subprocess.run(command,cwd=r/'gmp-platform/frontend',env=env,stdout=log,stderr=subprocess.STDOUT)
for f in sources:assert hashlib.sha256((r/f['path']).read_bytes()).hexdigest()==f['sha256']
meta={'command':command,'cwd':str(r/'gmp-platform/frontend'),'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':sources,'sourcesUnchangedDuringRun':True,'environmentOverrides':{k:env[k] for k in ('EDHR_PLAYWRIGHT_MODULE','CHROME_PATH','EDHR_PERSONNEL_OUTPUT')},'scope':'Actual Chromium/MUI with isolated HTTP fixtures; source/API wiring and interaction only, not live authorization/signature'}
(out/'run.json').write_text(json.dumps(meta,indent=2)+'\n');print((out/'browser.log').read_text()[-2000:]);raise SystemExit(result.returncode)
