import pathlib,tarfile,json,hashlib,subprocess
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=r/'docs/development/branch-review-20261105-personnel-paging';tmp=pathlib.Path('/tmp/edhr-personnel-paging-20261105');onto=pathlib.Path('/tmp/edhr-personnel-paging-ontology-20261105')
def sha(b):return hashlib.sha256(b).hexdigest()
items=[]
for f in sorted(tmp.rglob('*')):
 if f.is_file():items.append((f,'primary/'+str(f.relative_to(tmp))))
for f in sorted(onto.rglob('*')):
 if f.is_file():items.append((f,'ontology/'+str(f.relative_to(onto))))
raw=[{'member':name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f,name in items]
(o/'evidence').mkdir(exist_ok=True);a=o/'evidence/primary-and-ontology.tar.gz';assert not a.exists()
with tarfile.open(a,'w:gz') as t:
 for f,name in items:t.add(f,arcname=name,recursive=False)
x={'targetCommit':'f8638f5400356c4820d59bf26be50a79b453ca12','rawArtifacts':raw,'archive':{'path':'evidence/primary-and-ontology.tar.gz','bytes':a.stat().st_size,'sha256':sha(a.read_bytes())},'note':'All implementation stages including initial errors retained separately, not old-source negative controls or cumulative coverage. Final main177 and browser11 are distinct native/isolated HTTP scopes; ontology105 originals plus manifest/digest107. Source snapshots and metadata identify dirty baseline bytes; final independent QA must lock actual committed candidate.'}
(o/'evidence-manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rawArtifacts':len(raw),'archive':x['archive']},ensure_ascii=False))
