from pathlib import Path
import subprocess,json,hashlib,shutil,datetime,re,xml.etree.ElementTree as ET,yaml
r=Path('/workspace/edhr-nexus-frontend');o=Path('/tmp/edhr-personnel-paging-ontology-20261105');base='f8638f5400356c4820d59bf26be50a79b453ca12'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
def write(name,x):
 p=o/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
changed=[
 'docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml',
 'docs/knowledge/rules/personnel-target-selection.yaml',
 'docs/knowledge/evidence/qualified-personnel-selection-20261105.yaml',
 'docs/knowledge/evidence/qualified-personnel-selection-20261105.md',
 'docs/knowledge/implementation-anchors/personnel-target-selection.yaml',
 'docs/knowledge/README.md','docs/architecture/business-knowledge-model.md']
inputs=['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','docs/knowledge/rules/identity.yaml','docs/knowledge/rules/workflow-central-entry.yaml','docs/knowledge/facts/core-business.yaml','docs/development/branch-review-20261105-personnel-paging/decision-package.yaml','docs/development/branch-review-20261105-personnel-paging/user-confirmed.md','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionEngine.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ProductionExecutionService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/WorkflowTaskController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/WorkflowOperationsController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/ProductionExecutionController.java','gmp-platform/frontend/src/components/workflow/WorkflowResponsibilityDialog.tsx','gmp-platform/frontend/src/pages/workflow-center/TaskDetail.tsx','gmp-platform/frontend/src/pages/production/ProductionExecutionPage.tsx','gmp-platform/frontend/src/pages/form-management/FormReviewPage.tsx']
inputs.append('gmp-platform/frontend/src/components/identity/PersonnelTargetSelect.tsx')
fps=[]
for p in dict.fromkeys(inputs+changed):
 b=(r/p).read_bytes();d=o/'read-snapshots'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 prior=subprocess.run(['git','show',base+':'+p],cwd=r,capture_output=True)
 fps.append({'path':p,'bytes':len(b),'sha256':sha(b),'baselineExists':prior.returncode==0,'baselineSha256':sha(prior.stdout) if prior.returncode==0 else None,'snapshotKind':'end-of-role working tree; read source may include concurrent main implementation'})
write('input-fingerprints.json',fps)
kbpaths=git('ls-tree','-r','--name-only',base,'--','docs/knowledge').splitlines();current=[p for p in sorted((r/'docs/knowledge').rglob('*')) if p.is_file()]
oldkb={p:sha(subprocess.check_output(['git','show',base+':'+p],cwd=r)) for p in kbpaths};newkb={str(p.relative_to(r)):sha(p.read_bytes()) for p in current}
kbdelta={'baselineFiles':len(oldkb),'currentFiles':len(newkb),'added':sorted(newkb.keys()-oldkb.keys()),'deleted':sorted(oldkb.keys()-newkb.keys()),'changedExisting':[p for p in oldkb.keys()&newkb.keys() if oldkb[p]!=newkb[p]],'unchangedExisting':sum(oldkb[p]==newkb[p] for p in oldkb.keys()&newkb.keys())}
assert len(oldkb)==345 and len(newkb)==350 and len(kbdelta['added'])==5 and not kbdelta['deleted'] and kbdelta['changedExisting']==['docs/knowledge/README.md'];write('knowledge-delta.json',kbdelta);write('knowledge-baseline-fingerprints.json',oldkb);write('knowledge-current-fingerprints.json',newkb)
schema=yaml.safe_load((r/'docs/knowledge/schema.yaml').read_text());assert schema['knowledgeModelVersion']=='0.3.25' and schema['schemaVersion']=='1.2.0'
allrecords={}
def visit(v,path):
 if isinstance(v,dict):
  if 'id' in v and isinstance(v['id'],str):
   assert v['id'] not in allrecords,v['id'];allrecords[v['id']]={'record':v,'path':path}
  for w in v.values():visit(w,path)
 elif isinstance(v,list):
  for w in v:visit(w,path)
for p in current:
 if p.suffix=='.yaml' and p.name!='schema.yaml':visit(yaml.safe_load(p.read_text()),str(p.relative_to(r)))
addedids=[]
for path in changed:
 if path.endswith('.yaml'):
  addedids.extend(k for k,v in allrecords.items() if v['path']==path)
assert len(addedids)==12
newrule=allrecords['rule.personnel-targets-complete-qualified-navigation']['record'];fact=allrecords['fact.catalog.intervention-type']['record'];assert fact['aliases']==['intervention.type'] and 'equals' in fact['allowedOperators'];assert newrule['condition']=={'any':[{'fact':'intervention.type','operator':'equals','value':'ORDINARY_TRANSFER'},{'fact':'intervention.type','operator':'equals','value':'MANAGERIAL_REASSIGNMENT'}]};assert newrule['result']['type']=='return-query-projection' and newrule['result']['fixedTotalSelectionCap'] is False;assert newrule['status']=='specified' and newrule['visibility']=='internal'
checks={'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','uniqueIndexedIds':len(allrecords),'newIds':addedids,'newRecordCount':len(addedids),'conditionUsesExistingFact':True,'newFactsConceptsExecutionContracts':0,'existingDecisionsUntouched':all((r/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p],cwd=r) for p in inputs if '/decisions/' in p),'oldCountEvidencePreserved':True,'newRecordsSpecifiedOrEvidenceInternal':True,'noClaimOfRuntimeBrowserOrSlaAcceptance':True}
assert checks['existingDecisionsUntouched'];write('semantic-validation.json',checks)
full=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrInstanceService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/UserAccount.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/repository/UserAccountRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/audit/AuditContext.java']
protected=[]
for p in full:
 b=(r/p).read_bytes();prior=subprocess.check_output(['git','show',base+':'+p],cwd=r);protected.append({'path':p,'scope':'complete file','equal':b==prior,'bytes':len(b),'sha256':sha(b)})
regions=[('gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','public UserAccount require',None),('gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','public void reassign','private Context load'),('gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','private void requireActive',None),('gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','private void change','targets(WorkflowInstance instance'),('gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','private boolean eligible',None)]
for p,start,end in regions:
 cur=(r/p).read_text();prior=subprocess.check_output(['git','show',base+':'+p],cwd=r,text=True)
 def extract(s):
  s=s[s.index(start):]
  if end:
   at=s.index(end);s=s[:s.rfind('\n',0,at)]
  return s
 b=extract(cur).encode();old=extract(prior).encode();protected.append({'path':p,'scope':start+' to '+str(end),'equal':b==old,'bytes':len(b),'sha256':sha(b)})
assert all(v['equal'] for v in protected),[v for v in protected if not v['equal']];write('protected-source-checks.json',protected)
retained={
 'DEC-0081-01':'同租户有效未锁定其他用户、可集合外委托的原范围保留；分页只补可到达性。',
 'DEC-0081-02':'原候选来源与当前责任分开，后续加载不重算或覆盖原快照。',
 'DEC-0081-03':'原因和责任历史、节点/表单/结果不变；读取批量不改变写入动作。',
 'DEC-0081-04':'仅复核仍有效的DHR本人转办及通用绕过禁止；管理员局部开放按DEC0093，旧未开放表述不作当前全面禁令。',
 'DEC-0092-02':'记录控制仍限自身候选且禁止申请人自审，不外推同租户集合外委托。',
 'DEC-0092-03':'管理重新分配仍强制实际签署及专门权限和原因。',
 'DEC-0093-01':'集中投影不另建运行任务或扩大业务读取/填报范围。',
 'DEC-0093-02':'普通表单及DHR管理员签名改派原资格、DHR本人转办/撤回/绕过仍禁止。',
 'DEC-0093-03':'集中历史和各领域审计同事务、原签名/内容/冻结及责任证据不变。',
 'DEC-0093-04':'普通表单使用原生执行/历史，工程分页和具体权限码不冒充用户逐字段确认。',
 'fact.catalog.intervention-type':'复用现有两动作语义映射，不改持久化枚举或新增通用事实提供器。',
 'rule.workflow.task-creation-freezes-candidate-resolution':'任务创建时原候选解析证据继续冻结，数组匹配不改变其精确文本身份。',
 'question.multi-tenant-workflow-isolation':'保留既有完整多租户证据与业务契约缺口，不把同租户目录修复当整体隔离完成。'}
audits=[]
for ident,scope in retained.items():
 assert ident in allrecords;v=allrecords[ident];audits.append({'id':ident,'sourcePath':v['path'],'sourceLocator':ident,'reviewStatus':'reviewed','originalMaturity':v['record'].get('status'),'scope':scope,'conclusion':'evidence-gap' if ident.startswith('question.') else 'consistent','runtimeVerification':'not-run by ontology role; current raw source and confirmed semantics only'})
write('retained-semantic-audit.json',{'finiteRetainedIds':len(audits),'consistentInDeclaredScope':12,'existingEvidenceGapRetained':1,'records':audits,'notWholeAuditCoverage':True})
xml=r/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml';shutil.copy2(xml,o/xml.name);doc=ET.parse(xml).getroot();totals={k:int(doc.attrib.get(k,'0')) for k in ('tests','failures','errors','skipped')};assert totals=={'tests':89,'failures':0,'errors':0,'skipped':0};write('knowledge-run.json',{'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr --no-transfer-progress -f tools/knowledge-model/pom.xml clean test','cwd':str(r),'exitCode':0,'sourceCommit':git('rev-parse','HEAD'),'knowledgeWorkingTreeIncluded':changed,'totals':totals,'nativeOrBrowserTestsExecuted':False})
write('contract-baseline.json',{'sourceCommit':git('rev-parse','HEAD'),'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev'),'contractReadCommit':base,'uncommittedContractPaths':[],'contractsEqualToReadBaseline':all((r/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p],cwd=r) for p in ['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md'])})
(o/'knowledge-and-architecture.diff').write_text(subprocess.check_output(['git','diff',base,'--',*changed],cwd=r,text=True))
(o/'tooling-note.txt').write_text('First apply_patch was rejected atomically because architecture header context included an extra phrase absent from the actual source. No files changed in that attempt. Reapplied with exact heading context; formal knowledge run passed 89/89 without any product/test/config edits. Tool-context failure is not a product or JUnit failure.\n')
sync=[{'id':ident,'disposition':'updated','scope':'本轮DEC0095完整合法可选集合规范及来源/验收映射；specified/internal，不宣称产品运行已完成。','sourceReferences':[allrecords[ident]['path'],'docs/knowledge/evidence/qualified-personnel-selection-20261105.md']} for ident in addedids]
sync +=[{'id':a['id'],'disposition':'retained','scope':a['scope'],'sourceReferences':[a['sourcePath']]} for a in audits]
result={'ontologyResult':{'result':'updated','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':{'sourceCommit':git('rev-parse','HEAD'),'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev'),'contractReadCommit':base,'uncommittedContractPaths':[]},'reason':'用户明确要求全部原资格人员可分页/分批到达，已同步新DEC0095和正式规则及证据、锚点、README/架构投影；不把旧100工程截断伪造为历史业务政策。既有资格、写入保护及知识阶段保持，无未决业务问题。产品/前端仍由主审实现与独立质量另验。','changedArtifacts':[{'path':p,'changeType':'update' if p in ['docs/knowledge/README.md','docs/architecture/business-knowledge-model.md'] else 'create','ids':[k for k,v in allrecords.items() if v['path']==p]} for p in changed],'knowledgeSync':sync,'conflicts':[],'questions':[],'validationEvidence':[{'id':'validation.personnel-knowledge-formal-89','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr --no-transfer-progress -f tools/knowledge-model/pom.xml clean test','outcome':'passed','evidence':['knowledge-run.json','knowledge-maven.log',xml.name]},{'id':'validation.personnel-rule-reference-and-maturity','checkType':'reference','command':'python3 /tmp/edhr-personnel-paging-ontology-20261105/build-artifacts.py','outcome':'passed','evidence':['semantic-validation.json','knowledge-delta.json','input-fingerprints.json']},{'id':'validation.personnel-retained-scope-and-guards','checkType':'projection','command':'read current DEC0081/0092/0093/0094, source guards and user confirmation; compare protected source regions against f8638f54','outcome':'passed','evidence':['retained-semantic-audit.json','protected-source-checks.json','contract-baseline.json']}],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(o/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False));write('summary.json',{'result':'updated','changedPaths':changed,'newIds':12,'retainedIds':13,'retainedConsistentInScope':12,'retainedEvidenceGap':1,'knowledgeDelta':kbdelta,'formalKnowledgeTests':totals,'protectedChecks':len(protected),'allProtectedUnchanged':True,'parentNativeOrBrowserNotClaimed':True,'resources':{'subagents':[],'containers':[],'worktrees':[],'cleanupNeeded':False}})
print(json.dumps({'result':'updated','changedFiles':len(changed),'newIds':12,'retainedIds':13,'formalKnowledge':totals,'protectedChecks':len(protected)},ensure_ascii=False))
