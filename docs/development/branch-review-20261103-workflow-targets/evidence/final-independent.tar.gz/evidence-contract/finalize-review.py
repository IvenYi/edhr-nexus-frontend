import hashlib,json,pathlib,subprocess,yaml
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-targets-final-qa-20261103/evidence-contract')
ARC=OUT/'archive'
HEAD='1b4d5c2b1399b6203b5123f8650873d25909f3e5'
BASE='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(ref,path):return subprocess.check_output(['git','show',ref+':'+path],cwd=ROOT)
def write(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
extra=[]
for name,origin in [('ontology/manifest.json','ontology'),('ontology/policy-role/manifest.json','ontology/policy-role')]:
    data=json.loads((ARC/name).read_text());rows=[]
    for item in data['artifacts']:
        b=(ARC/origin/item['path']).read_bytes();rows.append({'path':item['path'],'matches':len(b)==item['bytes'] and sha(b)==item['sha256']})
    extra.append({'id':name,'entries':len(rows),'passed':all(r['matches'] for r in rows),'rows':rows})
for name,ref,expectedCount in [('ontology/source-manifest.json',HEAD,27),('ontology/policy-role/source-manifest.json',BASE,19)]:
    rows=[]
    for item in json.loads((ARC/name).read_text())['files']:
        b=blob(ref,item['path']);rows.append({'path':item['path'],'gitCommit':ref,'matches':sha(b)==item['sha256'] and len(b)==item.get('bytes',item.get('rawBytes'))})
    extra.append({'id':name,'entries':len(rows),'passed':len(rows)==expectedCount and all(r['matches'] for r in rows),'rows':rows})
more=['docs/development/branch-review-20261015/NEXT.md','docs/knowledge/rules/workflow-central-entry.yaml','docs/knowledge/implementation-anchors/workflow-central-entry.yaml','docs/knowledge/facts/workflow-central-entry.yaml']
manifest=json.loads((OUT/'read-source-manifest.json').read_text())
for path in more:
    b=blob(HEAD,path);p=OUT/'read-sources'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    manifest.append({'path':path,'sourceCommit':HEAD,'bytes':len(b),'sha256':sha(b)})
write('read-source-manifest.json',manifest)
write('nested-manifest-verification.json',extra)
assert all(r['passed'] for r in extra)
checks=json.loads((OUT/'checks.json').read_text());assert all(r['outcome']=='passed' for r in checks)
result={'qualityResult':{
 'result':'passed','baseCommit':BASE,'headCommit':HEAD,
 'contractBaseline':{'sourceCommit':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':HEAD,'uncommittedContractPaths':[]},
 'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},
 'knowledgeBaselineVersion':'0.3.25',
 'checks':[
  {'id':'check.original-archive-integrity','required':True,'category':'documentation','description':'Independent byte/manifest and original XML verification, not a test rerun; 154 raw members plus manifest and nested manifests','method':'command','command':'python3 audit-evidence.py; python3 finalize-review.py','outcome':'passed','evidence':['checks.json','verified-archive-manifest.json','nested-manifest-verification.json','original-XML-verification.json','original-red-failures.json']},
  {'id':'check.baseline-source-increment','required':True,'category':'regression','description':'Pinned candidate/base sources, red products at base and transplanted final test byte identity, 27 source receipts and628 increment paths independently recomputed','method':'command','command':'Git object/tree/blob and SHA-256 inspection in audit-evidence.py','outcome':'passed','evidence':['baseline.json','source-fingerprint-verification.json','red-green-source-verification.json','independent-increment-verification.json','commands.json']},
  {'id':'check.policy-and-scope','required':True,'category':'requirements','description':'Read DEC0093/0094 original confirmations and current policies; qualify-before-limit is equivalent to previous dual permissions; write guards unchanged; finite-only scope and original pauses retained','method':'inspection','command':'Read archived current policy/decision sources and candidate product diff; inspect review-notes/README/NEXT/TODO','outcome':'passed','evidence':['semantic-review.md','read-source-manifest.json','read-sources/','source-fingerprint-verification.json']},
  {'id':'check.knowledge-inventory-separation','required':True,'category':'ontology','description':'345 knowledge bytes unchanged;34 increment paths/931 nested candidates independently recomputed and allpending, separate25 finite receipts;0 whole files completed and historical unique unknown','method':'command','command':'Git blob/YAML nested-ID recomputation in audit-evidence.py','outcome':'passed','evidence':['knowledge-byte-verification.json','independent-increment-verification.json','checks.json']},
  {'id':'check.performance-and-A23-disclosure','required':True,'category':'documentation','description':'Concrete projection/strategy split proposal includes lock/transaction/rollback protection; reused existing indexes and explicit EXPLAIN gap; remaining605/JSON/name loops and post-limit candidate paths not falsely closed','method':'inspection','command':'Read review-notes.md and inspect unchanged write methods/indexDDL','outcome':'passed','evidence':['semantic-review.md','read-sources/docs/development/branch-review-20261103-workflow-targets/review-notes.md','checks.json']},
  {'id':'check.UI-evidence-limits','required':True,'category':'visual','description':'Inspect only original browser report metadata, no browser execution by this subrole.40 synthetic API cases separate from strict exit2/86 pending diagnostics and from real backend/JWT/signatures','method':'inspection','command':'Read original UI result and premium command/summary and current disclosures','outcome':'passed','evidence':['checks.json','archive/ui/result.json','archive/edhr-targets-premium-command-20261103.json','archive/edhr-targets-premium-audit-20261103.json']}],
 'findings':[],
 'residualRisks':[
  {'id':'residual.finite-readonly-subcheck','description':'This role inspected raw results but did not execute native integration, browser or knowledge tests. Parent/sibling roles provide actual independent runs.','impact':'This result alone cannot certify final runtime gate.','mitigation':'Combine with fresh independent parent/native/browser/old-source run results.'},
  {'id':'residual.full-audit-remains','description':'34 knowledge paths931 nested candidates allpending;7402 files/135 migrations/464HTTP/216routes only inventory; wholeFile0/historyUnique unknown; existing oldhigh/A12/gaps and paused UI tasks preserved.','impact':'No whole branch audit or release readiness claim.','mitigation':'Continue W2 remainder/W3-W5 and W6/W7 with incremental checkpoints.'},
  {'id':'residual.performance-strict','description':'Full premium strict remains exit2/86 pending candidates; other frozen-candidate postlimit paths,605 summary queries,JSON/name lookup cost and production-scale EXPLAIN/SLA remain unclosed.','impact':'Finite backend repair is not global UI/performance certification.','mitigation':'Queue diagnostic adjudication and measured performance discussion independently; no speculative index or UI changes.'}],
 'blockingConditions':[]}}
(OUT/'result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
write('result.json',result)
write('final-state.json',{'status':'FINAL','subresult':'passed','repositoryWrites':[],'testsRunByThisRole':[],
      'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
      'workingTreeStatus':subprocess.check_output(['git','status','--porcelain=v1'],cwd=ROOT,text=True),
      'independentAutomatedEvidenceChecks':len(checks),'nestedChecks':len(extra),
      'toolingCorrection':'Initial exact Chinese phrase check corrected only in QA evidence helper; initial script/log/checks and diagnosis retained under initial-tooling; no product/test/fixture/config changed.'})
print(json.dumps({'checks':len(checks),'nestedChecks':len(extra),'result':'passed','repositoryWrites':[]},ensure_ascii=False))
