import collections
import csv
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import yaml

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path('/tmp/edhr-targets-final-qa-20261103/evidence-contract')
PKG = 'docs/development/branch-review-20261103-workflow-targets'
HEAD = '1b4d5c2b1399b6203b5123f8650873d25909f3e5'
BASE = '7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
PRIOR = 'cd8a7c82c20bd914a0588579445b2f90d02cd02d'
OUT.mkdir(parents=True, exist_ok=True)
checks = []
commands = []

def sha(data): return hashlib.sha256(data).hexdigest()
def write(name, data):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str) + '\n')
def git(*args):
    cmd = ['git', *args]
    result = subprocess.run(cmd, cwd=ROOT, capture_output=True)
    commands.append({'command': cmd, 'cwd': str(ROOT), 'exitCode': result.returncode,
                     'stdoutBytes': len(result.stdout), 'stdoutSha256': sha(result.stdout),
                     'stderr': result.stderr.decode(errors='replace')})
    if result.returncode: raise RuntimeError(str(cmd) + '\n' + result.stderr.decode())
    return result.stdout
def blob(ref, path): return git('show', ref + ':' + path)
def tree(ref):
    result = {}
    for row in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if row:
            meta, path = row.split(b'\t', 1)
            result[path.decode()] = meta.decode().split()[2]
    return result
def check(name, good, detail):
    checks.append({'id': name, 'outcome': 'passed' if good else 'failed', 'detail': detail})
def readjson(path): return json.loads((OUT / 'archive' / path).read_text())
def jsonl(path): return [json.loads(x) for x in (OUT / 'archive' / path).read_text().splitlines()]

head = git('rev-parse', 'HEAD').decode().strip()
remote = git('rev-parse', 'origin/edhr-dev').decode().strip()
status_before = git('status', '--porcelain=v1', '--untracked-files=all').decode()
write('baseline.json', {'sourceCommit': head, 'targetCommit': remote,
                       'contractReadCommit': HEAD, 'status': status_before,
                       'repositoryWrites': []})
check('candidate-pinned-clean', head == HEAD and remote == BASE and status_before == '',
      {'head': head, 'remote': remote, 'status': status_before})
a, b, c = tree(PRIOR), tree(BASE), tree(HEAD)
contract_paths = ['AGENTS.md', 'codeplzreadme.md'] + sorted(p for p in c if p.startswith('docs/agents/'))
check('contract-byte-baseline', all(a.get(p) == b.get(p) == c.get(p) for p in contract_paths),
      {'paths': len(contract_paths), 'prior': PRIOR, 'base': BASE, 'head': HEAD})
sources = contract_paths + [
    'docs/knowledge/README.md', 'docs/knowledge/open-questions.yaml',
    'docs/architecture/business-knowledge-model.md',
    'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
    'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
    'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md',
    'docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md',
    'docs/development/workflow-central-entry-extension-20261102/user-confirmed.md',
    'docs/development/TODO.md',
    PKG + '/decision-package.yaml', PKG + '/source-review.json', PKG + '/review-notes.md',
    PKG + '/README.md', PKG + '/evidence-manifest.json', PKG + '/increment-manifest.json',
    PKG + '/inventory/inventory-summary.json']
read_manifest = []
for path in dict.fromkeys(sources):
    data = blob(HEAD, path)
    p = OUT / 'read-sources' / path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    read_manifest.append({'path': path, 'sourceCommit': HEAD, 'bytes': len(data), 'sha256': sha(data)})
write('read-source-manifest.json', read_manifest)

pkg = ROOT / PKG
outer = json.loads((pkg / 'evidence-manifest.json').read_text())
archive = (pkg / outer['archive']['path']).read_bytes()
check('archive-gzip-hash', len(archive) == outer['archive']['bytes'] and sha(archive) == outer['archive']['sha256'],
      {'bytes': len(archive), 'sha256': sha(archive)})
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    names = [m.name for m in tar.getmembers()]
    check('archive-safe-regular-unique', len(set(names)) == len(names) and all(m.isfile() and not m.name.startswith('/') and '..' not in pathlib.PurePosixPath(m.name).parts for m in tar),
          {'members': len(names)})
    for m in tar:
        data = tar.extractfile(m).read()
        p = OUT / 'archive' / m.name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(data)
manifest = readjson('manifest.json')
actual_manifest = []
for entry in outer['rawArtifacts']:
    data = (OUT / 'archive' / entry['member']).read_bytes()
    actual_manifest.append({'member': entry['member'], 'bytes': len(data), 'sha256': sha(data)})
check('raw-154-plus-manifest', len(names) == 155 and len(actual_manifest) == 154 and actual_manifest == outer['rawArtifacts'] and manifest == {k:v for k,v in outer.items() if k != 'archive'} and set(names) == {e['member'] for e in actual_manifest} | {'manifest.json'},
      {'raw': len(actual_manifest), 'members': len(names), 'matchesOuterManifest': actual_manifest == outer['rawArtifacts']})
write('verified-archive-manifest.json', actual_manifest)

review = json.loads((pkg / 'source-review.json').read_text())
fingerprints = []
for e in review['sourceFingerprints']:
    data = blob(HEAD, e['path'])
    fingerprints.append({'path': e['path'], 'bytes': len(data), 'sha256': sha(data),
                         'snapshotMatchesCandidate': (OUT / 'archive/source-snapshot' / e['path']).read_bytes() == data,
                         'declaredMatchesCandidate': e['bytes'] == len(data) and e['sha256'] == sha(data)})
check('source-27-candidate-fingerprints', len(fingerprints) == 27 and all(e['snapshotMatchesCandidate'] and e['declaredMatchesCandidate'] for e in fingerprints), {'count': len(fingerprints)})
write('source-fingerprint-verification.json', fingerprints)
redgreen = []
for mode in ['red', 'initial-green-environment', 'green']:
    for path in sorted(p for p in (OUT / 'archive' / mode / 'source-snapshot').rglob('*') if p.is_file()):
        rel = path.relative_to(OUT / 'archive' / mode / 'source-snapshot').as_posix()
        ref = BASE if mode == 'red' and '/src/main/' in rel else HEAD
        data = blob(ref, rel)
        redgreen.append({'mode': mode, 'path': rel, 'expectedCommit': ref, 'sha256': sha(path.read_bytes()), 'matches': path.read_bytes() == data})
check('red-original-products-and-final-identical-tests', len(redgreen) == 12 and all(e['matches'] for e in redgreen), redgreen)
write('red-green-source-verification.json', redgreen)

def suites(directory):
    rows=[]
    for path in sorted((OUT/'archive'/directory).glob('TEST-*.xml')):
        element=ET.parse(path).getroot()
        row={'class':element.attrib['name'],**{k:int(element.attrib.get(k,0)) for k in ['tests','failures','errors','skipped']}}
        rows.append(row)
    return {'totals':{k:sum(r[k] for r in rows) for k in ['tests','failures','errors','skipped']},'classes':rows}
actual_suites={d:suites(d) for d in ['red','initial-green-environment','green','ontology/surefire']}
expected={'red': {'tests':2,'failures':2,'errors':0,'skipped':0},
          'initial-green-environment':{'tests':130,'failures':0,'errors':23,'skipped':0},
          'green':{'tests':130,'failures':0,'errors':0,'skipped':0},
          'ontology/surefire':{'tests':89,'failures':0,'errors':0,'skipped':0}}
check('original-XML-totals-not-added-unique', all(actual_suites[k]['totals']==v for k,v in expected.items()), actual_suites)
initial_xml=(OUT/'archive/initial-green-environment/TEST-com.zencas.edhr.workflow.engine.WorkflowTransferPostgresTest.xml').read_text()
green_runner=(OUT/'archive/green/run.json').read_text()
red_xml=ET.parse(OUT/'archive/red/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml').getroot()
red_failures=[{'name':t.attrib['name'],'failures':[f.text for f in t.findall('failure')]} for t in red_xml.findall('testcase')]
check('initial-error-real-role-cause', 'role "edhr" does not exist' in initial_xml,
      {'roleMissingMessagePresent': 'role "edhr" does not exist' in initial_xml,
       'tests':actual_suites['initial-green-environment']['totals'], 'notCountedAsProductRed':True})
check('red-two-real-assertions', len(red_failures)==2 and all(x['failures'] and '["43"]' in x['failures'][0] and '[]' in x['failures'][0] for x in red_failures), red_failures)
write('original-XML-verification.json',actual_suites)
write('original-red-failures.json',red_failures)

changed=sorted(p for p in a.keys()|b.keys() if a.get(p)!=b.get(p))
def kind(p):
    for prefix,label in [('gmp-platform/backend/src/main/','backend'),('gmp-platform/frontend/src/','frontend'),('gmp-platform/backend/src/test/','test'),('docs/knowledge/','knowledge')]:
        if p.startswith(prefix): return label
    return 'support-or-evidence'
increment=json.loads((pkg/'increment-manifest.json').read_text())
expected_increment=[{'path':p,'oldBlob':a.get(p),'targetBlob':b.get(p),'kind':kind(p),'status':'inventory-only/pending'} for p in changed]
counts=dict(collections.Counter(kind(p) for p in changed))
check('628-increment-paths-and-category-blobs',len(changed)==628 and increment['paths']==expected_increment and counts==increment['counts'],counts)

knowledge=[p for p in c if p.startswith('docs/knowledge/')]
knowledge_manifest=readjson('ontology/knowledge-file-manifest.json')
knowledge_rows=[]
current_docs={}
old_docs={}
for p in sorted(knowledge):
    data=blob(HEAD,p);current_docs[p]=data
    knowledge_rows.append({'path':p,'bytes':len(data),'sha256':sha(data),'equalBase':c[p]==b.get(p)})
for p in sorted(p for p in a if p.startswith('docs/knowledge/')):
    old_docs[p]=blob(PRIOR,p)
check('345-knowledge-byte-preservation',len(knowledge)==345 and all(r['equalBase'] for r in knowledge_rows) and [{k:r[k] for k in ['path','bytes','sha256']} for r in knowledge_rows]==[{k:r[k] for k in ['path','bytes','sha256']} for r in knowledge_manifest['files']],{'count':len(knowledge),'changedInCandidate':sum(not r['equalBase'] for r in knowledge_rows)})
write('knowledge-byte-verification.json',knowledge_rows)
def records(data,path,locator='$',kind='root'):
    if isinstance(data,dict):
        if isinstance(data.get('id'),str):
            yield {'id':data['id'],'sourcePath':path,'sourceLocator':locator,'recordType':kind,'recordSha256':sha(json.dumps(data,ensure_ascii=False,sort_keys=True,default=str).encode())}
        for k,v in data.items(): yield from records(v,path,locator+'.'+str(k),str(k))
    elif isinstance(data,list):
        for i,v in enumerate(data):yield from records(v,path,locator+'['+str(i)+']',kind)
def allrecords(docs):
    return [r for p,data in sorted(docs.items()) if p.endswith(('.yaml','.yml')) for r in records(yaml.safe_load(data),p)]
current_records=allrecords(current_docs);old_records=allrecords(old_docs)
old_by_id=collections.defaultdict(list)
for r in old_records:old_by_id[r['id']].append(r)
changed_knowledge={p for p in changed if kind(p)=='knowledge'}
expected_records=[]
for r in current_records:
    if r['sourcePath'] not in changed_knowledge:continue
    old=old_by_id[r['id']]
    state='added-id' if not old else 'record-content-changed' if not any(x['recordSha256']==r['recordSha256'] for x in old) else 'same-record-in-changed-file'
    expected_records.append({**r,'incrementClass':state})
declared_records=jsonl('ontology/increment-records.jsonl')
projection=[{k:r[k] for k in ['id','sourcePath','sourceLocator','recordType','recordSha256','incrementClass']} for r in declared_records]
classification=dict(collections.Counter(x['incrementClass'] for x in expected_records))
check('34-path-931-ID-candidates-still-pending',len(changed_knowledge)==34 and len(expected_records)==931 and projection==expected_records and all(r['reviewStatus']=='pending' and r['conclusion']=='pending' for r in declared_records),{'files':len(changed_knowledge),'records':len(expected_records),'classes':classification})
finite=jsonl('ontology/id-disposition.jsonl')
current_index={(r['sourcePath'],r['sourceLocator']):r for r in current_records}
check('25-finite-ID-receipts-separate',len(finite)==25 and len({r['id'] for r in finite})==25 and all((r['sourcePath'],r['sourceLocator']) in current_index and r['id']==current_index[(r['sourcePath'],r['sourceLocator'])]['id'] and r['reviewStatus']=='reviewed' for r in finite), {'count':len(finite),'unique':len({r['id'] for r in finite}),'wholeKnowledgeSemantics':False})
write('independent-increment-verification.json',{'prior':PRIOR,'base':BASE,'allPaths':len(changed),'counts':counts,'knowledgePaths':len(changed_knowledge),'nestedIdCandidates':len(expected_records),'classificationCounts':classification,'allPending':True,'finiteRecheckIds':[r['id'] for r in finite]})

with (pkg/'inventory/coverage.csv').open() as f:coverage=list(csv.DictReader(f))
with (pkg/'inventory/entrypoints.csv').open() as f:entrypoints=list(csv.DictReader(f))
with (pkg/'inventory/migrations.csv').open() as f:migrations=list(csv.DictReader(f))
ecount=dict(collections.Counter(r['kind'] for r in entrypoints))
check('7402-fixed-path-inventory-only',len(coverage)==7402 and {r['path'] for r in coverage}==set(b) and all(r['review_status']=='pending' and r['review_depth']=='inventory-only' and r['baseline_commit']==BASE and r['source_evidence']==b[r['path']] for r in coverage),{'rows':len(coverage),'wholeFileCompletion':review['wholeFileCompletion'],'historicalUniqueIncrement':review['historicalUniqueIncrement']})
check('entrypoint-and-migration-candidates-not-runtime',ecount=={'http-annotation':464,'state-definition-candidate':8,'background-candidate':1,'frontend-route-candidate':216} and len(migrations)==135 and all(r['status']=='candidate-needs-call-chain-review' and r['baseline_commit']==BASE and r['source'] in blob(BASE,r['path']).decode().splitlines()[int(r['line'])-1] for r in entrypoints) and all(r['blob']==b[r['path']] and r['baseline_commit']==BASE and r['status']=='inventory-only' for r in migrations),{'entrypoints':ecount,'migrationFiles':len(migrations)})

ui=readjson('ui/result.json');strict=readjson('edhr-targets-premium-audit-20261103.json');strictcmd=readjson('edhr-targets-premium-command-20261103.json')
check('UI40-and-strict86-honest-boundaries',ui['tests']==ui['passed']==40 and ui['failed']==0 and len(ui['results'])==40 and {r['width'] for r in ui['results']}=={390,1440} and 'synthetic' in ui['qualification'] and strictcmd['exitCode']==2 and strict['summary']['total']==86 and review['uiEvidence']['strictPassed']==False and review['uiEvidence']['liveBackend']==False,{'uiQualification':ui['qualification'],'strictSummary':strict['summary'],'strictExit':strictcmd['exitCode'],'frontendProductDelta':[p for p in c if p.startswith('gmp-platform/frontend/src/') and c[p]!=b.get(p)]})
check('A23-split-performance-index-claims-present',all(term in (pkg/'review-notes.md').read_text() for term in ['FormWorkflowReadProjection','work_order→production_object','WorkflowResponsibilityService','EXPLAIN ANALYZE','605','N+1','先100后冻结候选过滤']) and review['newIndexes']==False and review['largeScaleExplainExecuted']==False,{'newIndexes':False,'largeScaleExplain':False,'implementedExtraction':False})

write('checks.json',checks)
write('commands.json',commands)
status_after=git('status','--porcelain=v1','--untracked-files=all').decode()
write('cleanup.json',{'repositoryWrites':[],'resourcesCreated':['evidence output directory only'],'worktreesCreated':[],'containersCreated':[],'statusBefore':status_before,'statusAfter':status_after,'sourceHeadAfter':git('rev-parse','HEAD').decode().strip()})
print(json.dumps({'checks':len(checks),'passed':sum(c['outcome']=='passed' for c in checks),'failed':[c for c in checks if c['outcome']!='passed'],'archiveSha256':sha(archive),'output':str(OUT)},ensure_ascii=False,default=str))
