import pathlib,json,hashlib,subprocess,yaml,datetime
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend');OUT=pathlib.Path('/tmp/edhr-workflow-targets-ontology-20261103');BASE='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def put(name,obj): (OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str)+'\n')
def walk(data,path,locator='$',kind='root'):
 result=[]
 if isinstance(data,dict):
  if isinstance(data.get('id'),str):result.append({'id':data['id'],'recordType':kind,'sourcePath':path,'sourceLocator':locator,'originalMaturity':data.get('status'),'originalVisibility':data.get('visibility'),'record':data})
  for k,v in data.items():result.extend(walk(v,path,locator+'.'+str(k),str(k)))
 elif isinstance(data,list):
  for i,v in enumerate(data):result.extend(walk(v,path,locator+'['+str(i)+']',kind))
 return result
prior=[]
for line in (OUT/'policy-role/statement-dispositions.jsonl').read_text().splitlines():prior.append(json.loads(line))
assert len(prior)==21 and len({r['id'] for r in prior})==21
extra={
 'rule.workflow-central-entry.domain-projection':('docs/knowledge/rules/workflow-central-entry.yaml','只修已存在的领域目标目录读取，集中投影和按权只读、不生成运行任务/不授操作权保持；未认证完整集中列表与所有领域。'),
 'rule.workflow-central-entry.signed-responsibility-change':('docs/knowledge/rules/workflow-central-entry.yaml','资格仍为对应领域原双权限，读取过滤前移，写入时require/qualified/eligible、签名/预期状态/锁/领域审计及冻结证据原代码保持；有限源码等价核对不等于整条规范已运行通过。'),
 'term.workflow-transfer-action':('docs/knowledge/glossary.yaml','普通转办原三参使用空额外权限集合，原租户正常可用其他用户及原来源边界保持；记录控制候选和禁止申请人自审路径不由本批扩大。'),
 'term.workflow-reassignment-action':('docs/knowledge/glossary.yaml','管理员按领域资格改派与处理人转办继续分开；100之前应用现有资格不新增政策或永久目标角色，原签名和处理责任语义保持。'),
}
all_index=[]
for p in sorted((ROOT/'docs/knowledge').rglob('*.yaml')):all_index.extend(walk(yaml.safe_load(p.read_text()),str(p.relative_to(ROOT))))
by_id={r['id']:r for r in all_index}
selected=[];dispositions=[]
for r in prior:
 item=by_id[r['id']];selected.append(item)
 dispositions.append({**r,'reviewScope':'Finite policy replacement/target-read eligibility equivalence only; not complete workflow or whole-increment runtime closure.','evidenceReferences':['policy-role/readonly-result.json','policy-role/review.md','implementation-equivalence.json']})
for id,(path,note) in extra.items():
 r=by_id[id];assert r['sourcePath']==path;selected.append(r)
 dispositions.append({k:v for k,v in r.items() if k!='record'}|{'sourceCommit':BASE,'reviewStatus':'reviewed','conclusion':'consistent','disposition':'retained','reviewScope':'Finite unchanged target-qualification semantics only; no status promotion or full-rule runtime certification.','judgment':note,'evidenceReferences':['implementation-equivalence.json',path]})
assert len(dispositions)==25 and len({r['id'] for r in dispositions})==25
(OUT/'id-disposition.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,default=str)+'\n' for r in dispositions))
(OUT/'selected-original-records.yaml').write_text(yaml.safe_dump({'sourceCommit':BASE,'selectedRecords':selected},allow_unicode=True,sort_keys=False))
paths=[
 'AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
 'docs/development/branch-review-20261103-workflow-targets/decision-package.yaml',
 'docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
 'docs/knowledge/decisions/DEC-0091-workflow-reassignment-signature.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
 'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
 'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md','docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md',
 'docs/knowledge/rules/workflow-central-entry.yaml','docs/knowledge/glossary.yaml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/UserAccount.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/UserRole.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/RolePermission.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/entity/Permission.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java',
]
files=[]
for p in paths:
 b=(ROOT/p).read_bytes();files.append({'path':p,'rawBytes':len(b),'sha256':sha(b),'scope':'Source fingerprint; semantic review is limited to records/methods documented separately.'})
put('source-manifest.json',{'sourceCommit':git('rev-parse','HEAD').decode().strip(),'targetCommit':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':BASE,'uncommittedContractPaths':[],'workingTreeIncludes':git('diff','--name-only','--','gmp-platform/backend/src/main','gmp-platform/backend/src/test').decode().splitlines(),'files':files,'note':'Current27 source fingerprints include intentional main-owned product/test worktree deltas. Policy-role19 source fingerprints refer to fixed7c Git originals, not an assertion they equal the repaired worktree.'})
(OUT/'product-working-tree.diff').write_bytes(git('diff','--','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java'))
put('implementation-equivalence.json',{
 'sourceCommit':BASE,'inspection':'Main-owned stable worktree after parent notification; no runtime tests by ontology role except formal knowledge suite.',
 'permissionConjunction':[{'domain':'FORM_PROCESS','requiredAll':['production.execution','form-management.review'],'before':'qualified uses permission(A) && permission(B)','after':'each code has correlated EXISTS and predicates composed with AND before PageRequest(0,100)'},{'domain':'DHR_SUMMARY reassignment','requiredAll':['records.dhr-review','dhr.reviews.act'],'before':'eligible uses count(DISTINCT code)==2','after':'each code has correlated EXISTS and predicates composed with AND before PageRequest(0,100)'}],
 'roleJoin':'UserRole.userId=user_account.id; RolePermission.roleId=UserRole.roleId; Permission.id=RolePermission.permissionId; Permission.code=bound code. Separate existence per code permits split-role grants and duplicates do not change eligibility.',
 'retained':['tenant equality','status ACTIVE','lockedUntil null or <= captured now','same lowercase keyword/sort by displayName,id and100 bound','current-assignee exclusion now before limit plus original post-filter','three-argument helper passes empty required set','write-time TenantTransferTargets.require and Form qualified/DHR eligible','operator and signer permissions, signature, state token, locks, transaction, audit and frozen evidence code'],
 'separateScope':['generic/record-control frozen-candidate post-filter path unchanged','record-control applicant exclusion unchanged','DEC0094 authenticated workflow-definition candidate read not applied to target/action authorization','all prior audit/high/A12/gaps and user pauses retained'],
 'nameOfChange':'Deterministic equivalent target eligibility in DB before bounded selection; not a new business rule. Read-time qualification naturally occurs in the candidate SQL snapshot; write-time immediate validation remains.',
 'runtimeLimit':'The ontology role did not run PG/HTTP/browser or native red/green tests; parent/main and final QA own those results.'})
put('source-preservation.json',{'files':len(files),'allSourceBytesEqualManifestAtFinalize':all(sha((ROOT/x['path']).read_bytes())==x['sha256'] for x in files),'knowledgeBytesEqualPinnedCommit':all((ROOT/x['path']).read_bytes()==git('show',BASE+':'+x['path']) for x in json.loads((OUT/'knowledge-file-manifest.json').read_text())['files']),'repositoryWritesByOntologyRole':[],'wholeFileCompletionClaim':0})
ontology={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':git('rev-parse','HEAD').decode().strip(),'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':BASE,'uncommittedContractPaths':[]},
 'reason':'本批仅将普通表单/DHR现有领域双权限资格、当前处理人排除放在租户有效用户100人截取前，修正合法目标被无资格前缀遮蔽；两个权限各自EXISTS并AND与原Form AND/DHR DISTINCT两码=2等价，不增加角色/资格政策。原三参传空额外权限集合，普通转办及记录控制冻结候选/禁止申请人自审保持；最终写入即时资格、签名/预期状态、锁/审计/冻结代码不变。DEC0093按声明局部替代旧管理员改派未开放范围，不能回流旧DHR全面禁令；DHR本人转办/撤回及通用批准绕过仍禁。DEC0094仅流程定义候选认证读取，不授改派或审批权。有限25既有ID保留原定义与成熟度，无新声明/替代或知识修改。345文件字节不变，0.3.25/schema1.2.0/P0进行中不提升；34路径/931嵌套ID候选仅盘点pending，不冒称全增量/全库已语义核对。此本体结果不代替主审与fresh独立PG/回归/最终质量。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
 {'id':'validation.workflow-targets-formal-knowledge','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test','outcome':'passed','evidence':['knowledge-maven.log','test-summary.json','surefire/','89 actual tests;0 failures/errors/skips. Formal schema/reference/type/projection only, not complete semantic or runtime certification.']},
 {'id':'validation.workflow-targets-finite-policy-equivalence','checkType':'evidence-path','command':'Read original current declarations/confirmed evidence and inspect main stable three-product-file diff','outcome':'passed','evidence':['id-disposition.jsonl','selected-original-records.yaml','implementation-equivalence.json','product-working-tree.diff','policy-role/readonly-result.json','policy-role/review.md']},
 {'id':'validation.workflow-targets-pinned-byte-increment','checkType':'reference','command':'NUL-delimited Git paths, raw SHA256 and pinned7c/oldcd8 nested-ID candidate inventory','outcome':'passed','evidence':['knowledge-file-manifest.json','increment-files.json','increment-records.jsonl','baseline-check.json','source-manifest.json','source-preservation.json','345 knowledge files unchanged;34 changed paths and931 nested current ID candidates remain inventory/pending.36 added,56 content-changed,839 same-in-changed-file;0 disappearing IDs.']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
}}
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(ontology,allow_unicode=True,sort_keys=False,width=120))
put('subroles.json',{'allFinal':True,'roles':[{'name':'policy_boundary_review','status':'FINAL','result':'passed','originalManifestSha256':'67889d121a7b18665cb57f659cd5dfbaebfa5732b23c9e0f5e0616dc8bb01612','scope':'21 declarations/19 fixed7c files, no runtime execution or repository edits'}]})
artifacts=[]
for p in sorted(OUT.rglob('*')):
 if p.is_file() and p.name!='manifest.json':b=p.read_bytes();artifacts.append({'path':str(p.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
# Preserve child manifest as an artifact rather than omit it with the root manifest.
child=OUT/'policy-role/manifest.json';b=child.read_bytes();assert sha(b)=='67889d121a7b18665cb57f659cd5dfbaebfa5732b23c9e0f5e0616dc8bb01612';artifacts.append({'path':str(child.relative_to(OUT)),'bytes':len(b),'sha256':sha(b)})
put('manifest.json',{'status':'FINAL','ontologyResult':'not-applicable','sourceCommit':BASE,'allSubrolesFinal':True,'artifactCount':len(artifacts),'artifacts':sorted(artifacts,key=lambda r:r['path']),'note':'All raw originals included; policy-role baseline fingerprints pinned7c, parent27 fingerprints are repaired worktree. Knowledge/ID inventories do not imply semantic closure.'})
print(json.dumps({'result':'not-applicable','finiteIds':len(dispositions),'sourceFingerprints':len(files),'rawArtifacts':len(artifacts),'manifestSha256':sha((OUT/'manifest.json').read_bytes())},ensure_ascii=False))
