import pathlib,subprocess,json,hashlib,tarfile,io,yaml,collections
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend');OUT=pathlib.Path('/tmp/edhr-workflow-targets-ontology-20261103')
BASE='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37';PRIOR='cd8a7c82c20bd914a0588579445b2f90d02cd02d'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(data):return hashlib.sha256(data).hexdigest()
def write(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str)+'\n')
def records(data,path,locator='$',kind='root'):
 result=[]
 if isinstance(data,dict):
  if isinstance(data.get('id'),str):
   result.append({'id':data['id'],'recordType':kind,'sourcePath':path,'sourceLocator':locator,'originalMaturity':data.get('status'),'originalVisibility':data.get('visibility'),'recordSha256':sha(json.dumps(data,ensure_ascii=False,sort_keys=True,default=str).encode()),'record':data})
  for key,value in data.items():result.extend(records(value,path,locator+'.'+str(key),str(key)))
 elif isinstance(data,list):
  for i,value in enumerate(data):result.extend(records(value,path,locator+'['+str(i)+']',kind))
 return result
def parse_files(files):
 result=[]
 for path,data in sorted(files.items()):
  if path.endswith(('.yaml','.yml')):result.extend(records(yaml.safe_load(data),path))
 return result
def archive(ref):
 raw=git('archive',ref,'docs/knowledge')
 with tarfile.open(fileobj=io.BytesIO(raw)) as tar:return {m.name:tar.extractfile(m).read() for m in tar if m.isfile()}
paths=[p.decode() for p in git('ls-files','-z','docs/knowledge').split(b'\0') if p]
current={p:(ROOT/p).read_bytes() for p in paths};pinned=archive(BASE);old=archive(PRIOR)
assert len(paths)==345 and current==pinned
changed=[p.decode() for p in git('diff','--name-only','-z',PRIOR,BASE,'--','docs/knowledge').split(b'\0') if p]
assert len(changed)==34
entries=[{'path':p,'bytes':len(b),'sha256':sha(b),'equalPinnedHeadBytes':b==pinned[p],'semanticReview':'pending','note':'Byte inventory only, not global semantic or runtime certification.'} for p,b in sorted(current.items())]
write('knowledge-file-manifest.json',{'sourceCommit':BASE,'files':entries,'count':len(entries),'semanticCompletionClaim':False})
curr_records=parse_files(current);old_records=parse_files(old)
old_by_id=collections.defaultdict(list)
for r in old_records:old_by_id[r['id']].append(r)
curr_by_id=collections.defaultdict(list)
for r in curr_records:curr_by_id[r['id']].append(r)
increment=[]
for r in curr_records:
 if r['sourcePath'] not in changed:continue
 previous=old_by_id[r['id']]
 state='added-id' if not previous else 'record-content-changed' if not any(x['recordSha256']==r['recordSha256'] for x in previous) else 'same-record-in-changed-file'
 increment.append({k:v for k,v in r.items() if k!='record'}|{'incrementClass':state,'auditScopeClass':'increment-inventory-only','reviewStatus':'pending','conclusion':'pending','remediationStatus':'not-assessed','evidence':[]})
removed=[]
for r in old_records:
 if r['sourcePath'] in changed and not curr_by_id[r['id']]:removed.append({k:v for k,v in r.items() if k!='record'}|{'incrementClass':'id-not-present-in-current-knowledge','reviewStatus':'pending','conclusion':'pending','evidence':[]})
(OUT/'increment-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False,default=str)+'\n' for r in increment+removed))
file_increment=[]
for p in changed:
 b=current.get(p);before=old.get(p)
 file_increment.append({'path':p,'change':'added' if before is None else 'modified' if b is not None else 'deleted','beforeSha256':sha(before) if before is not None else None,'afterSha256':sha(b) if b is not None else None,'currentNestedIdCandidates':sum(r['sourcePath']==p for r in increment),'semanticReview':'pending','conclusion':'pending','note':'Includes Markdown/no-ID support files; no schema pass or file existence converted to consistent.'})
write('increment-files.json',{'priorDeliveredCommit':PRIOR,'currentTargetCommit':BASE,'files':file_increment,'fileCount':len(file_increment),'recordCandidates':len(increment),'removedIdCandidates':len(removed),'classificationCounts':dict(collections.Counter(x['incrementClass'] for x in increment+removed)),'allInitializedPending':True,'countLimit':'Nested ID-valued record candidates; semantic selected-ID dispositions are separate. Raw inventory is not full semantic/unique coverage.'})
write('baseline-check.json',{'sourceCommit':git('rev-parse','HEAD').decode().strip(),'targetCommit':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':BASE,'uncommittedContractPaths':[],'knowledgeFiles':len(paths),'knowledgeBytesEqualPinnedCommit':True,'knowledgeModelVersion':yaml.safe_load(current['docs/knowledge/schema.yaml']).get('knowledgeModelVersion'),'schemaVersion':yaml.safe_load(current['docs/knowledge/schema.yaml']).get('schemaVersion'),'contractDeltaFromPriorDeliveredBytes':len(git('diff',PRIOR,BASE,'--','AGENTS.md','codeplzreadme.md','docs/agents')),'changedKnowledgeFiles':len(changed),'inventoryIdCandidates':len(increment),'idInventoryCandidatesAllPending':True,'wholeSemanticCompletionClaim':False,'repositoryKnowledgeWritesByThisRole':[]})
write('knowledge-id-index.json',{'sourceCommit':BASE,'records':[{k:v for k,v in r.items() if k!='record'} for r in curr_records],'note':'Source locator index only; no automatic semantic result.'})
print(json.dumps({'knowledgeFiles':len(paths),'incrementFiles':len(changed),'incrementRecordCandidates':len(increment),'removedIdCandidates':len(removed),'classifications':dict(collections.Counter(x['incrementClass'] for x in increment+removed))},ensure_ascii=False))
