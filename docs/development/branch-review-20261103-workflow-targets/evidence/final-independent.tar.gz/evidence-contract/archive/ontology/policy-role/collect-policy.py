import pathlib,subprocess,hashlib,json,yaml
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-targets-ontology-20261103/policy-role');out.mkdir(parents=True,exist_ok=True)
base='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
def blob(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root)
def sha(data):return hashlib.sha256(data).hexdigest()
decs={
'DEC-0081':'docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml',
'DEC-0087':'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml',
'DEC-0091':'docs/knowledge/decisions/DEC-0091-workflow-reassignment-signature.yaml',
'DEC-0092':'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
'DEC-0093':'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
'DEC-0094':'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml'}
retain={
'DEC-0081-01':'保留普通处理人通用/表单租户内集合外委托，不因管理员改派权限码而增加普通转办限制。',
'DEC-0081-02':'原候选来源与当前责任分开保留，只有当前目标处理，不重建历史缺失来源。',
'DEC-0081-03':'转办只换当前责任并记录原因/身份/时间，不推进节点或产生审批结果。',
'DEC-0081-04':'仅管理员改派未开放的普通表单/DHR范围被0093-02局部替代；DHR本人转办和证据绕过仍禁，历史原文保留。',
'DEC-0087-07':'0094只关闭候选读取协同差异；菜单与本人申请/当前及本人已处理审批数据范围保留。',
'DEC-0091-01':'重新分配必须有效电子签名，登录/权限/原因不能替代，现政策不留免签选项。',
'DEC-0091-02':'专门权限/目标/原因/审计及现行签署身份要求保留，不能外推普通转办/撤回必签。',
'DEC-0091-03':'管理员DHR改派未开放范围由0093-02局部替代；旧调研时点和DHR禁绕过/终止/跳转/直接批准保留。',
'DEC-0092-01':'0093-01补充集中普通表单/DHR范围，仍复用原路由/实例/只读日志，不另造运行引擎。',
'DEC-0092-02':'记录控制候选边界及申请人禁止自审保持；不把普通表单租户内转办范围扩展到记录控制。',
'DEC-0092-03':'管理员和真实签署人的权限、必签、原因与不可变审计保持，不授其他动作。',
'DEC-0092-04':'记录控制受限撤回仍限本轮未作批准/退回决定、原子消费WITHDRAWN，不落地来源效果。',
'DEC-0092-05':'只局部替代普通表单/DHR管理员改派未开放；DHR本人转办/撤回及通用批准绕过等禁令保留。',
'DEC-0092-06':'DHR排除仅是2026-10-30实现事实，保留原198/25测试时点，不作为当前永久范围。',
'DEC-0093-01':'当前普通表单/DHR集中日志与干预范围按权，日志不授审批/填报或内容写权。',
'DEC-0093-02':'管理员签名重新分配只改当前未处理任务责任，旧候选/内容/DHR冻结/旧签名决定保持，不授DHR本人转办。',
'DEC-0093-03':'集中历史与领域数据审计同事务可追溯，责任/签名/日志/审计成败一致；目标查询只读不改此链。',
'DEC-0093-04':'现有双权限码、分页等为可验证工程映射而非用户逐字段政策；本次先资格后100上限不新造业务含义。',
'DEC-0094-01':'仅CHANGE/OBSOLETE流程候选读取isAuthenticated，不把该认证边界扩展为改派目标可任意选。',
'DEC-0094-02':'候选可读不授发起/审批权，来源/签名/状态/数据范围继续服务端复核。',
'DEC-0094-03':'局部读取差异按本次证据关闭，不由此提升P0/A12/归档/多租户或发布成熟度。'}
records=[]
for path in decs.values():
 data=yaml.safe_load(blob(path))
 for di,decision in enumerate(data['decisions']):
  for si,statement in enumerate(decision.get('decisionStatements',[])):
   ident=statement['id']
   if ident in retain:
    records.append({'id':ident,'recordType':'decisionStatement','sourcePath':path,'sourceLocator':f'$.decisions[{di}].decisionStatements[{si}]','sourceCommit':base,'originalMaturity':statement['status'],'originalVisibility':statement.get('visibility'),'originalStatement':statement['statement'],'reviewStatus':'reviewed','conclusion':'consistent','disposition':'retained','reviewScope':'Finite declaration-level applicability and target-qualification policy only; not runtime or whole-library closure.','judgment':retain[ident]})
assert len(records)==21
(out/'statement-dispositions.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records))
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',*decs.values(),'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md','docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java']
files=[]
for path in paths:
 b=blob(path);files.append({'path':path,'sourceCommit':base,'bytes':len(b),'sha256':sha(b),'kind':'original-baseline-git-blob','currentBytesEqualAtCollection':(root/path).read_bytes()==b})
(out/'source-manifest.json').write_text(json.dumps({'baseline':base,'files':files,'note':'Baseline original blobs; source implementation is intentionally being repaired by main. This subrole does not claim final modified implementation or runtime validation.'},ensure_ascii=False,indent=2)+'\n')
result={'status':'FINAL','result':'passed','kind':'read-only-policy-boundary-subcheck','contractBaseline':{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','roadmap':{'stage':'P0','status':'in-progress'},'checkedDeclarations':21,'repositoryWrites':[],'testsRun':[],'findings':[],'conflicts':[],'questions':[],'scopeConclusion':'Existing two-code form/DHR target eligibility can be applied before100-user limit without a new business decision, while write-time exact authorization/signature/status/lock/audit/frozen evidence rules remain unchanged.','permissionMap':[{'domain':'FORM_PROCESS managerial reassignment','allRequired':['production.execution','form-management.review'],'originalSource':'FormWorkflowOperations.qualified/permission','authorityClass':'existing engineering mapping; not a user-specified code policy'},{'domain':'DHR_SUMMARY managerial reassignment','allRequired':['records.dhr-review','dhr.reviews.act'],'originalSource':'WorkflowResponsibilityService.eligible(reassignment=true)','authorityClass':'existing engineering mapping; not a user-specified code policy'}],'replacementMap':[{'new':'DEC-0093-01','old':'DEC-0092-01','relation':'supplements central form/DHR scope'},{'new':'DEC-0093-02','old':['DEC-0081-04','DEC-0091-03','DEC-0092-05'],'relation':'partial replacement only for previously unimplemented ordinary-form/DHR managerial reassignment; other prohibitions retained'},{'new':'DEC-0094-01','old':'DEC-0087-07 candidate-read collaboration gap','relation':'closes only local authenticated published workflow candidate read boundary'}],'implementationChecksRequiredByParent':['Both permission codes required, not OR; split/duplicate role grants preserve same meaning.','Tenant/status/lock/current assignee, bounded100 and existing sort/search retained.','Write-time require/qualified/eligible, valid signature/expected state, locking/audit and frozen origins retained.','Generic/record-control frozen candidates and applicant exclusion not silently expanded.','Fresh source fingerprints and native test evidence after main implementation are outside this subrole.'],'limitations':['No Maven/PG/HTTP/browser execution.','No whole34-path increment or345-file semantic-completion claim.','Not the final ontologyResult or independent final QA; parent integrates current source and formal knowledge validation.']}
(out/'readonly-result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(out/'review.md').write_text('''# 有限政策边界分项

FINAL passed，仅表示只读政策/原始实现边界核对无冲突，不是最终ontologyResult或运行质量通过。实际契约/来源/目标为7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37，知识0.3.25/schema1.2.0/P0进行中保持。

DEC0093-01补充集中日志/干预的普通表单与DHR范围；02只局部替代DEC0081-04、0091-03、0092-05中管理员重新分配未开放部分。DHR本人转办/撤回/通用直接批准及证据绕过仍不开放，原专属审批/退回、冻结、既有签名/决定保持。0092-06的旧DHR查询排除是历史实现事实，不是当前永久政策。

DEC0094只将CHANGE/OBSOLETE的已发布流程候选只读边界收敛为认证访问，不授菜单、来源修改、发起、审批或改派权；不应把这个读取规则错用为改派目标无需领域资格。

现有Form qualified要求production.execution AND form-management.review，DHR eligible在管理员改派分支要求records.dhr-review与dhr.reviews.act两个DISTINCT权限均存在。原确认页明确这些码是既有工程选择，不是用户逐字段政策。以等价存在性条件在数据库100人截取前过滤，解决无资格前缀遮蔽有资格目标，是合理确定性实现修复，不需新业务决策；不能使用OR、加入新角色状态规则或删除最终提交即时资格复核。

21个声明的逐项处置及原文定位在statement-dispositions.jsonl，19个原始基线文件的字节在source-manifest.json。原件基于固定Git基线；主审正修复读取查法，后续源指纹和真实数据库/回归由父角色与主审完成。本分项不运行Maven/PG，不修改仓库，不把34路径/345知识盘点或该有限一致结论当全库语义完成。
'''.replace('\n+','\n'))
script=pathlib.Path('/tmp/edhr-workflow-targets-policy-collect.py');(out/'collect-policy.py').write_bytes(script.read_bytes())
artifacts=[]
for file in sorted(out.rglob('*')):
 if file.is_file() and file.name!='manifest.json':b=file.read_bytes();artifacts.append({'path':str(file.relative_to(out)),'bytes':len(b),'sha256':sha(b)})
(out/'manifest.json').write_text(json.dumps({'status':'FINAL','result':'passed','artifacts':artifacts,'note':'Read-only bounded policy subrole; originals and all source baselines explicit.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'files':len(files),'declarations':len(records),'artifacts':len(artifacts),'manifestSha256':sha((out/'manifest.json').read_bytes())},ensure_ascii=False))
