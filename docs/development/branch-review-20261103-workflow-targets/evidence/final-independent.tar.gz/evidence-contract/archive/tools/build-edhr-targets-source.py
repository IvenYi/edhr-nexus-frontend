import pathlib,subprocess,json,hashlib,collections
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=root/'docs/development/branch-review-20261103-workflow-targets';old='cd8a7c82c20bd914a0588579445b2f90d02cd02d';base='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
def sha(b):return hashlib.sha256(b).hexdigest()
def tree(ref):
 result={}
 for row in subprocess.check_output(['git','ls-tree','-r','-z',ref],cwd=root).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);result[path.decode()]=meta.decode().split()[2]
 return result
a,b=tree(old),tree(base);changed=[p for p in sorted(a.keys()|b.keys()) if a.get(p)!=b.get(p)]
def kind(p):
 for prefix,label in [('gmp-platform/backend/src/main/','backend'),('gmp-platform/frontend/src/','frontend'),('gmp-platform/backend/src/test/','test'),('docs/knowledge/','knowledge')]:
  if p.startswith(prefix):return label
 return 'support-or-evidence'
increment={'previousDelivery':old,'targetCommit':base,'paths':[{ 'path':p,'oldBlob':a.get(p),'targetBlob':b.get(p),'kind':kind(p),'status':'inventory-only/pending'} for p in changed],'counts':dict(collections.Counter(kind(p) for p in changed)),'note':'Pin all actual remote increments, no automatic semantic completion; finite method receipts below are separate.'}
(out/'increment-manifest.json').write_text(json.dumps(increment,ensure_ascii=False,indent=2)+'\n')
paths=sorted({p for p in changed if kind(p) in ('backend','frontend','test')}|{'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/engine/WorkflowTransferPostgresTest.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','DESIGN.md'})
fingerprints=[]
for p in paths:
 data=(root/p).read_bytes();fingerprints.append({'path':p,'bytes':len(data),'sha256':sha(data)})
records=[
 {'path':'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','locator':'search three/four parameter methods','result':'Permissions and current-assignee exclusion before bounded100; existing available/post checks unchanged, no new permission restriction for three-arg normal delegation.','a23':'Explicit existing permission set only; no configuration/cache/fallback; retain old duplicate post checks for a separate whole pass.'},
 {'path':'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','locator':'targets/reassign/qualified and source/detail boundaries','result':'Reader passes same two permission codes; write-time qualified/signature/state/lock/audit/frozen scope unchanged.','a23':'Read eligibility does not replace fresh action checks. Projection/runtime splitting proposal documented, not implemented.'},
 {'path':'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','locator':'DHR reassignment targets vs change/eligible and other domain targets','result':'DHR reader only uses permission-scoped directory; other domains preserve prior path; write-time COUNT DISTINCT and business/signature gates unchanged.','a23':'Do not broaden target policy or interpret new admin reassignment as DHR self transfer. Other frozen-candidate post-limit paths remain candidate issues.'},
 {'path':'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','locator':'union SQL/count/page and detail task name loop','result':'Current remote addition pages scoped union in SQL, not Java; JSON lateral/full count cost and per-task name lookup remain separate performance candidates.','a23':'Do not remove visibility clauses as duplicate; data scope precedes count/page.'},
 {'path':'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java','locator':'candidate read authorization delta','result':'DEC0094 changes definition candidates to authenticated read only; current real method-security3 and integration fixtures pass, no new write grant.','a23':'Do not restore obsolete create permission requirement or broaden action scope.'}
]
ui=json.loads(pathlib.Path('/tmp/edhr-targets-ui-20261103/result.json').read_text())
assert ui['tests']==ui['passed']==40 and ui['failed']==0
static=json.loads(pathlib.Path('/tmp/edhr-targets-premium-audit-20261103.json').read_text())
source={'baseCommit':base,'wholeFileCompletion':0,'historicalUniqueIncrement':None,'records':records,'sourceFingerprints':fingerprints,'incrementCounts':increment['counts'],'productFilesChanged':3,'testFilesChanged':1,'newIndexes':False,'indexEvidence':['baseline uk_user_role(user_id,role_id)','baseline role_permission unique(role_id,permission_id)','baseline uk_permission_code(code)'],'largeScaleExplainExecuted':False,'uiEvidence':{'actualSyntheticBrowserCases':40,'actualWidths':[1440,390],'liveBackend':False,'screenshotsInspected':['form-390.png','single-1440.png'],'frontendSourceChangedInThisRepair':False,'canonicalOwners':'DESIGN/list/dialog/drawer guidelines, ListTableShell/styles/column helpers, DetailDrawer, FormDialog, WorkflowResponsibilityDialog, SnackbarProvider/MUI','strictScan':static['summary'],'strictPassed':False,'strictEntriesDisposition':'All pending diagnostic candidates, not86 product bugs; only one hit on14 incoming UI paths, native page-size ownership. No UI changes relative7c.'},'remaining':['34 knowledge paths/931 ID candidates pending;25 finite ontology checks overlap history','Other frozen-candidate after100 filter paths; central JSON projection and task-name loops; Summary605 and ZIP memory','Full workflow/UI/account/recipient/ACL/concurrency matrices; original high/A12/gaps and pauses','W2 remainder,W3/W4/W5 crossing,W6 robustness/performance/extraction/A23 include old reviewed,W7 new increments']}
(out/'source-review.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'incrementCounts':increment['counts'],'sourceFingerprints':len(fingerprints),'ui':40,'static':static['summary']}))
