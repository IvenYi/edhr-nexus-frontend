import pathlib,json,hashlib,tarfile,shutil,subprocess,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=root/'docs/development/branch-review-20261103-workflow-targets';stage=pathlib.Path('/tmp/edhr-targets-primary-archive-20261103');stage.mkdir(exist_ok=True)
def sha(b):return hashlib.sha256(b).hexdigest()
groups={'red':'/tmp/edhr-targets-main-red-20261103','green':'/tmp/edhr-targets-main-green-20261103','initial-green-environment':'/tmp/edhr-targets-main-green-initial-20261103','ontology':'/tmp/edhr-workflow-targets-ontology-20261103','ui':'/tmp/edhr-targets-ui-20261103'}
for label,path in groups.items():shutil.copytree(path,stage/label,dirs_exist_ok=True)
for group,expected in [('red',(2,2,0,0)),('green',(130,0,0,0)),('initial-green-environment',(130,0,23,0))]:
 d=json.loads((stage/group/'test-summary.json').read_text());assert tuple(d['totals'][k] for k in ['tests','failures','errors','skipped'])==expected and not d['missingFreshReports'];assert json.loads((stage/group/'cleanup.json').read_text())['removed']
red=ET.parse(stage/'red/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml').getroot();assert len(red.findall('testcase'))==2
for c in red.findall('testcase'):assert c.find('failure') is not None and '43' in c.find('failure').text and '[]' in c.find('failure').text
for item in json.loads((stage/'red/run.json').read_text())['sourceFingerprints'][:3]:assert sha(subprocess.check_output(['git','show','7c2c74d0:'+item['path']],cwd=root))==item['sha256']
assert 'role "edhr" does not exist' in (stage/'initial-green-environment/maven.log').read_text()
tools=stage/'tools';tools.mkdir(exist_ok=True)
for name in ['run-edhr-targets.py','build-edhr-targets-source.py','archive-edhr-targets-primary.py','edhr-premium-audit-20261103.py']:shutil.copy2('/tmp/'+name,tools/name)
for name in ['edhr-targets-ui-20261103.log','edhr-targets-frontend-build-20261103.log','edhr-targets-list-style-20261103.log','edhr-targets-premium-audit-20261103.json','edhr-targets-premium-command-20261103.json']:shutil.copy2('/tmp/'+name,stage/name)
fingerprints=json.loads((out/'source-review.json').read_text())['sourceFingerprints']
for item in fingerprints:
 p=item['path'];b=(root/p).read_bytes();assert sha(b)==item['sha256'];dest=stage/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
summary={'red':{'tests':2,'realAssertionFailures':2,'errors':0,'skipped':0},'green':{'tests':130,'failures':0,'errors':0,'skipped':0},'initialEnvironment':'23 WorkflowTransfer context errors because own runner lacked its hardcoded edhr DB login;107 positive tests not counted as an extra suite. Only owned DB role setup corrected, all130 rerun.','ui':{'cases':40,'passed':40,'widths':[1440,390],'api':'synthetic interception','liveBackend':False,'buildAndListContractPassed':True},'staticStrict':{'exit':2,'rawCandidates':86,'disposition':'pending diagnostics; no UI changes in repair; not86 proven product bugs'},'sourceSnapshots':len(fingerprints),'wholeFileCompletion':0,'historicalUniqueIncrement':None}
(stage/'primary-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
items=[]
for p in sorted(stage.rglob('*')):
 if p.is_file():b=p.read_bytes();items.append({'member':str(p.relative_to(stage)),'bytes':len(b),'sha256':sha(b)})
manifest={'sourceHeadDuringRuns':'7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37','rawArtifacts':items,'note':'Red snapshots match actual7c runtime; green snapshots identify uncommitted repaired source/test bytes. All initial environmental errors retained separately, not product red or unique passed coverage. Raw members distinguished from gzip archive bytes.'}
(stage/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');evidence=out/'evidence';evidence.mkdir(exist_ok=True);archive=evidence/'primary-and-ontology.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(stage.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(stage)),recursive=False)
manifest['archive']={'path':str(archive.relative_to(out)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())}
(out/'evidence-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rawArtifacts':len(items),'archive':manifest['archive'],'summary':summary},ensure_ascii=False))
