import hashlib,json,pathlib
p=pathlib.Path('/tmp/edhr-targets-final-qa-20261103/evidence-contract')
rows=[]
for f in sorted(p.rglob('*')):
    if f.is_file() and f != p/'manifest.json':
        b=f.read_bytes();rows.append({'path':f.relative_to(p).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
data={'status':'FINAL','result':'passed','artifactCount':len(rows),'artifacts':rows,'note':'Read-only independent evidence-contract subcheck; all archive copies are original bytes. Only this top-level manifest excludes itself; nested original manifests are included.'}
(p/'manifest.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'artifactCount':len(rows),'manifestSha256':hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()}))
