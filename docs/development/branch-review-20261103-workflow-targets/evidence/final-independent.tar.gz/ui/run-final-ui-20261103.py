import subprocess, pathlib, json, hashlib, tarfile, time, os
repo=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-targets-final-qa-20261103/ui')
out.mkdir(parents=True,exist_ok=True)
wt=pathlib.Path('/tmp/edhr-final-ui-wt-20261103')
commands=[]
def run(name,cmd,cwd=repo,env=None):
    start=time.time()
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.run(cmd,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT)
    commands.append(dict(id=name,command=cmd,cwd=str(cwd),exitCode=p.returncode,durationSeconds=round(time.time()-start,3)))
    (out/'commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
    print(name,p.returncode,flush=True)
    return p.returncode
run('baseline',['git','rev-parse','HEAD','origin/edhr-dev'])
run('main-status-before',['git','status','--porcelain=v1'])
if run('worktree-add',['git','worktree','add','--detach',str(wt),'1b4d5c2b1399b6203b5123f8650873d25909f3e5']):
    raise SystemExit('Cannot add own worktree')
f=wt/'gmp-platform/frontend'
(f/'node_modules').symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True)
run('tested-baseline',['git','rev-parse','HEAD','origin/edhr-dev'],wt)
run('frontend-diff',['git','diff','--name-status','7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37','HEAD','--','gmp-platform/frontend'],wt)
run('build',['npm','run','build'],f)
run('list-style',['npm','run','verify:list-table-style'],f)
env=os.environ.copy();env['WORKFLOW_LIST_ARTIFACTS']=str(out/'browser')
run('browser',['node','scripts/test-workflow-list-ui-browser.mjs'],f,env)
archive=repo/'docs/development/branch-review-20261103-workflow-targets/evidence/primary-and-ontology.tar.gz'
with tarfile.open(archive,'r:gz') as tf:
    data=tf.extractfile('tools/edhr-premium-audit-20261103.py').read()
script=out/'audit_project.py';script.write_bytes(data)
(out/'auditor-source.json').write_text(json.dumps({'source':'tools/edhr-premium-audit-20261103.py','archive':str(archive),'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'scriptSHA256':hashlib.sha256(data).hexdigest(),'tmpScriptSame':pathlib.Path('/tmp/edhr-premium-audit-20261103.py').read_bytes()==data},indent=2)+'\n')
run('premium-strict',['python3',str(script),str(wt),'--mode','strict','--output',str(out/'premium-audit.json')],wt)
paths=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','DESIGN.md','docs/frontend/list-page-guidelines.md','docs/frontend/dialog-guidelines.md','gmp-platform/frontend/src/App.tsx','gmp-platform/frontend/src/pages/workflow-center/InstanceList.tsx','gmp-platform/frontend/src/pages/record-control/RecordRequestListPage.tsx','gmp-platform/frontend/src/pages/record-control/RecordApprovalPage.tsx','gmp-platform/frontend/scripts/test-workflow-list-ui-browser.mjs','gmp-platform/frontend/scripts/verify-list-table-style-contract.mjs']
(out/'source-fingerprints.json').write_text(json.dumps([{'path':p,'sha256':hashlib.sha256((wt/p).read_bytes()).hexdigest()}for p in paths],indent=2)+'\n')
run('tested-status-with-tooling',['git','status','--porcelain=v1'],wt)
(f/'node_modules').unlink()
run('tested-status-after-tooling-cleanup',['git','status','--porcelain=v1'],wt)
run('worktree-remove',['git','worktree','remove',str(wt)])
run('main-status-after',['git','status','--porcelain=v1'])
run('resource-cleanup',['git','worktree','list','--porcelain'])
