# 独立 UI 分项 FINAL

本子项只读，候选 `1b4d5c2b1399b6203b5123f8650873d25909f3e5`，目标 `7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37`。自有 detached worktree `/tmp/edhr-final-ui-wt-20261103` 实跑后正常移除；frontend/node_modules 仅链接现有依赖，并先解除本链接。主工作树前后均 clean。未修改产品、测试、夹具或配置。

已读 AGENTS、质量角色与交接契约、知识 README/相关开放问题、DEC0093/0094、DESIGN、列表与弹窗规范，以及 frontend-design、frontend-design-premium、canonical-ui-resolution、verification-checklist、anti-patterns。应用类型是中文受控生产管理工具，不触发日本市场假定。DESIGN第10节明确列表规范优先，因此保留MUI既有色彩/布局，未为一般设计建议重设计。未创建/改写设计合同。一次 skill reference 读取返回暂时失败，随后同一 verification-checklist 及 anti-patterns 原资源读取成功；不是运行测试失败。

候选相对7c前端无差异。旧交付cd8至目标7c的frontend子树18路径包含14个src和4个scripts，不能混为18个产品源文件；本项运行覆盖维护的集中流程/记录控制组件，不声称对14src逐行完成。已核公共ListTableShell、DetailDrawer、AppDialog/FormDialog、SnackbarProvider、WorkflowReassignmentEntry及签署凭据组件的调用。当前DEC0093允许管理员签名改派普通表单/DHR，DHR本人转办仍禁止；DEC0094的认证候选读取不授予写入。本轮没有改变这两项政策。

实际构建包括tsc与Vite，exit0。列表脚本exit0，核35公共列表页、18样式入口、10可调列表、5RDO页和3个流程/记录控制组件图标动作。Chromium脚本40/40、0失败，两宽度1440/390；40最终态截图加8图标导航前截图共48 PNG。覆盖单/并行任务、无当前任务、已结束、加载失败重试、列表错误/空/加载、权限隐藏、未知业务类型、列偏好隔离、日志/干预详情区分、关闭重开刷新、记录控制导航、普通表单/DHR改派提交、领域审计。脚本用真实维护组件/主题/API客户端加合成拦截，未连接后台或写数据库。

实际查看7张截图。390加载失败重试后改派表单的输入、取消、禁用签署按钮均在视口内；390无任务弹窗提示与取消可见；390记录审批行右侧图标可见，内容区允许横向滚动；1440日志抽屉保持数据/审计页签；1440普通表单合成改派后成功反馈及列表可见；1440列表错误给出重试；390领域审计清楚列出前后责任、签署引用及原因。没有在这些有限代表图中发现本批交付阻断。

从候选原件包提取auditor并核其SHA与既有/tmp副本一致。独立strict实际exit2，86原始诊断候选=14 ownership未决+68 actionless模式+3 noValidate+1 scrollbar。14src增量中只有RecordRequestListPage第126行存在一个owner未决候选；这不是86个已证实bug，也未证明对应MUI Select当前不能使用。全仓UI合同和模式候选仍pending，留W6/W7，不宣称严格扫描通过。没有修改配置或界面让它变绿。

代表截图的观察与源码检索不能证明完整焦点/读屏/缩放/触屏/离线/多语言/真实签署。原用户暂停生产弹窗及朋友签署页保持。本子项FINAL passed仅指适用有限构建/交互检查，完整总体质量由父实例汇总。
