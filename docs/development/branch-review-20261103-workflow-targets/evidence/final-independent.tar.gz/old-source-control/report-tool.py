import pathlib,json,hashlib,yaml
root=pathlib.Path('/tmp/edhr-targets-final-qa-20261103/old-source-control')
run=json.loads((root/'attempt-02/run-state.json').read_text())
fp=json.loads((root/'attempt-02/source-fingerprints.json').read_text())
base=run['baseCommit'];head=run['candidateCommit'];test=run['testPath']
assert run['expectedNegativeControlReproduced'] and run['worktreeRemoved'] and run['containerRemoved'] and run['restoredWorktreeClean']
quality={'qualityResult':{
 'result':'passed','baseCommit':base,'headCommit':head,
 'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},
 'workingTreeState':{'status':'dirty','includedPaths':[test],'excludedPaths':['gmp-platform/frontend/node_modules (temporary read-only tooling symlink to main frontend/node_modules; removed after run)'],'untrackedPaths':[]},
 'knowledgeBaselineVersion':'0.3.25',
 'checks':[
  {'id':'check.old-control-source-integrity','required':True,'category':'regression','description':'Unchanged target7c products with exact candidate test bytes; only the 22-line added helper/two cases differ from base. This is an expected-red control, not execution of candidate products.','method':'inspection','command':'git worktree add --detach <own-worktree> '+base+'; byte-copy git show '+head+':'+test+'; git diff -- '+test,'outcome':'passed','evidence':['attempt-02/02-object-baselines.stdout','attempt-02/04-transplant-diff.stdout','attempt-02/05-pre-run-status.stdout','attempt-02/source-fingerprints.json','attempt-02/base-test.java','attempt-02/candidate-test.java']},
  {'id':'check.old-control-native-red','required':True,'category':'integration','description':'Two native full-application Spring/PostgreSQL cases both reproduce genuine missing-target assertion failures (expected43, actual[]), with zero context/compile/runtime errors and zero skips. Expected red is the success criterion of this check.','method':'automated-test','command':'PGUSER=postgres RECORD_CONTROL_TEST_DATABASE_URL=jdbc:postgresql://127.0.0.1:'+str(run['port'])+'/'+run['database']+' bash /workspace/.edhr-cloud-tools/mvn-edhr -f <own-worktree>/gmp-platform/backend/pom.xml -Dtest=RecordControlPostgresIntegrationTest#formReassignmentSearchQualifiesBeforeLimitingUsers+dhrReassignmentSearchQualifiesBeforeLimitingUsers test','outcome':'passed','evidence':['attempt-02/11-maven-negative.stdout','attempt-02/11-maven-negative.stderr','attempt-02/surefire-reports/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml','attempt-02/surefire-reports/com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.txt','attempt-02/run-state.json']},
  {'id':'check.old-control-real-migration-fixture','required':True,'category':'database','description':'Own postgres16.15, random loopback port32773, TCP-ready before creation, complete configured Liquibase migration applied11 changesets. Post-test SQL confirms121 target-scope users and eligible43 sorted last.','method':'query','command':'docker exec <own-container> psql -h127.0.0.1 -U postgres -d '+run['database']+' -v ON_ERROR_STOP=1 -c <database-state.sql>','outcome':'passed','evidence':['attempt-02/06-image.stdout','attempt-02/08-container-port.stdout','attempt-02/09-ready-2.stdout','attempt-02/10-create-record-db.stdout','attempt-02/database-state.sql','attempt-02/12-post-test-database-state.stdout','attempt-02/13-container-logs.stderr']},
  {'id':'check.old-control-resource-cleanup','required':True,'category':'documentation','description':'Only self-owned resources removed: own container absent, tool symlink removed, copied test restored to original7c bytes before normal clean worktree remove; main candidate remains clean.','method':'command','command':'restore own transplanted test from recorded7c bytes; unlink own node_modules symlink; git status --porcelain; git worktree remove <own-worktree>; docker rm -f <own-container>','outcome':'passed','evidence':['attempt-02/16-container-absence.stderr','attempt-02/17-restored-worktree-status.stdout','attempt-02/18-worktree-remove.stderr','attempt-02/19-final-main-status.stdout','attempt-02/run-state.json']}
 ],
 'findings':[],
 'residualRisks':[{'id':'residual.old-control-only','description':'This subrole executed only the two expected-red old-source cases; it did not execute candidate130, knowledge89, UI, complete record-control regression, full audit, CI or branch protection checks.','impact':'Cannot substitute for parent final independent candidate verification.','mitigation':'Parent QA runs applicable candidate checks separately and combines this finite control only.'}],
 'blockingConditions':[]},
 'negativeControl':{'testedProductCommit':base,'candidateTestCommit':head,'testSHA256':fp[test]['testedSHA256'],'expectedResult':{'tests':2,'failures':2,'errors':0,'skipped':0,'actualTargets':[],'expectedTargets':['43']},'actualResult':run['totals'],'testFailureType':'org.opentest4j.AssertionFailedError','cleanup':{'ownContainerRemoved':True,'ownWorktreeRestoredClean':True,'ownWorktreeRemoved':True},'environmentAttemptHistory':[{'attempt':'attempt-01-environment-failure','status':'environment-failure-not-product-red','cause':'Omitted node_modules tooling symlink; generate-resources vite not found exit127 before tests; no JUnit XML. Own resources cleaned.','resolution':'New own worktree/container; symlinked existing frontend node_modules without altering product/tests/fixture/config; reran original command.'},{'attempt':'attempt-02','status':'expected-real-assertion-red','tests':2,'failures':2,'errors':0,'skipped':0}]}}
(root/'result.yaml').write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False))
(root/'README.md').write_text('''# Independent old-source expected-red control — FINAL passed

Products tested: `7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37` in an own detached worktree. Only the exact candidate integration-test bytes were transplanted from `1b4d5c2b1399b6203b5123f8650873d25909f3e5`; diff contains22 added lines and no change to existing assertions. Three touched product files stayed byte-identical to7c, and the tracked diff contained only the one test path.

Actual native results: **2 tests,2 genuine assertion failures,0 errors,0 skips**. Both methods expected target43 and received an empty list. Full configured Liquibase ran11 changesets against own PostgreSQL16.15, loopback random port32773. SQL afterwards confirms121 matching users and target43 named `target-scope-Z`.

This expected red satisfies this negative-control check; it does not claim candidate products passed. Candidate130 and knowledge/UI acceptance belong to parent QA.

Initial attempt lacked the worktree node_modules tooling symlink: Maven generate-resources failed with vite not found (exit127), before JUnit. Those originals are preserved under `attempt-01-environment-failure` and are excluded from product-red counts. A new independent resource set with the tooling symlink then ran the unchanged command and original tests. No product/test/fixture/config repair was performed.

Own container and worktree removed; transplanted test restored first and normal `git worktree remove` used. Shared frontend node_modules was never removed or changed. Main worktree remained clean.

Preparatory read: an initial attempted path `docs/knowledge/evidence/record-control-authenticated-candidate-read-20261103.md` did not exist (sed exit2); `rg --files` located and original-read the authoritative `record-control-authenticated-candidate-read-confirmed.md` instead. Initial combined tool output was truncated; relevant contract sections, confirmation files and test boundary were reread separately, and exact full source snapshots are preserved under `read-sources` in both attempts.

All output paths are relative to this directory. `commands.json` in each attempt records exact arguments, timestamps, exit codes and explicit test DB env only. `runner.py` originals record orchestration. `result.yaml` carries the finite result and exact verification boundary.
''')
(root/'report-tool.py').write_bytes(pathlib.Path(__file__).read_bytes())
files=sorted(p for p in root.rglob('*') if p.is_file() and p.name!='manifest.sha256')
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in files)
(root/'manifest.sha256').write_text(manifest)
print(json.dumps({'result':'passed','rawFiles':len(files),'manifestSHA256':hashlib.sha256(manifest.encode()).hexdigest(),'resultPath':str(root/'result.yaml')},indent=2))
