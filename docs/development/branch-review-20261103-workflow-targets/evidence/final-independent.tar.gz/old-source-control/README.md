# Independent old-source expected-red control — FINAL passed

Products tested: `7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37` in an own detached worktree. Only the exact candidate integration-test bytes were transplanted from `1b4d5c2b1399b6203b5123f8650873d25909f3e5`; diff contains22 added lines and no change to existing assertions. Three touched product files stayed byte-identical to7c, and the tracked diff contained only the one test path.

Actual native results: **2 tests,2 genuine assertion failures,0 errors,0 skips**. Both methods expected target43 and received an empty list. Full configured Liquibase ran11 changesets against own PostgreSQL16.15, loopback random port32773. SQL afterwards confirms121 matching users and target43 named `target-scope-Z`.

This expected red satisfies this negative-control check; it does not claim candidate products passed. Candidate130 and knowledge/UI acceptance belong to parent QA.

Initial attempt lacked the worktree node_modules tooling symlink: Maven generate-resources failed with vite not found (exit127), before JUnit. Those originals are preserved under `attempt-01-environment-failure` and are excluded from product-red counts. A new independent resource set with the tooling symlink then ran the unchanged command and original tests. No product/test/fixture/config repair was performed.

Own container and worktree removed; transplanted test restored first and normal `git worktree remove` used. Shared frontend node_modules was never removed or changed. Main worktree remained clean.

Preparatory read: an initial attempted path `docs/knowledge/evidence/record-control-authenticated-candidate-read-20261103.md` did not exist (sed exit2); `rg --files` located and original-read the authoritative `record-control-authenticated-candidate-read-confirmed.md` instead. Initial combined tool output was truncated; relevant contract sections, confirmation files and test boundary were reread separately, and exact full source snapshots are preserved under `read-sources` in both attempts.

All output paths are relative to this directory. `commands.json` in each attempt records exact arguments, timestamps, exit codes and explicit test DB env only. `runner.py` originals record orchestration. `result.yaml` carries the finite result and exact verification boundary.
