import subprocess, pathlib, os, time, json, hashlib, shutil, datetime, xml.etree.ElementTree as ET

ROOT=pathlib.Path('/workspace/edhr-nexus-frontend')
OUT=pathlib.Path('/tmp/edhr-targets-final-qa-20261103/old-source-control/attempt-02')
BASE='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
HEAD='1b4d5c2b1399b6203b5123f8650873d25909f3e5'
TAG='negative_'+os.urandom(4).hex()
WT=pathlib.Path('/tmp/edhr-targets-'+TAG)
CONTAINER='edhr-targets-'+TAG.replace('_','-')
DB='edhr_record_control_test_'+TAG
TEST='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
PRODUCTS=['gmp-platform/backend/src/main/java/com/zencas/edhr/'+p for p in ['identity/service/TenantTransferTargets.java','production/service/FormWorkflowOperations.java','workflow/service/WorkflowResponsibilityService.java']]
OUT.mkdir(parents=True,exist_ok=True)
command_log=[]
def timestamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def cmd(name,args,cwd=ROOT,env=None,check=True):
    record={'name':name,'args':list(map(str,args)),'cwd':str(cwd),'started':timestamp()}
    if env: record['explicitEnvironment']={k:env[k] for k in ['RECORD_CONTROL_TEST_DATABASE_URL','PGUSER'] if k in env}
    with (OUT/(name+'.stdout')).open('wb') as stdout,(OUT/(name+'.stderr')).open('wb') as stderr:
        p=subprocess.run(list(map(str,args)),cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    record.update({'finished':timestamp(),'exitCode':p.returncode})
    command_log.append(record)
    (OUT/'commands.json').write_text(json.dumps(command_log,indent=2,ensure_ascii=False)+'\n')
    if check and p.returncode: raise RuntimeError(name+' exit '+str(p.returncode))
    return (OUT/(name+'.stdout')).read_bytes(),p.returncode
def gitbytes(commit,path): return subprocess.check_output(['git','show',commit+':'+path],cwd=ROOT)
def sha(data): return hashlib.sha256(data).hexdigest()

created=False;running=False;old_test=None
result={'phase':'starting','baseCommit':BASE,'candidateCommit':HEAD,'testPath':TEST,'worktree':str(WT),'container':CONTAINER,'database':DB,'started':timestamp()}
try:
    for path in ['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md','docs/knowledge/evidence/record-control-authenticated-candidate-read-confirmed.md','docs/development/branch-review-20261103-workflow-targets/decision-package.yaml']:
        dest=OUT/'read-sources'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(gitbytes(HEAD,path))
    cmd('01-main-baseline',['git','status','--porcelain=v1','--branch'])
    cmd('02-object-baselines',['git','rev-parse',BASE,HEAD,'origin/edhr-dev'])
    cmd('03-worktree-add',['git','worktree','add','--detach',str(WT),BASE]);created=True
    old_test=gitbytes(BASE,TEST);new_test=gitbytes(HEAD,TEST)
    (OUT/'base-test.java').write_bytes(old_test);(OUT/'candidate-test.java').write_bytes(new_test)
    (WT/TEST).write_bytes(new_test)
    node_modules=WT/'gmp-platform/frontend/node_modules'
    node_modules.symlink_to(ROOT/'gmp-platform/frontend/node_modules',target_is_directory=True)
    result['excludedToolingPaths']=[str(node_modules)]
    result['nodeModulesSymlinkTarget']=str(node_modules.resolve())
    cmd('04-transplant-diff',['git','diff','--',TEST],WT)
    cmd('05-pre-run-status',['git','status','--porcelain=v1'],WT)
    fingerprints={path:{'baseGitSHA256':sha(gitbytes(BASE,path)),'testedSHA256':sha((WT/path).read_bytes()),'unchanged':gitbytes(BASE,path)==(WT/path).read_bytes()} for path in PRODUCTS}
    fingerprints[TEST]={'baseGitSHA256':sha(old_test),'candidateGitSHA256':sha(new_test),'testedSHA256':sha((WT/TEST).read_bytes()),'candidateBytesIdentical':new_test==(WT/TEST).read_bytes()}
    (OUT/'source-fingerprints.json').write_text(json.dumps(fingerprints,indent=2)+'\n')
    assert all(fingerprints[p]['unchanged'] for p in PRODUCTS)
    assert fingerprints[TEST]['candidateBytesIdentical']
    cmd('06-image',['docker','image','inspect','postgres:16-alpine'])
    cmd('07-container-run',['docker','run','-d','--name',CONTAINER,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-p','127.0.0.1::5432','postgres:16-alpine']);running=True
    port_bytes,_=cmd('08-container-port',['docker','port',CONTAINER,'5432/tcp'])
    port=port_bytes.decode().strip().rsplit(':',1)[1];result['port']=int(port)
    ready=False
    for i in range(80):
        _,code=cmd('09-ready-'+str(i),['docker','exec',CONTAINER,'pg_isready','-h','127.0.0.1','-U','postgres'],check=False)
        if code==0: ready=True;break
        time.sleep(0.5)
    if not ready: raise RuntimeError('Own PostgreSQL never became TCP ready')
    cmd('10-create-record-db',['docker','exec',CONTAINER,'psql','-h','127.0.0.1','-U','postgres','-v','ON_ERROR_STOP=1','-c','CREATE DATABASE '+DB+' OWNER postgres'])
    env=os.environ.copy();env['PGUSER']='postgres';env['RECORD_CONTROL_TEST_DATABASE_URL']='jdbc:postgresql://127.0.0.1:'+port+'/'+DB
    selection='RecordControlPostgresIntegrationTest#formReassignmentSearchQualifiesBeforeLimitingUsers+dhrReassignmentSearchQualifiesBeforeLimitingUsers'
    result['phase']='maven-running';(OUT/'run-state.json').write_text(json.dumps(result,indent=2)+'\n')
    _,code=cmd('11-maven-negative',['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f',str(WT/'gmp-platform/backend/pom.xml'),'-Dtest='+selection,'test'],WT,env,check=False)
    result['mavenExitCode']=code
    reports=WT/'gmp-platform/backend/target/surefire-reports';target=OUT/'surefire-reports';target.mkdir()
    for src in reports.iterdir():
        if src.is_file():shutil.copy2(src,target/src.name)
    xmls=list(target.glob('TEST-*.xml')); totals={'tests':0,'failures':0,'errors':0,'skipped':0};case_results=[]
    for path in xmls:
        suite=ET.parse(path).getroot()
        for key in totals: totals[key]+=int(suite.attrib.get(key,'0'))
        for case in suite.findall('testcase'):
            f=case.find('failure');e=case.find('error');s=case.find('skipped')
            case_results.append({'name':case.attrib['name'],'classname':case.attrib['classname'],'failure':None if f is None else {'type':f.attrib.get('type'),'message':f.attrib.get('message'),'text':f.text},'error':None if e is None else {'message':e.attrib.get('message'),'text':e.text},'skipped':s is not None})
    result['totals']=totals;result['cases']=case_results
    expected_names={'formReassignmentSearchQualifiesBeforeLimitingUsers','dhrReassignmentSearchQualifiesBeforeLimitingUsers'}
    actual_names={case['name'] for case in case_results}
    result['expectedNegativeControlReproduced']=code!=0 and totals=={'tests':2,'failures':2,'errors':0,'skipped':0} and actual_names==expected_names and all(c['failure'] and '["43"]' in c['failure']['message'] and '[]' in c['failure']['message'] for c in case_results)
    query="SELECT current_database(),version(); SELECT count(*) AS applied_changesets FROM databasechangelog; SELECT count(*) AS target_scope_users FROM user_account WHERE display_name LIKE 'target-scope%'; SELECT id,display_name FROM user_account WHERE id=43;"
    (OUT/'database-state.sql').write_text(query+'\n')
    cmd('12-post-test-database-state',['docker','exec',CONTAINER,'psql','-h','127.0.0.1','-U','postgres','-d',DB,'-v','ON_ERROR_STOP=1','-c',query])
    result['phase']='done'
except Exception as error:
    result['phase']='runner-error';result['runnerError']=str(error)
finally:
    if running:
        cmd('13-container-logs',['docker','logs',CONTAINER],check=False)
        cmd('14-container-inspect',['docker','inspect',CONTAINER],check=False)
        cmd('15-container-remove',['docker','rm','-f',CONTAINER],check=False)
        _,code=cmd('16-container-absence',['docker','inspect',CONTAINER],check=False)
        result['containerRemoved']=code!=0
    if created:
        node_modules=WT/'gmp-platform/frontend/node_modules'
        if node_modules.is_symlink():node_modules.unlink()
        if old_test is not None:(WT/TEST).write_bytes(old_test)
        clean,code=cmd('17-restored-worktree-status',['git','status','--porcelain=v1'],WT,check=False)
        result['restoredWorktreeClean']=code==0 and not clean.strip()
        if result['restoredWorktreeClean']:
            _,code=cmd('18-worktree-remove',['git','worktree','remove',str(WT)],check=False);result['worktreeRemoved']=code==0
        else:result['worktreeRemoved']=False
    cmd('19-final-main-status',['git','status','--porcelain=v1','--branch'])
    result['finished']=timestamp();(OUT/'run-state.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    shutil.copy2(__file__,OUT/'runner.py')
print(json.dumps({k:v for k,v in result.items() if k!='cases'},indent=2))
