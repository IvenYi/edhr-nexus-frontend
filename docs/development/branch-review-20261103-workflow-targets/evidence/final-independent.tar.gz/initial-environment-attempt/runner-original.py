import subprocess,pathlib,os,json,time,uuid,datetime,hashlib,shutil,xml.etree.ElementTree as ET

OUT=pathlib.Path('/tmp/edhr-targets-final-qa-20261103'); OUT.mkdir(exist_ok=True)
ROOT=pathlib.Path('/workspace/edhr-nexus-frontend'); HEAD='1b4d5c2b1399b6203b5123f8650873d25909f3e5'; BASE='7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37'
SUFFIX=uuid.uuid4().hex[:10]; WT=pathlib.Path('/tmp/edhr-final-native-'+SUFFIX); NAME='edhr-final-native-'+SUFFIX; DB='edhr_record_control_test_final_'+SUFFIX
NATIVE=OUT/'native'; NATIVE.mkdir(exist_ok=True); KNOW=OUT/'knowledge'; KNOW.mkdir(exist_ok=True)
commands=[];created=False;worktree=False;err=None
def command(args,cwd=ROOT,env=None,check=True):
 r=subprocess.run(args,cwd=cwd,env=env,text=True,capture_output=True)
 commands.append({'argv':args,'cwd':str(cwd),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (OUT/'orchestration-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if check and r.returncode: raise RuntimeError('command failed '+repr(args)+' '+r.stderr)
 return r
def summarize(reportdir,dest,expected=None):
 classes=[]; totals={k:0 for k in ('tests','failures','errors','skipped')}; dest.mkdir(exist_ok=True)
 for f in sorted(reportdir.glob('TEST-*.xml')):
  shutil.copy2(f,dest/f.name); e=ET.parse(f).getroot(); n={k:int(e.attrib.get(k,0)) for k in totals};classes.append({'class':e.attrib['name'],**n})
  for k in totals: totals[k]+=n[k]
 result={'classes':classes,'totals':totals}; (dest.parent/'test-summary.json').write_text(json.dumps(result,indent=2)+'\n'); return result
try:
 command(['git','worktree','add','--detach',str(WT),HEAD]); worktree=True
 baseline={'source':command(['git','rev-parse','HEAD'],cwd=WT).stdout.strip(),'target':command(['git','rev-parse','origin/edhr-dev'],cwd=WT).stdout.strip(),'status':command(['git','status','--porcelain=v1'],cwd=WT).stdout,'worktree':str(WT),'base':BASE}
 (OUT/'baseline-start.json').write_text(json.dumps(baseline,indent=2)+'\n')
 diff=command(['git','diff',BASE,HEAD,'--','gmp-platform/backend/src/main','gmp-platform/backend/src/test'],cwd=WT).stdout
 (OUT/'product-test.diff').write_text(diff)
 paths=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java']
 snaps=[]
 for p in paths:
  data=(WT/p).read_bytes(); f=OUT/'source-snapshot'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data);snaps.append({'path':p,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 (OUT/'source-fingerprints.json').write_text(json.dumps(snaps,indent=2)+'\n')
 cid=command(['docker','run','--rm','-d','--name',NAME,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+DB,'-p','127.0.0.1::5432','postgres:16-alpine']).stdout.strip();created=True
 for _ in range(120):
  r=command(['docker','exec',NAME,'pg_isready','-h','127.0.0.1','-U','postgres'],check=False)
  if r.returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own PG TCP readiness timeout')
 command(['docker','exec',NAME,'psql','-U','postgres','-d',DB,'-v','ON_ERROR_STOP=1','-c','CREATE ROLE edhr LOGIN'])
 command(['docker','exec',NAME,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
 port=command(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',NAME]).stdout.strip()
 env=os.environ.copy();env.update(RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{DB}',PGUSER='postgres',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test')
 selected='RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest'
 nativecmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+selected,'test']
 knowcmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test']
 meta={'nativeCommand':nativecmd,'knowledgeCommand':knowcmd,'worktree':str(WT),'head':HEAD,'target':BASE,'database':env['RECORD_CONTROL_TEST_DATABASE_URL'],'transferDatabase':env['W3_TRANSFER_DATABASE_URL'],'container':NAME,'containerId':cid,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 (OUT/'run-start.json').write_text(json.dumps(meta,indent=2)+'\n')
 with (NATIVE/'maven.log').open('w') as nlog,(KNOW/'maven.log').open('w') as klog:
  nativeproc=subprocess.Popen(nativecmd,cwd=WT,env=env,stdout=nlog,stderr=subprocess.STDOUT)
  knowproc=subprocess.Popen(knowcmd,cwd=WT,stdout=klog,stderr=subprocess.STDOUT)
  nc=nativeproc.wait();kc=knowproc.wait()
 meta.update(nativeExitCode=nc,knowledgeExitCode=kc,finished=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (OUT/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
 ns=summarize(WT/'gmp-platform/backend/target/surefire-reports',NATIVE/'surefire')
 ks=summarize(WT/'tools/knowledge-model/target/surefire-reports',KNOW/'surefire')
 for db in [DB,'edhr_w3_transfer_test']:
  r=command(['docker','exec',NAME,'psql','-U','postgres','-d',db,'-X','-Atc',"SELECT current_database(),version(); SELECT count(*),count(DISTINCT id) FROM databasechangelog; SELECT datname,pg_get_userbyid(datdba) FROM pg_database WHERE datname=current_database();"],check=False)
  (NATIVE/('database-'+db+'.txt')).write_text(r.stdout+r.stderr)
 print(json.dumps({'native':ns,'knowledge':ks,'exitCodes':[nc,kc]}),flush=True)
 if nc or kc: raise RuntimeError('test process failed; inspect raw logs')
 if ns['totals']!={'tests':130,'failures':0,'errors':0,'skipped':0}:raise RuntimeError('native unexpected totals')
 if ks['totals']!={'tests':89,'failures':0,'errors':0,'skipped':0}:raise RuntimeError('knowledge unexpected totals')
except BaseException as e:
 err=repr(e);(OUT/'orchestration-error.txt').write_text(err+'\n');print(err,flush=True)
finally:
 cleanup={}
 if created:
  r=command(['docker','logs',NAME],check=False);(NATIVE/'postgres.log').write_text(r.stdout+r.stderr)
  r=command(['docker','stop',NAME],check=False);cleanup['stopExitCode']=r.returncode
  for _ in range(40):
   r=command(['docker','inspect',NAME],check=False)
   if r.returncode:break
   time.sleep(.1)
  cleanup['ownedContainerRemoved']=r.returncode!=0
 if worktree:
  status=command(['git','status','--porcelain=v1'],cwd=WT,check=False).stdout;cleanup['worktreeStatusBeforeRemove']=status
  if not status:
   r=command(['git','worktree','remove',str(WT)],check=False);cleanup['normalWorktreeRemoveExitCode']=r.returncode
  else:cleanup['retainedDirtyWorktree']=str(WT)
 cleanup['mainStatus']=command(['git','status','--porcelain=v1']).stdout;cleanup['mainHead']=command(['git','rev-parse','HEAD']).stdout.strip()
 (OUT/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
 print(json.dumps({'cleanup':cleanup,'error':err}),flush=True)
if err:raise SystemExit(1)
