from pathlib import Path
import json,hashlib,subprocess as sp,yaml,datetime,gzip
repo=Path('/workspace/edhr-nexus-frontend');p=Path('/tmp/edhr-dhr-combined-qa')
base='e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae';head='5cb1636a23e09342b2d218bb986217a4325ea559'
def read(name):return json.loads(Path(str(p)+'-'+name+'.json').read_text())
def artifact(name):return str(p)+'-'+name
def command(args):
    r=sp.run(args,cwd=repo,text=True,capture_output=True)
    return {'cmd':args,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
main=read('main-summary');cap=read('capacity-summary');knowledge=read('knowledge-summary');old=read('old-summary')
for result,expected in [(main,127),(cap,1),(knowledge,89)]:
    assert result['exit']==0 and result['totals']=={'tests':expected,'failures':0,'errors':0,'skipped':0} and not result['missingFreshSuites']
assert old['exit']==1 and old['totals']=={'tests':5,'failures':3,'errors':0,'skipped':0} and not old['missingFreshSuites']
for t in old['suites'][0]['testcases']:
    assert not t['error']
    assert bool(t['failure']) == (not t['name'].startswith('createCollision'))
copied=read('old-source-copy');assert copied['source']==copied['copy'];assert copied['productSha256']==copied['productBaseSha256']
comparison=read('comparison');assert comparison['result']=='passed'
src=read('source-review');ev=read('evidence-review')
assert src['qualityResult']['result']=='passed' and ev['summary']['result']=='passed' and ev['summary']['allChecksPassed']
cleanup=read('cleanup')
assert cleanup[-1]['mainHead']==head and cleanup[-1]['mainStatus']==''
for item in cleanup[:-1]:
    if 'stopExit' in item:assert item['stopExit']==item['removeExit']==0
    else:assert item['exit']==0 and item['statusBeforeRemove']==''
commands=[command(['git','rev-parse','HEAD']),command(['git','status','--porcelain=v1']),command(['git','rev-parse','refs/remotes/origin/edhr-dev']),command(['git','-c','core.whitespace=cr-at-eol','diff','--check',base+'..'+head]),command(['git','diff','--name-only',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture/business-knowledge-model.md'])]
assert all(c['exit']==0 for c in commands)
assert commands[0]['stdout'].strip()==head and commands[1]['stdout']=='' and commands[2]['stdout'].strip()==base and commands[4]['stdout']==''
Path(artifact('final-commands.json')).write_text(json.dumps(commands,indent=2)+'\n')
task='docs/development/branch-review-20261102-dhr-attachment-write/'
stream=json.loads((repo/task/'stream-evidence-manifest.json').read_text())
snaps=[]
for item in stream['sourceSnapshot']:
    raw=(repo/item['path']).read_bytes();snap={'path':item['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()};assert snap==item;snaps.append(snap)
Path(artifact('final-sourceSnapshot.json')).write_text(json.dumps({'sourceCommit':head,'sourceSnapshot':snaps,'additionalRuntimePomSnapshot':read('sourceSnapshot')[-1]},indent=2)+'\n')
checks=[]
def check(id,category,description,method,cmd,evidence):checks.append({'id':id,'required':True,'category':category,'description':description,'method':method,'command':cmd,'outcome':'passed','evidence':evidence})
check('check.scope-contract-baseline','requirements','L2已确认范围、实际候选、契约及0.3.25知识基线独立核对；仅DhrAttachmentService产品变更。','inspection','Read AGENTS.md, codeplzreadme.md, docs/agents/{agent-handoff-contract,quality-verifier}.md, business model, knowledge README/open questions, DEC0063 and original attachment confirmation; git diff '+base+'..'+head,[artifact('source-review.json'),artifact('start.json'),artifact('final-commands.json'),'base='+base+'; feature/tested candidate='+head+'; contractReadCommit='+head+'; current tracked tree clean; no contract/knowledge delta'])
check('check.source-behavior-and-a23','audit','独立源码核验写关IO所有权补偿/碰撞/suppressed/日志、完整流式SHA先于输出、原错误及SQL/UI保持；Summary/Archive/Review传递调用与有限A23/拆分边界。','inspection','Source inspection and typed-call/method/SQL parity searches; 6 source-review checks',[artifact('source-review.json'),artifact('source-review.md'),'CREATE_NEW open outside compensation catch; upload/file only original methods changed plus private Path SHA helper; verify byte[] and original 8KiB upload preserved','No new framework/guard/index/query reuse; source typed upload only injected Controller is a finite exclusion, not dynamic/future/deployment entrypoint certification'])
check('check.combined-regression-127','regression','当前精确组合17类127执行，全部freshXML且0F/E/S；包含真实PG事务、27项相邻DHR及已有文件边界/权限回归。','automated-test',' '.join(read('main-command')['cmd']),[artifact('main-command.json'),artifact('main-summary.json'),artifact('main-test.txt'),'17 fresh XMLs at '+artifact('main-<Class>.xml'),'Archive13 actual Chromium PDF elapsed70.890s passed; other browser dependency warnings retained without product/environment changes','Counts are 127 total = new5 + existing122, not additive unique full-audit coverage'])
check('check.owned-postgres-environment','database','本实例专有PG16-alpine只绑定loopback trust；最终TCP pg_isready -h127.0.0.1，两个专用库，实际原生事务回归非skip。','query','docker run postgres:16-alpine; pg_isready -h 127.0.0.1; createdb -h 127.0.0.1; SELECT version(); SELECT datcollate FROM pg_database',[artifact('database.json'),artifact('main-DhrAttachmentTransactionPostgresTest.xml'),'PostgreSQL16.15 en_US.utf8; DHR transaction11 and upload/delete native PG tests passed; metadata read from pg_database'])
check('check.capacity-combined-one','integration','容量单项0F/E/S，12组84请求；42次完整52428800字节/SHA/filename/attachment/contentType/nosniff，42损坏输出前拒绝。','automated-test',' '.join(read('capacity-command')['cmd']),[artifact('capacity-command.json'),artifact('capacity-summary.json'),artifact('capacity-DhrAttachmentDownloadCapacityPostgresTest.xml'),artifact('capacity-test.txt'),artifact('capacity/capacity.json'),'2GiB test JVM; current/frozen × good/corrupt × concurrency1/4/16; 1 test method, not84 business cases'])
check('check.capacity-jfr-baseline-comparison','integration','本实例重解析before/after各12JFR并逐请求核SQL/输出/分配；初601独立before原件复用，未声称本实例重跑before。','command','python3 /tmp/edhr-dhr-combined-qa-baseline-extract.py; java /tmp/edhr-dhr-combined-qa-JfrReads.java <12beforeJFR>; python3 /tmp/edhr-dhr-combined-qa-compare.py',[artifact('comparison.json'),artifact('baseline-extract.json'),artifact('baseline-jfr-reparsed.jsonl'),artifact('after-jfr-reparsed.jsonl'),artifact('after-jfr-command.json'),'Exact SQL arrays unchanged: current/frozen good5/6, bad4/5. JFR logical read good100MiB/bad50MiB per request. Later allocation about0.093–0.227MiB except first current2.053/frozen0.529MiB initialization; concurrency16 sampledheap3–5MiB vs independent old818–821MiB; no exact heap/latency threshold'])
check('check.knowledge-89','ontology','当前组合实际独立知识JUnit89，0F/E/S；330知识资产和6模型/契约文件与base无差异，本体not-applicable适用。','automated-test',' '.join(read('knowledge-command')['cmd']),[artifact('knowledge-command.json'),artifact('knowledge-summary.json'),artifact('knowledge-BusinessKnowledgeModelTest.xml'),artifact('knowledge-test.txt'),artifact('evidence-review.json'),'knowledge0.3.25/schema1.2.0; no maturity or whole-audit completion increase'])
check('check.exact-final-old-negative-control','unit','own detached e3旧产品仅复制HEAD精确最终故障测试，5执行=3真实assertion红+2碰撞正控，0error/skip。','automated-test',' '.join(read('old-command')['cmd']),[artifact('old-source-copy.json'),artifact('old-command.json'),artifact('old-summary.json'),artifact('old-DhrAttachmentWriteFailureTest.xml'),artifact('old-test.txt'),'Test source/copy7002B SHA2566088d5bb120f1800da70d8542a16278a625f6efd5ea233c8b5e753013b81c69f. Old productSHA equals e3. Failures are retained fragment/absent suppressed, not fixture setup. Expected red command exit1 is a passed reproduction check; repeated history stages not additive'])
check('check.three-stage-artifacts','documentation','原始/存储/member哈希与阶段源码映射全核，保留fixture-first及中间/精确旧控区别。','command','python3 /tmp/edhr-dhr-combined-qa-evidence-verify.py (final corrected schema-aware verifier); inspect raw artifacts and Git source bytes',[artifact('evidence-review.json'),artifact('evidence-review.md'),'1321 mechanical checks passed. old87raw+5source vs601; stream68raw+5source vscurrent/same320; initialbundle114 members plus embedded113artifact manifest vs601; old ontology12+manifest13/25fingerprints SHA470b0b8adaa2b9e4eb30dd05b0950ced70a4948463919142b6a044b88c4671a2; stream13+manifest14/27 SHA129e5867b99befc3269a03944934d11ae865e779e56f30c2e36c5a22dfe18b7c','Temporary verifier KeyError for optional baseSha256 and source regex first parser correction retained under /tmp; no repo/test/fixture/config changes or reduced assertions'])
check('check.fixed-inventory-and-review-counts','documentation','从固定e3重建四盘点并逐字节对比；不把盘点及机械校验冒称语义全审。','command','Rebuild four task inventory artifacts from git '+base+' and compare byte-for-byte',[artifact('evidence-review.json'),'6604paths/135SQL/464HTTP annotation candidates/216route candidates; four outputs byte-identical; wholeFileCompletion0; historicalUniqueCoverageunknown;14existingIDs retained, no unique increment'])
check('check.clean-diff-and-owned-cleanup','documentation','临时命令级CRLF whitespace检查通过；所有own资源正常清理，主树clean且HEAD不变。','command','git -c core.whitespace=cr-at-eol diff --check '+base+'..'+head+'; docker stop/rm own container; unlink own tooling symlink; git worktree remove own clean trees; git status --porcelain=v1',[artifact('cleanup.json'),artifact('final-commands.json'),'No force/global git config/product/test/fixture/config edits/CI or Actions queries/merge/deploy/history restore/orphan sweep. Tooling-only frontend/node_modules symlink used in both detached trees, then unlinked'])
risks=[
 {'id':'risk.remaining-write-reconciliation','description':'进程崩溃、清理失败及UNKNOWN结果仍可能保留原件；本次进程内补偿不提供持久对账或跨资源原子。','impact':'本次修复只闭合已取得流后的写关IOException，未确认的崩溃/幂等/持久对账仍留原队列。','mitigation':'保留ID/path与原异常；按既有W6/W7队列进一步核验，不做恢复或孤儿扫删。'},
 {'id':'risk.capacity-observation-limits','description':'2GiB测试JVM、暖页缓存/稀疏paddedPNG、Hikari10、未全预热JIT与64KiB输出缓冲；包含JDBC/断言/JFR采样开销。','impact':'heap不含native/direct/RSS/network；JFR逻辑读取不是物理磁盘IO；无生产SLA/并发上限/单请求更快承诺。','mitigation':'报告原始数值和环境，不固定精确heap/latency阈值；仅确认摘要阶段内存有界和既有输出兼容。'},
 {'id':'risk.finite-runtime-boundary','description':'此次进程内Controller/resource、既有MockMvc/权限回归及有限相邻27DHR用例，不是完整真实HTTP/RBAC、账号UI收件人矩阵或全部冻结业务流程。','impact':'动态/未来/部署入口、全局ACL/引用并发及完整任务下载认证未在此认证。','mitigation':'当前typed源码无无事务内部upload仅作为有限排除，保留原guard；继续原授权队列。'},
 {'id':'risk.full-audit-queues-retained','description':'本批不是W0→W7全审完成；原666paths/44knowledge/183ID、两DHR旧high、A12、fourgap、W2余项、W3/W4/W5交叉、W6健壮性/性能/抽取/A23含旧已审重核、W7增量及朋友签署页/生产弹窗等暂停均保持。','impact':'不得把本组合passed提升为全系统/全语义通过或关闭旧高风险项。','mitigation':'主角色在所有FINAL后实际向用户复核授权扩展/无漂移/阶段，再执行L0归档PR交付；人工merge，不部署。'}]
result={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':head,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':risks,'blockingConditions':[]}}
Path(artifact('quality-result.yaml')).write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=120))
report=[
 'FINAL：L2组合候选独立质量验证 passed，无本批发现、无阻塞。验证区间 '+base+' → '+head+'；实际契约读取提交为当前HEAD，知识0.3.25/schema1.2.0，主树clean。质量实例及两个只读下属均未参与产品、测试、夹具或配置修复，两个下属已FINAL。',
 '实际执行为17类127回归、知识89及单独容量1，均0F/E/S且fresh XML完整。Archive13实际Chromium PDF通过（70.890秒）；其他browser缺库警告保留，不改环境/业务。原生PG16.15/en_US.utf8容器仅loopback trust，最终readiness使用pg_isready -h127.0.0.1，metadata查询pg_database.datcollate。两个专用库及所有命令/源码指纹均留存。',
 'own detached e3只复制HEAD精确最终故障测试，源/副本SHA相同（6088d5bb120f1800da70d8542a16278a625f6efd5ea233c8b5e753013b81c69f），旧产品字节与e3相同；5执行=3真正断言红（残片与suppressed）+2碰撞正控，0error/skip。旧Maven exit1是预期负控结果；首夹具错误、中间旧控、精确旧控与本次旧控不重复累加业务覆盖。',
 '容量单项含12组84请求，不是84独立业务用例。42请求完整输出52428800字节并核SHA、文件名、attachment、ContentType及nosniff；42损坏请求在响应体前拒绝。所有before/after JFR由本实例自写RecordingFile解析器重读，SQL数组逐请求一致：当前/冻结good5/6、bad4/5，逻辑读取good100MiB/bad50MiB每请求。',
 'before复用初601另一独立QA已封存合格原件，并重新核archive member SHA与12JFR；本实例没有重跑before。after由本实例在当前精确组合执行。后续分配约0.093–0.227MiB，首次current2.053MiB及首次frozen0.529MiB含初始化；16并发本次采样heap3–5MiB，旧独立基线约818–821MiB。原始每组值见comparison.json，未硬定heap/latency阈值。'+comparison['interpretation'],
 '源码独立核对为CREATE_NEW成功取得流才清理当前写关IOException，创建碰撞保护既有文件/目录；清理失败suppressed+ID/path保留原错误，仍失败且不登记/LINK。file()以私有8KiB Path摘要完整比较后返回原路径，verify解析byte[]、原helper/错误文本、Controller/UI/SQL/资格/核验/unlink历史/冻结成员/事务回调保持。Summary附件集合/提交核验、Archive取原件和Review任务下载均已追踪，有限27相邻DHR回归不冒称全链路认证。A23和具体拆分边界见source-review，不新增假设guard/全局框架/索引/查询复用。',
 '三阶段证据1321项机械检查均通过：旧87raw+5源码对应601，新68raw+5对应当前且源码同320，初QA114成员包及内113原manifest全核；旧本体12+manifest13/25指纹、新13+manifest14/27指纹均通过，330知识+6模型契约无差异，14既有ID不加unique。四盘点从e3重建逐字节一致6604/135SQL/464HTTP/216routes，wholeFile0、历史unique未知。旧601通过只解释初阶段，不认证新stream组合。',
 '所有自有容器与两个工作树已正常stop/rm/remove；工具依赖只链接对应frontend/node_modules，清理时unlink，无force。主树HEAD未变且clean，CRLF CSV只用命令级git -c core.whitespace=cr-at-eol diff --check，通过且未改原字节。/tmp编排首KeyError及源解析首regex误计原件保留，均不属产品红，不改测试或降低标准。',
 '本批不是全审完成。崩溃/清理失败/UNKNOWN持久对账、原666paths/44knowledge/183ID、两DHR旧high/A12/fourgap、完整账号UI收件人/ACL引用并发、朋友签署页与生产弹窗暂停及其余W0–W7原队列均保留。无真实HTTP/RBAC/生产SLA/全部冻结流程认证，无CI/Actions查询触发，无merge/deploy/历史恢复/孤儿扫删。所有正式角色FINAL后由主角色实际向用户做授权扩展/无漂移/阶段复核，再L0归档PR；人工merge。',
 '正式结构化结果：'+artifact('quality-result.yaml')+'；运行摘要：'+artifact('main-summary.json')+'、'+artifact('capacity-summary.json')+'、'+artifact('knowledge-summary.json')+'、'+artifact('old-summary.json')+'；源码/证据分项：'+artifact('source-review.json')+'、'+artifact('evidence-review.json')+'；完整rawbytes/hash总manifest：'+artifact('manifest.json')+'。'
]
Path(artifact('report.md')).write_text('\n\n'.join(report)+'\n')
# Validate required handoff fields and enums without changing repository tests.
q=yaml.safe_load(Path(artifact('quality-result.yaml')).read_text())['qualityResult']
assert set(q)=={'result','baseCommit','headCommit','contractBaseline','workingTreeState','knowledgeBaselineVersion','checks','findings','residualRisks','blockingConditions'}
assert q['result']=='passed' and all(c['required'] and c['outcome']=='passed' for c in q['checks']) and q['blockingConditions']==[] and q['findings']==[]
for c in q['checks']:
    assert set(c)=={'id','required','category','description','method','command','outcome','evidence'}
    assert c['category'] in ['requirements','ontology','unit','integration','api','database','audit','security','e2e','visual','regression','documentation']
    assert c['method'] in ['command','inspection','browser','query','automated-test']
manifest=Path(artifact('manifest.json'));entries=[]
for path in sorted(Path('/tmp').glob('edhr-dhr-combined-qa*')):
    candidates=sorted(path.rglob('*')) if path.is_dir() else [path]
    for f in candidates:
        if not f.is_file() or f==manifest:continue
        raw=f.read_bytes();compression='none';stored=raw
        if f.suffix=='.gz':
            try:raw=gzip.decompress(stored);compression='gzip'
            except (gzip.BadGzipFile,EOFError):pass
        entries.append({'path':str(f),'rawBytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'storedBytes':len(stored),'storedSha256':hashlib.sha256(stored).hexdigest(),'compression':compression})
manifest.write_text(json.dumps({'status':'FINAL','baseCommit':base,'headCommit':head,'qualityResult':'passed','createdAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifactCount':len(entries),'artifacts':entries,'selfExcluded':True},indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'qualityResult':'passed','checks':len(checks),'artifactCount':len(entries),'manifestSha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'head':head,'clean':True},indent=2))
