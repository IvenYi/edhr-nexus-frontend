from pathlib import Path
import collections, csv, datetime, gzip, hashlib, json, subprocess, tarfile, xml.etree.ElementTree as ET

ROOT=Path('/workspace/edhr-nexus-frontend')
PKG=ROOT/'docs/development/branch-review-20261102-dhr-attachment-write'
BASE='e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
OLD='6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'
STREAM='320a4c74717dd913d44d6e01e6c5a6f2993d4695'
HEAD='5cb1636a23e09342b2d218bb986217a4325ea559'
PREFIX=Path('/tmp/edhr-dhr-combined-qa-evidence')
checks=[]; commands=[]; decoded={}
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=ROOT,stderr=subprocess.DEVNULL)
def fact(kind,path,passed=True,**kw):
    r={'kind':kind,'path':str(path),'passed':passed,**kw};checks.append(r)
    assert passed, r
def dump(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def raw_artifact(item):
    stored=(PKG/item['path']).read_bytes()
    raw=gzip.decompress(stored) if item['compression']=='gzip' else stored
    original=Path(item['sourcePath'])
    fact('raw-stored-provenance',item['path'],len(stored)==item['storedBytes'] and sha(stored)==item['storedSha256'] and len(raw)==item['rawBytes'] and sha(raw)==item['rawSha256'],rawBytes=len(raw),rawSha256=sha(raw),storedBytes=len(stored),storedSha256=sha(stored),sourcePath=str(original))
    if original.exists():fact('retained-original',original,raw==original.read_bytes(),rawSha256=sha(raw))
    decoded[item['sourcePath']]=raw
    return raw

assert git('status','--porcelain')==b'' and git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','origin/edhr-dev').decode().strip()==BASE
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md']
for p in contracts:fact('actual-contract-baseline',p,(ROOT/p).read_bytes()==git('show',HEAD+':'+p)==git('show',BASE+':'+p),bytes=len((ROOT/p).read_bytes()),sha256=sha((ROOT/p).read_bytes()))

inv=Path(str(PREFIX)+'-inventory-attempt2');assert not inv.exists()
generator=ROOT/'scripts/build-branch-review-inventory.py'
assert generator.read_bytes()==git('show',BASE+':scripts/build-branch-review-inventory.py')
argv=['python3',str(generator),'--ref',BASE,'--out',str(inv)]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=subprocess.run(argv,cwd=ROOT,capture_output=True)
Path(str(PREFIX)+'-inventory-attempt2-stdout.txt').write_bytes(r.stdout);Path(str(PREFIX)+'-inventory-attempt2-stderr.txt').write_bytes(r.stderr)
commands.append({'argv':argv,'cwd':str(ROOT),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'stdout':str(PREFIX)+'-inventory-attempt2-stdout.txt','stderr':str(PREFIX)+'-inventory-attempt2-stderr.txt'})
assert r.returncode==0
for name in ['coverage.csv','entrypoints.csv','migrations.csv','inventory-summary.json']:
    b=(inv/name).read_bytes();fact('rebuilt-inventory',name,b==(PKG/'inventory'/name).read_bytes(),rawBytes=len(b),rawSha256=sha(b))
inventory=json.loads((inv/'inventory-summary.json').read_bytes())
assert inventory['sourceCommit']==BASE and inventory['trackedPaths']==6604 and inventory['migrationFiles']==135 and inventory['entrypointCandidates']['http-annotation']==464 and inventory['entrypointCandidates']['frontend-route-candidate']==216 and inventory['semanticReviewComplete'] is False
rows=list(csv.DictReader((inv/'coverage.csv').open()))
assert len(rows)==6604 and all(x['review_depth']=='inventory-only' and x['review_status']=='pending' for x in rows)
assert {r['path'] for r in rows}=={p.decode() for p in git('ls-tree','-rz','--name-only',BASE).split(b'\0') if p}

manifests={}
for name,commit,count in [('evidence-manifest.json',OLD,87),('stream-evidence-manifest.json',HEAD,68)]:
    data=json.loads((PKG/name).read_bytes());manifests[name]=data
    assert data['baseCommit']==BASE and len(data['artifacts'])==count and len(data['sourceSnapshot'])==5
    for item in data['artifacts']:raw_artifact(item)
    for item in data['sourceSnapshot']:
        b=git('show',commit+':'+item['path'])
        fact('source-snapshot-'+commit[:8],item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'],bytes=len(b),sha256=sha(b),comparisonCommit=commit,currentMatches=b==(ROOT/item['path']).read_bytes())
        if commit==HEAD:fact('current-source-working-tree',item['path'],b==(ROOT/item['path']).read_bytes())
    if commit==HEAD:
        for item in data['sourceSnapshot']:
            if '/src/' in item['path']:fact('stream-product-tests-match-cherry-pick',item['path'],git('show',STREAM+':'+item['path'])==git('show',HEAD+':'+item['path']))

bundle_mapping=json.loads((PKG/'initial-quality-manifest.json').read_bytes())
bundle=(PKG/bundle_mapping['bundle']).read_bytes()
fact('initial-independent-bundle',bundle_mapping['bundle'],len(bundle)==bundle_mapping['storedBytes'] and sha(bundle)==bundle_mapping['storedSha256'],storedBytes=len(bundle),storedSha256=sha(bundle))
assert bundle_mapping['baseCommit']==BASE and bundle_mapping['headCommit']==OLD and len(bundle_mapping['members'])==114
with tarfile.open(PKG/bundle_mapping['bundle'],'r:gz') as tf:
    members={x.name:tf.extractfile(x).read() for x in tf.getmembers() if x.isfile()}
assert set(members)=={x['member'] for x in bundle_mapping['members']}
for item in bundle_mapping['members']:
    b=members[item['member']];fact('initial-independent-member',item['member'],len(b)==item['rawBytes'] and sha(b)==item['rawSha256'],rawBytes=len(b),rawSha256=sha(b))
old_qa_manifest=json.loads(members['edhr-dhr-write-qa-manifest.json'])
assert old_qa_manifest['artifactCount']==113 and old_qa_manifest['headCommit']==OLD and old_qa_manifest['baseCommit']==BASE
assert members['edhr-dhr-write-qa-manifest.json']==(PKG/'evidence/initial-quality/edhr-dhr-write-qa-manifest.json').read_bytes()
assert {x['sourcePath'] for x in bundle_mapping['members'] if x['member']!='edhr-dhr-write-qa-manifest.json'}=={x['path'] for x in old_qa_manifest['artifacts']}
for item in old_qa_manifest['artifacts']:
    mapping=next(x for x in bundle_mapping['members'] if x['sourcePath']==item['path']);b=members[mapping['member']]
    fact('initial-independent-internal-manifest',mapping['member'],len(b)==item['rawBytes'] and sha(b)==item['sha256'])
for name in ['edhr-dhr-write-qa-report.md','edhr-dhr-write-qa-quality-result.yaml']:
    fact('initial-independent-report-original',name,members[name]==(PKG/'evidence/initial-quality'/name).read_bytes())

ontology=[]
for label,ontoprefix,source_commit,stage_commit,expected_count,expected_sha in [('old','edhr-dhr-write-ontology',BASE,OLD,25,'470b0b8adaa2b9e4eb30dd05b0950ced70a4948463919142b6a044b88c4671a2'),('stream','edhr-dhr-stream-ontology',STREAM,HEAD,27,'129e5867b99befc3269a03944934d11ae865e779e56f30c2e36c5a22dfe18b7c')]:
    manifest_raw=decoded['/tmp/'+ontoprefix+'-manifest.json'];data=json.loads(manifest_raw)
    fact('ontology-manifest',label,sha(manifest_raw)==expected_sha and data['status']=='FINAL',sha256=sha(manifest_raw),entries=len(data['files']))
    assert len(data['files'])==(12 if label=='old' else 13)
    for item in data['files']:
        b=decoded[item['path']];fact('ontology-entry',item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'],rawBytes=len(b),rawSha256=sha(b))
    fingerprints=json.loads(decoded['/tmp/'+ontoprefix+'-source-fingerprints.json']);assert len(fingerprints['files'])==expected_count
    for item in fingerprints['files']:
        b=git('show',stage_commit+':'+item['path'])
        try:source=git('show',source_commit+':'+item['path'])
        except subprocess.CalledProcessError:source=None
        fact('ontology-source-'+label,item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'] and (b==source)==item['matchesSourceCommit'],bytes=len(b),sha256=sha(b),stageCommit=stage_commit,matchesSourceCommit=b==source,sourceCommit=source_commit)
    knowledge=json.loads(decoded['/tmp/'+ontoprefix+'-knowledge-inventory.json'])
    assert knowledge['knowledgeFileCount']==330 and len(knowledge['knowledge'])==330 and len(knowledge['businessModelAndContracts'])==6 and knowledge['knowledgeModelVersion']=='0.3.25' and knowledge['schemaVersion']=='1.2.0'
    paths={x['path'] for x in knowledge['knowledge']}
    assert paths=={x.decode() for x in git('ls-tree','-rz','--name-only',BASE,'docs/knowledge').split(b'\0') if x}=={x.decode() for x in git('ls-tree','-rz','--name-only',HEAD,'docs/knowledge').split(b'\0') if x}
    for item in knowledge['knowledge']+knowledge['businessModelAndContracts']:
        b=(ROOT/item['path']).read_bytes();base_b=git('show',BASE+':'+item['path'])
        fact('knowledge-contract-'+label,item['path'],len(b)==item['bytes'] and sha(b)==item['sha256'] and ('baseSha256' not in item or sha(base_b)==item['baseSha256']) and item['matchesBase'] is True and b==base_b==git('show',HEAD+':'+item['path']),bytes=len(b),sha256=sha(b),actualBaseSha256=sha(base_b),recordedBaseSha256=item.get('baseSha256'))
    result=decoded['/tmp/'+ontoprefix+'-result.yaml'].decode()
    assert 'result: not-applicable' in result and 'baselineBefore: 0.3.25' in result and 'baselineAfter: 0.3.25' in result
    ontology.append({'stage':label,'manifestSha256':sha(manifest_raw),'entries':len(data['files']),'withManifest':len(data['files'])+1,'sourceFingerprints':expected_count,'knowledgeFiles':330,'modelContracts':6})

stages=[]
for label,path in [('fixture-first','evidence/fixture-initial/edhr-dhr-write-old-attempt1-test.xml.gz'),('old-intermediate','evidence/old-intermediate/edhr-dhr-write-old-final-test.xml.gz'),('old-exact','evidence/primary-old-exact/edhr-dhr-write-old-exact-test.xml.gz')]:
    b=gzip.decompress((PKG/path).read_bytes());xml=ET.fromstring(b)
    totals={k:int(xml.attrib[k]) for k in ['tests','failures','errors','skipped']}
    assert totals=={'tests':5,'failures':3,'errors':0,'skipped':0}
    cases=[{'name':x.attrib['name'],'failureType':x.find('failure').attrib['type'] if x.find('failure') is not None else None,'failureMessage':x.find('failure').attrib.get('message') if x.find('failure') is not None else None} for x in xml.findall('testcase')]
    stages.append({'stage':label,'totals':totals,'cases':cases,'productRedCount':0 if label=='fixture-first' else 3,'collisionPositiveCount':2,'countAdditive':False})
assert json.loads((PKG/'evidence/fixture-initial/edhr-dhr-write-fixture-classification.json').read_bytes())['notProductRed'] is True
intermediate=(PKG/'evidence/old-intermediate/edhr-dhr-write-old-final-source.java').read_bytes()
final=git('show',HEAD+':gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentWriteFailureTest.java')
assert intermediate.replace(b'import static java.nio.file.StandardOpenOption.CREATE_NEW;\n',b'')==final
fact('intermediate-normalization-only-unused-import','DhrAttachmentWriteFailureTest.java',True,finalBytes=len(final),finalSha256=sha(final),intermediateSha256=sha(intermediate))

assert git('status','--porcelain')==b'' and git('rev-parse','HEAD').decode().strip()==HEAD
summary={'status':'FINAL','result':'passed','capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':BASE,'headCommit':HEAD,'contractBaseline':{'sourceCommit':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':HEAD,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','inventory':inventory,'inventoryOutputsByteIdentical':4,'oldArtifacts':87,'oldSourceSnapshots':5,'oldSourceComparisonCommit':OLD,'streamArtifacts':68,'streamSourceSnapshots':5,'streamSourceComparisonCommit':HEAD,'initialQualityBundleMembers':114,'initialQualityArtifacts':113,'initialQualityHead':OLD,'initialQualityBundleSha256':sha(bundle),'ontology':ontology,'oldControlStages':stages,'checksCount':len(checks),'allChecksPassed':all(x['passed'] for x in checks),'wholeFileSemanticReviewCount':0,'historicalUniqueCoverage':'unknown','findings':[],'boundary':'Mechanical byte/hash/inventory verification only. No all-ID semantics, new test/database/browser/HTTP/RBAC/migration execution or overall W0-W7 completion by this child.'}
dump(Path(str(PREFIX)+'-review.json'),{'summary':summary,'checks':checks});dump(Path(str(PREFIX)+'-commands.json'),commands)
Path(str(PREFIX)+'-review.md').write_text('# FINAL independent evidence review\n\nPassed on clean '+HEAD+' against '+BASE+'. Actual contractRead/source baseline is '+HEAD+'; project/role/model bytes are unchanged from e3. No repository files modified; no Maven, database, browser, HTTP, remote fetch or CI/Actions execution.\n\nRebuilt all four inventory outputs from fixed e3 with byte-identical results: 6604 paths,135 SQL migrations,464 HTTP annotation candidates,216 frontend route candidates. Every coverage row remains inventory-only/pending; whole-file semantic completion0; historical unique coverage unknown.\n\nOld evidence-manifest87 raw/stored artifacts and5 source snapshots verify against6012672a (old snapshots intentionally differ from current service,capacity test and package). Stream evidence68 raw/stored artifacts and5 source snapshots verify against currentHEAD; product/test source bytes also match320a4c74. Retained /tmp raw originals compared where present. Initial quality tar.gz SHA256 '+sha(bundle)+' verifies all114 members and the embedded113-item original manifest. This remains the independent601 stage, not validation of the streaming combination.\n\nOld ontology12 originals+manifest13 SHA256 '+ontology[0]['manifestSha256']+' remains unchanged,25 source fingerprints match601. Stream ontology13 originals+manifest14 SHA256 '+ontology[1]['manifestSha256']+' verifies27 current source fingerprints. Both330 knowledge files+6 model/governance files match e3 and current; knowledge0.3.25/schema1.2.0 and not-applicable results remain unchanged.\n\nParsed original XML: initial fixture first5/3F/0E/0S are explicitly excluded as product reds; actual old intermediate and old exact each5=3 product assertion reds+2 collision positives/0E/0S. Intermediate differs from final test only by removed unused import; exact final fault test7002B SHA256 '+sha(final)+'. Repeated stages are not additive unique coverage.\n\nNo findings in this mechanical scope. Existing two DHR high/A12/four gaps, original666paths/44knowledge/183ID and broader W0-W7/account/UI/recipient/ACL/concurrency/production-flow queues remain outside this pass.\n')
files=[]
for p in sorted(Path('/tmp').glob('edhr-dhr-combined-qa-evidence-*')):
    for f in sorted(p.rglob('*') if p.is_dir() else [p]):
        if f.is_file() and f.name!='edhr-dhr-combined-qa-evidence-manifest.json':
            b=f.read_bytes();files.append({'path':str(f),'rawBytes':len(b),'rawSha256':sha(b)})
dump(Path(str(PREFIX)+'-manifest.json'),{'status':'FINAL','files':files})
print(json.dumps({k:v for k,v in summary.items() if k not in ['inventory','oldControlStages']},ensure_ascii=False))
