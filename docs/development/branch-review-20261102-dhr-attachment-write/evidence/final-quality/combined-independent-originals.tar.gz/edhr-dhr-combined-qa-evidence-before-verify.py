from pathlib import Path
import concurrent.futures, datetime, gzip, hashlib, json, subprocess, tarfile, xml.etree.ElementTree as ET
ROOT=Path('/workspace/edhr-nexus-frontend')
PKG=ROOT/'docs/development/branch-review-20261102-dhr-attachment-write'
BASE='e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
OLD='6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'
P=Path('/tmp/edhr-dhr-combined-qa-evidence-before')
OUT=Path(str(P)+'-jfr');assert not OUT.exists();OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
with tarfile.open(PKG/'evidence/initial-quality/601-independent-originals.tar.gz') as t:
    members={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
mapping=json.loads((PKG/'initial-quality-manifest.json').read_bytes())
for i in mapping['members']:
    b=members[i['member']];assert len(b)==i['rawBytes'] and sha(b)==i['rawSha256']
capacity=json.loads(members['edhr-dhr-write-qa-capacity/capacity.json'])
assert capacity['completed'] is True and capacity['bytesPerFile']==52428800
assert len(capacity['cases'])==12 and sum(len(c['requests']) for c in capacity['cases'])==84
assert any('2g' in x for x in capacity['jvmArgs'])
source_paths={
 'DhrArchiveService.java':'src/main/java/com/zencas/edhr/production/service/',
 'DhrAttachmentController.java':'src/main/java/com/zencas/edhr/production/controller/',
 'DhrAttachmentDownloadCapacityPostgresTest.java':'src/test/java/com/zencas/edhr/production/service/',
 'DhrAttachmentService.java':'src/main/java/com/zencas/edhr/production/service/',
 'DhrAttachmentWriteFailureTest.java':'src/test/java/com/zencas/edhr/production/service/',
 'DhrOfficeAttachment.java':'src/main/java/com/zencas/edhr/production/service/',
 'DhrReviewController.java':'src/main/java/com/zencas/edhr/production/controller/',
 'DhrSummaryService.java':'src/main/java/com/zencas/edhr/production/service/'}
snapshots=[]
for name,rel in source_paths.items():
    b=members['edhr-dhr-write-qa-source-snapshots/'+name]
    committed=subprocess.check_output(['git','show',OLD+':gmp-platform/backend/'+rel+name],cwd=ROOT)
    assert b==committed;snapshots.append({'name':name,'bytes':len(b),'sha256':sha(b),'comparisonCommit':OLD})
suite_results=[]
for kind,tests in [('main',127),('knowledge',89),('capacity',1),('old',5)]:
    summary=json.loads(members['edhr-dhr-write-qa-'+kind+'-summary.json'])
    command=json.loads(members['edhr-dhr-write-qa-'+kind+'-command.json'])
    assert summary['missingFreshSuites']==[]
    totals={'tests':0,'failures':0,'errors':0,'skipped':0}
    for suite in summary['suites']:
        member=Path(suite['rawXML']).name;b=members[member]
        assert len(b)==suite['rawBytes'] and sha(b)==suite['sha256']
        xml=ET.fromstring(b)
        for k in totals:totals[k]+=int(xml.attrib[k])
        assert suite['sourceMtime']>=command['startedEpoch']
    assert totals=={'tests':tests,'failures':3 if kind=='old' else 0,'errors':0,'skipped':0}
    assert summary['totals']==totals
    assert command['testedHead']==OLD
    suite_results.append({'kind':kind,'totals':totals,'freshXMLCount':len(summary['suites']),'testedHead':command['testedHead'],'executionHead':command.get('executionWorktreeHead',OLD),'startedUTC':command['startedUTC'],'exitCode':summary['exitCode'],'currentInstanceExecuted':False})

def parse_case(case):
    label=case['label'];path=OUT/(label+'.jfr');b=members['edhr-dhr-write-qa-capacity/'+label+'.jfr'];path.write_bytes(b)
    argv=['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(path)]
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True)
    (OUT/(label+'-jfr-print.json.gz')).write_bytes(gzip.compress(r.stdout,mtime=0));(OUT/(label+'-jfr-print-stderr.txt')).write_bytes(r.stderr)
    assert r.returncode==0
    records=json.loads(r.stdout)['recording']['events'];target=[]
    for x in records:
        if x['type']=='jdk.FileRead' and (x['values'].get('path') or '').endswith('/capacity.png'):target.append(x['values'])
    paths={x['path'] for x in target};total=sum(max(0,x['bytesRead']) for x in target)
    assert len(paths)==1 and len(target)>0
    raw_reads=json.loads(members['edhr-dhr-write-qa-capacity/'+label+'-reads.json'])
    assert raw_reads['measurementAvailable'] is True and raw_reads['targetFileReadBytes']==total and raw_reads['fileReadEvents']==len(target)
    n=case['concurrency'];bad=case['corrupt'];assert len(case['requests'])==n
    expected=(50 if bad else 100)*1024*1024*n;assert total==expected
    query_count=(5 if case['frozen'] else 4) if bad else (6 if case['frozen'] else 5)
    for req in case['requests']:
        assert len(req['jdbcQueries'])==query_count and req['rejectedBeforeBody']==bad
        assert req['bodyBytes']==(0 if bad else 52428800)
    return {'label':label,'concurrency':n,'requests':len(case['requests']),'successfulExplicitJdbcQueriesPerRequest':query_count,'allocatedMiBRange':[min(r['allocatedBytes'] for r in case['requests'])/1048576,max(r['allocatedBytes'] for r in case['requests'])/1048576],'sampledHeapIncreaseMiB':case['sampledHeapIncreaseBytes']/1048576,'wallMillis':case['wallMillis'],'independentTargetReadBytes':total,'independentTargetReadEvents':len(target),'targetPath':next(iter(paths)),'logicalMiBPerRequest':total/n/1048576,'jfrRawBytes':len(b),'jfrRawSha256':sha(b),'currentInstanceExecutedCapacityBefore':False,'parseCommand':{'argv':argv,'startedUTC':started,'exitCode':r.returncode,'stdoutRawBytes':len(r.stdout),'stdoutRawSha256':sha(r.stdout),'stderrBytes':len(r.stderr)}}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:rows=list(ex.map(parse_case,capacity['cases']))
result={'status':'FINAL','result':'passed','currentInstanceExecutedCapacityBefore':False,'reusedBaseline':'Original independent601 QA run qualified by archived exact source snapshots, original freshXML/commands, member hashes, and this instance independent reparse of all12 original JFR through jfr print','baseCommit':BASE,'baselineHeadCommit':OLD,'snapshotComparisons':snapshots,'runtimeOriginalVerification':suite_results,'groups':len(rows),'requests':sum(r['requests'] for r in rows),'goodFullBytesAssertions':42,'badRejectedBeforeBody':42,'capacityEnvironment':{k:v for k,v in capacity.items() if k!='cases'},'rows':rows,'limitations':['Reanalysis of archived original evidence is not a new execution of old capacity before.','12 observations/84 requests is1 capacity test and not additive unique business coverage.','JFR logical file reads are not physical diskIO. Process heap/thread allocation excludes native/direct/RSS/network.','2GiB JVM,warm page cache,sparse paddedPNG,not fully warmedJIT,Hikari10,64KiB validation buffer andJFR/JDBC/assertion sampling overhead; no latency/heap threshold,HTTP/RBAC,full frozen process or productionSLA claim.']}
Path(str(P)+'-review.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':result['status'],'result':result['result'],'groups':12,'requests':84,'reparsedJFR':12,'snapshotComparisons':8,'oldOriginalRuntime':suite_results,'currentInstanceExecutedCapacityBefore':False},ensure_ascii=False))
