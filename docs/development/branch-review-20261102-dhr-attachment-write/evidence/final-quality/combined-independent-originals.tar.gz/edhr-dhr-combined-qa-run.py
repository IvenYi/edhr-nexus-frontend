from pathlib import Path
import subprocess as sp, json, os, time, hashlib, xml.etree.ElementTree as ET, traceback

repo=Path('/workspace/edhr-nexus-frontend')
prefix=Path('/tmp/edhr-dhr-combined-qa')
candidate=Path(str(prefix)+'-candidate')
old=Path(str(prefix)+'-old')
base='e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
head='5cb1636a23e09342b2d218bb986217a4325ea559'
container='edhr-dhr-combined-qa-20261102'
created=[]
def out(name, value):
    Path(str(prefix)+'-'+name+'.json').write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
def run(args,cwd=repo,**kw):
    return sp.run(args,cwd=cwd,text=True,stdout=sp.PIPE,stderr=sp.STDOUT,**kw)
def checked(args,cwd=repo):
    p=run(args,cwd); assert p.returncode==0,(args,p.stdout); return p.stdout.strip()
def snapshot(root,paths):
    return [{'path':p,'bytes':len((root/p).read_bytes()),'sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in paths]
paths=[
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentWriteFailureTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadCapacityPostgresTest.java',
 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentTransactionPostgresTest.java',
 'gmp-platform/backend/pom.xml']
classes='DhrAttachmentWriteFailureTest,DhrAttachmentTransactionPostgresTest,DhrAttachmentAndArchiveTest,DhrSummaryServiceTest,DhrReviewLifecycleIntegrationTest,FileControllerTest,FileCopyOwnershipTest,FileHttpBoundaryTest,FileUploadResourceTest,FileUploadTransactionIntegrationTest,FileUploadTransactionPostgresTest,FileUploadTransactionFailureTest,FileDeleteTransactionIntegrationTest,FileDeleteTransactionPostgresTest,FileDeleteTransactionFailureTest,DhrFormFilesTest,ExecutionAccessTest'
def maven(label,root,tests,pom,env,capacity=False):
    cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f',pom,'-Dtest='+tests]
    if capacity: cmd+=['-DargLine=-Xmx2g']
    cmd+=['test']; started=time.time()
    out(label+'-command',{'cmd':cmd,'cwd':str(root),'startedEpoch':started,'head':checked(['git','rev-parse','HEAD'],root),'database':database,'capacityOutput':env.get('EDHR_ATTACHMENT_CAPACITY_OUTPUT'),'sourceSnapshot':snapshot(candidate,paths)})
    print('START '+label,flush=True)
    with Path(str(prefix)+'-'+label+'-test.txt').open('wb') as log:
        p=sp.run(cmd,cwd=root,env=env,stdout=log,stderr=sp.STDOUT)
    suites=[]; missing=[]
    for name in tests.split(','):
        reports=list((root/Path(pom).parent/'target/surefire-reports').glob('TEST-*.'+name+'.xml'))
        if len(reports)!=1 or reports[0].stat().st_mtime<started:
            missing.append(name); continue
        raw=reports[0].read_bytes();Path(str(prefix)+'-'+label+'-'+name+'.xml').write_bytes(raw)
        tree=ET.fromstring(raw)
        suites.append({'suite':name,**{k:int(tree.get(k,'0')) for k in ['tests','failures','errors','skipped']},'time':tree.get('time'),'testcases':[{'name':t.get('name'),'failure':t.find('failure').get('message') if t.find('failure') is not None else None,'error':t.find('error').get('message') if t.find('error') is not None else None} for t in tree.findall('testcase')]})
    summary={'exit':p.returncode,'finishedEpoch':time.time(),'missingFreshSuites':missing,'suites':suites,'totals':{k:sum(s[k] for s in suites) for k in ['tests','failures','errors','skipped']}}
    out(label+'-summary',summary); print('DONE '+label+' '+json.dumps(summary['totals'])+' exit='+str(p.returncode),flush=True)

database={}
try:
    assert checked(['git','rev-parse','HEAD'])==head
    assert checked(['git','status','--porcelain=v1'])==''
    out('start',{'base':base,'head':head,'branch':checked(['git','branch','--show-current']),'status':checked(['git','status','--porcelain=v1']),'sourceSnapshot':snapshot(repo,paths)})
    checked(['git','worktree','add','--detach',str(candidate),head]); created.append(candidate)
    (candidate/'gmp-platform/frontend/node_modules').symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True)
    out('sourceSnapshot',snapshot(candidate,paths))
    checked(['docker','run','-d','--name',container,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_dhr_attachment_transaction_test','-p','127.0.0.1::5432','postgres:16-alpine']);created.append(container)
    port=checked(['docker','port',container,'5432/tcp']).split(':')[-1]
    deadline=time.time()+90;ready=[]
    while True:
        p=run(['docker','exec',container,'pg_isready','-h','127.0.0.1','-U','postgres','-d','edhr_dhr_attachment_transaction_test'])
        ready.append({'time':time.time(),'exit':p.returncode,'output':p.stdout})
        if p.returncode==0:break
        assert time.time()<deadline,'TCP PostgreSQL readiness timeout'
        time.sleep(1)
    checked(['docker','exec',container,'createdb','-h','127.0.0.1','-U','postgres','edhr_upload_transaction_test'])
    database={'container':container,'port':int(port),'readiness':ready,'dhrUrl':'jdbc:postgresql://127.0.0.1:'+port+'/edhr_dhr_attachment_transaction_test','uploadUrl':'jdbc:postgresql://127.0.0.1:'+port+'/edhr_upload_transaction_test','metadata':checked(['docker','exec',container,'psql','-h','127.0.0.1','-U','postgres','-d','edhr_dhr_attachment_transaction_test','-At','-c',"SELECT version(); SELECT datname,datcollate,datctype FROM pg_database WHERE datname IN ('edhr_dhr_attachment_transaction_test','edhr_upload_transaction_test');"]),'binding':checked(['docker','port',container])}
    out('database',database)
    env=os.environ.copy();env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=database['dhrUrl'],EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='',EDHR_UPLOAD_TX_DATABASE_URL=database['uploadUrl'],EDHR_UPLOAD_TX_DATABASE_USER='postgres',EDHR_UPLOAD_TX_DATABASE_PASSWORD='')
    maven('main',candidate,classes,'gmp-platform/backend/pom.xml',env)
    capacity=Path(str(prefix)+'-capacity');assert not capacity.exists();env['EDHR_ATTACHMENT_CAPACITY_OUTPUT']=str(capacity)
    maven('capacity',candidate,'DhrAttachmentDownloadCapacityPostgresTest','gmp-platform/backend/pom.xml',env,True)
    del env['EDHR_ATTACHMENT_CAPACITY_OUTPUT']
    maven('knowledge',candidate,'BusinessKnowledgeModelTest','tools/knowledge-model/pom.xml',env)
    checked(['git','worktree','add','--detach',str(old),base]);created.append(old)
    (old/'gmp-platform/frontend/node_modules').symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True)
    test=paths[1];(old/test).write_bytes((candidate/test).read_bytes())
    out('old-source-copy',{'source':snapshot(candidate,[test]),'copy':snapshot(old,[test]),'productSha256':hashlib.sha256((old/paths[0]).read_bytes()).hexdigest(),'productBaseSha256':hashlib.sha256(sp.check_output(['git','show',base+':'+paths[0]],cwd=repo)).hexdigest(),'statusBefore':checked(['git','status','--porcelain=v1'],old)})
    maven('old',old,'DhrAttachmentWriteFailureTest','gmp-platform/backend/pom.xml',env)
except BaseException:
    Path(str(prefix)+'-orchestration-error.txt').write_text(traceback.format_exc());print(traceback.format_exc(),flush=True)
finally:
    cleanup=[]
    if old in created and (old/paths[1]).exists():(old/paths[1]).unlink()
    for resource in reversed(created):
        if isinstance(resource,Path):
            symlink=resource/'gmp-platform/frontend/node_modules'
            if symlink.is_symlink():symlink.unlink()
            status=run(['git','status','--porcelain=v1'],resource)
            p=run(['git','worktree','remove',str(resource)])
            cleanup.append({'resource':str(resource),'statusBeforeRemove':status.stdout,'exit':p.returncode,'output':p.stdout})
        else:
            stop=run(['docker','stop',resource]);rm=run(['docker','rm',resource])
            cleanup.append({'resource':resource,'stopExit':stop.returncode,'stopOutput':stop.stdout,'removeExit':rm.returncode,'removeOutput':rm.stdout})
    cleanup.append({'mainHead':checked(['git','rev-parse','HEAD']),'mainStatus':checked(['git','status','--porcelain=v1'])})
    out('cleanup',cleanup);print('CLEANUP '+json.dumps(cleanup),flush=True)
