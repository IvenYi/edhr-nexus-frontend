import java.nio.file.*;
import java.util.*;
import jdk.jfr.consumer.*;
class EdhrCombinedJfrReads {
  public static void main(String[] args) throws Exception {
    for (String file:args) {
      long bytes=0, events=0; Set<String> paths=new TreeSet<>();
      try (var recording=new RecordingFile(Path.of(file))) {
        while (recording.hasMoreEvents()) {
          var event=recording.readEvent();
          if (!event.getEventType().getName().equals("jdk.FileRead")) continue;
          String path=event.getString("path");
          if (path==null || !path.endsWith("/capacity.png")) continue;
          paths.add(path);bytes+=Math.max(0,event.getLong("bytesRead"));events++;
        }
      }
      if(paths.size()!=1 || events==0) throw new IllegalStateException("Missing/ambiguous capacity path: "+file+" "+paths);
      System.out.println("{\"file\":\""+file+"\",\"targetFileReadBytes\":"+bytes+",\"fileReadEvents\":"+events+",\"path\":\""+paths.iterator().next()+"\"}");
    }
  }
}
