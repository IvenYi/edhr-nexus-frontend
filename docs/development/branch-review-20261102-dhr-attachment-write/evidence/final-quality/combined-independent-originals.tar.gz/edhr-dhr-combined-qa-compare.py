from pathlib import Path
import json,subprocess,hashlib,statistics
prefix=Path('/tmp/edhr-dhr-combined-qa')
before=Path(str(prefix)+'-baseline'); after=Path(str(prefix)+'-capacity')
java='/workspace/.edhr-cloud-tools/jdk-21/bin/java'
cmd=[java,str(prefix)+'-JfrReads.java']+[str(p) for p in sorted(after.glob('*.jfr'))]
assert len(cmd)==14
p=subprocess.run(cmd,text=True,capture_output=True)
Path(str(prefix)+'-after-jfr-command.json').write_text(json.dumps({'cmd':cmd,'exit':p.returncode,'stderr':p.stderr},indent=2)+'\n')
assert p.returncode==0,p.stderr
Path(str(prefix)+'-after-jfr-reparsed.jsonl').write_text(p.stdout)
def jfr_index(path):
    return {Path(x['file']).stem:x for x in [json.loads(line) for line in path.read_text().splitlines()]}
bj=jfr_index(Path(str(prefix)+'-baseline-jfr-reparsed.jsonl')); aj=jfr_index(Path(str(prefix)+'-after-jfr-reparsed.jsonl'))
b=json.loads((before/'capacity.json').read_text());a=json.loads((after/'capacity.json').read_text())
assert b['completed'] and a['completed'] and a['bytesPerFile']==b['bytesPerFile']==52428800
assert len(a['cases'])==len(b['cases'])==12
bm={c['label']:c for c in b['cases']};rows=[]
def stats(c):
    allocations=[r['allocatedBytes']/1048576 for r in c['requests']]
    return {'allocatedMiBMin':min(allocations),'allocatedMiBMax':max(allocations),'sampledHeapIncreaseMiB':c['sampledHeapIncreaseBytes']/1048576,'wallMillis':c['wallMillis']}
for c in a['cases']:
    label=c['label'];old=bm[label];n=c['concurrency'];bad=c['corrupt'];frozen=c['frozen']
    assert n in [1,4,16] and len(c['requests'])==n and len(old['requests'])==n
    queries=(5 if frozen else 4)+(0 if bad else 1)
    expected=(52428800 if bad else 104857600)*n
    for source,di in [(before,bj),(after,aj)]:
        stored=json.loads((source/(label+'-reads.json')).read_text());fresh=di[label]
        assert stored['measurementAvailable'] and fresh['targetFileReadBytes']==stored['targetFileReadBytes']==expected
        assert fresh['fileReadEvents']==stored['fileReadEvents']
    for stage in [c,old]:
        for request in stage['requests']:
            assert request['bodyBytes']==(0 if bad else 52428800)
            assert request['rejectedBeforeBody']==bad
            assert len(request['jdbcQueries'])==queries
            assert request['jdbcQueries']==old['requests'][0]['jdbcQueries']
    rows.append({'label':label,'requests':n,'jdbcQueriesPerRequest':queries,'jfrLogicalReadMiBPerRequest':expected/n/1048576,'bodyBytesPerRequest':0 if bad else 52428800,'rejectedBeforeBody':bad,'before':stats(old),'after':stats(c),'baselineJfrSha256':hashlib.sha256((before/(label+'.jfr')).read_bytes()).hexdigest(),'afterJfrSha256':hashlib.sha256((after/(label+'.jfr')).read_bytes()).hexdigest()})
assert sum(r['requests'] for r in rows)==84
assert sum(r['requests'] for r in rows if not r['rejectedBeforeBody'])==42
result={'result':'passed','beforeEvidence':'Reused initial601 independent QA original archived capacity + twelve JFRs. This instance re-parsed all JFRs and verified raw archive member hashes; did not execute before tests.','afterEvidence':'Executed this instance on exact combined5cb candidate detached tree with own PG16, capacity test one method. Re-parsed all twelve JFRs independently.','testMethods':1,'groups':12,'requests':84,'goodRequests':42,'corruptRequests':42,'rows':rows,'beforeJvmArgs':b['jvmArgs'],'afterJvmArgs':a['jvmArgs'],'beforeJava':b['javaVersion'],'afterJava':a['javaVersion'],'limits':a['limits'],'interpretation':'Observed heap allocation reduction; no exact heap/latency threshold asserted. Warm page cache synthetic sparse paddedPNG, 2GiB JVM, Hikari10, 64KiB output buffer; includes JDBC/assertion/JFR overhead. Heap excludes native/direct/RSS/network. JFR counts logical Java file reads, not physical disk IO. No HTTP/RBAC/full frozen workflow/production SLA or single-request speed guarantee.'}
Path(str(prefix)+'-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'result':result['result'],'groups':12,'requests':84,'rows':rows},indent=2))
