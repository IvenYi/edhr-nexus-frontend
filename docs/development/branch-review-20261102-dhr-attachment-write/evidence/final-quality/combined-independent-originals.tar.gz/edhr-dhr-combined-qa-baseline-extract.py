from pathlib import Path
import tarfile,json,hashlib
task=Path('/workspace/edhr-nexus-frontend/docs/development/branch-review-20261102-dhr-attachment-write')
manifest=json.loads((task/'initial-quality-manifest.json').read_text())
output=Path('/tmp/edhr-dhr-combined-qa-baseline');output.mkdir()
selected=[]
with tarfile.open(task/manifest['bundle'],'r:gz') as tar:
    for item in manifest['members']:
        member=item['member']
        if '/capacity.json' not in member and not member.endswith('.jfr') and not member.endswith('-reads.json') and member not in ['edhr-dhr-write-qa-quality-result.yaml','edhr-dhr-write-qa-capacity-summary.json','edhr-dhr-write-qa-capacity-command.json']:
            continue
        raw=tar.extractfile(member).read()
        assert len(raw)==item['rawBytes'] and hashlib.sha256(raw).hexdigest()==item['rawSha256']
        dest=output/Path(member).name;assert not dest.exists();dest.write_bytes(raw)
        selected.append({'member':member,'output':str(dest),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
Path('/tmp/edhr-dhr-combined-qa-baseline-extract.json').write_text(json.dumps({'stage':'601 independent original baseline; reused, not rerun by this instance','sourceManifest':str(task/'initial-quality-manifest.json'),'sourceManifestSha256':hashlib.sha256((task/'initial-quality-manifest.json').read_bytes()).hexdigest(),'headCommit':manifest['headCommit'],'selected':selected},indent=2)+'\n')
print(len(selected))
