import datetime
import hashlib
import json
import pathlib
import subprocess

import yaml

ROOT = pathlib.Path('/workspace/edhr-nexus-frontend')
OUT = pathlib.Path('/tmp/edhr-dhr-write-qa-source-knowledge-review.json')
BASE = 'e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
HEAD = '6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'
PACKAGE = ROOT / 'docs/development/branch-review-20261102-dhr-attachment-write'
ontology = json.loads((PACKAGE / 'evidence/ontology/edhr-dhr-write-ontology-semantic-review.json').read_text())
notes = {
    'term.dhr-controlled-attachment': 'Registered controlled evidence retains source, verification, association history and frozen references. A newly opened, unregistered partial file is outside that historical-evidence meaning; deleting only this owned fragment does not change the term.',
    'concept.dhr-controlled-attachment': 'The runtime-fact concept and its existing evidence links stay unchanged; the fix introduces no new business state or kind of record.',
    'relation.dhr-summary-version-contains-controlled-attachments': 'The frozen-version-to-attachment relation remains one-to-zero-or-many. The write failure occurs before registration and cannot become a frozen member.',
    'rule.dhr-summary-controlled-attachment-upload': 'The seven formats, inclusive 52428800-byte limit, original-byte/SHA-256 preservation and unlink-retains-original policy remain normative. CREATE_NEW ownership and write/close compensation are implementation reasoning, not new business rules.',
    'rule.dhr-review-task-frozen-attachment-download': 'Task scope and the task-bound frozen-version membership remain required. Capacity measurements through a direct controller/service/resource call provide no new authorization or recipient evidence.',
    'DEC-0063-05': 'Complete evidence and explicit source/version freezing are retained. The failed write is cleaned before INSERT and LINK, so it neither changes a historical frozen reference nor creates a new evidence member.',
    'DEC-0063-10': 'The original confirmation protects linked historical bytes, including after unlink. Successful CREATE_NEW ownership of a not-yet-registered file distinguishes the compensated fragment from those protected originals; create collisions remain protected.',
    'DEC-0063-11': 'Missing or corrupt applicable originals still block the relevant export, and explicit frozen-version scope remains. Memory/query observations do not authorize omitting integrity checks or converting original Office bytes.',
    'DEC-0063-12': 'Attachment LINK and other DHR data audit remain business events. Technical cleanup diagnostics and suppressed exceptions preserve a failed operation; they do not invent successful LINK or historical restoration audit.',
    'DEC-0063-13': 'Attachment association errors remain distinct from form-content errors and context ownership. Removing the new failed fragment does not move any evidence between production objects.',
    'evidence.dhr-summary-attachment-service': 'The code-evidence description explicitly dates its initial 25MB observation and disclaims later implementation proof. Its historical provenance is retained; the current source confirms the new local compensation without promoting the evidence to release-level preservation.',
    'scenario.dhr-summary-attachment-export-and-audit': 'This full scenario includes formats, size, bytes/hash, verification, unlink history, frozen exports, permissions and audit. The five fault cases and capacity observations are finite technical subsets and do not close the complete scenario.',
    'fact.dhr-summary.review-task-attachment-authorized': 'This boolean fact still derives from task authorization and frozen membership. File existence, a digest match and download throughput alone cannot establish it.',
    'evidence.dhr-summary-user-confirmed': 'The evidence index retains the actual user-confirmation source and the historical scope of each recorded run. This batch creates no new policy, maturity, stage, authorization or production SLA.',
}

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def find_id(node, ident):
    result = []
    if isinstance(node, dict):
        if node.get('id') == ident:
            result.append(node)
        for child in node.values():
            result.extend(find_id(child, ident))
    elif isinstance(node, list):
        for child in node:
            result.extend(find_id(child, ident))
    return result

records = []
for entry in ontology['records']:
    source = ROOT / entry['sourcePath']
    raw = source.read_bytes()
    matches = find_id(yaml.safe_load(raw), entry['id'])
    exact = len(matches) == 1 and matches[0] == entry['originalRecord']
    records.append({
        'id': entry['id'],
        'recordType': entry['recordType'],
        'sourcePath': entry['sourcePath'],
        'sourceLocator': next((f'line {i}' for i, line in enumerate(raw.decode().splitlines(), 1) if f'id: {entry["id"]}' in line), None),
        'sourceRawBytes': len(raw),
        'sourceRawSha256': hashlib.sha256(raw).hexdigest(),
        'currentIdOccurrences': len(matches),
        'exactCurrentRecordMatchesOntologyOriginal': exact,
        'originalMaturity': entry['originalMaturity'],
        'scopeClassification': 'finite-current-definition-policy-and-pre-registration-fragment-boundary',
        'semanticReviewStatus': 'reviewed',
        'conclusion': 'consistent' if exact else 'evidence-gap',
        'independentReason': notes[entry['id']],
        'originalRecord': matches[0] if len(matches) == 1 else matches,
        'evidenceReferences': [entry['sourcePath'], 'docs/knowledge/evidence/dhr-summary-user-confirmed.md#Office-originals-and-50MB', 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java', 'docs/development/branch-review-20261102-dhr-attachment-write/decision-package.yaml'],
    })

contract_paths = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/quality-verifier.md', 'docs/agents/business-knowledge-modeler.md', 'docs/architecture/business-knowledge-model.md']
delta = git('diff', '--name-status', BASE, HEAD, '--', *contract_paths, 'docs/knowledge')
result = {
    'status': 'FINAL',
    'reviewer': '/root/dhr_attachment_write_final_quality_20261102/source_review/knowledge_evidence',
    'capturedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'result': 'passed' if all(r['exactCurrentRecordMatchesOntologyOriginal'] for r in records) and not delta and git('rev-parse', 'HEAD') == HEAD else 'failed',
    'baseCommit': BASE,
    'headCommit': HEAD,
    'contractBaseline': {'sourceCommit': HEAD, 'targetBranch': 'edhr-dev', 'targetCommit': BASE, 'contractReadCommit': HEAD, 'uncommittedContractPaths': []},
    'workingTreeStatusPorcelain': git('status', '--porcelain'),
    'localTargetRef': git('rev-parse', 'edhr-dev'),
    'cachedRemoteTargetRef': git('rev-parse', 'origin/edhr-dev'),
    'knowledgeModelVersion': '0.3.25',
    'schemaVersion': '1.2.0',
    'knowledgeAndModelContractDelta': delta,
    'counts': {'reviewedFiniteExistingIds': len(records), 'mainExistingIdsReported': 12, 'sourceExistingIdsReported': 9, 'overlapReported': 7, 'wholeFileCompletion': 0, 'newHistoricalUnique': None},
    'records': records,
    'ontologyNotApplicableConclusion': 'Supported: the product change is compensation of the successfully CREATE_NEW-owned current unregistered fragment after write/close IOException. Existing and frozen originals, association history, format/size/digest/verification/permissions and current transaction callbacks keep their meanings. No policy, maturity, knowledge version, execution contract or stage change is needed.',
    'engineeringInferences': ['Successful CREATE_NEW stream return establishes ownership of only this new current file.', 'Only write/close IOException of that current unregistered file is compensated; create collision does not grant delete ownership.', 'Suppressed cleanup failure and ID/path logs preserve the primary failure without fabricating LINK.', 'Capacity metrics describe the local observation environment; proposed streaming SHA optimization remains unapproved/unimplemented in this batch.'],
    'retainedQueues': ['Two existing DHR high findings, A12 and four gaps', 'Original 666 paths / 44 knowledge files / 183 ID candidate ledger', 'W2 remainder; W3/W4/W5 crossing', 'W6 robustness/performance/A23 including previously reviewed scope; W7 latest increments', 'Complete account/UI/recipient matrix, shared ACL/reference concurrency', 'Persistent crash/cleanup-failure/UNKNOWN reconciliation and retry idempotency', 'Friend signature page and production-popup original pauses'],
    'limitations': ['Finite semantic review only; not all-ID semantics or whole-file completion.', 'No Maven, database, browser, HTTP/RBAC, recipient, schema/migration or performance execution by this child.', 'Mechanical 87 artifact / 5 snapshot / 13 ontology / 25 source fingerprint / 330 knowledge verification is owned by the parallel evidence inventory role; this report does not duplicate or claim that execution.', 'Current task source authorization is based on the supplied scope. This role did not fetch remote state or query CI/Actions. The local edhr-dev ref is older; the supplied target and cached origin/edhr-dev both identify the fixed e3 base.'],
    'findings': [],
}
OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': str(OUT), 'result': result['result'], 'finiteIds': len(records), 'allRecordSnapshotsMatch': all(r['exactCurrentRecordMatchesOntologyOriginal'] for r in records), 'knowledgeContractDeltaEmpty': not delta, 'head': git('rev-parse', 'HEAD'), 'clean': not result['workingTreeStatusPorcelain']}, ensure_ascii=False))
