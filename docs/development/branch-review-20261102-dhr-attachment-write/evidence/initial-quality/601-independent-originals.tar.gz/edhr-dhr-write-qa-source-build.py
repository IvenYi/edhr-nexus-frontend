import datetime, gzip, hashlib, json, pathlib, re, subprocess

root = pathlib.Path('/workspace/edhr-nexus-frontend')
prefix = pathlib.Path('/tmp/edhr-dhr-write-qa-source')
snapshots = pathlib.Path(str(prefix) + '-snapshots')
snapshots.mkdir(exist_ok=True)
base = 'e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
head = '6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'

def run(*args):
    return subprocess.run(args, cwd=root, check=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT).stdout

def sha(value):
    return hashlib.sha256(value).hexdigest()

files = [
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrAttachmentService.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentWriteFailureTest.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentDownloadCapacityPostgresTest.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrAttachmentController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrOfficeAttachment.java',
]
entries = []
for path in files:
    raw = (root / path).read_bytes()
    committed = run('git', 'show', f'{head}:{path}')
    assert raw == committed, path
    dest = snapshots / pathlib.Path(path).name
    dest.write_bytes(raw)
    entries.append({'path': path, 'snapshot': str(dest), 'bytes': len(raw), 'sha256': sha(raw), 'headExact': True})

diff = run('git', 'diff', base + '..' + head, '--', 'gmp-platform/backend/src/main/java')
pathlib.Path(str(prefix) + '-product.diff').write_bytes(diff)
changed = run('git', 'diff', '--name-only', base + '..' + head, '--', 'gmp-platform/backend/src/main/java').decode().splitlines()
assert changed == [files[0]], changed
old = run('git', 'show', f'{base}:{files[0]}')
pathlib.Path(str(prefix) + '-base-DhrAttachmentService.java').write_bytes(old)
current = (root / files[0]).read_bytes()
oldline = b'        Files.write(stored, bytes, java.nio.file.StandardOpenOption.CREATE_NEW);\n'
replacement = b'''        var output = Files.newOutputStream(stored, java.nio.file.StandardOpenOption.CREATE_NEW);
        try (output) {
            for (int offset = 0; offset < bytes.length; offset += 8192)
                output.write(bytes, offset, Math.min(8192, bytes.length - offset));
        } catch (IOException writeFailure) {
            try { Files.deleteIfExists(stored); }
            catch (IOException cleanupFailure) {
                writeFailure.addSuppressed(cleanupFailure);
                log.error("Failed to remove incomplete DHR attachment: id={}, path={}", id, stored, cleanupFailure);
            }
            throw writeFailure;
        }
'''
assert old.replace(oldline, replacement) == current

javap = run('/workspace/.edhr-cloud-tools/jdk-21/bin/javap', '-c', '-p', 'java.nio.file.Files')
start = javap.index(b'  public static java.nio.file.Path write(java.nio.file.Path, byte[], java.nio.file.OpenOption...) throws java.io.IOException;')
end = javap.index(b'  public static ', start + 2)
method = javap[start:end]
pathlib.Path(str(prefix) + '-jdk-write-bytecode.txt').write_bytes(method)
original = gzip.decompress((root / 'docs/development/branch-review-20261102-dhr-attachment-write/evidence/source-evidence/edhr-dhr-write-jdk-write-bytecode.txt.gz').read_bytes())
assert method == original, (len(method), len(original))
version = run('/workspace/.edhr-cloud-tools/jdk-21/bin/java', '-version')
pathlib.Path(str(prefix) + '-jdk-version.txt').write_bytes(version)
rawcalls = run('rg', '-n', 'DhrAttachmentService|new DhrAttachmentService|attachments\\.(upload|active|snapshot|file|downloadableFile|originalName)|service\\.upload\\(dhrId', 'gmp-platform/backend/src/main/java')
pathlib.Path(str(prefix) + '-callers.txt').write_bytes(rawcalls)

contracts = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md', 'docs/agents/quality-verifier.md']
unchanged = []
for path in contracts:
    raw = (root / path).read_bytes()
    assert raw == run('git', 'show', f'{base}:{path}')
    unchanged.append({'path': path, 'bytes': len(raw), 'sha256': sha(raw), 'baseHeadEqual': True})
status = run('git', 'status', '--porcelain=v1').decode()
assert status == '', status
result = {
    'phase': 'FINAL', 'result': 'passed', 'role': 'independent read-only source verification subtask',
    'createdAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'baseCommit': base, 'headCommit': head, 'testedCommit': head,
    'contractBaseline': {'sourceCommit': head, 'targetBranch': 'edhr-dev', 'targetCommit': run('git', 'rev-parse', 'origin/edhr-dev').decode().strip(), 'contractReadCommit': head, 'uncommittedContractPaths': []},
    'localEdhrDevReference': run('git', 'rev-parse', 'edhr-dev').decode().strip(),
    'workingTreeState': {'status': 'clean', 'includedPaths': [], 'excludedPaths': [], 'untrackedPaths': []},
    'knowledgeBaselineVersion': '0.3.25', 'schemaVersion': '1.2.0',
    'snapshots': entries, 'contractFingerprints': unchanged,
    'productChangedPaths': changed,
    'singleReplacementMatchesAllProductChanges': True,
    'jdkWrite': {'javaVersionRaw': version.decode(), 'javapCommand': '/workspace/.edhr-cloud-tools/jdk-21/bin/javap -c -p java.nio.file.Files', 'methodBytes': len(method), 'sha256': sha(method), 'savedOriginalExact': True, 'chunkSize': 8192},
    'callers': {'raw': str(prefix) + '-callers.txt', 'rawSha256': sha(rawcalls), 'scope': 'finite typed production source search only', 'conclusion': 'Only explicit current production upload is the injected DhrAttachmentController.service.upload call; Summary/Archive/Review consumers use reads. No explicit production construction or self-upload found.', 'limitations': 'Does not certify every reflective, dynamic, future, HTTP-authenticated or deployed entrypoint; unchanged original transaction synchronization guard is preserved.'},
    'reviewedChecks': [
        {'id': 'owned-create-boundary', 'locator': 'DhrAttachmentService.java:101-112', 'conclusion': 'CREATE_NEW acquisition is outside the IOException compensation catch. Existing path create collision cannot reach deleteIfExists.'},
        {'id': 'write-close-failure', 'locator': 'DhrAttachmentService.java:102-111', 'conclusion': 'try-with-resources covers actual writes and close; caught IOException cleans only the newly acquired current path. Cleanup IOException is suppressed on original, logged with ID/path, original is rethrown.'},
        {'id': 'retained-transaction-business-boundaries', 'locator': 'DhrAttachmentService.java:72-100,113-279; DhrAttachmentController.java', 'conclusion': 'Byte proof: replacing only former Files.write line generates entire current production change. Original transaction callback outcomes, metadata/size/format/SHA, verify/unlink/history/frozen/download and controller authorization remain unchanged.'},
        {'id': 'fault-fixtures', 'locator': 'DhrAttachmentWriteFailureTest.java:58-129', 'conclusion': 'Five executions assert real partial bytes, close failure, cleanup failure with real nonempty directory and original exception/log, file/directory collision preservation, no registration or audit and unrelated file retained. Conditional Answer does not open a file while configuring mock. These are explicit IOException injections, not physical disk exhaustion.'},
        {'id': 'a23', 'locator': 'changed product block and added test classes', 'conclusion': 'Narrow current-file compensation; no speculative global guard/state/retry/storage framework, new SQL or looped queries. 8KiB is actual JDK21 Files.write behavior; existing size precheck/actual byte length/format parse/hash/frozen membership have distinct integrity purposes. New test opt-in/loopback and empty-output guards limit destructive fixture scope.'},
        {'id': 'capacity-observation-scope', 'locator': 'DhrAttachmentDownloadCapacityPostgresTest.java:57-185', 'conclusion': '12 groups x concurrent1/4/16 across current/frozen and good/corrupt=84 requests in one test. Direct Controller with actual service proxy and FileSystemResource; successful explicit JdbcTemplate method counts, JFR logical file bytes, thread allocation and sampled heap. Full good body bytes/SHA and bad-before-body refusal asserted; no fixed heap/latency/query count production threshold. No HTTP/RBAC/network/native/RSS/physical disk/full freezing certification.'},
        {'id': 'extraction-not-implementation', 'locator': 'review-notes.md; source-review.json', 'conclusion': 'Proposed upload/read/association extraction preserves domain ownership and transaction+audit boundary; bounded-buffer full SHA before output is next-batch discussion only. No extraction or download optimization is implemented here.'}
    ],
    'findings': [],
    'residualRisks': ['Crash and cleanup-failure/UNKNOWN durable reconciliation remain outside this in-process compensation slice.', 'Cross-resource atomicity, complete retry idempotency, shared-reference ACL/concurrency, complete schema/FK/migration/UI/RBAC/tenant/recipient and deployed dynamic entrypoint verification are not certified.', 'Two old DHR highs/A12/four gaps, original666paths/44knowledge/183IDs, W2 remainder/W3-W5 crossing/W6 robustness-performance-A23 including old-reviewed whole pass/W7 increments and original pauses remain open. Whole-file completion remains0; historical unique coverage unknown.'],
    'rawEvidenceOwnership': 'Own source reads/snapshots/JDK extraction; execution test results remain owned by parent QA.'
}
pathlib.Path(str(prefix) + '-review.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'sourceReview': str(prefix) + '-review.json', 'snapshots': len(entries), 'productChangedPaths': changed, 'jdkExact': True, 'status': 'clean'}, ensure_ascii=False))
