from pathlib import Path
import datetime, hashlib, json, subprocess
import yaml

root = Path('/workspace/edhr-nexus-frontend')
prefix = '/tmp/edhr-dhr-write-qa'
base = 'e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
head = '6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'

def load(suffix): return json.loads(Path(prefix + suffix).read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def save(suffix, data): Path(prefix + suffix).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

assert git('rev-parse', 'HEAD') == head
assert not git('status', '--porcelain=v1')
remote_cmd = ['git', 'ls-remote', '--heads', 'origin', 'edhr-dev']
remote = subprocess.run(remote_cmd, cwd=root, capture_output=True, text=True)
assert remote.returncode == 0 and remote.stdout.split()[0] == base
save('-final-baseline.json', {'capturedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': head, 'branch': git('branch','--show-current'), 'workingTreeStatus': git('status','--porcelain=v1'), 'remoteCommand': remote_cmd, 'remoteExitCode': remote.returncode, 'remoteStdout': remote.stdout, 'remoteStderr': remote.stderr, 'worktrees': git('worktree','list','--porcelain')})
for label, expected in [('main',127), ('knowledge',89), ('capacity',1)]:
    s = load('-' + label + '-summary.json')
    assert s['exitCode'] == 0 and not s['missingFreshSuites']
    assert s['totals'] == {'tests': expected, 'failures': 0, 'errors': 0, 'skipped': 0}
old = load('-old-summary.json')
assert old['exitCode'] != 0 and not old['missingFreshSuites']
assert old['totals'] == {'tests': 5, 'failures': 3, 'errors': 0, 'skipped': 0}
assert load('-old-setup.json')[1]['testBytesMatch'] and load('-old-setup.json')[1]['productDiff'] == ''
assert load('-old-cleanup.json')['exitCode'] == 0 and not load('-old-cleanup.json')['worktreeExists']
cleanup = load('-cleanup.json')
assert all(row['exitCode'] == 0 for row in cleanup[:2])
assert cleanup[2]['headAfter'] == head and not cleanup[2]['statusAfter'] and not cleanup[2]['remainingOwnContainer']
capacity = load('-capacity-verification.json')
assert capacity['result'] == 'passed' and capacity['requests'] == 84
assert load('-source-review.json')['result'] == 'passed'
evidence_qa = yaml.safe_load(Path(prefix + '-evidence-quality-result.yaml').read_text())['qualityResult']
assert evidence_qa['result'] == 'passed'
assert load('-source-knowledge-review.json')['status'] == 'FINAL'
roles = [
 {'role': '/root/dhr_attachment_write_final_quality_20261102', 'status': 'FINAL', 'result': 'passed', 'scope': 'independent final current-batch QA; no repairs'},
 {'role': '/root/dhr_attachment_write_final_quality_20261102/source_review', 'status': 'FINAL', 'result': 'passed', 'scope': 'source/impact/A23 and finite knowledge review'},
 {'role': '/root/dhr_attachment_write_final_quality_20261102/source_review/knowledge_evidence', 'status': 'FINAL', 'result': 'passed', 'scope': '14 existing IDs finite semantic review'},
 {'role': '/root/dhr_attachment_write_final_quality_20261102/evidence_inventory', 'status': 'FINAL', 'result': 'passed', 'scope': 'fixed inventory and raw/stored/source fingerprints'},
]
save('-roles-final.json', {'roles': roles, 'evidence': 'Actual completed final responses returned through collaboration tools; no role participated in repairs.'})

def check(id, category, description, method, command, evidence):
    return {'id': id, 'required': True, 'category': category, 'description': description, 'method': method, 'command': command, 'outcome': 'passed', 'evidence': evidence}

main_cmd = load('-main-command.json')['argv']
capacity_cmd = load('-capacity-command.json')['argv']
checks = [
 check('qa.baseline-independence','documentation','独立质量实例、固定提交与实际契约基线；受测树clean且无未提交范围。','command','git rev-parse HEAD; git status --porcelain=v1; git ls-remote --heads origin edhr-dev', [prefix+'-baseline.json',prefix+'-final-baseline.json',prefix+'-source-review.json', 'Actual target/base '+base+'; feature head and tested integration candidate '+head+'; contractRead/source '+head+'; uncommittedContractPaths=[]. Local old edhr-dev ref was not used as target.']),
 check('qa.owned-write-source-impact','requirements','CREATE_NEW所有权、8KiB写入/关闭IOException补偿、原错/suppressed及ID/path日志与已确认范围一致。','inspection','Inspect exact base/head production diff and current upload block; independently invoke wrapper JDK21 javap.', [prefix+'-source-review.json',prefix+'-source-report.md',prefix+'-source-product.diff',prefix+'-source-snapshots/',prefix+'-source-jdk-write-bytecode.txt', 'Only original Files.write line replacement explains the entire production diff. Creation collision occurs outside cleanup catch; INSERT/LINK follows successful stream close. Actual JDK21 Files.write extraction 1965 bytes exactly matches retained original and uses 8192-byte chunks.']),
 check('qa.a23-neighbor-boundaries','regression','有限A23/调用链与既有事务、格式、SHA、资格、核验、unlink历史、冻结、下载和HTTP权限不变。','inspection','Inspect current typed production upload references and unchanged neighboring source against e3.',[prefix+'-source-review.json',prefix+'-source-callers.txt',prefix+'-source-report.md','Typed explicit production upload found only injected Controller call; no internal unsynchronized upload was found. This is finite source evidence, not dynamic/deployment/HTTP authentication certification. Existing transaction guard retained. No new performance implementation, SQL/index, retry or storage framework.']),
 check('qa.native-postgres-regression-127','integration','自有原生PG16上单次17类127项新故障及相邻回归。','automated-test',' '.join(main_cmd),[prefix+'-database.json',prefix+'-main-command.json',prefix+'-main-execution-environment.json',prefix+'-main-test.log',prefix+'-main-summary.json','17 fresh XML suites; 127 tests, 0 failures, 0 errors, 0 skipped. Includes fault5, native DHR transaction11, actual Chromium PDF archive13 and existing file/summary/lifecycle/access regression. Other-browser host-dependency warning retained; Chromium run passed without product/environment changes.']),
 check('qa.exact-old-base-controls','unit','own detached e3旧产品仅加精确最终测试字节，验证3真产品断言红与2碰撞正控。','automated-test','cd /tmp/edhr-dhr-write-qa-old-worktree && bash /workspace/.edhr-cloud-tools/mvn-edhr -f gmp-platform/backend/pom.xml -Dtest=DhrAttachmentWriteFailureTest test',[prefix+'-old-setup.json',prefix+'-old-command.json',prefix+'-old-test.log',prefix+'-old-summary.json',prefix+'-old-failure-classification.json',prefix+'-old-exact-DhrAttachmentWriteFailureTest.java',prefix+'-old-cleanup.json','Exact final test 7002 bytes SHA256 6088d5bb120f1800da70d8542a16278a625f6efd5ea233c8b5e753013b81c69f. Old production diff empty. Fresh XML:5 tests/3 assertion failures/0 errors/0 skipped; file and directory collisions pass. Old worktree frontend node_modules linked at gmp-platform/frontend/node_modules. Expected red Maven exit1; no fixture errors counted as product red; stages not additive unique coverage.']),
 check('qa.capacity-separate-observation','regression','单独1项容量测试完成12组84请求；完整输出/摘要和坏文件输出前拒绝，独立重解析12JFR。','automated-test',' '.join(capacity_cmd)+'; python3 /tmp/edhr-dhr-write-qa-capacity-verify.py',[prefix+'-capacity-command.json',prefix+'-capacity-execution-environment.json',prefix+'-capacity-test.log',prefix+'-capacity-summary.json',prefix+'-capacity/capacity.json',prefix+'-capacity-verification.json',prefix+'-capacity-independent-jfr-command.json',prefix+'-capacity-independent-jfr.tsv','Fresh XML 1/0/0/0.42 valid full 52428800-byte outputs with SHA256 assertion passed;42 corrupt rejected before body.12 raw JFR and12 raw reads.json retained. Explicit successful JDBC queries current good/corrupt5/4 and frozen6/5; independently parsed JFR logical bytes100MiB/50MiB per request. Thread allocations about50MiB/request;16-worker sampled heap increase818-821MiB. No precise heap/latency threshold.']),
 check('qa.knowledge-89','ontology','独立执行知识校验89项并核对本体NA及14既有ID有限语义。','automated-test','bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test',[prefix+'-knowledge-command.json',prefix+'-knowledge-test.log',prefix+'-knowledge-summary.json',prefix+'-source-knowledge-review.json',prefix+'-source-knowledge-report.md','89 tests,0 failures/errors/skipped. Knowledge0.3.25/schema1.2.0;14 existing IDs=12+9-7 limited review; ontology FINAL not-applicable unchanged. No knowledge maturity/stage promotion or full audit claim.']),
 check('qa.raw-evidence-inventory','documentation','重建固定e3四盘点并核原始证据bytes/hash、快照及知识/契约未变。','command','python3 /tmp/edhr-dhr-write-qa-evidence-verify.py',[prefix+'-evidence-commands.json',prefix+'-evidence-verification.json',prefix+'-evidence-report.md',prefix+'-evidence-manifest.json','469 mechanical checks passed. Four inventory outputs byte-identical:6604 paths/135SQL/464HTTP/216routes.87 primary raw/stored/source originals+5 source snapshots match. Ontology12+manifest13; manifest SHA256470b0b8adaa2b9e4eb30dd05b0950ced70a4948463919142b6a044b88c4671a2.25 source fingerprints;330 knowledge+6 model/governance paths unchanged from actual e3. WholeFile0; historical unique unknown.']),
 check('qa.whitespace-classification','documentation','保留默认diff-check的CSV CRLF结果；以命令级cr-at-eol核其余空白。','command','git -c core.whitespace=cr-at-eol diff --check '+base+' '+head,[prefix+'-baseline.json',prefix+'-whitespace.json','Default git diff --check exit2 only canonical generated CSV CRLF trailing-whitespace diagnostics retained as original output; command-level CRLF classification exit0. No repository config or inventory byte normalization.']),
 check('qa.cleanup-and-role-finals','documentation','自有容器/旧树正常清理，全部子角色FINAL，受测主树保持HEAD及clean。','command','python3 /tmp/edhr-dhr-write-qa-run.py cleanup; git status --porcelain=v1',[prefix+'-cleanup.json',prefix+'-old-cleanup.json',prefix+'-roles-final.json',prefix+'-final-baseline.json','Own docker stop and rm exit0 without force; no remaining own container. Own old worktree normal remove exit0. No product/test/fixture/config mutations, no merge/deploy/history restore, no CI/Actions query or trigger. All dispatched roles FINAL.']),
]

def risk(id, description, impact, mitigation): return {'id': id, 'description': description, 'impact': impact, 'mitigation': mitigation}
risks = [
 risk('risk.local-current-original-only','结论仅覆盖本批当前新文件登记前写入/关闭IOException及既有邻接回归。','不证明跨资源原子、进程崩溃恢复、持久对账、完整重试幂等或所有失败零残片。','清理失败及UNKNOWN保留诊断；崩溃和持久对账留原队列，不扫删或恢复历史。'),
 risk('risk.fault-injection','新5项使用真实文件/流并显式注入IOException，非真实磁盘满或网络故障。','不能外推底层硬件/文件系统/网络全部故障。','保留准确故障机制及原始阶段，不把早期夹具失败当产品红。'),
 risk('risk.capacity-limits','容量是2GiB JVM、暖页缓存/稀疏padded PNG、未全预热JIT、Hikari10、64KiB输出校验缓冲的进程内Controller/service/resource观测；含断言/JFR开销。','JFR为逻辑文件读取，allocation/采样heap不含native/direct/RSS/network，不代表HTTP/RBAC、完整冻结流程、物理IO或生产SLA。','按观测范围使用指标，不规定精确heap/延迟门槛，不承诺生产并发上限或单次更快。'),
 risk('risk.explicit-source-caller-boundary','当前typed源码只发现Controller上传入口；未发现内部无事务调用。','不认证反射/动态/未来入口、部署拓扑或完整HTTP认证。','保留原同步guard，后续新入口按W7核查；不为猜测新增全局防御。'),
 risk('risk.authorization-concurrency','本批不覆盖共享ACL、引用并发及完整账号/UI/RBAC/tenant/recipient矩阵。','局部资源所有权修复不能关闭更大授权与并发队列。','保留相应专项及已有DHR两项high/A12/四gap。'),
 risk('risk.schema-migration-scope','原生PG使用选定canonical表/手工版本元数据；不是完整schema/FK/migration/升级验收。','不能外推全量迁移或生产部署兼容。','仅报告实际代理/JDBC/JPA审计与文件路径；完整数据库路径继续待审。'),
 risk('risk.audit-backlog','6604paths/135SQL/464HTTP/216routes仅盘点；wholeFile0、历史unique未知。原666paths/44knowledge/183ID、W2余项/W3W4W5交叉/W6健壮性性能A23含旧已审全量/W7增量仍保留。','本批通过不等于整体W0-W7审计完成，也不关闭旧问题。','继续原队列，原记录控制已实现按增量审；朋友签署页与生产弹窗原暂缓保持。'),
 risk('risk.candidate-drift','本结果只适用clean601候选。用户随后确认的流式摘要优化由主审在独立树另行实施，本QA未覆盖。','新组合候选不能复用本结果声称已获最终质量通过。','主审在新候选重新评估影响并派全新独立QA，交付前实际漂移/阶段复核；人工merge/deploy。'),
]
quality = {'qualityResult': {'result': 'passed', 'baseCommit': base, 'headCommit': head, 'contractBaseline': {'sourceCommit': head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':risks,'blockingConditions':[]}}
result_path = Path(prefix + '-quality-result.yaml')
result_path.write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False,width=110))

rows = []
for r in capacity['rows']:
    rows.append('| '+r['label']+' | '+str(r['successfulExplicitJdbcQueriesPerRequest'])+' | '+f"{r['allocatedMiBRange'][0]:.2f}–{r['allocatedMiBRange'][1]:.2f}"+' | '+f"{r['sampledHeapIncreaseMiB']:.2f}"+' | '+f"{r['jfrTargetLogicalMiBPerRequest']:.0f}"+' | '+f"{r['wallMillis']:.1f}"+' |')
report = f'''# FINAL：601候选独立最终质量结果

`qualityResult.result: passed`；本实例未参与任何修复，仅验证，未修改产品、测试、夹具或配置。没有本批新发现。范围为 clean `{head}` 对固定目标/base `{base}`，实际读取契约提交/source 是 `{head}`。目标远程 `edhr-dev` 在最终只读 ls-remote 核对仍为 e3；本地旧 edhr-dev ref没有作为目标。知识基线0.3.25/schema1.2.0，模型、知识及项目/角色/交接契约对e3无增量。此结果是601初候选的局部通过，不覆盖随后在独立树实施的流式摘要优化；组合候选必须重新fresh独立QA。

| 实际独立运行 | 结果 | 说明 |
|---|---|---|
| 单次17类新故障及相邻回归 | 127/127，0F/E/S | 新fault5已包含；Archive13实际Chromium生成PDF |
| 独立知识校验 | 89/89，0F/E/S | 精确当前知识；不代替有限语义审读 |
| 单独容量测试 | 1/1，0F/E/S | 12组84请求，不能按84个业务用例相加 |
| own detached旧e3精确测试反证 | 5=3产品assertion红+2碰撞正控，0error/skip | Maven预期exit1；旧产品未改 |

四次运行均保留原始命令、日志、fresh XML及汇总。127测试的17份XML逐项检查mtime晚于本次运行开始；知识/容量/旧树各自独立fresh XML。受测最终fault源码7002B，SHA256 `6088d5bb120f1800da70d8542a16278a625f6efd5ea233c8b5e753013b81c69f`，与旧树仅复制文件和HEAD git blob完全一致。旧树只有该新测试及正确位置的`gmp-platform/frontend/node_modules`链接；旧生产diff为空。三红是部分写/关闭后当前原件未清理、清理失败缺suppressed断言；两类碰撞保留正控均过。旧初版stubbing夹具错误仍单独保留/excluded，不算产品红；重复反证阶段不相加唯一覆盖。

自有`postgres:16-alpine`仅loopback 127.0.0.1:32769，trust，PG16.15/en_US.utf8/UTF8/UTC。使用`pg_isready -h 127.0.0.1 -p5432`等到最终TCP server，再创建两指定库；元数据从`pg_database.datcollate`查询，未误用SHOW lc_collate。指定DHR/UPLOAD环境变量均指向本实例容器，postgres/空密码。主回归与容量使用同own原生PG环境，容量输出目录全新且为空；容量JVM为-Xmx2g。容器stop+rm、旧树worktree remove均正常exit0，无force、不碰他人资源。主工作树最终HEAD601且clean。

源码独立复核确认只替换DhrAttachmentService的原Files.write行：CREATE_NEW开流在catch外，取得当前文件后try-with-resources覆盖8KiB写和close IOException；补偿只删本次未登记文件，清理失败suppressed+ID/path技术日志且原异常保留。原事务COMMITTED/ROLLED_BACK/UNKNOWN、格式/50MiB/元信息/SHA/资格/核验/unlink历史/冻结与HTTP权限无本批变化。实际wrapper JDK21 Files.write字节码1965B与原存件完全一致，8192B分块沿用原行为。有限A23检查未新增全局状态、重试、SQL循环、集合N+1或多读Multipart。当前显式typed生产upload只有注入Controller入口；不能据此认证动态/未来入口或部署完整事务/HTTP认证。原同步guard未改。

容量42次有效请求均完整输出52428800B且精确测试SHA断言通过；42损坏请求均获得响应体前以摘要错误拒绝。12JFR、12reads.json及capacity.json保留。另以自有Java RecordingFile程序逐份重解析JFR，目标文件字节/事件与test原读数一致；成功Jdbc显式查询、ThreadMXBean堆分配及采样heap分别记录：

| 场景 | 成功显式Jdbc/请求 | 分配MiB/请求 | 采样heap增量MiB | JFR逻辑MiB/请求 | 组耗时ms |
|---|---:|---:|---:|---:|---:|
'''+ '\n'.join(rows)+'''

容量只代表2GiB进程内Controller/实际service proxy/FileSystemResource、四张canonical表和手工版本元数据。暖页缓存/稀疏padded PNG、非全预热JIT、Hikari10、64KiB输出校验缓冲和JDBC/断言/JFR开销限制外推。JFR逻辑读取不是物理磁盘IO；allocation和采样heap不含native/direct/RSS/network，不是完整HTTP/RBAC、DHR冻结流程或生产SLA。未以精确heap/延迟门槛要求复现。601产品无下载/SQL/索引性能改动；本质量结果不能覆盖新优化。

本体/知识子角色已FINAL passed，14既有ID为12+9-7有限当前定义核对，本体NA/FINAL成立，无知识或阶段提升。证据子角色已FINAL passed，469机械核对全过：固定e3四盘点重建逐字节一致6604paths/135SQL/464HTTP/216routes；87primary原件stored/raw/source三方及5源码快照一致；ontology12+manifest13一致，manifestSHA `470b0b8adaa2b9e4eb30dd05b0950ced70a4948463919142b6a044b88c4671a2`；25源指纹、330知识+6模型/治理文件与实际e3一致。盘点仍inventory-only/pending，wholeFile0、历史unique未知。默认diff-check仅生成CSV的canonical CRLF提示exit2，原输出保留；命令级cr-at-eol复核其余空白exit0，未修改配置或盘点字节。

全部派发子角色实际FINAL，见roles-final.json。证据分类：当前源码、提交、运行XML/日志、数据库元数据、JFR、原bytes/hash为original-evidence；任务包/旧报告只作secondary-reference索引并回到原件核对；DEC0063原确认属user-confirmed；所有权补偿工程解释及有限调用排除属inference，不提升为新业务政策。

本批只关闭当前已创建原件的登记前写关失败局部问题，不证明完整跨资源原子、崩溃持久对账、重试幂等、共享ACL/引用并发、完整schema/FK/migration/UI/RBAC/tenant/recipient或部署入口认证。两旧DHR high/A12/四gap、原666paths/44knowledge/183ID、W2余项、W3/W4/W5交叉、W6健壮性/性能/A23含旧已审全量、W7增量及朋友签署页/生产弹窗原暂缓保持；原记录控制已实现继续增量审，不写成未实现。不能宣称整审完成。人工merge/deploy，未执行CI/Actions查询或触发、merge/deploy、历史恢复或扫删孤儿。主审仍须在所有FINAL后对实际交付候选做漂移与阶段复核；新组合候选重做fresh质量门禁。

正式结果：/tmp/edhr-dhr-write-qa-quality-result.yaml。原始自有证据与子报告按/tmp/edhr-dhr-write-qa-manifest.json保存路径、raw字节长度及SHA256；清单自身的SHA在最终交接回执给出。
'''
Path(prefix+'-report.md').write_text(report)

# Validate the exact contract fields and enums without changing the repository.
q = yaml.safe_load(result_path.read_text())['qualityResult']
assert set(q) == {'result','baseCommit','headCommit','contractBaseline','workingTreeState','knowledgeBaselineVersion','checks','findings','residualRisks','blockingConditions'}
assert set(q['contractBaseline']) == {'sourceCommit','targetBranch','targetCommit','contractReadCommit','uncommittedContractPaths'}
assert set(q['workingTreeState']) == {'status','includedPaths','excludedPaths','untrackedPaths'}
assert q['result'] == 'passed' and q['checks'] and not q['blockingConditions'] and not q['findings']
for c in q['checks']:
    assert set(c) == {'id','required','category','description','method','command','outcome','evidence'}
    assert type(c['required']) is bool and c['required'] and c['outcome'] == 'passed'
    assert c['category'] in ('requirements','ontology','unit','integration','api','database','audit','security','e2e','visual','regression','documentation')
    assert c['method'] in ('command','inspection','browser','query','automated-test')
for r in q['residualRisks']: assert set(r) == {'id','description','impact','mitigation'}
save('-contract-validation.json', {'status':'FINAL','result':'passed','qualityResultAllFields':True,'checkCount':len(checks),'requiredPassed':len(checks),'findings':0,'blockingConditions':0,'sourceCommit':head,'contractReadCommit':head,'targetCommit':base,'knowledgeBaselineVersion':'0.3.25'})

paths = sorted(p for p in Path('/tmp').glob('edhr-dhr-write-qa*') if p.is_file() and str(p) != prefix+'-manifest.json')
for directory in sorted(p for p in Path('/tmp').glob('edhr-dhr-write-qa*') if p.is_dir()):
    paths += sorted(p for p in directory.rglob('*') if p.is_file())
artifacts = [{'path': str(p), 'rawBytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(set(paths))]
manifest = {'status':'FINAL','result':'passed','baseCommit':base,'headCommit':head,'workingTreeState':'clean','artifactCount':len(artifacts),'totalRawBytes':sum(a['rawBytes'] for a in artifacts),'selfExcluded':'/tmp/edhr-dhr-write-qa-manifest.json (self-hash supplied externally)','artifacts':artifacts}
save('-manifest.json',manifest)
manifest_raw=Path(prefix+'-manifest.json').read_bytes()
print(json.dumps({'status':'FINAL','qualityResult':'passed','baseCommit':base,'headCommit':head,'artifactCount':len(artifacts),'manifestBytes':len(manifest_raw),'manifestSHA256':hashlib.sha256(manifest_raw).hexdigest(),'qualityResultSHA256':hashlib.sha256(result_path.read_bytes()).hexdigest()},indent=2))
