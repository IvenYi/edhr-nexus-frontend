# FINAL：DHR 附件写入补偿独立源码与有限知识复核

本子任务 `passed`，没有新增可复现的中、高或阻断问题。实际受测 HEAD 为 `6012672aa8be4d0d0c8f35a01b0dee0dd4af2882`，base/目标为 `e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae`。实际读取项目、交接和质量契约的提交为受测 HEAD，知识 `0.3.25 / schema 1.2.0`。缓存 `origin/edhr-dev` 为固定 e3；本地 `edhr-dev` 仍为旧 `1185e6da`，没有用它替代目标。本实例及其子实例只读，未参与修复，也没有运行 Maven；运行验收由父 QA 独立归并。

产品全部差异只有 `DhrAttachmentService.java:101` 起的一个局部块。通过脚本将 e3 的原 `Files.write` 单行替换为当前块，得到的字节恰好等于 HEAD 的整个文件。由此确认原 COMMITTED/ROLLED_BACK/UNKNOWN 回调、事务同步 guard、来源元信息、50MiB 含边界及真实 bytes 长度、格式检查、SHA256、资格、核验、unlink 历史保留、冻结成员、下载与 HTTP 权限没有本批改动。

`CREATE_NEW` 取得输出流放在补偿 catch 之前。只有成功创建当前文件后才进入 try-with-resources，因此既有文件/目录的碰撞失败不会执行删除；写入和关闭的 IOException 都经过同一清理路径。清理 IOException 被挂到原错误的 suppressed，并以 ID/path 记录技术日志，最后抛出原错误。后续附件 INSERT 和 LINK 审计不会在这些失败路径执行。它解决当前未登记文件的进程内故障补偿，不改变既有关联及冻结原件的保留政策。

使用实际测试 wrapper 的 Temurin 21.0.12.1 JDK，重新执行 `javap -c -p java.nio.file.Files` 并提取 byte[] `Files.write` 方法。独立提取的 1965 字节与归档原件完全相同，其每次写入上限为 8192。新代码保留该行为，没有任意新增缓冲配置，也没有引入 SQL 循环、集合 N+1、额外 Multipart 字节读取或新的下载实现。原大小预检/真实字节长度、魔数/可读格式解析、SHA 与冻结成员各自有不同的完整性作用，不因 A23 简化目标而删去。

新增 fault 测试的五次执行使用真实文件和输出流，显式注入 IOException；分别断言实际 16 字节残片、完整写入后的关闭失败、真实非空目录导致清理失败及原异常/suppressed/ID/path 日志，还有既有文件与目录碰撞正控。每项同时核无登记/无 LINK、无关原件保持。conditional Answer 在真实 `newOutputStream` 被调用时才包装实际流，避免了首轮静态 stubbing 提前开流的夹具问题。这是受控流故障验证，不是物理磁盘耗尽实验；首轮夹具错误不得作为产品红。

独立有限生产源码搜索只发现 `DhrAttachmentController` 注入的 `service.upload` 是显式上传调用。`DhrSummaryService`、`DhrArchiveService` 和 `DhrReviewController` 是读取方；没有发现生产代码直接 `new DhrAttachmentService` 或内部自调用 upload。因此无事务上传旁路没有被本次源码证实，也没有理由新增全局 guard。这一结果仅覆盖当前显式 typed 源码，不认证反射、动态调用、未来入口、部署拓扑或完整 HTTP 认证。

容量测试的源码与报告边界一致：一个 opt-in JUnit 测试，12 组共 84 请求，直接调用 Controller，经过实际 service proxy 和 FileSystemResource。有效请求完整输出 50MiB 并比较 SHA；损坏请求须在获得响应体之前拒绝。CountingJdbc 只记录成功的显式 JdbcTemplate 调用，JFR 是逻辑文件读取，ThreadMXBean 是线程堆分配，MemoryMXBean 是采样 heap。没有把当前查询次数、堆或延迟硬编码为生产门槛。手工版本元数据、暖页缓存/稀疏 padded PNG、Hikari10、JFR/断言开销及 64KiB 输出校验缓冲均限制结论；不认证完整冻结/HTTP/RBAC/native/direct/RSS/network/物理磁盘 IO 或生产 SLA。本批没有性能实现改动；流式完整 SHA 后再输出和元数据复用仍是下一批讨论。

知识语义子实例已返回 `FINAL passed`。它独立逐 ID 对照 14 个既有记录（12+9-7）的当前原文、DEC-0063-05/10/11/12/13 和原始确认；本体 NA 的工程范围成立。知识、模型及契约从固定 e3 到受测 HEAD 无差异，没有新业务规则、成熟度、可见性、知识版本或阶段提升。机械原件/压缩字节/哈希核验属于并行 evidence inventory 角色，本文不重复宣称执行。

快照与原始结果见 `/tmp/edhr-dhr-write-qa-source-review.json`、`/tmp/edhr-dhr-write-qa-source-snapshots/`、`/tmp/edhr-dhr-write-qa-source-jdk-write-bytecode.txt`、`/tmp/edhr-dhr-write-qa-source-callers.txt`；逐 ID 原文和理由见 `/tmp/edhr-dhr-write-qa-source-knowledge-review.json`。本报告与所有自有产物的原始字节长度及 SHA 在 `/tmp/edhr-dhr-write-qa-source-manifest.json`。

进程崩溃、清理失败/UNKNOWN 的持久对账、跨资源原子与完整重试幂等、共享 ACL/引用并发、完整 schema/FK/migration/UI/RBAC/tenant/recipient 和部署入口认证继续在本切片之外。两项旧 DHR high、A12、四 gap、原 666 路径/44 知识文件/183 ID、W2 余项、W3/W4/W5 交叉、W6 健壮性/性能/A23 含旧已审全量、W7 增量，以及朋友签署页和生产弹窗原暂缓均保留。整文件完成 0，历史唯一新增覆盖未知，不能据本结果宣称整体审计完成。
