import java.nio.file.*;
import java.util.*;
import jdk.jfr.consumer.*;

class EdhrDhrWriteQaJfrReads {
    public static void main(String[] args) throws Exception {
        for (String name : args) {
            Path path = Path.of(name);
            long targetBytes = 0, targetEvents = 0, allFileReadEvents = 0;
            Set<String> targetPaths = new TreeSet<>();
            try (RecordingFile recording = new RecordingFile(path)) {
                while (recording.hasMoreEvents()) {
                    RecordedEvent event = recording.readEvent();
                    if (!event.getEventType().getName().equals("jdk.FileRead")) continue;
                    allFileReadEvents++;
                    String target = event.getString("path");
                    if (target == null || !target.endsWith("/capacity.png")) continue;
                    targetPaths.add(target);
                    targetEvents++;
                    targetBytes += Math.max(0, event.getLong("bytesRead"));
                }
            }
            if (targetPaths.size() != 1 || targetEvents == 0) throw new AssertionError("Missing or ambiguous capacity file events: " + path);
            System.out.println(path.getFileName() + "\t" + targetBytes + "\t" + targetEvents + "\t" + allFileReadEvents + "\t" + targetPaths.iterator().next());
        }
    }
}
