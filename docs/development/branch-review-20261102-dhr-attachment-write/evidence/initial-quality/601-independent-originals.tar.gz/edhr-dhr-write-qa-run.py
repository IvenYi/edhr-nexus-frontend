from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys, time, xml.etree.ElementTree as ET

ROOT = Path('/workspace/edhr-nexus-frontend')
PREFIX = Path('/tmp/edhr-dhr-write-qa')
BASE = 'e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
HEAD = '6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'
CLASSES = 'DhrAttachmentWriteFailureTest,DhrAttachmentTransactionPostgresTest,DhrAttachmentAndArchiveTest,DhrSummaryServiceTest,DhrReviewLifecycleIntegrationTest,FileControllerTest,FileCopyOwnershipTest,FileHttpBoundaryTest,FileUploadResourceTest,FileUploadTransactionIntegrationTest,FileUploadTransactionPostgresTest,FileUploadTransactionFailureTest,FileDeleteTransactionIntegrationTest,FileDeleteTransactionPostgresTest,FileDeleteTransactionFailureTest,DhrFormFilesTest,ExecutionAccessTest'
DBFILE = Path(str(PREFIX) + '-database.json')

def write(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def output(cmd, cwd=ROOT):
    return subprocess.check_output(cmd, cwd=cwd, text=True).strip()

def record_call(label, cmd, cwd=ROOT, env=None):
    start = time.time()
    command = {'argv': cmd, 'cwd': str(cwd), 'startedEpoch': start, 'startedUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'testedHead': output(['git', 'rev-parse', 'HEAD']), 'executionWorktreeHead': output(['git', 'rev-parse', 'HEAD'], cwd), 'workingTreeStatus': output(['git', 'status', '--porcelain=v1']), 'executionWorktreeStatus': output(['git', 'status', '--porcelain=v1'], cwd), 'testDatabase': json.loads(DBFILE.read_text()) if DBFILE.exists() else None}
    write(str(PREFIX) + '-' + label + '-command.json', command)
    with Path(str(PREFIX) + '-' + label + '-test.log').open('wb') as log:
        result = subprocess.run(cmd, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    return result.returncode, start

def collect(label, cwd, classes, start, exitcode):
    reports = cwd / ('tools/knowledge-model/target/surefire-reports' if label == 'knowledge' else 'gmp-platform/backend/target/surefire-reports')
    rows = []; missing = []
    for name in classes:
        paths = list(reports.glob('TEST-' + ('*.' + name if name else '*') + '.xml'))
        if not name:
            paths = list(reports.glob('TEST-*.xml'))
        fresh = [p for p in paths if p.stat().st_mtime >= start]
        if name and len(fresh) != 1:
            missing.append(name); continue
        for path in fresh:
            raw = path.read_bytes()
            stored = Path(str(PREFIX) + '-' + label + '-' + path.name)
            stored.write_bytes(raw)
            tree = ET.fromstring(raw)
            rows.append({'suite': tree.get('name'), **{k: int(tree.get(k, '0')) for k in ['tests', 'failures', 'errors', 'skipped']}, 'sourceMtime': path.stat().st_mtime, 'rawXML': str(stored), 'rawBytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(), 'testcases': [{'name': t.get('name'), 'failureType': t.find('failure').get('type') if t.find('failure') is not None else None, 'errorType': t.find('error').get('type') if t.find('error') is not None else None, 'skipped': t.find('skipped') is not None} for t in tree.findall('testcase')]})
    data = {'exitCode': exitcode, 'missingFreshSuites': missing, 'suites': rows, 'totals': {k: sum(row[k] for row in rows) for k in ['tests', 'failures', 'errors', 'skipped']}}
    write(str(PREFIX) + '-' + label + '-summary.json', data)
    print(json.dumps({'label': label, 'exitCode': exitcode, 'missing': missing, 'totals': data['totals']}, ensure_ascii=False), flush=True)
    return data

def env():
    d = json.loads(DBFILE.read_text()); e = os.environ.copy()
    e.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=d['dhrUrl'], EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres', EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='', EDHR_UPLOAD_TX_DATABASE_URL=d['uploadUrl'], EDHR_UPLOAD_TX_DATABASE_USER='postgres', EDHR_UPLOAD_TX_DATABASE_PASSWORD='')
    return e

def init():
    assert output(['git', 'rev-parse', 'HEAD']) == HEAD
    assert not output(['git', 'status', '--porcelain=v1'])
    name = 'edhr-dhr-write-qa-' + str(os.getpid()) + '-' + str(int(time.time()))
    cmds = []
    def call(cmd):
        r = subprocess.run(cmd, capture_output=True, text=True)
        cmds.append({'argv': cmd, 'exitCode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
        if r.returncode: raise RuntimeError(r.stderr)
        return r.stdout.strip()
    try:
        cid = call(['docker', 'run', '-d', '--name', name, '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', '-e', 'POSTGRES_DB=edhr_dhr_attachment_transaction_test', '-p', '127.0.0.1::5432', 'postgres:16-alpine'])
        port = call(['docker', 'port', name, '5432/tcp']).split(':')[-1]
        end = time.monotonic() + 55
        while True:
            ready = subprocess.run(['docker', 'exec', name, 'pg_isready', '-h', '127.0.0.1', '-p', '5432', '-U', 'postgres', '-d', 'edhr_dhr_attachment_transaction_test'], capture_output=True, text=True)
            cmds.append({'argv': ready.args, 'exitCode': ready.returncode, 'stdout': ready.stdout, 'stderr': ready.stderr})
            if ready.returncode == 0: break
            if time.monotonic() > end: raise RuntimeError('final TCP PostgreSQL not ready')
            time.sleep(.5)
        call(['docker', 'exec', name, 'createdb', '-h', '127.0.0.1', '-U', 'postgres', 'edhr_upload_transaction_test'])
        metadata = call(['docker', 'exec', name, 'psql', '-h', '127.0.0.1', '-U', 'postgres', '-d', 'edhr_dhr_attachment_transaction_test', '-XAt', '-c', "SELECT version(); SELECT datname || ':' || datcollate || ':' || datctype FROM pg_database WHERE datname IN ('edhr_dhr_attachment_transaction_test','edhr_upload_transaction_test') ORDER BY datname; SHOW server_encoding; SHOW timezone;"])
        d = {'containerName': name, 'containerId': cid, 'image': 'postgres:16-alpine', 'binding': '127.0.0.1:' + port, 'dhrUrl': 'jdbc:postgresql://127.0.0.1:' + port + '/edhr_dhr_attachment_transaction_test', 'uploadUrl': 'jdbc:postgresql://127.0.0.1:' + port + '/edhr_upload_transaction_test', 'username': 'postgres', 'password': '', 'metadata': metadata, 'commands': cmds}
        write(DBFILE, d); print(json.dumps(d), flush=True)
    except BaseException:
        write(str(PREFIX) + '-database-init-failure.json', cmds)
        subprocess.run(['docker', 'stop', '-t', '10', name], capture_output=True)
        subprocess.run(['docker', 'rm', name], capture_output=True)
        raise

def test(label):
    classes = CLASSES if label == 'main' else 'DhrAttachmentDownloadCapacityPostgresTest'
    e = env(); cmd = ['bash', '/workspace/.edhr-cloud-tools/mvn-edhr', '-f', 'gmp-platform/backend/pom.xml', '-Dtest=' + classes]
    if label == 'capacity':
        out = Path('/tmp/edhr-dhr-write-qa-capacity')
        out.mkdir(exist_ok=False)
        e['EDHR_ATTACHMENT_CAPACITY_OUTPUT'] = str(out); cmd.append('-DargLine=-Xmx2g')
    cmd.append('test')
    rc, start = record_call(label, cmd, env=e)
    summary = collect(label, ROOT, classes.split(','), start, rc)
    assert rc == 0 and not summary['missingFreshSuites']
    assert summary['totals'] == {'tests': 127 if label == 'main' else 1, 'failures': 0, 'errors': 0, 'skipped': 0}

def knowledge():
    cmd = ['bash', '/workspace/.edhr-cloud-tools/mvn-edhr', '-f', 'tools/knowledge-model/pom.xml', 'test']
    rc, start = record_call('knowledge', cmd)
    summary = collect('knowledge', ROOT, [''], start, rc)
    assert rc == 0 and summary['totals'] == {'tests': 89, 'failures': 0, 'errors': 0, 'skipped': 0}

def old():
    cwd = Path('/tmp/edhr-dhr-write-qa-old-worktree')
    assert not cwd.exists()
    testpath = Path('gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentWriteFailureTest.java')
    raw = (ROOT / testpath).read_bytes()
    setup = []
    try:
        r = subprocess.run(['git', 'worktree', 'add', '--detach', str(cwd), BASE], cwd=ROOT, capture_output=True, text=True)
        setup.append({'argv': r.args, 'exitCode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr}); r.check_returncode()
        assert output(['git', 'rev-parse', 'HEAD'], cwd) == BASE
        assert not output(['git', 'status', '--porcelain=v1'], cwd)
        (cwd / testpath).write_bytes(raw)
        Path(str(PREFIX) + '-old-exact-DhrAttachmentWriteFailureTest.java').write_bytes(raw)
        (cwd / 'gmp-platform/frontend/node_modules').symlink_to(ROOT / 'gmp-platform/frontend/node_modules', target_is_directory=True)
        setup.append({'copiedTestBytes': len(raw), 'copiedTestSHA256': hashlib.sha256(raw).hexdigest(), 'exactGitBlobSHA256': hashlib.sha256(subprocess.check_output(['git', 'show', HEAD + ':' + str(testpath)], cwd=ROOT)).hexdigest(), 'testBytesMatch': raw == subprocess.check_output(['git', 'show', HEAD + ':' + str(testpath)], cwd=ROOT), 'productDiff': output(['git', 'diff', '--', 'gmp-platform/backend/src/main'], cwd), 'status': output(['git', 'status', '--porcelain=v1'], cwd)})
        write(str(PREFIX) + '-old-setup.json', setup)
        cmd = ['bash', '/workspace/.edhr-cloud-tools/mvn-edhr', '-f', 'gmp-platform/backend/pom.xml', '-Dtest=DhrAttachmentWriteFailureTest', 'test']
        rc, start = record_call('old', cmd, cwd)
        data = collect('old', cwd, ['DhrAttachmentWriteFailureTest'], start, rc)
        assert data['totals'] == {'tests': 5, 'failures': 3, 'errors': 0, 'skipped': 0}
        assert rc != 0 and all(not t['errorType'] and not t['skipped'] for t in data['suites'][0]['testcases'])
    finally:
        if cwd.exists():
            (cwd / testpath).unlink(missing_ok=True)
            link = cwd / 'gmp-platform/frontend/node_modules'
            if link.is_symlink(): link.unlink()
            r = subprocess.run(['git', 'worktree', 'remove', str(cwd)], cwd=ROOT, capture_output=True, text=True)
            write(str(PREFIX) + '-old-cleanup.json', {'argv': r.args, 'exitCode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr, 'worktreeExists': cwd.exists()})
            r.check_returncode()

def cleanup():
    d = json.loads(DBFILE.read_text()); name = d['containerName']
    calls = []
    for cmd in [['docker', 'stop', '-t', '10', name], ['docker', 'rm', name]]:
        r = subprocess.run(cmd, capture_output=True, text=True)
        calls.append({'argv': cmd, 'exitCode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
    calls.append({'headAfter': output(['git', 'rev-parse', 'HEAD']), 'statusAfter': output(['git', 'status', '--porcelain=v1']), 'remainingOwnContainer': subprocess.run(['docker', 'ps', '-a', '--filter', 'name=^/' + name + '$', '--format', '{{.ID}}'], capture_output=True, text=True).stdout.strip()})
    write(str(PREFIX) + '-cleanup.json', calls)
    print(json.dumps(calls), flush=True)

if __name__ == '__main__':
    action = sys.argv[1]
    if action == 'init': init()
    elif action in ('main', 'capacity'): test(action)
    elif action == 'knowledge': knowledge()
    elif action == 'old': old()
    elif action == 'cleanup': cleanup()
    else: raise SystemExit(action)
