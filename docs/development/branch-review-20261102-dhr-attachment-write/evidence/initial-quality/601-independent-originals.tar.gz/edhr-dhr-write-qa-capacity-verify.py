from pathlib import Path
import json, subprocess, hashlib, datetime

directory = Path('/tmp/edhr-dhr-write-qa-capacity')
prefix = '/tmp/edhr-dhr-write-qa-capacity'
raw = directory / 'capacity.json'
report = json.loads(raw.read_text())
assert report['completed'] is True
assert report['bytesPerFile'] == 52428800
assert len(report['cases']) == 12
jfrs = sorted(directory.glob('*.jfr'))
reads = sorted(directory.glob('*-reads.json'))
assert len(jfrs) == len(reads) == 12
cmd = ['/workspace/.edhr-cloud-tools/jdk-21/bin/java', '/tmp/edhr-dhr-write-qa-JfrReads.java', *map(str, jfrs)]
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = subprocess.run(cmd, capture_output=True, text=True)
Path(prefix + '-independent-jfr.tsv').write_text(p.stdout)
Path(prefix + '-independent-jfr.stderr').write_text(p.stderr)
Path(prefix + '-independent-jfr-command.json').write_text(json.dumps({'argv': cmd, 'startedUTC': started, 'exitCode': p.returncode}, indent=2) + '\n')
p.check_returncode()
independent = {}
for line in p.stdout.splitlines():
    name, size, events, all_events, original = line.split('\t')
    independent[name[:-4]] = {'targetFileReadBytes': int(size), 'fileReadEvents': int(events), 'allFileReadEvents': int(all_events), 'targetPath': original}
rows = []; request_count = good = corrupt = 0
for case in report['cases']:
    label = case['label']; n = case['concurrency']; requests = case['requests']; request_count += len(requests)
    assert n in (1, 4, 16) and len(requests) == n
    assert label == ('frozen' if case['frozen'] else 'current') + ('-corrupt-' if case['corrupt'] else '-good-') + str(n)
    expected_queries = 4 + int(case['frozen']) + int(not case['corrupt'])
    for request in requests:
        assert request['allocatedBytes'] > 0
        assert request['rejectedBeforeBody'] is case['corrupt']
        assert request['bodyBytes'] == (0 if case['corrupt'] else 52428800)
        assert len(request['jdbcQueries']) == expected_queries
        assert all(isinstance(sql, str) and sql.strip() for sql in request['jdbcQueries'])
    good += 0 if case['corrupt'] else n
    corrupt += n if case['corrupt'] else 0
    stored = json.loads((directory / (label + '-reads.json')).read_text())
    observed = independent[label]
    assert stored['measurementAvailable']
    assert stored['targetFileReadBytes'] == observed['targetFileReadBytes']
    assert stored['fileReadEvents'] == observed['fileReadEvents']
    rows.append({'label': label, 'requests': n, 'successfulExplicitJdbcQueriesPerRequest': expected_queries, 'allocatedMiBRange': [min(r['allocatedBytes'] for r in requests) / 1048576, max(r['allocatedBytes'] for r in requests) / 1048576], 'sampledHeapIncreaseMiB': case['sampledHeapIncreaseBytes'] / 1048576, 'wallMillis': case['wallMillis'], 'jfrTargetLogicalMiBPerRequest': observed['targetFileReadBytes'] / n / 1048576, 'independentJfr': observed, 'outputBytesPerRequest': 0 if case['corrupt'] else 52428800, 'rejectedBeforeBody': case['corrupt']})
assert request_count == 84 and good == corrupt == 42
data = {'status': 'FINAL', 'result': 'passed', 'capacityJsonBytes': raw.stat().st_size, 'capacityJsonSHA256': hashlib.sha256(raw.read_bytes()).hexdigest(), 'groups': 12, 'requests': request_count, 'validFullBodySHAAssertionsPassed': good, 'corruptRejectedBeforeBody': corrupt, 'rawJfrFiles': len(jfrs), 'rawReadSummaries': len(reads), 'independentJfrParserExitCode': p.returncode, 'rows': rows, 'measurementBoundaries': ['One JUnit test, twelve groups, eighty-four requests; not additive independent business tests.', 'Every successful request body length and SHA256 were asserted by exact committed test; temporary original/body are not retained.', 'Successful explicit JdbcTemplate calls only; no driver/transaction setup count.', 'JFR Java logical file read bytes, not physical disk IO; independently parsed with RecordingFile.', 'ThreadMXBean heap allocation and sampled MemoryMXBean heap; no native/direct/RSS/network.', 'Warm page cache, synthetic sparse padded PNG, not fully warmed JIT, Hikari10, 64KiB body validation buffer and assertion/JFR sampling costs.', '2GiB JVM in-process Controller/proxy/service/resource with four canonical table fixtures; no HTTP/RBAC/deployment/production SLA certification.', 'No exact heap or latency acceptance threshold and no performance implementation change.']}
Path(prefix + '-verification.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps({k: data[k] for k in ('status','result','groups','requests','validFullBodySHAAssertionsPassed','corruptRejectedBeforeBody','rawJfrFiles','rawReadSummaries')}, indent=2))
for row in rows:
    print(row['label'], row['successfulExplicitJdbcQueriesPerRequest'], row['allocatedMiBRange'], row['sampledHeapIncreaseMiB'], row['jfrTargetLogicalMiBPerRequest'], row['wallMillis'])
