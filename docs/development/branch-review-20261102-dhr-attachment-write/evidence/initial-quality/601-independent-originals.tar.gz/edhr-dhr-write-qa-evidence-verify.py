from pathlib import Path
import collections
import csv
import datetime
import gzip
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/edhr-nexus-frontend')
BASE = 'e3e49784eda6bc01e7e5c686d6f79dc5a600d5ae'
HEAD = '6012672aa8be4d0d0c8f35a01b0dee0dd4af2882'
PKG = ROOT / 'docs/development/branch-review-20261102-dhr-attachment-write'
PREFIX = Path('/tmp/edhr-dhr-write-qa-evidence')
INV = Path(str(PREFIX) + '-inventory')
commands = []
checks = []

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def run(argv, name):
    start = now()
    result = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = Path(str(PREFIX) + '-' + name + '-stdout.txt')
    err = Path(str(PREFIX) + '-' + name + '-stderr.txt')
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    commands.append({'argv': argv, 'cwd': str(ROOT), 'startedAt': start, 'finishedAt': now(),
                     'exitCode': result.returncode, 'stdout': str(out), 'stderr': str(err)})
    return result

def git_bytes(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, stderr=subprocess.DEVNULL)

def fact(kind, path, **more):
    item = {'kind': kind, 'path': str(path), **more}
    checks.append(item)
    return item

start_status = git_bytes('status', '--porcelain').decode()
actual_head = git_bytes('rev-parse', 'HEAD').decode().strip()
assert start_status == '' and actual_head == HEAD
build_script = ROOT / 'scripts/build-branch-review-inventory.py'
assert build_script.read_bytes() == git_bytes('show', BASE + ':scripts/build-branch-review-inventory.py')
assert not INV.exists(), 'Fresh inventory output required'
build = run(['python3', str(build_script), '--ref', BASE, '--out', str(INV)], 'inventory-build')
assert build.returncode == 0
for name in ['coverage.csv', 'entrypoints.csv', 'migrations.csv', 'inventory-summary.json']:
    actual = (INV/name).read_bytes()
    expected = (PKG/'inventory'/name).read_bytes()
    fact('inventory-byte-comparison', name, bytes=len(actual), sha256=sha(actual),
         expectedSha256=sha(expected), passed=actual == expected)
    assert actual == expected, name
inventory = json.loads((INV/'inventory-summary.json').read_bytes())
assert inventory['sourceCommit'] == BASE and inventory['trackedPaths'] == 6604
assert inventory['migrationFiles'] == 135
assert inventory['entrypointCandidates']['http-annotation'] == 464
assert inventory['entrypointCandidates']['frontend-route-candidate'] == 216
assert inventory['semanticReviewComplete'] is False
rows = list(csv.DictReader((INV/'coverage.csv').open()))
assert len(rows) == 6604 and all(r['review_depth'] == 'inventory-only' and r['review_status'] == 'pending' for r in rows)
assert {r['path'] for r in rows} == {p.decode() for p in git_bytes('ls-tree','-rz','--name-only',BASE).split(b'\0') if p}

primary = json.loads((PKG/'evidence-manifest.json').read_bytes())
assert primary['baseCommit'] == BASE and len(primary['artifacts']) == 87 and len(primary['sourceSnapshot']) == 5
for item in primary['artifacts']:
    stored_path = PKG/item['path']
    stored = stored_path.read_bytes()
    raw = gzip.decompress(stored) if item['compression'] == 'gzip' else stored
    original = Path(item['sourcePath']).read_bytes()
    passed = (len(stored) == item['storedBytes'] and sha(stored) == item['storedSha256']
              and len(raw) == item['rawBytes'] and sha(raw) == item['rawSha256'] and raw == original)
    fact('primary-raw-stored-original', item['path'], sourcePath=item['sourcePath'],
         rawBytes=len(raw), rawSha256=sha(raw), storedBytes=len(stored), storedSha256=sha(stored),
         sourceBytes=len(original), sourceSha256=sha(original), stage=item['stage'], passed=passed)
    assert passed, item['path']
assert {str(p.relative_to(PKG)) for p in (PKG/'evidence').rglob('*') if p.is_file()} == {i['path'] for i in primary['artifacts']}
for item in primary['sourceSnapshot']:
    raw = (ROOT/item['path']).read_bytes()
    passed = len(raw) == item['bytes'] and sha(raw) == item['sha256'] and raw == git_bytes('show',HEAD+':'+item['path'])
    fact('primary-source-snapshot', item['path'], bytes=len(raw), sha256=sha(raw), passed=passed)
    assert passed, item['path']

ontology_dir = PKG/'evidence/ontology'
ontology_manifest_path = ontology_dir/'edhr-dhr-write-ontology-manifest.json'
ontology_manifest_raw = ontology_manifest_path.read_bytes()
expected_ontology_manifest_sha = '470b0b8adaa2b9e4eb30dd05b0950ced70a4948463919142b6a044b88c4671a2'
assert sha(ontology_manifest_raw) == expected_ontology_manifest_sha
assert ontology_manifest_raw == Path('/tmp/edhr-dhr-write-ontology-manifest.json').read_bytes()
ontology_manifest = json.loads(ontology_manifest_raw)
assert ontology_manifest['status'] == 'FINAL' and len(ontology_manifest['files']) == 12
for item in ontology_manifest['files']:
    raw = Path(item['path']).read_bytes()
    entry = next(a for a in primary['artifacts'] if a['sourcePath'] == item['path'])
    stored = (PKG/entry['path']).read_bytes()
    archived_raw = gzip.decompress(stored) if entry['compression'] == 'gzip' else stored
    passed = len(raw) == item['bytes'] and sha(raw) == item['sha256'] and raw == archived_raw
    fact('ontology-raw-archived', item['path'], bytes=len(raw), sha256=sha(raw), passed=passed)
    assert passed, item['path']
assert len([a for a in primary['artifacts'] if a['stage'] == 'ontology']) == 13
ontology_text = (ontology_dir/'edhr-dhr-write-ontology-result.yaml').read_text()
assert 'result: not-applicable' in ontology_text and 'baselineBefore: 0.3.25' in ontology_text and 'baselineAfter: 0.3.25' in ontology_text

fingerprints = json.loads((ontology_dir/'edhr-dhr-write-ontology-source-fingerprints.json').read_bytes())
assert len(fingerprints['files']) == 25
for item in fingerprints['files']:
    raw = (ROOT/item['path']).read_bytes()
    try:
        base_raw = git_bytes('show',BASE+':'+item['path'])
        matches_base = raw == base_raw
    except subprocess.CalledProcessError:
        matches_base = False
    passed = len(raw) == item['bytes'] and sha(raw) == item['sha256'] and matches_base == item['matchesSourceCommit']
    fact('ontology-source-fingerprint', item['path'], bytes=len(raw), sha256=sha(raw), matchesBase=matches_base, passed=passed)
    assert passed, item['path']

knowledge = json.loads((ontology_dir/'edhr-dhr-write-ontology-knowledge-inventory.json').read_bytes())
assert knowledge['knowledgeFileCount'] == 330 and len(knowledge['knowledge']) == 330
assert knowledge['knowledgeModelVersion'] == '0.3.25' and knowledge['schemaVersion'] == '1.2.0'
base_knowledge_paths = {p.decode() for p in git_bytes('ls-tree','-rz','--name-only',BASE,'docs/knowledge').split(b'\0') if p}
head_knowledge_paths = {p.decode() for p in git_bytes('ls-tree','-rz','--name-only',HEAD,'docs/knowledge').split(b'\0') if p}
inventory_paths = {i['path'] for i in knowledge['knowledge']}
assert base_knowledge_paths == head_knowledge_paths == inventory_paths
assert len(knowledge['businessModelAndContracts']) == 6
for item in knowledge['knowledge'] + knowledge['businessModelAndContracts']:
    raw = (ROOT/item['path']).read_bytes()
    base_raw = git_bytes('show',BASE+':'+item['path'])
    passed = (len(raw) == item['bytes'] and sha(raw) == item['sha256'] and sha(base_raw) == item['baseSha256']
              and raw == base_raw and item['matchesBase'] is True)
    fact('knowledge-or-contract-byte-provenance', item['path'], bytes=len(raw), sha256=sha(raw), baseSha256=sha(base_raw), passed=passed)
    assert passed, item['path']

end_status = git_bytes('status','--porcelain').decode()
assert end_status == '' and git_bytes('rev-parse','HEAD').decode().strip() == HEAD
summary = {
    'status': 'FINAL', 'result': 'passed', 'capturedAt': now(), 'baseCommit': BASE, 'headCommit': HEAD,
    'contractBaseline': {'sourceCommit': HEAD, 'targetBranch': 'edhr-dev', 'targetCommit': BASE,
                         'contractReadCommit': HEAD, 'uncommittedContractPaths': []},
    'workingTreeState': {'status': 'clean', 'includedPaths': [], 'excludedPaths': [], 'untrackedPaths': []},
    'inventory': inventory, 'inventoryByteIdenticalFiles': 4,
    'wholeFileSemanticReviewCount': 0, 'newHistoricalUniqueCoverage': 'unknown',
    'primaryArtifacts': len(primary['artifacts']), 'primarySourceSnapshots': len(primary['sourceSnapshot']),
    'stages': dict(collections.Counter(i['stage'] for i in primary['artifacts'])),
    'ontologyFiles': 12, 'ontologyIncludingManifest': 13, 'ontologyManifestSha256': sha(ontology_manifest_raw),
    'ontologySourceFingerprints': len(fingerprints['files']), 'knowledgeFileCount': 330,
    'businessModelAndContracts': 6, 'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0',
    'checksCount': len(checks), 'allChecksPassed': all(c['passed'] for c in checks),
    'findings': [], 'boundary': 'Byte provenance/inventory only; no all-ID semantics, route execution, migration application or overall W0-W7 completion claimed.'
}
write_json(Path(str(PREFIX)+'-verification.json'), {'summary': summary, 'checks': checks})
write_json(Path(str(PREFIX)+'-commands.json'), commands)
Path(str(PREFIX)+'-report.md').write_text(
    '# Independent evidence and inventory verification\n\n'
    f'FINAL passed at clean `{HEAD}` against `{BASE}`. No repository writes or Maven runs.\n\n'
    'Rebuilt the fixed e3 inventory with the unchanged versioned generator into a fresh /tmp directory. '
    'All four outputs are byte-identical: 6604 paths, 135 migration files, 464 HTTP annotation candidates, '
    '216 frontend route candidates. All coverage rows remain inventory-only/pending; whole-file semantics = 0, '
    'new historical unique coverage is unknown.\n\n'
    'Verified all 87 primary artifacts against stored byte counts/SHA256, decompressed byte counts/SHA256, '
    'and their retained /tmp originals, plus all 5 source snapshots against current committed bytes. '
    'The evidence directory has neither missing nor unlisted files. Verified ontology FINAL manifest '
    'SHA256 '+sha(ontology_manifest_raw)+' and its 12 raw entries (13 including manifest). '
    'The ontology result remains not-applicable at 0.3.25.\n\n'
    'Verified all 25 ontology source fingerprints against current source bytes and source-base matching flags. '
    'All 330 knowledge files and 6 business-model/governance files match both their recorded hashes and actual e3 '
    'bytes; path sets match and knowledge/schema versions remain 0.3.25/1.2.0.\n\n'
    'This mechanical verification does not substitute for source/semantic review or close any old high/A12/four-gap, '
    '666-path/44-knowledge/183-ID, W2/W3/W4/W5/W6/W7, account/UI/RBAC/recipient or concurrency queues. '
    'Historical fixture failures and repeated old-base stages remain separate evidence, not additive unique coverage.\n'
)
manifest_files = []
for path in sorted(Path('/tmp').glob('edhr-dhr-write-qa-evidence-*')):
    candidates = path.rglob('*') if path.is_dir() else [path]
    for file in sorted(candidates):
        if file.is_file() and file.name != 'edhr-dhr-write-qa-evidence-manifest.json':
            raw = file.read_bytes()
            manifest_files.append({'path': str(file), 'rawBytes': len(raw), 'rawSha256': sha(raw)})
write_json(Path(str(PREFIX)+'-manifest.json'), {'status':'FINAL', 'files': manifest_files})
print(json.dumps(summary, ensure_ascii=False))
