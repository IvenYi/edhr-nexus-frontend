from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys
import yaml

OUT = Path('/tmp/edhr-export-ontology-20261105')
ROOT = Path('/workspace/edhr-nexus-frontend')
BASE = '5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
mode = sys.argv[1]
def sha(data):
    return hashlib.sha256(data).hexdigest()
def nested_ids(value):
    found={}
    if isinstance(value,dict):
        if isinstance(value.get('id'),str): found[value['id']]=value
        for v in value.values(): found.update(nested_ids(v))
    elif isinstance(value,list):
        for v in value: found.update(nested_ids(v))
    return found
if mode == 'finite':
    records=[json.loads(s) for s in (OUT/'finite-audit-records.jsonl').read_text().splitlines()]
    assert len(records)==20 and len(set(r['id'] for r in records))==20
    for r in records:
        assert r['reviewStatus']=='reviewed'
        assert r['conclusion'] in {'consistent','evidence-gap'}
        assert r['sourceCommit']==BASE
        assert r['runtimeValidation']=='not-executed-by-this-role'
        assert r['maturityChange'] is False
        p=ROOT/r['sourcePath']
        assert p.is_file()
        if not r['id'].startswith('file:'):
            record=nested_ids(yaml.safe_load(p.read_text()))[r['id']]
            if record.get('status') is not None:
                assert record['status']==r['originalMaturity']['status']
            if record.get('visibility') is not None:
                assert record['visibility']==r['originalMaturity']['visibility']
        for evidence in r['evidenceReferences']:
            path,n=evidence.rsplit(':',1)
            source=ROOT/path
            assert source.is_file(), evidence
            assert 1 <= int(n) <= len(source.read_text().splitlines()), evidence
    print('PASS finite inventory: 20 reviewed records (19 stable IDs + 1 support Markdown); 18 finite consistent, 2 explicit acceptance evidence gaps; source IDs, declared maturity and evidence line paths resolve. This is not a knowledge-schema or runtime test.')
elif mode == 'baseline':
    for name in ['HEAD','origin/edhr-dev']:
        assert subprocess.check_output(['git','rev-parse',name],cwd=ROOT,text=True).strip()==BASE
    fingerprint=json.loads((OUT/'knowledge-fingerprint-inventory.json').read_text())
    assert fingerprint['fileCount']==350
    for entry in fingerprint['files']:
        data=(ROOT/entry['path']).read_bytes()
        base=subprocess.check_output(['git','show',BASE+':'+entry['path']],cwd=ROOT)
        assert data==base and sha(data)==entry['sha256']
    for entry in json.loads((OUT/'source-snapshot-manifest.json').read_text()):
        data=(ROOT/entry['path']).read_bytes()
        assert sha(data)==entry['sha256']
        assert data==(OUT/'snapshot'/entry['path']).read_bytes()
        if entry['trackedAtBaseline']:
            assert entry['baselineBytesEqual'] is True
    protected=['gmp-platform/backend/src/main','gmp-platform/frontend/src','docs/knowledge','AGENTS.md','docs/agents','docs/architecture']
    changed=subprocess.check_output(['git','diff','--name-only',BASE,'--',*protected],cwd=ROOT,text=True).strip()
    assert not changed
    print('PASS baseline/source-byte boundary: HEAD=origin/edhr-dev=5bfd96ff1e10a665a41db8fdf88352f65b1288a3; all 350 knowledge files byte-identical to baseline, 28 scoped raw snapshots resolve, protected product/knowledge/contracts unchanged. Fingerprints are inventory only, not 350-file semantic audit.')
elif mode == 'result':
    r=yaml.safe_load((OUT/'ontologyResult.yaml').read_text())['ontologyResult']
    required={'result','baselineBefore','baselineAfter','contractBaseline','reason','changedArtifacts','knowledgeSync','conflicts','questions','validationEvidence','roadmapProgress'}
    assert set(r)==required
    assert r['result']=='not-applicable'
    assert r['baselineBefore']==r['baselineAfter']=='0.3.25'
    assert all(r[k]==[] for k in ['changedArtifacts','knowledgeSync','conflicts','questions'])
    assert r['contractBaseline']=={'sourceCommit':BASE,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[]}
    for v in r['validationEvidence']:
        assert v['checkType'] in {'schema','reference','status-transition','projection','evidence-path'}
        assert v['outcome']=='passed'
    assert r['roadmapProgress']=={'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
    print('PASS local handoff-format assertion: exact ontologyResult fields/enums and unchanged maturity/baseline. This local assertion is not the formal BusinessKnowledgeModelTest or a project CI gate.')
else:
    raise SystemExit('mode must be finite/baseline/result')
