from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import yaml

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-export-ontology-20261105')
BASE = '5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
CHILD = Path('/tmp/edhr-export-number-signature-20261105')
DEC = 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml'
RULE = 'docs/knowledge/rules/dhr-summary.yaml'
ANCHOR = 'docs/knowledge/implementation-anchors/dhr-summary.yaml'
EV = 'docs/knowledge/evidence/dhr-summary.yaml'
MD = 'docs/knowledge/evidence/dhr-summary-user-confirmed.md'
ARCHIVE = 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java'
FILES = 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java'
INTEGRITY = 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java'
PDF = 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrPdfRenderer.java'
CONTROLLER = 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java'
PACK = 'docs/development/branch-review-20261105-dhr-export/decision-package.yaml'
DEC90 = 'docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml'

OUT.mkdir(parents=True, exist_ok=True)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
def digest(data):
    return hashlib.sha256(data).hexdigest()
def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
def line(path, record_id):
    for n, value in enumerate((ROOT/path).read_text().splitlines(), 1):
        if value.strip() == '- id: ' + record_id:
            return n
    return 1
def ref(path, n):
    return f'{path}:{n}'
records = []
def add(rid, typ, path, locator, detail, evidence, scope, conclusion='consistent', maturity=None):
    records.append({
        'id': rid, 'recordType': typ, 'sourcePath': path,
        'sourceLocator': f'{locator}; line {line(path, rid)}',
        'sourceCommit': BASE,
        'originalMaturity': maturity if maturity is not None else {'status':'specified', 'visibility':'internal'},
        'auditScopeClassification': 'finite-dhr-export-read-only',
        'auditScope': scope,
        'reviewStatus':'reviewed', 'conclusion':conclusion,
        'conclusionDetail':detail,
        'evidenceReferences':evidence,
        'runtimeValidation':'not-executed-by-this-role',
        'maturityChange':False,
    })
def dec(rid, detail, evidence, scope):
    add(rid, 'decisionStatement', DEC, f'decisions[id=DEC-0063].decisionStatements[id={rid}]', detail, evidence, scope)

dec('DEC-0063-05',
    '本次新增读取观察不触及 submit/START 或修订写入；实际 export 以 dhrId/versionId 查询冻结候选、附件及目录，独立证据行与版本摘要校验后继续，不用实时表单填补。结论只覆盖本次只读消费者，不能认证完整冻结创建或并发链。',
    [ref(ARCHIVE,49),ref(ARCHIVE,58),ref(ARCHIVE,82),ref(INTEGRITY,27),ref(INTEGRITY,57)],
    '显式版本读取与独立冻结摘要边界；不复验创建/提交/START、历史迁移或完整审批')
dec('DEC-0063-10',
    '实际导出读取冻结附件身份和原件，并比对冻结 size/SHA256；表单原件读取校验类型、生产对象、cutoff、size/MD5。附件字节独立入 ZIP、PDF仅列索引，未加入 Office 转换。测试容量不是新的50MiB政策或上传路径验收。',
    [ref(ARCHIVE,131),ref(ARCHIVE,144),ref(ARCHIVE,146),ref(FILES,94),ref(FILES,108)],
    '本次原件读取与不转换边界；上传7格式/50MiB、核验/解除及全部权限不由本项验收')
dec('DEC-0063-11',
    'FULL 取本版全部冻结ID；SELECTED必须非空且为本版成员，输出显式非完整标识。目录排序完整对照、原件缺失/摘要失配均失败；附件独立、同版表单PDF和追溯资料沿现契约。PDF生命周期和容量测试仅为工程证据，不新增命名截断规则或自动打印流程。',
    [ref(ARCHIVE,65),ref(ARCHIVE,104),ref(ARCHIVE,115),ref(ARCHIVE,120),ref(ARCHIVE,139),ref(ARCHIVE,146),ref(ARCHIVE,179)],
    'FULL/SELECTED同版/原件/顺序/范围说明源码；完整中文分页版式和浏览器交互须独立实际验收')
dec('DEC-0063-15',
    '来源执行审计与签名按真实 productionObjectId 和提交时点读取；来源/审批签名均先校验保存的UTF8原文摘要。SELECTED保留对象级身份/时间/摘要索引并清除可能含未选字段的原始载荷，明确非实例独占，不改变原冻结/审批对象。只读资源观察没有重新建签名或复原坏历史。',
    [ref(ARCHIVE,155),ref(ARCHIVE,160),ref(ARCHIVE,164),ref(ARCHIVE,231),ref(ARCHIVE,247),ref(ARCHIVE,266)],
    '来源追溯/审批签名读取与选定范围原始载荷排除；不宣称客户端收妥或全部外部记录控制事件完备')
dec('DEC-0063-16',
    '当前PDF/ZIP仍按指定版冻结候选输出，本批不按后续作废状态过滤或改写旧冻结。用户暂缓的打印过滤设计不被资源观察、mock打印器容量或既有PDF测试关闭。',
    [ref(ARCHIVE,58),ref(ARCHIVE,106),ref(ARCHIVE,117),ref(PACK,1)],
    '作废后历史冻结与打印过滤暂缓边界；不审核常规UI的默认隐藏或未来打印政策')
add('rule.dhr-summary-freeze-version','rule',RULE,'rules[id=rule.dhr-summary-freeze-version]',
    '规则的same frozen content/不可后改语义与实际只读export和FrozenEvidenceIntegrity一致；本批没有修改规则、冻结算法或写路径。实际冻结创建/修订、普通账号完整权限矩阵仍属原验收队列。',
    [ref(DEC,line(DEC,'DEC-0063-05')),ref(ARCHIVE,51),ref(INTEGRITY,27),ref(INTEGRITY,57)],
    '显式冻结读取消费者；不把直接持久化测试夹具当成提交/START业务证据')
add('rule.dhr-summary-zip-source-trace','rule',RULE,'rules[id=rule.dhr-summary-zip-source-trace]',
    '本批只对既有冻结ZIP读者、文件读取和流生命周期取证；实际成员限制、源分类、附件原件独立、校验失败拒绝、FULL/SELECTED追溯与明示边界均可定位。资源成本是待实测工程风险，不能凭SQL数或mock容量设业务限额。',
    [ref(DEC,line(DEC,'DEC-0063-11')),ref(DEC,line(DEC,'DEC-0063-15')),ref(ARCHIVE,49),ref(ARCHIVE,120),ref(ARCHIVE,160),ref(FILES,29),ref(CONTROLLER,26)],
    '同版冻结ZIP与工程观察的规范边界；保持specified/internal，不声明整体合规或生产SLA')
add('anchor.dhr-summary-immutable-version','implementationAnchor',ANCHOR,'implementationAnchors[id=anchor.dhr-summary-immutable-version]',
    '锚点已明确旧冻结、修订草稿与原生Java验收边界；代码引用FrozenEvidenceIntegrity仍对应当前只读导出完整性校验。未更新capturedAt/sourceRevision或将旧UI证据当新ZIP验收。',
    [ref(ANCHOR,17),ref(INTEGRITY,27),ref(INTEGRITY,57),ref(ARCHIVE,59)],
    '本批使用的冻结完整性实现锚点；提交/修订及迁移历史证据保持其原范围')
add('anchor.dhr-summary-zip-source-trace','implementationAnchor',ANCHOR,'implementationAnchors[id=anchor.dhr-summary-zip-source-trace]',
    '实际DhrArchiveService及GET路由可定位，原文本签名存储说明仍保留旧坏签名不恢复和未验收打印范围；本批仅扩展测试证据，不改该业务规范锚点或追认历史验证。',
    [ref(ANCHOR,63),ref(ARCHIVE,247),ref(ARCHIVE,266),ref(CONTROLLER,21)],
    '当前源码/接口/原字节签名校验定位；历史测试只作定位，不冒称本轮已执行')
add('evidence.dhr-summary-user-confirmed','evidence',EV,'evidence[id=evidence.dhr-summary-user-confirmed]',
    '证据登记指向原确认文档，其同版PDF/原件/JSON及工程inference区分与本次决策包相容。保留历史0.3.24来源文字及原始日期，不回填本轮运行记录或提升规范。',
    [ref(MD,9),ref(MD,15),ref(MD,36),ref(PACK,1)],
    '证据引用与原确认/工程方案分离；不是对文档涉及的全部迁移、UI及Office场景运行验收',
    maturity={'status':None,'visibility':'internal','type':'document'})
add('file:'+MD,'markdownEvidence',MD,'Markdown document; same-version export and inference paragraphs',
    '原文确认同版档案顺序PDF、真实来源分类、实例/汇总附件原件、JSON追溯和部分包标识；技术打印引擎、文件识别与联选依赖明确仍是inference。当前资源观察不改变这些含义，也不将历史初始HTML缺口误判为当前实现。',
    [ref(MD,9),ref(MD,15),ref(MD,36),ref(ARCHIVE,120),ref(ARCHIVE,179),ref(PDF,105)],
    '有限语义支撑文件；不把整份Markdown或历史竞品调研当当下全场景通过',
    maturity={'status':'specified','visibility':'internal','knowledgeModelVersionInSource':'0.3.24'})
for rid, detail, refs in [
    ('scenario.dhr-summary-attachment-export-and-audit',
     '本批可增加只读原件/摘要及导出失败证据，但该场景还要求七格式上传/核验/下载、50MiB边界、解除后冻结保留及权限双审计。本体角色未运行，本批直接夹具或mock打印器不能替代整场景端到端验收；保留其证据缺口，不作为不一致或产品缺陷。',
     [ref(DEC,line(DEC,'scenario.dhr-summary-attachment-export-and-audit')),ref(PACK,1),ref(ARCHIVE,144)]),
    ('scenario.dhr-summary-printable-archive-layout',
     '源码与规范边界一致，但全部中文模板版式、分页视觉、冻结目录树交互/切版清空、两类附件及完整HTTP组合仍需实际对应原件。主侧计划容量使用mock打印器，PDF可读/页数不认证真实完整版式；既有真实renderer测试也不由本角色声明本轮已通过。',
     [ref(DEC,line(DEC,'scenario.dhr-summary-printable-archive-layout')),ref(PACK,1),ref(PDF,105),ref(CONTROLLER,26)])]:
    add(rid,'acceptanceScenario',DEC,f'decisions[id=DEC-0063].acceptanceScenarios[id={rid}]',detail,refs,
        '验收证据边界核对；保留未组合覆盖场景，不因测试文件存在计作整场景通过',
        conclusion='evidence-gap',maturity={'status':None,'containerStatus':'specified','containerVisibility':'internal'})
add('DEC-0090-01','decisionStatement',DEC90,'decisions[id=DEC-0090].decisionStatements[id=DEC-0090-01]',
    '汇总冻结、指定版本ZIP副本与受控DHR归档生命周期彼此不同。实际export只生成副本并写生成审计，不设置归档状态；本批测试/证据和导出容量观察不关闭归档执行、放行、备份恢复或后续更正TODO。',
    [ref(DEC90,line(DEC90,'DEC-0090-01')),ref(ARCHIVE,75),ref(ARCHIVE,193)],
    '导出副本不等于DHR归档生命周期的术语/副作用边界；不实现后续归档')

for raw in (CHILD/'audit-records.jsonl').read_text().splitlines():
    r=json.loads(raw)
    r['reviewStatus']=r.pop('semanticReviewStatus')
    r['conclusionDetail']=r.pop('conclusionReason')
    r['evidenceReferences']=r.pop('originalEvidenceReferences')
    r['sourceCommit']=BASE
    r['maturityChange']=False
    records.append(r)
ids=[r['id'] for r in records]
assert len(ids)==len(set(ids))
(OUT/'finite-audit-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))

files = [
    'AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md',
    'docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md',
    'docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
    DEC,RULE,ANCHOR,EV,MD,DEC90,ARCHIVE,FILES,INTEGRITY,PDF,CONTROLLER,PACK,
]
files += [r['sourcePath'] for r in records]
files += ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormInstanceRecordService.java']
snapshot_entries=[]
for path in sorted(set(files)):
    src=ROOT/path
    dest=OUT/'snapshot'/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dest)
    data=src.read_bytes()
    tracked=git('ls-files','--error-unmatch',path) if path!=PACK else ''
    base_bytes=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT) if tracked else None
    snapshot_entries.append({'path':path,'sha256':digest(data),'bytes':len(data),'trackedAtBaseline':bool(tracked),
        'baselineBytesEqual': data==base_bytes if tracked else None,
        'semanticCoverage':'finite records only; snapshot presence is not semantic review completion'})
write_json(OUT/'source-snapshot-manifest.json',snapshot_entries)
shutil.copytree(CHILD,OUT/'subreview-number-signature',dirs_exist_ok=True)

knowledge=[]
for path in git('ls-files','docs/knowledge').splitlines():
    data=(ROOT/path).read_bytes()
    base_bytes=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT)
    knowledge.append({'path':path,'sha256':digest(data),'bytes':len(data),'baselineBytesEqual':data==base_bytes})
write_json(OUT/'knowledge-fingerprint-inventory.json',{
    'purpose':'inventory-and-byte-equality-only; NOT semantic coverage',
    'commit':BASE,'fileCount':len(knowledge),'files':knowledge})
write_json(OUT/'baseline.json',{
    'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'head':git('rev-parse','HEAD'),'originEdhrDev':git('rev-parse','origin/edhr-dev'),
    'branch':git('branch','--show-current'),'sourceCommit':BASE,
    'knowledgeBaseline':'0.3.25','schemaVersion':'1.2.0','stage':'P0','stageStatus':'in-progress',
    'decisionPackagePath':PACK,'decisionPackageSha256':digest((ROOT/PACK).read_bytes()),
    'statusPorcelain':git('status','--porcelain=v1').splitlines(),
    'changedTrackedProductOrKnowledge':git('diff','--name-only',BASE,'--','gmp-platform/backend/src/main','gmp-platform/frontend/src','docs/knowledge','AGENTS.md','docs/agents','docs/architecture').splitlines(),
    'rootRuntimeTests':'not-executed-or-certified-by-this-role',
})
counts=collections.Counter(r['conclusion'] for r in records)
write_json(OUT/'finite-audit-summary.json',{
    'scope':'finite baseline DHR frozen ZIP/PDF read contracts, numbering and signature presentation',
    'records':len(records),'knowledgeIds':len([r for r in records if not r['id'].startswith('file:')]),
    'supportMarkdownFiles':len([r for r in records if r['id'].startswith('file:')]),
    'reviewStatusCounts':dict(collections.Counter(r['reviewStatus'] for r in records)),
    'conclusionCounts':dict(counts),'knowledgeFilesInventory':len(knowledge),
    'knowledgeFilesSemanticallyReviewed':None,
    'wholeAuditNotClosed':True,'originalWholeAuditKnowledgeCandidates':931,
    'originalWholeAuditUiDiagnostics':86,
    'preservedGaps':['multi-tenant isolation','general quality/exception/source-signature automatic comparison',
        'A12 full history','DHR archive lifecycle/release/backup-and-recovery','full HTTP/auth matrix/real full PDF layout',
        'original whole-audit outstanding items and user pauses'],
    'notPerformanceOptimizationApproval':True,'runtimeTestsExecutedByThisRole':[],
})
print(json.dumps({'records':len(records),'conclusions':dict(counts),'snapshots':len(snapshot_entries),'knowledgeInventory':len(knowledge)},ensure_ascii=False))
