# 独立最终质量审查

本实例未参与本批任何产品、测试、夹具或配置修复；仅在自有 detached 工作树执行候选 `1eff0b51fbec41ce272f51a1089a670697b86384` 的只读验证。目标 `edhr-dev@5bfd96ff1e10a665a41db8fdf88352f65b1288a3` 是其祖先，目标与候选的契约/知识/前端/迁移原字节保持。只读证据子项另行最终返回，不替代本实例运行和最终判定。

## 源码及授权范围

唯一产品变化是 DhrFormFiles.resolve 每次新建签名图片 URL map，递归共享于该次 fieldValues 遍历。每个独立签名图片 ID 首次仍按原 requireFile/read 进行 default 租户、SIGNATURE_EVIDENCE、创建截止时点、原件存在、登记长度与 MD5 校验，并检查 PNG/JPEG；只在成功后保存完整 data URL。普通原件 map 单独持有，不能以签名缓存逃过普通对象/类型检查。无单例缓存字段，不跨调用、表单或截止时点。deepCopy 输入、签名 ID/所有值、ZIP 单独原件与数据结构保持。签署写入端 ExecutionAccess.signField 的原个人认证/密码和独立签署 ID 未变；复用认证图片是实际可达来源，展示编码不等于电子签署。

这与用户“先修复重复图片读取”的实际批准、同一 L2 决策包的 impactAnalysis 和 product-core 所有权一致。无接口、schema、索引、权限、生命周期、历史恢复、单表/总PDF数量或内容政策变更。PNG/JPEG 单测使用登记字节而非实际图像解码器，保证的是 MIME/摘要/编码语义；原生 PNG 夹具为有效 PNG 并附填充字节，不把单测视作浏览器展示认证。

## 实际独立验证

- 全新 PostgreSQL16 隔离库、canonical Liquibase、JPA open-in-view=false，12项显式 opt-in 观察完整执行；连同4 FormFiles、3流回调、13原归档、3版式读者、8汇总及6真实Chromium方法，总计49/49、0F/E/S。知识模块单独89/89。所有 XML 均为本次新建工作树/运行产物；未选取需要正式数据库配置的可选真实模板方法，不声称已运行它。
- 0/1/10/100 同图签名与普通附件，输入不变、所有显示编码解码后与登记字节相同；正数都1 SELECT和262144逻辑读取字节，空引用0。嵌套100字段/2图片、独立签名ID、跨调用重新读取、截止时点、普通类型隔离、坏MD5/长度/缺失/MIME/租户守卫均由实际所选测试覆盖。
- 实际归档1/10/100有效PDF，冻结版本整体摘要及逐源证据、真实ZIP提取、每组件255B检查、清单字节数/SHA、单表PDF原字节、合并页数、真实EXPORT审计均通过。容量部分打印器被mock，真实 ArchiveService、FrozenIntegrity、PDFBox/JPA/审计运行。直接持久化合法冻结夹具不能认证创建/START或生产放行。
- Controller 3例直接执行 StreamingResponseBody：字节/头、成功删除、输出8字节后IOException传播及删除、非法选择ID生成前拒绝。未启动认证HTTP、servlet异步拒绝/超时/取消矩阵，不能据此宣称完整HTTP或RBAC覆盖。
- 真实 Chromium6方法通过中文正文、原版式、3页60行完整性、横向、缺布局/外部图片/裁剪/省略拒绝。单独查看本次生成的中文首张、长表末页与横向3张PNG：中文内容和冻结值可读，末行ROW-060可见、末页3/3，横向原文字及1/1页脚可见。仅有限样本，不是整应用视觉或全部真实模板认证。

## 查询及资源证据

服务器成功 execute/statement 按自有库筛选，排除parse/bind重复。11个业务观察事件包含33 SELECT（24显式JDBC+9Hibernate），另3审计INSERT；11种SQL签名逐项匹配。图片查询在服务观察中6条，加8预热和5拒绝守卫控制，共19条服务器读取，不能把后13条当请求成本。另30条SELECT分为26初始化/驱动/建库设置、3归档后审计断言和1runner版本读取；全部其他语句也原样分列，不声称33是整个网络SQL。

独立外部 JDK jfr 工具重读11个 FileRead recording，按 registered.png 或 dhr-archive ZIP 路径重算事件和字节，与JSONL完全一致。100同图字段1条查询、262144B逻辑读取、1400240B线程累计分配（约1.335MiB）；不是物理IO或进程峰值。100张约190KiB有效PDF导出39878147B ZIP，线程累计分配155639216B（约148.43MiB），9条查询；这个缓冲累计风险仍open。heapBefore/After只是快照，GC可使差值负数，不能称峰值或SLA。并发Chromium进程、真实图片重量、50MiB多原件和历史审计载荷均需后续轴。

旧源预算19=16正/3失败/0E/S及初次容量夹具3E由独立证据子项直接核原档XML。旧源原生预算测试快照与最终测试逐字相同；原runner没有捕获DhrFormFilesTest运行前源，单测负控的原件证据是XML/日志及主侧无后续修改说明，不把它冒充独立旧源重跑。缺origin_kind/created_at的初次夹具错误不是产品缺陷，最终canonical约束未降低。负控原件及工具分类错误都不混入最终49通过。

## A23、有限本体及余项

局部Map足以处理本次确定性读取重复，无需新缓存层或通用导出框架。冻结版本摘要、逐记录source摘要、文件实际MD5及冻结附件SHA保护不同依据，SELECTED成员、目录完整性与写出数量也非相同保护，不机械删除。writeFrozenRecords / writeFrozenSummaryAttachments / appendTraceManifest 与将来 FrozenArchiveContext + ArchiveRecordWriter 的具体拆分建议保持为后续方案，本批未进行大模块重构。PDFMergerUtility.appendDocument 源关闭假设无现行缺陷证据，中文长编号仅宽列/历史假设，当前ASCII FR编号不触发255B组件上限，不为这些假设改产品。

知识350文件保持0.3.25/schema1.2/P0 in-progress。原20有限记录18个明确子范围一致、2个完整验收场景evidence-gap；复用delta的6个ID为子集，另2gap，不叠加unique。生成ZIP不等于DEC0090受控归档生命周期。7562仅基线跟踪路径盘点，整文件完成0，历史unique未知。931知识候选、86UI、W2余项/W3-W5交叉、W6健壮性/性能/抽取/A23含过去已审代码复查、W7增量及原高风险/A12/完整矩阵、文本ID索引、汇总605、导出内存继续；朋友签名页及生产弹窗样式暂停保持。不自动merge/deploy/历史恢复，不查询或触发CI，也未验证平台必需状态/分支保护。
