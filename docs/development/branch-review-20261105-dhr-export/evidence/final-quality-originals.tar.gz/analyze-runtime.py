from pathlib import Path
import json,re,collections,subprocess,hashlib,shutil,xml.etree.ElementTree as ET
out=Path('/tmp/edhr-dhr-export-quality-20261105');native=out/'native-optimized';root=Path('/tmp/edhr-dhr-export-quality-worktree-20261105')
def write(name,x): (out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def norm(s): return re.sub(r'\s+',' ',re.sub(r'\$[0-9]+','?',s.lower())).strip()
events=[json.loads(line) for line in (native/'observations/observations.jsonl').read_text().splitlines()]
app=collections.Counter(norm(s) for e in events for s in e['jdbcSql']+e['hibernateSql'])
parts=re.split(r'(?=^\d{4}-\d{2}-\d{2} )',(native/'postgres.log').read_text(),flags=re.M)
server=collections.Counter();valid=[]
for part in parts:
 m=re.match(r'^.*?edhr_dhr_export_read_test_quality_optimized LOG:\s+duration: [\d.]+ ms\s+(?:execute [^:]+|statement):\s*([\s\S]*)',part)
 if m:
  s=norm(m[1]);server[s]+=1;valid.append({'sql':s,'raw':part})
file=[s for s in app if s.startswith('select ') and 'from file_object ' in s];assert len(file)==1
checks=[]
for s,n in app.items():
 expected=n+(13 if s==file[0] else 0)
 checks.append({'sql':s,'applicationMeasured':n,'expectedControl':expected-n,'serverSuccessfulExecute':server[s],'matches':server[s]==expected})
assert all(c['matches'] for c in checks),[c for c in checks if not c['matches']]
remaining=server.copy()
for c in checks:del remaining[c['sql']]
write('server-sql-review.json',{'applicationEvents':len(events),'measuredSELECT':sum(e['selectStatements'] for e in events),'measuredOther':sum(1 for e in events for s in e['hibernateSql'] if not s.lower().lstrip().startswith('select')),'fileControls':{'warmup':8,'guard':5},'matchedShapes':checks,'otherSuccessfulStatements':[{'sql':s,'count':n} for s,n in remaining.items()],'serverAllSuccessfulStatements':sum(server.values()),'note':'Only successful execute/statement records for own DB, not parse/bind; other statements include fixture/init/control traffic and are not counted as measured requests'})
rawjfr=out/'jfr-json';rawjfr.mkdir(exist_ok=True);jfrs=[]
for e in events:
 p=native/'observations'/(e['name']+'.jfr')
 result=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(p)],check=True,capture_output=True,text=True)
 (rawjfr/(e['name']+'.json')).write_text(result.stdout)
 rows=json.loads(result.stdout)['recording']['events'];tracked=[]
 for r in rows:
  v=r['values'];path=v.get('path','')
  if (e['name'].startswith('archive-') and Path(path).name.startswith('dhr-archive-') and path.endswith('.zip')) or (not e['name'].startswith('archive-') and path.endswith('/registered.png')):tracked.append(v)
 byte_count=sum(v['bytesRead'] for v in tracked)
 assert byte_count==e['trackedLogicalReadBytes'],(e['name'],byte_count,e['trackedLogicalReadBytes'])
 assert len(tracked)==e['trackedReadEvents']
 jfrs.append({'name':e['name'],'rawReadEvents':len(rows),'trackedEvents':len(tracked),'logicalBytes':byte_count,'jsonlBytes':e['trackedLogicalReadBytes'],'threadAllocatedBytes':e['threadAllocatedBytes'],'heapBefore':e['heapBefore'],'heapAfter':e['heapAfter'],'outputArchiveBytes':e.get('outputArchiveBytes')})
write('jfr-allocation-review.json',{'events':jfrs,'scope':'Independent external JFR tool path filtering confirms logical FileRead bytes; thread allocation and heap snapshots come from current native action instrumentation, not a peak/physical-IO/SLA claim'})
knowledge=[]
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/'knowledge'/p.name);a=ET.parse(p).getroot().attrib;knowledge.append({'class':a['name'],**{k:int(a[k]) for k in ['tests','failures','errors','skipped']}})
write('knowledge/test-summary.json',{'classes':knowledge,'totals':{k:sum(e[k] for e in knowledge) for k in ['tests','failures','errors','skipped']}})
assert sum(e['tests'] for e in knowledge)==89
shutil.copytree(root/'gmp-platform/backend/target/dhr-pdf-qa',out/'real-print',dirs_exist_ok=True)
print(json.dumps({'shapes':len(checks),'allMatched':True,'measuredSELECT':sum(e['selectStatements'] for e in events),'measuredOther':sum(1 for e in events for s in e['hibernateSql'] if not s.lower().lstrip().startswith('select')),'otherSelectStatements':sum(n for s,n in remaining.items() if s.startswith('select')),'JfrIndependent':len(jfrs),'knowledge':89}))
