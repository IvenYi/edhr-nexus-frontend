from pathlib import Path
import json,yaml,hashlib,datetime
out=Path('/tmp/edhr-dhr-export-quality-20261105')
head='1eff0b51fbec41ce272f51a1089a670697b86384';base='5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
def read(p):return json.loads((out/p).read_text())
native=read('native-optimized/test-summary.json');knowledge=read('knowledge/test-summary.json');server=read('server-sql-review.json');jfr=read('jfr-allocation-review.json');cleanup=read('cleanup.json');child=read('evidence-review/result.json')
assert native['totals']=={'tests':49,'failures':0,'errors':0,'skipped':0}
assert knowledge['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
assert server['measuredSELECT']==33 and server['measuredOther']==3 and len(server['matchedShapes'])==11
assert len(jfr['events'])==11 and child['result']=='passed' and len(child['checks'])==8
assert cleanup['ownedPostgres']['removed'] and cleanup['ownedWorktreeRemoved'] and cleanup['afterDependencyRemovalStatus']==''
checks=[]
def c(i,category,description,method,command,evidence):checks.append({'id':'check.'+i,'required':True,'category':category,'description':description,'method':method,'command':command,'outcome':'passed','evidence':evidence})
c('actual-contract-candidate','documentation','实际读取1eff契约，开始/结束fetch仍5bfd；候选含目标。运行时仅自有node_modules软链，删除后工作树全clean，再正常移除；源码指纹保持。','command','git fetch/rev-parse/status/diff/merge-base; actual contracts', ['contract-and-source.json','cleanup.json'])
c('authorized-impact-and-extension','requirements','用户批准先修复重复签名图；同一L2 impact/extension覆盖直接、相邻、快照、审计、权限、迁移和证据缺口，产品仅一处局部Map，未扩范围。','inspection','Read decisionPackage and source diff',['read-snapshots/docs/development/branch-review-20261105-dhr-export/decision-package.yaml','review-notes.md'])
c('call-local-reuse-and-identity','security','首次原read+PNG/JPEG成功后缓存；每resolve新Map，不跨调用/截止时点/普通文件类型，输入deepCopy，签名ID与原件ZIP输出保持。','inspection','Review DhrFormFiles and current assertions',['native-optimized/source/gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java','native-optimized/source/gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrFormFilesTest.java','review-notes.md'])
c('native49-fresh','regression','自有detached候选及独立PG完整执行49/49、0F/E/S；新观察12、流3、原归档13、文件4、版式3、汇总8、真实renderer6，fresh XML。','command','python run-native.py optimized',['native-optimized/run.json','native-optimized/test-summary.json'])
c('unique-image-budget-and-failures','integration','0/1/10/100图片读取预算、嵌套2身份PNG/JPEG、跨调用/普通类型及损坏/截止/租户拒绝实际通过；未弱化原断言。','automated-test','Selected DhrExportReadObservationPostgresTest and DhrFormFilesTest',['native-optimized/TEST-com.zencas.edhr.production.service.DhrExportReadObservationPostgresTest.xml','native-optimized/TEST-com.zencas.edhr.production.service.DhrFormFilesTest.xml'])
c('canonical-archive-integrity','audit','实际canonical冻结版本/逐源摘要、1/10/100有效PDF ZIP解压、清单SHA和字节、合并页数、真实EXPORT审计通过；打印器容量mock隔离而非START/Chromium容量。','automated-test','Native archive capacity and original archive tests',['native-optimized/TEST-com.zencas.edhr.production.service.DhrExportReadObservationPostgresTest.xml','native-optimized/TEST-com.zencas.edhr.production.service.DhrAttachmentAndArchiveTest.xml','review-notes.md'])
c('stream-lifetime','unit','直接响应回调成功/8字节后输出中断均删除自有ZIP，异常传播；非法ID调用服务前拒绝。未声称HTTP/RBAC/异步拒绝矩阵。','automated-test','DhrArchiveControllerStreamingTest',['native-optimized/TEST-com.zencas.edhr.production.controller.DhrArchiveControllerStreamingTest.xml','review-notes.md'])
c('real-chromium-and-sample-visual','visual','真实Chromium6必需方法执行通过；亲自逐图查看中文首张、长表3/3末行ROW060、横向版式3样本，不等于全app或所有模板。','inspection','Real renderer tests; pdftoppm and view_image three focused samples',['native-optimized/TEST-com.zencas.edhr.production.service.DhrPdfRendererTest.xml','real-print/chinese-first.png','real-print/long-last.png','real-print/landscape.png'])
c('server-query-math','database','11SQL签名与自有服务器成功execute逐项对应：33观察SELECT、3审计INSERT；图片6业务+13控制=19。另26初始化/驱动、3后断言、1runner版本SELECT分列。','query','Parse own PG successful execute/statement records and compare native SQL',['server-sql-review.json','native-optimized/postgres.log','analyze-runtime.py'])
c('external-jfr-and-allocation-scope','integration','外部JFR工具独立重读11记录，按原件/ZIP路径重算事件与字节全等；signature100 1次/262144B/约1.335MiB分配；PDF100约38MiB ZIP/148.43MiB分配仍open。','command','JDK jfr print --json --events jdk.FileRead; independent path sums',['jfr-allocation-review.json','jfr-json/signature-100.json','jfr-json/archive-100.json'])
c('old-source-evidence','regression','原档旧源19项16正/3红/0E/S；原生预算源码同字节可证。旧unit仅XML/主侧修改历史，没有预运行源码快照，不冒称独立重跑。首次3夹具E单列。','inspection','Read original archive XML, fingerprints and negative control',['evidence-review/result.json','review-notes.md'])
c('all-original-bytes','documentation','4归档273文件外层及逐文件哈希吻合；四阶段XML/SQL数学、41JFR主原件与最终源7指纹通过。','command','Read-only evidence child hash/XML/JFR verification',['evidence-review/result.json','evidence-review/manifest.json'])
c('knowledge89-and-finite-ontology','ontology','独立知识89/89；350知识/0.3.25/schema1.2/P0保持，原20记录18有限一致2gap，delta6既有ID子集+2gap，两个本体NA，无政策漂移。','command','mvn -f tools/knowledge-model/pom.xml test; finite source/definition review',['knowledge/maven.log','knowledge/test-summary.json','evidence-review/result.json','review-notes.md'])
c('protected-baseline-and-inventory','documentation','1122保护指纹只一产品文件变化；基线7562路径仅盘点、wholeFile0/历史unique未知。931/86及全部原队列和用户暂停保留。','command','Compare baseline/current protected groups and fixed inventory',['contract-and-source.json','evidence-review/result.json'])
c('a23-and-concrete-extraction','requirements','不同冻结/源/原件摘要与选择范围保护各有依据，不机械删除；局部map足够，具体三私有writer/context拆分仍提案，不做大重构/假设修复。','inspection','Read actual DhrArchiveService/DhrFormFiles/PDFMerger and review proposals',['review-notes.md','evidence-review/result.json'])
c('final-resources-and-children','documentation','证据子项正式FINAL/passed8项；自有PG、软链、工作树已清理；终取目标仍5bfd；验证工具两非产品错误留记录，未修改repo或查询触发CI。','command','Final target fetch, candidate fingerprint check and owned cleanup',['cleanup.json','evidence-review/result.json','verifier-tool-notes.json'])
risks=[
 {'id':'risk.pdf-buffer-capacity','description':'100张隔离有效PDF约38MiB ZIP/148MiB线程累计分配；PDF数组/合并/序列化累计风险仍open。','impact':'真实Chromium、图像重量、进程峰值和并发容量未认证。','mitigation':'保留原输出与完整性，后续讨论磁盘/增量资源方案，未在本批自动优化。'},
 {'id':'limit.runtime-matrices','description':'直接服务/流回调及有限真实renderer样本，不覆盖创建START、完整HTTP/RBAC/异步拒绝、七格式/50MiB完整矩阵。','impact':'局部通过不能替代全系统/发布认证或DEC0090受控归档生命周期。','mitigation':'两完整场景保持evidence-gap，按原全审队列继续。'},
 {'id':'limit.old-unit-source-snapshot','description':'旧源预算unit原XML存在，但主runner未捕获DhrFormFilesTest预运行源码；同字节可证范围为原生预算测试。','impact':'不声称独立旧源unit复跑或补造缺失快照。','mitigation':'当前unit由本实例独立执行通过；保留原XML与修改历史限定，主侧L0收尾明确简称。'},
 {'id':'risk.remaining-whole-audit','description':'931知识候选/86UI、W2余项、W3-W5交叉、W6健壮性/性能/抽取/A23及旧代码复查、W7增量及原其他队列保持。','impact':'本批不是整体代码审计完成或全部业务本体一致通过。','mitigation':'持续台账；每轮先拉取目标并审增量，暂停项不自动恢复。'}]
q={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':head,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':risks,'blockingConditions':[]}}
(out/'quality-result.yaml').write_text(yaml.safe_dump(q,allow_unicode=True,sort_keys=False))
summary={'result':'passed','baseCommit':base,'headCommit':head,'requiredChecks':len(checks),'passedChecks':len(checks),'native':native['totals'],'knowledge':knowledge['totals'],'serverMeasuredSELECT':33,'serverAuditINSERT':3,'independentJfrRecords':11,'evidenceChild':{'result':'passed','checks':8,'status':'FINAL'},'resourcesClean':True,'findings':0,'blockingConditions':0,'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
for c in checks:
 for p in c['evidence']:assert (out/p).exists(),p
assert len(checks)==16 and all(c['required'] is True and c['outcome']=='passed' for c in checks)
files=[]
for p in sorted(out.rglob('*')):
 if p.is_file() and p not in [out/'manifest.json',out/'manifest.sha256']:files.append({'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'files':files},ensure_ascii=False,indent=2)+'\n')
digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps(summary));print('files',len(files),'manifest sha256',digest)
