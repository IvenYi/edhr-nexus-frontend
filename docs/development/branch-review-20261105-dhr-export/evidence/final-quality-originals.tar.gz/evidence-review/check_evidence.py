from pathlib import Path
import json, hashlib, tarfile, subprocess, xml.etree.ElementTree as ET, collections, gzip, re, datetime

ROOT=Path('/workspace/edhr-nexus-frontend')
SCOPE=ROOT/'docs/development/branch-review-20261105-dhr-export'
OUT=Path('/tmp/edhr-dhr-export-quality-20261105/evidence-review')
OUT.mkdir(parents=True,exist_ok=True)
HEAD='1eff0b51fbec41ce272f51a1089a670697b86384'
BASE='5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
checks=[]
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def record(name,data):
    checks.append({'id':name,'outcome':'passed','evidence':data})
def dump(name,data):(OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

assert git('cat-file','-t',HEAD).strip()==b'commit'
assert git('merge-base',HEAD,BASE).decode().strip()==BASE
contracts=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml']
for p in contracts:
    data=git('show',HEAD+':'+p);dest=OUT/'read-snapshots'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
record('candidate-contracts',{'head':HEAD,'base':BASE,'contractReadCommit':HEAD,'snapshots':contracts})

manifest=json.loads((SCOPE/'evidence/archive-manifest.json').read_text())
archives={};archive_results=[]
for archive in manifest['archives']:
    path=SCOPE/'evidence'/archive['archive'];blob=path.read_bytes()
    assert sha(blob)==archive['sha256'] and len(blob)==archive['bytes']
    expected={r['path']:r for r in archive['files']}
    with tarfile.open(path) as t:
        members=[m for m in t.getmembers() if m.isfile()]
        assert len(members)==archive['fileCount']==len(expected)
        assert set(m.name for m in members)==set(expected)
        data={m.name:t.extractfile(m).read() for m in members}
        for name,body in data.items():assert sha(body)==expected[name]['sha256'] and len(body)==expected[name]['bytes']
    archives[archive['archive']]=data
    archive_results.append({'archive':archive['archive'],'verifiedFiles':len(data),'bytes':len(blob),'sha256':sha(blob)})
record('all-archive-byte-integrity',archive_results)
dump('archive-verification.json',archive_results)
raw=archives['main-originals.tar.gz']
performance=json.loads((SCOPE/'performance-report.json').read_text());phases={};jfr_details=[]
expected_totals={'focused':(15,0,3,0),'full':(47,0,0,0),'budget':(19,3,0,0),'optimized':(49,0,0,0)}
for phase,expected in expected_totals.items():
    prefix='native-'+phase
    xmls={n:ET.fromstring(body) for n,body in raw.items() if n.startswith(prefix+'/TEST-') and n.endswith('.xml')}
    totals={k:sum(int(xml.attrib.get(k,0)) for xml in xmls.values()) for k in ['tests','failures','errors','skipped']}
    assert tuple(totals.values())==expected
    saved=json.loads(raw[prefix+'/test-summary.json'])
    assert saved['totals']==totals and not saved['missingFreshReports']
    events=[json.loads(s) for s in raw[prefix+'/observations/observations.jsonl'].decode().splitlines()]
    select_total=0;nonselect_total=0;shapes=collections.Counter()
    for event in events:
        calculated=len(event['jdbcSql'])+sum(s.lstrip().lower().startswith('select') for s in event['hibernateSql'])
        assert event['selectStatements']==calculated
        select_total+=calculated
        nonselect_total+=sum(not s.lstrip().lower().startswith('select') for s in event['hibernateSql'])
        shapes.update(' '.join(s.lower().split()) for s in event['jdbcSql']+event['hibernateSql'])
        assert event['threadAllocatedBytes']>=0 and event['elapsedNanos']>=0
        jfr_name=prefix+'/observations/'+event['name']+'.jfr'
        jfr_path=OUT/'jfr-originals'/prefix/(event['name']+'.jfr');jfr_path.parent.mkdir(parents=True,exist_ok=True);jfr_path.write_bytes(raw[jfr_name])
        command=['/workspace/.edhr-cloud-tools/jdk-21/bin/jfr','print','--json','--events','jdk.FileRead',str(jfr_path)]
        parsed=json.loads(subprocess.check_output(command,text=True))
        event_values=[e['values'] for e in parsed['recording']['events']]
        if event['name'].startswith('archive-'):
            watched=[v for v in event_values if re.fullmatch('/tmp/dhr-archive-[0-9]+\\.zip',v['path'])]
            assert sum(v['bytesRead'] for v in watched)==event['outputArchiveBytes']
        else: watched=[v for v in event_values if v['path'].endswith('/registered.png')]
        assert sum(v['bytesRead'] for v in watched)==event['trackedLogicalReadBytes']
        assert len(watched)==event['trackedReadEvents']
        jfr_details.append({'phase':phase,'name':event['name'],'matchedFileReadEventsIncludingEOF':len(watched),'matchedLogicalBytes':sum(v['bytesRead'] for v in watched),'recordingSha256':sha(raw[jfr_name]),'paths':sorted(set(v['path'] for v in watched))})
    report=performance['phases'][phase]
    assert report['tests']==saved and report['events']==[{k:v for k,v in event.items() if k not in ['jdbcSql','hibernateSql']} for event in events]
    assert report['logicalSelectStatements']==select_total and report['hibernateNonSelectStatements']==nonselect_total
    assert {e['sql']:e['count'] for e in report['sqlShapes']}==dict(shapes)
    cleanup=json.loads(raw[prefix+'/cleanup.json']);assert cleanup['removed'] is True
    phases[phase]={'totals':totals,'events':len(events),'measuredSELECT':select_total,'measuredOther':nonselect_total,'cleanup':cleanup}
assert phases['optimized']['measuredSELECT']==33 and phases['optimized']['measuredOther']==3
assert phases['full']['measuredSELECT']==141 and phases['full']['measuredOther']==3
record('xml-event-query-and-jfr-math',{'phases':phases,'jfrRecordingsParsed':len(jfr_details),'caveat':'EOF FileRead events are counted separately; logical bytes are not physical disk IO or open-count.'})
dump('jfr-byte-verification.json',jfr_details);dump('phase-verification.json',phases)

negative=json.loads((SCOPE/'negative-control.json').read_text());budget_run=json.loads(raw['native-budget/run.json']);optimized_run=json.loads(raw['native-optimized/run.json'])
old_product=next(r for r in budget_run['sourceFingerprints'] if r['path'].endswith('/DhrFormFiles.java'))
assert old_product['sha256']==negative['baselineSourceSha256']==sha(git('show',BASE+':'+old_product['path']))
new_path='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrExportReadObservationPostgresTest.java'
old_test=next(r for r in budget_run['sourceFingerprints'] if r['path']==new_path)
new_test=next(r for r in optimized_run['sourceFingerprints'] if r['path']==new_path)
assert old_test['sha256']==new_test['sha256']==negative['finalObservationTestSha256']==sha(git('show',HEAD+':'+new_path))
budget_failures=[]
for name,body in raw.items():
    if not (name.startswith('native-budget/TEST-') and name.endswith('.xml')):continue
    for c in ET.fromstring(body).findall('testcase'):
        for f in c.findall('failure')+c.findall('error'):budget_failures.append({'class':c.attrib['classname'],'name':c.attrib['name'],'type':f.tag,'message':f.attrib.get('message','')})
assert sorted(budget_failures,key=lambda r:r['name'])==sorted(negative['failures'],key=lambda r:r['name'])
assert all(f['type']=='failure' for f in budget_failures) and len(budget_failures)==3
knowledge_xml=ET.fromstring(raw['knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'])
assert tuple(int(knowledge_xml.attrib[k]) for k in ['tests','failures','errors','skipped'])==(89,0,0,0)
record('old-source-budget-and-main-knowledge',{'budget':phases['budget']['totals'],'nativeBudgetTestSameBytes':True,'oldProductMatchesBase':True,'knowledge89':True,'unitSourceSnapshotLimit':'DhrFormFilesTest was not among the 7 captured source paths. Its budget XML records the actual method/failure, but this child does not claim independently reexecuted old-source unit or prove a missing pre-run unit source snapshot.'})

for fingerprint in optimized_run['sourceFingerprints']:
    body=raw['native-optimized/source/'+fingerprint['path']]
    assert fingerprint['sha256']==sha(body)==sha(git('show',HEAD+':'+fingerprint['path']))
record('captured-final-main-sources-match-candidate',{'head':HEAD,'paths':len(optimized_run['sourceFingerprints']),'runtimeHeadActuallyReported':optimized_run['head'],'meaning':'Main tests ran base HEAD plus dirty changes; snapshots match later clean candidate, no backfilled runtime commit.'})

inventory=json.loads((SCOPE/'inventory-summary.json').read_text())
base_paths=git('ls-tree','-r','--name-only',BASE).decode().splitlines()
assert gzip.decompress((SCOPE/'baseline-tracked-paths.txt.gz').read_bytes()).decode().splitlines()==base_paths
assert sha((SCOPE/'baseline-tracked-paths.txt.gz').read_bytes())==inventory['baselinePathListSha256']
assert len(base_paths)==7562==inventory['trackedPaths']
assert sum(p.startswith('docs/knowledge/') for p in base_paths)==350==inventory['knowledgePaths']
assert inventory['fullFileSemanticCompletionThisBatch']==0 and inventory['historicalUniqueCoverage'].startswith('unknown')
protected=json.loads((SCOPE/'protected-source-manifest.json').read_text());changed=[]
for item in protected['files']:
    old=git('show',BASE+':'+item['path']);new=git('show',HEAD+':'+item['path'])
    assert sha(old)==item['baselineSha256'] and sha(new)==item['candidateSha256'] and item['unchanged']==(old==new)
    if old!=new:changed.append(item['path'])
assert changed==protected['changedProtectedPaths']==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java']
record('fixed-inventory-and-protected-bytes',{'basePaths':len(base_paths),'knowledgePaths':350,'protectedFingerprints':len(protected['files']),'changed':changed,'wholeFileCompletion':0,'historicalUnique':'unknown'})

finite=[json.loads(s) for s in (SCOPE/'finite-audit-records.jsonl').read_text().splitlines()]
delta=[json.loads(s) for s in (SCOPE/'delta-audit-records.jsonl').read_text().splitlines()]
assert len(finite)==20 and collections.Counter(r['conclusion'] for r in finite)=={'consistent':18,'evidence-gap':2}
assert len(delta)==8 and collections.Counter(r['conclusion'] for r in delta)=={'consistent':6,'evidence-gap':2}
assert set(r['id'] for r in delta)<=set(r['id'] for r in finite)
for row in finite+delta:
    source=git('show',HEAD+':'+row['sourcePath']).decode()
    if row['recordType']=='markdownEvidence':assert row['id']=='file:'+row['sourcePath']
    else:assert row['id'] in source
    assert row['reviewStatus']=='reviewed' and row['maturityChange'] is False
    assert row['runtimeValidation']=='not-executed-by-this-role'
    for ref in row['evidenceReferences']:
        p=ref.rsplit(':',1)[0] if re.search(r':[0-9]+$',ref) else ref
        assert (ROOT/p).is_file(),ref
initial=json.loads((SCOPE/'finite-audit-summary.json').read_text());delta_summary=json.loads((SCOPE/'delta-summary.json').read_text())
assert initial['originalWholeAuditKnowledgeCandidates']==delta_summary['originalWholeAuditKnowledgeCandidates']==931
assert initial['originalWholeAuditUiDiagnostics']==delta_summary['originalWholeAuditUiDiagnostics']==86
assert delta_summary['knowledgeChanged']==delta_summary['policyChanges']==delta_summary['newKnowledgeIds']==[]
record('finite-ontology-and-delta-honesty',{'originalRecords':20,'existingStableIds':19,'supportMarkdown':1,'conclusions':dict(collections.Counter(r['conclusion'] for r in finite)),'deltaRecords':8,'deltaUniqueScope':'subset, no newly completed IDs','preservedQueues':[931,86],'broadScenariosRemainEvidenceGap':[r['id'] for r in finite if r['conclusion']=='evidence-gap']})

notes=(SCOPE/'review-notes.md').read_text()
required_phrases=['A23','writeFrozenRecords','writeFrozenSummaryAttachments','appendTraceManifest','FrozenArchiveContext','不是峰值','完整servlet','仍open','350','931','86']
assert all(s in notes for s in required_phrases),[s for s in required_phrases if s not in notes]
record('scope-caveats-a23-and-concrete-extraction',{'notDeemedRedundant':['frozen version digest','per-record source hash','actual file size/MD5','frozen attachment SHA','selected membership/nonempty/count'],'concreteExtraction':['writeFrozenRecords','writeFrozenSummaryAttachments','appendTraceManifest','FrozenArchiveContext then ArchiveRecordWriter only when implementing resource work'],'capacityAndHttpGapsRemain':True})

result={'result':'passed','kind':'read-only-evidence-subcheck-not-final-quality','baseCommit':BASE,'headCommit':HEAD,'contractReadCommit':HEAD,'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[{'id':'limit.missing-pre-run-unit-source','description':'Negative-control DhrFormFilesTest source not captured by main runner; actual budget XML exists. Native budget source is fully captured and identical to candidate. No independent old-source rerun in this subitem.'},{'id':'limit.no-runtime-executed','description':'This subitem parsed original XML/JFR and current Git bytes; did not run Maven/PG/browser/HTTP. Parent final quality owns fresh runtime verification.'}],'resources':{'repositoryEdits':False,'mavenOrPgStarted':False,'cleanupRequired':False},'generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
dump('result.json',result)
print(json.dumps({'result':result['result'],'checks':len(checks),'archiveFiles':sum(a['verifiedFiles'] for a in archive_results),'JFRrecordings':len(jfr_details),'findings':0},ensure_ascii=False))
