# 冻结导出证据只读复核

本子项 `passed`，8项检查通过，无发现；不是最终质量结果。实际基线为 `1eff0b51fbec41ce272f51a1089a670697b86384`，目标/基准为 `5bfd96ff1e10a665a41db8fdf88352f65b1288a3`，契约读取同1eff。未修改仓库或运行 Maven、PostgreSQL、浏览器及 HTTP。

- 4份归档的压缩文件哈希及273个内部原件的长度/哈希/成员全集全部吻合。
- 原始XML与汇总吻合：focused 15=12正/3夹具错误；full 47全过；budget 19=16正/3预算失败；optimized 49全过；主侧知识XML89全过。夹具错误被正确分列，没有包装成产品缺陷或负控成功。
- 41份JFR由JDK21工具实际解析，指定PNG或生成ZIP路径的逻辑字节及事件数均与观察JSON吻合。事件数包含EOF，不能视为文件打开次数；这些是逻辑读取而非物理磁盘IO。
- 四阶段逐事件SELECT重算、Hibernate非SELECT和SQL形状频次吻合。最终11事件为33SELECT及3审计INSERT，原47阶段为141SELECT及3INSERT。主侧预热、资格失败守卫、审计断言与初始化没有混作受测业务查询；实际服务器核对由父质量独立完成。
- 旧DhrFormFiles原字节对应5bfd，原生预算测试源与最终测试/1eff逐字节相同，三个预算失败均为assertion failure，无error/skip。主runner未捕获DhrFormFilesTest预运行源快照，因此本子项只认证其真实预算XML，不能声称已独立重跑旧源单测或补造缺失快照。原生预算源码和全部最终主侧7份源码快照已与Git候选独立核对。
- 固定基线完整路径清单为7562，知识350，1122份保护指纹实际逐项与base/head核对，产品只改DhrFormFiles。盘点不作语义完成；整文件0，历史unique未知。
- 原20有限记录是19个既有ID加一份Markdown，18条在声明子范围一致、2个完整场景保留gap；8条delta均是原集合子集，其中6一致/2gap。原931知识候选、86 UI和暂停项保留，知识/业务政策/成熟度未提升。
- 实际DhrFormFiles仍执行首次完整资格、size/MD5和PNG/JPEG校验，只缓存成功URL，普通map独立，新调用重新建立map；与规则的冻结证据及字段签名规范相容。ArchiveService的版本hash、记录hash、附件原件hash及范围计数保护不同边界，A23无依据机械删除；三个写出私有方法和后续已验证上下文拆分建议具体且没有被实施成大重构。

PDF容量部分仍是mock打印器后的真实冻结/ZIP/PDFBox/审计观察；真实Chromium6项另行执行。线程分配不是峰值/RSS，heap快照不认证容量；完整HTTP、异步调度、并发/生产SLA、300表单及全格式/大原件矩阵保持未验证。父质量负责其独立运行与最终 `qualityResult`。

本子项分析工具首次把 `markdownEvidence` 支撑项误当成有稳定ID的YAML记录，发生工具断言错误；修正为核对 `file:<sourcePath>` 后完整只读分析通过。没有改仓库资产或降低仓库测试标准。
