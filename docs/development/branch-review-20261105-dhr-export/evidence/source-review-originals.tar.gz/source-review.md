# DHR ZIP/PDF导出只读源码复核

源/目标及契约读取基线：`5bfd96ff1e10a665a41db8fdf88352f65b1288a3`，知识0.3.25；本子项不是最终质量门禁。没有修改工作树、执行Maven/Chromium/导出运行测试、创建提交或运行服务资源。

## 已核源码与反证

- `DhrArchiveService.export`显式dhrId/versionId和default租户连接，先取冻结candidate/attachment，再用`DhrFrozenEvidenceIntegrity`比较独立source_snapshot/source_hash与版本整体摘要。SELECTED成员/非空检查、排序结果去重与全集比较、实际写出计数分别保护不同边界，不能仅因多次检查就判为过度防御。
- `DhrFormFiles.requireFile`保留tenant/targetType/生产对象/创建截止时点及实际MD5+长度。普通fileId在单record内缓存；签名图片要求SIGNATURE_EVIDENCE和PNG/JPEG。读取只在复制的renderingRecord嵌入data URL，不改冻结输入。
- SELECTED只解析选中record原件；未选原件缺失不应仅由resolve阻断，但冻结版本结构/摘要仍需完整验证。源对象级审计/签名仅选中有record时附身份/摘要元数据，原payload从部分清单移除，并声明NOT_INSTANCE_EXCLUSIVE；附件-only不附源对象载荷。既有Archive测试已核这类边界的断言存在，本子项未重跑。
- 原件摘要失败、缺失或渲染失败向外抛出；创建ZIP后的`catch`尝试删临时文件，成功后保存EXPORT审计，审计保存失败也尝试删除。Controller回调复制即使失败也finally删除。这里是源码覆盖，不代表所有文件系统删除失败或HTTP异步调度场景已执行。
- **PDF源流关闭假设未得到支持。**`DhrPdfRenderer.append:105–106`实际调用PDFMergerUtility.appendDocument，再关闭源；没有使用PDDocument.importPage。PDFBox 3.0.3实际jar字节码在appendDocument中创建目标PDFCloneUtility并cloneForNewDocument（原件pdfmerger-bytecode.txt）；不能仅凭源关闭推断共享流错误。既有DhrPdfRendererTest有真实Chromium中文字/60行3页/横向Word输出，Archive测试断言合并PDF3页及实际文字，不是全空白PDF mock。
- `DhrPdfRenderer.Session.close`以嵌套finally关闭browser/playwright并release许可；构造失败外层open释放许可。没有证据要求为OOM/Error、重复close等未见调用增加兜底。

## 路径组件候选及业务可达限制

`DhrArchiveService:122`对title和instanceNo各safeName最多160 UTF8字节，再拼`_id`，所以两个很长的字段组合可超过常见文件系统单组件255B；ZIP格式自身可保存这种条目，解压失败需要实际运行复现。

主审提出中文长编号夹具的物理推导成立（instance_no列varchar64、title字段更长）。但现行`FormInstanceRecordService.saved:75`新建编号固定ASCII `FR-YYYYMMDD-<id>`，正常最大31字符；此时160+1+31+1+19+4=216B，不触发该组件上限。已有记录分支89–90保留原instance_no，冻结读者没有ASCII约束；未找到当前公开导入或中文编号生成入口。因此应区分“接受的已持久化/历史冻结资料的读者健壮性”与“正常当前新建入口可触发”，不要将列宽本身称为后者证据。

规则`rule.dhr-summary-zip-source-trace`没有要求叶文件名逐字保留完整编号；用户确认证据`dhr-summary-user-confirmed.md:18/38`要求清单保留身份/版本/摘要，并将路径安全和同名去重列为工程实现。若确认修复，应保留稳定id后缀和完整清单/正文身份，且优先仅截短真正超过整体组件上限的名称，避免把当前合法212B名称无条件重截成160B而丢失原本安全的编号。

本子项没有独立执行真实export→filesystem复现，不将条件性候选提前标为已独立复现；最终由主审实际证据和技术判断确定修复范围。

## 性能与资源候选（待量化，不自动优化）

1. ArchiveService:113/128把每个单表PDF byte[]留在formPdfs，最后再构造combined PDDocument及bytes(combined)，PDFRenderer.bytes:108的ByteArrayOutputStream.toByteArray还有完整复制。峰值与总PDF字节相关，不能因每DHR≤300表单就认定安全；需要真实字体/图像负载的单页字节量和堆/RSS/JFR实验。
2. ArchiveService:145汇总附件Files.readAllBytes；DhrFormFiles.read:98实例原件同样全数组，Resolved可同时持有一个实例的所有原件。旧50MiB SHA流式校验不等于这些输出消费者已流式。可先测1/多附件、50MiB边界及并发，不直接改输出和资格时点。
3. DhrFormFiles.resolveValues:85–88重复签名图片id每次findById/read/MD5/base64，没有普通fileId的单record缓存。ExecutionAccess:285–293从用户PROFILE认证快照复用相同signatureImage fileId，故多个签名字段由同一用户签署是合理候选。需先量化n=1/10/100查询、原件读取和重复base64，不把尚未测的N+1次数当实测。
4. FULL来源audit/signature数组及JSON清单可能随完整历史/签署payload累积；SELECTED先取全payload再删字段也有中间内存，但sourceSignatures仍须用原payload验摘要，不能为降内存直接跳过完整性校验。

## A23与具体拆分建议

冻结整体摘要、记录原始快照hash、文件实际hash及与冻结附件hash比较是不同依据；不能机械删掉“看似重复”的保护。frozenIntegrity重复读取version和export第一行上下文有复用可能，但应在真正优化时设计单一已验证FrozenArchiveContext，保留dhrId/version/tenant身份及全部hash输入；不在本轮凭统计行数重构。

若后续落实资源方案，可先在原服务提取`writeFrozenRecords`、`writeFrozenSummaryAttachments`、`appendTraceManifest`，保持相同排序、数量守卫、AS_OF_EXPORT与提交截止时点。需要进一步隔离时再分FrozenArchiveContext读取/验证与ArchiveRecordWriter，不新建通用导出框架。Controller临时文件所有权可独立核验真实异步拒绝/超时；源码只见回调finally，不足以把“回调未执行可能残留”提前宣称真实已复现缺陷。

当前未确认新的正常业务入口正确性缺陷；文件名组件是带明确持久化/历史边界的待主审运行候选。完整HTTP/RBAC/并发/安装、生产SLA、全部内容大小和跨租户矩阵仍未覆盖；不计整文件或全仓完成，不重开PR5/PR6或暂停的签名页/样式。
