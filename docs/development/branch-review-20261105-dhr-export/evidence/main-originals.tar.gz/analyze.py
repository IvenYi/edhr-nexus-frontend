import pathlib, json, hashlib, subprocess, xml.etree.ElementTree as ET, collections, gzip, shutil, datetime
root=pathlib.Path('/workspace/edhr-nexus-frontend')
raw=pathlib.Path('/tmp/edhr-dhr-export-20261105')
out=root/'docs/development/branch-review-20261105-dhr-export'
def write(name, data): (out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
phases={}
for name in ['focused','full','budget','optimized']:
    d=raw/('native-'+name); events=[]
    for line in (d/'observations/observations.jsonl').read_text().splitlines(): events.append(json.loads(line))
    sqls=collections.Counter()
    for event in events:
        for sql in event['jdbcSql']+event['hibernateSql']: sqls[' '.join(sql.lower().split())]+=1
    phases[name]={'tests':json.loads((d/'test-summary.json').read_text()),'events':[{k:v for k,v in e.items() if k not in ['jdbcSql','hibernateSql']} for e in events],
       'logicalSelectStatements':sum(e['selectStatements'] for e in events),'hibernateNonSelectStatements':sum(1 for e in events for s in e['hibernateSql'] if not s.lstrip().lower().startswith('select')),
       'sqlShapes':[{'sql':s,'count':n} for s,n in sqls.items()], 'cleanup':json.loads((d/'cleanup.json').read_text())}
before={e['name']:e for e in phases['full']['events']}; after={e['name']:e for e in phases['optimized']['events']}
comparison=[{'name':n,'before':before[n],'after':after[n]} for n in after]
write('performance-report.json',{'baselineCommit':'5bfd96ff1e10a665a41db8fdf88352f65b1288a3','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':phases,'comparison':comparison,
   'measurementScope':['resolve/ArchiveService action only, native PG/JPA with open-in-view=false','FileRead JFR tracked path logical bytes, warm file cache, not physical disk IO','ThreadMXBean allocated bytes are cumulative allocations on calling thread, not retained heap/peak/RSS','Heap snapshots before/after permit GC and do not prove peak','Capacity renderer is mocked valid 190KiB PDF per form, actual archive/integrity/merge/audit; not Chromium capacity','8 file warmups+5 guard reads and 3 post-archive assertion SELECT excluded from measured request statements','Real Chromium renderer tests executed separately; direct Controller callback is not authenticated HTTP E2E'],
   'openRisks':['PDF arrays/combined document/serialization accumulation; disk-backed proposal not implemented','50MiB originals and source audit/signature manifest payload capacity need later axes','Production concurrency, full HTTP permissions/timeout/cancel and archival lifecycle remain unverified']})
negative=[]
for p in (raw/'native-budget').glob('TEST-*.xml'):
    for c in ET.parse(p).getroot().findall('testcase'):
        fs=c.findall('failure')+c.findall('error')
        if fs: negative.append({'class':c.attrib['classname'],'name':c.attrib['name'],'type':fs[0].tag,'message':fs[0].attrib.get('message','')})
assert len(negative)==3 and all(e['type']=='failure' for e in negative)
write('negative-control.json',{'scope':'old base DhrFormFiles bytes + same new budget tests prior to product edit','totals':phases['budget']['tests']['totals'],'failures':negative,
 'baselineSourceSha256':json.loads((raw/'native-budget/run.json').read_text())['sourceFingerprints'][1]['sha256'],
 'finalObservationTestSha256':sha(root/'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrExportReadObservationPostgresTest.java'),
 'budgetObservationTestSha256':next(e['sha256'] for e in json.loads((raw/'native-budget/run.json').read_text())['sourceFingerprints'] if e['path'].endswith('DhrExportReadObservationPostgresTest.java')),
 'initialFixtureErrors':'native-focused 15=12 pass/3 canonical not-null fixture E; corrected main fixture, no product/constraint changes; original logs kept separately, not counted as regression evidence'})
baseline='5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',baseline],cwd=root,text=True).splitlines()
with gzip.open(out/'baseline-tracked-paths.txt.gz','wb') as f: f.write(('\n'.join(paths)+'\n').encode())
write('inventory-summary.json',{'commit':baseline,'trackedPaths':len(paths),'knowledgePaths':sum(p.startswith('docs/knowledge/') for p in paths),'fullFileSemanticCompletionThisBatch':0,'historicalUniqueCoverage':'unknown; not reconstructed or increased by method-level review','baselinePathList':'baseline-tracked-paths.txt.gz','baselinePathListSha256':sha(out/'baseline-tracked-paths.txt.gz'),'scope':'all baseline tracked paths inventoried; only explicitly declared methods and finite knowledge records actually reviewed','pendingQueues':['931 knowledge candidates and 86 UI diagnostics retain prior task scope','W2 remainder, W3/W4/W5 cross-cutting review, W6 robustness/performance/extraction/A23 incl past reviewed code, W7 increments','history/deep pagination/keyword capacity, third text-ID index, summary 605 SELECT, export memory, original DHR high/A12/full runtime matrices','friend-owned generic task password/signature page and production dialog styling remain paused']})
protected=[]
for path in paths:
    if not (path.startswith('docs/knowledge/') or path.startswith('gmp-platform/backend/src/main/') or path.startswith('gmp-platform/frontend/') or path in ['AGENTS.md','codeplzreadme.md'] or path.startswith('docs/agents/')):continue
    p=root/path
    if not p.is_file():continue
    old=subprocess.check_output(['git','show',baseline+':'+path],cwd=root)
    protected.append({'path':path,'baselineSha256':hashlib.sha256(old).hexdigest(),'candidateSha256':sha(p),'unchanged':old==p.read_bytes()})
changed=[p['path'] for p in protected if not p['unchanged']]
assert changed==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java'],changed
write('protected-source-manifest.json',{'baselineCommit':baseline,'changedProtectedPaths':changed,'files':protected})
knowledge=[]
for p in sorted((raw/'knowledge').glob('TEST-*.xml')):
    a=ET.parse(p).getroot().attrib;knowledge.append({'class':a['name'],**{k:int(a[k]) for k in ['tests','failures','errors','skipped']}})
write('main-validation.json',{'native':phases['optimized']['tests'],'knowledge':knowledge,'measuredSelectStatements':phases['optimized']['logicalSelectStatements'],'measuredNonSelectStatements':phases['optimized']['hibernateNonSelectStatements'],'negativeControl':phases['budget']['tests']['totals'],'sources':'raw main archive source snapshots; native runs truthfully report base HEAD plus dirty tree, not later commit','visualReview':{'files':['real-print-optimized/long-last.png','real-print-optimized/landscape.png'],'actualInspection':'main agent individually opened both generated final sample PNGs; last row ROW-060 and footer on third page visible, landscape page has expected text and footer','limit':'two focused renderer sample pages only; no full app visual E2E or all 300 form layouts'}})
print(json.dumps({'baselinePaths':len(paths),'knowledgePaths':sum(p.startswith('docs/knowledge/') for p in paths),'measuredSELECT':phases['optimized']['logicalSelectStatements'],'nonSelect':phases['optimized']['hibernateNonSelectStatements'],'negative':len(negative)},ensure_ascii=False))
