from pathlib import Path
import hashlib
import json
import subprocess
import sys
import yaml

ROOT=Path('/workspace/edhr-nexus-frontend')
OUT=Path('/tmp/edhr-export-reuse-ontology-20261105')
PRIOR=Path('/tmp/edhr-export-ontology-20261105')
BASE='5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
SOURCE='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java'
OLD_MANIFEST_SHA='5a9b0ae97377361f58d29ab7d6935c3e2961e99d186b4f92c2e80d94198f3a37'
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def nested_ids(value):
    ids={}
    if isinstance(value,dict):
        if isinstance(value.get('id'),str): ids[value['id']]=value
        for x in value.values(): ids.update(nested_ids(x))
    elif isinstance(value,list):
        for x in value: ids.update(nested_ids(x))
    return ids
mode=sys.argv[1]
if mode=='references':
    records=[json.loads(x) for x in (OUT/'delta-audit-records.jsonl').read_text().splitlines()]
    assert len(records)==8 and len(set(r['id'] for r in records))==8
    assert sum(r['conclusion']=='consistent' for r in records)==6
    assert sum(r['conclusion']=='evidence-gap' for r in records)==2
    for r in records:
        assert r['reviewStatus']=='reviewed' and r['runtimeValidation']=='not-executed-by-this-role'
        assert r['sourceCommit']==BASE and r['maturityChange'] is False
        actual=nested_ids(yaml.safe_load((ROOT/r['sourcePath']).read_text()))[r['id']]
        if actual.get('status') is not None: assert actual['status']==r['originalMaturity']['status']
        if actual.get('visibility') is not None: assert actual['visibility']==r['originalMaturity']['visibility']
        for reference in r['evidenceReferences']:
            path,n=reference.rsplit(':',1)
            assert (ROOT/path).is_file() and 1<=int(n)<=len((ROOT/path).read_text().splitlines()),reference
    dispositions=[json.loads(x) for x in (OUT/'original-scope-dispositions.jsonl').read_text().splitlines()]
    assert len(dispositions)==20 and sum(r['currentConclusion']=='evidence-gap' for r in dispositions)==2
    assert all(r['currentConclusion']==r['originalConclusion'] and r['maturityChanged'] is False for r in dispositions)
    print('PASS finite delta references: 6 direct source reviews + 2 retained acceptance evidence gaps; original 20-record scope and maturity preserved. No runtime test executed.')
elif mode=='baseline':
    assert git('rev-parse','HEAD')==git('rev-parse','origin/edhr-dev')==BASE
    assert git('diff','--name-only','--','gmp-platform/backend/src/main','gmp-platform/frontend/src').splitlines()==[SOURCE]
    assert not git('diff','--name-only','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture','docs/knowledge')
    data=json.loads((OUT/'knowledge-fingerprint-inventory.json').read_text())
    assert data['fileCount']==350
    for r in data['files']:
        current=(ROOT/r['path']).read_bytes()
        original=subprocess.check_output(['git','show',BASE+':'+r['path']],cwd=ROOT)
        assert current==original and sha(current)==r['sha256'] and r['baselineBytesEqual'] is True
    for r in json.loads((OUT/'source-snapshot-manifest.json').read_text()):
        current=(ROOT/r['path']).read_bytes()
        assert current==(OUT/'snapshot'/r['path']).read_bytes() and sha(current)==r['sha256']
    assert sha((PRIOR/'manifest.json').read_bytes())==OLD_MANIFEST_SHA
    old=json.loads((PRIOR/'manifest.json').read_text())
    for r in old['files']: assert sha((PRIOR/r['path']).read_bytes())==r['sha256']
    print('PASS source-boundary baseline: HEAD/target 5bfd96ff; only DhrFormFiles production delta; 350 knowledge files and contracts unchanged. Original FINAL manifest and all 77 listed bytes retained; new source snapshots resolve. Fingerprints are not semantic audit coverage.')
elif mode=='result':
    r=yaml.safe_load((OUT/'ontologyResult.yaml').read_text())['ontologyResult']
    assert set(r)=={'result','baselineBefore','baselineAfter','contractBaseline','reason','changedArtifacts','knowledgeSync','conflicts','questions','validationEvidence','roadmapProgress'}
    assert r['result']=='not-applicable' and r['baselineBefore']==r['baselineAfter']=='0.3.25'
    assert r['contractBaseline']=={'sourceCommit':BASE,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[]}
    assert all(r[k]==[] for k in ['changedArtifacts','knowledgeSync','conflicts','questions'])
    for x in r['validationEvidence']: assert x['checkType'] in {'schema','reference','status-transition','projection','evidence-path'} and x['outcome']=='passed'
    assert r['roadmapProgress']=={'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
    print('PASS local strict ontologyResult format/enums and unchanged maturity; this is not formal knowledge JUnit, independent quality or runtime validation.')
else:
    raise SystemExit('references/baseline/result required')
