from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import yaml

ROOT=Path('/workspace/edhr-nexus-frontend')
OUT=Path('/tmp/edhr-export-reuse-ontology-20261105')
PRIOR=Path('/tmp/edhr-export-ontology-20261105')
BASE='5bfd96ff1e10a665a41db8fdf88352f65b1288a3'
OLD_MANIFEST_SHA='5a9b0ae97377361f58d29ab7d6935c3e2961e99d186b4f92c2e80d94198f3a37'
SOURCE='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFormFiles.java'
UNIT='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrFormFilesTest.java'
NATIVE='gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrExportReadObservationPostgresTest.java'
PACK='docs/development/branch-review-20261105-dhr-export/decision-package.yaml'
OUT.mkdir(parents=True,exist_ok=True)
def sha(data): return hashlib.sha256(data).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def dump(name,data): (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
assert sha((PRIOR/'manifest.json').read_bytes())==OLD_MANIFEST_SHA
old_manifest=json.loads((PRIOR/'manifest.json').read_text())
for f in old_manifest['files']:
    assert sha((PRIOR/f['path']).read_bytes())==f['sha256']
(OUT/'prior-final').mkdir(exist_ok=True)
for name in ['ontologyResult.yaml','finite-audit-records.jsonl','finite-audit-summary.json','manifest.json','manifest.sha256','baseline.json','source-snapshot-manifest.json']:
    shutil.copy2(PRIOR/name,OUT/'prior-final'/name)

prior_records=[json.loads(x) for x in (PRIOR/'finite-audit-records.jsonl').read_text().splitlines()]
prior_by_id={r['id']:r for r in prior_records}
details={
 'DEC-0063-10':('原件的租户、类型、cutoff、size/MD5以及PNG/JPEG检查仍由原read/requireFile完整执行；缓存只在首次成功校验和编码后保存，失败无返回。普通附件独立原有map和输出不变，没有Office转换、上传格式/容量政策变化。',[SOURCE+':29',SOURCE+':80',SOURCE+':91',SOURCE+':103',SOURCE+':117',UNIT+':45']),
 'DEC-0063-11':('rendering仍deep-copy冻结记录，同一resolve下相同签名图片ID复用同一个验证后data URL，每一签名字段仍写自己的展示URL且元数据不改；并未加入ZIP独立签名图附件、变化冻结版本或FULL/SELECTED选择/输出范围。',[SOURCE+':29',SOURCE+':32',SOURCE+':87',SOURCE+':97',UNIT+':19',NATIVE+':91']),
 'rule.dhr-summary-zip-source-trace':('本次批准的是单次解析内按签名图片fileId复用验证后的显示编码，属于工程读取成本优化；首次校验、失败拒绝、普通附件清单、输入冻结和显式版本消费均保留。无新业务限额、全局缓存、客户投影或归档状态。',[PACK+':24',SOURCE+':29',SOURCE+':85',SOURCE+':103',UNIT+':19',UNIT+':45',NATIVE+':91']),
 'rule.production-inline-signature':('多次字段签名复用认证图片是既有真实来源；本次只复用导出展示data URL，不复用signatureId或签署事件，不将图片展示当作签署，也不修改个人认证、签名密码或字段权限入口。',[SOURCE+':87',SOURCE+':95',UNIT+':29',UNIT+':35','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java:277']),
 'DEC-0058-01':('缓存局限一次resolve的局部Map，跨调用重新经过原件校验；每字段signatureId和冻结输入不变。读取认证图片并非重新生成电子签署，普通文件不能从签名图缓存绕过预期类型。',[SOURCE+':32',SOURCE+':80',SOURCE+':87',UNIT+':35',UNIT+':45',UNIT+':62']),
 'DEC-0074-04':('SIGN_FIELD继续当前登录人、USER_PROFILE认证及独立签名密码；本次改动未触及ExecutionAccess或按钮签署入口，也未借读取缓存引入admin/cross-account例外。',[SOURCE+':29',SOURCE+':87','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java:277','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java:281',UNIT+':19']),
}
delta=[]
for rid,(detail,refs) in details.items():
    previous=prior_by_id[rid]
    r={k:previous[k] for k in ['id','recordType','sourcePath','sourceLocator','sourceCommit','originalMaturity']}
    r.update({'auditScopeClassification':'finite-authorized-image-reuse-delta','auditScope':'单次resolve内复用通过原校验的签名图片显示data URL；仅当前源码/测试断言核对，不认证实际运行结果',
        'reviewStatus':'reviewed','conclusion':'consistent','conclusionDetail':detail,'evidenceReferences':refs,
        'runtimeValidation':'not-executed-by-this-role','maturityChange':False,'priorConclusionPreserved':previous['conclusion']})
    delta.append(r)
for rid in ['scenario.dhr-summary-attachment-export-and-audit','scenario.dhr-summary-printable-archive-layout']:
    r=dict(prior_by_id[rid])
    r['auditScopeClassification']='retained-acceptance-evidence-gap-after-delta'
    r['conclusionDetail']='本次仅增加图片读取复用及对应单元/原生预算断言，未改变该完整验收场景；原缺口保持。'+r['conclusionDetail']
    r['evidenceReferences']=r['evidenceReferences']+[PACK+':24',UNIT+':19',NATIVE+':91']
    delta.append(r)
(OUT/'delta-audit-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in delta))
dispositions=[]
for r in prior_records:
    dispositions.append({'id':r['id'],'originalConclusion':r['conclusion'],'deltaDisposition':'finite-source-rechecked' if r['id'] in details else ('acceptance-gap-reconfirmed' if r['conclusion']=='evidence-gap' else 'carried-forward-unchanged-semantics'),
                         'currentConclusion':r['conclusion'],'maturityChanged':False,'priorResultReference':'prior-final/finite-audit-records.jsonl'})
(OUT/'original-scope-dispositions.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in dispositions))

paths={SOURCE,UNIT,NATIVE,PACK,'AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrFrozenEvidenceIntegrity.java',
       'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java'}
paths.update(r['sourcePath'] for r in delta)
entries=[]
for path in sorted(paths):
    data=(ROOT/path).read_bytes()
    out=OUT/'snapshot'/path
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_bytes(data)
    tracked=git('ls-files',path)
    base=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT) if tracked else None
    entries.append({'path':path,'bytes':len(data),'sha256':sha(data),'trackedAtBaseline':bool(tracked),'baselineBytesEqual':data==base if tracked else None})
dump('source-snapshot-manifest.json',entries)
(OUT/'DhrFormFiles-working-tree.patch').write_text(git('diff','--',SOURCE)+'\n')
knowledge=[]
for path in git('ls-files','docs/knowledge').splitlines():
    data=(ROOT/path).read_bytes()
    base=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT)
    knowledge.append({'path':path,'sha256':sha(data),'baselineBytesEqual':data==base})
dump('knowledge-fingerprint-inventory.json',{'purpose':'byte-equality inventory only; not semantic coverage','files':knowledge,'fileCount':len(knowledge)})
dump('baseline.json',{'capturedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD'),'originEdhrDev':git('rev-parse','origin/edhr-dev'),'branch':git('branch','--show-current'),
    'sourceCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[],
    'statusPorcelain':git('status','--porcelain=v1').splitlines(),'productDelta':git('diff','--name-only','--','gmp-platform/backend/src/main','gmp-platform/frontend/src').splitlines(),
    'contractKnowledgeArchitectureDelta':git('diff','--name-only','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture','docs/knowledge').splitlines(),
    'priorFinalDirectory':str(PRIOR),'priorManifestSha256':OLD_MANIFEST_SHA,'priorFilesVerifiedUnchanged':len(old_manifest['files']),
    'decisionPackageSha256':sha((ROOT/PACK).read_bytes()),'mainRuntimeTests':'not executed or certified by ontology role'})
dump('delta-summary.json',{'priorScopeRecords':20,'priorStableIds':19,'priorSupportMarkdownFiles':1,'priorConclusionCounts':{'consistent':18,'evidence-gap':2},
    'deltaRecords':len(delta),'deltaConclusionCounts':dict(collections.Counter(r['conclusion'] for r in delta)),'sourceRecheckedIds':list(details),'unchangedCarriedForwardRecords':12,
    'knowledgeChanged':[],'policyChanges':[],'newKnowledgeIds':[],'roadmap':'0.3.25/schema 1.2.0/P0 in-progress',
    'originalWholeAuditKnowledgeCandidates':931,'originalWholeAuditUiDiagnostics':86,'allPriorGapsAndUserPausesRetained':True,'runtimeTestsExecutedByThisRole':[]})
print(json.dumps({'deltaRecords':len(delta),'sourceRecheckedIds':len(details),'retainedAcceptanceGaps':2,'snapshots':len(entries),'knowledgeFiles':len(knowledge),'priorFinalFilesUnchanged':len(old_manifest['files'])},ensure_ascii=False))
