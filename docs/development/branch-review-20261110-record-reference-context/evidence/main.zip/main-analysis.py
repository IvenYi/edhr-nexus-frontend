from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
candidate='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00';target='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d'
def read(p):return json.loads(p.read_text())
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(commit,path):return subprocess.check_output(['git','show',f'{commit}:{path}'],cwd=root)
run=read(raw/'final/run.json');assert run['head']==candidate and run['workingTreeStatus']=='' and run['exitCode']==0
for f in run['sourceFingerprints']:
 assert f['sha256']==sha((raw/'final/source'/f['path']).read_bytes())==sha((root/f['path']).read_bytes())==sha(blob(candidate,f['path']))
assert read(raw/'final/test-summary.json')['totals']==dict(tests=158,failures=0,errors=0,skipped=0)
assert read(raw/'focused_old_final/test-summary.json')['totals']==dict(tests=12,failures=10,errors=0,skipped=0)
native='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
assert (raw/'focused_old_final/source'/native).read_bytes()==blob(candidate,native)
for name in ['RecordControlDiff','RecordControlService']:
 p=f'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/{name}.java'
 assert (raw/'focused_old_final/source'/p).read_bytes()==blob(target,p)
checks={}
for phase in ['focused_old_final','final']:
 records=[json.loads(l) for l in (raw/phase/'http.jsonl').read_text().splitlines()]
 rows={x['case']:x for x in records if x['case'].startswith('reference-')}
 invalid=rows['reference-invalid-submit']
 if phase=='focused_old_final':
  assert invalid['actualStatus']==200 and invalid['expectedStatus']==400
  q=invalid['body']['data'];assert q['proposedValues']['driver']=='B' and q['proposedValues']['part']['id']=='501'
  assert q['sourceValues']['driver']=='A' and q['sourceValues']['part']['id']=='501'
  assert q['status']=='IN_REVIEW' and q['workflow_instance_id'] and q['applicant_signature_id']
 else:
  assert invalid['actualStatus']==invalid['expectedStatus']==400
  query=rows['reference-context-query'];legacy=rows['reference-context-legacy']
  assert query['actualStatus']==legacy['actualStatus']==200
  assert [x['id'] for x in query['body']['data']]==['502']
  assert [x['id'] for x in legacy['body']['data']]==['501']
  assert rows['reference-context-anonymous']['actualStatus']==401
  assert all(rows[k]['actualStatus']==400 for k in ['reference-context-missing-field','reference-context-invalid-values','reference-context-wrong-field-type'])
  a=rows['reference-people-first']['body']['data'];b=rows['reference-people-second']['body']['data']
  assert len(a)==101 and len(b)==52 and b[-1]['id']=='800150'
  assert len({x['id'] for x in a[:100]+b})==152
  valid=rows['reference-valid-submit'];assert valid['actualStatus']==200
  assert valid['body']['data']['proposedValues']['driver']=='B' and valid['body']['data']['proposedValues']['part']['id']=='502'
  assert rows['reference-valid-approve']['actualStatus']==200
 checks[phase]={'referenceHttpCases':len(rows),'invalidSubmitStatus':invalid['actualStatus']}
browser=read(raw/'browser_final/result.json');old_browser=read(raw/'browser_old_final/result.json')
assert (browser['tests'],browser['passed'],browser['failed'])==(42,42,0)
assert (old_browser['tests'],old_browser['passed'],old_browser['failed'])==(8,0,8)
assert all(not x.get('pageErrors',[]) and not x.get('nativeDialogs',[]) for x in browser['results'])
for r in browser['results']:
 if r['scenario'].startswith('reference-'):
  calls=[x for x in r['calls'] if x['path'].endswith('/references')];assert calls and all(x['method']=='POST' for x in calls)
  if r['scenario']=='reference-people':assert [x['body']['page'] for x in calls]==[0,1] and all(x['body']['size']==100 for x in calls)
  else:assert all(x['body']['values']['driver']=='B' and x['body']['size']==20 for x in calls)
for p in ['focused_old','focused_old_valid','focused_old_final','focused_new','focused_new_valid','final']:
 assert read(raw/p/'cleanup.json')['removed'] is True
knowledge=read(raw/'knowledge/test-summary.json');assert knowledge==dict(tests=89,failures=0,errors=0,skipped=0)
for f in read(raw/'knowledge/run.json')['sourceFingerprints']:assert f['sha256']==sha((root/f['path']).read_bytes())==sha(blob(target,f['path']))
static=read(raw/'static_final/runs.json');delta=read(raw/'static_final/premium-delta.json')
assert not delta['newIdentities'] and not delta['removedIdentities']
assert all(x['exitCode']==0 for x in static if x['name'] in ['build','list','fonts'])
for f in read(raw/'static_final/source-binding.json')['inputs']:assert f['sha256']==sha(Path(f['path']).read_bytes())
assert read(raw/'static_final/source-binding.json')['head']==candidate
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'testedCandidate':candidate,
 'protectedInputsMatch':len(run['sourceFingerprints']),'mainTests':dict(tests=158,failures=0,errors=0,skipped=0),'nativePostgres':99,'otherTestsIncluding15H2':59,
 'oldFinalSameNativeBytes':dict(tests=12,passed=2,failures=10,errors=0,skipped=0),'httpChecks':checks,
 'browser':{'current':{'tests':42,'passed':42},'oldSameFinalHarness':{'tests':8,'failed':8},'qualification':'Actual page/shared selectors/client with synthetic intercepted API,not live backend E2E'},
 'knowledgeActual':knowledge,'staticDelta':delta,'staticExitCodes':{x['name']:x['exitCode'] for x in static},
 'limitations':['Only newly prepared requests;preexisting signed IN_REVIEW/old revisions not repaired or certified clean','Legacy GET has saved main values,does not infer a current subtable row',
 'Initial2 fixture errors and browser syntax/department/locator calibration retained;not product reds','Earlier focused_new_valid has different native bytes;only final158 covers final candidate','Global strict/lint remain open;no whole-knowledge semantic or production capacity completion']}
repository_delta=read(raw/'static_final/repository-delta.json');assert not repository_delta['added'] and not repository_delta['removed']
assert repository_delta['candidateSummary']['total']==86
result['repositoryStrictDelta']=repository_delta
verified=read(raw/'browser_old_verified/run.json'); red=read(raw/'browser_old_verified/result.json')
assert verified['exitCode']==1 and verified['sourceHashesAfterExecutionMatch'] is True
assert (red['tests'],red['passed'],red['failed'])==(8,0,8)
assert len(verified['sourceFingerprintsBeforeExecution'])==5
for item in verified['sourceFingerprintsBeforeExecution']:
 p=Path(item['path'])
 capture=raw/'browser_old_verified/harness.mjs' if p.name=='test-record-change-async-browser.mjs' else raw/'browser_old_verified/source'/p.relative_to('/tmp/edhr-reference-old-20261110')
 data=capture.read_bytes()
 assert sha(data)==item['sha256']
assert all(not x.get('pageErrors',[]) and not x.get('nativeDialogs',[]) for x in red['results'])
result['browser']['oldVerifiedReceipt']={'tests':8,'failed':8,'preExecutionInputs':5,'preAndPostHashesMatch':True,'qualification':'Main actual rerun with pre-execution source receipt;QA read-only checked it,not an independent old-browser rerun'}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False,indent=2))
