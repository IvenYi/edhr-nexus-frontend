from pathlib import Path
import datetime,json,subprocess
repo=Path('/workspace/edhr-nexus-frontend');old=Path('/tmp/edhr-reference-old-20261110')
native='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
target='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d';candidate='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00'
def git(*args,cwd=repo):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
before=git('status','--porcelain',cwd=old)
assert git('rev-parse','HEAD',cwd=old)==target
assert set(before.splitlines())=={'M '+native,'?? gmp-platform/frontend/node_modules'},before
assert (old/native).read_bytes()==subprocess.check_output(['git','show',f'{candidate}:{native}'],cwd=repo)
link=old/'gmp-platform/frontend/node_modules';assert link.is_symlink()
dependency=link.resolve();assert dependency==(repo/'gmp-platform/frontend/node_modules').resolve()
link.unlink()
(old/native).write_bytes(subprocess.check_output(['git','show',f'{target}:{native}'],cwd=repo))
assert git('status','--porcelain',cwd=old)==''
subprocess.run(['git','worktree','remove',str(old)],cwd=repo,check=True)
assert not old.exists() and dependency.is_dir()
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ownWorktree':str(old),'before':before,'onlyOwnedNativeTestRestoredToBase':True,'onlyOwnedDependencySymlinkRemoved':True,'workingTreeCleanBeforeNormalRemoval':True,'normalWorktreeRemoval':True,'mainDependenciesPreserved':True}
(Path(__file__).parent/'old-worktree-cleanup.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
