from pathlib import Path
from collections import Counter
import datetime,hashlib,json,subprocess,sys

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;out=raw/(sys.argv[1] if len(sys.argv)>1 else 'static');out.mkdir(exist_ok=False)
front=root/'gmp-platform/frontend';base=Path('/tmp/edhr-reference-old-20261110/gmp-platform/frontend');audit=raw/'tools/audit_project.py'
inputs=list(sorted((front/'src').rglob('*')))+[front/'package.json',front/'package-lock.json',front/'scripts/test-record-change-async-browser.mjs',audit]
(out/'source-binding.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
 'workingTreeState':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),
 'inputs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in inputs if p.is_file()]},indent=2)+'\n')
jobs=[('premium-base',['python3',str(audit),str(base),'--mode','strict','--output',str(out/'premium-base.json')],base),
 ('premium-current',['python3',str(audit),str(front),'--mode','strict','--output',str(out/'premium-current.json')],front),
 ('lint',['npm','run','lint'],front),('build',['npm','run','build'],front),
 ('list',['npm','run','verify:list-table-style'],front),('fonts',['npm','run','verify:no-external-fonts'],front)]
records=[]
for name,args,cwd in jobs:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(args,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':args,'cwd':str(cwd),'startedAt':started,'exitCode':result.returncode})
 (out/'runs.json').write_text(json.dumps(records,indent=2)+'\n')
def findings(name,prefix):
 data=json.loads((out/(name+'.json')).read_text())
 return data,Counter((x['file'].replace(str(prefix),'<frontend>'),x['ruleId'],x['severity'],x['category'],x['message']) for x in data['findings'])
old,oc=findings('premium-base',base);new,nc=findings('premium-current',front)
delta={'baselineSummary':old['summary'],'candidateSummary':new['summary'],'newIdentities':list((nc-oc).elements()),'removedIdentities':list((oc-nc).elements()),
 'identity':'file/ruleId/severity/category/message multiset;raw line locators retained in both reports','scope':'Existing strict findings remain open;not claimed green'}
(out/'premium-delta.json').write_text(json.dumps(delta,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'runs':[{'name':x['name'],'exitCode':x['exitCode']} for x in records],'premiumDelta':delta},ensure_ascii=False))
assert not (nc-oc)
assert all(r['exitCode']==0 for r in records if r['name'] in ['build','list','fonts'])
