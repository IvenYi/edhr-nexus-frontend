from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, xml.etree.ElementTree as ET

root=Path('/tmp/edhr-reference-qa-20261110')
out=Path(__file__).parent/'knowledge'
out.mkdir(exist_ok=False)
paths=sorted(p for p in (root/'docs/knowledge').rglob('*') if p.is_file())
paths += sorted((root/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java'))
paths += [root/'gmp-platform/backend/pom.xml']
inputs=[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]
cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress',
     '-f','gmp-platform/backend/pom.xml','-Dtest=BusinessKnowledgeModelTest','test']
started=datetime.datetime.now(datetime.timezone.utc)
record={'startedAt':started.isoformat(),'command':cmd,'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        'workingTreeState':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'sourceFingerprints':inputs}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
with (out/'maven.log').open('w') as log:
    result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
record.update(exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
xml=root/'gmp-platform/backend/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
assert xml.stat().st_mtime>=started.timestamp()
shutil.copyfile(xml,out/xml.name)
attrs=ET.parse(xml).getroot().attrib
summary={k:int(attrs[k]) for k in ['tests','failures','errors','skipped']}
(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
assert result.returncode==0 and summary==dict(tests=89,failures=0,errors=0,skipped=0)
