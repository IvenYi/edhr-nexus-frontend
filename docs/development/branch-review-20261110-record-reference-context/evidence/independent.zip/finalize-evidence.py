from pathlib import Path
from collections import Counter
import datetime,hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET,yaml
raw=Path(__file__).parent;root=Path('/tmp/edhr-reference-qa-20261110');main=Path('/tmp/edhr-record-reference-context-20261110');ontology=Path('/tmp/edhr-record-reference-context-ontology-20261110')
base='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d';head='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def write(name,data):
 p=raw/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def load(name):return json.loads((raw/name).read_text())
changed=git('diff','--name-only',base,head).decode().splitlines();assert len(changed)==8
contract=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0082-defect-reason-detail-and-reference-ownership.yaml','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/rules/form-reference-runtime.yaml','docs/knowledge/rules/record-change.yaml','DESIGN.md','docs/frontend/list-page-guidelines.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java','gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceLookup.java','gmp-platform/frontend/src/components/form-renderer/ReferencePickerDialog.tsx','gmp-platform/frontend/src/components/identity/SubjectSelector.tsx','gmp-platform/backend/pom.xml']
inputs=[]
for name in sorted(set(changed+contract)):
 b=(root/name).read_bytes();assert git('show',head+':'+name)==b
 p=raw/'source'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 try:old=git('show',base+':'+name)
 except subprocess.CalledProcessError:old=None
 inputs.append(dict(path=name,bytes=len(b),sha256=sha(b),baseSha256=sha(old) if old is not None else None,unchangedSinceBase=old==b))
knowledge=[]
for p in sorted((root/'docs/knowledge').rglob('*')):
 if p.is_file():
  name=str(p.relative_to(root));b=p.read_bytes();assert git('show',base+':'+name)==b==git('show',head+':'+name);knowledge.append(dict(path=name,bytes=len(b),sha256=sha(b)))
assert len(knowledge)==353
write('source-binding.json',dict(role='independent final QA; no implementation/test/config modifications',baseCommit=base,headCommit=head,testedCommit=head,contractReadCommit=head,actualTargetCommit=git('rev-parse','origin/edhr-dev').decode().strip(),workingTreeFinal=git('status','--porcelain').decode(),changedFiles=changed,knowledgeCount=len(knowledge),knowledgeUnchanged=True,inputs=inputs,knowledgeInventory=knowledge))
(raw/'candidate.diff').write_bytes(git('diff','--binary',base,head))
reused=raw/'reviewed-main-evidence';reused.mkdir(exist_ok=True)
for directory in ['focused_old_final','browser_old_final']:
 shutil.copytree(main/directory,reused/directory,ignore=shutil.ignore_patterns('vm-tmp'),dirs_exist_ok=True)
shutil.copytree(ontology,raw/'reviewed-ontology',dirs_exist_ok=True)
old=load('reviewed-main-evidence/focused_old_final/run.json');test='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
testhash=sha((root/test).read_bytes());receipt=next(x for x in old['sourceFingerprints'] if x['path']==test);assert receipt['sha256']==testhash
oldsummary=load('reviewed-main-evidence/focused_old_final/test-summary.json')['totals'];assert oldsummary==dict(tests=12,failures=10,errors=0,skipped=0)
oldtree=ET.parse(reused/'focused_old_final/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml').getroot();assert len(oldtree.findall('.//testcase/failure'))==10
oldproduct=[]
for f in old['sourceFingerprints']:
 if '/src/main/' in f['path']:
  actual=sha(git('show',base+':'+f['path']));assert f['sha256']==actual;oldproduct.append(dict(path=f['path'],sha256=actual,matchBase=True))
oldbrowser=load('reviewed-main-evidence/browser_old_final/result.json');assert (oldbrowser['tests'],oldbrowser['passed'],oldbrowser['failed'])==(8,0,8)
write('old-negative-binding.json',dict(qualification='Main-role originals independently inspected/rebound; not independently rerun by this QA',native=dict(baseCommit=old['head'],testSha256=testhash,testMatchesFinalCandidate=True,summary=oldsummary,errorsAreZero=True,productionInputs=oldproduct),browser=dict(summary={k:v for k,v in oldbrowser.items() if k!='results'},failureModes='GET no context/page: B candidate/later personnel/failure fixture unavailable in all 8; screenshots/errors/calls retained',runtimeHarnessShaReceipt='No original dedicated runtime SHA receipt; line locations agree with final harness; not upgraded to independent old rerun'),earlierAttempts='Parent reported earlier native fixture errors and browser harness calibration; only focused_old_final is the exact-final-test native proof. Earlier successes are not substituted for this final 158/42/89.'))
summary=load('final_verified/test-summary.json');assert summary['totals']==dict(tests=158,failures=0,errors=0,skipped=0)
knowledgeSummary=load('knowledge/test-summary.json');assert knowledgeSummary==dict(tests=89,failures=0,errors=0,skipped=0)
kinputs=load('knowledge/run.json')['sourceFingerprints'];assert len(kinputs)==359
for f in kinputs:assert sha((root/f['path']).read_bytes())==f['sha256']
http=[json.loads(l) for l in (raw/'final_verified/http.jsonl').read_text().splitlines()];assert len(http)==82 and all(x['expectedStatus']==x['actualStatus'] for x in http)
ref={x['case']:x for x in http if x['case'].startswith('reference-')};assert len(ref)==11
def body(r):return json.loads(r['body']) if isinstance(r['body'],str) else r['body']
a=body(ref['reference-people-first'])['data'];b=body(ref['reference-people-second'])['data'];assert len(a)==101 and len(b)==52
ids=[x['id'] for x in a[:100]+b];assert len(set(ids))==len(ids)==152 and '800150' in ids
assert body(ref['reference-context-query'])['data'][0]['id']=='502';assert body(ref['reference-context-legacy'])['data'][0]['id']=='501'
pg=ET.parse(raw/'final_verified/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml').getroot();pgcases=[x.attrib['name'] for x in pg.findall('testcase')]
newnames=['referenceProposalUsesCompleteFrozenContextRegardlessOfFieldOrder','omittedReferenceCannotBypassChangedDependency','unchangedHistoricalReasonsKeepTheirOriginalRowIdentity','recordReferenceHttpUsesFrozenContextAndAllPersonnelPages','referenceSubmissionRejectsStaleOmittedValueAndApprovesValidReplacement']
newcases=[x for x in pgcases if any(n in x for n in newnames)];assert len(newcases)==12
browser=load('browser/result.json');assert (browser['tests'],browser['passed'],browser['failed'])==(42,42,0)
newbrowser=[x for x in browser['results'] if x['scenario'].startswith('reference-')];assert len(newbrowser)==8
for x in newbrowser:
 calls=[v for v in x['calls'] if v['path'].endswith('/references')];assert calls and all(c['method']=='POST' for c in calls)
 if x['scenario']=='reference-people':assert [c['body']['page'] for c in calls]==[0,1]
 else:assert all(c['body']['values']['driver']=='B' and c['body']['page']==0 and c['body']['size']==20 for c in calls)
 assert not x['writeCount']
catalog=[]
for p in sorted((raw/'final_verified/candidate-observations').glob('catalog-*.json')):
 d=json.loads(p.read_text());assert d['beforeStateDigest']==d['afterStateDigest'];assert len(d['observations'])==4
 assert all(len(o['sql'])==1 and o['returned']==d['catalogSizePerType'] for o in d['observations'])
 catalog.append(dict(size=d['catalogSizePerType'],reads=len(d['observations']),queriesPerRead=1,unchangedDigest=True))
signatures=[]
for p in sorted((raw/'final_verified/signature-observations').glob('*.json')):
 d=json.loads(p.read_text());assert d['signatureBefore']==d['signatureAfter'] and d['oldValuesBefore']==d['oldValuesAfter'] and d['oldHashBefore']==d['oldHashAfter'];signatures.append(dict(case=d['case'],signatureAndOldRevisionUnchanged=True))
assert len(signatures)==4
strict=load('static-exact/deltas.json');assert all(not s['newIdentities'] and not s['removedIdentities'] for s in strict)
assert strict[0]['candidateSummary']['total']==86 and strict[1]['candidateSummary']['total']==28
write('independent-analysis.json',dict(native=summary['totals'],nativePostgres=99,otherBackend=59,otherBackendQualification='Includes 15 H2 FormReferenceLookup cases and 8 pure config tests; not all native PG',freshNewNativeCases=newcases,knowledge=dict(tests=knowledgeSummary,sourceCount=len(kinputs),knowledgeFiles=len(knowledge)),http=dict(total=len(http),allExpectedStatusesMatch=True,newReferenceCases=[dict(case=x['case'],method=x['method'],expectedStatus=x['expectedStatus'],actualStatus=x['actualStatus']) for x in ref.values()],personnel=dict(firstBatchWithLookahead=101,secondBatch=52,combinedUnique=152,lastIdReachable='800150')),browser=dict(tests=42,passed=42,failed=0,newTests=8,existingTests=34,viewports=[1440,390],qualification=browser['qualification'],separateFromNativeHTTP=True),catalog=catalog,signatureRegression=signatures,strict=strict,codeReview=dict(fullProposedContext=True,frozenModelAndCanvas=True,omittedReferenceValidated=True,previousRowsByInternalStableIdentity=True,noIndexGuessing=True,shallowRowContextReadOnly=True,sharedLookupAndEvidenceUnchanged=True,immutableTopGuardUnchanged=True,noAdditionalPolicyDefaults=True,noSchemaMigrationOrIndexChange=True,capacityClaim=False),visualInspection=['reference-main-390-popup.png: candidate/columns/actions visible using existing shared picker; no new style', 'reference-people-390.png: later-page personnel149 visibly selected', 'reference-error-1440-popup.png: selection after explicit retry; request log proves 503 then retry, not automatic writes'],orchestrationAttempt=dict(description='Initial browser shell redirection before raw directory existed; zero tests ran. After directory creation normal 42-case run passed.',productOrTestChange=False)))
print(json.dumps(dict(sourceInputs=len(inputs),knowledge=len(knowledge),native=158,browser=42,knowledgeTests=89,http=len(http),newReferenceHttp=len(ref),candidateCatalogReads=sum(x['reads'] for x in catalog)),ensure_ascii=False))
