from pathlib import Path
from collections import Counter
import datetime,hashlib,json,subprocess
raw=Path(__file__).parent;out=raw/'static-exact';out.mkdir()
new=Path('/tmp/edhr-reference-qa-20261110');old=Path('/tmp/edhr-reference-old-20261110');script=raw/'tools/audit_project.py';runs=[];deltas=[]
for scope,suffix in [('repo',''),('frontend','gmp-platform/frontend')]:
 data={}
 for label,root in [('base',old),('candidate',new)]:
  scanned=root/suffix;output=out/(scope+'-'+label+'.json');cmd=['python3',str(script),str(scanned),'--mode','strict','--output',str(output)]
  start=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (out/(scope+'-'+label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  runs.append(dict(scope=scope,label=label,command=cmd,exitCode=r.returncode,startedAt=start,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat()))
  item=json.loads(output.read_text());count=Counter((f['file'].replace(str(scanned),'<scan>'),f['ruleId'],f['severity'],f['category'],f['message']) for f in item['findings']);data[label]=(item,count)
 base,bc=data['base'];candidate,cc=data['candidate']
 deltas.append(dict(scope=scope,baselineSummary=base['summary'],candidateSummary=candidate['summary'],newIdentities=list((cc-bc).elements()),removedIdentities=list((bc-cc).elements()),identity='file/ruleId/severity/category/message multiset; line locations retained in originals'))
 assert not cc-bc
(out/'runs.json').write_text(json.dumps(runs,indent=2)+'\n');(out/'deltas.json').write_text(json.dumps(deltas,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(deltas,ensure_ascii=False));assert all(x['exitCode']==2 for x in runs)
