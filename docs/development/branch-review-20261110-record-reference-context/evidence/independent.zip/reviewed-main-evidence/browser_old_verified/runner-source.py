from pathlib import Path
import datetime,hashlib,json,os,subprocess

repo=Path('/workspace/edhr-nexus-frontend');old=Path('/tmp/edhr-reference-old-20261110');raw=Path(__file__).parent
out=raw/'browser_old_verified';out.mkdir(exist_ok=False)
harness=repo/'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs'
target='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d';candidate='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00'
paths=['gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx','gmp-platform/frontend/src/api/record-control.ts',
 'gmp-platform/frontend/src/components/form-renderer/ReferencePickerDialog.tsx','gmp-platform/frontend/src/components/identity/SubjectSelector.tsx']
inputs=[]
for relative in paths:
 data=(old/relative).read_bytes();assert data==subprocess.check_output(['git','show',f'{target}:{relative}'],cwd=repo)
 dest=out/'source'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 inputs.append({'path':str(old/relative),'sha256':hashlib.sha256(data).hexdigest()})
data=harness.read_bytes();assert data==subprocess.check_output(['git','show',f'{candidate}:{harness.relative_to(repo)}'],cwd=repo)
(out/'harness.mjs').write_bytes(data);inputs.append({'path':str(harness),'sha256':hashlib.sha256(data).hexdigest()})
env=os.environ.copy();env.update(RECORD_CHANGE_ROOT=str(old/'gmp-platform/frontend'),RECORD_CHANGE_CASES='reference-main,reference-row,reference-people,reference-error',RECORD_CHANGE_ARTIFACTS=str(out))
command=['node',str(harness)]
record={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'target':target,'harnessCommit':candidate,'command':command,
 'sourceFingerprintsBeforeExecution':inputs,'sourceWorkingTreeState':subprocess.check_output(['git','status','--porcelain'],cwd=old,text=True),
 'qualification':'Actual old source and final harness captured before execution;API intercepted,no real business writes'}
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
with (raw/'browser-old-verified.log').open('w') as log:result=subprocess.run(command,cwd=repo/'gmp-platform/frontend',env=env,stdout=log,stderr=subprocess.STDOUT)
for item in inputs:assert hashlib.sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256']
record.update(exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceHashesAfterExecutionMatch=True)
(out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
r=json.loads((out/'result.json').read_text());assert (r['tests'],r['passed'],r['failed'])==(8,0,8) and result.returncode==1
assert all(not x['pageErrors'] and not x['nativeDialogs'] for x in r['results'])
print(json.dumps({'tests':8,'expectedProductFailures':8,'pageErrors':0,'capturedSourceInputs':len(inputs)}))
