from pathlib import Path
import json,hashlib,subprocess,shutil,yaml
raw=Path(__file__).parent;main=Path('/tmp/edhr-record-reference-context-20261110');root=Path('/tmp/edhr-reference-qa-20261110');old=Path('/tmp/edhr-reference-old-20261110')
base='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d';head='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00'
p=raw/'reviewed-main-evidence/browser_old_verified';shutil.copytree(main/'browser_old_verified',p,dirs_exist_ok=True)
shutil.copyfile(main/'verify-old-browser.py',p/'runner-source.py');shutil.copyfile(main/'browser-old-verified.log',p/'stdout.log')
r=json.loads((p/'run.json').read_text());b=json.loads((p/'result.json').read_text());assert (b['tests'],b['passed'],b['failed'])==(8,0,8) and r['exitCode']==1 and r['sourceHashesAfterExecutionMatch']
inputs=[]
for x in r['sourceFingerprintsBeforeExecution']:
 path=Path(x['path']);is_harness=path.name=='test-record-change-async-browser.mjs';relative=path.relative_to(Path('/workspace/edhr-nexus-frontend') if is_harness else old)
 stored=p/'harness.mjs' if is_harness else p/'source'/relative;data=stored.read_bytes();sha=hashlib.sha256(data).hexdigest()
 assert sha==x['sha256'] and data==subprocess.check_output(['git','show',(head if is_harness else base)+':'+str(relative)],cwd=root)
 inputs.append(dict(path=str(relative),commit=head if is_harness else base,sha256=sha,preexecutionReceiptAndStoredSourceMatch=True))
assert all(not x['pageErrors'] and not x['nativeDialogs'] and x['writeCount']==0 for x in b['results'])
proof=dict(qualification='Main-role actual supplemental old-browser rerun; this independent QA inspected pre-run/final receipts, stored source and Git bytes, not execution by QA',result=dict(tests=8,passed=0,expectedProductFailures=8,pageErrors=0,nativeDialogs=0,writes=0),inputs=inputs,startedAt=r['startedAt'],finishedAt=r['finishedAt'],environmentFromRetainedRunner=dict(RECORD_CHANGE_ROOT=str(old/'gmp-platform/frontend'),RECORD_CHANGE_CASES='reference-main,reference-row,reference-people,reference-error'),oldOriginalLimitation='browser_old_final had no original pre-run SHA receipt; preserved, not retroactively changed')
(raw/'old-browser-verified-binding.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
q=raw/'quality-result.yaml';data=yaml.safe_load(q.read_text());data['qualityResult']['checks'].append(dict(id='check.old-source-negative-proof',required=True,category='integration',description='独立核读同字节最终测试在固定旧产品源码的真实失败反证及新增预运行浏览器SHA收据',method='inspection',command='Verify reused main native and browser old-source originals against Git base/head and before/after fingerprints',outcome='passed',evidence=['old-negative-binding.json','old-browser-verified-binding.json','reviewed-main-evidence/focused_old_final/','reviewed-main-evidence/browser_old_verified/','Native12:2pass10fail0errors0skip with final test bytes; browser8:8 expected failures,0pageErrors/nativeDialogs/writes; supplemental runner preserves explicit old-source environment; this QA did not independently rerun old source']))
q.write_text(yaml.safe_dump(data,allow_unicode=True,sort_keys=False))
rp=raw/'review.md';s=rp.read_text();needle='## 剩余边界和清理';note='''追加反证：主侧随后实际运行 `browser_old_verified`，在运行前保存4个旧产品/共享源码和最终harness，与base/candidate分别核Git字节，运行后复核SHA不变。独立质量再次核读这些原件：8项全部真实失败，零页面异常/原生弹框/写入，环境由保留的runner明确指向旧源码。最终harness SHA为 `e2ab4a5a2c4a1c323aa946ccc87f06a9a27d566837ae8fcf2f535af208809b78`。这补足新的预收据反证，不回填旧 `browser_old_final` 的历史缺口，也不冒称本角色亲自重跑旧源码。见 `old-browser-verified-binding.json`。\n\n''';assert needle in s;rp.write_text(s.replace(needle,note+needle))
print('Supplemental old-browser proof verified, total formal checks',len(data['qualityResult']['checks']))
