from pathlib import Path
import json,yaml
raw=Path(__file__).parent;head='8766a0f90cd2b34ff35e0a9a1bef719c5d997b00';base='3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d'
checks=[]
def check(id,category,description,method,command,evidence):
 checks.append(dict(id=id,required=True,category=category,description=description,method=method,command=command,outcome='passed',evidence=evidence))
check('check.fixed-candidate-and-contract','documentation','独立固定来源/目标/受测提交，读取治理及L2决策包，8文件最小范围','inspection','git fetch origin edhr-dev; git diff base..head; git show; read contracts', [f'base={base}; head=tested={head}; contractReadCommit={head}; target last fetched unchanged','source-binding.json','candidate.diff','cleanup.json'])
check('check.existing-business-semantics','ontology','既有引用、冻结修订、人员完整性和未决边界核对，不制定新政策','inspection','Read DEC-0082/0087/0094/0095, form-reference-runtime, open-questions, shared validators', ['source/','reviewed-ontology/ontology-result.yaml','reviewed-ontology/finite-review-records.json','353 knowledge files unchanged; finite ontology denominator 21 = 18 consistent + 1 precise historical replacement + 2 existing out-of-scope questions; not new unique full-audit coverage'])
check('check.complete-proposed-context','integration','最终拟值先合并，按冻结model/canvas验证根引用及依赖主字段的子表引用；字段顺序与省略不能绕过','automated-test','EDHR_CANDIDATE_ROOT=ownWT EDHR_CANDIDATE_RAW=ownRaw EDHR_CANDIDATE_CONTAINER_PREFIX=edhr-reference-qa python3 run.py final_verified', ['final_verified/run.json','final_verified/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml','independent-analysis.json','8 new model/canvas x root/row positive/negative parameterized cases passed'])
check('check.historical-reason-row-identity','regression','原历史原因按稳定修订行身份传previous，旧无__rowId行重排保持；不新增失效原因豁免','automated-test','Same native-PG suite; inspect RecordControlDiff and unchanged FormReferenceLookup', ['2 new historical-reason cases passed, including reordered legacy rows','source/','independent-analysis.json'])
check('check.authenticated-reference-query','api','认证只读POST携带上下文和分页；GET沿保存主值兼容；401/400边界','automated-test','Same native-PG suite JWT+MockMvc HTTP requests', ['final_verified/http.jsonl','independent-analysis.json','POST frozen context returns502; GET saved context returns501; anonymous401; three malformed cases400; GET does not infer a specific current subtable row'])
check('check.complete-qualified-personnel','api','全部符合原资格的人员可跨页到达，无100名总量截断','automated-test','Native recordReferenceHttpUsesFrozenContextAndAllPersonnelPages and browser reference-people', ['independent-analysis.json','final_verified/http.jsonl','browser/result.json','native first101 includes lookahead, second52, first100+second52=152 distinct; last800150 reachable; browser later-page person149 selected at both widths'])
check('check.atomic-submit-and-history','audit','非法依赖拒绝前后8表摘要相同；合法真实申请/签署审批生效并保留旧修订','automated-test','Native referenceSubmissionRejectsStaleOmittedValueAndApprovesValidReplacement', ['final_verified/http.jsonl','final_verified/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml','source/gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java','400 invalid submit; before/after 8-table digest asserted; 200 valid submit and actual HTTP approval; Rev2=502, Rev1=501'])
check('check.native-adjacent-regression','regression','原签名不继承、锁定父表、审批权限、回滚、并发/幂等、候选SQL预算相邻回归','automated-test','Own isolated PostgreSQL16 canonical0092, both capacity opt-ins true; 10 selected classes', ['final_verified/test-summary.json','final_verified/postgres.log','final_verified/signature-observations/','final_verified/candidate-observations/','final_verified/record-observations/','158/158; 99 native PostgreSQL +59 other, including15 H2 supplemental and8 pure config; 20 catalog reads each1SQL; four old revision/signature evidence pairs unchanged'])
check('check.knowledge-actual89','documentation','本实例实际重跑知识89，353知识+5验证Java+POM共359输入绑定当前候选','automated-test','python3 knowledge-run.py (own temporary tool rooted to ownWT)', ['knowledge/run.json','knowledge/test-summary.json','knowledge/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','89/89, zero failures/errors/skips; not full natural-language semantic audit'])
check('check.actual-maintained-browser','e2e','实际维护页面、API客户端及共享选择器异步与错误恢复，共42场景','browser','RECORD_CHANGE_ROOT=ownWT/gmp-platform/frontend RECORD_CHANGE_ARTIFACTS=ownRaw/browser node ownWT/gmp-platform/frontend/scripts/test-record-change-async-browser.mjs', ['browser/result.json','browser.log','42/42 =34 prior +8 new, widths1440/390; all APIs intercepted synthetic, no live backend writes; separate from nativePG HTTP tests'])
check('check.visual-existing-components','visual','桌面/390窄屏复用既有公共选择器和设计规范，不改UI样式；后页实际可选择','browser','Inspect screenshots of reference-main, reference-row, reference-people, reference-error at1440/390', ['browser/reference-main-390-popup.png','browser/reference-people-390.png','browser/reference-error-1440-popup.png','source/DESIGN.md','source/docs/frontend/list-page-guidelines.md'])
check('check.build-style-font','regression','独立实际前端构建和仓库列表/外链字体检查','command','npm run build; npm run verify:list-table-style; npm run verify:no-external-fonts', ['static/runs.json','static/build.log','static/list.log','static/fonts.log','All three exit0; lint exit2 missing configuration is separately preserved as residual, not a passed lint result'])
check('check.strict-same-scope-no-regression','visual','官方exact脚本repo与frontend分别对比同范围基线，保留多重项，无新增或移除','command','python3 tools/audit_project.py <base/candidate root> --mode strict --output ...; Counter(file/ruleId/severity/category/message)', ['tools/audit_project.py SHA256=67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68 bytes37716','static-exact/runs.json','static-exact/deltas.json','repo86=72violations+14unresolved; frontend subset28=14+14; all exit2; no global static pass claimed; first extra-LF script and reports retained under tools/audit_project-initial-extra-lf.py and static/'])
check('check.robustness-and-scope-drift','requirements','核源码避免按索引猜历史、整表逐行深复制、共享上下文突变、权限放宽、冗余防御和新默认','inspection','Review five production diffs against base, shared readonly leaf validators, DP impact/extension strategy', ['candidate.diff','source-binding.json','independent-analysis.json','rowsById map per table; shallow main+row context read by unchanged validators; immutable topfields skip unchanged; source deep-copied; no schema/index/shared-control changes. No production capacity/SLA claim; omitted evidence validation is existing validity enforcement, not a new business rule'])
check('check.independent-environment-cleanup','documentation','只读独立验证，容器和运行依赖软链清理，受测输入和最终干净状态绑定','command','docker inspect owned-container; unlink own dependency symlink; git status --porcelain; source fingerprints', ['cleanup.json','final_verified/cleanup.json','source-binding.json','All own sessions completed; owned PG removed; own symlink removed, main dependency kept; ownWT final clean; no repository product/test/config modifications'])
risks=[dict(id='risk.existing-static',description='Repo strict86（72violations+14unresolved）及frontend子集28仍存在，基线/候选均exit2；npm lint因缺配置exit2。',impact='现有全仓静态问题与lint验证缺口仍开放；本批仅证明同范围无新增。',mitigation='留既有全量审计后续阶段，未为变绿扩大本批或降低门槛。'),dict(id='risk.audit-not-complete',description='本轮有限知识21项不是新增唯一覆盖；知识89为结构自动校验。W2-W7、已审A23整体回看、大模块具体拆分/性能其余项未由本批关闭。',impact='不能宣布整体代码/本体审计完成。',mitigation='沿仓库台账推进固定提交全量与新增增量审计，避免将本切片passed扩大到全系统。'),dict(id='risk.separate-synthetic-environments',description='浏览器42项拦截合成API；原生PG采用JWT+MockMvc与隔离fixture。',impact='两组证据互补，不构成同一个真实浏览器到后端再到PG的端到端发布验收。',mitigation='按实际环境口径报告；生产发布、完整多租户及全部签署组合另验。'),dict(id='risk.capacity-unknown',description='本批消除逐行整表深复制的新增风险，保持原逐叶子证据检查；未量化本切片大表规模SQL/内存峰值/吞吐SLA。原候选20SQL与目录容量仅相邻回归样本。',impact='生产容量仍UNKNOWN；不能由正确性全绿推定性能无界。',mitigation='结合实际数据规模在W6量化，重大性能取舍仍与用户讨论，不擅自改规则。'),dict(id='risk.existing-records',description='原存量在审申请/历史修订与签名未自动修复、回填或恢复，实际库存未知。',impact='本修复保证新处理路径，不证明旧存量已净化。',mitigation='有库存和授权时单独评估；保留历史证据，不回写。'),dict(id='risk.unchanged-deferred-boundaries',description='A12历史/放行/高风险完整矩阵、默认单租户限制、用户暂停项、未答性能方案继续原状态。',impact='不得将本候选验收扩大为上述范围的交付或生产批准。',mitigation='保留既有未决和台账；本批不自动关闭。')]
quality=dict(qualityResult=dict(result='passed',baseCommit=base,headCommit=head,contractBaseline=dict(sourceCommit=head,targetBranch='edhr-dev',targetCommit=base,contractReadCommit=head,uncommittedContractPaths=[]),workingTreeState=dict(status='clean',includedPaths=[],excludedPaths=[],untrackedPaths=[]),knowledgeBaselineVersion='0.3.25',checks=checks,findings=[],residualRisks=risks,blockingConditions=[]))
(raw/'quality-result.yaml').write_text(yaml.safe_dump(quality,allow_unicode=True,sort_keys=False))
(raw/'review.md').write_text('''# PR81 前独立质量复核：记录变更引用上下文

结论：`passed`，只适用于本切片。未发现需要修复的新产品问题；未修改业务、测试、配置或知识文件，未查询/触发CI、使用共享数据库、合并、部署或恢复数据。

- 目标/基点：`3b961a032ad4a21b2fdbd62d34bb0e26fc9e0a0d`，独立fetch前后未变。
- 固定受测候选：`8766a0f90cd2b34ff35e0a9a1bef719c5d997b00`，独立detached工作树 `/tmp/edhr-reference-qa-20261110`。
- 契约实际读取自候选；AGENTS、角色、知识与目标字节相同，知识0.3.25/schema1.2.0。决策包是本候选新增，L2影响/快照/权限/审计/兼容及扩展边界与8文件实际改动匹配。

## 源码和既有规则

原页面丢弃上下文和分页；原后台读取仅模型配置；原拟值逐字段校验证据且没有完整上下文/previous。这些是既有规则的实现偏差。现代码先合并完整拟值，再按同一冻结model/canvas校验可编辑字段，省略引用不能绕过依赖；不读取现行模板重解释历史。原不可修改顶字段skip、真实签署、审批/锁/事务/审计保持。

子表按记录控制内部稳定行ID匹配旧行，旧无原生__rowId的行重排不靠数组下标猜previous。每表建旧行map，每行浅合并主值和该行；共享叶子校验只读取context，不逐行深复制整表。历史原因仅按现有“typed metadata且与原值完全相等”的共享规则保留；没有新选失效原因的豁免。未发现本增量新增权限放宽、冗余兜底、静默默认或scope漂移。

只读POST沿原认证和来源资格转发context/page/size；旧GET沿保存的主值兼容，不推断具体子行。共享Lookup/ExecutionAccess/选择控件未改，人员完整性按DEC-0095，单批100不等于总上限。本体原件21个有限项=18一致、1精确历史局部替代、2范围外未决；353知识文件无变化。这不等于新增21个唯一覆盖或全知识语义审计完成。

## 实际验证

| 验证 | 本实例结果 | 口径 |
|---|---|---|
| 后端选定10类 | 158/158，0失败/错误/跳过 | 99原生PG16，59其他；其中15 H2补充，不能称158全PG |
| 本批新原生矩阵 | 12/12 | model/canvas × root/row-main、字段顺序/省略、旧原因无原生ID重排、实际POST/GET/401/400、152人员跨页、真实提交审批历史 |
| HTTP原件 | 82个预期状态全部相符，其中引用相关11个 | 非法提交400前后8表内容摘要相同；合法提交/审批200；Rev2=502、Rev1=501 |
| 知识自动校验 | 89/89，0失败/错误/跳过 | 本实例实际运行，359输入=353知识+5验证Java+POM |
| 维护页面浏览器 | 42/42=旧34+新8 | 桌面1440/窄屏390；真实页面/客户端/共享选择器，API拦截合成数据，无真实业务写 |
| build/list/font | 全部exit0 | 独立实际构建与规范检查 |
| strict repo根 | 原/新86=72violations+14unresolved，均exit2 | 保留重复项多重集0新增/0移除，未冒称全绿 |
| strict frontend根 | 原/新28=14violations+14unresolved，均exit2 | 是repo范围的子集，不能拿28替代86 |
| lint | exit2 | 原有ESLint配置缺失，保持开放 |

新引用浏览器含合法主/子表B候选、后页人员149实际选中、503显式重试；已查看对应390及1440截图。原34项保留异步过期响应、取消、候选错误/空值、IME、提交错误等行为。浏览器与原生PG是分开的证据链，不冒称联通的真实生产E2E。

原签名父表锁定4组旧签名/旧修订/旧哈希原件一致；原候选目录0/1/10/100/1000共20次读取均1SQL并保持数据摘要。审批权限、真实签署、锁、回滚、并发/幂等等适用相邻回归仍在158项中。已有20000背景任务读取计划原件也保留，但不据此宣称本切片的生产容量。

## 旧源码反证与验证过程

主侧 `focused_old_final` 原件已独立核对：固定目标旧产品源码，最终同字节原生测试SHA `52ddebd6610eae3192716e41c37e0da496fb1e30ed9245b6d88d8b1e1647aa7a`，12项中2正10真失败、0错误/跳过；不是fixture错误充当产品失败。本角色未重新执行旧源测试。旧browser_final原件8项实际失败、请求/截图/定位均保留；其最初没有预运行独立SHA收据，不能回填冒称已存在。

主侧先前fixture/harness校准历史未被抹去：最早native两项fixture错误（缺password_hash及HTTP后认证上下文）、浏览器语法0运行/缺部门fixture/定位校准，均不计作产品缺陷或最终通过。本实例浏览器首个命令因证据目录尚未创建而仅shell重定向失败、0项运行；依赖完成后运行维护脚本42项全过，没有改测试。首次静态工具多一个末尾LF与对应frontend28原件保留；随后按exact官方37716字节/SHA `67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68` 分别重跑repo/frontend对照，未改逻辑或产品。

## 剩余边界和清理

全仓strict86、lint缺配置、全知识语义、W2-W7余项、已审A23整体复看、A12/高风险/完整矩阵、生产容量UNKNOWN、未答性能和用户暂停项不关闭。旧存量在审/历史签名不自动净化或恢复。本候选按默认单租户既有资格运行，不等于完整多租户发布验收。

自有PG容器已关闭移除；自身node_modules软链已移除且主源依赖仍在，工作树最终clean。实际运行期间唯一untracked路径为该依赖软链，见run.json/cleanup.json；未将运行时状态伪装为clean。源文件全部与受测Git字节核对。`quality-result.yaml`为正式结构，`independent-analysis.json`为机械核对，`source-binding.json`、原始XML/HTTP/SQL/截图、manifest及SHA256SUMS共同绑定本结论。目标或候选变化后须按增量重新评估；本结论不授权合并或部署。
''')
print('formal report written; checks',len(checks))
