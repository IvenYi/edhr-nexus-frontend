import pathlib,json,re,collections,hashlib,subprocess,shutil
o=pathlib.Path('/tmp/edhr-workflow-reads-final-qa-20261104/server-sql');r=pathlib.Path('/workspace/edhr-nexus-frontend')
def norm(sql):return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql)).strip().rstrip(';')
events=list(map(json.loads,(o/'observations.jsonl').read_text().splitlines()));expected=collections.Counter()
for e in events:
 assert e['totalStatements']==len(e['jdbcSql'])+len(e['hibernateSql'])
 expected.update(norm(s) for s in e['jdbcSql']+e['hibernateSql'])
lines=(o/'postgres.log').read_text().splitlines();messages=[];current=None
for no,line in enumerate(lines,1):
 m=re.match(r'^(\d{4}-\d\d-\d\d .*?) \[(\d+)\] (LOG|DETAIL|HINT|ERROR|WARNING|FATAL|STATEMENT):\s*(.*)$',line)
 if m:
  if current:messages.append(current)
  current={'line':no,'timestamp':m.group(1),'pid':m.group(2),'level':m.group(3),'message':m.group(4)}
 elif current:current['message']+='\n'+line
if current:messages.append(current)
actual=collections.Counter();matched=[];allselects=[]
for m in messages:
 if m['level']!='LOG':continue
 x=re.match(r'(?:execute\s+\S+:|statement:)\s*(.*)',m['message'],re.S)
 if not x:continue
 sql=x.group(1);key=norm(sql)
 if re.match(r'^SELECT\b',key,re.I):allselects.append({'line':m['line'],'sql':key})
 if key in expected:
  actual[key]+=1;matched.append({'line':m['line'],'pid':m['pid'],'sql':key})
comparisons=[{'normalizedSql':k,'observationStatements':v,'serverExecutedStatements':actual[k],'equal':v==actual[k]} for k,v in sorted(expected.items())]
proof={'normalization':'Whitespace collapsed and PostgreSQL $n placeholders changed to JDBC ?. Case and literals preserved; optional terminal semicolon removed.','observations':len(events),'observationStatementTotal':sum(expected.values()),'serverMatchedStatementTotal':sum(actual.values()),'distinctObservedSqlSignatures':len(expected),'serverAllSelectMessages':len(allselects),'allObservedSignaturesExact':all(x['equal'] for x in comparisons),'comparisons':comparisons,'matchedLogLocations':matched,'scope':'Aggregate match of all SQL signatures emitted by current10 observation cases; startup/DDL/fixture/DML/control statements excluded because signatures absent from captured observations. No wall-clock/SLA or arbitrary future JDBC-entry claim.'}
(o/'server-crosscheck.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
assert proof['allObservedSignaturesExact'],comparisons
commands=json.loads((o/'commands.json').read_text());statuses=[c for c in commands if c['args']==['git','status','--porcelain=v1']]
assert statuses[1]['stdout']=='?? gmp-platform/frontend/node_modules\n'
for f in json.loads((o/'source-fingerprints.json').read_text()):
 b=subprocess.check_output(['git','show','b687300ac8f02b9c6a307f58c8ddc525e7e7b6e5:'+f['path']],cwd=r)
 assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
cleanup=json.loads((o/'cleanup.json').read_text());assert cleanup['containerRemoved'] and cleanup['worktreeRemoved'] and cleanup['mainStatus']==''
(o/'runner-postcheck-reconciliation.json').write_text(json.dumps({'nativeMavenExitCode':json.loads((o/'run.json').read_text())['exitCode'],'runnerWrapperExitCode':1,'cause':'Post-run helper asserted fully empty git status before unlinking its intentional tooling symlink. Raw status contained only ?? gmp-platform/frontend/node_modules; no tracked modification. Native10 tests had passed.','rawExceptionPreserved':'runner-console.log','originalWorktreeStatus':statuses[1],'sourceFingerprintsMatchTestedCandidate':True,'ownedResourcesRemoved':True,'mainRepositoryClean':True,'nativeTestsRerunForThisToolAssertion':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:proof[k] for k in ['observations','observationStatementTotal','serverMatchedStatementTotal','distinctObservedSqlSignatures','serverAllSelectMessages','allObservedSignaturesExact']},ensure_ascii=False))
