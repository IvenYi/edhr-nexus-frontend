import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,xml.etree.ElementTree as ET,sys
repo=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-workflow-reads-final-qa-20261104');out.mkdir(exist_ok=True)
tree=pathlib.Path('/tmp/edhr-workflow-reads-qa-tree-20261104');candidate='b687300ac8f02b9c6a307f58c8ddc525e7e7b6e5';base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
container='edhr-workflow-reads-final-qa-20261104';db='edhr_record_control_test_reads_finalqa';commands=[];created_tree=False;created_pg=False
def command(args,cwd=None,env=None,log=None,check=True):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    if log:
        with pathlib.Path(log).open('w') as f:p=subprocess.run(args,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,text=True)
        stdout=None;stderr=None
    else:
        p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True);stdout=p.stdout;stderr=p.stderr
    commands.append({'args':args,'cwd':str(cwd) if cwd else None,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':p.returncode,'stdout':stdout,'stderr':stderr,'log':str(log) if log else None})
    (out/'orchestration-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
    if check and p.returncode:raise RuntimeError('Command failed: '+repr(args))
    return stdout.strip() if stdout else p.returncode
def reports(source,dest,start,expected):
    dest.mkdir(parents=True,exist_ok=True);totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[]
    for p in sorted(source.glob('TEST-*.xml')):
        if p.stat().st_mtime<start:continue
        shutil.copy2(p,dest/p.name);root=ET.parse(p).getroot();c={k:int(root.attrib.get(k,0)) for k in totals};classes.append({'class':root.attrib['name'],**c})
        for k,v in c.items():totals[k]+=v
        txt=p.with_name(p.name[5:-4]+'.txt')
        if txt.exists():shutil.copy2(txt,dest/txt.name)
    summary={'totals':totals,'classes':classes};(dest.parent/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    assert totals=={'tests':expected,'failures':0,'errors':0,'skipped':0},summary
    return summary
code=1
try:
    command(['git','fetch','origin','edhr-dev'],cwd=repo)
    head=command(['git','rev-parse','HEAD'],cwd=repo);target=command(['git','rev-parse','origin/edhr-dev'],cwd=repo);status=command(['git','status','--porcelain=v1'],cwd=repo)
    assert head==candidate and target==base and not status
    command(['git','merge-base','--is-ancestor',base,candidate],cwd=repo)
    (out/'baseline-start.json').write_text(json.dumps({'head':head,'target':target,'workingTree':'clean','candidateBasedOnTarget':True},indent=2)+'\n')
    command(['git','worktree','add','--detach',str(tree),candidate],cwd=repo);created_tree=True
    dep=tree/'gmp-platform/frontend/node_modules';dep.symlink_to(repo/'gmp-platform/frontend/node_modules',target_is_directory=True)
    fingerprints=[]
    paths=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']
    for name in paths:
        data=(tree/name).read_bytes();dest=out/'source-snapshot'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);fingerprints.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    (out/'source-fingerprints.json').write_text(json.dumps(fingerprints,indent=2)+'\n')
    cid=command(['docker','run','--rm','-d','--name',container,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine']);created_pg=True
    for i in range(120):
        if subprocess.run(['docker','exec',container,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.5)
    else:raise RuntimeError('Own PG not ready')
    command(['docker','exec',container,'psql','-U','postgres','-d',db,'-c','CREATE ROLE edhr LOGIN'])
    command(['docker','exec',container,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
    command(['docker','exec',container,'createdb','-U','postgres','edhr_workflow_read_test_finalqa'])
    port=command(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',container])
    env=os.environ.copy();env.update(PGUSER='postgres',RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_workflow_read_test_finalqa',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test')
    (out/'native').mkdir(exist_ok=True);(out/'knowledge').mkdir(exist_ok=True)
    selected='WorkflowReadObservationPostgresTest,RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest'
    native_args=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'native/observations.jsonl'),'-Dtest='+selected,'test']
    native_start=time.time();native_exit=command(native_args,cwd=tree,env=env,log=out/'native/maven.log',check=False)
    native=reports(tree/'gmp-platform/backend/target/surefire-reports',out/'native/surefire',native_start,148);assert native_exit==0
    knowledge_start=time.time();knowledge_exit=command(['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test'],cwd=tree,log=out/'knowledge/maven.log',check=False)
    knowledge=reports(tree/'tools/knowledge-model/target/surefire-reports',out/'knowledge/surefire',knowledge_start,89);assert knowledge_exit==0
    version=command(['docker','exec',container,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])
    for database in [db,'edhr_workflow_read_test_finalqa']:
        text=command(['docker','exec',container,'psql','-U','postgres','-d',database,'-Atc','SELECT id,exectype FROM databasechangelog ORDER BY orderexecuted'])
        (out/'native'/('liquibase-'+database+'.txt')).write_text(text+'\n')
    (out/'run-result.json').write_text(json.dumps({'candidate':candidate,'base':base,'databases':{k:env[k] for k in ('RECORD_CONTROL_TEST_DATABASE_URL','WORKFLOW_READ_TEST_DATABASE_URL','W3_TRANSFER_DATABASE_URL')},'postgres':version,'nativeExit':native_exit,'knowledgeExit':knowledge_exit,'native':native['totals'],'knowledge':knowledge['totals']},indent=2)+'\n')
    assert not command(['git','status','--porcelain=v1'],cwd=tree)
    code=0
finally:
    cleanup={}
    if created_pg:
        subprocess.run(['docker','logs',container],stdout=(out/'native-postgres.log').open('w'),stderr=subprocess.STDOUT)
        command(['docker','stop',container]);removed=False
        for i in range(30):
            if subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:removed=True;break
            time.sleep(.1)
        cleanup['ownContainerRemoved']=removed
    if created_tree:
        dep=tree/'gmp-platform/frontend/node_modules'
        if dep.is_symlink():dep.unlink()
        command(['git','worktree','remove',str(tree)],cwd=repo);cleanup['ownWorktreeRemoved']=not tree.exists()
    cleanup['mainStatus']=command(['git','status','--porcelain=v1'],cwd=repo)
    (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
sys.exit(code)
