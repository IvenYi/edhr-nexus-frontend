import pathlib,subprocess,hashlib,json,tarfile,xml.etree.ElementTree as ET,collections,yaml,shutil
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=pathlib.Path(__file__).parent;b=r/'docs/development/branch-review-20261104-detail-reads'
base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620';head='b687300ac8f02b9c6a307f58c8ddc525e7e7b6e5';checks=[]
def sha(v):return hashlib.sha256(v).hexdigest()
def check(i,condition,detail):
 checks.append({'id':i,'passed':bool(condition),'detail':detail});assert condition,(i,detail)
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
check('baseline-clean',git('rev-parse','HEAD').decode().strip()==head and not git('status','--porcelain=v1'),'Current candidate clean exact head')
check('target-and-ancestor',git('rev-parse','origin/edhr-dev').decode().strip()==base and subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=r).returncode==0,'Target unchanged; target ancestor')
changed=git('diff','--name-only','-z',base,head).decode().split('\0');check('product-contract-knowledge-and-old-tests-unchanged',all(not x or x.startswith('docs/development/') or x=='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java' for x in changed),changed)
manifest=json.loads((b/'evidence-manifest.json').read_text());arc=b/manifest['archive']['path'];raw=arc.read_bytes()
check('stored-gzip-hash',len(raw)==manifest['archive']['bytes'] and sha(raw)==manifest['archive']['sha256'],manifest['archive'])
with tarfile.open(arc) as t:
 members={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
check('raw-member-set',len(members)==len(manifest['rawArtifacts'])==70 and set(members)=={f['member'] for f in manifest['rawArtifacts']},'70 exact raw members; no archive copied into this result')
for f in manifest['rawArtifacts']:assert len(members[f['member']])==f['bytes'] and sha(members[f['member']])==f['sha256'],f['member']
check('all70-raw-member-fingerprints',True,'Each raw member byte length and SHA256 recomputed')
nested=json.loads(members['ontology/manifest.json']);assert nested['status']=='FINAL' and nested['ontologyResult']=='not-applicable'
for f in nested['artifacts']:assert len(members['ontology/'+f['path']])==f['bytes'] and sha(members['ontology/'+f['path']])==f['sha256']
check('nested-ontology-manifest',len(nested['artifacts'])==nested['artifactCount']==35 and sha(members['ontology/manifest.json'])=='f1ba90746b9887589bf7a1446734b50d95fc39dd04abf3d07961948a21379cdf','35 originals independently verified')
for name,count in [('observe',10),('regression',148)]:
 summary=json.loads(members[f'primary/{name}/test-summary.json']);assert summary['totals']=={'tests':count,'failures':0,'errors':0,'skipped':0} and not summary['missingFreshReports']
 xml=[ET.fromstring(v) for n,v in members.items() if n.startswith(f'primary/{name}/TEST-') and n.endswith('.xml')]
 total={k:sum(int(x.get(k,'0')) for x in xml) for k in ['tests','failures','errors','skipped']};assert total==summary['totals']
 assert json.loads(members[f'primary/{name}/cleanup.json'])['removed']
check('raw-xml-main148-initial10-not-summed',True,'10 initial plus final148 are separate passes, unique accepted suite148')
events=list(map(json.loads,members['primary/regression/observations.jsonl'].decode().splitlines()));assert len(events)==10
by_key={}
for e in events:
 assert e['jdbcStatements']==len(e['jdbcSql']) and e['hibernateStatements']==len(e['hibernateSql'])
 assert e['totalStatements']==len(e['jdbcSql'])+len(e['hibernateSql'])
 assert e['jdbcSqlCounts']==dict(collections.Counter(e['jdbcSql']))
 key=(e['kind'],e['data'].get('tasks',e['data'].get('matchingPersonnel')));assert key not in by_key;by_key[key]=e
for n in [0,1,100,1000]:
 e=by_key['workflow-detail',n];assert e['totalStatements']==5+n and e['data']['returnedTasks']==n and sum(v for k,v in e['jdbcSqlCounts'].items() if k.startswith('SELECT display_name'))==n
for n in [0,1,99,100,101,5000]:
 e=by_key['personnel-directory',n];assert e['totalStatements']==(1 if n<100 else 2) and e['data']['returnedPersonnel']==min(n,100) and sum('count(' in x.lower() for x in e['hibernateSql'])==(0 if n<100 else 1)
check('ten-observation-raw-sql-consistency',True,'Each event count recomputed from raw SQL lists; detail5+N/directory1-or2 current baseline facts, not asserted performance contracts')
report=json.loads((b/'performance-report.json').read_text());assert len(report['observations'])==10
for x in report['observations']:
 key=(x['kind'],x['data'].get('tasks',x['data'].get('matchingPersonnel')));e=by_key[key]
 for k in ['data','jdbcStatements','hibernateStatements','totalStatements','elapsedNanos']:assert x[k]==e[k],(key,k)
check('report-matches-final-raw-events',not report['performanceFixed'] and not report['productCodeChanged'] and not report['runtimeBrowserOrHttpTested'] and not report['wholeAuditComplete'] and all(f['status']=='open-awaiting-implementation-discussion' for f in report['findings']),'Two performance findings remain open, diagnostic success does not close them')
fps=json.loads((b/'source-review.json').read_text())['sourceFingerprints']
for f in fps:
 v=(r/f['path']).read_bytes();assert len(v)==f['bytes'] and sha(v)==f['sha256'] and v==git('show',head+':'+f['path'])
check('nine-current-source-fingerprints',len(fps)==9,'Current candidate9 paths verified, no whole-file coverage inference')
ofps=json.loads(members['ontology/source-fingerprints.json'])['files']
for f in ofps:
 v=(r/f['path']).read_bytes();assert len(v)==f['bytes'] and sha(v)==f['sha256'],f['path']
check('ontology25-source-fingerprints',len(ofps)==25,'25 ontology current source fingerprints verified; overlaps not unique coverage')
kb=json.loads(members['ontology/knowledge-byte-check.json']);assert kb['count']==345 and kb['allUnchanged'] and not kb['semanticAuditOfAllFiles']
for f in kb['files']:
 v=(r/f['path']).read_bytes();assert len(v)==f['bytes'] and sha(v)==f['sha256'] and v==git('show',base+':'+f['path'])
check('knowledge345-byte-recheck',True,'345 current bytes independently equal base; not semantic completion')
onto=yaml.safe_load((b/'ontology-result.yaml').read_text());scope=onto['verificationScope'];ids=json.loads(members['ontology/finite-id-review.json'])
check('ontology-eight-ids-and-no-test-claim',ids['count']==len(ids['records'])==8 and scope['formalKnowledgeTestsExecuted']==scope['nativeTestsExecuted']==0 and scope['browserExecuted'] is False and scope['pendingKnowledgeIncrementCandidates']==931,'Ontology NA/FINAL finite8; no89/native/browser executed by that role')
source=(r/'gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java').read_text()
guard=['@EnabledIfSystemProperty(named = "edhr.audit.workflowReads", matches = "true")','@EnabledIfEnvironmentVariable(named = "WORKFLOW_READ_TEST_DATABASE_URL"','edhr_workflow_read_test_','@Import(WorkflowReadObservationPostgresTest.Config.class)','@TestConfiguration static class Config','ThreadLocal<Read<?>>','finally { read.elapsedNanos','CURRENT.remove();','@AfterEach void clear()']
check('opt-in-and-context-and-thread-isolation',all(s in source for s in guard),'Two gates and duplicate disposable DB validation; TestConfiguration explicitly imported only here; current-thread/finally/afterEach cleanup')
check('semantic-assertions-not-bad-count-budgets','assertThat(read.jdbcSql' not in source and 'assertThat(read.hibernateSql' not in source and 'assertThat(read.value)' in source and 'assertThat(task.get("assigneeName"))' in source,'SQL lists are observed, counts are not fixed in test assertions; response semantics asserted')
baseline=json.loads((b/'baseline-review.json').read_text());sr=json.loads((b/'source-review.json').read_text())
paths=[p for p in git('ls-tree','-r','--name-only','-z',base).decode().split('\0') if p]
check('inventory-and-unfinished-accounting',len(paths)==baseline['trackedPaths']==7435 and sha('\0'.join(paths).encode())==baseline['pathListSha256'] and baseline['wholeFileComplete']==sr['wholeFileComplete']==0 and baseline['historicalUniqueCoverage'] is None and baseline['pendingKnowledgeCandidates']==931 and baseline['priorUiDiagnosticCandidates']==86,'7435 is inventory only, full semantic audit/931/86 not closed')
source_snapshots=['AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml']
source_snapshots+=['docs/development/branch-review-20261104-detail-reads/'+n for n in ['decision-package.yaml','README.md','review-notes.md','performance-report.json','source-review.json','baseline-review.json','ontology-result.yaml','evidence-manifest.json']]
for p in source_snapshots:
 dest=o/'read-sources'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes((r/p).read_bytes())
(o/'checks.json').write_text(json.dumps({'checks':checks,'allPassed':all(c['passed'] for c in checks),'count':len(checks)},ensure_ascii=False,indent=2)+'\n')
(o/'archive-verification.json').write_text(json.dumps({'archive':manifest['archive'],'rawArtifacts':manifest['rawArtifacts'],'nestedOntologyManifestSha256':sha(members['ontology/manifest.json']),'nestedOntologyArtifacts':35,'sourceFingerprints':fps,'ontologyFingerprintCount':len(ofps)},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'checksPassed':len(checks),'originalArtifactsVerified':70,'ontologyArtifactsVerified':35,'sourceFingerprints':len(fps),'ontologyFingerprints':len(ofps),'knowledgeFiles':345},ensure_ascii=False))
