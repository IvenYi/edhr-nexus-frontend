# 有限本体边界核对

基线：`edhr-dev@fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620`。本角色实际重读契约于fa，独立fetch确认目标不变；该树与上一交付8b53相同。父角色decisionPackage记录其本人实际读契约为8b53，不将其改填成fa；两个值不冲突。知识0.3.25/schema1.2.0、P0进行中保持。

本角色只做有限读取边界核对，未修改仓库，未运行正式知识、原生或浏览器测试。全部345个知识文件与fa字节相同，是机器保持证明，不是345个文件语义审计完成。8个既有声明见finite-id-review.json；它们与旧工作可能重叠，不累计历史唯一覆盖，不等同于上轮19个ID或931个待审候选。

## 当前姓名与历史签署身份

WorkflowOperationsQuery.detail的tasks.assigneeName按当前user_account.display_name读取；空assigneeId或查不到账户时沿现有“待候选人处理”fallback，任务taskState、signatureId、opinion和action仍来自该任务。该姓名字段是当前目录投影，不是签名时身份。当前源码对每个任务分别读取是可量化成本候选；本角色不把静态5+N或Page满页COUNT推算当实际SQL执行结果。

该详情的logs.operatorName也以COALESCE(current user.display_name, stored operator_name, operator_id)展示，当前目录名优先是现有工程事实，不是本轮新确认的业务政策。原WorkflowActionLog.operatorName/snapshot、责任审计contentAfter和Signature.signerName/snapshotData各自保存动作及签署时证据。ExecutionAccess.signTarget把会话身份和实际签署人分开，签名与内容hash沿原证据。DEC0074-01和DEC0093-03要求保留这些身份及关联，不能为了减少目录查询而用当前姓名覆盖历史签署证据。

未来如批量读取姓名，应保持现有任务ID、状态摘要、可见范围、姓名查找和fallback语义；当前名字不能被当成历史签署人的重新认定，也不能顺带改日志姓名优先级或历史显示政策。对当前展示“已删除账户仍显示待候选人处理”的用户体验是否另行改名，本批没有给出新政策，也不借取证修改。

## 读取与运行领域所有权

DEC0092-01的流程日志/干预入口和DEC0093-01的普通表单、DHR覆盖只提供已有领域事实的按权投影。WorkflowOperationsQuery.visibility在读取前限制范围，干预权限另承载管理查询；本批观测选择现有干预读取身份，不能替代普通账号、JWT或完整权限矩阵。表单仍用FormWorkflowOperations原生投影，DHR运行与冻结版本仍归其领域；不建立第二套运行任务，不从“能够查询详情”推导“能够审批或填报”。

## 目录和动作边界

TenantTransferTargets继续组合租户、ACTIVE、未锁定、当前处理人排除、关键词及排序，最多100条；额外双权限或Specification仍由既有领域消费者指定。WorkflowResponsibilityService.targets/eligible的原候选、unrestricted、记录控制申请人回避、DHR双权限分支及写入校验均与fa相同。

DEC0081-01/02只允许通用任务与普通表单本人显式租户内委托并分别保留原来源与当前责任；DEC0092-02的记录控制转办仍按原候选且申请人回避。目录额外COUNT取证既不放宽集合，也不把新读取性能机制列为业务规则。无新增政策、声明级替代或业务未决，ontologyResult为not-applicable。

## 验证与残余范围

实际检查仅：Git基线/整树和产品/知识/契约/架构差异、345文件字节比对、25个当前输入/来源指纹、8个声明的有限原始确认与源码核对。新观测测试的工具及夹具允许主审继续完善，本角色没有将该测试指纹锁成最终产品候选。正式89项和原生观测/相邻回归、最终质量由主审及全新QA执行。

931知识候选、86全仓UI诊断、完整多租户/账号/签署/收件人矩阵、W2-W7、原高风险/A12及暂停项均保留。现有open-question集合仍为questions；探索性摘要脚本曾误写openQuestions得到KeyError，已按实际键只读重查，该工具错误不计产品失败或测试失败。未查询/触发CI、未合并/部署、未恢复历史或修改任何产品/知识资产。
