import pathlib, subprocess, hashlib, json, yaml, datetime

root = pathlib.Path('/workspace/edhr-nexus-frontend')
out = pathlib.Path('/tmp/edhr-workflow-read-ontology-20261104')
out.mkdir(exist_ok=False)
base = 'fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620'
prior = '8b53f71d272ece3328b17a4c50ecdd2b700c45a9'
commands = []
def sha(data): return hashlib.sha256(data).hexdigest()
def run(args):
    result = subprocess.run(args, cwd=root, capture_output=True, text=True)
    commands.append({'args':args, 'exitCode':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr})
    if result.returncode: raise RuntimeError(args)
    return result.stdout
def write(name, value):
    (out/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

head = run(['git','rev-parse','HEAD']).strip()
target = run(['git','rev-parse','origin/edhr-dev']).strip()
assert target == base
assert not run(['git','diff','--name-only',prior,base])
assert not run(['git','diff','--name-only',base,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture','gmp-platform/backend/src/main','gmp-platform/frontend/src'])
initial_status = run(['git','status','--porcelain=v1'])
knowledge = []
for path in run(['git','ls-tree','-r','--name-only',base,'--','docs/knowledge']).splitlines():
    actual=(root/path).read_bytes()
    expected=subprocess.check_output(['git','show',base+':'+path],cwd=root)
    assert actual==expected,path
    knowledge.append({'path':path,'bytes':len(actual),'sha256':sha(actual),'matchesBaseline':True})
assert len(knowledge)==345
write('knowledge-byte-check.json',{'baseCommit':base,'files':knowledge,'count':len(knowledge),'allUnchanged':True,'semanticAuditOfAllFiles':False})

paths = [
 'AGENTS.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md',
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml',
 'docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml',
 'docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml',
 'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
 'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
 'docs/knowledge/rules/identity.yaml','docs/knowledge/rules/workflow-central-entry.yaml',
 'docs/knowledge/evidence/button-signature-confirmed.md',
 'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md',
 'docs/knowledge/evidence/workflow-operations-20261030.md',
 'docs/knowledge/evidence/central-form-dhr-workflow-20261102.md',
 'docs/development/workflow-operations-20261030/user-confirmed.md',
 'docs/development/workflow-central-entry-extension-20261102/user-confirmed.md',
 'docs/development/branch-review-20261104-detail-reads/decision-package.yaml',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
 'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/Signature.java'
]
fingerprints=[]
for path in paths:
    data=(root/path).read_bytes();p=out/'read-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    committed=path!='docs/development/branch-review-20261104-detail-reads/decision-package.yaml'
    if committed: assert data==subprocess.check_output(['git','show',base+':'+path],cwd=root),path
    fingerprints.append({'path':path,'bytes':len(data),'sha256':sha(data),'sourceRevision':base if committed else 'working-tree decisionPackage','baselineBytesEqual':committed})
write('source-fingerprints.json',{'baseCommit':base,'files':fingerprints,'note':'Only listed source anchors/references; not whole-file semantic completion. Observation test intentionally not pinned as final product.'})

scope_rows=[
 ('DEC-0074-01','DEC-0074-shared-terminal-button-signature.yaml','实际签署人身份与会话身份分开；当前目录姓名不能重写signature.signerName/snapshotData。','docs/knowledge/evidence/button-signature-confirmed.md'),
 ('DEC-0081-01','DEC-0081-tenant-scoped-task-delegation.yaml','通用/普通表单本人转办的同租户正常可用目标范围保留，目录成本观测不加候选或权限政策。','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md'),
 ('DEC-0081-02','DEC-0081-tenant-scoped-task-delegation.yaml','原候选来源与当前责任分开；姓名只读不重算冻结来源或让旧候选获得处理权。','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md'),
 ('DEC-0092-01','DEC-0092-workflow-operations-entry-and-actions.yaml','流程日志/干预继续既有实例读取和身份，不新增重复运行任务或改变历史身份。','docs/development/workflow-operations-20261030/user-confirmed.md'),
 ('DEC-0092-02','DEC-0092-workflow-operations-entry-and-actions.yaml','记录控制转办仍原候选且申请人回避，不从通用租户内委托外推开放范围。','docs/knowledge/evidence/workflow-operations-20261030.md'),
 ('DEC-0093-01','DEC-0093-central-form-dhr-workflow-responsibility.yaml','集中只读查询按领域授权，菜单/读取不授予动作；表单和DHR拥有各自运行事实。','docs/development/workflow-central-entry-extension-20261102/user-confirmed.md'),
 ('DEC-0093-03','DEC-0093-central-form-dhr-workflow-responsibility.yaml','责任历史和领域数据审计保留实际会话/签署人及签名关联；当前姓名投影不是历史签名证据。','docs/development/workflow-central-entry-extension-20261102/user-confirmed.md'),
 ('DEC-0093-04','DEC-0093-central-form-dhr-workflow-responsibility.yaml','具体查询/分页/权限码属于工程选择；SQL次数和本地观测不冒充新政策、全系统或生产验收。','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md')
]
rows=[]
for id,name,scope,evidence in scope_rows:
    path='docs/knowledge/decisions/'+name
    doc=yaml.safe_load((root/path).read_text());record=next(s for d in doc['decisions'] for s in d['decisionStatements'] if s['id']==id)
    rows.append({'id':id,'recordType':'decision-statement','sourcePath':path,'sourceLocator':'decisionStatements[id='+id+']','sourceRevision':base,'originalMaturity':record['status'],'visibility':record['visibility'],'auditScopeCategory':'finite-read-projection-and-directory-boundary','semanticReviewStatus':'reviewed','conclusion':'consistent','scope':scope,'originalEvidence':[evidence],'implementationReferences':paths[-5:],'newHistoricalUniqueCoverageClaim':False})
write('finite-id-review.json',{'count':len(rows),'records':rows,'note':'Finite reread only; overlaps previous work. No added historical unique count or931-candidate closure.'})
write('baseline.json',{'sourceCommitAtReview':head,'targetCommit':target,'contractReadCommit':base,'previousDeliveredCommit':prior,'targetTreeEqualsPreviousDelivery':True,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeFiles':345,'trackedRuntimeKnowledgeContractArchitectureDeltaFromBase':[],'parentWorktreeStatus':initial_status.splitlines(),'roleChangedRepositoryPaths':[],'testsExecutedByRole':[],'childRoles':[]})
questions=yaml.safe_load((root/'docs/knowledge/open-questions.yaml').read_text())
write('open-question-scope.json',{'collection':'questions','ids':[q['id'] for q in questions['questions']],'relevantExistingNonBlockingResidual':'question.multi-tenant-workflow-isolation','newQuestionsForThisSlice':[],'allExistingQuestionsRemain':True})
write('helper-discovery-error.json',{'command':'python YAML overview using x[openQuestions]','exitCode':1,'error':'KeyError: openQuestions','classification':'Read-only inspection helper assumed wrong collection name. Actual key questions was read and corrected in subsequent inspection. No repository/test/knowledge modification or test failure.','countedAsProductOrValidationFailure':False})

result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':base,'uncommittedContractPaths':[]},
 'reason':'本轮仅新增opt-in原生只读观测测试，全部产品代码、知识、契约和架构字节保持；有限核对当前目录姓名、历史签署证据、只读领域所有权和既有目录目标范围，未引入新业务政策或定义替代。查询优化选择仍待主审与用户讨论，不需改写知识。',
 'changedArtifacts':[],
 'knowledgeSync':[{'id':row['id'],'disposition':'retained','scope':row['scope'],'sourceReferences':[row['sourcePath']]+row['originalEvidence']} for row in rows],
 'conflicts':[],'questions':[],
 'validationEvidence':[
   {'id':'validation.stable-baseline-and-source','checkType':'reference','command':'git rev-parse / git diff previousDelivery..base and base..workingTree over product, contracts, knowledge and architecture','outcome':'passed','evidence':['baseline.json','commands.json','source-fingerprints.json']},
   {'id':'validation.knowledge-byte-preservation','checkType':'reference','command':'Compare all345 tracked docs/knowledge file bytes against fa592169 Git blobs','outcome':'passed','evidence':['knowledge-byte-check.json']},
   {'id':'validation.finite-policy-read-boundary','checkType':'evidence-path','command':'Read eight existing statements, original confirmations and five current product anchors; separate current-name projection from persisted signature/audit identity','outcome':'passed','evidence':['finite-id-review.json','semantic-review.md','read-snapshot/']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
},'verificationScope':{
 'status':'FINAL','formalKnowledgeTestsExecuted':0,'nativeTestsExecuted':0,'browserExecuted':False,'roleChangedRepositoryPaths':[],
 'finiteExistingStatementsReviewed':8,'newHistoricalUniqueCoverageClaim':False,'knowledgeFilesByteCompared':345,'fullKnowledgeSemanticAuditComplete':False,
 'pendingKnowledgeIncrementCandidates':931,'priorUiDiagnosticCandidatesStillPending':86,'sourceFingerprints':len(fingerprints),'childRoles':[],
 'readScope':'Mandatory governance references loaded; relevant model/ownership/status/stage and open-question scope read. Historical prose/source snapshots are provenance, not whole-file semantic completion.',
 'testFingerprintIntentionallyNotFinal':'Parent may adjust observation tools/fixtures; this role pins stable product anchors and current decisionPackage only.',
 'residuals':['Future batching must preserve existing current-name fallback and task/visibility semantics without replacing historical signatures','No actual SQL counts, execution-plan or production SLA certified by this role; main/final QA execute tests','Full account/JWT/browser/signature/tenant/recipient matrices,931 knowledge/86 UI, W2-W7/high/A12 and paused scopes remain']
}}
(out/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
write('commands.json',commands)
print(json.dumps({'out':str(out),'finiteStatements':len(rows),'knowledgeUnchanged':len(knowledge),'sourceFingerprints':len(fingerprints),'result':result['ontologyResult']['result']},ensure_ascii=False))
