import pathlib,subprocess,json,hashlib,tarfile,shutil,yaml
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=r/'docs/development/branch-review-20261104-detail-reads';o.joinpath('evidence').mkdir(exist_ok=True)
base='fa5921698f5fa4024ad7ca86ee2a90e3cd3a9620';onto=pathlib.Path('/tmp/edhr-workflow-read-ontology-20261104')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((onto/'manifest.json').read_bytes())=='f1ba90746b9887589bf7a1446734b50d95fc39dd04abf3d07961948a21379cdf'
m=json.loads((onto/'manifest.json').read_text());assert len(m['artifacts'])==m['artifactCount']==35
for f in m['artifacts']:
 b=(onto/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert yaml.safe_load((onto/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
files=[]
for mode,count in [('observe',10),('regression',148)]:
 d=pathlib.Path('/tmp/edhr-workflow-read-main-'+mode+'-20261104');s=json.loads((d/'test-summary.json').read_text());assert s['totals']=={'tests':count,'failures':0,'errors':0,'skipped':0}
 assert len((d/'observations.jsonl').read_text().splitlines())==10
 for f in json.loads((d/'run.json').read_text())['sourceFingerprints']:
  b=(d/'source-snapshot'/f['path']).read_bytes();assert sha(b)==f['sha256'] and b==(r/f['path']).read_bytes()
  if '/src/main/' in f['path']:assert b==subprocess.check_output(['git','show',base+':'+f['path']],cwd=r)
 assert json.loads((d/'cleanup.json').read_text())['removed']
 for p in sorted(d.rglob('*')):
  if p.is_file():files.append(('primary/'+mode+'/'+str(p.relative_to(d)),p))
for p in sorted(onto.rglob('*')):
 if p.is_file():files.append(('ontology/'+str(p.relative_to(onto)),p))
for n in ['run-workflow-read-audit.py','archive-workflow-read-primary.py','edhr-workflow-read-observe-runner-20261104.log','edhr-workflow-read-regression-runner-20261104.log']:
 files.append(('tools/'+n,pathlib.Path('/tmp')/n))
raw=[{'member':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files];a=o/'evidence/primary-and-ontology.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,p in files:t.add(p,arcname=n,recursive=False)
(o/'evidence-manifest.json').write_text(json.dumps({'sourceHeadDuringRuns':base,'rawArtifacts':raw,'archive':{'path':str(a.relative_to(o)),'bytes':a.stat().st_size,'sha256':sha(a.read_bytes())},'note':'Original trial10 and final148 not cumulative coverage. Products unchanged; one uncommitted new test at these runs. Raw member bytes and gzip storage bytes distinct. Performance not fixed.'},ensure_ascii=False,indent=2)+'\n');shutil.copy2(onto/'ontology-result.yaml',o/'ontology-result.yaml')
print(json.dumps({'rawArtifacts':len(raw),'archiveBytes':a.stat().st_size,'archiveSha256':sha(a.read_bytes())},ensure_ascii=False))
