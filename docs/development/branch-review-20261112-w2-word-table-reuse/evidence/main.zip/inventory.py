from pathlib import Path
import collections,csv,datetime,json,subprocess
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
candidate='de9aa396115ac326dd016235ec664a9c0c95fe15';target='8a415040babc1cc91ca9f5683bf0db46829eea76'
data=subprocess.check_output(['git','ls-tree','-r','-l','-z',candidate],cwd=repo)
rows=[]
for entry in data.split(b'\0'):
 if not entry:continue
 meta,p=entry.split(b'\t',1);mode,kind,blob,size=meta.decode().split();path=p.decode();domain='support';work='W0/W7';exclude=''
 if path.startswith('docs/knowledge/'):asset='knowledge';domain='knowledge';work='W0/W7'
 elif path.startswith('docs/development/branch-review-') or '/evidence/' in path:asset='audit-evidence';exclude='历史证据按归属保留，不把原件重复计为新源码/语义覆盖'
 elif path.endswith('.sql'):asset='sql';domain='database';work='W5/W6'
 elif '/src/test/' in path or '/scripts/test-' in path:asset='test';work='W5/W7'
 elif path.endswith(('.java','.ts','.tsx','.js','.mjs','.cjs','.css','.py','.sh')):asset='source' if '/src/' in path else 'tool-code';work='W2/W3/W4/W5/W6'
 elif path.endswith(('.yaml','.yml','.json','.xml','.toml')):asset='configuration';work='W5/W6'
 elif path.endswith('.md'):asset='documentation'
 else:asset='other';exclude='需按实际用途判断；未由本轮机械盘点自动通过'
 if '/com/zencas/edhr/' in path:domain=path.split('/com/zencas/edhr/',1)[1].split('/')[0]
 if '/frontend/src/pages/' in path:domain=path.split('/frontend/src/pages/',1)[1].split('/')[0]
 rows.append(dict(path=path,gitBlob=blob,bytes=int(size) if size!='-' else None,assetType=asset,domain=domain,workPackage=work,scope='inventory-only',exclusionReason=exclude,reviewConclusion='no-new-whole-file-conclusion'))
with (raw/'baseline-tree-inventory.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
delta=subprocess.check_output(['git','diff','--name-status','4ea1a96f32cf7a0df575f9595bb3bbdc74e07154',target],cwd=repo,text=True)
assert delta==''
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,'pr86ActualMerged':True,'pr86DeliveryTreeIdentical':True,'externalIncrement':[],
 'trackedPaths':len(rows),'byAssetType':dict(collections.Counter(x['assetType'] for x in rows)),
 'qualification':'Mechanical fixed tree inventory only;preserve historical ledgers;method-level current review separately listed;no overall percentage or new whole-file completion inferred'}
(raw/'inventory-summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False))
