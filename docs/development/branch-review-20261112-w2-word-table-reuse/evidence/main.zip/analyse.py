from pathlib import Path
import datetime,hashlib,json,statistics,subprocess
root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;final=raw/'final'
candidate='de9aa396115ac326dd016235ec664a9c0c95fe15';base='8a415040babc1cc91ca9f5683bf0db46829eea76'
sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((final/'run.json').read_text());assert run['head']==candidate and run['result']=='passed' and not run['workingTreeState']
for item in run['sourceFingerprints']:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256']==sha((final/'source'/item['path']).read_bytes()) and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
before=json.loads((final/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((final/'knowledge-inputs.json').read_text());assert before==after
for item in after:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
node=json.loads((final/'node-summary.json').read_text());assert node['pass']==91 and node['fail']==node['skipped']==0
parser=json.loads((final/'word-parser/result.json').read_text());assert len(parser['results'])==8 and all(x['outcome']=='passed'for x in parser['results'])
wordPath='gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importWord.ts'
referenceSource=subprocess.check_output(['git','show',base+':'+wordPath],cwd=root)
assert sha(referenceSource)==parser['sourceSha256']['reference'] and sha((root/wordPath).read_bytes())==parser['sourceSha256']['candidate']
(raw/'reference-source').mkdir(exist_ok=True);(raw/'reference-source/importWord.ts').write_bytes(referenceSource)
comparisons=[x for r in parser['results']for x in r['comparisons']];assert all(x['candidatePageSha256']==x['referencePageSha256']for x in comparisons)
capacity=parser['results'][-1]['comparisons'];assert len(capacity)==3 and all(x['candidate']['calls']==1 and x['reference']['calls']==52 for x in capacity)
perf={'rows':300,'imageOccurrences':50,'referenceParseCalls':52,'currentParseCalls':1,'referenceMs':[x['reference']['durationMs']for x in capacity],'currentMs':[x['candidate']['durationMs']for x in capacity],'referenceMedianMs':statistics.median(x['reference']['durationMs']for x in capacity),'currentMedianMs':statistics.median(x['candidate']['durationMs']for x in capacity),'fullPageJsonEqual':True,'measurement':'Browser conversion including test JSON preparation;not whole UI latency,peak memory or productionSLA;time not assertion threshold'}
browsers=[]
for width in [1440,390]:
    for group,count in [('word',3),('document',8),('save',13),('import',15)]:
        d=json.loads((final/(group+'-'+str(width))/'result.json').read_text());assert len(d['results'])==count and all(x.get('outcome',x.get('status'))=='passed'for x in d['results']);browsers.append({'group':group,'width':width,'passed':count,'failed':0})
java=json.loads((final/'java-summary.json').read_text());assert [x['tests']for x in java]==[41,89] and all(x['failures']==x['errors']==x['skipped']==0 for x in java)
negative=json.loads((raw/'negative/command.json').read_text());assert negative['passed']==1 and negative['failed']==7 and negative['allPageComparisonsEqual']
for p,digest in negative['scripts'].items():assert sha((root/'gmp-platform/frontend'/p).read_bytes())==digest
premium=json.loads((raw/'premium-summary.json').read_text());assert all(x['fullFindingMultisetsEqualIgnoringLineOnly']for x in premium)
result={'analysedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'testedCandidate':candidate,'target':base,'result':'passed','protectedSourceInputs':len(run['sourceFingerprints']),'protectedSourceCurrentGitAndSnapshotEqual':True,'knowledgeInputs':len(after),'knowledgeBeforeAfterCurrentGitEqual':True,'node':node,'pureParserCases':8,'completePageComparisons':len(comparisons),'browserExecutions':browsers,'componentBrowserExecutions':78,'functionalExecutions':218,'knowledgeChecksSeparate':89,'java':java,'performance':perf,
 'negativeSameFinalScripts':negative,
 'resolution':{'id':'PERF-W2-WORD-TABLE-REPARSE-001','parentId':'PERF-DESIGNER-OFFICE-EXPANSION-001','status':'resolved','scope':'Per-import reuse of already parsed direct-body tables;parent fullZIP/workbook/media capacity risk remains open','userAuthorization':'下一批先复用表格解析结果（推荐）'},
 'premium':premium,'lint':{'baselineExit':2,'candidateExit':2,'reason':'Existing missing configuration;not passed'},
 'processEvidence':{'initialOld':'One error-path evidence hash attempted undefined;fixture/test error,not product failure;final immutable-base run1positive/7true parse-budget failures','initialHost':'Raw JS undefined props compared to JSON serialization/normalization led representation-only mismatch;final compares entire protocol JSON,with all values/styles/borders/media retained;no product normalizer/serialization change','network':'Two transient HTTP503 fetch failures and one bad upstream API body retained as observations;target-refresh.json actual later successful fetch to same base','environment':'Starting->ready wait completed;HEAD and retained test/role evidence reverified against source hashes,no claim of rerun'},
 'inflightPr87':json.loads((raw/'baseline-observation.json').read_text())['inflightPr87'],
 'visualInspected':['final/word-1440/history-and-save.png','final/word-390/history-and-save.png'],
 'limits':['PR87 independent OPEN branch;no inherited Excel fix or scope certification','Complete JSON equality preserves existing Word approximations,not full Office layout/legacyDOC support','Actual component/controlledGETAPI/save callbacks and mock/direct controller not realHTTP/PG E2E','Original grid300/75 is not global Word content/input memory policy;no new file/row/image limits','Strict86/28 and missinglint configuration remain','WholeW2/W3-W7/knowledge semantics/A23/allUI/productioncapacity and original deferred issues remain']}
(raw/'main-analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k]for k in ['testedCandidate','result','protectedSourceInputs','knowledgeInputs','functionalExecutions','knowledgeChecksSeparate','performance']}))
