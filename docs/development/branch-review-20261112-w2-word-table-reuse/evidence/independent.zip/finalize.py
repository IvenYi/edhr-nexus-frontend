from pathlib import Path
import datetime,hashlib,json,subprocess,yaml
raw=Path(__file__).parent;root=Path('/tmp/edhr-word-table-reuse-qa-20261112');candidate='de9aa396115ac326dd016235ec664a9c0c95fe15';base='8a415040babc1cc91ca9f5683bf0db46829eea76'
sha=lambda b:hashlib.sha256(b).hexdigest()
e=json.loads((raw/'inputs-verified.json').read_text());assert e['totalExecutions']==307 and e['sourceCurrentGitSnapshotEqual'] and e['knowledgeBeforeAfterCurrentGitEqual']
assert json.loads((raw/'final/run.json').read_text())['result']=='passed'
o=yaml.safe_load((raw/'ontology-final/ontology-result.yaml').read_text())['ontologyResult'];assert o['result']=='not-applicable' and o['contractBaseline']['sourceCommit']==candidate
link=root/'gmp-platform/frontend/node_modules'
if link.is_symlink():
 assert str(link.resolve())=='/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules';link.unlink()
else:assert not link.exists()
status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=root,text=True);assert status==''
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==candidate
(raw/'final-working-tree.json').write_text(json.dumps({'recordedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':candidate,'status':status,'dependencyLinkRemoved':True,'excludedDuringExecution':['gmp-platform/frontend/node_modules'],'productTestDpEditsByQa':[]},indent=2)+'\n')
checks=[]
def check(id,category,description,method,evidence,command=''):
 checks.append({'id':'quality.'+id,'required':True,'category':category,'description':description,'method':method,'command':command,'outcome':'passed','evidence':evidence})
check('baseline-and-scope','requirements','独立核对固定base/candidate及五文件切片，知识/契约无差异；PR87未合入独立处理','inspection',['baseline.json','final-working-tree.json'])
check('policy-and-ontology','ontology','DEC0077-12/22/30及本体NA FINAL与实现边界一致，非业务政策或成熟度升级','inspection',['ontology-final/ontology-result.yaml','ontology-final-inspection.json','review.md'])
check('source-lifetime-a23','security','Map仅本次DOCX创建、DOM Element身份、只读消费者，不全局缓存或新增兜底/验证绕过','inspection',['review.md','anti-pattern-scan.json'])
check('parser-full-output','regression','真实JSZip/DOM/旧新Word模块逐项完整CanvasPage JSON等价，非结果mock','automated-test',['final/word-parser/result.json','inputs-verified.json'],'node scripts/test-designer-word-table-reuse.mjs')
check('parser-budget-capacity','regression','实际300行50图片三次对照52次解析到1次，600单元格/50图片和页面摘要保持；耗时仅记录不作阈值','automated-test',['final/word-parser/result.json','inputs-verified.json'],'same recorded parser execution')
check('parser-isolation-recovery','regression','实际同名新内容、并发独立导入、空白/缺失关系/坏XML及重试保持','automated-test',['final/word-parser/result.json'],'same recorded 8-case parser execution')
check('host-history-save','e2e','真实Shell/store/Canvas两屏6项，导入不自动保存、单次撤销历史、同名新文件、错误恢复及保存重开完整JSON','browser',['final/word-1440/result.json','final/word-390/result.json'],'node scripts/test-designer-word-table-reuse-browser.mjs at 1440 and 390')
check('adjacent-node','regression','本人实际原解析/保存状态/子列/选项/表单及执行预览91项全过','automated-test',['final/node.log','final/node-summary.json'],'node --test --test-reporter=tap <six recorded scripts>')
check('adjacent-browser','regression','本人实际原加载16、保存26、导入30，两宽合计72项全过','browser',['final/document-1440/result.json','final/document-390/result.json','final/save-1440/result.json','final/save-390/result.json','final/import-1440/result.json','final/import-390/result.json'],'recorded three browser scripts at both widths')
check('build-and-guards','integration','实际npm构建含tsc及三个原静态约束通过，原检查未改','command',['final/build.log','final/verify-template-designer-react.log','final/verify-list-table-style-contract.log','final/verify-no-external-fonts.log'],'npm run build;node scripts/verify-template-designer-react.mjs;node scripts/verify-list-table-style-contract.mjs;node scripts/verify-no-external-fonts.mjs')
check('controller','api','原控制器mock/direct41项实际独立运行，无失败/错误/skip；非真实HTTP/PG','automated-test',['final/java.log','final/java-summary.json','final/TEST-com.zencas.edhr.template.controller.TemplateModelingControllerTest.xml'],'bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress -f gmp-platform/backend/pom.xml -Dtest=TemplateModelingControllerTest,BusinessKnowledgeModelTest test')
check('knowledge','ontology','知识89实际独立运行，新鲜XML；359输入前后/Git一致，不等于全库语义已审','automated-test',['final/java-summary.json','final/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','inputs-verified.json'],'same independently recorded Maven execution')
check('visual','visual','本人实际查看1440/390导入截图，表格/合并/图片渲染、窄屏原侧栏关闭/滚动可达；不声称全部Word版式正确','inspection',['visual-review.json','final/word-1440/history-and-save.png','final/word-390/history-and-save.png'])
check('old-product-counterexample','regression','复核主侧同最终脚本/旧产品原件1P7真实解析预算F，完整页面仍相同；明确非本人重跑旧产品','inspection',['main-negative-inspection/command.json','main-negative-inspection/parser/result.json','inputs-verified.json'])
check('premium-increment','regression','本人官方精确脚本base/current两范围完整finding多重集相同，仅忽略行号；新增0','command',['premium-commands.json','premium-comparison.json'],'python3 audit_project.py <base/candidate repo/frontend> --mode strict --output <recorded file>')
check('inputs-and-integrity','documentation','49源码输入与359知识输入同当前/Git/原件，环境恢复后再次核对；清依赖软链且worktreeclean','inspection',['inputs-verified.json','final-working-tree.json','final/run.json'])
check('live-target-observation','requirements','本人GitHub API实际观察目标8a415040及PR87 OPEN；主审集成前仍需实际fetch增量复核','command',['network-observation.json'],'gh api repos/IvenYi/edhr-nexus-frontend/git/ref/heads/edhr-dev --jq .object.sha;gh pr view 87 --json number,state,headRefOid,mergeCommit,mergedAt')
assert len(checks)==17
checks.extend([{'id':'quality.premium-whole-project','required':False,'category':'visual','description':'既有strict仓库86/前端28债务未关闭，包含关系不相加','method':'command','command':'recorded official strict audits','outcome':'blocked','evidence':['premium-comparison.json']},{'id':'quality.eslint','required':False,'category':'regression','description':'基线/当前均因已有缺配置exit2，未计通过','method':'command','command':'recorded installed ESLint command','outcome':'blocked','evidence':['lint-commands.json','baseline-lint.log','candidate-lint.log']}])
risks=[
 ('controlled-not-http-pg','纯解析与受控API真实组件/保存回调、mock/direct控制器不等于真实HTTP/PG完整E2E。','未认证真实服务器鉴权、数据库事务或生产端到端。','按真实链后续验证；本批没有后台或DB改动。'),
 ('old-layout-fidelity','完整JSON等价保留现有Word图文近似，包括部分图片与文字重叠；嵌套样本仅保留既有表现。','不能据此宣称所有Word版式、打印PDF/历史格式正确。','保持本次优化边界，格式/布局专项另审，不在复用中改变布局政策。'),
 ('parent-capacity','本批仅关闭重复表解析；ZIP全解压、DOM/媒体编码、其他Office输入膨胀未关闭。','不保证生产SLA、峰值内存或任意大文档容量。','保留父风险并分别量化讨论；300/50为样本而非上限。'),
 ('existing-static-lint-debt','官方strict仓库86/前端28旧债及ESLint缺配置保留。','未宣称全仓静态合规或lint通过。','完整finding多重集新增0；按原审计队列处理。'),
 ('not-overall-completion','全W2/W3-W7、A23已审补查、全知识语义及原high/A12/多租户/用户暂停仍未完成。','307项局部执行不能换算整体覆盖比例或生产发布。','台账分列机械盘点、有限方法与语义审查、运行验收和后续范围。'),
 ('parallel-pr87','PR87仍OPEN，不在本基线内；本批没有继承其Excel修复和覆盖。','后续目标/并行合入变化需要实际集成候选增量复核。','主审PR前及收到合入消息后fresh fetch、检查相关变化再适用复验。'),
 ('limited-ui-matrix','只对实际变更导入链两屏截图/键盘/错误恢复做验证，复杂窄屏画布与重开侧栏原布局保留。','未认证全站响应式、无障碍、账号/离线/权限/本地化完整矩阵。','维持既有完整UI队列，不为计算优化重设计。')]
q={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':candidate,'contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':candidate,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[{'id':'risk.'+i,'description':d,'impact':a,'mitigation':m}for i,d,a,m in risks],'blockingConditions':[]}}
(raw/'quality-result.yaml').write_text(yaml.safe_dump(q,allow_unicode=True,sort_keys=False,width=120))
metrics=e['performanceObserved']
review=f'''# Word表格复用独立质量复验

结果passed/FINAL，base `{base}`，受测 `{candidate}`。全新实例未参与修复，只读代码/测试/DP；临时node_modules软链已清理，最终独立worktree clean。实际契约读取和知识基线在quality-result.yaml，知识0.3.25/schema1.2.0/P0不升级。

本人实际通过91 Node、8纯Chromium解析、78真实组件浏览器（新6/原72）、41控制器=218功能执行，另89知识检查，共307，0失败/错误/跳过。构建含tsc及原三guard通过；新鲜JUnit及49源码/359知识输入前后/当前/Git核对完成。环境恢复后保留的同一测试原件与输入再次核验，未冒称重新执行整套测试。

源码仅importWord14+/10−：Map在当前DOCX调用内按实际DOM Element存ParsedTable，块/图片高度消费者只读；无全局或文件名缓存、无额外重试/格式兜底。原图位/表格解析/段落近似、媒体/错误、.doc/Excel、权限/保存/历史未改。全部新旧CanvasPage JSON逐项相同，固定解析预算一表一次；同名新内容及并发独立，空白/缺失关系/坏XML重试保持。宿主两宽单次history、不自动保存、undo/redo、其他模型/流程/页面身份及保存重开完整协议JSON实测。

本人300行/50处图三次记录：旧解析52次→新1次；旧耗时 {[round(x['referenceMs'],1)for x in metrics]} ms，新 {[round(x['candidateMs'],1)for x in metrics]} ms，完整页摘要一致。耗时是本机浏览器转换/测试JSON准备的观测，不作阈值，不等同页面首屏、峰值内存或生产SLA。只消除重复表解析，父Office膨胀风险继续。

主侧negative原件已独立复核：同最终测试字节与旧产品8a，1正对照/7解析次数预算失败，完整页面JSON均仍相同；这些是效率反例，不是七项正确性缺陷，也不是本人重跑旧产品。源码/脚本摘要及原完整JSON已复制到main-negative-inspection。初期hash(undefined)与保存JS对象/JSON表示的测试作者错误不计作产品红，最终比较完整协议值；未改产品normalizer或降低有效值断言。

本人官方精确脚本SHA67fd3559…ce68实际四组扫描，仓库base/current各86，前端各28；完整finding多重集保持重复项且只忽略行号，新增0，strict仍exit2。ESLint两侧原缺配置exit2未计通过。DESIGN/共享原语/tokens未改。本人看了1440/390导入截图，表格/合并/图片渲染；390通过原关闭侧栏与横向滚动可达。现有图文近似/图片覆盖文字没有因复用改变，不宣称全部Word版式正确。

本体NA FINAL原manifest56项及SHA256SUMS已逐项核验，有限8=5一致/1原gap/2原待决，353/2849机械分母不转为语义通过。本人GitHub API成功观察目标8a、PR87仍OPEN；其Excel修复未纳入本基线，主审集成前仍须实际fetch并核对未来增量。

17必需检查通过，无findings/blocking。受控组件和mock/direct控制器非真实HTTP/PG全链；所有格式/打印/生产容量、完整UI/账号/权限矩阵、全W2/W3-W7/A23/全知识语义及原high/A12/用户暂停仍保留。建议主审完成实际PR前漂移门禁后交付人工合并，不自动merge/deploy/恢复或查询触发CI。
'''
(raw/'review.md').write_text(review)
files=[]
for p in sorted(raw.rglob('*')):
 if p.is_file() and p not in [raw/'manifest.json',raw/'SHA256SUMS']:
  b=p.read_bytes();files.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
manifest={'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'independent-quality','testedCandidate':candidate,'baseCommit':base,'result':'passed','files':files}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
allFiles=files+[{'path':'manifest.json','sha256':sha((raw/'manifest.json').read_bytes())}]
(raw/'SHA256SUMS').write_text(''.join(x['sha256']+'  '+x['path']+'\n'for x in allFiles))
for x in files:assert sha((raw/x['path']).read_bytes())==x['sha256']
print(json.dumps({'result':'passed','candidate':candidate,'requiredChecks':17,'manifestMembers':len(files),'manifestSha256':sha((raw/'manifest.json').read_bytes()),'sha256SumsSha256':sha((raw/'SHA256SUMS').read_bytes()),'functional':218,'knowledge':89,'clean':True}))
