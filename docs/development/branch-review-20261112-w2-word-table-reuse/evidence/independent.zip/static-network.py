from pathlib import Path
import collections,datetime,hashlib,json,shutil,subprocess
raw=Path(__file__).parent;root=Path('/tmp/edhr-word-table-reuse-qa-20261112');base=Path('/tmp/edhr-import-normalization-baseline-20261112')
expected='67fd35597c85a2f37dd3c566f0bd79768cbe059114edcf28074fc5afa3e0ce68'
script=raw/'audit_project.py';shutil.copyfile('/tmp/edhr-w2-word-table-reuse-20261112/skill/audit_project.py',script);assert hashlib.sha256(script.read_bytes()).hexdigest()==expected
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=base,text=True).strip()=='8a415040babc1cc91ca9f5683bf0db46829eea76'
assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=base,text=True).strip()
commands=[]
for label,path in [('baseline-repo',base),('candidate-repo',root),('baseline-frontend',base/'gmp-platform/frontend'),('candidate-frontend',root/'gmp-platform/frontend')]:
    args=['python3',str(script),str(path),'--mode','strict','--output',str(raw/(label+'-premium.json'))];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (raw/(label+'-premium.log')).open('w')as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
    commands.append({'label':label,'command':args,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode,'scriptSha256':expected});assert r.returncode==2
comparisons=[]
for scope in ['repo','frontend']:
    b=json.loads((raw/('baseline-'+scope+'-premium.json')).read_text());c=json.loads((raw/('candidate-'+scope+'-premium.json')).read_text())
    key=lambda d:collections.Counter(json.dumps({k:v for k,v in row.items()if k!='line'},sort_keys=True)for row in d['findings'])
    assert key(b)==key(c)
    comparisons.append({'scope':scope,'baseline':b['summary'],'candidate':c['summary'],'fullFindingMultisetsEqualIgnoringOnlyLine':True,'added':[],'removed':[]})
(raw/'premium-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(raw/'premium-comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
lint=[]
for label,path in [('baseline',base/'gmp-platform/frontend'),('candidate',root/'gmp-platform/frontend')]:
    args=['node','/workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules/eslint/bin/eslint.js','.','--ext','ts,tsx','--report-unused-disable-directives','--max-warnings','0'];start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (raw/(label+'-lint.log')).open('w')as f:r=subprocess.run(args,cwd=path,stdout=f,stderr=subprocess.STDOUT)
    lint.append({'label':label,'command':args,'cwd':str(path),'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':r.returncode});assert r.returncode==2
(raw/'lint-commands.json').write_text(json.dumps(lint,indent=2)+'\n')
network=[]
for label,args in [('target-api',['gh','api','repos/IvenYi/edhr-nexus-frontend/git/ref/heads/edhr-dev','--jq','.object.sha']),('pr87',['gh','pr','view','87','--json','number,state,headRefOid,mergeCommit,mergedAt'])]:
    entry={'label':label,'command':args,'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:r=subprocess.run(args,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=35);entry.update(exitCode=r.returncode,output=r.stdout)
    except subprocess.TimeoutExpired as e:entry.update(timeoutSeconds=35,output=(e.stdout or b'').decode()if isinstance(e.stdout,bytes)else(e.stdout or ''))
    entry['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();network.append(entry)
(raw/'network-observation.json').write_text(json.dumps(network,indent=2)+'\n');print(json.dumps({'premium':comparisons,'lint':lint,'network':network}))
