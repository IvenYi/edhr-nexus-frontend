from pathlib import Path
import datetime,hashlib,json,subprocess,xml.etree.ElementTree as ET
root=Path('/tmp/edhr-word-table-reuse-qa-20261112');raw=Path(__file__).parent;candidate='de9aa396115ac326dd016235ec664a9c0c95fe15';base='8a415040babc1cc91ca9f5683bf0db46829eea76';sha=lambda b:hashlib.sha256(b).hexdigest()
run=json.loads((raw/'final/run.json').read_text());assert run['result']=='passed' and run['head']==candidate
for x in run['sourceFingerprints']:
 b=(root/x['path']).read_bytes();assert sha(b)==x['sha256']==sha((raw/'final/source'/x['path']).read_bytes());assert b==subprocess.check_output(['git','show',candidate+':'+x['path']],cwd=root)
before=json.loads((raw/'final/knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((raw/'final/knowledge-inputs.json').read_text());assert before==after
for x in after:
 b=(root/x['path']).read_bytes();assert sha(b)==x['sha256'];assert b==subprocess.check_output(['git','show',candidate+':'+x['path']],cwd=root)
assert len(run['sourceFingerprints'])==49 and len(after)==359
node=json.loads((raw/'final/node-summary.json').read_text());assert node==dict(tests=91,**{'pass':91,'fail':0,'skipped':0,'cancelled':0})
java=json.loads((raw/'final/java-summary.json').read_text());assert [x['tests']for x in java]==[41,89] and all(x['failures']==x['errors']==x['skipped']==0 for x in java)
browser=[]
for label,count in [('word-parser',8)]+[(g+'-'+str(w),n)for w in[1440,390]for g,n in[('word',3),('document',8),('save',13),('import',15)]]:
 d=json.loads((raw/'final'/label/'result.json').read_text());assert len(d['results'])==count and all(x.get('outcome',x.get('status'))=='passed'for x in d['results']);browser.append({'label':label,'passed':count})
assert sum(x['passed']for x in browser)==86
parser=json.loads((raw/'final/word-parser/result.json').read_text());metrics=[]
for case in parser['results']:
 for comparison in case['comparisons']:
  assert comparison['candidatePageSha256']==comparison['referencePageSha256']
  assert comparison['candidate'].get('page')==comparison['reference'].get('page')
  assert comparison['candidate'].get('error')==comparison['reference'].get('error')
 for key in ['candidate','reference']:assert parser['sourceSha256'][key]==sha(subprocess.check_output(['git','show',(candidate if key=='candidate'else base)+':gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importWord.ts'],cwd=root))
 if case['case']=='capacity-300-50':
  for c in case['comparisons']:
   assert c['candidate']['calls']==1 and c['reference']['calls']==52
   metrics.append({'candidateCalls':c['candidate']['calls'],'referenceCalls':c['reference']['calls'],'candidateMs':c['candidate']['durationMs'],'referenceMs':c['reference']['durationMs'],'pageSha256':c['candidatePageSha256']})
negative=json.loads((raw/'main-negative-inspection/command.json').read_text());assert negative['testHead']==candidate and negative['selectedProductCommit']==base and negative['passed']==1 and negative['failed']==7
for name,digest in negative['scripts'].items():assert sha((root/'gmp-platform/frontend'/name).read_bytes())==digest
nr=json.loads((raw/'main-negative-inspection/parser/result.json').read_text());assert sum(x['outcome']=='passed'for x in nr['results'])==1
for r in nr['results']:
 if r['outcome']=='failed':assert r['failure'].startswith('AssertionError') and 'Expected values to be strictly equal' in r['failure']
 for c in r['comparisons']:assert c['candidate'].get('page')==c['reference'].get('page') and c['candidate'].get('error')==c['reference'].get('error')
for c in java:
 p=next((raw/'final').glob('TEST-*.'+c['class']+'.xml'));e=ET.parse(p).getroot();assert len(e.findall('testcase'))==c['tests'] and p.stat().st_mtime>0
data={'verifiedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'base':base,'protectedSourceCount':49,'knowledgeInputs':359,'sourceCurrentGitSnapshotEqual':True,'knowledgeBeforeAfterCurrentGitEqual':True,'node':node,'browser':browser,'java':java,'functionalExecutions':218,'knowledgeExecutionsSeparate':89,'totalExecutions':307,'parserFullOutputComparisonsEqual':True,'performanceObserved':metrics,'negativeEvidenceSource':'Inspection of main raw artifacts,not independently rerun','negativeSameFinalScriptsConfirmed':True}
(raw/'inputs-verified.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:data[k]for k in['functionalExecutions','knowledgeExecutionsSeparate','protectedSourceCount','knowledgeInputs','performanceObserved']}))
