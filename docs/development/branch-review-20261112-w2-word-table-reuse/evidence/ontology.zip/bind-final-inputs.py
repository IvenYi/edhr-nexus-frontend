from pathlib import Path
from zoneinfo import ZoneInfo
import datetime,hashlib,json,re,shutil,subprocess,sys,xml.etree.ElementTree as ET

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent;candidate=sys.argv[1];runpath=Path(sys.argv[2]);phase=runpath.parent
base=sys.argv[3] if len(sys.argv)>3 else '8a415040babc1cc91ca9f5683bf0db46829eea76'
assert re.fullmatch('[a-f0-9]{40}',candidate) and re.fullmatch('[a-f0-9]{40}',base)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
run=json.loads(runpath.read_text());assert run['head']==candidate and run['result']=='passed' and not run['workingTreeState']
assert git('rev-parse','HEAD')==candidate
assert not git('diff','--name-only',base,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture/business-knowledge-model.md','docs/knowledge')
assert git('ls-remote','origin','refs/heads/edhr-dev').split()[0]==base
source=[]
for item in run['sourceFingerprints']:
    p=item['path'];b=(root/p).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',candidate+':'+p],cwd=root)
    if (phase/'source'/p).exists():assert (phase/'source'/p).read_bytes()==b
    source.append({'path':p,'sha256':item['sha256'],'candidateAndCurrentEqual':True})
before=json.loads((phase/'knowledge-inputs-before.json').read_text())['inputs'];after=json.loads((phase/'knowledge-inputs.json').read_text());assert before==after
for item in after:
    p=item['path'];b=(root/p).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',candidate+':'+p],cwd=root)
inventory=[json.loads(line) for line in (raw/'knowledge-file-inventory.jsonl').read_text().splitlines()]
for item in inventory:
    b=(root/item['path']).read_bytes();assert sha(b)==item['sha256'] and b==subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=root)
java=[x for x in run['steps'] if x['name']=='java'];assert len(java)==1 and java[0]['exitCode']==0
xmls=list(phase.glob('TEST-*.BusinessKnowledgeModelTest.xml'));assert len(xmls)==1
xml=xmls[0];suite=ET.parse(xml).getroot();attrs=suite.attrib
assert int(attrs['tests'])==89 and int(attrs['failures'])==int(attrs['errors'])==int(attrs['skipped'])==0 and len(suite.findall('testcase'))==89
source_xml=root/'gmp-platform/backend/target/surefire-reports'/xml.name;assert source_xml.read_bytes()==xml.read_bytes()
started=datetime.datetime.fromisoformat(java[0]['startedAt']);finished=datetime.datetime.fromisoformat(java[0]['finishedAt']);assert started.timestamp()<=source_xml.stat().st_mtime<=finished.timestamp()+1
copied=[];readroot=raw/'read-evidence/final-main';readroot.mkdir(parents=True,exist_ok=True)
for p in [runpath,*[phase/n for n in ['node.log','node-summary.json','java.log','java-summary.json','knowledge-inputs-before.json','knowledge-inputs.json'] if (phase/n).exists()],*phase.glob('TEST-*.xml'),*phase.rglob('result.json')]:
    rel=p.relative_to(phase);dest=readroot/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,dest);copied.append({'path':str(dest.relative_to(raw)),'sha256':sha(dest.read_bytes())})
front='gmp-platform/frontend/src/pages/master-data/template-designer-react/'
for p in [front+'utils/importWord.ts','docs/development/branch-review-20261112-w2-word-table-reuse/decision-package.yaml']:
    b=(root/p).read_bytes();dest=raw/'read-evidence/candidate-source'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
(raw/'read-evidence/import-word-candidate.diff').write_text(subprocess.check_output(['git','diff',base,candidate,'--',front+'utils/importWord.ts'],cwd=root,text=True))
result={'boundAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'candidate':candidate,'target':base,'contractReadCommit':'8a415040babc1cc91ca9f5683bf0db46829eea76','uncommittedContractPaths':[],'mainRunResult':run['result'],'sourceInputs':source,'sourceInputsCurrentAndGitEqual':True,'knowledgeBeforeAfterCurrentAndGitEqual':True,'knowledgeInputs':len(after),'knowledgeFiles':len(inventory),'knowledgeTestcases':89,'mainJavaCommand':java[0],'sourceKnowledgeXmlMtime':datetime.datetime.fromtimestamp(source_xml.stat().st_mtime,datetime.timezone.utc).isoformat(),'knowledgeXmlSourceAndCopySha256':sha(xml.read_bytes()),'copiedMainRuntimeEvidence':copied,'knowledgeOrContractChanged':False,'roleActuallyExecutedRuntimeTests':False,'scope':'本体只读主侧正式原件并绑定来源；不代替独立QA，不声称亲跑Node/浏览器/Java/数据库/CI或手动视觉检查。'}
(raw/'final-source-knowledge-binding.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['candidate','mainRunResult','knowledgeInputs','knowledgeFiles','knowledgeTestcases','roleActuallyExecutedRuntimeTests']},ensure_ascii=False))
