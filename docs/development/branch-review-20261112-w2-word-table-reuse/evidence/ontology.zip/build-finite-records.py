from pathlib import Path
from zoneinfo import ZoneInfo
import collections,datetime,hashlib,json,subprocess,yaml

root=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
base='8a415040babc1cc91ca9f5683bf0db46829eea76'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
raw.mkdir(parents=True,exist_ok=True)
schema=yaml.safe_load((root/'docs/knowledge/schema.yaml').read_text());records=[];files=[];by_id={}
for p in sorted((root/'docs/knowledge').rglob('*')):
    if not p.is_file():continue
    name=str(p.relative_to(root));b=p.read_bytes();assert b==subprocess.check_output(['git','show',base+':'+name],cwd=root)
    files.append({'path':name,'bytes':len(b),'sha256':sha(b),'scope':'inventory-only','semanticReview':'pending','conclusion':'pending'})
    if p.suffix not in ('.yaml','.yml'):continue
    data=yaml.safe_load(b)
    if not isinstance(data,dict):continue
    def add(record,kind,locator):
        item={'id':record['id'],'recordType':kind,'sourcePath':name,'sourceLocator':locator,'originalStatus':record.get('status'),'originalVisibility':record.get('visibility'),'scope':'inventory-only','semanticReview':'pending','conclusion':'pending'}
        records.append(item);assert record['id'] not in by_id;by_id[record['id']]=(item,record)
    for collection,kind in schema['collectionTypes'].items():
        for i,record in enumerate(data.get(collection,[]) or []):
            if not isinstance(record,dict) or not isinstance(record.get('id'),str):continue
            add(record,kind,f'/{collection}/{i}')
            for nested,nkind in schema['nestedCollectionTypes'].items():
                for j,item in enumerate(record.get(nested,[]) or []):
                    if isinstance(item,dict) and isinstance(item.get('id'),str):add(item,nkind,f'/{collection}/{i}/{nested}/{j}')
assert len(files)==353 and len(records)==len(by_id)==2849
for name,data in [('knowledge-file-inventory.jsonl',files),('knowledge-id-inventory.jsonl',records)]:
    (raw/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in data))
pr=json.loads(subprocess.check_output(['gh','pr','view','87','--json','number,state,headRefOid,mergeCommit,url'],cwd=root,text=True))
baseline={'observedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'sourceCommitAtRead':git('rev-parse','HEAD'),'targetCommit':base,'actualRemoteTarget':git('ls-remote','origin','refs/heads/edhr-dev').split()[0],'contractReadCommit':base,'uncommittedContractPaths':[],
 'contractAndKnowledgeDeltaFromTarget':git('diff','--name-status',base,'HEAD','--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge'),'knowledgeModelVersion':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion'],'knowledgeFiles':len(files),'schemaSelectedAssetIds':len(records),'uniqueIds':len(by_id),'byRecordType':dict(collections.Counter(x['recordType'] for x in records)),'pr87AtRead':pr,
 'wordDeltaFromPR87':git('diff','--name-status',base,pr['headRefOid'],'--','gmp-platform/frontend/src/pages/master-data/template-designer-react/utils/importWord.ts'),'qualification':'Mechanical schema top/nested inventory only,all pending;finite semantic selections separately listed;not whole-catalog or historical unique completion.'}
assert baseline['actualRemoteTarget']==base and not baseline['contractAndKnowledgeDeltaFromTarget'] and not baseline['wordDeltaFromPR87']
(raw/'baseline-inputs.json').write_text(json.dumps(baseline,ensure_ascii=False,indent=2)+'\n')
front='gmp-platform/frontend/src/pages/master-data/template-designer-react/'
sources=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0077-form-traceability-projection-ownership.yaml','docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md','docs/development/branch-review-20261028-designer-import/findings.md',front+'utils/importWord.ts',front+'utils/importGrid.ts',front+'utils/templateImport.ts',front+'utils/document.ts',front+'types/canvas.ts',front+'store/useTemplateDesignerStore.ts',front+'TemplateDesignerReactShell.tsx','gmp-platform/frontend/package-lock.json']
source_rows=[]
for name in sources:
    b=subprocess.check_output(['git','show',base+':'+name],cwd=root);dest=raw/'read-evidence/target-source'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);source_rows.append({'path':name,'bytes':len(b),'sha256':sha(b),'readCommit':base})
dp='docs/development/branch-review-20261112-w2-word-table-reuse/decision-package.yaml';b=(root/dp).read_bytes();p=raw/'read-evidence/decision-package-at-read.yaml';p.write_bytes(b)
source_rows.append({'path':dp,'bytes':len(b),'sha256':sha(b),'readCommit':'uncommitted decision package at initial baseline;final candidate bound separately'})
(raw/'source-inputs.json').write_text(json.dumps(source_rows,ensure_ascii=False,indent=2)+'\n')
authorization={'evidenceKind':'user-confirmed','source':'current user answer to the actual async question in this task','question':'Word 导入时，同一表格每多一处图片就会重新解析整张表。300 行、50 处图片的合成实验中，表格被解析 52 次，导入阶段三次实测约 1.14–1.26 秒；这些是样本数，不是数量上限，也不代表生产 SLA。是否下一批先在一次导入内复用已解析的表格，保持原图片位置、文字、边框和撤销行为？本轮 Excel 图片尺寸修复继续独立验收。','answer':'下一批先复用表格解析结果（推荐）','scope':'Engineering performance authorization only;no new business policy,limits,format migration or cross-request cache.'}
(raw/'user-authorization.json').write_text(json.dumps(authorization,ensure_ascii=False,indent=2)+'\n')
checks=[
 ('DEC-0077-12','consistent','retained','仅优化新导入临时解析，不回写模板或实例/执行/DHR既有快照；原使用时冻结与模板可编辑规则保持，不创造发布冻结或图片快照新状态。',[front+'utils/importWord.ts','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md']),
 ('DEC-0077-22','consistent','retained','表格复用留在原Word适配器；完整CanvasPage仍经原Shell/store一次导入及同一保存/撤销机制应用，不建立另一历史或自动保存。',[front+'store/useTemplateDesignerStore.ts#replaceCurrentPageFromImport',front+'TemplateDesignerReactShell.tsx#handleImportFileChange',front+'utils/document.ts#serializeTemplateDesignerDocument']),
 ('DEC-0077-30','consistent','retained','不增加字段/投影业务完整性门禁，不改变空白、损坏来源或原请求/证据安全边界；本次性能授权不能扩为草稿资格或无上下文所属政策。',[front+'utils/importWord.ts','docs/knowledge/evidence/form-traceability-projection-ownership-user-confirmed.md#2026-10-10-第三轮注释草稿缺上下文可空批号单位与保存后追溯']),
 ('discrepancy.dhr-review-complete-evidence-impact-gap','evidence-gap','deferred','原通用质量/异常/源签署有效性变化自动判读high继续open；Word表格复用没有覆盖或关闭依据，与当前有限优化无依赖。',['docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml']),
 ('question.form-projection-trace-index-effective-scope','needs-decision','deferred','原A12失效/修订历史视图未决保持；不迁移设计或改历史只读，不重新询问已确认过程检索，不用复用结果关闭A12。',['docs/knowledge/open-questions.yaml']),
 ('question.multi-tenant-workflow-isolation','needs-decision','deferred','完整非MVP租户隔离未决保持；本次调用局部DOM Map不等于后台认证或多租户隔离验收。',['docs/knowledge/open-questions.yaml'])]
finite=[]
for ident,conclusion,disposition,meaning,refs in checks:
    item,record=by_id[ident];finite.append({**item,'scope':'finite-current-slice','semanticReview':'reviewed','conclusion':conclusion,'disposition':disposition,'conclusionDetail':meaning,'originalRecord':record,'checkedDecisionIds':['DEC-0077-12','DEC-0077-22','DEC-0077-30'],'evidenceReferences':refs,'knowledgeChangeRequired':False})
for ident,path,loc,meaning in [
 ('selection.business-knowledge-model.current-boundaries','docs/architecture/business-knowledge-model.md','当前版本、使用时冻结与共享配置/历史边界','当前模型未将Word重复解析、工程clamp或本次性能授权定义为业务政策；仅消除冗余运算，不提升知识成熟度、P0或全审计覆盖。'),
 ('selection.office-import.previous-review','docs/development/branch-review-20261028-designer-import/findings.md','性能与大模块方案','历史审查只作索引；已回原importWord源码核对每图parseTable重复。用户仅授权该子范围，整ZIP并发解压/媒体编码/Excel工作簿载入等父风险及容量缺口继续，不将局部优化称为完整Office容量认证。')]:
    finite.append({'id':ident,'recordType':'selectedMarkdownExplanation','sourcePath':path,'sourceLocator':loc,'originalStatus':None,'originalVisibility':None,'scope':'finite-current-slice','semanticReview':'reviewed','conclusion':'consistent','disposition':'retained','conclusionDetail':meaning,'checkedDecisionIds':['DEC-0077-12','DEC-0077-22','DEC-0077-30'],'evidenceReferences':[path,front+'utils/importWord.ts','user-authorization.json'],'knowledgeChangeRequired':False})
(raw/'finite-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in finite))
summary={'targetCommit':base,'finiteRecords':len(finite),'selectedAssetIds':len(checks),'selectedMarkdownExplanations':2,'conclusions':dict(collections.Counter(x['conclusion'] for x in finite)),'knowledgeChangeRequired':False,'historicalUniqueCoverageAdded':False,'wholeKnowledgeSemanticAuditCompleted':False,'pendingInventorySeparate':True}
(raw/'finite-review-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'baseline':baseline,'finite':summary},ensure_ascii=False))
