from pathlib import Path
from zoneinfo import ZoneInfo
import collections,datetime,hashlib,json,yaml

raw=Path(__file__).parent
binding=json.loads((raw/'final-source-knowledge-binding.json').read_text());assert binding['mainRunResult']=='passed' and binding['knowledgeTestcases']==89 and not binding['knowledgeOrContractChanged']
finite=[json.loads(line) for line in (raw/'finite-review-records.jsonl').read_text().splitlines()]
summary=json.loads((raw/'finite-review-summary.json').read_text());assert summary['finiteRecords']==8 and collections.Counter(x['conclusion'] for x in finite)=={'consistent':5,'evidence-gap':1,'needs-decision':2}
base=binding['target'];candidate=binding['candidate'];main=raw/'read-evidence/final-main'
node=json.loads((main/'node-summary.json').read_text());assert node['pass']==node['tests'] and node['fail']==node['skipped']==node['cancelled']==0
groups=[]
for path in sorted(main.rglob('result.json')):
    data=json.loads(path.read_text());results=data.get('results',[])
    assert results and all(x.get('outcome',x.get('status'))=='passed' for x in results)
    groups.append({'group':str(path.parent.relative_to(main)),'executions':len(results)})
java=json.loads((main/'java-summary.json').read_text());assert all(x['failures']==x['errors']==x['skipped']==0 for x in java)
(raw/'runtime-evidence-inspection.json').write_text(json.dumps({'source':'Main actually executed results,read and bound by ontology only','node':node,'browserOrParserGroups':groups,'java':java,'ownRuntimeExecuted':False},ensure_ascii=False,indent=2)+'\n')
sync=[{'id':r['id'],'disposition':r['disposition'],'scope':r['conclusionDetail'],'sourceReferences':r['evidenceReferences']} for r in finite if r['recordType']!='selectedMarkdownExplanation']
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':{'sourceCommit':candidate,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':binding['contractReadCommit'],'uncommittedContractPaths':[]},
 'reason':'用户明确授权复用Word表格解析结果。本轮仅将同次DOCX导入已经解析的正文表格按实际DOM Element身份共享给原图片/高度读取，去掉重复运算；不改原图位、文字、边框、合并、媒体、错误/空白或原保存撤销/使用时冻结规则。未新增业务概念、生命周期、数量上限、权限、签署、审计、格式迁移、跨请求缓存或知识发布。353知识文件、2849资产ID和全部成熟度及投影保持，性能子项关闭不代表完整Office容量或父风险关闭，无必要新增同义业务规则。',
 'changedArtifacts':[],'knowledgeSync':sync,'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.w2-word-reuse-finite-records','checkType':'reference','command':'python3 build-finite-records.py','outcome':'passed','evidence':['finite-review-records.jsonl','finite-review-summary.json','knowledge-file-inventory.jsonl','knowledge-id-inventory.jsonl','user-authorization.json','有限8条=6个既有ID与2个选定Markdown说明，5consistent/1原evidence-gap/2原needs-decision；机械353文件/2849唯一schema资产全pending，不新增历史unique或全库语义完成结论。']},
  {'id':'validation.w2-word-reuse-source-and-knowledge','checkType':'status-transition','command':f'python3 bind-final-inputs.py {candidate} <main-final-run.json> {base}','outcome':'passed','evidence':['baseline-inputs.json','final-source-knowledge-binding.json','read-evidence/import-word-candidate.diff','knowledge0.3.25/schema1.2.0/P0 in-progress及原成熟度/客户和运行投影均保持；目标与候选契约及知识无差异。PR87初读时OPEN且Word无差异，未据其未合入分支认证当前范围。']},
  {'id':'validation.w2-word-reuse-main-knowledge-89','checkType':'schema','command':'主侧实际Java命令见final-source-knowledge-binding.json.mainJavaCommand；本体仅核对原件','outcome':'passed','evidence':['read-evidence/final-main/java-summary.json','read-evidence/final-main/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','read-evidence/final-main/knowledge-inputs-before.json','read-evidence/final-main/knowledge-inputs.json','实际XML89个testcase且0失败/错误/skip；源XML时间在本轮Java步骤内，前后知识/测试输入与Git候选及当前一致。']},
  {'id':'validation.w2-word-reuse-runtime-binding','checkType':'evidence-path','command':'python3 bind-final-inputs.py；只读主侧正式测试和源码绑定，不执行运行测试','outcome':'passed','evidence':['runtime-evidence-inspection.json','final-source-knowledge-binding.json','read-evidence/final-main/run.json','主侧完整页面新旧等价、解析次数和实际组件结果按各自原件记录；本体没有亲跑浏览器/Node/Java/数据库/CI或手动视觉检查，不替代独立QA，也不认证全部格式/布局近似/历史或生产SLA。']}
 ],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(raw/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=120))
review=f'''# W2 Word 表格解析复用本体核对

正式结果：not-applicable / FINAL。受测候选 `{candidate}`，集成目标 `{base}`。实际契约读取 `{binding['contractReadCommit']}`；最终逐字节核对契约、知识与候选一致。知识0.3.25/schema1.2.0、P0 in-progress、各资产成熟度与客户/运行投影保持。

当前用户已明确选择“下一批先复用表格解析结果（推荐）”，授权范围是一次DOCX导入内部减少重复解析，并保留原图片位置、文字、边框和撤销行为。并未确认新业务规则、文档或图数上限、布局修正或跨请求缓存。用户原问答单独保存在user-authorization.json。技术性Map存活在单次导入，依据实际DOM节点区分当前表格；解析输出沿原CanvasPage、Shell/store一次应用、序列化和读取消费。完整输出等价与原行为保护由主侧运行证据和独立QA验证，不把“复用”当作“原图文近似完全正确”。

保留DEC-0077-12实际使用时冻结及不回写历史、22同一配置保存/撤销归属、30草稿免阻断业务完整性但保留格式/权限/证据安全。原确认证据中的旧DEC-0075编号按既有集成记录解释为当前DEC-0077，原话与历史不改写。此次没有后台API、权限/签署/审计、生产执行、实例或DHR历史变更，无迁移和新生命周期。原300行/75列等clamp仅保留工程行为，不升级为用户政策。

有限8条=6既有ID+2选定说明，5consistent、1原evidence-gap、2原needs-decision。剩余通用质量/异常/源签署有效性变化high、A12历史视图、非MVP完整多租户继续，不依赖本次优化，不为当前切片重问用户。353文件和2849唯一schema资产目录只是机械清单，全部pending；与有限语义结论分列，不新增历史unique，也不宣称全知识语义或全审计完成。

初始基线8a415040；PR87当时仍OPEN，其Word源与当前目标相同，所以独立分支不继承其Excel修复或未合入覆盖。最终目标/来源按上方实际绑定，而非把“已创建PR”当成已合入。

已核对主侧正式运行原件：Node {node['pass']}，浏览器/解析器分组 `{json.dumps(groups,ensure_ascii=False)}`，Java `{json.dumps(java,ensure_ascii=False)}`。知识89实际testcase、源XML时间/摘要及前后输入已核验；来源指纹{len(binding['sourceInputs'])}、知识/知识测试输入{binding['knowledgeInputs']}同当前和Git。这里只是本体读取已执行原件，不声称本角色亲跑Node/浏览器/Java、数据库或CI，也不声称手动视觉检查，不替代全新独立QA。

本轮仅处理PERF-W2-WORD-TABLE-REPARSE-001的重复表解析子范围；父项Office ZIP全量解压、无关条目/工作簿加载、媒体编码、峰值内存和生产容量仍保留。局部计数/耗时不是生产SLA或完整Office合规验证。W2其他格式/叶子/图文布局、W3–W7、全知识语义、A23已审补查及原用户暂停保持。

changedArtifacts为空，当前切片无conflicts/questions，不新增试点或运行知识引擎，不提升P1–P3阶段。原件、源快照、有限逐条记录和正式结果由manifest及SHA256SUMS封存。
'''
(raw/'review.md').write_text(review)
def sha(b):return hashlib.sha256(b).hexdigest()
files=[]
for p in sorted(raw.rglob('*')):
    if p.is_file() and p.name not in ('manifest.json','SHA256SUMS'):
        b=p.read_bytes();files.append({'path':str(p.relative_to(raw)),'bytes':len(b),'sha256':sha(b)})
(raw/'manifest.json').write_text(json.dumps({'sealedAt':datetime.datetime.now(ZoneInfo('Asia/Shanghai')).isoformat(),'candidate':candidate,'target':base,'result':'not-applicable','files':files},ensure_ascii=False,indent=2)+'\n')
checks=files+[{'path':'manifest.json','sha256':sha((raw/'manifest.json').read_bytes())}]
(raw/'SHA256SUMS').write_text(''.join(item['sha256']+'  '+item['path']+'\n' for item in checks))
for item in files:
    b=(raw/item['path']).read_bytes();assert len(b)==item['bytes'] and sha(b)==item['sha256']
for line in (raw/'SHA256SUMS').read_text().splitlines():
    digest,path=line.split('  ',1);assert sha((raw/path).read_bytes())==digest
print(json.dumps({'result':'not-applicable','candidate':candidate,'manifestFiles':len(files),'manifestSha256':sha((raw/'manifest.json').read_bytes()),'sha256SumsSha256':sha((raw/'SHA256SUMS').read_bytes())},ensure_ascii=False))
