from pathlib import Path
import hashlib,json,subprocess
repo=Path('/workspace/edhr-nexus-frontend');raw=Path(__file__).parent
candidate='7b63b4c545490489e3e7df1d2009957e7e34cf63'
base='gmp-platform/backend/src/main/java/com/zencas/edhr/'
scopes=[
 ('recordcontrol/service/RecordControlService.java',['handle','applyResult'],'reviewed-limited','event identity,lock order,actual approval timing,replay and same transaction;not whole service',[]),
 ('production/service/DhrEvidenceImpactService.java',['sourceEffective'],'reviewed-limited','frozen source identity,submitter recovery,current responsibility,recipient dedup,SQL growth,A23',['PERF-DHR-IMPACT-NOTIFICATION-READ-001']),
 ('production/service/DhrImpactNotificationService.java',['list','read','actor'],'reviewed-limited','personal tenant scope,database paging,read idempotency,no extra detail permission,A23',[]),
 ('production/controller/DhrImpactNotificationController.java',['list','read'],'reviewed-limited','authenticated route and real HTTP filter/controller/service path;no browser claim',[]),
 ('workflow/service/WorkflowResponsibilityService.java',['reassign','change'],'reviewed-limited','only DHR signed reassignment influence on current candidate and originSnapshot;not full transfer matrix',[]),
 ('production/service/DhrSummaryService.java',['submit','reorganize'],'runtime-fixture-support','real frozen version creation exercised;no new full semantic/placement/concurrency review claimed',[]),
]
rows=[]
for suffix,methods,status,scope,risks in scopes:
 path=base+suffix;data=subprocess.check_output(['git','show',candidate+':'+path],cwd=repo)
 rows.append({'candidate':candidate,'path':path,'sha256':hashlib.sha256(data).hexdigest(),'methods':methods,'reviewStatus':status,'actualScope':scope,
  'fullFileComplete':False,'newCorrectnessDefects':[],'performanceSignals':risks,
  'evidence':['final_candidate/run.json','final_candidate/test-summary.json','final_candidate/notification-observations','final_candidate/http.jsonl','source-execute-frames.json'],
  'qualification':'Current method/chain scope only;historical overlap not counted as new unique or whole-file completion'})
(raw/'method-review-records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows))
print(json.dumps({'limitedSourceScopes':5,'runtimeFixtureSupportOnly':1,'newWholeFileCompletions':0,'historicalUniqueNotRecomputed':True}))
