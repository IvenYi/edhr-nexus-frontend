from pathlib import Path
import collections, datetime, hashlib, json, re, subprocess

repo=Path('/workspace/edhr-nexus-frontend'); raw=Path(__file__).parent
candidate='7b63b4c545490489e3e7df1d2009957e7e34cf63'
target='ea46c826f821ab2496a56df13fbcb0bd47e25eff'
def sha(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(p.read_text())
phase=raw/'final_candidate'; run=load(phase/'run.json')
assert run['head']==candidate and not run['workingTreeStatus'] and run['exitCode']==0
summary=load(phase/'test-summary.json')
assert summary['totals']==dict(tests=177,failures=0,errors=0,skipped=0) and not summary['missingFreshReports']
bindings=[]
for item in run['sourceFingerprints']:
 p=item['path']; actual=sha((repo/p).read_bytes()); committed=sha(subprocess.check_output(['git','show',candidate+':'+p],cwd=repo))
 assert item['sha256']==actual==committed==sha((phase/'source'/p).read_bytes()),p
 bindings.append({'path':p,'sha256':actual})
k=load(raw/'knowledge/run.json')
assert k['head']==candidate and not k['workingTreeState'] and k['exitCode']==0
assert load(raw/'knowledge/test-summary.json')==dict(tests=89,failures=0,errors=0,skipped=0)
for item in k['sourceFingerprints']:
 assert item['sha256']==sha((repo/item['path']).read_bytes())==sha(subprocess.check_output(['git','show',candidate+':'+item['path']],cwd=repo))
observations=[]
for p in sorted((phase/'notification-observations').glob('*.json')):
 d=load(p)
 if p.stem.startswith(('identity-','recipients-')):
  assert d['recipients']==sorted(r['recipient_id'] for r in d['actualNotificationRows'])
  assert len(d['actualImpactRows'])==1
 if 'frozenBeforeSha256' in d:
  assert d['frozenBeforeSha256']==d['frozenAfterSha256'] and d['replayBeforeSha256']==d['replayAfterSha256']
 observations.append({'file':p.name,'sha256':sha(p.read_bytes()),**{q:v for q,v in d.items() if q not in ['actualNotificationRows','actualImpactRows']}})
assert len(observations)==20
pages=load(phase/'notification-observations/pages-and-read.json')
assert pages['total']==pages['uniqueReachable']==len(set(pages['orderedIds']))==100
assert pages['orderedIds']==sorted(pages['orderedIds'],key=int,reverse=True)
assert pages['unreadAfterRead']==99 and sum(r['read_at'] is not None for r in pages['actualNotificationRows'])==1
http=[json.loads(line) for line in (phase/'http.jsonl').read_text().splitlines()]
notices=[d for d in http if d['case'].startswith('notification-')]
assert len(notices)==28
records=re.split(r'(?m)(?=^2026-\d\d-\d\d \d\d:\d\d:\d\d\.\d+ UTC \[)',(phase/'postgres.log').read_text())
cost=[]; allplans=[]; sqlframes=[]
for v in [1,10,100]:
 counts=collections.Counter(); plans=[]
 for record in records:
  if not record:continue
  first=record.splitlines()[0]
  if f' notification-source-{v} ' not in first:continue
  if ' execute ' in first:
   sql=re.split(r' execute [^:]+: ',record,maxsplit=1)[-1]
   if not sql.startswith(('SELECT','INSERT')):continue
   kind='SELECT' if sql.startswith('SELECT') else 'IMPACT_UPSERT_RETURNING' if 'INSERT INTO dhr_evidence_impact' in sql else 'NOTICE_INSERT'
   counts[kind]+=1;sqlframes.append({'versions':v,'kind':kind,'record':record})
  if 'plan:' in first:
   plans.append(json.loads(record.split('plan:',1)[1].strip()))
 assert counts==dict(SELECT=v+1,IMPACT_UPSERT_RETURNING=v,NOTICE_INSERT=v)
 assert len(plans)==3*v+1
 d=load(phase/f'notification-observations/capacity-{v}.json')
 assert len(d['actualImpactRows'])==len(d['actualNotificationRows'])==v
 cost.append({'versions':v,**dict(counts),'totalSourceCommands':sum(counts.values()),'elapsedNanos':d['elapsedNanos'],'threadAllocatedBytes':d['threadAllocatedBytes'],'planCount':len(plans)})
 allplans.append({'versions':v,'plans':plans})
(raw/'source-execute-frames.json').write_text(json.dumps(sqlframes,ensure_ascii=False,indent=2)+'\n')
(raw/'source-auto-explain-plans.json').write_text(json.dumps(allplans,ensure_ascii=False,indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only',target,candidate],cwd=repo,text=True).splitlines()
assert len(changed)==8 and not any('/src/main/' in p or '/frontend/' in p for p in changed)
out={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'target':target,
 'mainTests':summary,'knowledgeTests':load(raw/'knowledge/test-summary.json'),'protectedInputs':bindings,'knowledgeInputs':len(k['sourceFingerprints']),
 'changedFiles':changed,'notificationObservations':observations,'notificationHttpCount':len(notices),'allNativeHttpCount':len(http),'sourceCosts':cost,
 'fixtureFailurePreserved':{'phase':'focused_complete','tests':19,'failures':1,'cause':'test oracle ORDER BY projected text alias;product numeric order correct;qualified column retained exact order and unique-100 assertions'},
 'intermediateFullRun':{'phase':'final','actualHead':load(raw/'final/run.json')['head'],'tests':load(raw/'final/test-summary.json')['totals'],'qualification':'intermediate only;subsequent one-line knowledge clarification separately committed and clean final_candidate repeated'},
 'qualification':'Real source method in actual approval transaction;cost covers sourceEffective only, not entire approval/lock duration. Version samples are not caps or personnel counts. Allocated bytes are cumulative on invoking thread, not RSS/peak. No runtime product/policy/index optimization.'}
(raw/'main-analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['candidate','knowledgeInputs','notificationHttpCount','allNativeHttpCount','sourceCosts']},ensure_ascii=False,indent=2))
