from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

root = Path(os.environ.get('EDHR_CANDIDATE_ROOT', '/workspace/edhr-nexus-frontend'))
raw = Path(os.environ.get('EDHR_CANDIDATE_RAW', '/tmp/edhr-dhr-impact-notifications-20261111'))
phase = sys.argv[1]
assert re.fullmatch('[a-z0-9_]+', phase)
out = raw / phase
out.mkdir(parents=True, exist_ok=False)
shutil.copyfile(__file__, out / 'runner-source.py')
prefix = os.environ.get('EDHR_CANDIDATE_CONTAINER_PREFIX', 'edhr-dhr-notifications-main')
name = prefix + '-' + phase + '-20261111'
db = 'edhr_record_control_test_notify_' + phase
selected = 'RecordControlPostgresIntegrationTest#effectiveNotificationRecipientsFollowActualCurrentResponsibility+legacyNotificationIdentityUsesOnlyRecoverableAccounts' if phase.startswith('focused') else 'RecordControlPostgresIntegrationTest,RecordControlDiffTest,RecordControlTaskActionServiceTest,RecordControlAccessTest,CurrentDatabaseBaselineTest,RecordControlWorkflowServiceTest,RecordControlWorkflowControllerTest,RecordControlCandidateAuthorizationTest,FormReferenceConfigTest,FormReferenceLookupTest'
classes = [s.split('#')[0] for s in selected.split(',')]
created = False
exit_code = 1


def checked(args, **kwargs):
    return subprocess.run(args, check=True, text=True, capture_output=True, **kwargs).stdout.strip()


try:
    checked(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust',
             '-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine',
             '-c','shared_preload_libraries=auto_explain,pg_stat_statements',
             '-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1',
             '-c','log_line_prefix=%m [%p] %d %a %x '])
    created = True
    for _ in range(120):
        if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode == 0:
            break
        time.sleep(.25)
    else:
        raise RuntimeError('Owned PG did not become ready')
    port = checked(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
    url = f'jdbc:postgresql://127.0.0.1:{port}/{db}'
    env = os.environ.copy()
    env.update(PGUSER='postgres',PGPASSWORD='',RECORD_CONTROL_TEST_DATABASE_URL=url)
    paths = ['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md',
      'docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlDiff.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/ExecutionAccess.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/controller/RecordControlController.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceConfig.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/template/service/FormReferenceLookup.java',
      'docs/development/branch-review-20261111-dhr-impact-notifications/decision-package.yaml',
      'DESIGN.md','docs/frontend/list-page-guidelines.md',
      'gmp-platform/frontend/src/api/record-control.ts',
      'gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx',
      'gmp-platform/frontend/scripts/test-record-change-async-browser.mjs',
      'gmp-platform/frontend/src/components/form-renderer/ReferencePickerDialog.tsx',
      'gmp-platform/frontend/src/components/form-renderer/referenceConfig.ts',
      'gmp-platform/backend/pom.xml',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/RecordControlWorkflowService.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/controller/RecordControlWorkflowController.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/contract/RecordControlWorkflowContracts.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionRepository.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowDefinitionVersionRepository.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/entity/WorkflowDefinition.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/entity/WorkflowDefinitionVersion.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
      'gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml',
      'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql',
      'gmp-platform/backend/src/main/resources/db/changelog/baseline/0002-current-seed.sql',
      'gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql',
      'docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
      'docs/knowledge/decisions/DEC-0094-record-control-authenticated-candidate-read.yaml',
      'docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','docs/knowledge/rules/record-change.yaml',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrImpactNotificationService.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrImpactNotificationController.java',
      'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
      'docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml','docs/knowledge/evidence/record-control-dhr-linkage.yaml']
    for c in classes:
        matches = list((root/'gmp-platform/backend/src/test/java').rglob(c+'.java'))
        assert len(matches) == 1, c
        paths.append(str(matches[0].relative_to(root)))
    inputs = []
    for path in paths:
        data = (root/path).read_bytes()
        inputs.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        dest = out/'source'/path
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
    tmp = out/'vm-tmp'
    tmp.mkdir()
    command = ['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress',
       '-f','gmp-platform/backend/pom.xml','-Dtest='+selected,
       '-Dedhr.audit.recordSignatureOutput='+str(out/'signature-observations'),
       '-Dedhr.audit.workflowCandidateCapacity=true','-Dedhr.audit.workflowCandidateOutput='+str(out/'candidate-observations'),
       '-Dedhr.audit.recordReadCapacity=true','-Dedhr.audit.recordReadOutput='+str(out/'record-observations'),
       '-Dedhr.audit.dhrHttpOutput='+str(out/'http.jsonl'),
       '-Dedhr.audit.notifications=true','-Dedhr.audit.notificationOutput='+str(out/'notification-observations'),
       '-DargLine=-Xmx1536m -Djava.io.tmpdir='+str(tmp),'test']
    started = datetime.datetime.now(datetime.timezone.utc)
    record = {'command':command,'head':checked(['git','rev-parse','HEAD'],cwd=root),
      'workingTreeStatus':checked(['git','status','--porcelain=v1'],cwd=root),
      'sourceFingerprints':inputs,'databaseUrl':url,'ownedContainer':name,'startedAt':started.isoformat()}
    (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    with (out/'maven.log').open('w') as log:
        result = subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exitCode=result.returncode,finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
    (out/'run.json').write_text(json.dumps(record,indent=2)+'\n')
    totals = dict(tests=0,failures=0,errors=0,skipped=0)
    reports, missing = [], []
    for c in classes:
        hits = [p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+c+'.xml') if p.stat().st_mtime>=started.timestamp()]
        if len(hits)!=1:
            missing.append(c)
            continue
        p = hits[0]
        shutil.copyfile(p,out/p.name)
        attrs=ET.parse(p).getroot().attrib
        counts={k:int(attrs.get(k,0)) for k in totals}
        reports.append({'name':attrs['name'],**counts})
        for k in totals:
            totals[k]+=counts[k]
    summary={'totals':totals,'classes':reports,'missingFreshReports':missing}
    (out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)
    print((out/'maven.log').read_text()[-1300:],flush=True)
    exit_code = 0 if result.returncode == 0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
    if created:
        logs=subprocess.run(['docker','logs',name],capture_output=True,text=True)
        (out/'postgres.log').write_text(logs.stdout+logs.stderr)
        checked(['docker','stop',name])
        removed=False
        for _ in range(30):
            if subprocess.run(['docker','inspect',name],capture_output=True).returncode != 0:
                removed=True
                break
            time.sleep(.1)
        (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n')
sys.exit(exit_code)
