from pathlib import Path
import datetime, hashlib, json

raw=Path(__file__).parent
def sha(data): return hashlib.sha256(data).hexdigest()
files=[]
for path in sorted(raw.rglob('*')):
    if not path.is_file() or path.name in ['manifest.json','SHA256SUMS']: continue
    data=path.read_bytes()
    files.append({'path':str(path.relative_to(raw)), 'bytes':len(data), 'sha256':sha(data)})
manifest={'role':'independent-quality-verifier','final':True,'sealedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'baseCommit':'ea46c826f821ab2496a56df13fbcb0bd47e25eff','testedCandidate':'7b63b4c545490489e3e7df1d2009957e7e34cf63',
          'qualityResult':'passed','files':files}
(raw/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
lines=[x['sha256']+'  '+x['path'] for x in files]
lines.append(sha((raw/'manifest.json').read_bytes())+'  manifest.json')
(raw/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
for item in files:
    data=(raw/item['path']).read_bytes()
    assert len(data)==item['bytes'] and sha(data)==item['sha256']
for line in (raw/'SHA256SUMS').read_text().splitlines():
    checksum,path=line.split('  ',1); assert sha((raw/path).read_bytes())==checksum
print(json.dumps({'manifestSha256':sha((raw/'manifest.json').read_bytes()),'files':len(files),'bytes':sum(x['bytes'] for x in files)},indent=2))
