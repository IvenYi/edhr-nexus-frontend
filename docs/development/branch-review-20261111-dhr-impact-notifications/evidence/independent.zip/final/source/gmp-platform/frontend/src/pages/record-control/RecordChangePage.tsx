import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle,
  Divider, MenuItem, Paper, Snackbar, Stack, TextField, Tooltip, Typography } from '@mui/material';
import { DescriptionOutlined, FactCheckOutlined, RateReviewOutlined, SearchRounded } from '@mui/icons-material';
import ButtonSignatureCredentials from '@/components/workflow/ButtonSignatureCredentials';
import ConfirmDialog from '@/components/ConfirmDialog';
import type { ReferencePageRequest } from '@/components/form-renderer/referenceConfig';
import { executionFormValues } from '@/pages/production/executionFormValues';
import { FormCanvasPreview } from '@/pages/master-data/DhrTemplateWorkspaceDialog';
import { parseReactTemplateDesignerDocument } from '@/pages/master-data/template-designer-react/utils/document';
import { uploadExecutionFile } from '@/api/production-execution';
import { listPublishedRecordControlWorkflowCandidates, type PublishedRecordControlWorkflowCandidate,
  type RecordControlBusinessType } from '@/api/record-control-workflow';
import { findRecordByNumber, getRecordControlReferences, submitRecordControlRequest,
  type RecordControlRecord } from '@/api/record-control';

type Mode = 'READ' | RecordControlBusinessType;

export default function RecordChangePage() {
  const navigate = useNavigate();
  const [number, setNumber] = useState('');
  const [record, setRecord] = useState<RecordControlRecord | null>(null);
  const [mode, setMode] = useState<Mode>('READ');
  const [values, setValues] = useState<Record<string, unknown>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dialog, setDialog] = useState(false);
  const [reason, setReason] = useState('');
  const [candidates, setCandidates] = useState<PublishedRecordControlWorkflowCandidate[]>([]);
  const [workflowVersionId, setWorkflowVersionId] = useState('');
  const [account, setAccount] = useState('');
  const [password, setPassword] = useState('');
  const [requestId, setRequestId] = useState<string | null>(null);
  const [idempotencyKey, setIdempotencyKey] = useState('');
  const [activeRequestNoticeOpen, setActiveRequestNoticeOpen] = useState(false);
  const [pendingSearch, setPendingSearch] = useState('');
  const [candidatesLoading, setCandidatesLoading] = useState(false);
  const [candidatesError, setCandidatesError] = useState('');
  const lookupSequence = useRef(0);
  const recordId = record?.id;

  useEffect(() => () => { lookupSequence.current++; }, []);

  useEffect(() => {
    if (mode === 'READ' || !recordId) { setCandidatesLoading(false); return; }
    let active = true;
    setCandidatesLoading(true);
    listPublishedRecordControlWorkflowCandidates(mode).then((result) => {
      if (active) setCandidates(result);
    }).catch((cause) => {
      if (active) setCandidatesError(cause instanceof Error ? cause.message : '可用审批流程加载失败');
    }).finally(() => { if (active) setCandidatesLoading(false); });
    return () => { active = false; };
  }, [mode, recordId]);

  const document = useMemo(() => {
    if (!record) return null;
    const form = record.snapshot;
    const parsed = parseReactTemplateDesignerDocument({ id: record.id, name: form.name }, {
      id: form.versionId, version: form.version, modelDesignJson: form.model, canvasDesignJson: form.canvas,
    });
    parsed.model.fields = form.fields.map((field, index) => ({ ...field, typeConfig: field.typeConfig ?? {},
      status: field.status ?? 'enabled', sortOrder: field.sortOrder ?? index }));
    return parsed;
  }, [record]);

  const eligible = record?.status === 'COMPLETED' && Boolean(record.current_revision_id) && !record.active_request_id;
  const modified = record && JSON.stringify(values) !== JSON.stringify(record.fieldValues);
  const selectedCandidate = candidates.find((item) => item.workflowVersionId === workflowVersionId);
  const canViewSubmittedRequest = record?.active_request_id === requestId && record.canViewActiveRequest !== false;

  const loadRecord = useCallback(async (instanceNo: string) => {
    const request = ++lookupSequence.current;
    setLoading(true); setError(''); setRequestId(null); setMode('READ'); setActiveRequestNoticeOpen(false);
    setRecord(null); setValues({}); setDialog(false); setPassword(''); setCandidates([]); setWorkflowVersionId(''); setCandidatesError('');
    try {
      const found = await findRecordByNumber(instanceNo);
      if (request !== lookupSequence.current) return;
      setRecord(found); setValues(structuredClone(found.fieldValues));
      setActiveRequestNoticeOpen(Boolean(found.active_request_id && found.active_request_no));
    } catch (cause) {
      if (request !== lookupSequence.current) return;
      setRecord(null); setActiveRequestNoticeOpen(false); setError(cause instanceof Error ? cause.message : '查询失败');
    } finally { if (request === lookupSequence.current) setLoading(false); }
  }, []);

  const search = () => {
    const instanceNo = number.trim();
    if (!instanceNo) { setError('请输入表单实例编号'); return; }
    if (mode === 'CHANGE' && modified) { setPendingSearch(instanceNo); return; }
    void loadRecord(instanceNo);
  };

  const chooseMode = (next: RecordControlBusinessType) => {
    if (!record || !eligible) return;
    setMode(next); setValues(structuredClone(record.fieldValues)); setReason(''); setPassword('');
    setWorkflowVersionId(''); setCandidates([]); setError(''); setCandidatesError('');
  };

  const openConfirmation = () => {
    if (mode === 'CHANGE' && !modified) { setError('表单内容没有实际变化'); return; }
    setIdempotencyKey(crypto.randomUUID()); setDialog(true); setError('');
  };

  const confirm = async () => {
    if (!record?.current_revision_id || mode === 'READ' || !selectedCandidate) return;
    const request = ++lookupSequence.current;
    setLoading(true); setError('');
    try {
      const submitted = await submitRecordControlRequest({
        requestType: mode, instanceNo: record.instance_no, sourceRevisionId: record.current_revision_id,
        proposedValues: mode === 'CHANGE' ? executionFormValues(record.snapshot.fields, values) : undefined, reason: reason.trim(),
        workflowDefinitionId: selectedCandidate.workflowDefinitionId,
        workflowVersionId: selectedCandidate.workflowVersionId, account, password, idempotencyKey,
      });
      if (request !== lookupSequence.current) return;
      setRequestId(submitted.id); setDialog(false); setPassword(''); setMode('READ');
      const fresh = await findRecordByNumber(record.instance_no);
      if (request !== lookupSequence.current) return;
      setRecord(fresh); setValues(structuredClone(fresh.fieldValues));
    } catch (cause) { if (request === lookupSequence.current) setError(cause instanceof Error ? cause.message : '申请提交失败'); }
    finally { if (request === lookupSequence.current) setLoading(false); }
  };

  useEffect(() => {
    if (mode !== 'CHANGE' || !modified) return;
    const guard = (event: BeforeUnloadEvent) => { event.preventDefault(); event.returnValue = ''; };
    window.addEventListener('beforeunload', guard);
    return () => window.removeEventListener('beforeunload', guard);
  }, [mode, modified]);

  const runtime = record ? {
    values: mode === 'CHANGE' ? values : record.fieldValues,
    disabled: mode !== 'CHANGE' || loading,
    rowIdentity: true,
    onChange: (fieldId: string, value: unknown) => setValues((current) => ({ ...current, [fieldId]: value })),
    upload: (file: File) => uploadExecutionFile(record.object_id, file),
    references: (fieldId: string, keyword: string, context: Record<string, unknown>, paging?: ReferencePageRequest) =>
      getRecordControlReferences(record.id, fieldId, keyword, context, paging),
  } : undefined;

  return <Box sx={{ height: { xs: 'auto', lg: 'calc(100vh - 150px)' }, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: { xs: 'visible', lg: 'hidden' } }}>
    {!dialog && error && <Alert severity="error" sx={{ mb: 1.5 }} onClose={() => setError('')}>{error}</Alert>}
    {!dialog && mode !== 'READ' && candidatesError && <Alert severity="error" sx={{ mb: 1.5 }}>{candidatesError}</Alert>}
    {requestId && <Alert severity="success" sx={{ mb: 1.5 }} action={<Tooltip title={canViewSubmittedRequest ? '查看申请' : record?.active_request_id === requestId ? '当前账号无权查看此在审申请' : '请重新查询表单后查看申请'} arrow>
      <span tabIndex={canViewSubmittedRequest ? undefined : 0}><Button disabled={!canViewSubmittedRequest} onClick={() => navigate(`/records/requests/${requestId}`)}>查看申请</Button></span>
    </Tooltip>}>
      申请已提交，原表单仍保持已完成状态，等待审批。
    </Alert>}
    <Snackbar open={!requestId && activeRequestNoticeOpen && Boolean(record?.active_request_id && record.active_request_no)}
      autoHideDuration={3000} anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      onClose={(_, reason) => { if (reason !== 'clickaway') setActiveRequestNoticeOpen(false); }}
      sx={{ top: { xs: '72px !important', md: '132px !important' }, maxWidth: 'min(760px, calc(100vw - 32px))' }}>
      <Alert severity="warning" variant="standard" onClose={() => setActiveRequestNoticeOpen(false)}
        sx={{ width: '100%', border: '1px solid', borderColor: 'warning.light', boxShadow: 4 }}>
        该表单存在正在进行中的{record?.active_request_type === 'OBSOLETE' ? '作废' : '变更'}申请，申请编号：
        <Tooltip title={record?.canViewActiveRequest === false ? '当前账号无权查看此在审申请' : '查看申请'} arrow>
        <span tabIndex={record?.canViewActiveRequest === false ? 0 : undefined}><Button size="small" variant="text" aria-label={`查看申请 ${record?.active_request_no ?? ''}`}
          disabled={record?.canViewActiveRequest === false}
          sx={{ minWidth: 0, p: 0, mx: 0.5, verticalAlign: 'baseline' }}
          onClick={() => { if (record?.active_request_id) navigate(`/records/requests/${record.active_request_id}`); }}>{record?.active_request_no}</Button></span></Tooltip>
        。请先完成当前申请后再发起新申请。
      </Alert>
    </Snackbar>
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} sx={{ flex: 1, minHeight: 0, overflow: { xs: 'visible', lg: 'hidden' } }}>
      <Paper variant="outlined" sx={{ width: { xs: '100%', md: 360 }, flexShrink: 0, minHeight: 0, p: 2.5, alignSelf: 'stretch', overflowY: { xs: 'visible', lg: 'auto' } }}>
        <Typography fontWeight={600} sx={{ mb: 2 }}>查询表单</Typography>
        <Stack direction="row" spacing={1.5}>
          <TextField size="small" fullWidth label="表单实例编号" value={number} onChange={(event) => setNumber(event.target.value)}
            onKeyDown={(event) => { if (event.key === 'Enter' && !event.nativeEvent.isComposing) { event.preventDefault(); search(); } }} />
          <Button variant="contained" disabled={loading} onClick={() => void search()}>查询</Button>
        </Stack>
        {!record && <Box sx={{ mt: 3, pt: 2.5, borderTop: '1px solid #ebeef5' }}>
          <Typography variant="body2" fontWeight={600} color="text.primary" sx={{ mb: 1.25 }}>查询说明</Typography>
          <Stack spacing={1.25}>
            <QueryHint index="1" text="输入完整的表单实例编号，例如 FR-20260917-000004" />
            <QueryHint index="2" text="查询后先核对表单状态、当前修订与原始填报内容" />
            <QueryHint index="3" text="仅已完成且存在有效修订的表单可以发起申请" />
          </Stack>
        </Box>}
        {record && <Box sx={{ mt: 2.5 }}>
          <Divider sx={{ mb: 2 }} />
          <Info label="表单名称" value={record.template_name} />
          <Info label="表单编码" value={record.template_code} />
          <Info label="表单实例编号" value={record.instance_no} />
          <Info label="模板版本" value={`V${record.version_number}`} />
          <Info label="当前修订" value={record.revision_no ? `Rev.${record.revision_no}` : '无'} />
          <Info label="创建人" value={record.created_by || '未知'} />
          <Info label="创建时间" value={displayDateTime(record.created_at)} />
          <Info label="更新人" value={record.updated_by || '未知'} />
          <Info label="更新时间" value={displayDateTime(record.updated_at)} />
          <Box sx={{ display: 'grid', gridTemplateColumns: '96px minmax(0, 1fr)', columnGap: 1.5, alignItems: 'center' }}>
            <Typography variant="body2" color="text.secondary">表单状态</Typography>
            <Chip size="small" sx={{ justifySelf: 'start' }}
              label={record.status === 'COMPLETED' ? '已完成' : record.status === 'OBSOLETE' ? '已作废' : record.status} />
          </Box>
          {!eligible && !record.active_request_id && <Alert severity="info" sx={{ mt: 2 }}>仅已完成且有有效修订的表单可以发起申请。</Alert>}
        </Box>}
      </Paper>
      <Paper variant="outlined" sx={{ flex: 1, minWidth: 0, minHeight: 0, display: 'flex', flexDirection: 'column', overflow: 'hidden', bgcolor: record ? '#fff' : '#fbfcfe' }}>
        <Box sx={{ flex: 1, minHeight: 0, p: 2, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          {loading && !record ? <Box sx={{ flex: 1, display: 'grid', placeItems: 'center' }}><Stack spacing={1.5} alignItems="center">
              <CircularProgress size={32} /><Typography variant="body2" color="text.secondary">正在查询表单记录…</Typography>
            </Stack></Box> : record && document && runtime
            ? <>{Object.keys(record.fieldValues).length === 0 && record.snapshot.fields.length > 0 &&
                <Alert severity="warning" sx={{ mb: 2, flexShrink: 0 }}>当前实例没有已保存的字段值；下方内容不能作为原始填报记录{mode === 'CHANGE' ? '，新填写的内容仅是未提交的变更草稿' : ''}。请先核对生产执行中的保存记录。</Alert>}
              <Box sx={{ flex: 1, minHeight: 0, display: 'flex', overflow: 'hidden' }}>
                <FormCanvasPreview document={document} runtime={runtime} />
              </Box></>
            : <RecordChangeEmptyState />}
        </Box>
        {record && <Stack direction="row" justifyContent="flex-end" spacing={1} sx={{ p: 1.5, flexShrink: 0, borderTop: '1px solid #e4e7ed', bgcolor: '#fff' }}>
          {mode === 'READ' ? <>
            <Button disabled={!eligible || loading} onClick={() => void chooseMode('CHANGE')}>表单变更</Button>
            <Button color="error" disabled={!eligible || loading} onClick={() => void chooseMode('OBSOLETE')}>表单作废</Button>
          </> : <>
            <Button onClick={() => { setMode('READ'); setValues(structuredClone(record?.fieldValues ?? {})); }}>取消</Button>
            <Button variant="contained" disabled={loading || (mode === 'CHANGE' && !modified)} onClick={openConfirmation}>提交{mode === 'CHANGE' ? '变更' : '作废'}审批</Button>
          </>}
        </Stack>}
      </Paper>
    </Stack>
    <Dialog open={dialog} onClose={loading ? undefined : () => setDialog(false)} maxWidth="sm" fullWidth>
      <DialogTitle>确认提交{mode === 'CHANGE' ? '表单变更' : '表单作废'}申请</DialogTitle>
      <DialogContent><Stack spacing={2} sx={{ pt: 1 }}>
        <TextField multiline minRows={3} fullWidth required label={mode === 'CHANGE' ? '变更原因' : '作废原因'} value={reason}
          onChange={(event) => setReason(event.target.value)} inputProps={{ maxLength: 2000 }} />
        <TextField select fullWidth required label="审批流程版本" value={workflowVersionId} disabled={candidatesLoading}
          onChange={(event) => setWorkflowVersionId(event.target.value)} helperText="必须显式选择匹配类型的已发布流程版本">
          {candidates.map((candidate) => <MenuItem key={candidate.workflowVersionId} value={candidate.workflowVersionId}>
            {candidate.templateName} · V{candidate.versionNumber}
          </MenuItem>)}
        </TextField>
        {candidatesLoading ? <Alert severity="info">正在加载可用审批流程…</Alert>
          : candidatesError ? <Alert severity="error">{candidatesError}</Alert>
            : !candidates.length && <Alert severity="warning">暂无可用的已发布审批流程。</Alert>}
        <ButtonSignatureCredentials account={account} password={password} disabled={loading}
          onAccountChange={setAccount} onPasswordChange={setPassword} />
        {error && <Alert severity="error">{error}</Alert>}
      </Stack></DialogContent>
      <DialogActions><Button disabled={loading} onClick={() => setDialog(false)}>取消</Button>
        <Button variant="contained" disabled={loading || !reason.trim() || !selectedCandidate || !account.trim() || !password}
          onClick={() => void confirm()}>{loading ? '提交中…' : '签署并确认提交'}</Button>
      </DialogActions>
    </Dialog>
    <ConfirmDialog open={Boolean(pendingSearch)} title="重新查询表单" confirmText="放弃修改并查询"
      message="当前拟变更内容尚未提交，重新查询将丢弃修改。确定继续吗？" destructive initialFocus="cancel"
      onCancel={() => setPendingSearch('')} onConfirm={() => { const instanceNo = pendingSearch; setPendingSearch(''); void loadRecord(instanceNo); }} />
  </Box>;
}

function RecordChangeEmptyState() {
  const steps = [
    { icon: <SearchRounded />, number: '01', title: '查询表单', description: '输入表单实例编号，定位需要处理的生产记录。' },
    { icon: <FactCheckOutlined />, number: '02', title: '核对原始内容', description: '确认表单状态、当前修订及已保存的字段值。' },
    { icon: <RateReviewOutlined />, number: '03', title: '发起申请', description: '选择变更或作废，填写原因并完成电子签署。' },
  ];

  return <Box sx={{ flex: 1, minHeight: 0, overflowY: 'auto', display: 'grid', placeItems: 'center', px: { xs: 1, md: 4 }, py: 3 }}>
    <Box sx={{ width: '100%', maxWidth: 820 }}>
      <Stack alignItems="center" textAlign="center" spacing={1.25} sx={{ mb: 4 }}>
        <Box sx={{ width: 64, height: 64, borderRadius: 3, display: 'grid', placeItems: 'center', bgcolor: '#ecf5ff', color: 'primary.main' }}>
          <DescriptionOutlined sx={{ fontSize: 34 }} />
        </Box>
        <Typography variant="h6" fontWeight={700} color="text.primary">从一份已完成的表单开始</Typography>
        <Typography variant="body2" color="text.secondary" sx={{ maxWidth: 560, lineHeight: 1.8 }}>
          在左侧输入表单实例编号。系统会加载原始填报内容，并在同一工作区完成变更或作废申请。
        </Typography>
      </Stack>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', lg: 'repeat(3, minmax(0, 1fr))' }, gap: 1.5 }}>
        {steps.map((step) => <Box key={step.number} sx={{ p: 2.25, minHeight: 150, border: '1px solid #e4e7ed', borderRadius: 2, bgcolor: '#fff' }}>
          <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
            <Box sx={{ width: 38, height: 38, borderRadius: 2, display: 'grid', placeItems: 'center', bgcolor: '#ecf5ff', color: 'primary.main', '& svg': { fontSize: 21 } }}>{step.icon}</Box>
            <Typography variant="caption" fontWeight={700} color="#c0c4cc">STEP {step.number}</Typography>
          </Stack>
          <Typography variant="body1" fontWeight={600} sx={{ mb: 0.75 }}>{step.title}</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.7 }}>{step.description}</Typography>
        </Box>)}
      </Box>

      <Box sx={{ mt: 2, px: 2, py: 1.5, borderRadius: 1.5, bgcolor: '#f4f8ff', border: '1px solid #d9ecff' }}>
        <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.7 }}>
          <Box component="span" sx={{ color: 'primary.main', fontWeight: 600 }}>提示：</Box>
          查询不会修改原始记录；申请审批完成前，原表单仍保持当前状态。
        </Typography>
      </Box>
    </Box>
  </Box>;
}

function QueryHint({ index, text }: { index: string; text: string }) {
  return <Stack direction="row" spacing={1.25} alignItems="flex-start">
    <Box sx={{ width: 22, height: 22, mt: '1px', flexShrink: 0, display: 'grid', placeItems: 'center', borderRadius: '50%', bgcolor: '#ecf5ff', color: 'primary.main', fontSize: 12, fontWeight: 700 }}>{index}</Box>
    <Typography variant="body2" color="text.secondary" sx={{ lineHeight: 1.65 }}>{text}</Typography>
  </Stack>;
}

function Info({ label, value }: { label: string; value: string }) {
  return <Box sx={{ display: 'grid', gridTemplateColumns: '96px minmax(0, 1fr)', columnGap: 1.5, mb: 1.5, alignItems: 'start' }}>
    <Typography variant="body2" color="text.secondary">{label}</Typography>
    <Typography variant="body2" sx={{ overflowWrap: 'anywhere' }}>{value}</Typography>
  </Box>;
}

function displayDateTime(value: string | null): string {
  return value ? value.replace('T', ' ').slice(0, 19) : '未知';
}
