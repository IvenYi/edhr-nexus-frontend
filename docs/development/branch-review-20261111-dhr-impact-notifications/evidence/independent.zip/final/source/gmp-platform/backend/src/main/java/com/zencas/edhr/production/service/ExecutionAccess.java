package com.zencas.edhr.production.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zencas.edhr.common.audit.AuditContext;
import com.zencas.edhr.common.util.SnowflakeIdGenerator;
import com.zencas.edhr.compliance.entity.Signature;
import com.zencas.edhr.compliance.repository.SignatureRepository;
import com.zencas.edhr.identity.dto.SubjectReference;
import com.zencas.edhr.identity.entity.UserAccount;
import com.zencas.edhr.identity.repository.UserAccountRepository;
import com.zencas.edhr.identity.service.SubjectResolver;
import com.zencas.edhr.identity.service.TenantTransferTargets;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.*;

import static com.zencas.edhr.production.service.ExecutionSnapshotBuilder.invalid;

@Component
@RequiredArgsConstructor
public class ExecutionAccess {
    private final SubjectResolver subjects;
    private final UserAccountRepository users;
    private final PasswordEncoder passwords;
    private final SignatureRepository signatures;
    private final SnowflakeIdGenerator ids;
    private final ObjectMapper mapper;
    private final JdbcTemplate jdbc;

    public List<Map<String, String>> references(JsonNode field, String keyword) {
        return references(field, keyword, mapper.createObjectNode());
    }

    public List<Map<String, String>> references(JsonNode field, String keyword, JsonNode values) {
        return references(field, keyword, values, null, null);
    }

    public List<Map<String, String>> references(JsonNode field, String keyword, JsonNode values, Integer page, Integer size) {
        return new com.zencas.edhr.template.service.FormReferenceLookup(jdbc).search(field.path("typeConfig"), keyword, values, page, size);
    }

    public JsonNode contextReference(JsonNode config, String id, JsonNode values) {
        Map<String, String> found = new com.zencas.edhr.template.service.FormReferenceLookup(jdbc).find(config, id, values);
        return found == null ? null : mapper.valueToTree(found);
    }

    public void validateEvidence(JsonNode field, JsonNode value, String objectId) {
        validateEvidence(field, value, objectId, mapper.createObjectNode());
    }

    public void validateEvidence(JsonNode field, JsonNode value, String objectId, JsonNode values) {
        validateEvidence(field, value, objectId, values, null);
    }

    public void validateEvidence(JsonNode field, JsonNode value, String objectId, JsonNode values, JsonNode previous) {
        if (value.isNull() || value.isMissingNode() || (value.isTextual() && value.asText().isBlank())) return;
        String type = field.path("type").asText();
        if ("subTable".equals(type) && value.isArray()) {
            int index = 0;
            for (JsonNode row : value) {
                ObjectNode context = values.isObject() ? ((ObjectNode) values).deepCopy() : mapper.createObjectNode();
                if (row.isObject()) context.setAll((ObjectNode) row);
                JsonNode oldRow = previousRow(previous, row, index++);
                for (JsonNode column : field.path("typeConfig").path("columns"))
                    validateEvidence(column, row.path(column.path("id").asText()), objectId, context, oldRow.path(column.path("id").asText()));
            }
        }
        if ("reference".equals(type)) {
            new com.zencas.edhr.template.service.FormReferenceLookup(jdbc).validate(field.path("typeConfig"), value, values, previous);
        }
        if (Set.of("attachment", "image").contains(type)) {
            if (!value.isArray()) throw invalid("附件字段必须使用上传文件记录");
            for (JsonNode file : value) {
                long fileId;
                try { fileId = Long.parseLong(file.path("fileId").asText()); } catch (NumberFormatException e) { throw invalid("文件标识不正确"); }
                List<String> names = jdbc.query("SELECT original_name FROM file_object WHERE id=? AND target_type='PRODUCTION_EXECUTION' AND target_id=?", (rs, i) -> rs.getString(1), fileId, objectId);
                if (names.isEmpty() || !names.get(0).equals(file.path("originalName").asText())) throw invalid("文件不属于当前生产对象或已不存在");
            }
        }
    }

    private JsonNode previousRow(JsonNode previous, JsonNode row, int index) {
        if (previous == null || !previous.isArray()) return com.fasterxml.jackson.databind.node.MissingNode.getInstance();
        String id = row.path("__rowId").asText();
        if (!id.isBlank()) for (JsonNode candidate : previous) if (id.equals(candidate.path("__rowId").asText())) return candidate;
        JsonNode legacy = previous.path(index);
        return legacy.isObject() && !legacy.has("__rowId") ? legacy : com.fasterxml.jackson.databind.node.MissingNode.getInstance();
    }

    public Set<String> resolve(JsonNode configured) {
        if (!configured.isArray() || configured.isEmpty()) return Set.of();
        List<SubjectReference> refs = new ArrayList<>();
        for (JsonNode item : configured) {
            try { refs.add(new SubjectReference(SubjectReference.SubjectType.valueOf(item.path("type").asText()), Long.valueOf(item.path("id").asText()),
                    "SELF_ONLY".equals(item.path("departmentScope").asText()) ? SubjectReference.DepartmentScope.SELF_ONLY : SubjectReference.DepartmentScope.SELF_AND_CHILDREN)); }
            catch (Exception e) { throw invalid("表单主体配置无法解析"); }
        }
        Set<String> result = new LinkedHashSet<>();
        subjects.resolve(subjectTenantId(), refs).users().forEach(user -> result.add(user.userId().toString()));
        return result;
    }

    private Long subjectTenantId() {
        // Reuse the authenticated operator's stored scope, not a configured subject or signer.
        String operator = AuditContext.getOperatorId();
        if (operator == null || operator.isBlank()) throw invalid("请先登录后解析表单主体");
        try {
            return users.findById(Long.valueOf(operator))
                    .map(UserAccount::getTenantId)
                    .orElseThrow(() -> invalid("无法确定当前用户的主体解析范围"));
        } catch (NumberFormatException error) {
            throw invalid("当前登录用户标识无效");
        }
    }

    public void captureApprovers(JsonNode node, ObjectNode formState) {
        if (!"APPROVAL".equals(node.path("data").path("kind").asText())) return;
        JsonNode configured = configuredSubjects(node.path("data").path("config"), "approverSubjects", "approvers");
        ObjectNode approvals = formState.withObject("/approvers");
        if (approvals.has(node.path("id").asText())) return;
        approvals.set(node.path("id").asText(), mapper.valueToTree(resolve(configured)));
        formState.withObject("/restrictedApprovers").put(node.path("id").asText(), configured.isArray() && !configured.isEmpty());
    }

    public boolean canAct(JsonNode form, JsonNode node, JsonNode state, String operator) {
        if (operator == null || operator.isBlank()) return false;
        if ("APPROVAL".equals(node.path("data").path("kind").asText())) {
            String assigned = state.path("transferAssignees").path(node.path("id").asText()).asText("");
            if (!assigned.isBlank()) return operator.equals(assigned);
            if (!state.path("restrictedApprovers").path(node.path("id").asText()).asBoolean()) return true;
            for (JsonNode id : state.path("approvers").path(node.path("id").asText())) if (operator.equals(id.asText())) return true;
            return false;
        }
        JsonNode groups = node.path("data").path("config").path("permissionGroupRules");
        if ((!groups.isArray() || groups.isEmpty()) && !node.path("data").path("config").path("permissionGroups").isEmpty()
                && node.path("data").path("config").has("permissionGroups")) throw invalid("旧版填报主体配置需要明确转换后才能执行");
        if (!groups.isArray() || groups.isEmpty()) return true;
        for (JsonNode group : groups) if (resolve(configuredSubjects(group, "subjects", "group")).contains(operator)) return true;
        return false;
    }

    public TenantTransferTargets.Page transferTargets(JsonNode form, JsonNode node, JsonNode state, String operator, String keyword, int page, int size) {
        if (!"APPROVAL".equals(node.path("data").path("kind").asText()) || !canAct(form, node, state, operator))
            throw invalid("当前用户无权转办此表单节点");
        try {
            return new TenantTransferTargets(users).search(transferTenantId(operator), operator, keyword, page, size);
        } catch (IllegalArgumentException error) { throw invalid(error.getMessage()); }
    }

    public UserAccount requireTransferTarget(JsonNode node, JsonNode state, String operator, String targetUserId) {
        try {
            return new TenantTransferTargets(users).require(transferTenantId(operator), operator, targetUserId);
        } catch (IllegalArgumentException error) { throw invalid(error.getMessage()); }
    }

    private Long transferTenantId(String operator) {
        try {
            return users.findById(Long.valueOf(operator)).map(UserAccount::getTenantId)
                    .orElseThrow(() -> invalid("无法确定转办的租户范围"));
        } catch (NumberFormatException error) { throw invalid("当前登录用户标识无效"); }
    }

    private boolean availableForTransfer(UserAccount user) {
        return "ACTIVE".equals(user.getStatus()) && (user.getLockedUntil() == null || !user.getLockedUntil().isAfter(LocalDateTime.now()));
    }

    public ObjectNode permissions(JsonNode form, JsonNode node, JsonNode state, String operator) {
        return permissions(form, node, state, operator, false);
    }

    public ObjectNode permissions(JsonNode form, JsonNode node, JsonNode state, String operator, boolean signing) {
        ObjectNode result = mapper.createObjectNode();
        boolean allowed = canAct(form, node, state, operator);
        JsonNode config = node.path("data").path("config");
        JsonNode groups = config.path("permissionGroupRules");
        List<JsonNode> matched = new ArrayList<>();
        if ("START".equals(node.path("data").path("kind").asText())) {
            for (JsonNode group : groups) if (resolve(configuredSubjects(group, "subjects", "group")).contains(operator)) matched.add(group);
        }
        for (JsonNode field : form.path("fields")) {
            String id = field.path("id").asText();
            boolean edit = allowed && (signing || !"signature".equals(field.path("type").asText())) && !field.path("readOnly").asBoolean()
                    && !"disabled".equals(field.path("status").asText());
            if (!matched.isEmpty()) {
                for (JsonNode group : matched) {
                    String key = "start:" + group.path("id").asText();
                    JsonNode override = form.path("binding").path("fieldPermissions").path(key);
                    edit &= editable(group, override, id);
                }
            } else {
                String key = "APPROVAL".equals(node.path("data").path("kind").asText()) ? "approval:" + node.path("id").asText() : "start:open";
                edit &= editable(config, form.path("binding").path("fieldPermissions").path(key), id);
            }
            result.put(id, edit ? "EDIT" : "READ_ONLY");
        }
        return result;
    }

    private boolean editable(JsonNode config, JsonNode override, String id) {
        boolean edit = !"READ_ONLY".equals(override.path("defaultPermission").asText(config.path("defaultPermission").asText("EDIT")));
        for (JsonNode field : override.path("editableFieldIds")) if (id.equals(field.asText())) edit = true;
        for (JsonNode field : override.path("readOnlyFieldIds")) if (id.equals(field.asText())) edit = false;
        return edit;
    }

    private JsonNode configuredSubjects(JsonNode config, String field, String legacy) {
        if (config.path(field).isArray()) return config.path(field);
        String value = config.path(legacy).asText("");
        if (value.isBlank()) return mapper.createArrayNode();
        try { JsonNode parsed = mapper.readTree(value); if (parsed.isArray()) return parsed; }
        catch (Exception ignored) { }
        throw invalid("旧版主体配置无法可靠解析，请先在表单流程中更新主体配置");
    }

    public record ButtonSigner(String id, String name, String account, String authMethod, String certificationId) { }

    public ButtonSigner authenticateButtonSigner(String account, String password) {
        if (AuditContext.getOperatorId() == null) throw invalid("请重新登录后签署");
        var user = users.findByUsername(account == null ? "" : account.strip())
                .filter(this::availableForTransfer).orElseThrow(() -> invalid("签署账户或密码不正确，或账户不可用"));
        String signerId = user.getId().toString();
        if ("admin".equals(user.getUsername())) {
            if (password == null || password.isBlank() || !passwords.matches(password, user.getPasswordHash()))
                throw invalid("签署账户或密码不正确，或账户不可用");
            return new ButtonSigner(signerId, user.getDisplayName(), user.getUsername(), "ADMIN_LOGIN_PASSWORD", null);
        }
        Signature certification = signatures.findFirstByTargetTypeAndTargetIdOrderBySignedAtDesc("USER_PROFILE", signerId)
                .orElseThrow(() -> invalid("签署账户尚未完成电子签名认证，请由本人登录后在个人设置中完成认证"));
        if (certification.getExpiresAt() != null && !certification.getExpiresAt().isAfter(LocalDateTime.now()))
            throw invalid("签署账户的电子签名已过期，请由本人登录后在个人设置中重新认证");
        if (certification.getSignaturePasswordHash() == null || certification.getSignaturePasswordHash().isBlank())
            throw invalid("签署账户尚未设置电子签名密码，请由本人登录后在个人设置中完成认证");
        if (password == null || password.isBlank() || !passwords.matches(password, certification.getSignaturePasswordHash()))
            throw invalid("电子签名密码错误");
        return new ButtonSigner(signerId, user.getDisplayName(), user.getUsername(), "SIGNATURE_PASSWORD", certification.getId().toString());
    }

    public String sign(String objectId, String formId, String action, JsonNode values, ButtonSigner signer) {
        return signTarget("PRODUCTION_EXECUTION", objectId, formId, action, values, signer);
    }

    public String signTarget(String targetType, String objectId, String formId, String action, JsonNode values, ButtonSigner signer) {
        String operator = AuditContext.getOperatorId();
        if (operator == null) throw invalid("请重新登录后签署");
        ObjectNode evidence = mapper.createObjectNode().put("objectId", objectId).put("formId", formId).put("action", action)
                .put("sessionOperatorId", operator).put("sessionOperatorName", AuditContext.getOperatorName())
                .put("sessionOperatorAccount", AuditContext.getOperatorAccount()).put("signerId", signer.id())
                .put("signerName", signer.name()).put("signerAccount", signer.account()).put("authMethod", signer.authMethod())
                .put("certificationId", signer.certificationId());
        evidence.set("values", values.deepCopy());
        try {
            String payload = mapper.writeValueAsString(evidence);
            String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(payload.getBytes(StandardCharsets.UTF_8)));
            long id = ids.nextId();
            signatures.save(Signature.builder().id(id).targetType(targetType).targetId(objectId)
                    .meaning(action + " · " + formId).signerId(signer.id()).signerName(signer.name())
                    .authMethod(signer.authMethod()).authEventRef(signer.certificationId())
                    .snapshotHash(hash).snapshotData(payload).signedAt(LocalDateTime.now()).build());
            return String.valueOf(id);
        } catch (Exception e) { throw invalid("签署记录保存失败"); }
    }

    public ObjectNode signField(ObjectNode evidence, String password) {
        String operator = AuditContext.getOperatorId();
        if (operator == null) throw invalid("请重新登录后签署");
        var user = users.findById(Long.valueOf(operator)).orElseThrow(() -> invalid("签署用户不存在"));
        if (!"ACTIVE".equals(user.getStatus()) || (user.getLockedUntil() != null && user.getLockedUntil().isAfter(LocalDateTime.now())))
            throw invalid("签署账户不可用");
        Signature certification = signatures.findFirstByTargetTypeAndTargetIdOrderBySignedAtDesc("USER_PROFILE", operator)
                .orElseThrow(() -> invalid("请先在个人设置中完成电子签名认证"));
        if (certification.getExpiresAt() != null && !certification.getExpiresAt().isAfter(LocalDateTime.now()))
            throw invalid("电子签名已过期，请先在个人设置中重新认证");
        if (password == null || password.isBlank() || certification.getSignaturePasswordHash() == null
                || !passwords.matches(password, certification.getSignaturePasswordHash())) throw invalid("电子签名密码错误");
        String fileId;
        JsonNode image;
        try { image = mapper.readTree(certification.getSnapshotData()).path("signatureImage"); fileId = image.path("fileId").asText(); }
        catch (Exception e) { throw invalid("电子签名图片不存在，请先在个人设置中重新认证"); }
        if (!fileId.matches("[0-9]+") || jdbc.queryForObject("SELECT COUNT(*) FROM file_object WHERE id=? AND mime_type LIKE 'image/%'", Integer.class, Long.valueOf(fileId)) == 0)
            throw invalid("电子签名图片不存在，请先在个人设置中重新认证");
        String signedAt = LocalDateTime.now().withNano(0).toString();
        String signatureId = String.valueOf(ids.nextId());
        ObjectNode presentation = mapper.createObjectNode().put("type", "signature").put("signatureId", signatureId)
                .put("signerId", operator).put("signerName", user.getDisplayName()).put("signedAt", signedAt)
                .put("signatureImageFileId", fileId).put("certificationId", certification.getId().toString());
        evidence.set("signature", presentation.deepCopy());
        evidence.set("signatureImage", image.deepCopy());
        evidence.put("certificationSnapshotHash", certification.getSnapshotHash());
        try {
            String payload = mapper.writeValueAsString(evidence);
            String hash = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(payload.getBytes(StandardCharsets.UTF_8)));
            signatures.save(Signature.builder().id(Long.valueOf(signatureId)).targetType("PRODUCTION_EXECUTION")
                    .targetId(evidence.path("objectId").asText()).meaning("SIGN_FIELD · " + evidence.path("fieldId").asText())
                    .signerId(operator).signerName(user.getDisplayName()).authMethod("SIGNATURE_PASSWORD")
                    .authEventRef(certification.getId().toString()).snapshotData(payload).snapshotHash(hash).signedAt(LocalDateTime.parse(signedAt)).build());
        } catch (Exception e) { throw invalid("签署记录保存失败"); }
        return presentation;
    }
}
