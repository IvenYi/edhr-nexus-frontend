from pathlib import Path
import collections, datetime, hashlib, json, re, subprocess

raw = Path(__file__).parent
phase = raw / 'final_ready'
repo = Path('/tmp/edhr-notification-qa-20261111')
candidate = '7b63b4c545490489e3e7df1d2009957e7e34cf63'
base = 'ea46c826f821ab2496a56df13fbcb0bd47e25eff'
def sha(data): return hashlib.sha256(data).hexdigest()
def command(args): return subprocess.check_output(args, cwd=repo, text=True).strip()

summary = json.loads((phase/'test-summary.json').read_text())
assert summary['totals'] == dict(tests=177, failures=0, errors=0, skipped=0)
assert not summary['missingFreshReports']
native = next(x for x in summary['classes'] if x['name'].endswith('RecordControlPostgresIntegrationTest'))
assert native['tests'] == 118
run = json.loads((phase/'run.json').read_text())
assert run['head'] == candidate and run['exitCode'] == 0
assert run['workingTreeStatus'] == '?? gmp-platform/frontend/node_modules'
assert len(run['sourceFingerprints']) == 52
for x in run['sourceFingerprints']:
    assert sha((repo/x['path']).read_bytes()) == x['sha256']
    assert sha((phase/'source'/x['path']).read_bytes()) == x['sha256']

observations=[]
for path in sorted((phase/'notification-observations').glob('*.json')):
    d=json.loads(path.read_text()); name=path.stem
    row=dict(name=name, bytes=path.stat().st_size, sha256=sha(path.read_bytes()))
    if name != 'pages-and-read':
        assert d['frozenBeforeSha256']==d['frozenAfterSha256']
        assert d['replayBeforeSha256']==d['replayAfterSha256']
        assert all(re.fullmatch('[a-f0-9]{64}',d[k]) for k in ['frozenBeforeSha256','frozenAfterSha256','replayBeforeSha256','replayAfterSha256'])
        row['frozenDigestPairEqual']=row['replayDigestPairEqual']=True
    actual=d['actualNotificationRows']; impacts=d['actualImpactRows']
    if name.startswith(('recipients-', 'identity-')):
        expected=d['recipients']
        assert sorted(x['recipient_id'] for x in actual)==expected
        assert len(impacts)==1 and impacts[0]['action']==d['businessType']
        assert len({x['id'] for x in impacts})==1
        assert all(x['impact_id']==impacts[0]['id'] for x in actual)
        assert all(x['summary_version_id']==int(d['versionId']) for x in impacts)
        assert all(x['read_at'] is None for x in actual)
        row.update(businessType=d['businessType'], recipients=expected)
    elif name.startswith('capacity-'):
        n=d['versions']; assert n in [1,10,100]
        assert d['impacts']==d['notifications']==len(impacts)==len(actual)==n
        assert len({x['summary_version_id'] for x in impacts})==n
        assert all(x['recipient_id']=='41' and x['read_at'] is None for x in actual)
        assert {x['impact_id'] for x in actual}=={x['id'] for x in impacts}
        assert d['realSourceMethodCalls']==1
        row.update(versions=n, elapsedNanos=d['elapsedNanos'], threadAllocatedBytes=d['threadAllocatedBytes'])
    else:
        assert name=='pages-and-read'
        ids=d['orderedIds']; assert len(ids)==len(set(ids))==d['total']==d['uniqueReachable']==100
        assert ids==sorted(ids,key=int,reverse=True)
        assert d['unreadAfterRead']==99 and d['readAtUnchanged'] and d['readAt']
        assert len([x for x in actual if x['read_at'] is not None])==1
        row.update(total=100, uniqueReachable=100, unreadAfterRead=99)
    observations.append(row)
assert len(observations)==20

http=[json.loads(line) for line in (phase/'http.jsonl').read_text().splitlines() if line]
new=[x for x in http if x['case'].startswith('notification-')]
assert len(new)==28
for x in http: assert x['actualStatus']==x['expectedStatus']
page_rows=[x for x in new if re.fullmatch('notification-page-[0-5]',x['case'])]
assert len(page_rows)==6
page_rows.sort(key=lambda x:int(x['case'].rsplit('-',1)[1]))
httpids=[]
for i,x in enumerate(page_rows):
    b=x['body']; b=json.loads(b) if isinstance(b,str) else b; d=b['data']
    assert d['total']==d['unreadCount']==100 and len(d['content'])==(20 if i<5 else 0)
    httpids.extend(row['id'] for row in d['content'])
assert httpids==json.loads((phase/'notification-observations/pages-and-read.json').read_text())['orderedIds']

text=(phase/'postgres.log').read_text()
records=re.split(r'(?m)(?=^\d{4}-\d\d-\d\d \d\d:\d\d:\d\d\.\d+ UTC \[)',text)
cost=[]; selected_plans=[]
for n in [1,10,100]:
    counts=collections.Counter(); plans=[]
    for r in records:
        line=r.splitlines()[0] if r else ''
        if f' notification-source-{n} ' not in line: continue
        m=re.search(r' execute [^:]+: ([\s\S]+)',r)
        if m:
            sql=m.group(1).strip()
            if sql.startswith('SELECT'): counts['select']+=1
            elif sql.startswith('INSERT INTO dhr_evidence_impact'): counts['impactUpsertReturning']+=1
            elif sql.startswith('INSERT INTO dhr_impact_notification'): counts['noticeInsert']+=1
            elif sql.startswith('SET LOCAL'): pass
            else: raise AssertionError(sql[:120])
        if ' plan:' in line:
            p=json.loads(r.split('plan:',1)[1].strip()); plans.append(p)
    assert counts==dict(select=n+1,impactUpsertReturning=n,noticeInsert=n)
    assert len(plans)==3*n+1
    def walk(node):
        yield node
        for child in node.get('Plans',[]): yield from walk(child)
    first=[p for p in plans if p['Query Text'].startswith('SELECT DISTINCT')]
    assert len(first)==1 and first[0]['Plan']['Actual Rows']==n
    nodes=[{k:node[k] for k in ['Node Type','Relation Name','Index Name','Actual Rows','Actual Loops','Rows Removed by Filter'] if k in node} for node in walk(first[0]['Plan'])]
    selected_plans.append(dict(versions=n,initialQuery=first[0]['Query Text'],parameters=first[0].get('Query Parameters'),nodes=nodes))
    ob=json.loads((phase/f'notification-observations/capacity-{n}.json').read_text())
    cost.append(dict(versions=n,**counts,sourceSqlStatements=sum(counts.values()),autoExplainPlans=len(plans),elapsedNanos=ob['elapsedNanos'],threadAllocatedBytes=ob['threadAllocatedBytes']))

knowledge=json.loads((raw/'knowledge/run.json').read_text())
assert knowledge['head']==candidate and knowledge['exitCode']==0
assert knowledge['workingTreeState']=='?? gmp-platform/frontend/node_modules\n'
assert len(knowledge['sourceFingerprints'])==359
assert json.loads((raw/'knowledge/test-summary.json').read_text())==dict(tests=89,failures=0,errors=0,skipped=0)
for x in knowledge['sourceFingerprints']: assert sha((repo/x['path']).read_bytes())==x['sha256']
assert command(['git','status','--porcelain'])==''
changed=command(['git','diff','--name-only',base,candidate]).splitlines();assert len(changed)==8
product=command(['git','diff','--name-only',base,candidate,'--','gmp-platform/backend/src/main','gmp-platform/frontend','AGENTS.md','codeplzreadme.md','docs/agents'])
assert product==''
result={'observedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':candidate,'base':base,'finalClean':True,
        'executionWorkingTreeStatus':run['workingTreeStatus'],'excludedDependencyPath':'gmp-platform/frontend/node_modules',
        'sourceInputsVerified':52,'knowledgeInputsVerified':359,'nativeTests':118,'totalRegressionTests':177,'knowledgeTests':89,
        'observationCount':len(observations),'observationRows':observations,'httpTotal':len(http),'httpNew':len(new),
        'newHttpStatuses':dict(collections.Counter(x['actualStatus'] for x in new)),'allHttpStatusesMatch':True,'sqlCosts':cost,
        'changedPaths':changed,'runtimeProductDelta':[],
        'qualifications':['Digest pairs and exact-content test assertions verified;raw pre/post table payload was not persisted separately,so this script does not independently recompute table hashes from original rows.',
          'Source phase counts only successful server execute;parse/bind/auto_explain not counted again;writes separate from SELECT.',
          'Capacity uses real frozen versions with no current DHR review;cost is original sourceEffective only,not complete approval or lock duration;allocated bytes cumulative calling thread,not peak/RSS/SLA.',
          '100 is a sample count of frozen versions/notifications,not a qualified-personnel cap;20 is page size;all100 verified reachable.',
          'No new UI/browser/full account-switch matrix;no production database/performance claims;existing remaining high/A12 and other audit stages remain.']}
(raw/'independent-recheck.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
(raw/'source-plans.json').write_text(json.dumps(selected_plans,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['observationRows','changedPaths','qualifications']},ensure_ascii=False,indent=2))
