from pathlib import Path
import hashlib
import json
import subprocess
import yaml
import runpy

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-dhr-notifications-ontology-20261111')
BASE = 'ea46c826f821ab2496a56df13fbcb0bd47e25eff'
FINAL = '7b63b4c545490489e3e7df1d2009957e7e34cf63'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def fingerprint(path):
    data = (ROOT/path).read_bytes()
    assert data == git('show', FINAL + ':' + path), path
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

head = git('rev-parse', 'HEAD').decode().strip()
assert head == FINAL, head
remote = git('ls-remote', 'origin', 'refs/heads/edhr-dev').decode().split()[0]
assert remote == BASE, remote
knowledge = sorted(str(p.relative_to(ROOT)) for p in (ROOT/'docs/knowledge').rglob('*') if p.is_file())
validation = knowledge + sorted(str(p.relative_to(ROOT)) for p in (ROOT/'gmp-platform/backend/src/test/java/com/zencas/edhr/knowledge').glob('*.java')) + ['gmp-platform/backend/pom.xml']
assert len(knowledge) == 353 and len(validation) == 359
governance = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md',
              'docs/agents/business-knowledge-modeler.md', 'docs/architecture/business-knowledge-model.md']
source = ['gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrImpactNotificationService.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrImpactNotificationController.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',
          'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrReviewService.java',
          'gmp-platform/backend/src/main/resources/db/changelog/0089-record-control-dhr-linkage.sql',
          'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java',
          'gmp-platform/backend/pom.xml',
          'docs/development/branch-review-20261111-dhr-impact-notifications/decision-package.yaml',
          'docs/reference-assets/research/crown-dhr-change-downstream-20261029/handoff.yaml']
inputs = [fingerprint(path) for path in validation]
extras = [fingerprint(path) for path in governance+source]
read = runpy.run_path(str(OUT/'build-finite-records.py'))['records_at']
before, after = read(BASE), read(FINAL)
status_changes = [{'id': rid, 'before': before[rid]['record'].get('status'), 'after': after[rid]['record'].get('status')}
                  for rid in sorted(before.keys() & after.keys()) if before[rid]['record'].get('status') != after[rid]['record'].get('status')]
assert status_changes == [{'id': 'discrepancy.dhr-review-effective-source-integration', 'before': 'open', 'after': 'resolved'}]
projection_changes = [rid for rid in sorted(before.keys() & after.keys())
                      if before[rid]['record'].get('visibility') != after[rid]['record'].get('visibility')]
assert not projection_changes, projection_changes
for record in after.values():
    for eid in record['record'].get('evidenceIds', []):
        assert eid in after, (record['id'], eid)
schema = yaml.safe_load((ROOT/'docs/knowledge/schema.yaml').read_text())
for record in after.values():
    obj = record['record']
    if record['recordType'] == 'evidence' and obj['type'] in schema['evidencePathPolicy']['mustExistForTypes']:
        assert (ROOT/obj['path']).is_file(), obj['path']
product_diff = git('diff', '--name-only', BASE, FINAL, '--', 'gmp-platform/backend/src/main',
                   'gmp-platform/frontend', 'tools/knowledge-model', 'AGENTS.md', 'docs/agents', 'docs/architecture').decode().splitlines()
assert not product_diff, product_diff
changed = git('diff', '--name-only', BASE, FINAL, '--', 'docs/knowledge').decode().splitlines()
assert len(changed) == 6, changed
subprocess.run(['git', 'diff', '--check', BASE, FINAL], cwd=ROOT, check=True)
data = {'sourceCommit': FINAL, 'targetBranch': 'edhr-dev', 'targetCommit': remote,
        'contractReadCommit': BASE, 'uncommittedContractPaths': [],
        'sourceAndKnowledgeMatchCommittedBytes': True, 'knowledgeFileCount': 353,
        'formalKnowledgeValidationInputCount': 359, 'knowledgeInputs': inputs,
        'governanceAndSourceInputs': extras, 'knowledgeChangedPaths': changed,
        'statusChanges': status_changes, 'projectionChanges': projection_changes,
        'productUiMigrationGovernanceDifferences': product_diff,
        'staticReferencesAndEvidencePaths': 'passed', 'diffWhitespace': 'passed',
        'allRuleFactDecisionMaturityAndProjectionUnchanged': True,
        'formalMavenExecutionNotPerformedByThisRole': True}
(OUT/'final-source-knowledge-binding.json').write_text(json.dumps(data, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({key: value for key,value in data.items() if key not in ['knowledgeInputs', 'governanceAndSourceInputs']}, ensure_ascii=False))
