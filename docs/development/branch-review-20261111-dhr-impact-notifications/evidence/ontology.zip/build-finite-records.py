from pathlib import Path
import hashlib
import json
import subprocess
import yaml

REPO = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-dhr-notifications-ontology-20261111')
BASE = 'ea46c826f821ab2496a56df13fbcb0bd47e25eff'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def records_at(commit):
    found = {}
    schema = yaml.safe_load(git('show', commit + ':docs/knowledge/schema.yaml'))
    for path in git('ls-tree', '-r', '--name-only', commit, 'docs/knowledge').decode().splitlines():
        if not path.endswith('.yaml') or path == 'docs/knowledge/schema.yaml':
            continue
        raw = git('show', commit + ':' + path)
        document = yaml.safe_load(raw)
        for collection, items in document.items():
            if collection == 'knowledgeModelVersion':
                continue
            queue = [(schema['collectionTypes'][collection], item) for item in items]
            while queue:
                kind, item = queue.pop(0)
                rid = item['id']
                assert rid not in found, rid
                found[rid] = {'id': rid, 'recordType': kind, 'path': path,
                              'fileSha256': hashlib.sha256(raw).hexdigest(),
                              'recordSha256': hashlib.sha256(json.dumps(item, ensure_ascii=False, sort_keys=True).encode()).hexdigest(),
                              'record': item}
                for nested, nested_kind in schema['nestedCollectionTypes'].items():
                    queue.extend((nested_kind, child) for child in item.get(nested, []))
    return found

def main():
    head = git('rev-parse', 'HEAD').decode().strip()
    before = records_at(BASE)
    after = records_at(head)
    mapping = [
        ('DEC-0068-04', 'consistent', 'retained', 'Real source effectiveness remains owned by record control, not pending application submission.'),
        ('DEC-0068-05', 'consistent', 'retained', 'Notification does not automatically return a DHR or authorize stale approval.'),
        ('DEC-0068-06', 'consistent', 'retained', 'Frozen version and old approval remain historical evidence; new review remains a human action.'),
        ('DEC-0068-08', 'consistent', 'retained', 'No new production or release transition is introduced by this test-only increment.'),
        ('DEC-0068-11', 'consistent', 'retained', 'Notification receipt does not grant task-specific frozen attachment access.'),
        ('DEC-0068-12', 'consistent', 'retained', 'Original in-app channel, actual account identities and current reviewer/version submitter recipients remain unchanged.'),
        ('DEC-0068-13', 'consistent', 'retained', 'Current pending record-control application still blocks DHR finalization; coexistence fixture is legacy stock only.'),
        ('DEC-0068-14', 'consistent', 'retained', 'Current DHR review still blocks a new record-control application; native gate regression is retained.'),
        ('scenario.dhr-effective-form-impact-in-app-recipients', 'consistent', 'updated', 'References actual CHANGE/OBSOLETE recipient and legacy identity matrix evidence, preserving scenario semantics.'),
        ('discrepancy.dhr-review-effective-source-integration', 'consistent', 'updated', 'Only the original three finite remaining combinations are resolved using actual native PostgreSQL proof.'),
        ('discrepancy.dhr-review-complete-evidence-impact-gap', 'evidence-gap', 'retained', 'Generic quality result, exception treatment and source-signature validity change interpretation remains open/high.'),
        ('rule.dhr-summary-block-stale-approval', 'evidence-gap', 'retained', 'The complete rule stays specified/internal; local notification proof does not resolve the separate automatic-interpretation gap.'),
        ('fact.dhr-summary.effective-evidence-change', 'evidence-gap', 'retained', 'The complete fact stays specified/not-available; finite notification proof is not all source-change interpretation.'),
        ('anchor.dhr-summary-stale-approval', 'evidence-gap', 'retained', 'Existing implementation anchor keeps its limited maturity; no invented runtime execution contract.'),
        ('DEC-0093-02', 'consistent', 'retained', 'Real signed managerial reassignment changes current responsibility only; original candidates are preserved separately.'),
        ('DEC-0093-03', 'consistent', 'retained', 'Responsibility change, signature and domain audit remain atomic; notification proof does not replace their original evidence.'),
        ('DEC-0087-08', 'consistent', 'updated', 'Current cross-domain summary reflects the now-proven combinations while preserving quality, release and A12 limits.'),
        ('evidence.dhr-filling-review-confirmed', 'consistent', 'retained', 'October 29 original user confirmation is source authority, distinct from competitor examples and later implementation.'),
        ('evidence.dhr-impact-notification-matrix-20261111', 'consistent', 'updated', 'One new code evidence index points to actual native matrix tests and dated implementation evidence.'),
        ('evidence.dhr-linkage-initial-quality-result', 'consistent', 'historical', 'Original failed quality result is retained at its original scope; later proof is not backdated.'),
        ('question.form-projection-trace-index-effective-scope', 'needs-decision', 'deferred', 'A12 invalidated/history view and controlled historical reconstruction remain outside this increment.'),
        ('question.multi-tenant-workflow-isolation', 'needs-decision', 'deferred', 'Same-tenant sample separation does not implement or close the full non-MVP multi-tenant workflow contract.'),
    ]
    common_sources = [
        'docs/reference-assets/research/crown-dhr-change-downstream-20261029/handoff.yaml#confirmedNotificationReply',
        'docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml',
        'docs/knowledge/evidence/dhr-filling-review-implementation.md#2026-11-11生效提醒剩余组合证据接续',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java#sourceEffective',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrImpactNotificationService.java#list/read',
        'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java',
    ]
    results = []
    for rid, conclusion, disposition, scope in mapping:
        item = after[rid]
        results.append({'id': rid, 'assetPath': item['path'], 'recordType': item['recordType'],
                        'sourceCommit': head, 'baselineCommit': BASE,
                        'contractBaseline': {'sourceCommit': head, 'targetBranch': 'edhr-dev', 'targetCommit': BASE,
                                             'contractReadCommit': BASE, 'uncommittedContractPaths': []},
                        'conclusion': conclusion, 'disposition': disposition, 'scope': scope,
                        'baselineRecordSha256': before.get(rid, {}).get('recordSha256'),
                        'candidateRecordSha256': item['recordSha256'],
                        'sourceReferences': common_sources})
    for path in ['docs/knowledge/README.md',
                 'docs/knowledge/evidence/dhr-filling-review-implementation.md',
                 'docs/knowledge/evidence/workflow-record-dhr-closure-20261102.md']:
        raw = git('show', head + ':' + path)
        results.append({'id': 'file:' + path, 'assetPath': path, 'recordType': 'file-without-id',
                        'sourceCommit': head, 'baselineCommit': BASE,
                        'contractBaseline': {'sourceCommit': head, 'targetBranch': 'edhr-dev', 'targetCommit': BASE,
                                             'contractReadCommit': BASE, 'uncommittedContractPaths': []},
                        'conclusion': 'consistent', 'disposition': 'updated',
                        'scope': 'Dated current evidence succession is explicit; old failures and former remaining ranges retain their historical time.' ,
                        'candidateFileSha256': hashlib.sha256(raw).hexdigest(), 'sourceReferences': common_sources})
    assert len(results) == len(set(x['id'] for x in results))
    with (OUT / 'finite-review-records.jsonl').open('w') as stream:
        for item in results:
            stream.write(json.dumps(item, ensure_ascii=False) + '\n')
    changed = sorted(rid for rid in before.keys() & after.keys() if before[rid]['recordSha256'] != after[rid]['recordSha256'])
    summary = {'baselineCommit': BASE, 'sourceCommit': head, 'baselineIdInventory': len(before),
               'candidateIdInventory': len(after), 'addedIds': sorted(after.keys() - before.keys()),
               'deletedIds': sorted(before.keys() - after.keys()), 'modifiedIdsIncludingParentDecisionRecords': changed,
               'finiteSemanticRecords': len(results), 'finiteIdRecords': len(mapping), 'finiteFileRecords': 3,
               'finiteConclusions': {c: sum(r['conclusion'] == c for r in results) for c in sorted(set(r['conclusion'] for r in results))},
               'inventoryIsNotSemanticCoverage': True, 'wholeBranchAuditCompleted': False,
               'knowledgeModelVersion': '0.3.25', 'schemaVersion': '1.2.0', 'roadmap': 'P0/in-progress'}
    (OUT/'finite-review-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(summary, ensure_ascii=False))

if __name__ == '__main__':
    main()
