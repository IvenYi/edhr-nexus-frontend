from pathlib import Path
import hashlib
import json
import shutil
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/edhr-nexus-frontend')
RAW = Path('/tmp/edhr-dhr-impact-notifications-20261111')
OUT = Path('/tmp/edhr-dhr-notifications-ontology-20261111')
FINAL = '7b63b4c545490489e3e7df1d2009957e7e34cf63'
binding = json.loads((OUT/'final-source-knowledge-binding.json').read_text())
review = {'sourceCommit': FINAL, 'evidenceExecutor': 'parent-main-agent',
          'ontologyRoleExecutedBusinessOrKnowledgeMaven': False, 'phases': []}

for phase, expected in [('final_candidate', 177), ('knowledge', 89)]:
    path = RAW/phase
    run = json.loads((path/'run.json').read_text())
    assert run['head'] == FINAL and run['exitCode'] == 0
    assert run.get('workingTreeStatus', run.get('workingTreeState')) == ''
    fingerprints = run['sourceFingerprints']
    assert len({f['path'] for f in fingerprints}) == len(fingerprints)
    for item in fingerprints:
        data = (ROOT/item['path']).read_bytes()
        if 'bytes' in item:
            assert len(data) == item['bytes']
        assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
    if phase == 'knowledge':
        assert {f['path']: f['sha256'] for f in fingerprints} == {f['path']: f['sha256'] for f in binding['knowledgeInputs']}
    xml = list(path.glob('TEST-*.xml'))
    suites = [ET.parse(p).getroot() for p in xml]
    totals = {key: sum(int(s.get(key)) for s in suites) for key in ['tests','failures','errors','skipped']}
    assert totals == {'tests': expected, 'failures': 0, 'errors': 0, 'skipped': 0}
    cases = [c for suite in suites for c in suite.iter('testcase')]
    assert len(cases) == expected
    assert not any(c.find('failure') is not None or c.find('error') is not None or c.find('skipped') is not None for c in cases)
    if phase == 'final_candidate':
        assert sum(c.get('name','').startswith('effectiveNotificationRecipientsFollowActualCurrentResponsibility(') for c in cases) == 8
        assert sum(c.get('name','').startswith('legacyNotificationIdentityUsesOnlyRecoverableAccounts(') for c in cases) == 8
        assert sum(c.get('name','').startswith('effectiveNotificationCostAndAllPersonalPagesUseRealFrozenVersions(') for c in cases) == 3
        native = next(s for s in suites if s.get('name','').endswith('RecordControlPostgresIntegrationTest'))
        assert int(native.get('tests')) == 118
    files = [path/'run.json', path/'test-summary.json', *xml]
    if phase == 'final_candidate':
        files += [path/'http.jsonl', *(path/'notification-observations').glob('*.json')]
    for src in files:
        target = OUT/'read-evidence'/phase/src.relative_to(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
    review['phases'].append({'name': phase, 'head': run['head'], 'workingTreeClean': True,
                              'command': run['command'], 'exitCode': 0, 'xmlCount': len(xml),
                              'fingerprintsVerified': len(fingerprints), 'totals': totals})

path = RAW/'final_candidate'
observations = sorted((path/'notification-observations').glob('*.json'))
assert len(observations) == 20
review['notificationObservations'] = []
for file in observations:
    item = json.loads(file.read_text())
    if 'frozenBeforeSha256' in item:
        assert item['frozenBeforeSha256'] == item['frozenAfterSha256']
        assert item['replayBeforeSha256'] == item['replayAfterSha256']
    if 'recipients' in item:
        actual = sorted(str(row['recipient_id']) for row in item['actualNotificationRows'])
        assert actual == sorted(item['recipients'])
        assert len(item['actualImpactRows']) == 1
    if file.name.startswith('capacity-'):
        assert item['versions'] == item['impacts'] == item['notifications']
        assert len(item['actualImpactRows']) == item['versions']
        assert len(item['actualNotificationRows']) == item['versions']
    if file.name == 'pages-and-read.json':
        assert item['total'] == item['uniqueReachable'] == 100
        assert item['unreadAfterRead'] == 99 and item['readAtUnchanged'] is True
        assert len(item['orderedIds']) == len(set(item['orderedIds'])) == 100
    review['notificationObservations'].append({'path': str(file), 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
http = [json.loads(line) for line in (path/'http.jsonl').read_text().splitlines()]
assert all(row['expectedStatus'] == row['actualStatus'] for row in http)
notice_http = [row for row in http if row['case'].startswith('notification-')]
for page in range(6):
    row = next(row for row in notice_http if row['case'] == 'notification-page-' + str(page))
    data = row['body']['data']
    assert data['total'] == 100 and len(data['content']) == (0 if page == 5 else 20)
assert next(row for row in notice_http if row['case'] == 'notification-anonymous')['actualStatus'] == 401
assert next(row for row in notice_http if row['case'] == 'notification-other-account')['body']['data']['total'] == 0
review['httpResponses'] = len(http)
review['notificationHttpResponses'] = len(notice_http)
review['allHttpExpectedStatusMatched'] = True
review['oldIntermediateFailuresAreNotFinalCandidateResults'] = True
(OUT/'final-evidence-review.json').write_text(json.dumps(review, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({'phases': review['phases'], 'httpResponses': len(http), 'notificationObservations': len(observations), 'outcome': 'passed'}, ensure_ascii=False))
