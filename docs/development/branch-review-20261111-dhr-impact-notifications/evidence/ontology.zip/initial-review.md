# DHR effective-source notification finite ontology review

Scope: `DEC-PACKAGE-DHR-IMPACT-NOTIFICATIONS-20261111`, read at `ea46c826f821ab2496a56df13fbcb0bd47e25eff`, target `edhr-dev` at the same commit; knowledge `0.3.25`, schema `1.2.0`, P0 in-progress. Baseline inventory has 353 knowledge files. Inventory is a denominator, not evidence that all files have passed semantic review. This is a finite audit increment, not a restarted whole-branch audit.

## Source and rationale

- **user-confirmed**: original `confirmedNotificationReply` in `docs/reference-assets/research/crown-dhr-change-downstream-20261029/handoff.yaml` selects in-app notices to the current reviewer(s) and the affected frozen version's submitter. `DEC-0068-12` preserves that exact scope. No historical approver or email requirement follows.
- **original-evidence**: `RecordControlService.applyResult` calls `sourceEffective` after real APPROVED source revision, trace and projection changes in the same transaction. Replaying the consumed event returns before generating further notifications. `sourceEffective` resolves real version submitter identity, follows current pending task responsibility and inserts de-duplicated impact/recipient records. It does not update frozen content or approval decisions.
- **original-evidence**: `DhrImpactNotificationService` applies the authenticated recipient to count/page/read queries. Twenty is a page size, not a total-recipient or total-inbox limit. Reading uses `COALESCE(read_at, CURRENT_TIMESTAMP)` and does not grant DHR or task permission. The controller requires authentication for GET and POST.
- **secondary-reference**: November 3 closure evidence and the existing DEC discrepancy describe earlier tested and untested scopes. They are useful indexes, but do not prove this batch's pending combinations have run.
- **inference**: testing the remaining combinations can resolve the existing implementation-evidence discrepancy; it does not introduce a new notification policy or justify promoting the complete DEC/rule/fact to verified/runtime.

## Bounded decisions

1. Signed DHR reassignment already changes current responsibility to the new target and preserves origin, under `DEC-0093-02/03`. Testing notices after that action is consistent with the old notification rule. Origin or historical participants are not extra recipients.
2. Multiple pending candidates can all be current reviewers. For unrestricted tasks, test the same-tenant normal qualified set actually selected by the current implementation. Do not turn engineering account filtering into an invented universal account-state policy. Frozen candidate deactivation does not itself authorize cancelling their notices.
3. For old versions, explicit submitted account, original review account and unique original SUBMIT auditor are identity sources. Names are not identity. When reliable sources cannot uniquely identify the submitter, leave that recipient unresolved rather than guess. Current reviewer notices remain independent of that missing identity.
4. Concurrent source application and DHR review is an explicitly labelled old-stock fixture. `DEC-0068-13/14` still prevent new coexistence through current entrypoints. Temporarily changing fixture status to construct a real frozen workflow cannot be presented as a supported normal product sequence.
5. Re-delivery must not create new notices or clear read state. Another user's mark-read must not affect the recipient; anonymous access must be rejected. Notices confer no source or task access.
6. More frozen versions and recipients naturally require persistence work. Quantify real SELECT/INSERT scaling and plans separately; do not silently introduce an optimization, a total-count cap or SLA claim.

No new business ambiguity found in the planned finite combinations. No repository knowledge file changed at this initial-review stage. Native runtime and independent-quality proof are still pending; this document is not a gate result.

## Minimum proposed knowledge sync after actual proof

- `docs/knowledge/decisions/DEC-0068-dhr-filling-review.yaml`: only the effective-source integration discrepancy, and precise current notification scenario evidence references if all remaining assertions are actually proven.
- `docs/knowledge/evidence/record-control-dhr-linkage.yaml`: append a current finite evidence index, preserving original historical evidence entries.
- `docs/knowledge/README.md`: current remaining-boundary synopsis.
- `docs/knowledge/evidence/dhr-filling-review-implementation.md`: append dated scope/provenance and original runtime references; preserve old failed/blocked text as historical.
- `docs/knowledge/evidence/workflow-record-dhr-closure-20261102.md`: update only the current remaining-range paragraph with explicit dated succession, retaining its old 32-test/12-step proof and limitations.

Keep the separate complete-quality/exception/source-signature change high, A12 history/rule reconstruction, full browser/permissions/account-switch/error matrices, full multi-tenant contract and unrelated audit items. Keep knowledge/schema versions, specified/internal statuses and P0 phase unchanged.
