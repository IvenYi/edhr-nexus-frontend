from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('/workspace/edhr-archive-async-qa-20261107')
out=Path('/tmp/edhr-archive-async-final-qa-source-20261107')
head='8fc765ddf566517c22487564e1bbbc9a0e435e9a'
base='764258b869567c0f7840f16ff1358ed5c2491f53'
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
paths=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/development/branch-review-20261107-dhr-archive-async/decision-package.yaml','docs/development/branch-review-20261107-dhr-archive-async/README.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncOwnershipTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java']
assert git('rev-parse','HEAD').decode().strip()==head
for path in paths:
    data=git('show',head+':'+path)
    assert (root/path).read_bytes()==data
    dest=out/'source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
(out/'candidate.diff').write_bytes(git('diff',base,head,'--','gmp-platform/backend'))
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md']
for path in contracts:assert git('show',head+':'+path)==git('show',base+':'+path)
result={'taskStatus':'completed','finality':'FINAL','role':'read-only final-QA source child, not aggregate final quality','sourceCommit':head,'baseCommit':base,'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev').decode().strip(),'contractReadCommit':head,'uncommittedContractPaths':[],'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','stage':'P0 / in-progress','checks':{'candidateSourcesByteIdentical':len(paths),'contractsUnchangedFromBase':len(contracts),'productChangedFiles':['DhrArchiveController.java'],'oldSixStreamAssertionsPreserved':True,'directInstalledSpringJavap':True,'A23':'request-local CAS and local cleanup helper justified by actual lifecycle race; no generic framework','businessPolicyChanged':False},'findings':[],'residualRisks':['pre-listener/startAsync/framework setup failures','actual active-body network cancellation/timeout unverified','Error/OOM/crash/disk failure/UNKNOWN/persistent reconciliation/capacity not closed'],'executed':{'applicationTests':False,'knowledgeTests':False,'postgres':False,'browser':False,'CI':False,'repositoryMutation':False},'workingTreeObservation':git('status','--porcelain').decode().strip(),'excludedPaths':['gmp-platform/frontend/node_modules (parent QA dependency symlink)'],'wholeFilesCompleted':0,'historicalUnique':'unknown','children':[],'completedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
entries=[dict(path=str(p.relative_to(out)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
(out/'manifest.json').write_text(json.dumps({'files':entries},ensure_ascii=False,indent=2)+'\n')
sha=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(sha+'  manifest.json\n')
print(len(entries),sha)
