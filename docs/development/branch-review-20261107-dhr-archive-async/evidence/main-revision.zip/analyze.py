from pathlib import Path
import shutil
old=Path(__file__).with_name('analysis-template.py').read_text()
old=old.replace("raw=Path('/tmp/edhr-archive-async-20261107')", "raw=Path('/tmp/edhr-archive-async-revision-20261107')")
old=old.replace("['negative','negative_context','final']", "['negative_context','final']")
old=old.replace("out['initialNegativeContextNote']='Initial five cases ran before adding a test-only profile to isolate nested config from later full-app PG context. Both old runs retained (2 positive/3 file-leak assertion failures each); latest negative_context is byte-identical to final.'", "out['fixtureRevision']='Original main95 and first independent94/95 kept separately. First QA exposed default lazy header writer race in synthetic Basic chain; latest fixture explicitly uses eager headers ONLY in that isolated chain. Product SecurityConfig and every original assertion unchanged. Latest same-byte baseline negative_context still has exactly three file-leak assertion failures. Product shared lazy-header risk remains separately open, not fixed by fixture isolation.'")
dest=Path('/workspace/edhr-nexus-frontend/docs/development/branch-review-20261107-dhr-archive-async')
shutil.copy2(Path('/tmp/edhr-archive-async-20261107/analysis.json'), dest/'initial-main-analysis.json')
exec(compile(old,'original-analysis-adapted-for-fixture-revision','exec'))
