from pathlib import Path
import subprocess,json,hashlib,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-async-history-20261107');out.mkdir(parents=True,exist_ok=True)
base='764258b869567c0f7840f16ff1358ed5c2491f53'
paths=[
'AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/knowledge/schema.yaml',
'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java',
'docs/development/branch-review-20261105-dhr-export/README.md',
'docs/development/branch-review-20261105-dhr-export/review-notes.md',
'docs/development/branch-review-20261105-dhr-export/scope-review.md',
'docs/development/branch-review-20261105-dhr-export/quality-result.yaml',
'docs/development/branch-review-20261106-dhr-archive-cleanup/README.md',
'docs/development/branch-review-20261106-dhr-archive-cleanup/findings.md',
'docs/development/branch-review-20261106-dhr-archive-cleanup/source-review.md',
'docs/development/branch-review-20261106-dhr-archive-cleanup/pre-pr-drift-review.md',
'docs/development/branch-review-20261106-dhr-archive-cleanup/quality-result.yaml',
'docs/development/branch-review-20261106-dhr-archive-cleanup/independent-review.md',
'docs/development/branch-review-20261106-dhr-archive-cleanup/decision-package.yaml',
'docs/development/branch-review-20261106-dhr-archive-cleanup/ontology-review.md',
'docs/development/branch-review-20261015/NEXT.md']
manifest=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=root);p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 manifest.append({'path':path,'sourceCommit':base,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
dp='docs/development/branch-review-20261107-dhr-archive-async/decision-package.yaml';b=(root/dp).read_bytes();(out/'working-decision-package.yaml').write_bytes(b)
searches=[
 ['git','grep','-n','-I','-E','StreamingResponseBody|TaskRejectedException|CallableProcessingInterceptor|未开始.*ZIP|ZIP.*未开始|未启动.*(ZIP|流)|异步.*(导出|清理)',base,'--',':(glob)docs/development/**/*.md',':(glob)docs/development/**/*.yaml'],
 ['git','grep','-n','-I','-E','未开始|未启动|异步|Files\\.size|UNKNOWN|拒绝|超时|afterCompletion|StreamingResponseBody',base,'--','docs/development/branch-review-20261105-dhr-export','docs/development/branch-review-20261106-dhr-archive-cleanup']]
results=[]
for i,args in enumerate(searches,1):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);(out/f'search-{i}.txt').write_text(p.stdout+p.stderr)
 results.append({'command':args,'exitCode':p.returncode,'matchLines':len(p.stdout.splitlines()),'evidence':f'search-{i}.txt'})
(out/'search-results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n')
(out/'baseline.json').write_text(json.dumps({'sourceCommit':base,'targetBranch':'edhr-dev','contractReadCommit':base,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','capturedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workingDecisionPackage':{'path':dp,'source':'working-tree-uncommitted','sha256':hashlib.sha256(b).hexdigest()},'execution':'read-only fixed-Git source/history searches; no application, HTTP, PG, browser or CI'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'fixedSources':len(manifest),'searches':results},ensure_ascii=False,indent=2))
