package org.springframework.web.context.request.async;
import java.util.*;
import java.util.concurrent.*;
import java.io.IOException;
import org.springframework.web.context.request.NativeWebRequest;

/** Actual installed dependency micro-probe only: no application, request, servlet or database execution. */
public class CompletionChainProbe {
    public static void main(String[] args) {
        Callable<Void> task=()->null; List<String> events=new ArrayList<>();
        var hook=new CallableProcessingInterceptor(){
            @Override public <T> void preProcess(NativeWebRequest r,Callable<T> t){events.add("preProcess");}
            @Override public <T> void afterCompletion(NativeWebRequest r,Callable<T> t){events.add("afterCompletion");}
        };
        new CallableInterceptorChain(List.of(hook)).triggerAfterCompletion(null,task);
        if(!events.equals(List.of("afterCompletion")))throw new AssertionError(events);
        System.out.println("{\"case\":\"completion-without-preprocess\",\"afterCompletion\":1,\"preProcess\":0,\"passed\":true}");

        events.clear(); var bad=new CallableProcessingInterceptor(){
            @Override public <T> void afterCompletion(NativeWebRequest r,Callable<T> t)throws Exception {events.add("cleanup-fault");throw new IOException("fixture");}
        };
        new CallableInterceptorChain(List.of(hook,bad)).triggerAfterCompletion(null,task);
        if(!events.equals(List.of("cleanup-fault","afterCompletion")))throw new AssertionError(events);
        System.out.println("{\"case\":\"completion-exception-swallowed-and-chain-continues\",\"returnedNormally\":true,\"passed\":true}");

        events.clear(); var future=new FutureTask<Void>(task);var chain=new CallableInterceptorChain(List.of(hook));chain.setTaskFuture(future);
        Object result=chain.triggerAfterTimeout(null,task);
        if(!future.isCancelled()||result!=CallableProcessingInterceptor.RESULT_NONE)throw new AssertionError();
        chain.triggerAfterCompletion(null,task);
        if(!events.equals(List.of("afterCompletion")))throw new AssertionError(events);
        System.out.println("{\"case\":\"timeout-cancels-queued-future-completion-still-invoked\",\"cancelled\":true,\"passed\":true}");
    }
}
