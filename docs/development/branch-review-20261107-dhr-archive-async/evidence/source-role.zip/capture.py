from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-async-source-20261107');base='764258b869567c0f7840f16ff1358ed5c2491f53'
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/schema.yaml','docs/knowledge/open-questions.yaml','docs/architecture/business-knowledge-model.md','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/rules/dhr-summary.yaml','gmp-platform/backend/pom.xml','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/resources/application.yml','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrArchiveCleanupFailureTest.java','docs/development/branch-review-20261106-dhr-archive-cleanup/README.md','docs/development/branch-review-20261106-dhr-archive-cleanup/findings.md','docs/development/branch-review-20261106-dhr-archive-cleanup/quality-result.yaml']
m=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=root);p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);m.append({'path':path,'source':'fixed-git:'+base,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
dp='docs/development/branch-review-20261107-dhr-archive-async/decision-package.yaml';b=(root/dp).read_bytes();p=out/'working-context'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);m.append({'path':dp,'source':'working-tree-read-context-only','bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'source-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
jars=[]
for artifact in ['spring-web','spring-webmvc','spring-core','spring-jcl']:
 p=Path('/workspace/.pr6-m2/org/springframework')/artifact/'6.1.8'/(artifact+'-6.1.8.jar');jars.append({'artifact':artifact,'version':'6.1.8','path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'dependency-evidence.json').write_text(json.dumps(jars,indent=2)+'\n')
searches=[]
for args in [['rg','-n','CallableProcessingInterceptor|AsyncListener|configureAsyncSupport|TaskExecutor|async.request-timeout|async-supported','gmp-platform/backend/src/main'],['rg','-n','knowledgeModelVersion|schemaVersion','docs/knowledge/schema.yaml']]:
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);searches.append({'command':args,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
(out/'search-results.json').write_text(json.dumps(searches,ensure_ascii=False,indent=2)+'\n')
(out/'baseline.json').write_text(json.dumps({'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':subprocess.check_output(['git','rev-parse','origin/edhr-dev'],cwd=root,text=True).strip(),'contractReadCommit':base,'knowledgeVersion':'0.3.25','schemaVersion':'1.2.0','knowledgeStage':'P0 / in-progress','workingTreeAtCapture':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True),'capturedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Fixed Git source and installed dependency static inspection; separate 3 dependency microprobes only; no application/HTTP/PG/browser/CI execution'},ensure_ascii=False,indent=2)+'\n')
child=Path('/tmp/edhr-archive-async-history-20261107');dest=out/'history-role';shutil.copytree(child,dest,dirs_exist_ok=True)
print('fixed sources',len(paths),'working contexts',1,'jars',len(jars),'history files',len([p for p in dest.rglob('*') if p.is_file()]))
