from pathlib import Path
import json,hashlib,subprocess,re,socket,shutil,datetime,xml.etree.ElementTree as ET,zipfile
root=Path('/workspace/edhr-archive-async-qa-v2-20261107')
raw=Path('/tmp/edhr-archive-async-final-qa-v2-20261107')
main=Path('/tmp/edhr-archive-async-revision-20261107')
base='764258b869567c0f7840f16ff1358ed5c2491f53'
head='7b68eabc6f9c8d7d00863285f9dd79e75a86a4a2'
def git(*args):return subprocess.check_output(['git',*args],cwd=root).decode().strip()
def sha(data):return hashlib.sha256(data).hexdigest()
assert git('rev-parse','HEAD')==head and git('rev-parse','origin/edhr-dev')==base
assert git('status','--porcelain') in ('','?? gmp-platform/frontend/node_modules')
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
summary={'base':base,'head':head,'trackedWorkingTreeClean':True,'testRunExcludedUntrackedPaths':['gmp-platform/frontend/node_modules'],'checks':{}}
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md']
for path in contracts:
    assert git('rev-parse',base+':'+path)==git('rev-parse',head+':'+path)
summary['contractBaselinesIdentical']=contracts
knowledge=sorted(git('ls-tree','-r','--name-only',head,'docs/knowledge').splitlines())
assert len(knowledge)==350
assert not git('diff','--name-only',base,head,'--','docs/knowledge','docs/architecture/business-knowledge-model.md')
summary['knowledgeFilesUnchanged']=len(knowledge)
delta=git('diff','--name-only',base,head).splitlines()
assert [x for x in delta if '/src/main/' in x]==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']
summary['deltaFiles']=delta
evidence=root/'docs/development/branch-review-20261107-dhr-archive-async/evidence'
archive_checks=[]
for label in ['main','source-role','main-revision','quality-initial-failed','ontology','header-source']:
    descriptor=json.loads((evidence/(label+'-archive.json')).read_text())
    manifest=json.loads((evidence/(label+'-manifest.json')).read_text())
    blob=evidence/(label+'.zip')
    assert sha(blob.read_bytes())==descriptor['sha256']
    assert sha((evidence/(label+'-manifest.json')).read_bytes())==descriptor['manifestSHA256']
    with zipfile.ZipFile(blob) as z:
        assert z.testzip() is None and len(z.namelist())==descriptor['members']==len(manifest['files'])
        for item in manifest['files']:assert sha(z.read(item['path']))==item['sha256']
    archive_checks.append(dict(label=label,members=descriptor['members'],verified=True))
summary['archives']=archive_checks
controller='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java'
http='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java'
negative=[]
for phase in ['negative_context']:
    p=main/phase
    t=json.loads((p/'test-summary.json').read_text())['totals']
    assert t==dict(tests=5,failures=3,errors=0,skipped=0)
    failures=list(ET.parse(next(p.glob('TEST-*DhrArchiveAsyncLifecycleTest.xml'))).getroot().iter('failure'))
    assert len(failures)==3
    for f in failures:
        assert 'Assertion' in f.attrib['type'] and 'completed request must release' in f.attrib.get('message','')
        assert 'not to exist within 5 seconds' in f.text
    assert (p/'source'/controller).read_bytes()==subprocess.check_output(['git','show',base+':'+controller],cwd=root)
    for name in ['rejected','queued-timeout','client-cancelled']:
        case=json.loads((p/'http'/(name+'.json')).read_text())
        assert case['started']==0 and case['ownedExistsBeforeFixtureTeardown']
    negative.append(dict(phase=phase,totals=t,trueFileLeakAssertions=3))
assert (main/'negative_context/source'/http).read_bytes()==(root/http).read_bytes()
summary['negativeControls']=negative
summary['latestNegativeHTTPSourceMatchesCandidate']=True
for item in json.loads((main/'final/run.json').read_text())['sourceFingerprints']:
    assert sha((root/item['path']).read_bytes())==item['sha256']
summary['mainFinalInputHashesVerified']=21
final=raw/'final'
run=json.loads((final/'run.json').read_text())
assert run['head']==head and run['status']=='?? gmp-platform/frontend/node_modules' and run['exitCode']==0
total=dict(tests=0,failures=0,errors=0,skipped=0)
classes=[]
for file in final.glob('TEST-*.xml'):
    node=ET.parse(file).getroot();a=node.attrib
    values={key:int(a.get(key,0)) for key in total}
    for key in total:total[key]+=values[key]
    classes.append(dict(name=a['name'],**values))
assert total==dict(tests=95,failures=0,errors=0,skipped=0) and len(classes)==10
assert not json.loads((final/'test-summary.json').read_text())['missingFreshReports']
summary['actualIndependentTests']=dict(totals=total,classes=classes)
for item in run['sourceFingerprints']:
    assert sha((root/item['path']).read_bytes())==item['sha256']
assert len(run['sourceFingerprints'])==21
summary['independentInputHashesVerified']=21
cases={f.stem:json.loads(f.read_text()) for f in (final/'http').glob('*.json')}
assert len(cases)==5
for name in ['normal','rejected','queued-timeout','client-cancelled','forbidden']:
    assert not cases[name]['ownedExistsBeforeFixtureTeardown']
for name in ['rejected','queued-timeout','client-cancelled']:assert cases[name]['started']==0 and cases[name]['submitted']==1
assert cases['normal']['httpStatus']==200 and cases['normal']['started']==1 and cases['normal']['submitted']==1
assert cases['rejected']['httpStatus']==500 and cases['queued-timeout']['httpStatus']==503
assert cases['forbidden']['httpStatus']==403 and cases['forbidden']['submitted']==0
summary['realIsolatedHTTP']=cases
normal_xml=ET.parse(next(final.glob('TEST-*DhrArchiveAsyncLifecycleTest.xml'))).getroot()
assert not [item for item in normal_xml.findall('testcase') if item.find('failure') is not None]
assert 'ArrayIndexOutOfBoundsException' not in (final/'maven.log').read_text()
summary['normalHTTPPositiveControl']={'actualStatus':200,'bytes':cases['normal']['responseBytes'],'submitted':1,'started':1,'noMimeHeadersArrayFailureInLog':True,'scope':'Synthetic Basic+eager chain only; product default-lazy header risk remains open, not repaired by test isolation'}
observations=[json.loads(line) for line in (final/'observations/observations.jsonl').read_text().splitlines()]
assert len(observations)==11 and sum(item['selectStatements'] for item in observations)==33
summary['nativeObservations']=dict(events=11,callingThreadSELECTs=33,allNetworkOrPerServerWindowClaim=False)
shutil.copy2(main/'ReadExportJfr.java',raw/'ReadExportJfr.java')
cmd=['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(raw/'ReadExportJfr.java'),str(final/'observations'),str(final/'vm-tmp')]
result=subprocess.run(cmd,text=True,capture_output=True,check=True)
(raw/'jfr-recalculation.tsv').write_text(result.stdout)
(raw/'jfr-recalculation.stderr').write_text(result.stderr)
by_name={item['name']:item for item in observations}
jfr=[]
for line in result.stdout.splitlines():
    name,b,n,paths=line.split('\t');name=name.removesuffix('.jfr');obs=by_name[name]
    assert int(b)==obs['trackedLogicalReadBytes'] and int(n)==obs['trackedReadEvents'] and int(paths)<=1
    jfr.append(dict(name=name,bytes=int(b),events=int(n)))
assert len(jfr)==11
summary['independentlyRecomputedJFR']=jfr
sql=(final/'postgres.log').read_text().splitlines()
audit=[]
for i,line in enumerate(sql):
    if not re.search(r'execute [^:]+: insert into audit_event ',line):continue
    assert 'parameters:' in sql[i+1]
    pairs=re.findall(r"\$(\d+) = (NULL|'(?:[^']|'')*')(?=, \$|$)",sql[i+1])
    values={int(k):None if v=='NULL' else v[1:-1].replace("''", "'") for k,v in pairs}
    assert len(values)==20 and values[1]=='EXPORT' and values[17]=='audit-event-v2'
    after=json.loads(values[2]);assert set(after)=={'dhrId','scope','versionId','archiveSha256'} and after['scope']=='FULL'
    created=values[4].replace(' ','T')
    if '.' not in created:created+='.'
    created=created.ljust(26,'0')
    payload=['audit-event-v2',values[20],values[19],values[7],values[6],values[1],None,[dict(sorted(after.items()))],values[13],values[14],values[12],values[18],values[11],values[10],values[8],values[5],values[15],values[9],created]
    computed=sha(json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode())
    assert computed==values[16],(computed,values[16])
    audit.append(dict(id=values[20],version=values[17],snapshotHash=values[16],archiveSha256=after['archiveSha256'],recomputedFromServerParameters=True))
assert len(audit)==3
summary['actualServerEXPORTBindings']=audit
assert json.loads((final/'cleanup.json').read_text())['removed']
assert not json.loads((final/'temporary-archives.json').read_text())['leftovers']
ports=sorted(set(map(int,re.findall(r'Tomcat started on port (\d+)',(final/'maven.log').read_text()))))
assert len(ports)==1
for port in ports:
    with socket.socket() as s:s.settimeout(.5);assert s.connect_ex(('127.0.0.1',port))!=0
summary['ownedResourceCleanup']=dict(removedContainer=json.loads((final/'cleanup.json').read_text())['ownedContainer'],closedHTTPPorts=ports,temporaryZIPLeftovers=[])
knowledge_xml=root/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
shutil.copy2(knowledge_xml,raw/'knowledge'/knowledge_xml.name)
kt=ET.parse(knowledge_xml).getroot().attrib
assert {k:int(kt[k]) for k in ['tests','failures','errors','skipped']}==dict(tests=89,failures=0,errors=0,skipped=0)
summary['actualIndependentKnowledge']=dict(tests=89,failures=0,errors=0,skipped=0)
summary['completedAtUTC']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(raw/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(actualTests=total,knowledge=89,negative=negative,verifiedArchives=archive_checks,independentJFR=11,serverEXPORT=3,resources=summary['ownedResourceCleanup']),indent=2))
