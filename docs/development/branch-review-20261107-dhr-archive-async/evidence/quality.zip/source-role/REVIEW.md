# 最终 QA v2 源码子审

正式 **completed / FINAL**，未发现本切片新增的阻断缺陷；无子任务。固定候选 `7b68eabc6f9c8d7d00863285f9dd79e75a86a4a2`，base/目标 `764258b869567c0f7840f16ff1358ed5c2491f53`，项目、质量角色及交接契约按候选读取。知识基线0.3.25/schema1.2.0/P0 in-progress。本角色只读取固定Git、原始测试产物及安装依赖字节码，没有修改仓库，也没有实际运行HTTP、PG、知识89或最终95；执行由父QA单列。

## 已实际核对

- 唯一产品差异为DhrArchiveController。Service、SecurityConfig、FileController及知识/架构/项目和角色契约Git字节不变，20份固定源码/报告已捕获SHA。
- Controller生成成功后才接管自有ZIP；一个AtomicBoolean由body入口和完成回调竞争。body先取得归属继续原TWR，completion不提前删；completion先取得则删除，latebody抛IOException。删除失败后归属不释放，避免后续误读或重复删除同路径替代物。
- `Files.size`/响应构造同步失败在catch内按同一归属清理，重新抛同一failure；删除错误附加suppressed和ERROR路径日志。完成回调删失败只记录，并不声称已回收或改变已结束HTTP结果。
- Spring6.1.8 `CallableInterceptorChain.triggerAfterCompletion`从全部interceptor尾部倒序执行，不使用preProcessIndex，单项Throwable仅TRACE吞掉；本角色实际javap三类并保留输出。`WebAsyncManager`启动后submit/timeout路径与当前hook适用范围相符，监听器建立前的异常仍保留缺口。
- 原六项stream测试可机械归一化掉新ServletWebRequest的import、helper及四处参数后，与目标旧源完整逐字节相等。新HTTP测试在8fc765→7b68eabc仅加eager装配和必要import/注释，全部assertion/verify/Awaitility行逐字节保持，包括normal启动一次。
- 最新negative_context与final的HTTP测试源码和候选逐字节相同；旧controller匹配目标Git。独立解析旧XML为5项2正/3真实文件遗留Assertion失败、0errors/skipped。最新主侧21输入均绑定候选Git字节。首轮依赖缺失是0JUnit构建错误，不能混入产品红。

## 响应头风险及隔离边界

初版独立QA在8fc765实际94/95，normal200/164字节、started2的失败证据仍完整保留；本角色读取其原始XML/JSON，不以主测绿覆盖。默认lazy HeaderWriterFilter被servlet finally及worker commit共同触发的依赖机制与原始堆栈相容；“客户端自动重试”仍只是推断，没有协议trace，不能归因250ms超时或CAS新增缺陷。

候选只在独立Basic夹具启用eager，产品JWT安全配置不变。实际Security6.3.0字节码表明eager先写头再chain，不创建原lazy响应包装器；它消除该包装器两个写入口的干扰。现有FileController:227和:269为真实private,max-age=300响应；全局eager可能留下Pragma/Expires或改变304/reset边界，因此夹具改动不能被称作产品header风险修复。

本切片以明确隔离安全装配验证ZIP请求归属，仍保留真实Tomcat、MVC、方法权限和严格旧断言，这不属于降低ZIP验收标准。产品JWT响应头竞争是已明确登记且与本产品差异分离的open风险，应下一专项用真实产品安全链复现并保留预览缓存后再选方案。父QA仍须实际新95全部通过，且不得把该结果解释为产品JWT/缓存/全HTTP链已经验收。

## 业务、A23及抽取判断

rule.dhr-summary-zip-source-trace、DEC0063的冻结版本/源/hash/按权导出以及DEC0090临时导出与受控归档的区分均未变化；EXPORT仍流前保存，不能回滚已发状态/字节。不存在历史恢复、自动归档、未知孤儿扫描或新超时/重试政策。

CAS对应真实资源竞争，清理小方法复用同步与完成两处，未引入跨请求缓存、无限重试、空ZIP兜底或大框架。新产品Controller无SQL，Service不变，不将相邻11观察/33SELECT当全系统N+1关闭。review-notes具体给出writeFrozenRecords、writeFrozenSummaryAttachments、appendTraceManifest及验证边界，是可实施的后续抽取方案；本次没有以行数或方法清单冒充重构已完成。

## 保留范围

真实网络活动body超时/取消、pre-listener/startAsync外部异常、Error/OOM/crash/磁盘失效/UNKNOWN及持久对账、PDF/上传/Office容量和原W2-W7/A23复查/931知识/86UI/A12/高风险/完整矩阵/用户暂停队列继续。手动回调5项不是活动网络取消证明；Basic/mock Service不等于产品JWT/PG/PDF全链。取消调用accepted不等于future.isCancelled或即时服务器取消。wholeFileCompleted=0、historicalUnique=unknown。本角色不将只读源码核对当最终质量passed。
