from pathlib import Path
import subprocess,json,hashlib,xml.etree.ElementTree as ET,datetime,re
r=Path('/workspace/edhr-nexus-frontend');o=Path('/tmp/edhr-archive-async-qa-v2-source-20261107');o.mkdir(exist_ok=True)
base='764258b869567c0f7840f16ff1358ed5c2491f53';head='7b68eabc6f9c8d7d00863285f9dd79e75a86a4a2'
def git(*a):return subprocess.check_output(['git',*a],cwd=r)
def fixed(path,rev=head):return git('show',rev+':'+path)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/rules/dhr-summary.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncOwnershipTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java','docs/development/branch-review-20261107-dhr-archive-async/decision-package.yaml','docs/development/branch-review-20261107-dhr-archive-async/README.md','docs/development/branch-review-20261107-dhr-archive-async/review-notes.md','docs/development/branch-review-20261107-dhr-archive-async/header-source-review.md','docs/development/branch-review-20261107-dhr-archive-async/quality-initial-failed.yaml']
finger=[]
for p in paths:
 b=fixed(p);d=o/'source'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);finger.append(dict(path=p,bytes=len(b),sha256=sha(b)))
changed=git('diff','--name-only',base,head,'--','gmp-platform/backend/src/main').decode().splitlines()
assert changed==['gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']
for p in [paths[9],paths[10],paths[11]]:assert fixed(p)==fixed(p,base)
assert not git('diff',base,head,'--','docs/knowledge','docs/architecture/business-knowledge-model.md','AGENTS.md','docs/agents','codeplzreadme.md')
stream=paths[14];original=fixed(stream,base).decode();new=fixed(stream).decode()
for imp in ['import org.springframework.mock.web.MockHttpServletRequest;\n','import org.springframework.mock.web.MockHttpServletResponse;\n','import org.springframework.web.context.request.ServletWebRequest;\n']:new=new.replace(imp,'')
new=new.replace(', request()', '').replace(',request()', '')
new=new.replace('    private ServletWebRequest request(){return new ServletWebRequest(new MockHttpServletRequest(),new MockHttpServletResponse());}\n\n','')
assert new==original,'stream test changed beyond request context'
http=paths[12];before=fixed(http,'8fc765ddf566517c22487564e1bbbc9a0e435e9a').decode();after=fixed(http).decode()
def assertions(s):return [x.strip() for x in s.splitlines() if any(y in x for y in ['assertThat','verifyNoInteractions','untilAsserted','Awaitility.await'])]
assert assertions(before)==assertions(after)
revision=Path('/tmp/edhr-archive-async-revision-20261107');neg=revision/'negative_context';final=revision/'final'
assert (neg/'source'/http).read_bytes()==(final/'source'/http).read_bytes()==fixed(http)
controller=paths[8];assert (neg/'source'/controller).read_bytes()==fixed(controller,base)
negative=json.loads((neg/'test-summary.json').read_text());assert negative['totals']==dict(tests=5,failures=3,errors=0,skipped=0)
failures=list(ET.parse(next(neg.glob('TEST-*.xml'))).getroot().iter('failure'))
assert len(failures)==3 and all('completed request must release' in x.get('message','') for x in failures)
for x in json.loads((final/'run.json').read_text())['sourceFingerprints']:assert sha(fixed(x['path']))==x['sha256']
previous=Path('/tmp/edhr-archive-async-final-qa-20261107/final')
assert json.loads((previous/'test-summary.json').read_text())['totals']==dict(tests=95,failures=1,errors=0,skipped=0)
normal=json.loads((previous/'http/normal.json').read_text());assert normal['httpStatus']==200 and normal['started']==2
result=dict(status='FINAL',role='read-only source review child; not application or final QA execution',sourceCommit=head,targetCommit=base,contractReadCommit=head,knowledgeVersion='0.3.25',schema='1.2.0',stage='P0 in-progress',sourceFiles=finger,changedProductFiles=changed,originalStreamAssertionsUnchanged=True,httpAssertionsUnchangedAcrossEagerRevision=True,latestNegativeSameByte=True,latestNegativeTotals=negative['totals'],latestInputFingerprintsBoundToCandidate=21,priorIndependentFailurePreserved=True,productHeadersUnchanged=True,repositoryMutations=False,applicationHTTPExecuted=False,postgresExecuted=False,findings=[],wholeFilesCompleted=0,historicalUnique='unknown',childTasks=[],completedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat())
(o/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='sourceFiles'},ensure_ascii=False,indent=2))
