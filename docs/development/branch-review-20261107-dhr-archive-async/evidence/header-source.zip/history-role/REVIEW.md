# Header policy source comparison — FINAL

Role: read-only security/header source and bounded history increment. No repository product, test, configuration or knowledge edits. No application, HTTP, PostgreSQL or CI execution. This is not final QA and does not independently reproduce the reported Tomcat failure.

## Fixed source versus working snapshot

Fixed product baseline: `764258b869567c0f7840f16ff1358ed5c2491f53`. Working HEAD captured before and after: `8fc765ddf566517c22487564e1bbbc9a0e435e9a`. `baseline.json` records separate source SHA-256 values; SecurityConfig, JwtAuthenticationFilter, WebMvcConfig and FileController working contents all equal the fixed baseline. The new async lifecycle test is a working-tree snapshot, not a baseline file. No statement covers later working changes.

## Shared mechanism and actual differences

- `fixed-base/SecurityConfig.java:40–59`: no custom `headers(...)`, `HeaderWriter`, default-header disable, or eager configuration. Its JWT filter is placed before UsernamePasswordAuthenticationFilter; authentication is stateless, CSRF/form login/Basic disabled. JSON authentication/authorization responses are set by `writeErrorResponse` at lines62–68 (401/403 with existing messages).
- `working/DhrArchiveAsyncLifecycleTest.java:158–174`: isolated test application imports DhrArchiveController and enables method security; its own Basic security chain also leaves default headers unchanged. It permits ERROR/ASYNC dispatches and uses synthetic users. Unlike product configuration, it keeps default CSRF/session behavior. Its MVC async executor/default 250ms timeout is test-only. It does not import product SecurityConfig/JWT/WebMvcConfig and is not an end-to-end product-auth proof.
- Both chains therefore use the same default Spring Security 6.3.0 HeaderWriterFilter behavior. Exact installed bytecode shows its `shouldWriteHeadersEagerly=false` constructor default and the before/after branches. This static commonality supports relevance of a default-header race found in the Basic fixture; it does not prove the product application's complete request ordering or runtime failure incidence.
- `fixed-base/JwtAuthenticationFilter.java:27–53`: valid Bearer token sets the authenticated principal, authorities, request userId and AuditContext; finally clears AuditContext. It reads Authorization/X-Forwarded-For/X-Real-IP; it does not write HTTP response headers. It neither supplies custom security header writers nor makes their lazy wrapper thread-safe.
- Finite `search.json` over product Java/resources found no additional custom HeaderWriter or global response-header mutation. Explicit controller headers include preview cache/CSP and download nosniff; this is a bounded lexical/source search, not whole-application dynamic proof.

## Eager timing: what must remain explicit

Using the same writers eagerly preserves their configured names/values and HSTS request matcher, but it changes when the writers inspect downstream status/headers. It is therefore not universally response-equivalent.

1. **Concrete existing preview boundary:** FileController `pagePreview` lines226–228 and `buildInlinePreviewResponse` lines267–274 set `Cache-Control: private, max-age=300`. The latter serves both inline and permitted public-preview requests (lines235–243). The lazy CacheControlHeadersWriter skips its entire default trio if Cache-Control, Expires or Pragma already exists, and also skips final 304 responses. Eager mode can first install `Cache-Control: no-cache, no-store, max-age=0, must-revalidate`, `Pragma: no-cache`, `Expires: 0`; later MVC code replaces only Cache-Control, potentially leaving the other two defaults. These preview responses must not be described as unchanged under a global eager switch. This is a source/bytecode prediction, not an HTTP observation by this role.
2. **DHR ZIP:** current archive controller has no custom Cache-Control/Pragma/Expires policy. Restricting a timing remedy to this download path avoids treating preview caching as part of the ownership fix. A precise implementation and runtime proof remain the main author's responsibility; do not replace the default writer set or disable headers merely to pass a test.
3. **Default protective headers:** exact installed classes/config establish X-Content-Type-Options nosniff, X-XSS-Protection 0, X-Frame-Options default DENY, and HSTS using its secure-request matcher (request.isSecure) with default one-year/includeSubDomains behavior. Eager timing does not intentionally alter those configured policies. It can still affect later overrides/reset or a downstream request transformation; no blanket invariance claim is made. HSTS on HTTP must remain absent and HTTPS matching must remain intact.
4. **401/403 and CORS:** product JSON handlers and JWT qualifications should remain unchanged; the Basic fixture's challenges/error-dispatch allowance cannot validate them. `fixed-base/WebMvcConfig.java:12–18` configures MVC `/api/**` CORS with origin patterns `*`, six listed methods, headers `*`, credentials and max-age3600. Product SecurityConfig has no explicit `.cors(...)`; fixture does not import this MVC configuration. Default security headers are separate from Access-Control headers; an eager setting does not add CORS authentication/preflight support. Existing preflight behavior has not been evaluated here.

## Validation handoff and limits

For the selected scope, retain normal ZIP status/type/disposition/length/bytes, both declared method authorities, rejected/queued task cleanup and body-start ownership cases. Verify runtime response headers on the chosen path and that no new global preview cache behavior is introduced. If implementation changes the entire chain, existing preview cache trio, HTTP/HTTPS HSTS, final 304, explicit downstream headers/reset, JWT JSON401/403 and CORS behavior need separate appropriate checks; this role has not supplied them.

This increment does not reopen PR70's closed primary-error/suppressed-cleanup finding, does not change timeout/business policy, and does not claim cancellation/crash/UNKNOWN orphan recovery. It relies on the earlier FINAL bounded async-history package for that issue deduplication; no new issue-ID closure is asserted.

## Evidence notes

`commands.json` records all javap exit codes. Nine requested classes succeeded; one XFrameOptionsHeaderWriter lookup used the wrong package and failed. The default DENY is instead visible in the successful `HeadersConfigurer$FrameOptionsConfig.javap`, which refers to the actual `.writers.frameoptions.XFrameOptionsHeaderWriter` class. The failed lookup is retained transparently and is not evidence of runtime absence. Parent source role already has separate exact dependency probes; this child ran none.

Main-review decision received after this snapshot: this batch will not modify the product HeaderWriterFilter. A fixture-only eager setting will isolate the synthetic Basic test from the separate header race while retaining all five lifecycle assertions, the 95-test regression and same-byte negative control. The product header risk remains open for a product-JWT-specific reproduction. This decision is a scope handoff, not execution evidence from this child; neither this package nor a passing fixture may be presented as a product header-risk fix.

Status: **FINAL / static review complete**. No nested children were started.
