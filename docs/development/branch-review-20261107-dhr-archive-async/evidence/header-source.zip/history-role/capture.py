from pathlib import Path
import subprocess,hashlib,json,datetime

repo=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-archive-header-history-20261107')
out.mkdir(parents=True,exist_ok=True)
base='764258b869567c0f7840f16ff1358ed5c2491f53'
def run(args):
 p=subprocess.run(args,cwd=repo,capture_output=True)
 return {'command':args,'exitCode':p.returncode,'stdout':p.stdout.decode(errors='replace'),'stderr':p.stderr.decode(errors='replace')}
def write(rel,data):
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_bytes(data if isinstance(data,bytes) else data.encode())
def sha(data):return hashlib.sha256(data).hexdigest()
head1=run(['git','rev-parse','HEAD'])['stdout'].strip()
paths=['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/WebMvcConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java']
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java'
entries=[]
for path in paths:
 data=subprocess.check_output(['git','show',base+':'+path],cwd=repo)
 rel='fixed-base/'+Path(path).name;write(rel,data)
 current=(repo/path).read_bytes();wrel='working/'+Path(path).name;write(wrel,current)
 entries.append({'path':path,'fixedBase':base,'baseArtifact':rel,'baseSha256':sha(data),'workingArtifact':wrel,'workingSha256':sha(current),'workingEqualsBase':data==current})
data=(repo/test).read_bytes();write('working/'+Path(test).name,data)
entries.append({'path':test,'workingArtifact':'working/'+Path(test).name,'workingSha256':sha(data),'source':'working tree; not baseline file'})
search=run(['rg','-n','-i','HeaderWriter|headers\\(|setHeader\\(|addHeader\\(|Access-Control|CorsConfiguration|Content-Security|Cache-Control|cachecontrol|Strict-Transport|X-Frame|X-Content-Type|crossorigin|forward.*header', 'gmp-platform/backend/src/main/java','gmp-platform/backend/src/main/resources'])
write('search.json',json.dumps(search,indent=2))
javap='/workspace/.edhr-cloud-tools/jdk-21/bin/javap'
web=Path('/workspace/.pr6-m2/org/springframework/security/spring-security-web/6.3.0/spring-security-web-6.3.0.jar')
config=Path('/workspace/.pr6-m2/org/springframework/security/spring-security-config/6.3.0/spring-security-config-6.3.0.jar')
classes=[(web,'org.springframework.security.web.header.HeaderWriterFilter'),(web,'org.springframework.security.web.header.writers.CacheControlHeadersWriter'),(web,'org.springframework.security.web.header.writers.HstsHeaderWriter'),(web,'org.springframework.security.web.header.writers.HstsHeaderWriter$SecureRequestMatcher'),(web,'org.springframework.security.web.header.writers.XFrameOptionsHeaderWriter'),(web,'org.springframework.security.web.header.writers.XContentTypeOptionsHeaderWriter'),(web,'org.springframework.security.web.header.writers.XXssProtectionHeaderWriter'),(web,'org.springframework.security.web.header.writers.StaticHeadersWriter'),(config,'org.springframework.security.config.annotation.web.configurers.HeadersConfigurer'),(config,'org.springframework.security.config.annotation.web.configurers.HeadersConfigurer$FrameOptionsConfig')]
commands=[]
for jar,cls in classes:
 result=run([javap,'-p','-c','-classpath',str(jar),cls])
 rel='bytecode/'+cls.split('.')[-1]+'.javap'
 write(rel,result.pop('stdout'));commands.append(dict(result,artifact=rel))
write('commands.json',json.dumps(commands,indent=2))
write('dependencies.json',json.dumps([{'path':str(jar),'sha256':sha(jar.read_bytes())} for jar in [web,config]],indent=2))
head2=run(['git','rev-parse','HEAD'])['stdout'].strip()
write('baseline.json',json.dumps({'capturedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fixedGitBaseline':base,'headBefore':head1,'headAfter':head2,'headStableDuringCapture':head1==head2,'sources':entries,'scope':'static source and installed bytecode only; no app, HTTP, PostgreSQL, CI, or product mutation'},indent=2))
print(json.dumps({'out':str(out),'sourceCount':len(entries),'headBefore':head1,'headAfter':head2,'javapExitCodes':[c['exitCode'] for c in commands]}))
