from pathlib import Path
import hashlib,json,zipfile,shutil
root=Path('/workspace/edhr-nexus-frontend')
out=root/'docs/development/branch-review-20261107-dhr-archive-async/evidence'
out.mkdir(exist_ok=True)
raw=Path('/tmp/edhr-archive-async-20261107')
knowledge=root/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
shutil.copy2(knowledge,raw/'knowledge'/knowledge.name)
def archive(label,source):
    files=sorted(p for p in source.rglob('*') if p.is_file())
    entries=[dict(path=str(p.relative_to(source)),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    manifest=out/(label+'-manifest.json')
    manifest.write_text(json.dumps({'sourceRoot':str(source),'files':entries},ensure_ascii=False,indent=2)+'\n')
    target=out/(label+'.zip')
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as z:
        for p in files:z.write(p,p.relative_to(source))
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        for item in entries:assert hashlib.sha256(z.read(item['path'])).hexdigest()==item['sha256']
    (out/(label+'-archive.json')).write_text(json.dumps(dict(members=len(entries),bytes=target.stat().st_size,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),manifestSHA256=hashlib.sha256(manifest.read_bytes()).hexdigest()),indent=2)+'\n')
    print(label,len(entries),target.stat().st_size)
archive('main',raw)
archive('source-role',Path('/tmp/edhr-archive-async-source-20261107'))
