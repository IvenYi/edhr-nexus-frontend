from pathlib import Path
import json,hashlib,subprocess,re,xml.etree.ElementTree as ET,shutil,socket,datetime
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-archive-async-20261107');base='764258b869567c0f7840f16ff1358ed5c2491f53';out={'baseline':base,'runs':{},'http':{}}
for phase in ['negative','negative_context','final']:
 p=raw/phase;s=json.loads((p/'test-summary.json').read_text());expected=dict(tests=95,failures=0,errors=0,skipped=0) if phase=='final' else dict(tests=5,failures=3,errors=0,skipped=0);assert s['totals']==expected;out['runs'][phase]=s
 cases={f.stem:json.loads(f.read_text()) for f in (p/'http').glob('*.json')};assert len(cases)==5
 assert cases['normal']['httpStatus']==200 and cases['normal']['started']==1 and not cases['normal']['ownedExistsBeforeFixtureTeardown']
 assert cases['forbidden']['httpStatus']==403 and cases['forbidden']['submitted']==0 and not cases['forbidden']['ownedExistsBeforeFixtureTeardown']
 for name,status in [('rejected',500),('queued-timeout',503)]:
  assert cases[name]['httpStatus']==status and cases[name]['started']==0
 for name in ['rejected','queued-timeout','client-cancelled']:assert cases[name]['ownedExistsBeforeFixtureTeardown']==(phase!='final')
 out['http'][phase]=cases
 if phase!='final':
  xml=next(p.glob('TEST-*DhrArchiveAsyncLifecycleTest.xml'));failures=list(ET.parse(xml).getroot().iter('failure'))
  assert len(failures)==3 and all('Assertion' in x.attrib['type'] and 'completed request must release' in x.attrib.get('message','') for x in failures)
  path='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java';assert (p/'source'/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=r)
 assert not json.loads((p/'temporary-archives.json').read_text())['leftovers']
test='DhrArchiveAsyncLifecycleTest.java';old=list((raw/'negative_context/source').rglob(test))[0].read_bytes();current=list((raw/'final/source').rglob(test))[0].read_bytes();assert old==current
out['sameSourceNegativeControlSha256']=hashlib.sha256(current).hexdigest();out['initialNegativeContextNote']='Initial five cases ran before adding a test-only profile to isolate nested config from later full-app PG context. Both old runs retained (2 positive/3 file-leak assertion failures each); latest negative_context is byte-identical to final.'
fingers=json.loads((raw/'final/run.json').read_text())['sourceFingerprints']
for x in fingers:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
out['finalInputsStillIdentical']=len(fingers)
p=raw/'final';a=[json.loads(x) for x in (p/'observations/observations.jsonl').read_text().splitlines()];assert len(a)==11
out['nativeObservations']={'events':len(a),'instrumentedSelects':sum(x['selectStatements'] for x in a),'scope':'original calling-thread observer, no per-event server tag; not all-network SQL attribution'}
sql=(p/'postgres.log').read_text();inserts=re.findall(r'execute [^:]+: (insert into audit_event[^\n]+)',sql,re.I);assert len(inserts)==3;out['serverExportAuditInsertExecutions']=3
command=['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(raw/'ReadExportJfr.java'),str(p/'observations'),str(p/'vm-tmp')];result=subprocess.run(command,capture_output=True,text=True,check=True);(raw/'jfr-recalculation.tsv').write_text(result.stdout);(raw/'jfr-recalculation.stderr').write_text(result.stderr)
byName={x['name']:x for x in a};checks=[]
for line in result.stdout.splitlines():
 name,b,n,paths=line.split('\t');key=name.removesuffix('.jfr');obs=byName[key];assert int(b)==obs['trackedLogicalReadBytes'] and int(n)==obs['trackedReadEvents'] and int(paths)<=1;checks.append({'name':key,'bytes':int(b),'events':int(n),'matches':True})
assert len(checks)==11;out['jfrRecalculation']=checks;assert json.loads((p/'cleanup.json').read_text())['removed']
ports=sorted(set(int(x) for x in re.findall(r'Tomcat started on port (\d+)',(p/'maven.log').read_text())));assert len(ports)==1
for port in ports:
 with socket.socket() as s:s.settimeout(.5);assert s.connect_ex(('127.0.0.1',port))!=0
out['embeddedHttpPortsClosedAfterFork']=ports;out['ownedResourcesClean']=True
out['limits']=['Real embedded Tomcat/MVC/controller with synthetic Basic security/mock archive generator; not product JWT/GlobalExceptionHandler/DB/PDF HTTP chain','500 rejection/503 timeout are isolated test wiring observations, not production status contracts','Cancellation call accepted (strict assertion before file check); recorded future.isCancelled may be false. Only eventual request completion cleanup claimed, not immediate server cancellation attribution or response rollback','Manual callback ownership tests are not active-body network timeout/cancellation verification','No hook guarantee before async listeners/startAsync if framework setup fails outside controller; no crash/UNKNOWN/persistent reconciliation/capacity closure']
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');shutil.copy2(raw/'analysis.json',r/'docs/development/branch-review-20261107-dhr-archive-async/main-analysis.json')
print(json.dumps({'oldLatest':out['runs']['negative_context']['totals'],'final':out['runs']['final']['totals'],'unchangedInputs':len(fingers),'httpCases':5,'observerEvents':len(a),'observedSelects':out['nativeObservations']['instrumentedSelects'],'auditInserts':3,'jfrRecalculated':len(checks),'httpPortsClosed':ports},indent=2))
