import copy
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path
import yaml

OUT=Path('/tmp/edhr-archive-async-ontology-delta-20261107')
OLD=Path('/tmp/edhr-archive-async-ontology-20261107')
RAW=Path('/tmp/edhr-archive-async-revision-20261107')
FAILED=Path('/tmp/edhr-archive-async-final-qa-20261107')
HEADER=Path('/tmp/edhr-archive-header-source-20261107')
REPO=Path('/workspace/edhr-nexus-frontend')
BASE='764258b869567c0f7840f16ff1358ed5c2491f53'
PREVIOUS='8fc765ddf566517c22487564e1bbbc9a0e435e9a'
CURRENT='7b68eabc6f9c8d7d00863285f9dd79e75a86a4a2'

def git(*args):return subprocess.check_output(['git',*args],cwd=REPO)
def sha(b):return hashlib.sha256(b).hexdigest()
def jread(p):return json.loads(p.read_text())
def jwrite(name,v):(OUT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def cp(src,dst):
    dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)

assert git('rev-parse','HEAD').decode().strip()==CURRENT
initial_status=git('status','--porcelain').decode()
expected_working_docs=['docs/development/branch-review-20261107-dhr-archive-async/review-notes.md','docs/development/branch-review-20261107-dhr-archive-async/header-risk-followup.md']
assert all(line[3:] in expected_working_docs for line in initial_status.splitlines()),initial_status
working_snapshots=[]
for path in expected_working_docs:
    data=(REPO/path).read_bytes();dest=OUT/'observed-working-documents'/path
    dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    working_snapshots.append({'path':path,'bytes':len(data),'sha256':sha(data),'provenance':'Actual uncommitted L0 documentation at ontology delta read time, not candidate Git bytes'})
jwrite('observed-working-document-manifest.json',working_snapshots)
fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=REPO,capture_output=True,text=True)
(OUT/'fetch.log').write_text(fetch.stdout+fetch.stderr);assert fetch.returncode==0
assert git('rev-parse','origin/edhr-dev').decode().strip()==BASE

oldmanifest=jread(OLD/'manifest.json')
oldsha=sha((OLD/'manifest.json').read_bytes())
assert oldsha=='d6ba64abda0540abe2f6bfd9cc347b75de00d24131c75cf43aa98d77e2ef408d'
for row in oldmanifest['files']:
    data=(OLD/row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256']
for name in ['ontology-result.yaml','REVIEW.md','manifest.json','manifest.sha256','knowledge-run.json','knowledge-test-summary.json','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','finite-audit-records.jsonl','finite-audit-summary.json']:
    cp(OLD/name,OUT/'prior-ontology-final'/name)
jwrite('prior-final-preservation.json',{'originalDirectory':str(OLD),'filesVerified':len(oldmanifest['files']),'manifestSha256':oldsha,'originalsNotModified':True})

inventory=[]
original=jread(OLD/'knowledge-fingerprint-inventory-initial.json')
assert len(original)==350
assert sorted(git('ls-tree','-r','--name-only',CURRENT,'docs/knowledge').decode().splitlines())==sorted(r['path'] for r in original)
for row in original:
    path=row['path'];data=(REPO/path).read_bytes()
    assert sha(data)==row['sha256']
    assert data==git('show',BASE+':'+path)==git('show',PREVIOUS+':'+path)==git('show',CURRENT+':'+path)
    inventory.append({**row,'sameAsPreviousCandidate':True,'sameAsCurrentCandidate':True,'sameAsInitialKnowledgeRun':True})
jwrite('knowledge-fingerprint-inventory.json',inventory)
assert git('diff','--name-only',BASE,CURRENT,'--','tools/knowledge-model','docs/agents','AGENTS.md','codeplzreadme.md','docs/architecture/business-knowledge-model.md').decode()==''
assert git('diff','--name-only',PREVIOUS,CURRENT,'--','gmp-platform/backend/src/main').decode()==''
changed=git('diff','--name-only',PREVIOUS,CURRENT).decode().splitlines()
code=[p for p in changed if not p.startswith('docs/')]
http_path='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java'
assert code==[http_path]
(OUT/'delta.patch').write_bytes(git('diff',PREVIOUS,CURRENT,'--',http_path,'docs/development/branch-review-20261015/NEXT.md','docs/development/branch-review-20261107-dhr-archive-async/README.md'))
jwrite('changed-paths.json',changed)

run=jread(RAW/'final/run.json')
sources=[]
for row in run['sourceFingerprints']:
    path=row['path'];data=(RAW/'final/source'/path).read_bytes();candidate=git('show',CURRENT+':'+path)
    assert sha(data)==row['sha256'] and len(data)==row['bytes']
    assert data==candidate==(REPO/path).read_bytes()
    cp(RAW/'final/source'/path,OUT/'final-source'/path)
    sources.append({**row,'matchesCurrentCandidate':True,'sourceProvenance':'Actual parent precommit runtime snapshot compared byte-for-byte with current candidate Git'})
assert len(sources)==21
jwrite('source-input-binding.json',sources)
extra=[r['path'] for r in jread(OLD/'final-source-manifest.json')]
extra+=['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java',
        'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java',
        'docs/development/branch-review-20261015/NEXT.md']
final_sources=[]
for path in sorted(set(extra+[r['path'] for r in sources])):
    data=git('show',CURRENT+':'+path);dest=OUT/'final-source'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    final_sources.append({'path':path,'bytes':len(data),'sha256':sha(data),'sourceCommit':CURRENT})
jwrite('final-source-manifest.json',final_sources)

assert (RAW/'negative_context/source'/http_path).read_bytes()==(RAW/'final/source'/http_path).read_bytes()==git('show',CURRENT+':'+http_path)
controller='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java'
assert (RAW/'negative_context/source'/controller).read_bytes()==git('show',BASE+':'+controller)
cp(RAW/'negative_context/source'/http_path,OUT/'parent-generated-evidence/negative_context/source'/http_path)
cp(RAW/'negative_context/source'/controller,OUT/'parent-generated-evidence/negative_context/source'/controller)
xml_result={}
for label,srcdir in [('latest-negative',RAW/'negative_context'),('latest-main',RAW/'final'),('initial-independent-failed',FAILED/'final')]:
    totals=dict(tests=0,failures=0,errors=0,skipped=0);classes=[]
    for name in ['run.json','test-summary.json']:
        cp(srcdir/name,OUT/'parent-generated-evidence'/label/name)
    for p in sorted(srcdir.glob('TEST-*.xml')):
        node=ET.parse(p).getroot();row={'class':node.attrib['name'],**{k:int(node.attrib.get(k,0)) for k in totals}}
        for k in totals:totals[k]+=row[k]
        classes.append(row);cp(p,OUT/'parent-generated-evidence'/label/p.name)
    assert totals==jread(srcdir/'test-summary.json')['totals']
    for p in sorted((srcdir/'http').glob('*.json')):cp(p,OUT/'parent-generated-evidence'/label/'http'/p.name)
    xml_result[label]={'totals':totals,'classes':classes,'provenance':'Read and independently sum parent/QA-generated actual XML; not executed by this ontology role'}
assert xml_result['latest-negative']['totals']==dict(tests=5,failures=3,errors=0,skipped=0)
assert xml_result['latest-main']['totals']==dict(tests=95,failures=0,errors=0,skipped=0)
assert xml_result['initial-independent-failed']['totals']==dict(tests=95,failures=1,errors=0,skipped=0)
jwrite('xml-recalculation.json',xml_result)
for name in ['analysis.json','setup-failure-note.md']:
    cp(RAW/name,OUT/'parent-generated-evidence'/name)
for name in ['run.json','test-summary.json','maven.log']:
    cp(RAW/'negative_context_setup-failure'/name,OUT/'parent-generated-evidence/setup-failure'/name)
for name in ['REVIEW.md','result.json','manifest.json','manifest.sha256','probe-execution.json','probe-result.jsonl']:
    cp(HEADER/name,OUT/'header-source-role'/name)
for name in ['quality-initial-failed.yaml','independent-initial-failed.md','header-source-review.md']:
    cp(REPO/'docs/development/branch-review-20261107-dhr-archive-async'/name,OUT/'fixed-documentation'/name)
cp(FAILED/'normal-http-failure-extract.txt',OUT/'parent-generated-evidence/initial-independent-failed/normal-http-failure-extract.txt')

normal=jread(RAW/'final/http/normal.json');failednormal=jread(FAILED/'final/http/normal.json')
assert normal['httpStatus']==200 and normal['responseBytes']==164 and normal['started']==1 and normal['submitted']==1
assert failednormal['httpStatus']==200 and failednormal['responseBytes']==164 and failednormal['started']==2 and failednormal['submitted']==2
contract=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md']
for path in contract:assert git('show',BASE+':'+path)==git('show',CURRENT+':'+path)
jwrite('final-verification.json',{'recordedAtUTC':datetime.now(timezone.utc).isoformat(),'sourceCommit':CURRENT,'previousSourceCommit':PREVIOUS,'targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[],'workingTreeState':'L0 documentation-only dirty','observedWorkingTreeStatus':initial_status,'knowledgeUnchanged':350,'knowledgeValidatorSourceUnchanged':True,'reusedOwnActualKnowledgeTests':89,'newKnowledgeRuntime':False,'parentRuntimeInputsMatchingCandidate':21,'productSourceUnchangedSincePreviousCandidate':True,'modifiedCodePaths':code,'negativeFinalHttpByteEquality':True,'negativeFinalHttpSha256':sha((RAW/'final/source'/http_path).read_bytes()),'oldFinal112FilesPreserved':True,'headerProductRisk':'open; test-only eager is not product fix','finalIndependentQA':'Not executed/read by this role; fresh instance pending at this review'})
jwrite('finite-review-scope.json',{'phase':'FINAL-delta','priorFiniteRecords':10,'retainedConsistent':8,'retainedEvidenceGap':2,'newSemanticIdReviews':0,'newWholeFileCompletions':0,'historicalUniqueCoverage':'unknown','knowledge350Meaning':'fingerprint inventory only, not semantic whole-knowledge audit','deltaScope':'Only synthetic Basic fixture eager-header isolation and related reports; no product/knowledge/policy change'})

result=copy.deepcopy(yaml.safe_load((OLD/'ontology-result.yaml').read_text()))
o=result['ontologyResult'];o['contractBaseline']['sourceCommit']=CURRENT
o['reason']='对旧FINAL的只读增量：候选相对8fc765仅修改已隔离Basic HTTP测试链的eager响应头装配及审计文档，产品源码/知识/契约未变；五项原断言、真实Tomcat及normal一次启动标准保留。该装配修正不改变DHR业务或产品JWT/缓存政策，不构成产品响应头风险修复。故原工程临时ZIP归属结论仍为not-applicable，无需变更知识。'
o['validationEvidence']=[
 {'id':'validation.reused-own-knowledge89','checkType':'schema','command':'Reuse actual prior bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test after byte-for-byte knowledge/tool-source comparison','outcome':'passed','evidence':['本角色前次实际89/89；此次没有重跑。350知识与validator源码均未变，fresh原始XML按原执行时间保留。','prior-ontology-final/knowledge-run.json','prior-ontology-final/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','knowledge-fingerprint-inventory.json']},
 {'id':'validation.prior-finite10-retained','checkType':'reference','command':'Read delta against prior fixed affected-rule review','outcome':'passed','evidence':['原有限10=8consistent/2gap保持；新增语义ID审查0、整文件完成0，不重复累计覆盖。','finite-review-scope.json','prior-ontology-final/finite-audit-records.jsonl']},
 {'id':'validation.unchanged-status-and-policy','checkType':'status-transition','command':'Compare target, prior candidate, current candidate and current worktree knowledge/contract bytes','outcome':'passed','evidence':['350知识和原契约均未变，0.3.25/schema1.2.0/P0 in-progress及原成熟度保持。','final-verification.json','knowledge-fingerprint-inventory.json']},
 {'id':'validation.fixture-business-projection','checkType':'projection','command':'Read test-only eager delta, preserved initial failed QA, header source role and new parent raw evidence','outcome':'passed','evidence':['eager仅在独立Basic链；实际产品缓存/304/reset策略风险仍open，非JWT/产品头修复；不以主侧95覆盖初版94/95。','REVIEW.md','delta.patch','header-source-role/REVIEW.md','xml-recalculation.json']},
 {'id':'validation.fixed-input-paths','checkType':'evidence-path','command':'fetch origin edhr-dev and compare candidate Git bytes to 21 actual run snapshots','outcome':'passed','evidence':['目标仍764258，固定候选7b68eab，21输入全同；实际共享工作树仅两项L0文档dirty，另存工作快照；最新旧源HTTP测试与final同字节，旧controller同目标。','final-verification.json','source-input-binding.json','observed-working-document-manifest.json']}
]
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
review=f'''# 临时 ZIP 异步生命周期本体只读增量 — FINAL

结果仍为 **not-applicable**：本次相对旧候选仅修改独立Basic HTTP测试安全链的eager响应头装配及审计材料，没有产品源码、知识或业务政策变化。此次不重做旧本体审查或累计覆盖，不把测试装配修正当产品响应头修复。

最终固定候选 `{CURRENT}`，旧候选 `{PREVIOUS}`。实际fetch后edhr-dev仍为`{BASE}`，原契约实际读取commit仍为目标；共享工作树实际有review-notes.md修改及header-risk-followup.md未跟踪两项L0文档，并非clean，已另存实际工作快照和来源，产品/测试/知识/契约无未提交变更。这两项仅移除易漂移行号、登记受测来源及保留响应头风险/下一专项，不引入政策。350知识逐字节同目标、旧/新候选、工作树及前次知识执行时资产，知识validator源码未变。保留知识0.3.25/schema1.2.0/P0 in-progress及原status/visibility。自身旧FINAL的112个manifest成员已全部重新核验，原目录不改；本增量另存此目录。21个父侧实际运行输入与新候选Git字节完全一致，运行时HEAD/dirty记录保持原件，不虚构运行commit。

首个独立质量是实质 **failed/FINAL：95=94通过/1失败，0errors/skips**，不是全绿；normal虽200/164字节且ZIP已删，实际submitted2/started2，违背started1断言。已核原始XML、normal.json、选定异常摘录并保留独立报告。HeaderWriterFilter的servlet finally与worker commit写头竞争和MimeHeaders AIOOBE有实际来源；第二次GET可见，但“客户端自动重试”没有客户端协议trace，保留推断，不归因250ms超时或ZIP CAS。本增量不反写旧报告，不以新绿覆盖旧失败。

只读源码角色及其子角色另已正式FINAL；本角色读其报告和结果，未执行其10个依赖微例或重现产品JWT。其证据明确global eager提前执行同一writer列表，并不保证终态头策略完全等价：304、自定义Cache-Control、reset存在差异。当前产品FileController有private,max-age=300预览，产品默认lazy头与异步流的共享风险仍 **open**，待产品JWT专项复现、方案与缓存边界验证；本次没有修改SecurityConfig/FileController或授权新缓存策略。

测试修改只位于已有@Profile隔离的TestApplication.security合成Basic链，显式设HeaderWriterFilter.eager。真实Tomcat/MVC/Controller/方法权限和可控执行器保持，五项测试方法/原断言及normal启动一次要求均未变，无新增重跑/容错。已核新parent原件并独立汇总XML：最新旧源5=2正控/3真实文件遗留断言失败、0errors/skips，最新主侧95/95全过；两者HTTP测试源码完全相同，旧controller与目标Git相同。最新normal为200/164且submitted1/started1。旧源首轮依赖软链缺失导致renderer构建127且JUnit0，原件单列setup-failure，未计为产品红；补依赖后才取得有效5项负对照。

本角色本次 **没有运行产品/HTTP/PG/知识测试**。知识89/89仅复用自身前次实际执行的原命令、时间和XML，因知识及工具字节未变；新主侧95、初版独立94/95、依赖微例及SQL/JFR等均分别归属原执行角色。另一全新最终QA由父侧安排，本角色不提前声明通过。Basic/mock生成服务/测试专属超时与产品JWT、GlobalExceptionHandler、真实PDF/DB全HTTP仍分离；500/503非产品状态契约。cancel(true)接受但future.isCancelled=false仍只证明最终请求完成清理；直接归属回调检查不冒充活动body真实网络断开。

旧有限10条中的8consistent、2evidence-gap保持，新增语义ID审查0、整文件完成0、历史unique未知。DEC0063的显式冻结版本/范围、原件/SHA/缺失阻断、权限及流前EXPORT审计不变；DEC0090受控归档/放行、保存期限、恢复/自动销毁未实现或提升。HTTP已发状态/字节及成功生成审计无传输失败回滚承诺。临时ZIP请求归属不是业务状态；本体无新冲突/用户问题。

原完整可打印视觉、完整多租户、pre-async框架外异常、活动body网络timeout/cancel、Error/OOM/crash/磁盘失效、UNKNOWN/持久对账、容量和历史性能队列保持；产品头竞态新增明确open，不被ZIP局部验收关闭。W2-W7/931知识/86UI/A12/高风险/完整矩阵、A23含已审代码及用户暂停项保持，数据库分页仍待实际选择。没有修改仓库、查/触发CI、merge/deploy或恢复数据。
'''
(OUT/'REVIEW.md').write_text(review)
assert yaml.safe_load((OUT/'ontology-result.yaml').read_text())==result
end_status=git('status','--porcelain').decode()
assert all(line[3:] in expected_working_docs for line in end_status.splitlines()),end_status
jwrite('final-working-tree-observation.json',{'initialStatus':initial_status,'finalStatus':end_status,'allUncommittedPathsAreDeclaredL0Docs':True})
print(json.dumps({'status':'FINAL','result':'not-applicable','sourceCommit':CURRENT,'knowledgeUnchanged':350,'runtimeInputMatches':21,'reusedOwnKnowledge':89,'priorFinalVerified':112,'newSemanticIdReviews':0},ensure_ascii=False))
