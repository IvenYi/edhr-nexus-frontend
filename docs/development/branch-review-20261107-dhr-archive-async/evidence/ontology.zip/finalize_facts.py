import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from pathlib import Path

OUT = Path('/tmp/edhr-archive-async-ontology-20261107')
PARENT = Path('/tmp/edhr-archive-async-20261107')
REPO = Path('/workspace/edhr-nexus-frontend')
BASE = '764258b869567c0f7840f16ff1358ed5c2491f53'
CANDIDATE = sys.argv[1]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def put_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

head = git('rev-parse', 'HEAD').decode().strip()
assert head == CANDIDATE, (head, CANDIDATE)
status = git('status', '--porcelain').decode()
assert status == '', status
fetch = subprocess.run(['git', 'fetch', 'origin', 'edhr-dev'], cwd=REPO, capture_output=True, text=True)
(OUT / 'final-fetch.log').write_text(fetch.stdout + fetch.stderr)
assert fetch.returncode == 0
target = git('rev-parse', 'origin/edhr-dev').decode().strip()
assert target == BASE, ('Target increment requires review', target)

initial_inventory = json.loads((OUT / 'knowledge-fingerprint-inventory-initial.json').read_text())
tracked = git('ls-tree', '-r', '--name-only', CANDIDATE, 'docs/knowledge').decode().splitlines()
assert sorted(tracked) == sorted(row['path'] for row in initial_inventory)
inventory = []
for row in initial_inventory:
    path = row['path']
    base = git('show', BASE + ':' + path)
    candidate = git('show', CANDIDATE + ':' + path)
    current = (REPO / path).read_bytes()
    assert base == candidate == current
    assert sha(current) == row['sha256']
    inventory.append({'path': path, 'bytes': len(current), 'sha256': sha(current),
                      'sameAsBase': True, 'sameAsCandidate': True, 'sameAsInitialKnowledgeRun': True})
assert len(inventory) == 350
put_json(OUT / 'knowledge-fingerprint-inventory-final.json', inventory)

parent_run = json.loads((PARENT / 'final/run.json').read_text())
initial_sources = json.loads((OUT / 'initial-source-manifest.json').read_text())
if isinstance(initial_sources, dict):
    initial_sources = initial_sources['files']
paths = sorted(set([row['path'] for row in initial_sources] +
                   [row['path'] for row in parent_run['sourceFingerprints']]))
source_manifest = []
for path in paths:
    data = git('show', CANDIDATE + ':' + path)
    assert data == (REPO / path).read_bytes()
    dest = OUT / 'final-source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    source_manifest.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'sourceCommit': CANDIDATE})
put_json(OUT / 'final-source-manifest.json', source_manifest)

source_binding = []
for row in parent_run['sourceFingerprints']:
    path = row['path']
    actual = (PARENT / 'final/source' / path).read_bytes()
    assert len(actual) == row['bytes'] and sha(actual) == row['sha256']
    candidate = git('show', CANDIDATE + ':' + path)
    same = candidate == actual
    if not same:
        assert path.startswith('docs/development/branch-review-20261107-dhr-archive-async/'), path
    source_binding.append({**row, 'matchesCandidate': same,
                           'candidateSha256': sha(candidate),
                           'provenance': 'Parent executed precommit worktree snapshot; this role compares raw bytes to candidate Git object'})
put_json(OUT / 'parent-final-source-binding.json', source_binding)

contract_paths = ['AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md',
                  'docs/agents/business-knowledge-modeler.md', 'docs/architecture/business-knowledge-model.md']
for path in contract_paths:
    assert git('show', BASE + ':' + path) == git('show', CANDIDATE + ':' + path)

evidence = OUT / 'parent-generated-evidence'
for run in ['negative', 'negative_context', 'final']:
    for name in ['run.json', 'test-summary.json']:
        dest = evidence / run / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(PARENT / run / name, dest)
    for pattern in ['TEST-*.xml', 'http/*.json']:
        for src in (PARENT / run).glob(pattern):
            dest = evidence / run / src.relative_to(PARENT / run)
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(src, dest)
shutil.copyfile(PARENT / 'analysis.json', evidence / 'analysis.json')

xml_summaries = {}
for run in ['negative', 'negative_context', 'final']:
    totals = dict(tests=0, failures=0, errors=0, skipped=0)
    cases = []
    run_data = json.loads((evidence / run / 'run.json').read_text())
    for src in sorted((evidence / run).glob('TEST-*.xml')):
        node = ET.parse(src).getroot()
        row = {'class': node.attrib['name'], **{key: int(node.attrib.get(key, 0)) for key in totals}}
        for key in totals:
            totals[key] += row[key]
        cases.append(row)
    expected = json.loads((evidence / run / 'test-summary.json').read_text())['totals']
    assert totals == expected
    xml_summaries[run] = {'totals': totals, 'classes': cases, 'source': 'Parent-generated XML read and independently summed; not executed by ontology role'}
assert xml_summaries['final']['totals'] == dict(tests=95, failures=0, errors=0, skipped=0)
for run in ['negative', 'negative_context']:
    assert xml_summaries[run]['totals'] == dict(tests=5, failures=3, errors=0, skipped=0)
http_path = 'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveAsyncLifecycleTest.java'
negative_test = (PARENT / 'negative_context/source' / http_path).read_bytes()
final_test = (PARENT / 'final/source' / http_path).read_bytes()
assert negative_test == final_test
base_controller = git('show', BASE + ':gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java')
for run in ['negative', 'negative_context']:
    assert (PARENT / run / 'source/gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java').read_bytes() == base_controller
put_json(OUT / 'parent-xml-recalculation.json', xml_summaries)
put_json(OUT / 'final-verification.json', {
    'recordedAtUTC': datetime.now(timezone.utc).isoformat(),
    'candidateCommit': CANDIDATE, 'targetBranch': 'edhr-dev', 'targetCommit': target,
    'contractReadCommit': BASE, 'uncommittedContractPaths': [], 'workingTreeState': 'clean',
    'knowledgeFilesUnchanged': 350, 'parentInputFilesCompared': len(source_binding),
    'parentInputFilesMatchingCandidate': sum(row['matchesCandidate'] for row in source_binding),
    'contractFilesUnchanged': contract_paths,
    'latestNegativeFinalHttpTestSameBytes': True,
    'latestNegativeFinalHttpTestSha256': sha(final_test),
    'parentTestEvidenceReadOnly': True,
    'ontologyRoleRuntime': 'Own knowledge validator 89/89; no product/HTTP/PostgreSQL tests executed by this role'
})
print(json.dumps({'candidate': CANDIDATE, 'target': target, 'knowledge': len(inventory),
                  'parentInputs': len(source_binding), 'matching': sum(row['matchesCandidate'] for row in source_binding)}, ensure_ascii=False))
