from pathlib import Path
import subprocess,json,hashlib,datetime,xml.etree.ElementTree as ET,shutil
r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-archive-async-ontology-20261107');out.mkdir(exist_ok=True)
base='764258b869567c0f7840f16ff1358ed5c2491f53'
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
assert git('rev-parse','origin/edhr-dev')==base
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/evidence/dhr-summary-user-confirmed.md','docs/knowledge/evidence/dhr-archive-minimum-20261029.md','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java']
manifest=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=r);p=out/'initial-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);manifest.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source':'Git '+base})
dp='docs/development/branch-review-20261107-dhr-archive-async/decision-package.yaml';b=(r/dp).read_bytes();p=out/'initial-working-tree'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);manifest.append({'path':dp,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'source':'actual uncommitted working tree; not Git baseline'})
(out/'initial-source-manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
knowledge=[]
for path in git('ls-tree','-r','--name-only',base,'--','docs/knowledge').splitlines():
 old=subprocess.check_output(['git','show',base+':'+path],cwd=r);current=(r/path).read_bytes();assert current==old,path
 knowledge.append({'path':path,'bytes':len(current),'sha256':hashlib.sha256(current).hexdigest(),'sameAsBase':True})
assert len(knowledge)==350
(out/'knowledge-fingerprint-inventory-initial.json').write_text(json.dumps(knowledge,ensure_ascii=False,indent=2)+'\n')
(out/'baseline.json').write_text(json.dumps({'readAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'headAtRead':git('rev-parse','HEAD'),'target':git('rev-parse','origin/edhr-dev'),'status':git('status','--porcelain').splitlines(),'knowledgeFiles':len(knowledge),'contractDiff':git('diff','--name-only',base,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture'),'role':'ontology; no product/test/config changes, only own /tmp evidence'},ensure_ascii=False,indent=2)+'\n')
start=datetime.datetime.now(datetime.timezone.utc);command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test']
with (out/'knowledge-validation.log').open('w') as f:result=subprocess.run(command,cwd=r,stdout=f,stderr=subprocess.STDOUT)
totals=dict(tests=0,failures=0,errors=0,skipped=0);reports=[]
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 assert p.stat().st_mtime>=start.timestamp(),p
 a=ET.parse(p).getroot().attrib
 for key in totals:totals[key]+=int(a[key])
 shutil.copy2(p,out/p.name);reports.append(p.name)
(out/'knowledge-run.json').write_text(json.dumps({'command':command,'startedAtUTC':start.isoformat(),'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'freshReports':reports,'totals':totals},ensure_ascii=False,indent=2)+'\n')
(out/'knowledge-test-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
assert result.returncode==0 and totals==dict(tests=89,failures=0,errors=0,skipped=0)
print(json.dumps({'knowledgeFiles':len(knowledge),'tests':totals,'sourcePaths':len(manifest)},indent=2))
