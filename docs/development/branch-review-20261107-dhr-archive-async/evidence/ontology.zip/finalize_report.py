import hashlib
import json
import subprocess
from pathlib import Path
import yaml

OUT = Path('/tmp/edhr-archive-async-ontology-20261107')
REPO = Path('/workspace/edhr-nexus-frontend')
BASE = '764258b869567c0f7840f16ff1358ed5c2491f53'
CANDIDATE = '8fc765ddf566517c22487564e1bbbc9a0e435e9a'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def put_json(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

facts = json.loads((OUT / 'final-verification.json').read_text())
assert facts['candidateCommit'] == CANDIDATE
assert facts['parentInputFilesMatchingCandidate'] == 21
diff_paths = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
assert not any(p.startswith(('docs/knowledge/', 'tools/knowledge-model/', 'docs/agents/')) for p in diff_paths)
(OUT / 'candidate-diff-paths.json').write_text(json.dumps(diff_paths, ensure_ascii=False, indent=2) + '\n')
readme = 'docs/development/branch-review-20261107-dhr-archive-async/README.md'
data = git('show', CANDIDATE + ':' + readme)
dest = OUT / 'final-source' / readme
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_bytes(data)
source_manifest = json.loads((OUT / 'final-source-manifest.json').read_text())
source_manifest.append({'path': readme, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'sourceCommit': CANDIDATE})
put_json('final-source-manifest.json', sorted(source_manifest, key=lambda r: r['path']))
(OUT / 'candidate-controller-stream-diff.patch').write_bytes(git('diff', BASE, CANDIDATE, '--',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveControllerStreamingTest.java'))

records_path = OUT / 'finite-audit-records.jsonl'
records = [json.loads(line) for line in records_path.read_text().splitlines() if line]
for row in records:
    row['runtimeValidationScope'] = (
        'Only knowledge validator 89/89 executed by ontology role. '
        'Parent-generated final XML independently read/summed 95/95; old two HTTP runs each 5=2 pass/3 assertion failures, 0 errors/skips. '
        'Real embedded Tomcat/MVC uses synthetic Basic identity and mock ZIP generator. '
        'Direct callback tests are distinct from real active-body network faults; no full product JWT/PDF/tenant runtime claim.')
    row['finalEvidenceReferences'] = [
        {'path': 'final-verification.json', 'kind': 'Ontology-role candidate/target/byte verification'},
        {'path': 'parent-xml-recalculation.json', 'kind': 'Ontology-role sum of parent-generated actual XML'},
        {'path': 'final-source/' + row['sourcePath'], 'kind': 'Candidate Git fixed source'},
    ]
    row['sourceCommit'] = CANDIDATE
records_path.write_text(''.join(json.dumps(r, ensure_ascii=False) + '\n' for r in records))
assert len(records) == 10
assert sum(r['conclusion'] == 'consistent' for r in records) == 8
assert sum(r['conclusion'] == 'evidence-gap' for r in records) == 2
put_json('finite-audit-summary.json', {
    'phase': 'FINAL', 'sourceCommit': CANDIDATE, 'targetCommit': BASE,
    'finiteRecords': 10, 'consistent': 8, 'evidence-gap': 2,
    'knowledgeInventory': 350, 'knowledgeInventoryIsSemanticCoverage': False,
    'wholeFileCompletions': 0, 'historicalUniqueCoverage': 'unknown',
    'runtimeByOntologyRole': 'knowledge89 only',
    'parentRuntimeEvidence': 'Read parent-generated XML: final95 and two old negative5 each; not executed by this ontology role'
})

decision = 'docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml'
archive = 'docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml'
result = {'ontologyResult': {
    'result': 'not-applicable', 'baselineBefore': '0.3.25', 'baselineAfter': '0.3.25',
    'contractBaseline': {
        'sourceCommit': CANDIDATE, 'targetBranch': 'edhr-dev', 'targetCommit': BASE,
        'contractReadCommit': BASE, 'uncommittedContractPaths': []},
    'reason': '已核最终候选与原件：仅为当前请求生成的临时ZIP补Spring完成回调和单次清理归属；活动body保持原TWR。指定冻结版本/范围、原件/摘要、按权导出和流前EXPORT审计不变，不引入新DHR状态、受控归档/放行、业务超时/重试或历史恢复政策；因此无需变更知识。',
    'changedArtifacts': [],
    'knowledgeSync': [
        {'id': 'rule.dhr-summary-zip-source-trace', 'disposition': 'retained',
         'scope': '完整/选定导出仍绑定同一显式冻结版本；来源原件、SHA、缺失阻断和权限保持，临时副本回收不更改证据。',
         'sourceReferences': ['docs/knowledge/rules/dhr-summary.yaml', decision,
                              'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java']},
        {'id': 'DEC-0063-10', 'disposition': 'retained',
         'scope': '仅回收本请求自有ZIP；历史原件和冻结引用保持。', 'sourceReferences': [decision]},
        {'id': 'DEC-0063-12', 'disposition': 'retained',
         'scope': '查看/导出分权与审计保持；生成成功的EXPORT仍先于流，不新增网络失败回滚审计或HTTP已发内容回滚承诺。', 'sourceReferences': [decision]},
        {'id': 'DEC-0090-01', 'disposition': 'retained',
         'scope': '汇总冻结、最终放行后的受控归档和指定版本下载副本继续区分；临时资源回收不实现受控归档。', 'sourceReferences': [archive]},
        {'id': 'DEC-0090-03', 'disposition': 'retained',
         'scope': '不增加保存期限、自动销毁、备份恢复或跨租户政策。', 'sourceReferences': [archive]},
        {'id': 'term.dhr-archive', 'disposition': 'retained',
         'scope': '保留specified/internal成熟度；请求临时ZIP清理不提升归档能力实现或验证状态。', 'sourceReferences': ['docs/knowledge/glossary.yaml', archive]},
        {'id': 'question.multi-tenant-workflow-isolation', 'disposition': 'deferred',
         'scope': '原未决保持；独立Basic装配只验证方法权限局部，不能代表产品JWT与完整租户隔离。本切片不引入隔离政策，不形成新的用户问题或业务阻断。',
         'sourceReferences': ['docs/knowledge/open-questions.yaml']},
    ],
    'conflicts': [], 'questions': [],
    'validationEvidence': [
        {'id': 'validation.knowledge89', 'checkType': 'schema',
         'command': 'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test',
         'outcome': 'passed', 'evidence': ['本角色实际执行89/89，0失败/错误/跳过；fresh XML及UTC时间已存。', 'knowledge-run.json', 'TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']},
        {'id': 'validation.finite-reference10', 'checkType': 'reference',
         'command': 'Read fixed authority IDs and final implementation within temporary-ZIP lifecycle slice',
         'outcome': 'passed', 'evidence': ['有限10条：8 consistent、2保留evidence-gap；350是指纹盘点，非语义全审。', 'finite-audit-records.jsonl', 'finite-audit-summary.json']},
        {'id': 'validation.original-status-retained', 'checkType': 'status-transition',
         'command': 'Compare 350 tracked knowledge files at initial knowledge run, target, current worktree and candidate Git objects',
         'outcome': 'passed', 'evidence': ['350逐字节一致，原status/visibility未提升；知识0.3.25/schema1.2.0/P0 in-progress保持。', 'knowledge-fingerprint-inventory-final.json']},
        {'id': 'validation.engineering-business-projection', 'checkType': 'projection',
         'command': 'Read candidate controller/service/DP/test assembly and parent-generated raw XML/HTTP records',
         'outcome': 'passed', 'evidence': ['只处理临时副本生命周期；Basic/mock测试与产品JWT、真实PDF及完整多租户能力分离。', 'REVIEW.md', 'parent-xml-recalculation.json', 'parent-generated-evidence/final/http/queued-timeout.json']},
        {'id': 'validation.candidate-evidence-path', 'checkType': 'evidence-path',
         'command': 'fetch origin edhr-dev; compare actual candidate Git bytes, final source snapshots and referenced evidence',
         'outcome': 'passed', 'evidence': ['目标仍764258；候选8fc765 clean；父侧受测21输入与候选逐字节相同；最新旧源负对照HTTP测试与最终同字节。', 'final-verification.json', 'parent-final-source-binding.json']},
    ],
    'roadmapProgress': {'stage': 'P0', 'status': 'in-progress', 'exitCriteriaEvidence': [], 'deferredStages': ['P1', 'P2', 'P3']}
}}
(OUT / 'ontology-result.yaml').write_text(yaml.safe_dump(result, allow_unicode=True, sort_keys=False))

review = f'''# 临时 ZIP 异步生命周期本体有限核对 — FINAL

正式结果为 `not-applicable`。当前请求临时副本的清理归属属于工程修复，最终候选未改变业务知识、授权、冻结、原件、摘要、业务超时或审计规则。本角色仅写本临时目录，产品、测试、配置及知识均只读。

最终源码为 `{CANDIDATE}`；本角色实际 fetch 后目标 edhr-dev 仍为 `{BASE}`，工作树 clean。原契约按 `{BASE}` 实际读取，5份相关契约/架构文件在候选中逐字节未变。350份知识资产在初始知识验证、目标、候选Git及当前工作树间逐字节一致；原知识0.3.25/schema1.2.0/P0 in-progress保持。父侧测试运行时HEAD是目标且包含未提交修复，未虚构运行commit；本角色已逐字节核父侧最终21个实际运行输入，全部与clean候选相同。详见final-verification.json及parent-final-source-binding.json。

DEC-0063-05/10/11/12、rule.dhr-summary-zip-source-trace要求的同一显式冻结版本、完整/选定范围、原件/摘要、缺失或损坏阻断、查看/导出分权保持。Service生成及流前EXPORT审计未改。Controller仅新增Spring Callable完成回调与请求内一次CAS归属：body先领取则保留原TWR，完成先领取则清理未开始body的自有ZIP；活动body不能被回调提前删文件，重复回调不再领取路径。同步响应元信息失败清理保留原异常，清理失败记录自有路径/异常。请求局部归属不是新DHR业务状态。

DEC-0090-01继续区分汇总冻结、最终放行后的受控归档、指定版本下载副本。DEC-0090-03和term.dhr-archive未提升为已实现/已验证；不新增保存年限、自动销毁、备份恢复、未知孤儿扫描或持久对账。既有EXPORT生成成功审计不会因传输失败自动回滚，HTTP已经发送的状态/字节也无回滚承诺。本体无新冲突或待用户决定问题，无需新增业务政策。

本角色实际仅运行知识校验 **89/89，0 failures/errors/skipped**，fresh XML、命令和UTC时间在knowledge-run.json。不冒称执行过产品、HTTP、PostgreSQL、PDF或故障试验。父侧实际原件已另标来源复制到parent-generated-evidence：本角色读取并独立汇总XML得到最终 **95/95**；旧产品两次HTTP负对照各 **5=2通过/3真实文件遗留断言失败，0 errors/skipped**。初次之后仅增加测试profile隔离嵌套配置，原件未反写；最新negative_context的HTTP源码与最终逐字节一致，父侧旧Controller也与目标Git逐字节一致。最终原件HTTP记录显示正常200且精确字节、无权403且Service未调用、拒绝/排队超时body started=0且teardown前自有文件已消失。

这些HTTP用例使用真实嵌入式Tomcat/MVC、真实Controller和方法权限表达式，但采用独立合成Basic身份、mock ZIP生成服务和测试专属250ms超时。固定产品SecurityConfig禁用Basic并使用JWT，GlobalExceptionHandler有Exception→500映射；因此实验500拒绝/503超时不是生产状态契约，不授权改产品安全或错误码。客户端cancel(true)严格断言调用被接受，但实际记录future.isCancelled=false，只证明取消请求后最终请求结束清理，不声称服务器即时取消归因。5项归属单元直接调用回调，不能冒充真实网络活动流超时或断开。父侧原生PG、11个观察区间/33调用线程SELECT、3次serverEXPORT及JFR数字仅归属其原始运行/分析，本角色未另行执行或重新测量；真实Chromium版式、产品JWT全链、多租户和生产负载均未由本角色证明。

有限10条逐ID记录为 **8 consistent、2 evidence-gap**，见finite-audit-records.jsonl；两个保留缺口是完整可打印档案运行/视觉场景、原完整多租户问题，不作为本切片新增阻断。350是指纹盘点，10不是新增全量unique，整文件完成0、历史unique未知，未提升任何原成熟度。

未覆盖async listener/startAsync建立前的框架外异常、真实活动body网络超时/取消、Error/OOM、进程崩溃、磁盘失效、UNKNOWN/持久对账、容量及所有生命周期故障；清理失败可见不等于保证必删。原W2-W7/931知识/86 UI候选/A12/高风险/完整矩阵、历史ZIP/text-ID/容量及性能队列、A23含已审代码和用户暂停项全部保持。数据库分页仍待用户实际选择，本轮不产生新授权。全新独立质量由其他未修复实例完成；本体知识校验不代替质量门禁，整体审计不因本FINAL而完成。未查/触发CI、合并、部署或恢复数据。
'''
(OUT / 'REVIEW.md').write_text(review)
parsed = yaml.safe_load((OUT / 'ontology-result.yaml').read_text())
assert parsed == result
print(json.dumps({'status': 'FINAL', 'result': 'not-applicable', 'sourceCommit': CANDIDATE, 'finite': {'consistent':8, 'evidence-gap':2}, 'knowledge':89}, ensure_ascii=False))
