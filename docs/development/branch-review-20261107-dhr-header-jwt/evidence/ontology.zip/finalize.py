from pathlib import Path
import subprocess,hashlib,json,datetime,shutil,sys,xml.etree.ElementTree as ET,yaml
root=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-header-jwt-ontology-20261107')
base='b6691e2c6289ab414a7a3fed1f128562cbba4166';candidate=sys.argv[1];parent=Path(sys.argv[2]);phase=sys.argv[3] if len(sys.argv)>3 else 'final'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def get(commit,path):return subprocess.check_output(['git','show',commit+':'+path],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
fetch=subprocess.run(['git','fetch','origin','edhr-dev'],cwd=root,text=True,capture_output=True,check=True)
(raw/'final-fetch.log').write_text(fetch.stdout+fetch.stderr)
assert git('rev-parse','origin/edhr-dev')==base,'Target changed: increment required'
assert git('rev-parse',candidate)==candidate
inventory=json.loads((raw/'knowledge-fingerprints-initial.json').read_text())
for item in inventory:
    assert sha(get(candidate,item['path']))==item['sha256'] and sha((root/item['path']).read_bytes())==item['sha256'],item['path']
(raw/'knowledge-fingerprints-final.json').write_text(json.dumps(inventory,indent=2)+'\n')
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md']
for path in contracts:assert get(base,path)==get(candidate,path)==(root/path).read_bytes(),path
validator=git('ls-tree','-r',base,'--','tools/knowledge-model')
assert git('diff',base,candidate,'--','tools/knowledge-model')==''
changed=git('diff',base,candidate,'--name-only').splitlines()
(raw/'candidate-changed-paths.json').write_text(json.dumps(changed,indent=2)+'\n')
(raw/'candidate-runtime.patch').write_text(git('diff',base,candidate,'--','gmp-platform/backend/src/main','gmp-platform/backend/src/test')+'\n')
unchanged=['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtTokenProvider.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java']
for path in unchanged:assert get(base,path)==get(candidate,path),(path,'unexpected semantic input delta')
final=parent/phase;run=json.loads((final/'run.json').read_text());binding=[]
for item in run['sourceFingerprints']:
    b=get(candidate,item['path']);current=(root/item['path']).read_bytes();snapshot=(final/'source'/item['path']).read_bytes()
    assert sha(b)==sha(current)==sha(snapshot)==item['sha256'],item['path']
    binding.append(dict(path=item['path'],sha256=item['sha256'],candidateEqualsRuntimeAndWorktree=True))
(raw/'parent-final-source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
snapPaths=list(dict.fromkeys([x['path'] for x in json.loads((raw/'fixed-initial-source-manifest.json').read_text())]+[x['path'] for x in run['sourceFingerprints']]))
snaps=[]
for path in snapPaths:
    b=get(candidate,path);p=raw/'fixed-final-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);snaps.append(dict(path=path,bytes=len(b),sha256=sha(b)))
(raw/'fixed-final-source-manifest.json').write_text(json.dumps(snaps,indent=2)+'\n')
counts={k:0 for k in ['tests','failures','errors','skipped']};xmls=[]
for xml in final.glob('TEST-*.xml'):
    a=ET.parse(xml).getroot().attrib;v={k:int(a.get(k,0)) for k in counts}
    for k in counts:counts[k]+=v[k]
    p=raw/'parent-generated-evidence/final'/xml.name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(xml,p);xmls.append(dict(path=xml.name,**v))
assert counts==json.loads((final/'test-summary.json').read_text())['totals'] and counts['tests']>0 and not any(counts[k] for k in ['failures','errors','skipped'])
(raw/'parent-xml-recalculation.json').write_text(json.dumps(dict(totals=counts,classes=xmls,evidenceProvenance='Parent-generated XML independently read/summed by ontology; not ontology-executed application tests'),indent=2)+'\n')
for folder in ['jwt-http','http']:
    if (final/folder).exists():shutil.copytree(final/folder,raw/'parent-generated-evidence/final'/folder)
for filename in ['run.json','test-summary.json','cleanup.json','temporary-archives.json']:
    if (final/filename).exists():shutil.copy2(final/filename,raw/'parent-generated-evidence/final'/filename)
history=[]
for earlier in sorted(parent.iterdir()):
    if not earlier.is_dir() or earlier==final or not (earlier/'test-summary.json').exists():continue
    out=raw/'parent-generated-evidence/history'/earlier.name;out.mkdir(parents=True,exist_ok=True)
    for p in earlier.glob('TEST-*.xml'):shutil.copy2(p,out/p.name)
    for name in ['run.json','test-summary.json']:
        if (earlier/name).exists():shutil.copy2(earlier/name,out/name)
    if (earlier/'jwt-http').exists():shutil.copytree(earlier/'jwt-http',out/'jwt-http')
    history.append(dict(phase=earlier.name,summary=json.loads((earlier/'test-summary.json').read_text())))
(raw/'parent-run-history.json').write_text(json.dumps(history,indent=2)+'\n')
if len(sys.argv)>4:
    negative=Path(sys.argv[4]);s=json.loads((negative/'test-summary.json').read_text())
    assert s['totals']==dict(tests=13,failures=3,errors=0,skipped=0)
    test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveJwtHeadersTest.java'
    assert (negative/'source'/test).read_bytes()==get(candidate,test)==(final/'source'/test).read_bytes()
    oldInputs=['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']
    for path in oldInputs:assert (negative/'source'/path).read_bytes()==get(base,path)
    failed=[]
    for p in negative.glob('TEST-*.xml'):
        for f in ET.parse(p).getroot().iter('failure'):failed.append(dict(type=f.attrib.get('type'),message=f.attrib.get('message')))
    assert len(failed)==3 and all('Assertion' in x['type'] for x in failed)
    out=raw/'parent-generated-evidence/latest-negative';out.mkdir(parents=True,exist_ok=True)
    for name in ['run.json','test-summary.json']:
        shutil.copy2(negative/name,out/name)
    for p in negative.glob('TEST-*.xml'):shutil.copy2(p,out/p.name)
    shutil.copytree(negative/'jwt-http',out/'jwt-http')
    (raw/'latest-negative-source-binding.json').write_text(json.dumps(dict(sourceDirectory=str(negative),testSha256=sha(get(candidate,test)),sameByteHttpTest=True,oldProductInputsMatchBase=oldInputs,totals=s['totals'],failures=failed),indent=2)+'\n')
childDelta=Path('/tmp/edhr-header-jwt-ontology-finite-delta-20261107')
if childDelta.exists():
    m=json.loads((childDelta/'manifest.json').read_text())
    for item in m['files']:
        p=childDelta/item['path'];assert p.stat().st_size==item['bytes'] and sha(p.read_bytes())==item['sha256']
    shutil.copytree(childDelta,raw/'finite-authority-delta-role')
status=git('status','--porcelain')
verification=dict(recordedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=candidate,targetCommit=base,contractReadCommit=base,uncommittedContractPaths=[],workingTreeStatus=status,knowledgeUnchanged=350,knowledgeValidatorUnchanged=True,ownKnowledgeRuntimeTests=89,ownApplicationRuntimeTests=0,parentXmlRuntimeTests=counts['tests'],parentRuntimePhase=phase,parentEvidenceOutputLabel='parent-generated-evidence/final is a normalized accepted-run copy; original phase and paths are retained in run.json and this verification',parentRuntimeInputsMatchingCandidate=len(binding),unchangedSemanticInputs=unchanged,finiteReview=dict(records=10,consistent=8,evidenceGap=2,asyncDeltaIsSubsetNotUniqueIncrement=True),childStatus='completed/FINAL; original and ASYNC supplement preserved',wholeFilesCompleted=0,historicalUnique='unknown')
(raw/'final-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n')
sync=[dict(id='rule.dhr-summary-zip-source-trace',disposition='retained',scope='同一显式冻结版本、FULL/SELECTED、原件/摘要与缺失阻断保持；响应串行只交接临时副本。',sourceReferences=['docs/knowledge/rules/dhr-summary.yaml']),dict(id='DEC-0063-12',disposition='retained',scope='原view+export分权及流前EXPORT顺序保持；ASYNC按原Bearer执行原验签/权限恢复，不permitAll/session/放宽过期，不保证已发HTTP或生成审计回滚。',sourceReferences=['docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java']),dict(id='DEC-0090-01',disposition='retained',scope='汇总冻结、指定版本下载副本和放行后受控归档继续区分；本修复不创建归档状态。',sourceReferences=['docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml']),dict(id='DEC-0090-03',disposition='retained',scope='保存期限、自动销毁、跨租户访问、备份恢复及归档签署政策未由请求协调推导。',sourceReferences=['docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml']),dict(id='term.dhr-archive',disposition='retained',scope='specified/internal成熟度保持，不因JWT下载可靠性修复认定受控归档执行已交付。',sourceReferences=['docs/knowledge/glossary.yaml']),dict(id='question.multi-tenant-workflow-isolation',disposition='deferred',scope='原非MVP开放问题保持；合成JWT claims/key和mock协作者不认证实际登录目录/数据库全链或完整多租户隔离。本工程切片未新增政策问题。',sourceReferences=['docs/knowledge/open-questions.yaml'])]
def evidence(id,kind,command,items):return dict(id=id,checkType=kind,command=command,outcome='passed',evidence=items)
result=dict(result='not-applicable',baselineBefore='0.3.25',baselineAfter='0.3.25',contractBaseline=dict(sourceCommit=candidate,targetBranch='edhr-dev',targetCommit=base,contractReadCommit=base,uncommittedContractPaths=[]),reason='最终候选只协调DHR导出请求响应归属、ASYNC按原Bearer验签恢复权限，以及未开始body/未commit的异常响应清ZIP长度/类型并置inline供原500/JSON输出；WAITING/BODY/FAILED/CLEANED是临时资源工程状态，不是DHR业务状态。默认lazy/预览缓存、冻结/原件/hash、原分权及流前EXPORT保持，无新权限/超时/归档/保留政策，因此无需修改知识。',changedArtifacts=[],knowledgeSync=sync,conflicts=[],questions=[],validationEvidence=[evidence('validation.knowledge89','schema','bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test',['本角色实际89/89、0F/E/S；fresh XML及UTC时间原件保留。','knowledge-run.json','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml']),evidence('validation.finite-authority','reference','Read fixed authority IDs and ASYNC identity scope supplement',['有限10=8 consistent/2 evidence-gap；ASYNC补充仅原受影响子集，不增unique。','finite-audit-records.jsonl','finite-authority-delta-role/REVIEW.md']),evidence('validation.unchanged-maturity','status-transition','Compare 350 tracked knowledge files and validator/contract source with baseline and candidate',['350逐字节不变、原status/visibility/P0保持；知识0.3.25/schema1.2.0。','knowledge-fingerprints-final.json','final-verification.json']),evidence('validation.engineering-projection','projection','Read candidate filter/controller/security/JWT and unchanged source/audit/cache paths',['只核业务边界及父侧原件，不冒称本角色运行HTTP/PG/浏览器。','candidate-runtime.patch','parent-xml-recalculation.json','REVIEW.md']),evidence('validation.candidate-source-binding','evidence-path','fetch origin edhr-dev; compare fixed Git, runtime input snapshots and worktree',[f'目标仍{base}；{len(binding)}受测输入与候选Git/工作文件同字节。','parent-final-source-binding.json','final-verification.json','latest-negative-source-binding.json'])],roadmapProgress=dict(stage='P0',status='in-progress',exitCriteriaEvidence=[],deferredStages=['P1','P2','P3']))
(raw/'ontology-result.yaml').write_text(yaml.safe_dump(dict(ontologyResult=result),allow_unicode=True,sort_keys=False))
print(json.dumps(dict(candidate=candidate,knowledge=350,ownKnowledgeTests=89,parentXmlTests=counts['tests'],runtimeInputs=len(binding),workingTreeStatus=status),ensure_ascii=False,indent=2))
