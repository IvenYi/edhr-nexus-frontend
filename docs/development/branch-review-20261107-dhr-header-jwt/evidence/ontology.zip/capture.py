from pathlib import Path
import subprocess,hashlib,json,datetime,shutil,xml.etree.ElementTree as ET
root=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-header-jwt-ontology-20261107')
base='b6691e2c6289ab414a7a3fed1f128562cbba4166'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def get(path):return subprocess.check_output(['git','show',base+':'+path],cwd=root)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['AGENTS.md','codeplzreadme.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/rules/dhr-summary.yaml','docs/knowledge/glossary.yaml','docs/knowledge/schema.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtTokenProvider.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java','docs/development/branch-review-20261107-dhr-archive-async/header-risk-followup.md','tools/knowledge-model/pom.xml']
snap=[]
for path in paths:
    b=get(path);p=raw/'fixed-initial-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    snap.append(dict(path=path,bytes=len(b),sha256=sha(b)))
(raw/'fixed-initial-source-manifest.json').write_text(json.dumps(snap,indent=2)+'\n')
dp='docs/development/branch-review-20261107-dhr-header-jwt/decision-package.yaml';p=raw/'initial-working-context'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((root/dp).read_bytes())
inventory=[]
for path in git('ls-files','docs/knowledge').splitlines():
    b=get(path);current=(root/path).read_bytes();assert b==current,path
    inventory.append(dict(path=path,bytes=len(b),sha256=sha(b)))
assert len(inventory)==350
(raw/'knowledge-fingerprints-initial.json').write_text(json.dumps(inventory,indent=2)+'\n')
baseline=dict(readAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceCommit=base,headAtRead=git('rev-parse','HEAD'),targetCommit=git('rev-parse','origin/edhr-dev'),contractReadCommit=base,uncommittedContractPaths=[],workingTreeStatus=git('status','--porcelain'),knowledgeFiles=350,fixedSourceFiles=len(paths),workingContext=[dict(path=dp,bytes=p.stat().st_size,sha256=sha(p.read_bytes()))])
assert baseline['targetCommit']==base
(raw/'baseline.json').write_text(json.dumps(baseline,indent=2)+'\n')
command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test'];start=datetime.datetime.now(datetime.timezone.utc)
with (raw/'knowledge-validation.log').open('w') as log:r=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
xml=root/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'
assert xml.stat().st_mtime>=start.timestamp();shutil.copy2(xml,raw/xml.name);a=ET.parse(xml).getroot().attrib;summary={k:int(a.get(k,0)) for k in ['tests','failures','errors','skipped']}
(raw/'knowledge-run.json').write_text(json.dumps(dict(command=command,startedAtUTC=start.isoformat(),finishedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=r.returncode,summary=summary),indent=2)+'\n')
(raw/'knowledge-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert r.returncode==0 and summary==dict(tests=89,failures=0,errors=0,skipped=0)
print(json.dumps(dict(knowledge=summary,files=350,fixedSourceFiles=len(paths)),indent=2))
