from pathlib import Path
import subprocess,json,hashlib,datetime,yaml
r=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-header-jwt-ontology-finite-20261107');base='b6691e2c6289ab414a7a3fed1f128562cbba4166'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
def sha(b):return hashlib.sha256(b).hexdigest()
paths=['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/knowledge/decisions/DEC-0090-dhr-archive-minimum-scope.yaml','docs/knowledge/glossary.yaml','docs/knowledge/rules/dhr-summary.yaml']
snap=[];objects={}
for path in paths:
 b=git('show',base+':'+path);p=out/'fixed-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);snap.append(dict(path=path,bytes=len(b),sha256=sha(b)))
 if path.endswith('.yaml'):
  def walk(x):
   if isinstance(x,dict):
    if 'id' in x:objects[x['id']]=(path,x)
    for y in x.values():walk(y)
   elif isinstance(x,list):
    for y in x:walk(y)
  walk(yaml.safe_load(b))
(out/'fixed-source-manifest.json').write_text(json.dumps(dict(baseCommit=base,files=snap),indent=2)+'\n')
dp='docs/development/branch-review-20261107-dhr-header-jwt/decision-package.yaml';b=(r/dp).read_bytes();p=out/'working-context'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
(out/'working-context-manifest.json').write_text(json.dumps(dict(path=dp,bytes=len(b),sha256=sha(b),uncommitted=True),indent=2)+'\n')
notes=[
 ('rule.dhr-summary-zip-source-trace','rule','consistent','仅核header交接不改变同显式冻结版本、FULL/SELECTED、原件、摘要及缺失阻断；打印/数据库实际完整能力不由本项推定。'),
 ('DEC-0063-10','decision-statement','consistent','临时ZIP响应交接与受控源附件区分；原件字节/SHA/冻结引用、历史文件不物理删除保持，不借清理监视器获得源文件删除权。'),
 ('DEC-0063-11','decision-statement','consistent','目录/顺序/别名、原模板PDF、附件原件及同版范围定义保持；请求monitor不改变导出包业务结构或批准范围。'),
 ('DEC-0063-12','decision-statement','consistent','JWT读取/导出分权及DHR导出审计语义保持，流前EXPORT次序是既有实现边界；已发HTTP或生成审计不承诺回滚。'),
 ('DEC-0090-01','decision-statement','consistent','汇总冻结、下载指定版本副本、放行后受控归档三者继续区分，header竞态工程修复不产生已归档状态。'),
 ('DEC-0090-03','decision-statement','consistent','不从下载修复发明保存期限/自动销毁/跨租户规则/归档签名政策，备份恢复仍需后续独立证据。'),
 ('DEC-0090-04','decision-statement','consistent','不增加归档审批、解封或放行后更正能力，原TODO和不阻塞授权功能开发的范围保持。'),
 ('term.dhr-archive','term','consistent','保留specified/internal：请求局部同步和临时包传输不实现或提升受控归档执行成熟度。'),
 ('scenario.dhr-archive-minimum-evidence-and-access','acceptance-scenario','evidence-gap','本次header/临时副本测试不是放行后真实归档事务、权限、固定证据及备份恢复验证，完整场景保持待验；不阻断本工程修复。'),
 ('question.multi-tenant-workflow-isolation','open-question','evidence-gap','真实JWT签发/验签装配采用合成claims/key与mock仓库，未提供完整租户上下文/跨域隔离和历史迁移证据，原非MVP开放问题保持。')]
records=[]
for id,kind,conclusion,note in notes:
 path,obj=objects[id];maturity=dict(status=obj.get('status'),visibility=obj.get('visibility'))
 if kind=='acceptance-scenario':maturity.update(inheritedDecision='DEC-0090',inheritedStatus='specified',inheritedVisibility='internal')
 if kind=='open-question':maturity.update(statusFieldPresent=False,stateExplanation='listed in open-questions; no source status field')
 records.append(dict(id=id,recordType=kind,sourcePath=path,sourceLocator='id: '+id,originalAssetMaturity=maturity,auditScopeClassification='current-effective / directed engineering-boundary slice',semanticReviewStatus='reviewed',conclusion=conclusion,reviewScope=note,reviewedDefinitionsAndAdjacentRelations=['DP engineering scope only; source rules fixed at '+base,'temporary export copy vs frozen evidence vs controlled archive','synthetic JWT verification vs real login/directory/database/multi-tenant execution'],originalEvidenceReferences=['git:'+base+':'+path+'#'+id,'working-context/'+dp],runtimeValidation='none by this finite child; knowledge89 run owned by parent ontology; application/HTTP/PG and final independent QA owned elsewhere'))
(out/'records.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records))
result=dict(taskStatus='completed',finality='FINAL',role='read-only finite authority subreview, not final QA',sourceCommit=base,targetBranch='edhr-dev',targetCommit=base,contractReadCommit=base,knowledgeVersion='0.3.25',schemaVersion='1.2.0',roadmapStage='P0/in-progress',reviewedAtUTC=datetime.datetime.now(datetime.timezone.utc).isoformat(),fixedGitSourceFiles=len(paths),workingContextFiles=1,finiteRecords=len(records),conclusions=dict(consistent=8,evidenceGap=2),knowledgeModifications=[],applicationCodeModifications=[],testsRun=0,applicationHTTP=False,postgres=False,browser=False,CI=False,wholeFilesCompleted=0,historicalUnique='unknown',conflicts=[],questions=[],businessConclusion='No rule/policy conflict in proposed request-local header handoff scope; no business replacement or knowledge maturity change required',limits=['Engineering proposal reviewed, not final candidate implementation or runtime proof','Full archive lifecycle and backup/restore not verified','Synthetic JWT/mock collaborators do not close multi-tenant isolation','Original W2-W7/931 knowledge/86 UI/A12/high-risk/full matrices/A23 and paused queues retained'])
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
report='''# 固定权威资产有限核对\n\n正式 completed / FINAL。固定来源/目标/契约 b6691e2c6289ab414a7a3fed1f128562cbba4166，知识0.3.25/schema1.2.0/P0 in-progress。10份Git原件与未提交DP工作快照分开保存；未修改仓库、代码、测试、配置或知识，未运行应用/HTTP/PG/浏览器/CI或知识89。\n\n本项只核拟定工程修复的业务边界：导出请求局部monitor协调initial HeaderWriterFilter链与body，保留lazy/cache/JWT权限、CAS/TWR、源原件/摘要/冻结及EXPORT-before-stream。不确认最终实现或运行通过，不新增业务政策，也不把下载副本当受控归档。\n\n有限10条语义记录：8 consistent、2 evidence-gap，逐ID原始定义、成熟度、范围和来源见records.jsonl。8条一致只限工程边界，不能据此称整个DEC0063/0090或全本体完成。scenario.dhr-archive-minimum-evidence-and-access仍缺实际归档/恢复验证；question.multi-tenant-workflow-isolation仍开放，合成JWT claims/key与mock仓库不构成真实登录目录/数据库全HTTP链或完整多租户验收。\n\n无业务冲突或新问题需要用户决定。最终候选的filter范围、HEAD/context-path/无双注册、inline重入、completion不等待monitor及默认缓存/304/reset不变，由主侧源码/运行及全新质量实例验证，本子项不替代。请求局部同步不得拓展为新的归档、超时、重试或保留期政策。\n\n当前/历史知识成熟度保持，归档TODO及原W2-W7、931知识/86UI、A12/高风险/完整矩阵/A23含已审代码和暂停队列保留；本批整文件完成0、历史unique未知，不累计成全量语义覆盖。\n'''
(out/'REVIEW.md').write_text(report)
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
manifest=dict(taskStatus='completed',finality='FINAL',sourceCommit=base,files=[dict(path=str(p.relative_to(out)),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in files])
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for x in manifest['files']:assert sha((out/x['path']).read_bytes())==x['sha256']
h=sha((out/'manifest.json').read_bytes());(out/'manifest.sha256').write_text(h+'  manifest.json\n');print(json.dumps(dict(files=len(files),manifestSHA256=h,finiteRecords=10,consistent=8,evidenceGap=2),indent=2))
