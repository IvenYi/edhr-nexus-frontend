from pathlib import Path
import hashlib,json,shutil
raw=Path('/tmp/edhr-header-jwt-ontology-20261107');child=Path('/tmp/edhr-header-jwt-ontology-finite-20261107')
manifest=json.loads((child/'manifest.json').read_text())
for item in manifest['files']:
    p=child/item['path'];assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
shutil.copytree(child,raw/'finite-authority-role',dirs_exist_ok=False)
shutil.copy2(child/'records.jsonl',raw/'finite-audit-records.jsonl')
records=[json.loads(x) for x in (child/'records.jsonl').read_text().splitlines()]
summary=dict(records=len(records),consistent=sum(x['conclusion']=='consistent' for x in records),evidenceGap=sum(x['conclusion']=='evidence-gap' for x in records),wholeFilesCompleted=0,historicalUnique='unknown; directed IDs only, not new global unique count')
(raw/'finite-audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(raw/'child-finality.json').write_text(json.dumps(dict(task='/root/header_jwt_ontology/finite_authority',taskStatus='completed',finality='FINAL',manifestSHA256=hashlib.sha256((child/'manifest.json').read_bytes()).hexdigest(),verifiedMembers=len(manifest['files'])),indent=2)+'\n')
print(json.dumps(summary,indent=2))
