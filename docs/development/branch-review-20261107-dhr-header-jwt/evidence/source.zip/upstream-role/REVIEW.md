# 官方 HeaderWriterFilter 修复范围核查

只读有限源码子审，正式 completed / FINAL。项目 source/target/contractRead 固定 b6691e2c6289ab414a7a3fed1f128562cbba4166；知识 0.3.25/schema1.2.0/P0 in-progress。原件保存9份固定Git输入及本次实际下载的官方源码、提交、发布说明、POM和Maven元数据。未修改仓库产品、测试、配置、知识；未运行应用、HTTP、JWT、PG、浏览器或CI，不替代主侧产品链验证或最终质量。

## 可直接使用的结论

Spring Security 已有**确切的同类根因修复**：官方提交 [bdf501fe87daf07586a26ae9b442a2818578e90b](https://github.com/spring-projects/spring-security/commit/bdf501fe87daf07586a26ae9b442a2818578e90b)，标题 `Fix HeaderWriterFilter Race Condition`，关闭 gh-9175。作者时间2026-04-18，真正committer/合入时间为2026-09-03，不能用作者时间宣称当时已经发布。

该补丁在 `HeaderWriterResponse` 增加请求响应实例内的 `AtomicBoolean headersWritten`，由 `compareAndSet(false,true)` 领取原writer循环；没有把默认lazy改成eager。它直接针对servlet退出与异步首次commit两路径重复执行writer。此为官方源码证据，不是本审查运行过并发微例或产品HTTP。

在本次完整比对的7.0稳定版本0至8中，**7.0.8首次含该CAS，7.0.0至7.0.7均不含**；7.1.0/7.1.1不含，7.1.2含。官方7.0.8和7.1.2 release均在2026-10-22发布且非prerelease，发布说明明确列出该race修复。Maven元数据和7.0.8 POM也已实际取得，不只是未发布main上的修复。

但这不是当前Boot3.3项目的低风险单jar升级：7.0.8 POM引用security-core7.0.8及Spring Framework7.0.10；当前6.3.0 POM引用security-core6.3.0及Framework6.1.7，而项目实际Boot3.3安装Framework6.1.8。不能只把web jar替换为7.0.8并宣称兼容。不建议为此在当前切片扩大到跨主版本平台迁移。

本次取得6.3.0至6.3.10的全部源码，以及6.3.x/6.4.x/6.5.x分支、6.4.0至6.4.3、6.5.0至6.5.2及6.5.8至6.5.11：均无该CAS。6.3.0至6.3.10源码SHA完全相同，6.4.0至6.4.3及6.5.0至6.5.2亦同。**在所查当前6.x分支/发布版本里，没有发现可直接用于当前基线的已发布补丁**；此结论是有限查询范围，不声称每个商业6.x构建均已认证。

## 公开扩展点限制

已取6.3.0官方 `HeadersConfigurer.java`。`createHeaderWriterFilter()`先通过private `getHeaderWriters()`取得列表，直接new `HeaderWriterFilter(writers)`，然后只对整个filter调用 `postProcess`。各writer没有逐一postProcess，列表getter是private；`HeaderWriterFilter.writeHeaders(request,response)`为包级方法，内部 `HeaderWriterResponse` 也非公开替换点。因而“给每个现有默认writer加一次包装”并非当前公开配置API可直接完成。

`withObjectPostProcessor<HeaderWriterFilter>`确是公开入口，可设置现有eager选项或替换filter，但没有公开的原writer列表导出接口。本审查不建议反射private字段、不复制整套默认writer政策、不在异步Controller提前flush提交HTTP状态、不用同步Resource下载替代原async从而改变线程容量，也不建议复制两套认证链。具体保持现有语义的最小实现由主侧设计并验证，官方CAS可作为根因和预期行为证据，不能自动证明任何本地实现正确。

## 官方 workaround 与缓存风险相符

[issue9175](https://github.com/spring-projects/spring-security/issues/9175)有官方维护者 [2020-07-21 comment](https://github.com/spring-projects/spring-security/issues/9175#issuecomment-661879599)提供eager配置，同时明确警告：Controller自定义Cache-Control时，会残留先写入的其他缓存头如Expires。该警告与仓库FileController private,max-age=300边界一致，故全局eager不能被当作保持现有HTTP缓存策略的无差别开关。

issue中的其他用户SSE、StreamingResponseBody、Jetty/Tomcat及概率陈述只作为外部历史线索，未外推为本产品发生率、影响面或运行证据。当前产品JWT链是否可达、正常字节/状态/权限/预览CSP及缓存/304/reset、临时ZIP归属和EXPORT顺序是否保持，仍以主侧本轮真实配置运行及新的独立质量为准。即使官方补丁保留lazy时点，也不由本次源码审查宣称所有reset/include和网络并发场景均等价通过。

## 证据与限制

所有请求 URL、下载时间、HTTP结果、大小与SHA见 `official-fetches*.json`；实际原文见 `official/`。部分试探tag返回404（如6.3.11、6.5.12/13、7.1.3/4），明确保留，不把404写成源码结论。`comparison.json`记录实际逐文件CAS判断、7.0边界和POM依赖差异。API提交与release正文是原始外部证据；本报告推导“跨主版本升级不适合作单jar补丁”是基于实际POM的工程判断，未做二进制兼容运行测试。

本子项没有子代理或在途工作，未新增业务规则或提高知识成熟度，整文件完成0、历史unique未知。只完成有限官方源范围，原W2-W7/性能/容量/A23和暂停队列保持。
