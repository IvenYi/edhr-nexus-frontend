package com.zencas.edhr.compliance.controller;

import com.zencas.edhr.common.dto.ApiResponse;
import com.zencas.edhr.common.dto.PageResult;
import com.zencas.edhr.common.audit.AuditContext;
import com.zencas.edhr.common.exception.BusinessException;
import com.zencas.edhr.common.exception.ErrorCode;
import com.zencas.edhr.common.util.SnowflakeIdGenerator;
import com.zencas.edhr.compliance.entity.FileObject;
import com.zencas.edhr.compliance.repository.FileObjectRepository;
import com.zencas.edhr.identity.repository.UserAccountRepository;
import com.zencas.edhr.system.repository.IconAssetRepository;
import com.zencas.edhr.system.repository.SystemSettingRepository;
import jakarta.persistence.criteria.Predicate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;
import java.util.Set;

/**
 * File management controller for upload/download/preview/delete/list operations.
 * Complies with GMP compliance requirement C-09 for file/attachment storage.
 */
@Slf4j
@RestController
@RequestMapping("/api/v1/files")
@RequiredArgsConstructor
public class FileController {

    private final FileObjectRepository fileObjectRepository;
    private final IconAssetRepository iconAssetRepository;
    private final SystemSettingRepository systemSettingRepository;
    private final UserAccountRepository userAccountRepository;
    private final SnowflakeIdGenerator idGenerator;
    private final PlatformTransactionManager transactionManager;

    @Value("${edhr.file.storage-path:#{systemProperties['user.home'] + '/.edhr/files'}}")
    private String storagePath;

    /** Allowed MIME types for upload (whitelist). */
    private static final List<String> ALLOWED_MIME_TYPES = List.of(
            "application/pdf",
            "image/png", "image/jpeg", "image/webp", "image/gif",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "application/vnd.ms-powerpoint",
            "application/vnd.openxmlformats-officedocument.presentationml.presentation",
            "video/mp4", "video/webm", "video/quicktime",
            "text/plain", "text/csv",
            "application/zip"
    );

    private static final long MAX_FILE_SIZE = 150L * 1024 * 1024; // 150 MB
    private static final Set<String> PUBLIC_PREVIEW_TARGET_TYPES = Set.of("ICON_ASSET", "SYSTEM_LOGO", "SYSTEM_FAVICON", "USER_AVATAR");

    // ======================== Upload ========================

    /**
     * Upload a file and register it in the database.
     */
    @PostMapping("/upload")
    public ApiResponse<Map<String, Object>> upload(
            @RequestParam("file") MultipartFile file,
            @RequestParam(value = "targetType", required = false) String targetType,
            @RequestParam(value = "targetId", required = false) String targetId) throws IOException {

        if (file.isEmpty()) {
            throw new BusinessException(ErrorCode.GENERAL_001, "上传文件不能为空");
        }
        if ("FORM_TEMPLATE_BACKGROUND".equals(targetType)) {
            throw new BusinessException(ErrorCode.GENERAL_003, "表单模板背景文件只能由模板导入生成");
        }
        if (file.getSize() > MAX_FILE_SIZE) {
            throw new BusinessException(ErrorCode.FILE_002,
                    "文件大小超出限制: " + (file.getSize() / 1024 / 1024) + "MB (最大 150MB)");
        }
        String contentType = file.getContentType();
        if (contentType == null || !ALLOWED_MIME_TYPES.contains(contentType)) {
            throw new BusinessException(ErrorCode.FILE_003,
                    "不支持的文件类型: " + contentType);
        }

        // Compute MD5
        String md5Hash;
        try (InputStream input = file.getInputStream()) {
            md5Hash = computeMd5(input);
        }

        // Ensure storage directory exists
        Path storageDir = Path.of(storagePath);
        Files.createDirectories(storageDir);

        // Generate stored name: {id}_{originalName}
        long fileId = idGenerator.nextId();
        String storedName = fileId + "_" + sanitizeFileName(file.getOriginalFilename());
        Path targetPath = storageDir.resolve(storedName);
        // Reserve a new path before taking cleanup ownership; never replace an existing original.
        Files.createFile(targetPath);
        try {
            try (InputStream input = file.getInputStream();
                 OutputStream output = Files.newOutputStream(targetPath, StandardOpenOption.WRITE)) {
                input.transferTo(output);
            }
        } catch (IOException | RuntimeException failure) {
            try {
                Files.deleteIfExists(targetPath);
            } catch (IOException | RuntimeException cleanupFailure) {
                failure.addSuppressed(cleanupFailure);
                log.warn("Failed to remove incomplete upload: {}", targetPath, cleanupFailure);
            }
            throw failure;
        }

        FileObject fileObject = FileObject.builder()
                .id(fileId)
                .originalName(file.getOriginalFilename())
                .storedPath(targetPath.toString())
                .mimeType(contentType)
                .fileSize(file.getSize())
                .md5Hash(md5Hash)
                .targetType(targetType)
                .targetId(targetId)
                .uploadedBy(getCurrentOperatorId())
                .createdAt(LocalDateTime.now())
                .build();
        registerUploadedFile(fileObject, targetPath);

        log.info("File uploaded: id={}, originalName={}, size={}", fileId,
                file.getOriginalFilename(), file.getSize());
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("id", String.valueOf(fileObject.getId()));
        response.put("fileId", String.valueOf(fileObject.getId()));
        response.put("originalName", fileObject.getOriginalName());
        response.put("targetType", fileObject.getTargetType());
        response.put("targetId", fileObject.getTargetId());
        response.put("mimeType", fileObject.getMimeType());
        response.put("fileSize", fileObject.getFileSize());
        response.put("previewUrl", "/api/v1/files/" + fileObject.getId() + "/public-preview");
        return ApiResponse.success(response);
    }

    // ======================== Download ========================

    /**
     * Download a file as attachment (Content-Disposition: attachment).
     */
    @GetMapping("/{id}/download")
    public ResponseEntity<Resource> download(@PathVariable Long id) {
        FileObject fileObject = fileObjectRepository.findById(id)
                .orElseThrow(() -> new BusinessException(ErrorCode.FILE_001));

        Path filePath = Path.of(fileObject.getStoredPath());
        if (!Files.exists(filePath)) {
            throw new BusinessException(ErrorCode.FILE_001, "文件物理存储丢失: " + id);
        }

        Resource resource = new FileSystemResource(filePath);
        String encodedName = encodeFileName(fileObject.getOriginalName());

        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" + encodedName + "\"; filename*=UTF-8''" + encodedName)
                .header(HttpHeaders.CONTENT_LENGTH, String.valueOf(fileObject.getFileSize()))
                .body(resource);
    }

    // ======================== Preview ========================

    /**
     * Preview a file inline (Content-Disposition: inline).
     */
    @GetMapping("/{id}/preview")
    public ResponseEntity<Resource> preview(@PathVariable Long id) {
        FileObject fileObject = fileObjectRepository.findById(id)
                .orElseThrow(() -> new BusinessException(ErrorCode.FILE_001));

        return buildInlinePreviewResponse(fileObject);
    }

    /** Render PDF pages for browsers without an embedded PDF viewer. */
    @GetMapping("/{id}/page-preview")
    public ResponseEntity<?> pagePreview(@PathVariable Long id, @RequestParam(defaultValue = "1") int page) throws IOException {
        FileObject file = fileObjectRepository.findById(id).orElseThrow(() -> new BusinessException(ErrorCode.FILE_001));
        if (!"application/pdf".equals(file.getMimeType())) return buildInlinePreviewResponse(file);
        Path path = Path.of(file.getStoredPath());
        if (!Files.exists(path)) throw new BusinessException(ErrorCode.FILE_001);
        try (var document = org.apache.pdfbox.Loader.loadPDF(path.toFile())) {
            if (page < 1 || page > document.getNumberOfPages()) throw new BusinessException(ErrorCode.GENERAL_001, "文件页码超出范围");
            var rendered = new org.apache.pdfbox.rendering.PDFRenderer(document).renderImageWithDPI(page - 1, 110);
            var bytes = new java.io.ByteArrayOutputStream();
            javax.imageio.ImageIO.write(rendered, "png", bytes);
            return ResponseEntity.ok().contentType(MediaType.IMAGE_PNG)
                .header(HttpHeaders.CACHE_CONTROL, "private, max-age=300")
                .header("X-Page-Count", String.valueOf(document.getNumberOfPages())).body(bytes.toByteArray());
        }
    }

    /**
     * Public inline preview for UI assets that must render inside browser image tags.
     */
    @GetMapping("/{id}/public-preview")
    public ResponseEntity<Resource> publicPreview(@PathVariable Long id) {
        FileObject fileObject = fileObjectRepository.findById(id)
                .orElseThrow(() -> new BusinessException(ErrorCode.FILE_001));
        if (!canPublicPreview(fileObject)) {
            throw new BusinessException(ErrorCode.GENERAL_003, "文件不允许公开预览");
        }

        return buildInlinePreviewResponse(fileObject);
    }

    private boolean canPublicPreview(FileObject fileObject) {
        if (fileObject.getTargetType() == null || !PUBLIC_PREVIEW_TARGET_TYPES.contains(fileObject.getTargetType())) return false;
        Long fileId = fileObject.getId();
        if ("ICON_ASSET".equals(fileObject.getTargetType())) {
            return iconAssetRepository.existsByFileId(fileId);
        }
        if ("USER_AVATAR".equals(fileObject.getTargetType())) {
            return userAccountRepository.existsByAvatarFileId(fileId);
        }
        return systemSettingRepository.existsBySystemLogoFileIdOrBrowserIconFileId(fileId, fileId);
    }

    private ResponseEntity<Resource> buildInlinePreviewResponse(FileObject fileObject) {
        Path filePath = Path.of(fileObject.getStoredPath());
        if (!Files.exists(filePath)) {
            throw new BusinessException(ErrorCode.FILE_001, "文件物理存储丢失: " + fileObject.getId());
        }

        Resource resource = new FileSystemResource(filePath);
        MediaType mediaType = resolveMediaType(fileObject.getMimeType());

        return ResponseEntity.ok()
                .contentType(mediaType)
                .header(HttpHeaders.CACHE_CONTROL, "private, max-age=300")
                .header("X-Content-Type-Options", "nosniff")
                .header("Content-Security-Policy", "default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; script-src 'none'; sandbox")
                .header(HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + encodeFileName(fileObject.getOriginalName()) + "\"")
                .body(resource);
    }

    // ======================== Delete ========================

    /**
     * Delete a file (both DB record and physical storage).
     */
    @DeleteMapping("/{id}")
    public ApiResponse<Void> delete(@PathVariable Long id) {
        return new TransactionTemplate(transactionManager).execute(transaction -> {
            FileObject fileObject = fileObjectRepository.findById(id)
                    .orElseThrow(() -> new BusinessException(ErrorCode.FILE_001));
            if ("PRODUCTION_EXECUTION".equals(fileObject.getTargetType()))
                throw new BusinessException(ErrorCode.GENERAL_003, "生产执行附件作为追溯证据保留，不能删除");
            if ("SIGNATURE_EVIDENCE".equals(fileObject.getTargetType()))
                throw new BusinessException(ErrorCode.GENERAL_003, "电子签名认证材料作为追溯证据保留，不能删除");
            Path filePath = Path.of(fileObject.getStoredPath());
            TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                @Override public void afterCommit() {
                    try {
                        Files.deleteIfExists(filePath);
                        log.info("File deletion committed: id={}, originalName={}", id, fileObject.getOriginalName());
                    } catch (IOException cleanupFailure) {
                        log.error("File record deletion committed but original cleanup failed: id={}, path={}", id, filePath, cleanupFailure);
                        throw new UncheckedIOException("File record deletion committed but original cleanup failed", cleanupFailure);
                    }
                }
                @Override public void afterCompletion(int status) {
                    if (status == STATUS_UNKNOWN)
                        log.error("File deletion transaction outcome unknown; original retained: id={}, path={}", id, filePath);
                }
            });
            fileObjectRepository.deleteById(id);
            return ApiResponse.success(null);
        });
    }

    // ======================== List ========================

    /**
     * List files with optional filtering by targetType and/or targetId.
     */
    @GetMapping
    public ApiResponse<PageResult<FileObject>> list(
            @RequestParam(value = "targetType", required = false) String targetType,
            @RequestParam(value = "targetId", required = false) String targetId,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "createdAt") String sort,
            @RequestParam(defaultValue = "desc") String order) {

        Sort.Direction direction = "asc".equalsIgnoreCase(order) ? Sort.Direction.ASC : Sort.Direction.DESC;
        PageRequest pageable = PageRequest.of(page - 1, size, Sort.by(direction, sort));

        Specification<FileObject> spec = (root, query, cb) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (targetType != null && !targetType.isBlank()) {
                predicates.add(cb.equal(root.get("targetType"), targetType));
            }
            if (targetId != null && !targetId.isBlank()) {
                predicates.add(cb.equal(root.get("targetId"), targetId));
            }
            return cb.and(predicates.toArray(new Predicate[0]));
        };

        Page<FileObject> result = fileObjectRepository.findAll(spec, pageable);
        return ApiResponse.success(PageResult.of(
                result.getContent(), page, size, result.getTotalElements()));
    }

    // ======================== Helpers ========================

    private void registerUploadedFile(FileObject file, Path ownedPath) {
        boolean[] completionRegistered = {false};
        try {
            new TransactionTemplate(transactionManager).executeWithoutResult(transaction -> {
                TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
                    @Override public void afterCompletion(int status) {
                        if (status == STATUS_ROLLED_BACK) {
                            try {
                                Files.deleteIfExists(ownedPath);
                            } catch (IOException | RuntimeException cleanupFailure) {
                                log.error("Failed to remove rolled-back upload: id={}, path={}", file.getId(), ownedPath, cleanupFailure);
                            }
                        } else if (status == STATUS_UNKNOWN) {
                            log.error("Upload transaction outcome unknown; original retained: id={}, path={}", file.getId(), ownedPath);
                        }
                    }
                });
                completionRegistered[0] = true;
                fileObjectRepository.save(file);
            });
        } catch (RuntimeException failure) {
            // No synchronization means database registration was never reached (e.g. connection unavailable).
            if (!completionRegistered[0]) {
                try {
                    Files.deleteIfExists(ownedPath);
                } catch (IOException | RuntimeException cleanupFailure) {
                    failure.addSuppressed(cleanupFailure);
                    log.error("Failed to remove upload before registration: id={}, path={}", file.getId(), ownedPath, cleanupFailure);
                }
            }
            throw failure;
        }
    }

    private String computeMd5(InputStream inputStream) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                md.update(buffer, 0, bytesRead);
            }
            return HexFormat.of().formatHex(md.digest());
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException("MD5 algorithm unavailable", e);
        }
    }

    private String sanitizeFileName(String name) {
        if (name == null) return "unnamed";
        return name.replaceAll("[^a-zA-Z0-9._\\-\\u4e00-\\u9fff]", "_");
    }

    private String encodeFileName(String name) {
        if (name == null) return "file";
        try {
            return java.net.URLEncoder.encode(name, "UTF-8")
                    .replace("+", "%20");
        } catch (Exception e) {
            return "file";
        }
    }

    private MediaType resolveMediaType(String mimeType) {
        if (mimeType == null) return MediaType.APPLICATION_OCTET_STREAM;
        try {
            return MediaType.parseMediaType(mimeType);
        } catch (Exception e) {
            return MediaType.APPLICATION_OCTET_STREAM;
        }
    }

    /** Use the authenticated request identity; retain the legacy fallback for direct internal calls. */
    private String getCurrentOperatorId() {
        String operatorId = AuditContext.getOperatorId();
        return operatorId != null ? operatorId : "system";
    }
}
