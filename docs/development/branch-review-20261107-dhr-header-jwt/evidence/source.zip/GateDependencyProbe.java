import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.web.header.HeaderWriter;
import org.springframework.security.web.header.HeaderWriterFilter;

/** Dependency-only scheduling proof, not the application JWT/Tomcat chain or proposed product implementation. */
public class GateDependencyProbe {
    static Map<String,Object> asynchronousGate() throws Exception {
        Object monitor=new Object();
        AtomicInteger calls=new AtomicInteger(),active=new AtomicInteger(),maximum=new AtomicInteger();
        AtomicBoolean initialExited=new AtomicBoolean(),workerObservedExit=new AtomicBoolean();
        AtomicReference<Throwable> failure=new AtomicReference<>();
        CountDownLatch attempted=new CountDownLatch(1);
        HeaderWriter writer=(request,response)->{
            calls.incrementAndGet();int n=active.incrementAndGet();maximum.accumulateAndGet(n,Math::max);
            try {response.setHeader("X-Probe","unchanged");} finally {active.decrementAndGet();}
        };
        HeaderWriterFilter filter=new HeaderWriterFilter(List.of(writer));
        var request=new MockHttpServletRequest("GET","/dependency-probe");var response=new MockHttpServletResponse();
        AtomicReference<Thread> thread=new AtomicReference<>();
        synchronized(monitor){
            filter.doFilter(request,response,(req,res)->{
                var wrapped=(HttpServletResponse)res;wrapped.setContentLength(1);
                Thread t=new Thread(()->{
                    attempted.countDown();
                    synchronized(monitor){
                        try {workerObservedExit.set(initialExited.get());wrapped.getOutputStream().write(1);}
                        catch(Throwable ex){failure.set(ex);}
                    }
                },"gate-worker");thread.set(t);t.start();
                try {if(!attempted.await(2,TimeUnit.SECONDS))throw new AssertionError("worker did not attempt gate");}
                catch(InterruptedException ex){throw new RuntimeException(ex);}
            });
            if(calls.get()!=1)throw new AssertionError("initial filter must write before gate release");
            initialExited.set(true);
        }
        thread.get().join(2000);
        if(thread.get().isAlive()||failure.get()!=null)throw new AssertionError("worker unfinished/failed",failure.get());
        if(!workerObservedExit.get()||maximum.get()!=1||calls.get()!=2)throw new AssertionError("wrong writer scheduling");
        if(response.getContentAsByteArray().length!=1)throw new AssertionError("wrong bytes");
        return Map.of("case","gate-worker-after-initial-exit","passed",true,"writerCalls",calls.get(),"maxConcurrent",maximum.get(),"workerObservedInitialExit",workerObservedExit.get());
    }
    static Map<String,Object> inlineGate() throws Exception {
        Object monitor=new Object();AtomicInteger bytes=new AtomicInteger();
        HeaderWriterFilter filter=new HeaderWriterFilter(List.of((req,res)->res.setHeader("X-Probe","unchanged")));
        synchronized(monitor){
            filter.doFilter(new MockHttpServletRequest(),new MockHttpServletResponse(),(req,res)->{
                // Inline executors run on the current servlet thread; intrinsic monitors are reentrant.
                synchronized(monitor){((HttpServletResponse)res).getOutputStream().write(1);bytes.incrementAndGet();}
            });
        }
        if(bytes.get()!=1)throw new AssertionError("inline body failed");
        return Map.of("case","same-thread-inline-reentrant","passed",true,"bodyCopies",bytes.get());
    }
    static Map<String,Object> completedBeforeGateRelease() throws Exception {
        Object monitor=new Object();AtomicBoolean claimed=new AtomicBoolean(),lateRejected=new AtomicBoolean();
        AtomicInteger copies=new AtomicInteger();CountDownLatch attempted=new CountDownLatch(1);Thread worker;
        synchronized(monitor){
            worker=new Thread(()->{attempted.countDown();synchronized(monitor){if(!claimed.compareAndSet(false,true)){lateRejected.set(true);return;}copies.incrementAndGet();}},"late-gate-worker");worker.start();
            if(!attempted.await(2,TimeUnit.SECONDS))throw new AssertionError("no attempt");
            // Completion owns cleanup without waiting on the monitor held by initial filter chain.
            if(!claimed.compareAndSet(false,true))throw new AssertionError("completion failed to claim");
        }
        worker.join(2000);
        if(worker.isAlive()||!lateRejected.get()||copies.get()!=0)throw new AssertionError("late task was not rejected");
        return Map.of("case","completion-before-gate-release-late-body-rejected","passed",true,"copies",copies.get());
    }
    static Map<String,List<String>> headers(boolean gated,boolean secure,String mode)throws Exception{
        // The old helper reads installed defaults reflectively for observation only, never a production proposal.
        HeaderWriterFilter filter=new HeaderWriterFilter(HeaderWriterConcurrencyProbe.defaults());
        var request=new MockHttpServletRequest();request.setSecure(secure);var response=new MockHttpServletResponse();
        jakarta.servlet.FilterChain chain=(req,res)->{var http=(HttpServletResponse)res;
            if(mode.equals("304"))http.setStatus(304);
            if(mode.equals("custom-cache"))http.setHeader("Cache-Control","private, max-age=300");
            if(mode.equals("reset"))http.reset();
        };
        if(gated){synchronized(new Object()){filter.doFilter(request,response,chain);}}
        else filter.doFilter(request,response,chain);
        Map<String,List<String>> out=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for(String name:response.getHeaderNames())out.put(name,new ArrayList<>(response.getHeaders(name)));
        return out;
    }
    public static void main(String[] args)throws Exception{
        System.out.println(HeaderWriterConcurrencyProbe.json(asynchronousGate()));
        System.out.println(HeaderWriterConcurrencyProbe.json(inlineGate()));
        System.out.println(HeaderWriterConcurrencyProbe.json(completedBeforeGateRelease()));
        for(boolean secure:List.of(false,true))for(String mode:List.of("normal","304","custom-cache","reset")){
            var old=headers(false,secure,mode);var gated=headers(true,secure,mode);
            if(!old.equals(gated))throw new AssertionError("header policy changed "+mode);
            System.out.println(HeaderWriterConcurrencyProbe.json(Map.of("case","gate-headers-"+mode,"secure",secure,"headers",gated,"equal",true,"passed",true)));
        }
    }
}
