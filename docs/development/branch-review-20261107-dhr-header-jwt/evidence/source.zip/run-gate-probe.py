from pathlib import Path
import subprocess,json,hashlib,datetime
out=Path('/tmp/edhr-header-jwt-source-20261107');m2=Path('/workspace/.pr6-m2')
patterns=['org/springframework/security/spring-security-web/6.3.0/*.jar','org/springframework/security/spring-security-config/6.3.0/*.jar','org/springframework/security/spring-security-core/6.3.0/*.jar','org/springframework/spring-core/6.1.8/*.jar','org/springframework/spring-web/6.1.8/*.jar','org/springframework/spring-test/6.1.8/*.jar','org/springframework/spring-beans/6.1.8/*.jar','org/springframework/spring-jcl/6.1.8/*.jar','org/apache/tomcat/embed/tomcat-embed-core/10.1.24/*.jar','org/springframework/spring-context/6.1.8/*.jar','org/springframework/spring-aop/6.1.8/*.jar','org/springframework/spring-expression/6.1.8/*.jar']
jars=[]
for pattern in patterns:
    found=list(m2.glob(pattern));assert len(found)==1,(pattern,found);jars+=found
cp=':'.join(map(str,jars));classes=out/'classes';classes.mkdir(exist_ok=True)
commands=[['/workspace/.edhr-cloud-tools/jdk-21/bin/javac','-cp',cp,'-d',str(classes),str(out/'prior-source/HeaderWriterConcurrencyProbe.java'),str(out/'GateDependencyProbe.java')],['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-cp',str(classes)+':'+cp,'GateDependencyProbe']]
result=[]
for index,command in enumerate(commands):
    p=subprocess.run(command,capture_output=True,text=True)
    (out/f'probe-{index}.stdout').write_text(p.stdout);(out/f'probe-{index}.stderr').write_text(p.stderr)
    result.append(dict(command=command,exitCode=p.returncode))
    (out/'gate-probe-run.json').write_text(json.dumps({'recordedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'commands':result,'dependencies':[dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in jars]},indent=2)+'\n')
    assert p.returncode==0,p.stderr
print((out/'probe-1.stdout').read_text())
