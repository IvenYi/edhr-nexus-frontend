import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.web.header.HeaderWriter;
import org.springframework.security.web.header.HeaderWriterFilter;

public class HeaderWriterConcurrencyProbe {
    static Map<String,Object> concurrency(boolean eager) throws Exception {
        AtomicInteger calls = new AtomicInteger(), active = new AtomicInteger(), maxActive = new AtomicInteger();
        CountDownLatch firstEntry = new CountDownLatch(1);
        CyclicBarrier twoWriters = new CyclicBarrier(2);
        AtomicReference<Throwable> workerFailure = new AtomicReference<>();
        List<String> threads = new CopyOnWriteArrayList<>();
        HeaderWriter writer = (request, response) -> {
            calls.incrementAndGet(); threads.add(Thread.currentThread().getName());
            int n=active.incrementAndGet(); maxActive.accumulateAndGet(n, Math::max);firstEntry.countDown();
            try { if(!eager) twoWriters.await(5, TimeUnit.SECONDS); }
            catch(Exception ex) { throw new RuntimeException(ex); }
            finally {active.decrementAndGet();}
        };
        HeaderWriterFilter filter = new HeaderWriterFilter(List.of(writer));
        filter.setShouldWriteHeadersEagerly(eager);
        MockHttpServletRequest request = new MockHttpServletRequest("GET","/dependency-probe");
        MockHttpServletResponse response = new MockHttpServletResponse();
        AtomicReference<Thread> worker = new AtomicReference<>();
        filter.doFilter(request,response,(req,res)->{
            HttpServletResponse wrapped=(HttpServletResponse)res;
            wrapped.setContentLength(1);
            Thread t=new Thread(()->{
                try { wrapped.getOutputStream().write(1); }
                catch(Throwable ex){workerFailure.set(ex);}
            },"probe-worker");worker.set(t);t.start();
            if(!eager) {
                try { if(!firstEntry.await(5,TimeUnit.SECONDS)) throw new AssertionError("worker not in header writer"); }
                catch(InterruptedException ex){Thread.currentThread().interrupt();throw new RuntimeException(ex);}
            }
            // Return while the worker owns the lazy commit callback; filter finally also writes.
        });
        worker.get().join(5000);
        if(worker.get().isAlive())throw new AssertionError("worker did not finish");
        if(workerFailure.get()!=null)throw new AssertionError("worker failed",workerFailure.get());
        boolean passed=eager ? calls.get()==1&&maxActive.get()==1 : calls.get()==2&&maxActive.get()==2;
        if(!passed)throw new AssertionError("unexpected scheduling: "+calls+"/"+maxActive);
        Map<String,Object> out=new LinkedHashMap<>();out.put("case",eager?"eager-one-pre-chain-writer":"lazy-two-concurrent-writers");out.put("calls",calls.get());out.put("maxConcurrent",maxActive.get());out.put("threads",threads);out.put("passed",passed);return out;
    }
    @SuppressWarnings("unchecked")
    static List<HeaderWriter> defaults() throws Exception {
        HeadersConfigurer<?> configurer=new HeadersConfigurer<>();
        Method m=HeadersConfigurer.class.getDeclaredMethod("getHeaderWriters");m.setAccessible(true);
        return (List<HeaderWriter>)m.invoke(configurer);
    }
    static Map<String,List<String>> headers(boolean eager, boolean secure, String mode) throws Exception {
        HeaderWriterFilter filter=new HeaderWriterFilter(defaults());filter.setShouldWriteHeadersEagerly(eager);
        MockHttpServletRequest request=new MockHttpServletRequest("GET","/dependency-probe");request.setSecure(secure);
        MockHttpServletResponse response=new MockHttpServletResponse();
        filter.doFilter(request,response,(req,res)->{
            HttpServletResponse http=(HttpServletResponse)res;
            if(mode.equals("304"))http.setStatus(304);
            if(mode.equals("custom-cache"))http.setHeader("Cache-Control","private, max-age=60");
            if(mode.equals("reset"))http.reset();
        });
        Map<String,List<String>> result=new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for(String name:response.getHeaderNames())result.put(name,new ArrayList<>(response.getHeaders(name)));
        return result;
    }
    static String json(Object value) {
        if(value==null)return "null";
        if(value instanceof Number||value instanceof Boolean)return value.toString();
        if(value instanceof Map<?,?> map){StringJoiner s=new StringJoiner(",","{","}");map.forEach((k,v)->s.add(json(k.toString())+":"+json(v)));return s.toString();}
        if(value instanceof Collection<?> collection){StringJoiner s=new StringJoiner(",","[","]");for(Object v:collection)s.add(json(v));return s.toString();}
        return "\""+value.toString().replace("\\","\\\\").replace("\"","\\\"")+"\"";
    }
    public static void main(String[] args)throws Exception {
        System.out.println(json(concurrency(false)));System.out.println(json(concurrency(true)));
        for(boolean secure:List.of(false,true))for(String mode:List.of("normal","304","custom-cache","reset")){
            Map<String,List<String>> lazy=headers(false,secure,mode),eager=headers(true,secure,mode);
            boolean equal=lazy.equals(eager),expected=mode.equals("normal");
            if(equal!=expected)throw new AssertionError("unexpected equivalence "+secure+" "+mode);
            Map<String,Object> out=new LinkedHashMap<>();out.put("case","default-headers-"+mode);out.put("secure",secure);out.put("equal",equal);out.put("lazy",lazy);out.put("eager",eager);out.put("passed",true);System.out.println(json(out));
        }
    }
}
