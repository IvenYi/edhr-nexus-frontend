# Read-only source quality review — FINAL

Result: passed for the assigned source-inspection subtask. No reproducible delivery finding was identified. This child ran no tests and did not modify application sources, tests, fixtures, configuration, assertions, or shared build outputs. The parent quality instance owns the fresh 125 + 89 execution and overall quality result.

Base/target: edhr-dev@b6691e2c6289ab414a7a3fed1f128562cbba4166. Candidate and actual read HEAD: 703f2ee90417e778cf745fbbcd24f908a345d3bd. Contract files and knowledge assets have no delta in that interval. The base tree equals 45858291's tree. Knowledge remains 0.3.25/schema 1.2.0/P0; the declared 350-asset knowledge baseline is unchanged, without claiming semantic re-audit of all 350 assets.

The worktree was dirty during inspection solely because the parent quality instance installed the excluded dependency symlink gmp-platform/frontend/node_modules -> /workspace/edhr-nexus-frontend/gmp-platform/frontend/node_modules. The source-evidence record reports this actual state; it does not claim clean. Thirty inspected documents/source inputs were independently fingerprinted and all match candidate Git bytes.

## Response handoff and ownership

DhrArchiveResponseFilter is instantiated once inside SecurityConfig's SecurityFilterChain, before HeaderWriterFilter. It has neither a component annotation nor a Filter bean. The original default lazy header writers, authorization configuration, stateless session setting, and public-preview allowlist remain unchanged. A source search found no second production registration or eager-header override.

The Ant matcher names only the DHR version export path; it uses servlet path/path info, so the context path is excluded. Existing @GetMapping also accepts HEAD. The new direct tests inspect GET and HEAD under /header-audit, and the real HTTP fixture configures that same non-root context path. Other HTTP verbs at the same exact path also enter the harmless gate, but the controller still only accepts GET/HEAD; no handler permission or verb is added. File preview endpoints do not match.

Each initial export request creates its own ResponseHandoff and request attribute. The synchronized block surrounds the downstream initial chain, so a worker waits until HeaderWriterFilter's finally path has returned. The body synchronizes on that same object and performs WAITING -> BODY before entering the original Files.copy/TWR cleanup. Java monitor reentrancy permits the inline executor case without an interthread handoff. No static/global monitor, cross-request registry, retry loop, or SQL was added.

The four states encode resource ownership rather than a DHR business lifecycle: WAITING can become BODY, FAILED, or CLEANED; FAILED can become CLEANED. Completion does not take the monitor. Its CAS can clean a waiting/failed archive and make a late worker's claim fail; a BODY claim excludes callback deletion. Repeated completion cannot consume a replacement path. Async error dispatch does not wait for the monitor and can only claim FAILED before a body starts and before commit. It resets the Servlet content length through setContentLengthLong(-1), explicitly changes disposition to inline, and clears ZIP content type before the original handler writes JSON. BODY and committed responses are left to their existing streaming/error behavior.

The streaming TWR retains the primary output IOException/runtime failure and suppresses delete failure. Callback/metadata cleanup still deletes only the owned path, catches IOException/runtime cleanup faults, adds suppression when a primary failure exists, and logs failures without recursive deletion. Service generation/audit cleanup remains unchanged. The preexisting tests inspect primary identity, suppression, exact output, repeated completion, copy-time completion, and cleanup failure; this child inspected their assertions without executing them.

## Authentication and adjacent contracts

JwtAuthenticationFilter only adds shouldNotFilterAsyncDispatch=false. ASYNC dispatch therefore follows the original Bearer extraction, current validateToken, subject/display name/permission parsing, userId request attribute, AuditContext installation, and finally clear. JwtTokenProvider is byte-identical to base and still parses/verifies signed claims with the current clock, without an expiration allowance or alternate parser. SecurityConfig's permitAll list, ERROR-dispatch defaults, method permissions, and stateless configuration are unchanged. The added ASYNC fixtures check restoration of the exact identity/permission and invalid-token non-authentication. The existing signed-expired-fixture test remains a current-parser check rather than a natural-expiry long-queue experiment.

DhrArchiveController still requires both dhr.instances.view and dhr.summaries.export before invoking the unchanged service. The service completes frozen content, archive creation, hash, and EXPORT save before returning the path to the controller, hence before body output. No new promise to roll back HTTP bytes or generated audit was introduced. FULL/SELECTED parsing, source/frozen version, attachment bytes/hash, and PDF/ZIP service behavior remain outside the four product-file changes.

FileController is identical to base: authenticated/private PNG, eligible anonymous public PNG, and PDF-page PNG responses retain private, max-age=300. The real-HTTP tests assert this exact value and absence of Pragma/Expires on all three, while importing the actual controller; the two static PNG paths also assert their security/CSP headers. No cache policy, synchronous Resource behavior, dependency, schema, migration, UI, signing policy, or permission expansion appears in the product diff.

## A23, impact review, and knowledge

The requested product-core path is coherent: the DHR-specific filter owns response handoff, the controller owns the body/cleanup claim, and JWT keeps its existing identity logic. The new handoff object replaces the former boolean ownership rather than stacking an independent state flag. Its two cleanup CAS operations cover the observed WAITING/FAILED states without retries or a second cleanup owner. Coupling is confined to the local controller/filter package plus SecurityConfig registration; the long export service is not refactored incidentally.

The L2 decision package covers direct response/JWT/framing impact, security-chain placement, non-interruptible waiting, unchanged caches and frozen evidence, no persistence/migration, unchanged pre-body audit and permission rules, and the test/environment gaps. Inspection found those statements consistent with the actual diff. Proposed future service extraction remains a design note and was not implemented here; performance/pagination policies remain deferred as documented.

DEC-0063-05/11/15/16, DEC-0090-01..04, and rule.dhr-summary-zip-source-trace retain their meanings: export is a copy of one explicit frozen version and is distinct from final product release or DHR archival lifecycle completion. The monitor states do not add business lifecycle states. No replacement scope or knowledge maturity is changed. Global W2–W7, A12, high-risk/matrix, 931-knowledge/86-UI candidate, A23 already-reviewed/paused queues, whole-file=0 and unknown historical-unique coverage are not closed by this inspection.

## Evidence and limits

Original evidence: candidate/base Git diff, current source bytes, unchanged neighboring source, and source/test assertions. Secondary reference: the batch README/main-analysis and earlier run descriptions. No browser, database, HTTP request, negative control, JFR calculation, or runtime test was executed by this child. The parent must bind its own runtime evidence to the fixed candidate and perform the final overall review.

Remaining boundaries are explicit: monitor waits are non-interruptible and can persist if a downstream initial filter hangs; active real-network cancellation, natural token expiry during long queues, Error/OOM/crash/UNKNOWN reconciliation, volume/capacity, all tenants, and the complete permission/behavior matrix were not established here. Failed/committed active bodies cannot safely be reframed as an unstarted JSON response. Probe timing in the supplied HTTP test is synthetic scheduling, not production latency or event frequency.

All children of this read-only subtask: none. Status: FINAL. The main role's post-all-FINAL PR drift check remains its own action.
