from pathlib import Path
import yaml,json,hashlib,datetime
r=Path('/tmp/edhr-header-jwt-final-qa-20261107');q=yaml.safe_load((r/'quality-result.yaml').read_text())['qualityResult']
required=['result','level','baseCommit','headCommit','contractBaseline','workingTreeState','knowledgeBaselineVersion','checks','findings','residualRisks','blockingConditions','impactReview','knowledgeSync']
assert all(k in q for k in required)
assert q['result']=='passed' and q['level']=='L2' and q['workingTreeState']['status']=='clean'
cats={'requirements','ontology','unit','integration','api','database','audit','security','e2e','visual','regression','documentation'}
methods={'command','inspection','browser','query','automated-test'}
for c in q['checks']:
    assert set(c)=={'id','required','category','description','method','command','outcome','evidence'}
    assert isinstance(c['required'],bool) and c['category'] in cats and c['method'] in methods and c['outcome']=='passed' and c['evidence']
assert q['checks'] and any(c['required'] for c in q['checks']) and not q['blockingConditions']
for f in q['findings']:
    assert set(f)=={'id','severity','scope','summary','reproductionSteps','expectedResult','actualResult','evidence','resolutionStatus','resolutionEvidence'}
    assert f['severity']=='medium' and f['resolutionStatus']=='resolved' and f['resolutionEvidence']
    assert all(e['type'] in {'commit','command','screenshot','audit-record','document'} and e['reference'] for e in f['resolutionEvidence'])
assert len(q['findings'])==3
for k in q['knowledgeSync']: assert k['disposition'] in {'updated','retained','historical','deferred'}
child_result=yaml.safe_load((r/'source-audit/quality-result.yaml').read_text())['qualityResult']
assert child_result['finalStatus']=='FINAL' and child_result['result']=='passed'
child=json.loads((r/'source-audit/manifest.json').read_text())
for x in child['records']:
    b=(r/'source-audit'/x['path']).read_bytes();assert len(b)==x['bytes'] and hashlib.sha256(b).hexdigest()==x['sha256']
check={'status':'FINAL','format':'docs/agents/agent-handoff-contract.md qualityResult','resultInvariant':'passed satisfied','checks':len(q['checks']),'findings':{'resolvedMedium':3,'open':0},'children':'FINAL','finalWorktree':'clean',
    'reportToolCalibration':'First inline checker expected child manifest.status/files; actual child manifest uses records and FINAL lives in qualityResult.finalStatus. Corrected checker and its report text only. No product/test changes or test rerun.'}
(r/'report-validation.json').write_text(json.dumps(check,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
    if p.is_file() and p.relative_to(r).as_posix() not in {'manifest.json','manifest.sha256'}:
        b=p.read_bytes();files.append({'path':p.relative_to(r).as_posix(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
m={'status':'FINAL','qualityResult':'passed','level':'L2','baseCommit':q['baseCommit'],'headCommit':q['headCommit'],'contractBaseline':q['contractBaseline'],'workingTreeState':q['workingTreeState'],'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'excludedSelfArtifacts':['manifest.json','manifest.sha256'],'children':[{'name':'readonly_source_audit','status':'FINAL','manifestPath':'source-audit/manifest.json','manifestSHA256':hashlib.sha256((r/'source-audit/manifest.json').read_bytes()).hexdigest()}],'files':files}
(r/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n')
digest=hashlib.sha256((r/'manifest.json').read_bytes()).hexdigest();(r/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'result':'passed','checks':len(q['checks']),'files':len(files),'bytes':sum(x['bytes'] for x in files),'manifestSHA256':digest,'reviewSHA256':hashlib.sha256((r/'REVIEW.md').read_bytes()).hexdigest(),'analysisSHA256':hashlib.sha256((r/'analysis.json').read_bytes()).hexdigest(),'qualityResultSHA256':hashlib.sha256((r/'quality-result.yaml').read_bytes()).hexdigest()},indent=2))
