from pathlib import Path
import datetime, hashlib, json, re, shutil, socket, subprocess, xml.etree.ElementTree as ET, zipfile

ROOT=Path('/workspace/edhr-header-jwt-qa-20261107')
RAW=Path('/tmp/edhr-header-jwt-final-qa-20261107')
BASE='b6691e2c6289ab414a7a3fed1f128562cbba4166'
HEAD='703f2ee90417e778cf745fbbcd24f908a345d3bd'
MAIN=Path('/tmp/edhr-header-jwt-20261107/final_verified')
OLD=Path('/tmp/edhr-header-jwt-negative-20261107/negative_verified')
QA=RAW/'final_verified'
def sha(b): return hashlib.sha256(b).hexdigest()
def cmd(*args): return subprocess.check_output(args,cwd=ROOT,text=True).strip()
def read(p): return json.loads(p.read_text())
def xml_summary(paths):
    total=dict(tests=0,failures=0,errors=0,skipped=0); classes=[]
    for p in sorted(paths):
        e=ET.parse(p).getroot(); item={'class':e.get('name'), **{k:int(e.get(k,0)) for k in total}}
        classes.append(item)
        for k in total: total[k]+=item[k]
    return {'totals':total,'classes':classes}

result={'status':'FINAL','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
assert cmd('git','rev-parse','HEAD')==HEAD
assert cmd('git','rev-parse','refs/remotes/origin/edhr-dev')==BASE
assert cmd('git','rev-parse',BASE+'^{tree}')==cmd('git','rev-parse','45858291^{tree}')
contract=['AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture/business-knowledge-model.md']
assert not cmd('git','diff','--name-only',BASE,HEAD,'--',*contract)
result['baseline']={'base':BASE,'head':HEAD,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':HEAD,
    'targetTree':cmd('git','rev-parse',BASE+'^{tree}'),'unchangedContractAndKnowledgePaths':contract,
    'targetRefScope':'Local origin/edhr-dev ref inspected; remote refetch and PR-before-drift recheck remain root responsibility; CI/Actions not inspected or invoked.'}
result['main']=xml_summary(QA.glob('TEST-*.xml'))
assert result['main']['totals']==dict(tests=125,failures=0,errors=0,skipped=0)
assert result['main']['totals']==read(QA/'test-summary.json')['totals']
knowledge=RAW/'knowledge'
for p in (ROOT/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'): shutil.copy2(p,knowledge/p.name)
result['knowledge']=xml_summary(knowledge.glob('TEST-*.xml'))
assert result['knowledge']['totals']==dict(tests=89,failures=0,errors=0,skipped=0)
(knowledge/'test-summary.json').write_text(json.dumps(result['knowledge'],indent=2)+'\n')
run=read(QA/'run.json'); assert run['head']==HEAD and run['exitCode']==0
result['run']={k:run[k] for k in ['command','head','status','startedAt','finishedAt','exitCode']}
result['dependencyLink']={'path':'gmp-platform/frontend/node_modules','target':str((ROOT/'gmp-platform/frontend/node_modules').resolve()),
    'validationStatus':'dirty','includedPaths':[],'excludedPaths':['gmp-platform/frontend/node_modules'],'untrackedPaths':['gmp-platform/frontend/node_modules']}
result['inputFingerprints']=[]
prior={x['path']:x for x in read(MAIN/'run.json')['sourceFingerprints']}
for x in run['sourceFingerprints']:
    b=(ROOT/x['path']).read_bytes(); assert len(b)==x['bytes'] and sha(b)==x['sha256']
    assert sha((QA/'source'/x['path']).read_bytes())==x['sha256']
    assert prior[x['path']]==x
    result['inputFingerprints'].append(x)
assert len(result['inputFingerprints'])==32

result['archives']=[]
evidence=ROOT/'docs/development/branch-review-20261107-dhr-header-jwt/evidence'
for name in ['main','negative','source','auth-source']:
    p=evidence/(name+'.zip'); meta=read(evidence/(name+'-archive.json')); mp=evidence/(name+'-manifest.json'); manifest=read(mp)
    assert sha(p.read_bytes())==meta['sha256'] and sha(mp.read_bytes())==meta['manifestSHA256']
    files={x['path']:x for x in manifest['files']}; raw_count=0
    with zipfile.ZipFile(p) as z:
        assert len(z.namelist())==len(files)==meta['members'] and set(z.namelist())==set(files)
        for path,x in files.items():
            b=z.read(path); assert len(b)==x['bytes'] and sha(b)==x['sha256']
            raw=Path(manifest['sourceRoot'])/path
            if raw.exists(): assert raw.read_bytes()==b;raw_count+=1
    role=evidence/(name+'-role-manifest.json')
    if role.exists(): assert read(role)['status']=='FINAL'
    result['archives'].append({'name':name,**meta,'rawMembersCompared':raw_count,'membersVerified':len(files)})

neg=xml_summary(OLD.glob('TEST-*.xml'));assert neg['totals']==dict(tests=13,failures=3,errors=0,skipped=0)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveJwtHeadersTest.java'
assert (OLD/'source'/test).read_bytes()==(ROOT/test).read_bytes()==(MAIN/'source'/test).read_bytes()
oldxml=ET.parse(next(OLD.glob('TEST-*DhrArchiveJwtHeadersTest.xml'))).getroot()
failures=[{'test':t.get('name'),'type':f.get('type'),'message':f.get('message')} for t in oldxml.iter('testcase') for f in t.findall('failure')]
assert len(failures)==3 and all('Assertion' in x['type'] for x in failures)
oldcases={p.stem:read(p) for p in (OLD/'jwt-http').glob('*.json')}
assert oldcases['forced-header-overlap']['maxConcurrentHeaderWriters']==2
assert oldcases['forced-header-overlap']['headers']['x-content-type-options']==['nosniff','nosniff']
assert all(oldcases[k]['httpStatus']==401 for k in ['rejected','queued-timeout'])
old_sources=[]
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']:
    b=subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT); assert b==(OLD/'source'/path).read_bytes()
    old_sources.append({'path':path,'sha256':sha(b),'matchesGitBase':True})
result['negative']={**neg,'sameByteTestSHA256':sha((ROOT/test).read_bytes()),'failureDetails':failures,'oldSources':old_sources,
    'oldFilterAbsent':not (OLD/'source/gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveResponseFilter.java').exists(),
    'forcedMaxConcurrentHeaderWriters':2,'rejectedStatus':401,'queuedTimeoutStatus':401,'execution':'Archived latest negative_verified inspected; not independently rerun in this QA.'}

cases={p.stem:read(p) for p in (QA/'jwt-http').glob('*.json')};assert len(cases)==13
for k in ['normal','forced-header-overlap','inline']:
    x=cases[k]; assert x['httpStatus']==200 and x['submitted']==x['started']==x['initialRequests']==1
    assert x['responseBytes']==162 and x['headers']['content-length']==['162'] and x['exchangeFailure'] is None
    assert x['headers']['x-content-type-options']==['nosniff'] and x['headers']['x-frame-options']==['DENY']
    assert not x['ownedExistsBeforeFixtureTeardown']
assert cases['forced-header-overlap']['maxConcurrentHeaderWriters']==1
for k,status in [('anonymous',401),('invalid-jwt',401),('view-only',403)]:
    x=cases[k];assert x['httpStatus']==status and x['submitted']==0 and not x['ownedExistsBeforeFixtureTeardown']
for k in ['rejected','queued-timeout']:
    x=cases[k];assert x['httpStatus']==500 and x['responseBytes']==137 and x['started']==0 and x['exchangeFailure'] is None
    assert x['headers']['content-type']==['application/json'] and x['headers']['content-disposition']==['inline']
    assert x['headers'].get('content-length') in [None,['137']] and not x['ownedExistsBeforeFixtureTeardown']
for k in ['private-preview','public-preview','pdf-page-preview']:
    x=cases[k];assert x['httpStatus']==200 and x['headers']['content-type']==['image/png']
    assert x['headers']['cache-control']==['private, max-age=300'] and 'pragma' not in x['headers'] and 'expires' not in x['headers']
assert cases['head']['httpStatus']==200 and cases['head']['responseBytes']==0 and cases['head']['started']==1 and not cases['head']['ownedExistsBeforeFixtureTeardown']
assert cases['client-cancelled']['started']==0 and not cases['client-cancelled']['ownedExistsBeforeFixtureTeardown']
result['jwtHttp']=cases

reader=RAW/'ReadExportJfr.java';shutil.copy2('/tmp/edhr-header-jwt-20261107/ReadExportJfr.java',reader)
result['nativeObservations']=[]
for label,folder in [('qa',QA),('mainArchivedOriginal',MAIN)]:
    obs=[json.loads(s) for s in (folder/'observations/observations.jsonl').read_text().splitlines()]
    by_name={x['name']:x for x in obs}; assert len(obs)==11 and sum(x['selectStatements'] for x in obs)==33
    p=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(reader),str(folder/'observations'),str(folder/'vm-tmp')],capture_output=True,text=True,check=True)
    (RAW/(label+'-jfr-recalculation.tsv')).write_text(p.stdout);(RAW/(label+'-jfr-recalculation.stderr')).write_text(p.stderr)
    recalculated=[]
    for line in p.stdout.splitlines():
        name,b,n,paths=line.split('\t'); o=by_name[name.removesuffix('.jfr')]
        assert int(b)==o['trackedLogicalReadBytes'] and int(n)==o['trackedReadEvents'] and int(paths)<=1
        recalculated.append({'name':o['name'],'bytes':int(b),'events':int(n),'paths':int(paths)})
    assert len(recalculated)==11
    lines=(folder/'postgres.log').read_text().splitlines(); inserts=[]
    for i,line in enumerate(lines):
        if re.search(r'execute [^:]+: insert into audit_event ',line,re.I):
            cols=re.search(r'insert into audit_event \(([^)]+)\)',line,re.I).group(1).split(',')
            detail=lines[i+1];assert 'DETAIL:  parameters:' in detail
            values=dict((int(k),v) for k,v in re.findall(r'\$(\d+) = (.*?)(?=, \$\d+ = |$)',detail))
            assert len(cols)==len(values)==20
            data={c:values[j+1] for j,c in enumerate(cols)}
            assert data['action']=="'EXPORT'" and data['entity_type']=="'DHR_SUMMARY_EXPORT'" and data['entity_id']=="'10'" and data['snapshot_hash_version']=="'audit-event-v2'"
            assert re.fullmatch("'[0-9a-f]{64}'",data['snapshot_hash'])
            inserts.append({'line':i+1,'parameterCount':len(values),'action':data['action'],'entityType':data['entity_type'],'entityId':data['entity_id'],'hashVersion':data['snapshot_hash_version'],'snapshotHash':data['snapshot_hash']})
    assert len(inserts)==3
    result['nativeObservations'].append({'source':label,'observations':11,'callThreadSelects':33,'jfrRecalculation':recalculated,'serverExportInserts':inserts,
        'attributionLimit':'Calling-thread SQL collector only; server log has no per-event tag. Not all-network or exact observation-window SQL attribution; renderer is mocked.'})

ports=sorted(set(int(p) for p in re.findall(r'Tomcat started on port (\d+)',(QA/'maven.log').read_text())));assert len(ports)==2
for port in ports:
    with socket.socket() as s: s.settimeout(.5);assert s.connect_ex(('127.0.0.1',port))!=0
cleanup=read(QA/'cleanup.json');assert cleanup['removed']
assert subprocess.run(['docker','inspect',cleanup['ownedContainer']],capture_output=True).returncode!=0
assert not read(QA/'temporary-archives.json')['leftovers'] and not list((QA/'vm-tmp').rglob('dhr-archive-*.zip'))
result['resources']={'httpPortsClosed':ports,'ownedPostgres':cleanup,'ownedArchiveZipLeftovers':[]}
result['history']='Preserved in verified archives: pilot throws compilation omission produced zero JUnit; first setHeader-only probe max0 was calibration error (addHeader unobserved); corrected old13 10P/3 true assertion F; intermediate124 and125 each two EOF errors; length setter correction then focused13 two attachment failures; explicit inline and strict exact assertion then final125; latest same-byte negative13 still3 true F. Old passes not accumulated into current125.'
result['qaToolCalibration']={'firstAttempt':'audit-evidence-first-failed.log','cause':'Independent report parser incorrectly expected short literal v2; original server records and unchanged product constant use audit-event-v2. Corrected report parser only; all XML/tests/source remain unchanged. No test rerun needed.'}
(RAW/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'main':result['main']['totals'],'knowledge':result['knowledge']['totals'],'negative':neg['totals'],'inputs':len(result['inputFingerprints']),'archiveMembers':sum(x['membersVerified'] for x in result['archives']),'jfrFiles':22,'ports':ports},indent=2))
