import java.nio.file.*;
import java.util.*;
import jdk.jfr.consumer.RecordingFile;
class ReadExportJfr {
    public static void main(String[] args)throws Exception {
        Path dir=Path.of(args[0]);String ownedRoot=Path.of(args[1]).toString();
        try(var files=Files.list(dir)){
            for(Path file:files.filter(p->p.toString().endsWith(".jfr")).sorted().toList()){
                boolean archive=file.getFileName().toString().startsWith("archive-");long bytes=0,events=0;Set<String> paths=new HashSet<>();
                for(var event:RecordingFile.readAllEvents(file)){
                    if(!event.getEventType().getName().equals("jdk.FileRead"))continue;
                    String path=event.getString("path");
                    if(path==null||!path.startsWith(ownedRoot))continue;
                    boolean watched=archive ? Path.of(path).getFileName().toString().startsWith("dhr-archive-")&&path.endsWith(".zip") : path.endsWith("/registered.png");
                    if(watched){bytes+=event.getLong("bytesRead");events++;paths.add(path);}
                }
                System.out.println(file.getFileName()+"\t"+bytes+"\t"+events+"\t"+paths.size());
            }
        }
    }
}
