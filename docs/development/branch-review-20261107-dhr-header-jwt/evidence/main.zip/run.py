from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,shutil,time,xml.etree.ElementTree as ET
root=Path(os.getenv('EDHR_ARCHIVE_ROOT','/workspace/edhr-nexus-frontend'));raw=Path(os.getenv('EDHR_ARCHIVE_RAW','/tmp/edhr-header-jwt-20261107'));phase=sys.argv[1];assert phase in ['negative','negative_context','negative_final','negative_verified','final','retry','probe','probe_verified','final_verified'];negative=phase.startswith('negative') or phase.startswith('probe')
out=raw/phase;out.mkdir(parents=True,exist_ok=False);tmp=out/'vm-tmp';tmp.mkdir();name='edhr-header-jwt-main-'+phase+'-20261107';created=False;code=1
selected='DhrArchiveJwtHeadersTest'
if not negative:selected+=',DhrArchiveResponseFilterTest,JwtTokenProviderTest,JwtAuthenticationFilterTest,SecurityConfigTest,SecurityJwtExpirationTest,DhrArchiveAsyncLifecycleTest,DhrArchiveAsyncOwnershipTest,DhrArchiveCleanupFailureTest,DhrArchiveControllerStreamingTest,DhrExportReadObservationPostgresTest,DhrFormFilesTest,DhrArchiveLayoutReaderTest,AuditEventHashTest,AuditEventTest,AuditAspectTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 env=os.environ.copy();env.update(PGUSER='postgres',PGPASSWORD='')
 if not negative:
  db='edhr_dhr_export_read_test_header_'+phase
  run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a ']);created=True
  for _ in range(120):
   if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
   time.sleep(.25)
  else:raise RuntimeError('owned PG unavailable')
  port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env['DHR_EXPORT_READ_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/{db}'
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/development/branch-review-20261107-dhr-header-jwt/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrPdfRenderer.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/exception/GlobalExceptionHandler.java']
 for test in selected.split(','):
  files=list((root/'gmp-platform/backend/src/test/java').rglob(test+'.java'));assert len(files)==1;paths.append(str(files[0].relative_to(root)))
 paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtTokenProvider.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java']
 gate='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveResponseFilter.java'
 if (root/gate).exists():paths.append(gate)
 fingers=[]
 for path in paths:
  b=(root/path).read_bytes();fingers.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.jwtHeaders=true','-Dedhr.audit.jwtHeadersOutput='+str(out/'jwt-http'),'-Dedhr.audit.archiveAsync=true','-Dedhr.audit.archiveAsyncOutput='+str(out/'http'),'-Dedhr.audit.archiveCleanupFaults=true','-Dedhr.audit.dhrExportReads=true','-Dedhr.audit.dhrExportReadOutput='+str(out/'observations'),'-DargLine=-Xmx1536m -Djava.io.tmpdir='+str(tmp),'-Dtest='+selected,'test'];start=datetime.datetime.now(datetime.timezone.utc)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'run.json').write_text(json.dumps({'command':command,'head':run(['git','rev-parse','HEAD'],cwd=root),'status':run(['git','status','--porcelain'],cwd=root),'startedAt':start.isoformat(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fingers},indent=2)+'\n')
 totals=dict(tests=0,failures=0,errors=0,skipped=0);classes=[];missing=[]
 for test in selected.split(','):
  reports=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not reports:missing.append(test)
  for p in reports:
   shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;v={k:int(a.get(k,0)) for k in totals};classes.append({'class':a['name'],**v})
   for k in totals:totals[k]+=v[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-1800:]);code=0 if result.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name])
  removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n')
 leftovers=sorted(str(p) for p in tmp.glob('dhr-archive-*.zip'));(out/'temporary-archives.json').write_text(json.dumps({'dedicatedJvmTempRoot':str(tmp),'leftovers':leftovers,'note':'Tests remove only their own blocker child/path in teardown; production cleanup remains non-recursive.'},indent=2)+'\n');print('temp archive leftovers',leftovers)
sys.exit(code)
