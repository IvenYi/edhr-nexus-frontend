from pathlib import Path
import json,hashlib,subprocess,re,xml.etree.ElementTree as ET,socket,shutil
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-header-jwt-20261107');base='b6691e2c6289ab414a7a3fed1f128562cbba4166'
old=Path('/tmp/edhr-header-jwt-negative-20261107/negative_verified');new=raw/'final_verified'
out={'base':base,'negative':json.loads((old/'test-summary.json').read_text()),'final':json.loads((new/'test-summary.json').read_text())}
assert out['negative']['totals']==dict(tests=13,failures=3,errors=0,skipped=0)
assert out['final']['totals']==dict(tests=125,failures=0,errors=0,skipped=0)
xml=ET.parse(next(old.glob('TEST-*DhrArchiveJwtHeadersTest.xml'))).getroot();failures=list(xml.iter('failure'))
assert len(failures)==3 and all('Assertion' in x.attrib['type'] for x in failures)
test='gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/DhrArchiveJwtHeadersTest.java'
assert (old/'source'/test).read_bytes()==(new/'source'/test).read_bytes()
out['sameByteNegativeHttpSha256']=hashlib.sha256((new/'source'/test).read_bytes()).hexdigest()
for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveController.java']:
    assert (old/'source'/path).read_bytes()==subprocess.check_output(['git','show',base+':'+path],cwd=r)
cases={f.stem:json.loads(f.read_text()) for f in (new/'jwt-http').glob('*.json')};assert len(cases)==13
for key in ['normal','forced-header-overlap','inline']:
    x=cases[key];assert x['httpStatus']==200 and x['submitted']==x['started']==x['initialRequests']==1 and not x['ownedExistsBeforeFixtureTeardown']
    assert x['headers']['x-content-type-options']==['nosniff'] and x['headers']['x-frame-options']==['DENY']
assert cases['forced-header-overlap']['maxConcurrentHeaderWriters']==1
for key,status in [('anonymous',401),('invalid-jwt',401),('view-only',403)]:assert cases[key]['httpStatus']==status and cases[key]['submitted']==0 and not cases[key]['ownedExistsBeforeFixtureTeardown']
for key in ['rejected','queued-timeout']:
    x=cases[key];assert x['httpStatus']==500 and x['started']==0 and not x['ownedExistsBeforeFixtureTeardown']
    assert x['headers']['content-disposition']==['inline'] and x['headers']['content-type']==['application/json']
    assert 'content-length' not in x['headers'] or x['headers']['content-length']==[str(x['responseBytes'])]
for key in ['private-preview','public-preview','pdf-page-preview']:
    x=cases[key];assert x['httpStatus']==200 and x['headers']['cache-control']==['private, max-age=300']
    assert 'pragma' not in x['headers'] and 'expires' not in x['headers']
assert cases['head']['httpStatus']==200 and cases['head']['responseBytes']==0 and not cases['head']['ownedExistsBeforeFixtureTeardown']
assert cases['client-cancelled']['started']==0 and not cases['client-cancelled']['ownedExistsBeforeFixtureTeardown']
out['jwtHttp']=cases
out['oldJwtHttp']={f.stem:json.loads(f.read_text()) for f in (old/'jwt-http').glob('*.json')}
assert out['oldJwtHttp']['forced-header-overlap']['maxConcurrentHeaderWriters']==2
for k in ['rejected','queued-timeout']:assert out['oldJwtHttp'][k]['httpStatus']==401
run=json.loads((new/'run.json').read_text())
for x in run['sourceFingerprints']:assert hashlib.sha256((r/x['path']).read_bytes()).hexdigest()==x['sha256'],x['path']
out['inputsIdentical']=len(run['sourceFingerprints'])
obs=[json.loads(x) for x in (new/'observations/observations.jsonl').read_text().splitlines()];assert len(obs)==11
out['nativeObserverSelects']=sum(x['selectStatements'] for x in obs);assert out['nativeObserverSelects']==33
inserts=re.findall(r'execute [^:]+: (insert into audit_event[^\n]+)',(new/'postgres.log').read_text(),re.I);assert len(inserts)==3;out['serverExportInserts']=3
jfr=subprocess.run(['/workspace/.edhr-cloud-tools/jdk-21/bin/java',str(raw/'ReadExportJfr.java'),str(new/'observations'),str(new/'vm-tmp')],capture_output=True,text=True,check=True)
(raw/'jfr-recalculation.tsv').write_text(jfr.stdout);(raw/'jfr-recalculation.stderr').write_text(jfr.stderr);byName={x['name']:x for x in obs};j=[]
for line in jfr.stdout.splitlines():
    name,b,n,paths=line.split('\t');k=name.removesuffix('.jfr');v=byName[k]
    assert int(b)==v['trackedLogicalReadBytes'] and int(n)==v['trackedReadEvents'] and int(paths)<=1
    j.append(dict(name=k,bytes=int(b),events=int(n)))
assert len(j)==11;out['jfrRecalculation']=j
ports=sorted(set(int(x) for x in re.findall(r'Tomcat started on port (\d+)',(new/'maven.log').read_text())));assert len(ports)==2
for port in ports:
    with socket.socket() as s:s.settimeout(.5);assert s.connect_ex(('127.0.0.1',port))!=0
assert json.loads((new/'cleanup.json').read_text())['removed'];assert not json.loads((new/'temporary-archives.json').read_text())['leftovers']
out['ownedHttpPortsClosed']=ports;out['ownedResourcesClean']=True
out['history']='Pilot compile0; first setHeader-only probe max0 calibration failure, not product race; corrected old13 10P3F; intermediate124/125 EOF2E preserved; null disposition unsupported, explicit inline contract and strict assertion preserved; latest same-byte old13 10P3F is canonical.'
out['limits']=['Synthetic signed JWT and mocked ZIP generator/repos, not full login/identity DB HTTP chain','Probe forces timing; not production latency/frequency or SLA','Native PG12 renderer mocked; observer33 lacks per-event server tags, not all-network SQL attribution','Direct gate tests not active-body real network cancellation; monitor wait non-interruptible, no hanging-filter/crash/UNKNOWN guarantee','Security7.x official fix is not current6.x drop-in; no dependency/cache policy changes']
(raw/'analysis.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');shutil.copy2(raw/'analysis.json',r/'docs/development/branch-review-20261107-dhr-header-jwt/main-analysis.json')
print(json.dumps({'negative':out['negative']['totals'],'final':out['final']['totals'],'inputs':out['inputsIdentical'],'http':len(cases),'jfr':len(j),'portsClosed':ports},indent=2))
