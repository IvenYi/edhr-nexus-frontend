from pathlib import Path
from zipfile import ZipFile
p=Path('/tmp/edhr-header-jwt-20261107')
with ZipFile('/workspace/edhr-nexus-frontend/docs/development/branch-review-20261107-dhr-archive-async/evidence/main.zip') as z:
    old=z.read('run.py').decode();(p/'ReadExportJfr.java').write_bytes(z.read('ReadExportJfr.java'))
old=old.replace("/tmp/edhr-archive-async-20261107","/tmp/edhr-header-jwt-20261107")
old=old.replace("['negative','negative_context','final','retry']", "['negative','negative_context','negative_final','negative_verified','final','retry','probe','probe_verified','final_verified']")
old=old.replace("negative=phase.startswith('negative')", "negative=phase.startswith('negative') or phase.startswith('probe')")
old=old.replace("edhr-archive-async-main-","edhr-header-jwt-main-").replace("edhr_dhr_export_read_test_async_","edhr_dhr_export_read_test_header_")
old=old.replace("selected='DhrArchiveAsyncLifecycleTest'", "selected='DhrArchiveJwtHeadersTest'")
old=old.replace("selected+=',DhrArchiveAsyncOwnershipTest", "selected+=',DhrArchiveAsyncLifecycleTest,DhrArchiveAsyncOwnershipTest")
old=old.replace("selected+=',DhrArchiveAsyncLifecycleTest", "selected+=',DhrArchiveResponseFilterTest,JwtTokenProviderTest,JwtAuthenticationFilterTest,SecurityConfigTest,SecurityJwtExpirationTest,DhrArchiveAsyncLifecycleTest")
old=old.replace("branch-review-20261107-dhr-archive-async/decision-package.yaml", "branch-review-20261107-dhr-header-jwt/decision-package.yaml")
old=old.replace(" for test in selected.split(','):", " for test in selected.split(','):",1)
old=old.replace(" fingers=[]", " paths += ['gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtTokenProvider.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/FileController.java']\n gate='gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrArchiveResponseFilter.java'\n if (root/gate).exists():paths.append(gate)\n fingers=[]")
old=old.replace("'-Dedhr.audit.archiveAsync=true'", "'-Dedhr.audit.jwtHeaders=true','-Dedhr.audit.jwtHeadersOutput='+str(out/'jwt-http'),'-Dedhr.audit.archiveAsync=true'")
(p/'run.py').write_text(old)
