package com.zencas.edhr.production.controller;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/** Keeps an archive worker from committing headers while the initial security chain is still writing them. */
public final class DhrArchiveResponseFilter extends OncePerRequestFilter {
    private static final String MONITOR = DhrArchiveResponseFilter.class.getName() + ".monitor";
    private final AntPathRequestMatcher exports = new AntPathRequestMatcher("/api/v1/dhr-instances/*/summary/versions/*/export");

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        return !exports.matches(request);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        Object monitor = new Object();
        request.setAttribute(MONITOR, monitor);
        synchronized (monitor) {
            chain.doFilter(request, response);
        }
    }

    static Object responseMonitor(NativeWebRequest request) {
        Object monitor = request.getAttribute(MONITOR, RequestAttributes.SCOPE_REQUEST);
        // Direct controller callers and isolated MVC fixtures do not install the security filter chain.
        return monitor == null ? new Object() : monitor;
    }
}
