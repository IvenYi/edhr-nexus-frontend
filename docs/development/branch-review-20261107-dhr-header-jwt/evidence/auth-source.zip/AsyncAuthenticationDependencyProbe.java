import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.mock.web.*;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.*;
import org.springframework.security.web.context.request.async.SecurityContextCallableProcessingInterceptor;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.WebUtils;

/** Framework dependency simulation: synthetic authentication, not product JWT crypto or Tomcat HTTP. */
public class AsyncAuthenticationDependencyProbe {
    static class SyntheticFilter extends OncePerRequestFilter {
        final boolean recheckAsync;final AtomicInteger validations=new AtomicInteger();boolean valid=true;
        SyntheticFilter(boolean value){recheckAsync=value;}
        @Override protected boolean shouldNotFilterAsyncDispatch(){return !recheckAsync;}
        @Override protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws java.io.IOException,ServletException{
            validations.incrementAndGet();
            if(valid)SecurityContextHolder.getContext().setAuthentication(UsernamePasswordAuthenticationToken.authenticated("synthetic-user",null,List.of()));
            chain.doFilter(req,res);
        }
    }
    static Map<String,Object> dispatches(boolean recheckAsync,boolean validOnAsync,boolean error)throws Exception{
        var request=new MockHttpServletRequest("GET","/dependency-probe");var response=new MockHttpServletResponse();
        var contextFilter=new SecurityContextHolderFilter(new RequestAttributeSecurityContextRepository());var authFilter=new SyntheticFilter(recheckAsync);
        List<Boolean> visible=new ArrayList<>();
        FilterChain terminal=(req,res)->visible.add(SecurityContextHolder.getContext().getAuthentication()!=null);
        FilterChain authentication=(req,res)->authFilter.doFilter(req,res,terminal);
        contextFilter.doFilter(request,response,authentication);
        if(SecurityContextHolder.getContext().getAuthentication()!=null)throw new AssertionError("initial thread context leaked");
        authFilter.valid=validOnAsync;request.setDispatcherType(error?DispatcherType.ERROR:DispatcherType.ASYNC);
        if(error)request.setAttribute(WebUtils.ERROR_REQUEST_URI_ATTRIBUTE,"/dependency-probe");
        contextFilter.doFilter(request,response,authentication);
        boolean expected=!error&&recheckAsync&&validOnAsync;
        int expectedValidations=!error&&recheckAsync?2:1;
        if(!visible.equals(List.of(true,expected))||authFilter.validations.get()!=expectedValidations)throw new AssertionError("wrong auth dispatch "+visible+"/"+authFilter.validations);
        if(SecurityContextHolder.getContext().getAuthentication()!=null)throw new AssertionError("redispatch thread context leaked");
        return Map.of("case",error?"error-default-skipped":"async-"+(recheckAsync?"rechecked":"default-skipped")+(validOnAsync?"-valid":"-invalid"),"visibleAuthentication",visible,"validations",authFilter.validations.get(),"passed",true);
    }
    static Map<String,Object> callableContextIsNotRepositorySave()throws Exception{
        var request=new MockHttpServletRequest();var response=new MockHttpServletResponse();var web=new ServletWebRequest(request,response);
        var interceptor=new SecurityContextCallableProcessingInterceptor();Callable<Void> task=()->null;
        SecurityContextHolder.getContext().setAuthentication(UsernamePasswordAuthenticationToken.authenticated("synthetic-user",null,List.of()));
        interceptor.beforeConcurrentHandling(web,task);SecurityContextHolder.clearContext();
        var observed=new AtomicBoolean();var cleared=new AtomicBoolean();var failure=new AtomicReference<Throwable>();
        Thread worker=new Thread(()->{try{interceptor.preProcess(web,task);observed.set(SecurityContextHolder.getContext().getAuthentication()!=null);interceptor.postProcess(web,task,null);cleared.set(SecurityContextHolder.getContext().getAuthentication()==null);}catch(Throwable ex){failure.set(ex);}},"context-probe-worker");worker.start();worker.join(2000);
        if(worker.isAlive()||failure.get()!=null||!observed.get()||!cleared.get())throw new AssertionError("callable context failed",failure.get());
        var repository=new RequestAttributeSecurityContextRepository();
        boolean saved=repository.containsContext(request);if(saved)throw new AssertionError("callable unexpectedly saved repository");
        return Map.of("case","callable-context-worker-only-not-repository-save","workerAuthenticated",observed.get(),"workerCleared",cleared.get(),"repositoryContainsContext",saved,"passed",true);
    }
    public static void main(String[] args)throws Exception{
        System.out.println(HeaderWriterConcurrencyProbe.json(dispatches(false,true,false)));
        System.out.println(HeaderWriterConcurrencyProbe.json(dispatches(true,true,false)));
        System.out.println(HeaderWriterConcurrencyProbe.json(dispatches(true,false,false)));
        System.out.println(HeaderWriterConcurrencyProbe.json(dispatches(true,true,true)));
        System.out.println(HeaderWriterConcurrencyProbe.json(callableContextIsNotRepositorySave()));
    }
}
