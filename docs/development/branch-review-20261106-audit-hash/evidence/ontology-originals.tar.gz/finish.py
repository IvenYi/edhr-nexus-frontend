from pathlib import Path
import json,hashlib,subprocess,datetime,yaml
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-w5-hash-ontology-20261106');base='9dc5c0014643d99db299d27a80788cc777a0ccca'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
head=git('rev-parse','HEAD');target=git('rev-parse','origin/edhr-dev');assert target==base
for f in json.loads((out/'knowledge-fingerprint-inventory.json').read_text())['files']:
 assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
contracts=['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md']
for path in contracts:
 assert subprocess.check_output(['git','show',base+':'+path],cwd=root)==(root/path).read_bytes(),path
paths=['gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventHashTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventHashCompatibilityPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventRoundTripPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditHashMigrationPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/common/config/CurrentDatabaseBaselinePostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentTransactionPostgresTest.java','docs/development/branch-review-20261106-audit-hash/decision-package.yaml']
paths.append('gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAttachmentUploadVerifyObservationPostgresTest.java')
sources=[]
for path in paths:
 data=(root/path).read_bytes();p=out/'final-working-source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 sources.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'evidenceState':'stable working tree at '+head})
write('final-source-manifest.json',{'headCommitAtReview':head,'targetCommit':target,'contractReadCommit':base,'workingTreeStatus':git('status','--porcelain'),'sourceFiles':sources,'note':'Product and tests are uncommitted current main implementation snapshots; no invented commit hash. Ontology role read source/tests, did not execute business tests.'})
producers=[]
for path in (root/'gmp-platform/backend/src/main/java').rglob('*.java'):
 text=path.read_text();pos=0
 while (start:=text.find('AuditEvent.builder()',pos))>=0:
  end=text.index('.build()',start)+len('.build()');block=text[start:end];producers.append({'path':str(path.relative_to(root)),'line':text[:start].count('\n')+1,'explicitSnapshotHash':'.snapshotHash(' in block});pos=end
assert len(producers)==49 and len({p['path'] for p in producers})==37 and not any(p['explicitSnapshotHash'] for p in producers)
write('current-producer-count.json',{'scope':'Current main AuditEvent.builder blocks only; not all historical DB writers or runtime coverage','builderSites':49,'files':37,'explicitProvidedHashes':0,'records':producers})
result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,'contractReadCommit':base,'uncommittedContractPaths':[]},
 'reason':'经有限现行定义、历史依据和稳定工作树实现核对，本批仅修复新自动AuditEvent摘要的持久化往返确定性：新增nullable版本元数据、JSONB业务值确定编码和同一LocalDateTime的微秒精度，不改变独立事件/真实前后值/操作者/动作投影/发生时点含义、不可变规则或现有读取权限及下载政策；旧日志、旧hash、Signature/DHR/file摘要不改。没有新的业务概念、关系、政策或执行契约需同步，350知识文件逐字节不变，知识0.3.25/schema1.2.0/P0 in-progress保持。本结果不认证旧历史都可复算或完整ZIP自足校验。',
 'changedArtifacts':[],
 'knowledgeSync':[
  {'id':'term.audit-event','disposition':'retained','scope':'独立不可变审计事件仍保留对象、原动作、操作者和发生时间；v2是内部摘要编码版本，不是新业务事件或流程状态。','sourceReferences':['docs/knowledge/glossary.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java']},
  {'id':'term.audit-change-snapshot','disposition':'retained','scope':'真实前后业务值与历史原件所有权保持；新hash对JSONB业务值编码，不宣称原JSON字符字节无损，不从当前主数据补造旧原件。','sourceReferences':['docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java']},
  {'id':'relation.audit-event-retains-change-snapshot','disposition':'retained','scope':'原事件到可选变化快照关系和首次START冻结边界保持；新自动封存不更新旧行或覆盖DHR/生产快照。','sourceReferences':['docs/knowledge/ontology.yaml','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql']},
  {'id':'rule.production.audit-action-projection','disposition':'retained','scope':'内部hash版本不增加页面动作类别、筛选或验证状态，不更改原action及客户新增/修改投影。','sourceReferences':['docs/knowledge/rules/production.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java']},
  {'id':'execution.production-object-audit-snapshot','disposition':'retained','scope':'原verified/runtime登记仅承接原控制器契约；本批不提升其成熟度，也不把49共享PrePersist等同49条业务链均已认证审计失败回滚。','sourceReferences':['docs/knowledge/execution-contracts.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/common/audit/AuditAspect.java']},
  {'id':'evidence.ontology-audit-event-entity','disposition':'historical','scope':'保留ea5d1a65和2026-10-12证据原文，不把新v2工程实现反填为历史已验证；独立身份、操作者、时间、前后值及拒绝更新描述仍适用。','sourceReferences':['docs/knowledge/evidence/ontology-foundation-repair.yaml']},
  {'id':'scenario.dhr-summary-printable-archive-layout','disposition':'deferred','scope':'仅本批摘要修复不能认证完整PDF/ZIP/来源签名/附件/视觉矩阵；当前部分字段或裁剪审计清单不能自足复算原事件，未来完整证据或阻断UI政策本批未决定。','sourceReferences':['docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java']}
 ],
 'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.w5-finite-definition-source','checkType':'evidence-path','command':'Read current records, original controller/entity/readers and stable helper/migration/test source; compare exact source fingerprints','outcome':'passed','evidence':['finite-audit-records.jsonl: 16 reviewed (15 ID records plus 1 historical Markdown); 14 consistent only in declared subscopes, 2 evidence-gap retained','final-source-manifest.json; baseline-source-manifest.json','current-producer-count.json: 49 current builder sites / 37 files / zero explicit hashes; not runtime verification of all sites']},
  {'id':'validation.w5-formal-knowledge','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','outcome':'passed','evidence':['knowledge-validation.log: exit 0 BUILD SUCCESS','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml: 89 tests, zero failure/error/skip','knowledge-test-summary.json; schema/reference/status/projection only, not product/PG/UI/production acceptance']},
  {'id':'validation.w5-baseline-retention','checkType':'reference','command':'Compare all tracked knowledge files and applicable contracts against 9dc5c0014643d99db299d27a80788cc777a0ccca','outcome':'passed','evidence':['knowledge-fingerprint-inventory.json: 350 files byte-identical to target; inventory is not semantic coverage','baseline.json; final-source-manifest.json; no knowledge or contract edits by ontology role']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
}}
(out/'ontologyResult.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=110))
(out/'REVIEW.md').write_text('''# W5 新自动审计摘要往返修复：有限本体核对

结果 `not-applicable`，知识 `0.3.25 / schema 1.2.0 / P0 in-progress` 保持。起点与目标为 edhr-dev@9dc5c0014643d99db299d27a80788cc777a0ccca，PR66已合入、整树同dbc95776；本角色读取适用契约并核对其字节与该提交一致，未发现契约或知识增量。主实现仍处于稳定工作树，具体HEAD、文件SHA和未提交状态见 `final-source-manifest.json`，不为工作树虚构提交SHA。

本角色未修改业务代码、测试、迁移、配置、架构或知识资产。实际执行的是正式知识模块89/89，0失败/错误/跳过；实际读取新的编码、PG/迁移与邻接事务测试源码，不代称亲自运行这些业务测试。主侧运行与全新独立质量应按其各自原件验收。

## 当前定义与实现

有限16记录为15个ID与1份历史Markdown，14项在声明子范围一致、2项证据缺口。记录含原始成熟度、schema记录类型、来源提交/定位、原始值及实际核对依据。此集合与上轮附件核验16记录不是同一集合；不新增或推算全审唯一覆盖率，不把implemented/verified标签当本轮运行通过。

现行term.audit-event/concept.audit-event和事件到变化快照关系要求独立不可变事件、对象、原始动作、操作者、发生时间与真实前后值；没有规定旧字符串拼接算法或纳秒存储为业务政策。新nullable版本列、UTF8版本域加固定18字段、JSONB值确定编码及原LocalDateTime微秒截断属于现有摘要能力的工程修复，不产生新状态、用户动作或审批规则。未知版本仅显式拒绝内部重算，不改变普通读取和下载资格；未标旧行保留旧算法诊断、显式已有hash不自动改写或盖v2。

已读稳定实现：PrePersist只在原hasText判断为空时选择v2并对同一createdAt截到微秒，未引入新时区或取当前时间替代旧时间。原18字段覆盖保留。JSON内容以单元素数组区分SQLnull与JSONnull，对象键稳定排序、数组保序、任意精度数值去尾零、重复键按最后值解释，纯编码直接送SHA。局部Jackson限制显式处理、容器输出用迭代栈，未把解析器默认数字长度或深度上限另立为业务限制。内容字段仍为原JSONB映射；此实现不是原JSON字符串字节保全。

0092仅追加无default的nullable版本列，master追加include，原baseline未改；没有UPDATE/回填/重封存或触发器。应用回退保留版本列与新旧hash，不承诺破坏性schema回退。迁移测试的旧应用兼容是旧列集合SQL读写，不应冒称真实旧二进制混部/生产部署验收。旧三表事务夹具追加实际0092使实体列与夹具一致，原提交/回滚断言保留，不是放松业务标准。附件native测试在原hex/身份断言上增加按真实ID从JPA重读并复算v2，额外验证查询在被观察业务动作之外，不能把动作查询数当所有测试网络SQL。新unit的1/10MiB资源观察增加旧算法同内容参照；本角色只读测试源码，不代称运行通过。

当前main/java逐builder重新静态盘点49位点/37文件，0显式AuditEvent hash；现有生产者继续共享PrePersist。已读AuditController/DhrArchiveService仍透传已存hash，未新增自动验错、UI验证状态或下载放行/阻断；生产工单和对象的真实差量及中文动作投影未改。Signature TEXT原文SHA、DHR/附件hash和冻结内容仍独立，不以AuditEvent修复替它们做兼容或历史恢复。

## 保留边界

AuditAspect既有catch(Exception)记录日志后返回业务结果仍在，未由本批修改。49共享入口不等于49业务链都已认证同事务审计失败回滚；显式领域写事务按实际独立测试范围说明。无密钥SHA也不证明具有数据库写权限者不能同时替换内容和摘要，本批不引入链式日志、电子签名或外部保全。

旧事件可能已丢失原JSON字符/纳秒依据；新行可重算不修复这些历史，旧W5新行缺陷和不可恢复历史限制须分开结案。原2026-10-20等失败/研究证据保留原时点，不重写为新方案已验证。当前ZIP仅保留部分审计字段且选定范围可裁剪，即使新行带数据库版本列，也不能据此认证ZIP脱库自足重算，完整打印/ZIP/来源/签名/附件/视觉矩阵仍为证据缺口。

350知识文件逐字节不变。没有新业务政策需要confirmed建模，也不为工程内部版本创建新术语、规则或执行契约、增加知识版本或提升成熟度。原931知识/86UI候选、高风险/A12/完整矩阵、历史/text-ID索引、上传/PDF/Office容量、大解析器、UNKNOWN持久对账、W2余项-W7及已审代码A23过度防御复查继续；朋友任务签名页与生产管理弹窗样式暂停保持。整文件完成/总体审计完成未由本角色增加。

原件索引：`ontologyResult.yaml`、`finite-audit-records.jsonl`、`knowledge-fingerprint-inventory.json`、`baseline-source-manifest.json`、`final-source-manifest.json`、`current-producer-count.json`、`knowledge-test-summary.json`。正式知识日志/XML与实际读源码快照均保存在本目录，manifest逐文件封存。
''')
write('final-validation.json',{'knowledgeFormalPassed':89,'knowledgeFilesUnchanged':350,'finiteReviewed':16,'finiteConsistent':14,'finiteEvidenceGap':2,'ontologyResult':'not-applicable','modifiedRepositoryFilesByOntology':[],'actualBusinessTestsRunByOntology':[],'subagents':[],'readyForFormalFinal':True,'finalizedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':head,'target':target})
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':head,'target':target,'files':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
write('manifest.json',manifest);digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'ontologyResult':'not-applicable','sourceHead':head,'files':len(files),'manifestSha256':digest,'productSourceFingerprints':sources[:4]},ensure_ascii=False,indent=2))
