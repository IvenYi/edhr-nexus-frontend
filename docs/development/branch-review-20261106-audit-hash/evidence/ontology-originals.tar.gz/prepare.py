from pathlib import Path
import subprocess, hashlib, json, shutil, datetime, yaml, xml.etree.ElementTree as ET

root=Path('/workspace/edhr-nexus-frontend')
out=Path('/tmp/edhr-w5-hash-ontology-20261106')
base='9dc5c0014643d99db299d27a80788cc777a0ccca'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','origin/edhr-dev')==base
tracked=git('ls-tree','-r','--name-only',base).splitlines()
knowledge=[]
for path in tracked:
 if not path.startswith('docs/knowledge/'):continue
 old=subprocess.check_output(['git','show',base+':'+path],cwd=root)
 current=(root/path).read_bytes();assert current==old,path
 knowledge.append({'path':path,'bytes':len(current),'sha256':hashlib.sha256(current).hexdigest(),'equalsBase':True})
assert len(knowledge)==350
write('knowledge-fingerprint-inventory.json',{'baselineCommit':base,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','inventoryCount':len(knowledge),'allEqualBase':True,'semanticMeaning':'Inventory and byte equality only, not whole-library semantic completion','files':knowledge})
scope={
 'term.audit-event': '不可变审计事件身份、原动作/操作者/时间不因v2工程标识改变；hash版本不是新业务事件类型。',
 'term.audit-change-snapshot': '真实业务前后值与当前显示投影保持；不把JSONB业务值确定编码宣称为原JSON字符无损保存，不补造历史。',
 'concept.audit-event': '原独立运行事实概念、身份与internal成熟度保持，新增nullable列是存储实现元数据。',
 'concept.audit-change-snapshot': '前后快照仍属原事件，helper不把当前主数据或请求重构为历史。',
 'relation.audit-event-retains-change-snapshot': '事件到真实变化快照关系与可选性不变；新hash不得重写源JSON字段或生产START/DHR快照。',
 'relation.audit-event-projects-action-category': '计算内部hash不改变客户动作投影或原action。',
 'rule.production.audit-action-projection': '生产工单/对象仍显示新增/修改，内部hash版本不增加动作标签、筛选或写权限。',
 'rule.production.work-order-audit-change-snapshot': '核对原控制器从持久业务对象构造真实前后值并写事件；本批不变此生产者范围或既有成熟度。',
 'rule.production.production-object-audit-change-snapshot': '保留每对象独立CREATE/UPDATE、真实差量和首次START原件；不因新摘要改执行/工单或旧缺失内容。',
 'rule.production.audit-field-localized-display': '原中文字段投影、{}明确快照入口及历史原件继续，不新增验证状态UI或下载阻断。',
 'execution.production-object-audit-snapshot': '原已登记verified/runtime契约仅沿原控制器范围保留，本角色不重新认证该运行成熟度，不将新hash扩大成整条生产执行验收。',
 'anchor.master-data-write-audit-snapshot': '核对原主数据审计实现定位和业务来源，保留sourceRevision/capturedAt/reviewStatus的历史含义，不反填当年审查。',
 'rule.master-data.write-audit-snapshot': '新摘要仍封存已记录业务值；不修改旧审计JSON，不把展示字段转换当作后端快照。',
 'evidence.ontology-audit-event-entity': '历史ea5d1a65核对仍是当时原件；新工程实现不反写旧证据、原独立ID/操作者/时间/前后值/拒绝更新语义保持。',
 'scenario.dhr-summary-printable-archive-layout': '本批未执行全部PDF/ZIP/权限/来源/附件视觉及完整机器清单验收；当前ZIP只投影部分审计字段且可裁剪，不能借v2声称ZIP自足重算原事件。',
}
schema=yaml.safe_load((root/'docs/knowledge/schema.yaml').read_text());records=[]
def walk(value,path,loc='',rtype=None,parent=None):
 if isinstance(value,dict):
  if value.get('id') in scope:
   ident=value['id'];gap=ident=='scenario.dhr-summary-printable-archive-layout'
   records.append({'id':ident,'recordType':rtype,'sourcePath':path,'sourceLocator':loc,'sourceCommit':base,'originalMaturity':{'status':value.get('status'),'visibility':value.get('visibility'),'parentStatus':parent.get('status') if parent else None},'auditScope':'finite W5 new-row persisted hash change; not full original scenario','semanticReviewStatus':'reviewed','conclusion':'evidence-gap' if gap else 'consistent','disposition':'deferred' if gap else 'retained','reason':scope[ident],'originalRecord':value,'evidenceReferences':['docs/development/branch-review-20261106-audit-hash/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java']})
  for k,v in value.items():
   nexttype=schema['nestedCollectionTypes'].get(k,schema['collectionTypes'].get(k,rtype))
   walk(v,path,loc+'/'+str(k),nexttype,value if value.get('id') else parent)
 elif isinstance(value,list):
  for i,v in enumerate(value):walk(v,path,loc+'/'+str(i),rtype,parent)
for path in sorted((root/'docs/knowledge').rglob('*.yaml')):walk(yaml.safe_load(path.read_text()),str(path.relative_to(root)))
assert len(records)==len(scope)==15
records.append({'id':'support.work-template-audit-hash-history-20261020','recordType':'markdown-support','sourcePath':'docs/knowledge/evidence/work-template-write-shape-audit-2026-10-20.md','sourceLocator':'line 13; W5 original hash round-trip limitation','sourceCommit':base,'originalMaturity':{'status':None,'visibility':'internal-evidence'},'auditScope':'historical/legacy W5 limitation only','semanticReviewStatus':'reviewed','conclusion':'evidence-gap','disposition':'historical','reason':'原文是2026-10-20当时失败与边界，新自动事件修复不重写旧证据，不认证所有旧事件可重算。旧W5新行缺陷和不可恢复历史限制必须分开结案。','evidenceReferences':['docs/development/branch-review-20261026-capacity-audit/ledger/findings.json','docs/development/branch-review-20261106-image-verification/W5-COMPATIBILITY-PLAN.md']})
(out/'finite-audit-records.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in sorted(records,key=lambda v:v['id'])))
write('finite-audit-summary.json',{'baselineCommit':base,'knowledgeBaselineVersion':'0.3.25','schemaVersion':'1.2.0','records':len(records),'idRecords':15,'markdownSupportRecords':1,'reviewed':16,'conclusions':{'consistent':14,'evidence-gap':2},'newUniqueOverallCoverage':'not claimed; finite records overlap prior batches and whole-library coverage remains pending','changedKnowledgeFiles':[],'legacyHashAndZipScopeGapsRetained':True})
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/schema.yaml','docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','docs/knowledge/execution-contracts.yaml','docs/knowledge/rules/production.yaml','docs/knowledge/rules/master-data-permission-audit.yaml','docs/knowledge/evidence/ontology-foundation-repair.yaml','docs/knowledge/implementation-anchors/master-data-permission-audit.yaml','docs/knowledge/evidence/work-template-write-shape-audit-2026-10-20.md','docs/knowledge/evidence/signature-payload-storage-2026-10-21.md','docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/development/branch-review-20261106-image-verification/W5-COMPATIBILITY-PLAN.md','docs/development/branch-review-20261106-image-verification/w5-producer-inventory.json','docs/development/branch-review-20261026-capacity-audit/ledger/findings.json','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/Signature.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/common/audit/AuditAspect.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/ProductionObjectController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/WorkOrderController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProductController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/controller/ProcessModelingController.java','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql']
files=[]
for path in paths:
 b=subprocess.check_output(['git','show',base+':'+path],cwd=root);target=out/'baseline-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);files.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'sourceCommit':base})
write('baseline-source-manifest.json',{'sourceCommit':base,'files':files})
dp='docs/development/branch-review-20261106-audit-hash/decision-package.yaml';target=out/'working-tree-decision-package.yaml';shutil.copy2(root/dp,target)
write('baseline.json',{'sourceCommitAtStart':git('rev-parse','HEAD'),'targetBranch':'edhr-dev','targetCommit':git('rev-parse','origin/edhr-dev'),'contractReadCommit':base,'uncommittedContractPaths':[],'decisionPackageWorkingTreeSource':dp,'knowledgeModelVersion':'0.3.25','schemaVersion':'1.2.0','phase':'finite semantic review, final implementation consistency pending main stable-source notice','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
reports=[]
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;reports.append({'class':a['name'],**{k:int(a.get(k,0)) for k in ['tests','failures','errors','skipped']}})
assert sum(v['tests'] for v in reports)==89 and all(v['failures']==v['errors']==v['skipped']==0 for v in reports)
write('knowledge-test-summary.json',{'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','exitCode':0,'classes':reports,'scope':'Formal schema/reference/status/projection validation only; not full semantic or product/PG/UI acceptance'})
print(json.dumps({'knowledgeFiles':len(knowledge),'finiteRecords':len(records),'formalTests':sum(v['tests'] for v in reports),'knowledgeChanged':False},ensure_ascii=False))
