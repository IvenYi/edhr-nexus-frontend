from pathlib import Path
import subprocess,json,hashlib,shutil,re,datetime,yaml,xml.etree.ElementTree as ET
root=Path('/workspace/edhr-nexus-frontend');old=Path('/tmp/edhr-w5-hash-ontology-20261106');out=Path('/tmp/edhr-w5-hash-ontology-text-revision-20261106')
base='9dc5c0014643d99db299d27a80788cc777a0ccca';initial='1c077d2877f760156ab0072f557990c45c1df4b0';priorSha='e7737b05c9ef84eccb1eaa70e37c588b08b3933b1a6a23abed7b9dde0393aff3'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','origin/edhr-dev')==base
assert hashlib.sha256((old/'manifest.json').read_bytes()).hexdigest()==priorSha
prior=json.loads((old/'manifest.json').read_text())
for f in prior['files']:assert hashlib.sha256((old/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
write('prior-original-preservation.json',{'priorRoot':str(old),'priorManifestSha256':priorSha,'allListedOriginalFilesStillMatch':True,'originalFileCount':len(prior['files']),'priorResult':'not-applicable for its initial limited semantic scope, not proof that initial product had no defects','priorResultDisposition':'Historical original retained byte-for-byte; current incremental result covers current helper delta; no old report overwritten'})
inventory=json.loads((old/'knowledge-fingerprint-inventory.json').read_text())
for f in inventory['files']:assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
shutil.copy2(old/'knowledge-fingerprint-inventory.json',out/'knowledge-fingerprint-inventory.json')
for path in ['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md']:
 assert subprocess.check_output(['git','show',base+':'+path],cwd=root)==(root/path).read_bytes(),path
paths=['docs/development/branch-review-20261106-audit-hash/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventHashTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTextPersistencePostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventVarcharPersistencePostgresTest.java']
files=[]
for path in paths:
 data=(root/path).read_bytes();p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);files.append({'path':path,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
write('final-source-manifest.json',{'headCommit':git('rev-parse','HEAD'),'targetCommit':base,'actualContractReadCommit':base,'workingTreeState':git('status','--porcelain'),'sourceFiles':files,'reviewScope':'Uncommitted persisted-text encoding/DP/test delta against initial 1c077d28; not all earlier source re-audited'})
helper=(root/paths[1]).read_text();ddl=(root/paths[5]).read_text();widths=[]
for getter,size in re.findall(r'text\(output, event\.get(\w+)\(\), (\d+)\)',helper):
 field=getter[0].lower()+getter[1:];column=re.sub(r'([A-Z])',lambda m:'_'+m[1].lower(),field);expected=re.search(r'\b'+column+r' character varying\((\d+)\)',ddl)
 assert expected and expected[1]==size,(column,size)
 widths.append({'field':field,'column':column,'codePointWidth':int(size),'matchesCanonicalDdl':True})
assert len(widths)==13
write('varchar-width-check.json',{'canonicalSource':paths[5],'hashWidthSource':paths[1],'columns':widths,'allThirteenMatch':True,'reasonTextNotTruncated':True,'hashAndHashVersionAreNotBusinessTextFieldsInThisList':True})
selected={'term.audit-event','term.audit-change-snapshot','concept.audit-event','relation.audit-event-retains-change-snapshot','rule.master-data.write-audit-snapshot','rule.production.audit-field-localized-display'}
records=[]
for line in (old/'finite-audit-records.jsonl').read_text().splitlines():
 v=json.loads(line)
 if v['id'] not in selected:continue
 v['incrementSourceHead']=initial;v['auditScope']='Only actual-persisted ordinary text encoding correction, not a fresh full original-record or all-domain audit';v['semanticReviewStatus']='reviewed';v['conclusion']='consistent';v['disposition']='retained'
 v['incrementReason']='Hash now uses values already persisted by existing JDBC/PG: malformed standalone UTF16 surrogate becomes ?, and only excess ASCII spaces beyond real varchar code-point width are omitted. Event fields, JSONB leaves, valid supplementary characters, within-width spaces, input acceptance, history and UI policies are unchanged.'
 v['incrementEvidenceReferences']=['final-source-manifest.json','varchar-width-check.json','source-snapshot/'+paths[0]];records.append(v)
assert len(records)==6
(out/'increment-audit-records.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in records))
qroot=Path('/tmp/edhr-w5-hash-quality-20261106');q=yaml.safe_load((qroot/'qualityResult.yaml').read_text())['qualityResult'];assert q['result']=='failed'
for name in ['qualityResult.yaml','text-unicode-probe.jsonl','text-unicode-probe-runtime.json']:
 if (qroot/name).exists():
  target=out/'initial-quality-originals'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(qroot/name,target)
write('initial-quality-context.json',{'sourceRoot':str(qroot),'initialHead':q['headCommit'],'initialResult':'failed','findings':[{'id':f['id'],'severity':f['severity'],'originalResolutionStatus':f.get('resolutionStatus')} for f in q['findings']],'disposition':'Preserve failed original; incremental ontology result is not final quality revalidation and cannot convert failed to passed'})
reports=[]
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;reports.append({'class':a['name'],**{k:int(a.get(k,0)) for k in ['tests','failures','errors','skipped']}})
assert sum(v['tests'] for v in reports)==89 and all(v['failures']==v['errors']==v['skipped']==0 for v in reports)
write('knowledge-test-summary.json',{'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','exitCode':0,'classes':reports,'scope':'Fresh formal knowledge checks only, not native/product/quality tests'})
sync=[]
for ident in ['term.audit-event','term.audit-change-snapshot','relation.audit-event-retains-change-snapshot','rule.master-data.write-audit-snapshot']:
 sync.append({'id':ident,'disposition':'retained','scope':'仅按原JDBC/PG实际持久值封存普通文本hash，不改字段/接收规则/JSONB内容/操作者与事件含义或旧历史；未增加trim政策或Unicode拒绝规则。','sourceReferences':['docs/knowledge/glossary.yaml','docs/knowledge/ontology.yaml','docs/knowledge/rules/master-data-permission-audit.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java']})
sync.append({'id':'scenario.dhr-summary-printable-archive-layout','disposition':'deferred','scope':'与原有限结果相同，完整ZIP广域验收及脱库自足hash复核缺口保留；不以本次文本编码整改关闭。','sourceReferences':['docs/knowledge/decisions/DEC-0063-dhr-summary-and-review-configuration.yaml','docs/development/branch-review-20261106-image-verification/W5-COMPATIBILITY-PLAN.md']})
result={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25','contractBaseline':{'sourceCommit':git('rev-parse','HEAD'),'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},'reason':'对同一DP的engineering.actual-persisted-text增量已有限核对。普通文本hash映射原JDBC未配对UTF16代理项替换值，并只去除13真实varchar宽度外PG原本会截断的ASCII空格；保留event字段、原数据库接收/拒绝、JSONB叶子、合法补充字符和范围内空格。此为新行持久化可重算的工程补全，没有新业务政策或知识含义；350知识与目标逐字节不变，0.3.25/schema1.2.0/P0保持。旧not-applicable及初版failed质量原件均保留，不当当前产品质量通过；旧历史/完整ZIP缺口仍保留。','changedArtifacts':[],'knowledgeSync':sync,'conflicts':[],'questions':[],'validationEvidence':[{'id':'validation.w5-persisted-text-finite-semantics','checkType':'evidence-path','command':'Read current DP engineering.actual-persisted-text, helper delta, canonical DDL and added native/unit test source; compare exact widths and source fingerprints','outcome':'passed','evidence':['increment-audit-records.jsonl: 6 affected records reviewed only in incremental declared scope; no unique overall coverage claimed','varchar-width-check.json: all13 widths match actual DDL, code-point width not UTF16 length','final-source-manifest.json; source-snapshot/']},{'id':'validation.w5-persisted-text-knowledge','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','outcome':'passed','evidence':['knowledge-validation.log; TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml: 89 tests, zero failures/errors/skips','knowledge-test-summary.json; knowledge-fingerprint-inventory.json: 350 unchanged, not full semantic coverage']},{'id':'validation.w5-prior-results-retained','checkType':'evidence-path','command':'Verify original ontology manifest and every original file checksum; preserve initial quality failed result as dated evidence','outcome':'passed','evidence':['prior-original-preservation.json: prior manifest '+priorSha+' and all60 originals unchanged','initial-quality-context.json; initial-quality-originals/qualityResult.yaml: failed for initial 1c077d28']}],'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
(out/'ontologyResult.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=110))
(out/'REVIEW.md').write_text('''# W5 普通文本持久值编码：本体有限增量

正式结果 `not-applicable`。同一DP增加engineering.actual-persisted-text，当前HEAD为1c077d2877f760156ab0072f557990c45c1df4b0，修复在未提交工作树中；目标仍9dc5c001，契约/350知识逐字节不变。旧本体原件保留在原目录，manifest e7737b05c9ef84eccb1eaa70e37c588b08b3933b1a6a23abed7b9dde0393aff3及全部60项原件仍匹配，未静默覆盖或把初版源指纹当新代码。

实际核对范围是普通text/varchar持久值hash编码及相应测试、DP增量；原定义中的6条受影响ID在此子范围一致，不重复声称全量语义审计或新增唯一覆盖。原有限16项（14子范围一致、2gap）保留其原时点与范围；本次不扩张为全库一致。

PG JDBC已会把普通文本未配对UTF16代理项存为问号，PG varchar(n)已会接受并截断超过n个代码点的尾ASCII空格。新helper只在送入摘要的临时字符串上按这些实际持久值编码，不给event字段赋修复值，不全局trim、不改变普通文本接收规则或JSONB叶子编码。正常配对补充字符保持，宽度按代码点；范围内空格保持，超宽部分一旦存在非ASCII空格/非空格仍保留原输入，由原数据库约束拒绝。reason是text，没有varchar截断。逐项核13个宽度与正式baseline DDL全同；snapshot_hash及版本元数据不是这13个业务文本字段。

这不建立新业务数据清洗、Unicode拒绝、截断或历史修复政策，而是让新行摘要匹配原写入链已接受的持久语义。事件标识、操作者、原动作、真实前后值与发生时点仍沿原定义；Signature/DHR/file摘要及普通读取/下载/UI未变。新helper依赖正式varchar宽度，未来变更schema宽度应一并重核编码/测试，不能自动沿旧宽度封存。

已读新原生文本4例、13字段varchar及补充字符/原非空格超宽拒绝共19例，以及新增8项单元声明；本角色没有执行它们或201产品回归。主侧同源文本反证1正3真红与当前201结论应由主侧、全新独立质量分别以原件证明；初版174通过仅历史，新独立初版failed及QF-W5-UTF16-001/QF-W5-VARCHAR-002原件保留，不由本体NA转换为passed。

本角色本次实际重跑正式知识89/89，0失败/错误/跳过；350文件与目标不变，未修改仓库知识/架构/产品/测试/迁移。没有新的概念、状态、业务规则、关系、执行契约、待决问题或知识版本需增设，0.3.25/schema1.2.0/P0 in-progress保持。

旧事件仍可能无法重建丢失的JSON字符/时间依据，当前部分/裁剪ZIP也不能自足复算原事件；两类原缺口保留。既有AuditAspect日志后返回边界保持，不推定49生产者全部原子回滚。原931/86、W2-W7、A12/高风险/完整矩阵、历史/索引、上传及PDF/Office容量、UNKNOWN持久对账与A23及用户暂停项继续，整文件与总体审计完成未新增。
''')
write('increment-summary.json',{'ontologyResult':'not-applicable','reviewedIncrementIds':6,'consistentInDeclaredIncrementScope':6,'knowledgeFilesUnchanged':350,'freshKnowledgeTests':89,'actualProductTestsRunByOntology':[],'priorOntologyPreserved':True,'initialQualityResultPreserved':'failed','currentProductQualityGate':'Fresh independent 201 and signed final quality still required; not executed/certified by ontology role','changedRepositoryFilesByOntology':[],'subagents':[]})
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
write('manifest.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceCommit':git('rev-parse','HEAD'),'targetCommit':base,'priorOntologyManifest':priorSha,'files':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]})
digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n');print(json.dumps({'result':'not-applicable','files':len(files),'manifestSha256':digest,'helperSha256':hashlib.sha256((root/paths[1]).read_bytes()).hexdigest(),'priorAll60Preserved':True},indent=2))
