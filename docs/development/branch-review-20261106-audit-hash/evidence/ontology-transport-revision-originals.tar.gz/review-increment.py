from pathlib import Path
import json,hashlib,subprocess,shutil,datetime,yaml,xml.etree.ElementTree as ET
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-w5-hash-ontology-transport-revision-20261106');base='9dc5c0014643d99db299d27a80788cc777a0ccca';failedHead='f640dc75e5e588da9dd60579157092bfcd0e8148'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert git('rev-parse','origin/edhr-dev')==base
priorRoots=[('/tmp/edhr-w5-hash-ontology-20261106','e7737b05c9ef84eccb1eaa70e37c588b08b3933b1a6a23abed7b9dde0393aff3'),('/tmp/edhr-w5-hash-ontology-text-revision-20261106','a10ab905c1c745867d71d11edaa828839bcbe9202bdda5b46874ac0895602dce')];preserved=[]
for folder,digest in priorRoots:
 p=Path(folder);assert hashlib.sha256((p/'manifest.json').read_bytes()).hexdigest()==digest
 m=json.loads((p/'manifest.json').read_text())
 for f in m['files']:assert hashlib.sha256((p/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
 preserved.append({'originalRoot':folder,'manifestSha256':digest,'allOriginalFilesMatch':True,'listedFiles':len(m['files']),'disposition':'Original not-applicable records retained for their limited historical source/scope; not current product acceptance'})
write('prior-original-preservation.json',{'priorResults':preserved,'noPriorFilesOverwritten':True})
prior=Path(priorRoots[1][0]);inv=json.loads((prior/'knowledge-fingerprint-inventory.json').read_text())
for f in inv['files']:assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256'],f['path']
shutil.copy2(prior/'knowledge-fingerprint-inventory.json',out/'knowledge-fingerprint-inventory.json')
for path in ['AGENTS.md','docs/agents/business-knowledge-modeler.md','docs/agents/agent-handoff-contract.md']:
 assert subprocess.check_output(['git','show',base+':'+path],cwd=root)==(root/path).read_bytes(),path
paths=['docs/development/branch-review-20261106-audit-hash/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventJsonTextPersistencePostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventHashTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTextPersistencePostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventVarcharPersistencePostgresTest.java']
source=[]
for path in paths:
 b=(root/path).read_bytes();p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);source.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
write('final-source-manifest.json',{'sourceHead':git('rev-parse','HEAD'),'failedPreRevisionHead':failedHead,'targetCommit':base,'actualContractReadCommit':base,'workingTreeState':git('status','--porcelain'),'sourceFiles':source,'scope':'Carrier transport normalization before JSON parsing; shared ordinary-text helper extraction, no new DB/semantic policy'})
current=(root/paths[1]).read_text();old=subprocess.check_output(['git','show',failedHead+':'+paths[1]],cwd=root,text=True)
assert current[current.index('    private static void writeJson('):]==old[old.index('    private static void writeJson('):]
assert 'MAPPER.readTree(jdbcUtf8(value))' in current and 'String persisted = jdbcUtf8(value);' in current
write('transport-scope-check.json',{'jsonParsingUsesRawCarrierProjection':True,'ordinaryTextReusesSameProjection':True,'entireParsedJsonLeafAndContainerWriterEqualF640':True,'ordinaryTextWidthRulesUnchangedByInspectedExtraction':True,'eventFieldAssignmentsAdded':False,'jsonbAcceptancePolicyAdded':False,'literalSixCharacterUnicodeEscapeIsNotRawUtf16Surrogate':True,'evidence':'Actual source diff and same-byte tail from private writeJson to end of class; new native rejection control source read'})
records=[]
for line in (prior/'increment-audit-records.jsonl').read_text().splitlines():
 v=json.loads(line);v['incrementSourceHead']=failedHead;v['auditScope']='Only raw Java JSON carrier text JDBC conversion before parse, shared function extraction';v['incrementReason']='Hash parses the JSON carrier text after the same existing JDBC UTF8 raw-surrogate replacement. The event carrier is unchanged; JSON escape characters and parsed JSONB leaf values are not rewritten. This preserves original PG acceptance/refusal and does not add cleanup policy.';v['incrementEvidenceReferences']=['transport-scope-check.json','final-source-manifest.json','source-snapshot/'+paths[0]];records.append(v)
assert len(records)==6
(out/'increment-audit-records.jsonl').write_text(''.join(json.dumps(v,ensure_ascii=False)+'\n' for v in records))
qroot=Path('/tmp/edhr-w5-hash-final-quality-20261106');q=yaml.safe_load((qroot/'qualityResult.yaml').read_text())['qualityResult'];assert q['result']=='failed' and q['headCommit']==failedHead
for name in ['qualityResult.yaml','json-text-persistence-probe.jsonl','json-text-persistence-runtime.json']:
 p=qroot/name
 if p.exists():target=out/'second-quality-originals'/name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
write('second-quality-context.json',{'sourceRoot':str(qroot),'sourceHead':failedHead,'result':'failed','findings':[{'id':f['id'],'severity':f['severity'],'resolutionStatusAtThatTime':f.get('resolutionStatus')} for f in q['findings']],'disposition':'Its201/89,original6-case and59-parameter passes retain historical scope; failed remains failed, fresh206 final quality required'})
reports=[]
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;reports.append({'class':a['name'],**{k:int(a.get(k,0)) for k in ['tests','failures','errors','skipped']}})
assert sum(v['tests'] for v in reports)==89 and all(v['failures']==v['errors']==v['skipped']==0 for v in reports)
write('knowledge-test-summary.json',{'command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','exitCode':0,'classes':reports,'scope':'Fresh formal knowledge checks only; no native or product tests executed by ontology role'})
r=yaml.safe_load((prior/'ontologyResult.yaml').read_text())['ontologyResult'];r['contractBaseline']['sourceCommit']=git('rev-parse','HEAD')
r['reason']='同一DP的engineering.json-carrier-jdbc-text增量只把原Java JSON载体字符串按现有JDBC UTF8转换后再解析，并与普通text路径共用jdbcUtf8；不改event原字段、不替换六字符Unicode转义或解析后的JSONB叶子，不改变数据库接受/拒绝和业务政策。普通文本13个varchar边界、版本/时间、旧行保留、其他摘要与读取规则不变。6条有限受影响记录在该增量范围一致，350知识不变，未新增业务模型或成熟度。前两份本体和两份failed质量原件保留，旧历史/完整ZIP缺口继续；本体结果不代替206全新质量验收。'
for s in r['knowledgeSync']:
 if s['disposition']=='retained':s['scope']='仅把原Java JSON载体按既有JDBC UTF8传输值送入hash解析，共用普通text转换；不改event字段、Unicode转义字面串或解析后的叶子，不增接收/清洗/阻断政策，原事件与业务快照含义保持。'
r['validationEvidence']=[{'id':'validation.w5-json-carrier-semantics','checkType':'evidence-path','command':'Read actual helper diff, current DP and5-native source; compare complete parsed JSON writer to fixed f640 source','outcome':'passed','evidence':['increment-audit-records.jsonl:6 affected records, consistent only in declared transport increment','transport-scope-check.json:raw carrier projection before readTree, ordinarytext shared, parsed leaf/container writer byte-identical to f640','final-source-manifest.json; source-snapshot/']},{'id':'validation.w5-json-carrier-knowledge','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml clean test','outcome':'passed','evidence':['knowledge-validation.log; TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml:89 tests0F/E/S','knowledge-test-summary.json; knowledge-fingerprint-inventory.json:350 files unchanged, not full semantic coverage']},{'id':'validation.w5-prior-text-and-quality-retention','checkType':'evidence-path','command':'Verify both prior ontology manifests and every listed original file; preserve second signed failed quality as original','outcome':'passed','evidence':['prior-original-preservation.json:60 initial and25 text-revision originals unchanged; manifest hashes retained','second-quality-context.json; second-quality-originals/qualityResult.yaml:failed for f640, no failed-to-passed rewrite']}]
(out/'ontologyResult.yaml').write_text(yaml.safe_dump({'ontologyResult':r},allow_unicode=True,sort_keys=False,width=110))
(out/'REVIEW.md').write_text('''# W5 JSON载体传输：本体最小增量核对

正式结果not-applicable，限同一DP的engineering.json-carrier-jdbc-text。当前固定起点f640dc75e5e588da9dd60579157092bfcd0e8148，目标9dc5c001，修复为未提交稳定工作树，指纹和当前HEAD见final-source-manifest.json。前两份本体原件根目录不动：e7737b05…初版60文件、a10ab905…普通文本增量25文件全部仍匹配原manifest；本次另根输出，不静默覆盖旧结论或抹去失败阶段。

本次实际读helper diff、DP新增工程声明及5项native测试源码。6条有限受影响记录在该增量范围一致，没有重新统计全库覆盖或累计unique完成。新helper从text抽取同一个jdbcUtf8，用于普通text/varchar投影之前，也用于原Java JSON载体String送入readTree之前；只有原Java字符串中未配对UTF16代理项按照PG JDBC既有传输替换成为问号。合法补充字符成对保留。

原ObjectMapper可生成仍含原始未配对Java代理项的JSON载体，数据库经JDBC替换后能接受；新hash现在按该实际传输值解析，匹配已存JSONB。event.getContentBefore/After仍保持输入字段，不向实体写回修复后的内容。字面六字符反斜杠Unicode转义不是原始代理项，不会被jdbcUtf8改写；解析后的JSONB叶子和容器写法与f640整段逐字节相同，没有叶子替换或全局parser政策。原字面不合法转义仍由PG拒绝，新测试保留此原生反例。因此这是摘要适配既有存储传输的工程补全，不是新业务清洗、接受无效JSON或改写历史政策。

普通文本此前13个varchar代码点宽度及仅超界ASCII空格投影保持，正常范围内空格、原非空格超宽拒绝保持；JSON字段不套用varchar截断。新变更不修改实体版本分派/微秒时点、迁移、事件身份/操作者/原动作、UI或下载；Signature/DHR/file摘要继续独立。共享小函数属于本域重复逻辑抽取，没有增加通用框架或新权限。

第二全新质量原件在f640正式failed：原201/89、六例、59参数通过只覆盖当时范围，新增QF-W5-JSON-UTF16-003保持原记录。本体读取这些失败证据，不把历史通过覆盖当前候选，也不把本体NA当成产品缺陷已独立验收。新5native同源2正3真红与最终206应由主侧及下一全新质量各自原件说明；本角色只读测试声明，不执行或代称运行业务/PG/206验证。

本角色本次实际重跑正式知识模块89/89，零失败/错误/跳过；350知识及适用契约与目标不变，没有修改仓库知识/架构/产品/测试/配置/迁移。知识0.3.25/schema1.2.0/P0 in-progress保持，没有新概念、关系、状态、业务规则、执行契约或待决政策需要增设。

原不可恢复旧审计JSON字符/时间依据、完整ZIP广域与脱库自足复算缺口继续。既有AuditAspect日志返回边界保持，不以49共享入口推定全事务验收。原931/86、W2-W7、A12/高风险/完整矩阵、历史/索引、上传及PDF/Office容量、UNKNOWN持久对账、A23及用户暂停项继续；整文件/整体审计完成未新增。
''')
write('increment-summary.json',{'result':'not-applicable','incrementReviewedIds':6,'incrementConsistent':6,'knowledgeFilesUnchanged':350,'freshKnowledgeTests':89,'actualProductTestsRunByOntology':[],'bothPriorOntologiesUnchanged':True,'secondQualityOriginal':'failed','currentProductGate':'Fresh final206 independent quality still required, not certified here','subagents':[],'repositoryFilesModifiedByOntology':[]})
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
write('manifest.json',{'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceHead':git('rev-parse','HEAD'),'targetCommit':base,'files':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]})
digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n');print(json.dumps({'result':'not-applicable','files':len(files),'manifestSha256':digest,'helperSha256':hashlib.sha256((root/paths[1]).read_bytes()).hexdigest(),'bothPriorOriginalsIntact':True},indent=2))
