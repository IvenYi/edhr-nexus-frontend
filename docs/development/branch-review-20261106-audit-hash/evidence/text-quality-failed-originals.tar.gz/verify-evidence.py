from pathlib import Path
import json,hashlib,tarfile,subprocess,xml.etree.ElementTree as ET,datetime,shutil
r=Path('/tmp/edhr-w5-hash-final-quality-worktree-20261106');out=Path('/tmp/edhr-w5-hash-final-quality-20261106');batch=r/'docs/development/branch-review-20261106-audit-hash';base='9dc5c0014643d99db299d27a80788cc777a0ccca';head='f640dc75e5e588da9dd60579157092bfcd0e8148'
def write(n,v):(out/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
retained={};archives=[];total=0
for manifest in ['archive-manifest.json','correction-archive-manifest.json']:
 for a in json.loads((batch/'evidence'/manifest).read_text())['archives']:
  p=batch/'evidence'/a['archive'];assert hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256']
  with tarfile.open(p) as tar:
   names={m.name for m in tar.getmembers() if m.isfile()};assert names=={v['path'] for v in a['files']}
   for f in a['files']:
    data=tar.extractfile(f['path']).read();assert len(data)==f['bytes'];assert hashlib.sha256(data).hexdigest()==f['sha256'];total+=1
    if a['archive']=='main-originals.tar.gz' and f['path'].startswith('negative/'):retained[f['path']]=data
    if a['archive']=='corrected-main-originals.tar.gz' and f['path'].startswith('unicode/'):retained[f['path']]=data
    if a['archive'] in ['ontology-originals.tar.gz','ontology-text-revision-originals.tar.gz','initial-quality-originals.tar.gz'] and f['path'] in ['ontologyResult.yaml','qualityResult.yaml','finite-audit-records.jsonl','increment-audit-records.jsonl','manifest.json','manifest.sha256','final-source-manifest.json']:
     target=out/'retained-role-originals'/a['archive'].replace('.tar.gz','')/f['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  archives.append({'archive':a['archive'],'files':len(a['files']),'sha256':a['sha256'],'allMatch':True})
assert len(archives)==6 and total==1181
write('archive-check.json',{'archives':archives,'files':total,'allMatch':True})
entity='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java';jsonTest='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventRoundTripPostgresTest.java';textTest='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTextPersistencePostgresTest.java'
assert retained['negative/source/'+entity]==subprocess.check_output(['git','show',base+':'+entity],cwd=r)
assert retained['negative/source/'+jsonTest]==(r/jsonTest).read_bytes();assert retained['unicode/source/'+textTest]==(r/textTest).read_bytes()
negative=[]
for stage,test,expected in [('negative','AuditEventRoundTripPostgresTest',{'tests':2,'failures':2,'errors':0,'skipped':0}),('unicode','AuditEventTextPersistencePostgresTest',{'tests':4,'failures':3,'errors':0,'skipped':0})]:
 tree=ET.fromstring(retained[stage+'/TEST-com.zencas.edhr.compliance.entity.'+test+'.xml']);counts={k:int(tree.attrib[k]) for k in expected};assert counts==expected
 failures=[{'test':c.attrib['name'],'assertion':c.find('failure').attrib['message']} for c in tree.findall('testcase') if c.find('failure') is not None];assert all('expected:' in f['assertion'] and 'but was:' in f['assertion'] for f in failures)
 negative.append({'stage':stage,'counts':counts,'failures':failures,'sameTestAsFinalCandidate':True})
write('negative-controls.json',{'oldEntityEqualsBase':True,'controls':negative,'scope':'Original JSON/time failures and initial-v2 text failures retained, not compilation/setup errors; normal supplementary text positive kept.'})
protected=[]
for p in git('ls-tree','-r','--name-only',base).splitlines():
 if p.startswith('docs/knowledge/') or p.startswith('docs/agents/') or p in ['AGENTS.md','codeplzreadme.md']:
  data=subprocess.check_output(['git','show',base+':'+p],cwd=r);assert (r/p).read_bytes()==data,p;protected.append({'path':p,'sha256':hashlib.sha256(data).hexdigest()})
assert sum(p['path'].startswith('docs/knowledge/') for p in protected)==350
changes=git('diff','--name-status',base+'..'+head).splitlines();runtime=[p for p in changes if '/src/main/' in p];assert len(runtime)==4
assert not any('gmp-platform/frontend/' in p or 'Signature.java' in p or 'DhrArchiveService.java' in p or 'AuditController.java' in p or '/baseline/' in p for p in changes)
write('knowledge-contract-scope.json',{'base':base,'head':head,'latestFetchedTarget':git('rev-parse','origin/edhr-dev'),'protectedFiles':protected,'knowledgeFilesUnchanged':350,'runtimeDelta':runtime,'allDiff':changes,'finiteScope':'Initial16=14 consistent/2 retained gaps; increment6 affected records retained, not additive unique. Whole-file completion0/historical unique unknown; W2-W7/931/86/A12/high/large-capacity/UNKNOWN/A23 and paused queues remain.'})
font=json.loads((batch/'runtime-font.json').read_text());assert hashlib.sha256(Path(font['path']).read_bytes()).hexdigest()==font['sha256'];write('font-check.json',{'matches':True,'font':font})
vector=['audit-event-v2','1','default','AUDIT_PROBE','42','UPDATE',None,[{'a':'原始变更','z':1}],'7','审查人员','audit-probe','UI','审计','审计验证','修改','对象42','验证持久化','127.0.0.1','2026-11-06T12:00:00.123456'];encoded=json.dumps(vector,ensure_ascii=False,separators=(',',':'));digest=hashlib.sha256(encoded.encode()).hexdigest();assert digest=='ebfb3e7a6cda30e0d9c91cd58b7939c4e5cb2cefeba9597343dd1023b10a1e81'
write('fixed-vector.json',{'encoded':encoded,'sha256':digest,'method':'Independent Python UTF8/JSON/SHA256 fixed vector, no product helper'})
print(json.dumps({'archives':6,'files':total,'knowledgeFiles':350,'negativeControls':len(negative),'runtimeFiles':4}))
