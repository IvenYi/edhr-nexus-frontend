import com.zencas.edhr.compliance.entity.AuditEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
public class TextUnicodeProbe {
 public static void main(String[] args)throws Exception {
  var mapper=new ObjectMapper();
  try(var c=DriverManager.getConnection(args[0],"postgres","")) {
   c.createStatement().execute("CREATE TABLE audit_event(id bigint,operator_name varchar(128),data_summary varchar(512),created_at timestamp,snapshot_hash text,snapshot_hash_version text)");
   int id=1;
   for(String[] values:List.of(new String[]{"normal","中文😀",null},new String[]{"high","\uD800",null},new String[]{"low","\uDC00",null},new String[]{"mixed","x\uD800y",null},new String[]{"name_trailing_space","N".repeat(128)+" ",null},new String[]{"summary_trailing_space","normal","S".repeat(512)+" "})) {
    String name=values[1],summary=values[2];
    var event=AuditEvent.builder().id((long)id).entityType("TEXT_PROBE").entityId("42").action("UPDATE").operatorName(name).dataSummary(summary).createdAt(LocalDateTime.parse("2026-11-06T12:00:00.123456")).build();
    String legacy=event.computeSnapshotHash();event.sealSnapshotHash();
    var record=new LinkedHashMap<String,Object>();record.put("id",id);record.put("case",values[0]);record.put("inputUtf16",name.chars().mapToObj(x->String.format("%04X",x)).toList());record.put("inputNameCodePoints",name.codePointCount(0,name.length()));record.put("inputSummaryLength",summary==null?null:summary.length());
    try(var insert=c.prepareStatement("INSERT INTO audit_event VALUES(?,?,?,?,?,?)")) {
     insert.setInt(1,id);insert.setString(2,name);insert.setString(3,summary);insert.setObject(4,event.getCreatedAt());insert.setString(5,event.getSnapshotHash());insert.setString(6,event.getSnapshotHashVersion());insert.executeUpdate();
     try(var q=c.prepareStatement("SELECT * FROM audit_event WHERE id=?")) {
      q.setInt(1,id);try(var rs=q.executeQuery()){rs.next();event.setOperatorName(rs.getString("operator_name"));event.setDataSummary(rs.getString("data_summary"));event.setCreatedAt(rs.getObject("created_at",LocalDateTime.class));record.put("storedUtf16",event.getOperatorName().chars().mapToObj(x->String.format("%04X",x)).toList());record.put("storedNameCodePoints",event.getOperatorName().codePointCount(0,event.getOperatorName().length()));record.put("storedSummaryLength",event.getDataSummary()==null?null:event.getDataSummary().length());record.put("v2StoredHash",rs.getString("snapshot_hash"));record.put("v2RecomputedHash",event.computeSnapshotHash());record.put("v2Matches",event.computeSnapshotHash().equals(rs.getString("snapshot_hash")));event.setSnapshotHashVersion(null);record.put("legacyMatches",legacy.equals(event.computeSnapshotHash()));}
     }
    } catch(Exception ex) {record.put("failure",ex.toString());}
    System.out.println(mapper.writeValueAsString(record));id++;
   }
  }
 }
}
