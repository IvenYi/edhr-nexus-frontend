import com.zencas.edhr.compliance.entity.AuditEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
public class JsonTextPersistenceProbe {
 public static void main(String[] args) throws Exception {
  var mapper=new ObjectMapper();
  try(var connection=DriverManager.getConnection(args[0],"postgres","")) {
   connection.createStatement().execute("CREATE TABLE probe(id bigint,content_after jsonb,snapshot_hash text)");
   int id=1;
   for(String[] item:List.of(new String[]{"paired","{\"value\":\"中文😀\"}"},new String[]{"raw_high_value","{\"value\":\"\uD800\"}"},new String[]{"raw_low_key","{\"\uDC00\":1}"},new String[]{"escaped_high","{\"value\":\"\\uD800\"}"},new String[]{"mapper_high",mapper.writeValueAsString(Map.of("value","\uD800"))})) {
    var event=AuditEvent.builder().id((long)id).entityType("JSON_TEXT_PROBE").entityId("42").action("UPDATE").createdAt(LocalDateTime.parse("2026-11-06T12:00:00.123456")).contentAfter(item[1]).build();
    var row=new LinkedHashMap<String,Object>();row.put("case",item[0]);row.put("inputUtf16",item[1].chars().mapToObj(c->String.format("%04X",c)).toList());
    try {
     event.sealSnapshotHash();
     try(var insert=connection.prepareStatement("INSERT INTO probe VALUES(?,?::jsonb,?)")) {insert.setInt(1,id);insert.setString(2,item[1]);insert.setString(3,event.getSnapshotHash());insert.executeUpdate();}
     try(var query=connection.prepareStatement("SELECT content_after::text,snapshot_hash FROM probe WHERE id=?")) {query.setInt(1,id);try(var rs=query.executeQuery()){rs.next();event.setContentAfter(rs.getString(1));row.put("storedJson",event.getContentAfter());row.put("storedHash",rs.getString(2));row.put("recomputedHash",event.computeSnapshotHash());row.put("matches",rs.getString(2).equals(event.computeSnapshotHash()));}}
    } catch(Exception failure) {row.put("failure",failure.toString());}
    System.out.println(mapper.writeValueAsString(row));id++;
   }
  }
 }
}
