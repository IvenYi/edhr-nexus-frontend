from pathlib import Path
import subprocess,os,sys,time,json,datetime,hashlib,shutil,xml.etree.ElementTree as ET
root=Path(os.environ.get('EDHR_AUDIT_ROOT','/workspace/edhr-nexus-frontend'));phase=sys.argv[1];assert phase in ['negative','final','retry','final2','unicode','corrected','corrected2','jsontext','transport','transport2']
raw=Path(os.environ.get('EDHR_HASH_RAW','/tmp/edhr-w5-hash-20261106'));raw.mkdir(exist_ok=True);out=raw/phase;out.mkdir(exist_ok=False)
name='edhr-w5-hash-main-'+phase+'-20261106';db='edhr_audit_hash_test_'+phase;created=False;code=1
selected='AuditEventRoundTripPostgresTest'
if phase!='negative':selected+=',AuditEventHashTest,AuditEventTest,AuditEventHashCompatibilityPostgresTest,AuditHashMigrationPostgresTest,CurrentDatabaseBaselinePostgresTest,AuditAspectTest,AuditControllerTest,DhrAuditReadTest,DhrAttachmentUploadVerifyObservationPostgresTest,DhrAttachmentImageVerificationTest,DhrAttachmentAndArchiveTest,AuthControllerTest,SignatureSnapshotPostgresTest,DhrAttachmentTransactionPostgresTest'
if phase=='unicode':selected='AuditEventTextPersistencePostgresTest'
if phase=='jsontext':selected='AuditEventJsonTextPersistencePostgresTest'
if phase in ['corrected','corrected2','transport','transport2']:selected+=',AuditEventTextPersistencePostgresTest,AuditEventVarcharPersistencePostgresTest'
if phase in ['transport','transport2']:selected+=',AuditEventJsonTextPersistencePostgresTest'
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.25)
 else:raise RuntimeError('own PG unavailable')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env=os.environ.copy();env.update(PGUSER='postgres',PGPASSWORD='',EDHR_AUTHORIZATION_NOTICE_FONT='/workspace/.edhr-cloud-tools/fonts/EdhrTestCJK-Regular.ttf')
 env['AUDIT_HASH_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/{db}'
 if phase!='negative':
  run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE ROLE edhr LOGIN SUPERUSER']);run(['docker','exec',name,'createdb','-U','postgres','-O','edhr','edhr_signature_test']);env['SIGNATURE_TEST_DATABASE_URL']=f'jdbc:postgresql://127.0.0.1:{port}/edhr_signature_test'
  for key,database in [('AUDIT_HASH_MIGRATION_DATABASE_URL','edhr_audit_hash_migration_test_'+phase),('BASELINE_TEST_DATABASE_URL','edhr_baseline_test_hash_'+phase),('DHR_ATTACHMENT_WRITE_DATABASE_URL','edhr_dhr_attachment_write_test_hash_'+phase)]:
   run(['docker','exec',name,'createdb','-U','postgres',database]);env[key]=f'jdbc:postgresql://127.0.0.1:{port}/{database}'
  run(['docker','exec',name,'createdb','-U','postgres','edhr_dhr_attachment_transaction_test']);env.update(EDHR_DHR_ATTACHMENT_TX_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_dhr_attachment_transaction_test',EDHR_DHR_ATTACHMENT_TX_DATABASE_USER='postgres',EDHR_DHR_ATTACHMENT_TX_DATABASE_PASSWORD='')
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.hash=true','-Dedhr.audit.hashOutput='+str(out/'observations'),'-Dedhr.audit.attachmentUploadVerify=true','-Dedhr.audit.attachmentWriteOutput='+str(out/'attachments'),'-DargLine=-Xmx1536m','-Dtest='+selected,'test']
 start=datetime.datetime.now(datetime.timezone.utc);fps=[]
 paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/development/branch-review-20261106-audit-hash/decision-package.yaml']
 paths+=[str(p.relative_to(root)) for p in (root/'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity').glob('AuditEvent*.java')]
 paths+=['gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml'];paths+=['gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql'] if phase!='negative' else []
 for test in selected.split(','):
  found=list((root/'gmp-platform/backend/src/test/java').rglob(test+'.java'));assert len(found)==1,test;paths.append(str(found[0].relative_to(root)))
 for path in paths:
  b=(root/path).read_bytes();fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 (out/'run.json').write_text(json.dumps({'command':command,'head':run(['git','rev-parse','HEAD'],cwd=root),'status':run(['git','status','--porcelain'],cwd=root),'startedAt':start.isoformat(),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':fps},indent=2)+'\n')
 totals={k:0 for k in ['tests','failures','errors','skipped']};classes=[];missing=[]
 for test in selected.split(','):
  reports=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not reports:missing.append(test)
  for p in reports:
   shutil.copy2(p,out/p.name);doc=ET.parse(p).getroot();values={k:int(doc.attrib.get(k,0)) for k in totals};classes.append({'class':doc.attrib['name'],**values})
   for k in totals:totals[k]+=values[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-2100:]);code=0 if result.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n');print('owned PG cleanup',removed)
sys.exit(code)
