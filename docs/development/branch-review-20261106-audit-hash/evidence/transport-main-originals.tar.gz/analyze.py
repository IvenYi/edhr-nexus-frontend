from pathlib import Path
import json,re,collections,hashlib,shutil,subprocess,xml.etree.ElementTree as ET
r=Path('/workspace/edhr-nexus-frontend');raw=Path('/tmp/edhr-w5-hash-20261106');out=r/'docs/development/branch-review-20261106-audit-hash';base='9dc5c0014643d99db299d27a80788cc777a0ccca'
def write(name,data):(out/name).write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def norm(s):return ' '.join(re.sub(r'\$\d+','?',s).lower().split())
negative=json.loads((raw/'negative/test-summary.json').read_text());final=json.loads((raw/'transport/test-summary.json').read_text());unicode=json.loads((raw/'unicode/test-summary.json').read_text());jsontext=json.loads((raw/'jsontext/test-summary.json').read_text())
assert negative['totals']=={'tests':2,'failures':2,'errors':0,'skipped':0};assert final['totals']=={'tests':206,'failures':0,'errors':0,'skipped':0};assert unicode['totals']=={'tests':4,'failures':3,'errors':0,'skipped':0};assert jsontext['totals']=={'tests':5,'failures':3,'errors':0,'skipped':0}
test='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventRoundTripPostgresTest.java';assert (raw/'negative/source'/test).read_bytes()==(raw/'transport/source'/test).read_bytes()==(r/test).read_bytes()
textTest='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventTextPersistencePostgresTest.java';assert (raw/'unicode/source'/textTest).read_bytes()==(raw/'transport/source'/textTest).read_bytes()==(r/textTest).read_bytes()
carrierTest='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventJsonTextPersistencePostgresTest.java';assert (raw/'jsontext/source'/carrierTest).read_bytes()==(raw/'transport/source'/carrierTest).read_bytes()==(r/carrierTest).read_bytes()
event='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java';assert (raw/'negative/source'/event).read_bytes()==subprocess.check_output(['git','show',base+':'+event],cwd=r)
parts=re.split(r'(?=^\d{4}-\d\d-\d\d .*? UTC \[\d+\])',(raw/'transport/postgres.log').read_text(),flags=re.M);sql=collections.defaultdict(collections.Counter)
for part in parts:
 m=re.search(r'edhr_audit_hash_test_transport (audit_hash_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',part,re.S)
 if m:sql[m.group(1)][norm(m.group(2).strip())]+=1
core=[]
for name in ['json','time']:
 for suffix in ['write','read']:
  counter=sql['audit_hash_'+name+'_'+suffix];business={s:n for s,n in counter.items() if 'pg_catalog.pg_type' not in s and s.startswith(('select','insert','update','delete'))};assert sum(business.values())==1,(name,suffix,business)
  assert next(iter(business)).startswith('insert' if suffix=='write' else 'select')
  core.append({'tag':'audit_hash_'+name+'_'+suffix,'businessStatements':business,'driverMetadataStatements':{s:n for s,n in counter.items() if 'pg_catalog.pg_type' in s}})
roundtrips=[]
for p in sorted((raw/'transport/observations').glob('*.json')):
 data=json.loads(p.read_text())
 if 'storedHash' in data:
  consistent=data['storedHash']==data['recomputedHash'];assert consistent or p.stem=='provided'
  roundtrips.append({'name':p.stem,'hashMatches':consistent,'providedLegacyNotCertified':p.stem=='provided','requestedTime':data['requestedTime'],'sealedTime':data['sealedTime'],'storedTime':data['storedTime']})
assert len(roundtrips)==38,len(roundtrips)
alloc=[json.loads((raw/'transport/observations'/f'allocation_{n}mib.json').read_text()) for n in [1,10]]
knowledge=[]
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,raw/'knowledge'/p.name);a=ET.parse(p).getroot().attrib;knowledge.append({k:int(a[k]) for k in ['tests','failures','errors','skipped']})
assert knowledge==[{'tests':89,'failures':0,'errors':0,'skipped':0}]
write('main-validation.json',{'baseCommit':base,'negative':negative,'textNegative':unicode,'jsonCarrierNegative':jsontext,'final':final,'knowledge':knowledge,'oldAndNewRoundtripTestByteIdentical':True,'beforeAndAfterTextTestByteIdentical':True,'beforeAndAfterJsonCarrierTestByteIdentical':True,'roundTrips':roundtrips,'sqlCoreProbe':core,'initialIndependent':'1c077d28 had174/89 passed but independent quality failed two medium text persistence boundaries; f640 had201/89 and original6 probes/59 bound parameter hashes passed but fresh independent failed raw JSON carrier UTF16. All failed originals retained; main fixed and another fresh final QA required.','producerScope':'Configuration controller+real repositories; real aspect with synthetic joinpoint+real repository; actual signature audit producer invoked on target with synthetic user/signature/request+real JPA, not full certification; real attachment native27 now rehashes actual events; Signature native9 independent from AuditEvent.','intermediateAttempts':[{'phase':'final','tests':163,'failures':0,'errors':4,'cause':'new test private producer invoked CGLIB proxy without target fields;3 existing Auth PDF tests lacked configured font'},{'phase':'retry','tests':174,'failures':1,'errors':1,'cause':'new test generic invoke overload inferred Class target; existing PDF extraction differed due Noto duplicate glyph mappings; main corrected explicit Object target and existing test font config, no lowered assertions'}]})
write('performance-report.json',{'observations':alloc,'interpretation':'New v2 correctness fix streams canonical output but still parses JSON trees and sorts object keys; not constant memory. Measurements use same simple large text JSON and retained legacy method, allocation is calling-thread cumulative heap, not peak/RSS/native/concurrency; timing one local sample, not SLA.','sql':'Core automatic persist has1 INSERT, reload1 SELECT; metadata type SELECT separated. No hash-specific SQL or DB normalization roundtrip.','otherCapacity':'Wide-object sorting/production concurrency and upload/PDF/Office/export/UNKNOWN capacity queues remain; no new cap or policy introduced.'})
protected=[]
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base],cwd=r,text=True).splitlines()
for p in paths:
 if p.startswith('docs/knowledge/') or p.startswith('docs/agents/') or p in ['AGENTS.md','codeplzreadme.md']:
  before=subprocess.check_output(['git','show',base+':'+p],cwd=r);assert (r/p).read_bytes()==before,p;protected.append({'path':p,'sha256':hashlib.sha256(before).hexdigest()})
write('inventory-and-scope.json',{'baseCommit':base,'trackedPaths':len(paths),'unchangedKnowledgeAndContracts':protected,'wholeFileCompletionThisBatch':0,'historicalUniqueCoverage':'unknown; finite16=14 consistent/2gap differs from last batch16, not newly additive','remaining':'Whole audit W2-W7/931 knowledge/86UI/A12/high/full matrices/history/text-ID index/large upload/PDF/Office/export/UNKNOWN reconciliation/A23 including reviewed code and paused friend signature/modal queues retained.','issue':'W5-AUDIT-HASH-001 old issue reused; only new auto events can close after fresh QA; old unmarked history remains nonrecomputable, full/cropped ZIP self-contained verification not implemented.'})
font=Path('/workspace/.edhr-cloud-tools/fonts/EdhrTestCJK-Regular.ttf');write('runtime-font.json',{'path':str(font),'bytes':font.stat().st_size,'sha256':hashlib.sha256(font.read_bytes()).hexdigest(),'scope':'Existing AuthController authorization PDF test environment only; no test expectation/product font logic change.'})
print(json.dumps({'tests':206,'knowledge':89,'roundTrips':len(roundtrips),'coreSQLCases':len(core),'allocations':alloc},indent=2))
