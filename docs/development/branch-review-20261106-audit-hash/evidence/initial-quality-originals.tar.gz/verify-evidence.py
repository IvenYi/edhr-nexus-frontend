from pathlib import Path
import json,hashlib,tarfile,subprocess,xml.etree.ElementTree as ET,collections,re,shutil,datetime
r=Path('/tmp/edhr-w5-hash-quality-worktree-20261106');out=Path('/tmp/edhr-w5-hash-quality-20261106');batch=r/'docs/development/branch-review-20261106-audit-hash';base='9dc5c0014643d99db299d27a80788cc777a0ccca';head='1c077d2877f760156ab0072f557990c45c1df4b0'
def write(name,obj):(out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git',*a],cwd=r,text=True).strip()
manifest=json.loads((batch/'evidence/archive-manifest.json').read_text());count=0;archiveSummary=[];retained={}
for a in manifest['archives']:
 p=batch/'evidence'/a['archive'];assert hashlib.sha256(p.read_bytes()).hexdigest()==a['sha256']
 with tarfile.open(p) as tar:
  names={m.name for m in tar.getmembers() if m.isfile()};assert names=={v['path'] for v in a['files']}
  for f in a['files']:
   data=tar.extractfile(f['path']).read();assert len(data)==f['bytes'];assert hashlib.sha256(data).hexdigest()==f['sha256'];count+=1
   if a['archive']=='main-originals.tar.gz' and (f['path'].startswith('negative/') or f['path'].endswith('test-summary.json')):retained[f['path']]=data
   if a['archive']=='ontology-originals.tar.gz' and f['path'] in ['finite-audit-records.jsonl','final-source-manifest.json','knowledge-fingerprint-inventory.json']:(out/('ontology-'+f['path'])).write_bytes(data)
 archiveSummary.append({'archive':a['archive'],'files':len(a['files']),'sha256':a['sha256'],'allSizesAndChecksumsMatch':True})
assert count==699
write('archive-check.json',{'archives':archiveSummary,'files':count,'allMatch':True})
testPath='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity/AuditEventRoundTripPostgresTest.java';entityPath='gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java'
assert retained['negative/source/'+testPath]==(r/testPath).read_bytes();assert retained['negative/source/'+entityPath]==subprocess.check_output(['git','show',base+':'+entityPath],cwd=r)
xml=ET.fromstring(retained['negative/TEST-com.zencas.edhr.compliance.entity.AuditEventRoundTripPostgresTest.xml']);assert all(int(xml.attrib[k])==v for k,v in {'tests':2,'failures':2,'errors':0,'skipped':0}.items());failures=[]
for case in xml.findall('testcase'):
 f=case.find('failure');assert f is not None and 'expected:' in f.attrib['message'] and 'but was:' in f.attrib['message'];failures.append({'test':case.attrib['name'],'assertion':f.attrib['message']})
write('negative-control-check.json',{'negativeSourceEqualsBase':True,'negativeTestEqualsCandidate':True,'tests':2,'failures':failures,'errors':0,'skipped':0,'genuineHashMismatch':True,'originalIntermediateSummaries':[json.loads(retained[s]) for s in ['final/test-summary.json','retry/test-summary.json','final2/test-summary.json']]})
protected=[]
for p in git('ls-tree','-r','--name-only',base).splitlines():
 if p.startswith('docs/knowledge/') or p.startswith('docs/agents/') or p in ['AGENTS.md','codeplzreadme.md']:
  b=subprocess.check_output(['git','show',base+':'+p],cwd=r);assert (r/p).read_bytes()==b,p;protected.append({'path':p,'sha256':hashlib.sha256(b).hexdigest(),'unchanged':True})
assert sum(e['path'].startswith('docs/knowledge/') for e in protected)==350
diff=git('diff','--name-status',base+'..'+head).splitlines();runtime=[v for v in diff if '/src/main/' in v];assert len(runtime)==4,runtime
assert all(not any(x in v for x in ['gmp-platform/frontend/','Signature.java','DhrArchiveService.java','AuditController.java','baseline/0001']) for v in diff)
write('knowledge-contract-check.json',{'baseCommit':base,'headCommit':head,'latestFetchedTarget':git('rev-parse','origin/edhr-dev'),'knowledgeFilesUnchanged':350,'protected':protected,'runtimeDelta':runtime,'allDiff':diff,'ontologyScope':'16 finite records:14 consistent/2gap, not same set as previous16 and not additive unique coverage; no knowledge maturity upgrade','historyStatus':'Old W5 original record retained, current claim limited to new auto events; legacy/ZIP/full audit not closed'})
font=json.loads((batch/'runtime-font.json').read_text());assert hashlib.sha256(Path(font['path']).read_bytes()).hexdigest()==font['sha256'];write('font-check.json',{'font':font,'matches':True,'scope':'existing authorization PDF test environment only'})
payload=['audit-event-v2','1','default','AUDIT_PROBE','42','UPDATE',None,[{'a':'原始变更','z':1}],'7','审查人员','audit-probe','UI','审计','审计验证','修改','对象42','验证持久化','127.0.0.1','2026-11-06T12:00:00.123456'];encoded=json.dumps(payload,ensure_ascii=False,separators=(',',':'));fixed=hashlib.sha256(encoded.encode()).hexdigest();assert fixed=='ebfb3e7a6cda30e0d9c91cd58b7939c4e5cb2cefeba9597343dd1023b10a1e81';write('independent-fixed-vector.json',{'encoding':encoded,'sha256':fixed,'source':'Python UTF8 JSON array and hashlib, independent from Java helper'})
print(json.dumps({'archiveFiles':count,'knowledgeFiles':350,'runtimeFiles':len(runtime),'negativeFailures':2,'vector':fixed}))
