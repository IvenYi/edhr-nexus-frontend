from pathlib import Path
import subprocess,time,json,xml.etree.ElementTree as ET,hashlib,datetime
root=Path('/tmp/edhr-w5-hash-quality-20261106');name='edhr-w5-hash-quality-text-probe-20261106';created=False
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout.strip()
try:
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(100):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.1)
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);xml=ET.parse(root/'final2/TEST-com.zencas.edhr.compliance.entity.AuditEventHashTest.xml').getroot();cp=next(v.attrib['value'] for v in xml.find('properties') if v.attrib.get('name')=='java.class.path')
 compileCommand=['/workspace/.edhr-cloud-tools/jdk-21/bin/javac','-proc:none','-cp',cp,str(root/'TextUnicodeProbe.java')];command=['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-cp',str(root)+':'+cp,'TextUnicodeProbe',f'jdbc:postgresql://127.0.0.1:{port}/postgres'];(root/'text-probe-classpath.txt').write_text(cp+'\n')
 run(compileCommand);text=run(command);(root/'text-unicode-probe.jsonl').write_text(text+'\n')
 (root/'text-unicode-probe-runtime.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'1c077d2877f760156ab0072f557990c45c1df4b0','compileCommand':compileCommand,'executeCommand':command,'classpathSha256':hashlib.sha256(cp.encode()).hexdigest(),'probeSourceSha256':hashlib.sha256((root/'TextUnicodeProbe.java').read_bytes()).hexdigest(),'classFiles':[{'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in ['/tmp/edhr-w5-hash-quality-worktree-20261106/gmp-platform/backend/target/classes/com/zencas/edhr/compliance/entity/AuditEvent.class','/tmp/edhr-w5-hash-quality-worktree-20261106/gmp-platform/backend/target/classes/com/zencas/edhr/compliance/entity/AuditEventHash.class']]},indent=2)+'\n')
 print(json.dumps([{'case':r['case'],'v2Matches':r.get('v2Matches'),'legacyMatches':r.get('legacyMatches'),'inputName':r['inputNameCodePoints'],'storedName':r.get('storedNameCodePoints'),'inputSummary':r['inputSummaryLength'],'storedSummary':r.get('storedSummaryLength')} for r in map(json.loads,text.splitlines())]))
finally:
 if created:run(['docker','stop',name]);(root/'text-unicode-probe-cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':True})+'\n')
