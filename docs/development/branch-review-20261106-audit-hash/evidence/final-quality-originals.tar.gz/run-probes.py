from pathlib import Path
import subprocess,time,json,xml.etree.ElementTree as ET,hashlib,datetime,shutil
out=Path('/tmp/edhr-w5-hash-transport-quality-20261106');work=Path('/tmp/edhr-w5-hash-transport-quality-worktree-20261106');name='edhr-w5-hash-transport-finalqa-probes-20261106';created=False
def run(args):return subprocess.run(args,check=True,capture_output=True,text=True).stdout.strip()
try:
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.1)
 else:raise RuntimeError('Own probe PG not ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 xml=ET.parse(out/'transport/TEST-com.zencas.edhr.compliance.entity.AuditEventHashTest.xml').getroot();cp=next(v.attrib['value'] for v in xml.find('properties') if v.attrib.get('name')=='java.class.path');(out/'probe-classpath.txt').write_text(cp+'\n')
 records=[]
 for cls,filename in [('TextUnicodeProbe','text-unicode-probe.jsonl'),('JsonTextPersistenceProbe','json-text-persistence-probe.jsonl')]:
  compile=['/workspace/.edhr-cloud-tools/jdk-21/bin/javac','-proc:none','-cp',cp,str(out/(cls+'.java'))]
  command=['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-cp',str(out)+':'+cp,cls,f'jdbc:postgresql://127.0.0.1:{port}/postgres']
  run(compile);output=run(command);(out/filename).write_text(output+'\n');rows=[json.loads(s) for s in output.splitlines()]
  if cls=='TextUnicodeProbe':assert len(rows)==6 and all(x.get('v2Matches') is True for x in rows)
  else:
   assert len(rows)==5
   for row in rows:
    if row['case']=='escaped_high':assert 'invalid input syntax for type json' in row.get('failure','')
    else:assert row.get('matches') is True,row
  records.append({'class':cls,'rows':len(rows),'sourceSha256':hashlib.sha256((out/(cls+'.java')).read_bytes()).hexdigest(),'compileCommand':compile,'executeCommand':command,'outputFile':filename,'allExpectedOutcomes':True})
 classes=[]
 for cls in ['AuditEvent.class','AuditEventHash.class','AuditEventHash$Frame.class']:
  path=work/'gmp-platform/backend/target/classes/com/zencas/edhr/compliance/entity'/cls;dst=out/'runtime-classes'/cls;dst.parent.mkdir(exist_ok=True);shutil.copy2(path,dst);classes.append({'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 (out/'probe-runtime.json').write_text(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':'1c2cbb86b119f593925e5a147505a7ed97dd7fa2','classpathSha256':hashlib.sha256(cp.encode()).hexdigest(),'cases':records,'actualClasses':classes,'postgresVersion':run(['docker','exec',name,'psql','-U','postgres','-Atc','select version()'])},indent=2)+'\n')
 print(json.dumps({'ordinaryTextAndVarcharCases':6,'jsonCarrierCases':5,'successfulV2Rehash':10,'originalEscapedJsonRejection':1,'allExpectedOutcomes':True}))
finally:
 if created:
  run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'probe-cleanup.json').write_text(json.dumps({'ownedContainer':name,'removed':removed})+'\n');assert removed
