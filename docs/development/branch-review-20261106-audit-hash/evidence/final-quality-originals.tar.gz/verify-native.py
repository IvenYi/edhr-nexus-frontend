from pathlib import Path
from decimal import Decimal
import json,re,collections,hashlib,datetime,xml.etree.ElementTree as ET,shutil,subprocess,sys
sys.setrecursionlimit(20000)
out=Path('/tmp/edhr-w5-hash-transport-quality-20261106');r=Path('/tmp/edhr-w5-hash-transport-quality-worktree-20261106');raw=out/'transport'
def write(n,v):(out/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def norm(s):return ' '.join(re.sub(r'\$\d+','?',s).lower().split())
lines=(raw/'postgres.log').read_text().splitlines();tags=collections.defaultdict(collections.Counter);audits=[];drivers=[];core=[]
def number(v):
 t=v.as_tuple();digits=''.join(map(str,t.digits));exponent=t.exponent
 if not any(t.digits):return '0'
 while digits.endswith('0'):digits=digits[:-1];exponent+=1
 scale=-exponent;adjusted=len(digits)-1+exponent;sign='-' if t.sign else ''
 if scale>=0 and adjusted>=-6:
  if scale==0:return sign+digits
  if scale>=len(digits):return sign+'0.'+'0'*(scale-len(digits))+digits
  return sign+digits[:-scale]+'.'+digits[-scale:]
 return sign+digits[0]+('.'+digits[1:] if len(digits)>1 else '')+'E'+('+' if adjusted>=0 else '')+str(adjusted)
def encode(v):
 if isinstance(v,Decimal):return number(v)
 if v is None:return 'null'
 if isinstance(v,bool):return 'true' if v else 'false'
 if isinstance(v,str):
  chars=[]
  for ch in v:
   code=ord(ch)
   if ch in {'"','\\'}:chars.append('\\'+ch)
   elif ch in {'\b','\f','\n','\r','\t'}:chars.append({'\b':'\\b','\f':'\\f','\n':'\\n','\r':'\\r','\t':'\\t'}[ch])
   elif code<32:chars.append('\\u%04X'%code)
   elif code>65535:
    code-=65536;chars.append('\\u%04X\\u%04X'%(55296+(code>>10),56320+(code&1023)))
   else:chars.append(ch)
  return '"'+''.join(chars)+'"'
 if isinstance(v,list):return '['+','.join(encode(x) for x in v)+']'
 if isinstance(v,dict):return '{'+','.join(encode(k)+':'+encode(v[k]) for k in sorted(v,key=lambda x:x.encode('utf-16-be','surrogatepass'))) +'}'
 raise AssertionError(type(v))
def hash_event(row):
 payload=['audit-event-v2']
 for k in ['id','tenant_id','entity_type','entity_id','action','content_before','content_after','operator_id','operator_name','operator_account','source','module_name','menu_name','function_name','data_summary','reason','ip_address','created_at']:
  v=row[k]
  if k in ['content_before','content_after'] and v is not None:v=[json.loads(v,parse_int=Decimal,parse_float=Decimal)]
  elif k=='created_at' and v is not None:v=datetime.datetime.fromisoformat(v).strftime('%Y-%m-%dT%H:%M:%S.%f')
  
  widths={'tenant_id':64,'entity_type':128,'entity_id':128,'action':64,'operator_id':64,'operator_name':128,'operator_account':128,'source':32,'module_name':128,'menu_name':128,'function_name':128,'data_summary':512,'ip_address':64}
  if k in widths and v is not None and len(v)>widths[k] and all(ch==' ' for ch in v[widths[k]:]):v=v[:widths[k]]
  payload.append(v)
 return hashlib.sha256(encode(payload).encode()).hexdigest()
for i,line in enumerate(lines):
 m=re.search(r'\] (\S+) (audit_hash_\w+) LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)',line)
 if m:tags[m.group(2)][norm(m.group(3))]+=1
 insert=re.search(r'\] (\S+) (\S+) LOG:  duration: [\d.]+ ms  execute [^:]+: insert into audit_event \(([^)]+)\) values',line,re.I)
 if insert and i+1<len(lines) and 'DETAIL:  parameters:' in lines[i+1]:
  columns=insert.group(3).split(',');params=dict((int(n),None if v=='NULL' else v[1:-1].replace("''","'")) for n,v in re.findall(r"\$(\d+) = (NULL|'(?:[^']|'')*')",lines[i+1]))
  assert len(columns)==len(params),(line,params)
  row={c:params[n+1] for n,c in enumerate(columns)}
  if row.get('snapshot_hash_version')=='audit-event-v2':
   digest=hash_event(row);assert digest==row['snapshot_hash'],(insert.group(2),digest,row)
   audits.append({'database':insert.group(1),'tag':insert.group(2),'entityType':row['entity_type'],'action':row['action'],'id':row['id'],'version':row['snapshot_hash_version'],'storedHash':row['snapshot_hash'],'independentHash':digest,'matches':True,'executionNotCommit':True})
for name in ['json','time']:
 for suffix in ['write','read']:
  tag='audit_hash_'+name+'_'+suffix;counter=tags[tag]
  business={s:n for s,n in counter.items() if s.startswith(('select','insert','update','delete')) and 'pg_catalog.pg_type' not in s}
  assert sum(business.values())==1,(tag,business);assert next(iter(business)).startswith('insert' if suffix=='write' else 'select')
  core.append({'tag':tag,'business':business,'control':{s:n for s,n in counter.items() if s.startswith('set ')},'driver':{s:n for s,n in counter.items() if 'pg_catalog.pg_type' in s}})
assert all(any(v['tag']==tag for v in audits) for tag in ['audit_hash_json_write','audit_hash_time_write','audit_hash_settings_write','audit_hash_aspect_write','audit_hash_signature_write'])
write('native-sql-and-independent-rehash.json',{'coreSQL':core,'v2AuditInsertExecutionsIndependentlyRehashed':len(audits),'audits':audits,'encoding':'Independent Python exact Decimal/UTF16 object ordering/JSON framing and SHA256 from PG execute parameters; successful execution not commit. Very deep JSON beyond Python recursion excluded only from this cross-language rehash below if any.'})
summary=json.loads((raw/'test-summary.json').read_text());assert summary['totals']=={'tests':206,'failures':0,'errors':0,'skipped':0};knowledge=[]
for p in (r/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 shutil.copy2(p,out/'knowledge'/p.name);a=ET.parse(p).getroot().attrib;knowledge.append({k:int(a[k]) for k in ['tests','failures','errors','skipped']})
assert knowledge==[{'tests':89,'failures':0,'errors':0,'skipped':0}]
roundtrips=[]
for p in sorted((raw/'observations').glob('*.json')):
 e=json.loads(p.read_text())
 if 'storedHash' in e:assert (e['storedHash']==e['recomputedHash']) or p.stem=='provided';roundtrips.append({'name':p.stem,'matches':e['storedHash']==e['recomputedHash'],'legacySuppliedNotCertified':p.stem=='provided'})
write('validation-summary.json',{'baseCommit':'9dc5c0014643d99db299d27a80788cc777a0ccca','headCommit':'1c2cbb86b119f593925e5a147505a7ed97dd7fa2','regression':summary,'knowledge':knowledge,'roundTrips':roundtrips,'auditInsertExecutionsIndependentlyRehashed':len(audits),'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'tests':206,'knowledge':89,'independentlyRehashedPGExecutions':len(audits),'coreSQLCases':len(core)}))
