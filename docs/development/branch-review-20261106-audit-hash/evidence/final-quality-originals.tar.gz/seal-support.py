from pathlib import Path
import hashlib,json,re,subprocess,datetime
r=Path('/tmp/edhr-w5-hash-transport-quality-worktree-20261106');out=Path('/tmp/edhr-w5-hash-transport-quality-20261106');base='9dc5c0014643d99db299d27a80788cc777a0ccca';head='1c2cbb86b119f593925e5a147505a7ed97dd7fa2'
paths=['AGENTS.md','codeplzreadme.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/rules/master-data-permission-audit.yaml','docs/knowledge/ontology.yaml','docs/knowledge/glossary.yaml','docs/development/branch-review-20261106-audit-hash/decision-package.yaml','docs/development/branch-review-20261106-audit-hash/encoding.md','docs/development/branch-review-20261106-audit-hash/ontology-result.yaml','docs/development/branch-review-20261106-audit-hash/README.md','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/main/java/com/zencas/edhr/common/audit/AuditAspect.java','gmp-platform/backend/src/main/java/com/zencas/edhr/system/controller/SystemSettingsController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/AuthController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrArchiveService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/Signature.java']
paths += [str(p.relative_to(r)) for p in (r/'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity').glob('AuditEvent*.java')]
paths += [str(p.relative_to(r)) for p in (r/'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/entity').glob('*.java')]
files=[]
for path in paths:
 b=(r/path).read_bytes();dest=out/'source-snapshot'/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b);files.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'source-snapshot-manifest.json').write_text(json.dumps({'headCommit':head,'baseCommit':base,'readAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},indent=2)+'\n')
ddl=(r/'gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql').read_text();block=re.search(r'CREATE TABLE public.audit_event \((.*?)\n\);',ddl,re.S).group(1)
widths={'tenant_id':64,'entity_type':128,'entity_id':128,'action':64,'operator_id':64,'operator_name':128,'operator_account':128,'source':32,'module_name':128,'menu_name':128,'function_name':128,'data_summary':512,'ip_address':64}
actual={k:int(re.search(r'\b'+k+r' character varying\((\d+)\)',block).group(1)) for k in widths};assert actual==widths
(out/'varchar-width-check.json').write_text(json.dumps({'actualCanonicalDDL':actual,'expectedV2Widths':widths,'all13Match':True,'nativeTests':'AuditEventVarcharPersistencePostgresTest15/15 incl all13 padding/Unicode codepoints/nonspace old refusal'},indent=2)+'\n')
context=[]
for folder in ['initial-quality-originals','text-quality-failed-originals','ontology-originals','ontology-text-revision-originals','ontology-transport-revision-originals']:
 f=out/'retained-role-originals'/folder
 if (f/'qualityResult.yaml').is_file():
  text=(f/'qualityResult.yaml').read_text();assert 'result: failed' in text;context.append({'role':folder,'result':'failed','originalSha256':hashlib.sha256((f/'qualityResult.yaml').read_bytes()).hexdigest(),'scope':'historical candidate, not reused as current passed'})
 elif (f/'ontologyResult.yaml').is_file():context.append({'role':folder,'originalSha256':hashlib.sha256((f/'ontologyResult.yaml').read_bytes()).hexdigest(),'scope':'finite historical/incremental result, not additive semantic coverage'})
(out/'retained-results-check.json').write_text(json.dumps(context,indent=2)+'\n');print(json.dumps({'sourceSnapshots':len(files),'varcharWidths':len(actual),'retainedRoleContexts':len(context)}))
