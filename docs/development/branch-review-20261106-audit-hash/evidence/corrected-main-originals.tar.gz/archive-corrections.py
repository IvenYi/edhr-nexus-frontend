from pathlib import Path
import hashlib,json,tarfile,datetime
out=Path('/workspace/edhr-nexus-frontend/docs/development/branch-review-20261106-audit-hash/evidence');entries=[]
for name,folder,subset in [('corrected-main-originals','/tmp/edhr-w5-hash-20261106',True),('ontology-text-revision-originals','/tmp/edhr-w5-hash-ontology-text-revision-20261106',False),('initial-quality-originals','/tmp/edhr-w5-hash-quality-20261106',False)]:
 root=Path(folder);files=[p for p in sorted(root.rglob('*')) if p.is_file() and (not subset or p.relative_to(root).parts[0] in ['unicode','corrected','knowledge','run-native.py','analyze.py','archive-corrections.py'])];archive=out/(name+'.tar.gz')
 with tarfile.open(archive,'w:gz') as tar:
  for p in files:tar.add(p,arcname=p.relative_to(root),recursive=False)
 entries.append({'archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'originalRoot':str(root),'fileCount':len(files),'scope':'selected correction/current folders; earlier stages in initial main-originals' if subset else 'complete role originals','files':[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]})
(out/'correction-archive-manifest.json').write_text(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archives':entries},ensure_ascii=False,indent=2)+'\n')
print(json.dumps([{k:v for k,v in e.items() if k!='files'} for e in entries],indent=2))
