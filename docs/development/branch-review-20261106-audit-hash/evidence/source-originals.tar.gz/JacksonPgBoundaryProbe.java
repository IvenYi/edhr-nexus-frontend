import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.core.StreamReadConstraints;
import com.fasterxml.jackson.core.StreamWriteConstraints;
import com.fasterxml.jackson.core.JsonFactory;
import java.io.OutputStream;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;

/** External compatibility observation only; no product/test/config files modified. */
class JacksonPgBoundaryProbe {
    static final ObjectMapper output = new ObjectMapper();
    public static void main(String[] args) throws Exception {
        var exact = new ObjectMapper().enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
                .enable(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS);
        var localFactory = JsonFactory.builder().streamReadConstraints(StreamReadConstraints.builder()
                .maxNestingDepth(Integer.MAX_VALUE).maxNumberLength(Integer.MAX_VALUE)
                .maxNameLength(Integer.MAX_VALUE).maxStringLength(Integer.MAX_VALUE).build())
                .streamWriteConstraints(StreamWriteConstraints.builder().maxNestingDepth(Integer.MAX_VALUE).build()).build();
        var localExact = new ObjectMapper(localFactory).enable(DeserializationFeature.USE_BIG_DECIMAL_FOR_FLOATS)
                .enable(DeserializationFeature.USE_BIG_INTEGER_FOR_INTS);
        var defaults = StreamReadConstraints.defaults();
        System.out.println(output.writeValueAsString(Map.of("constraints", Map.of("depth", defaults.getMaxNestingDepth(), "number", defaults.getMaxNumberLength(), "string", defaults.getMaxStringLength(), "name", defaults.getMaxNameLength()))));
        var fixtures = new LinkedHashMap<String,String>();
        fixtures.put("ordinary", "{\"n\":1.00,\"s\":\"中文😀\"}");
        fixtures.put("integer_1001_digits", "1".repeat(1001));
        fixtures.put("decimal_1001_digits", "0." + "1".repeat(1001));
        fixtures.put("exponent_10000", "1e10000");
        fixtures.put("field_50001_chars", "{\"" + "a".repeat(50001) + "\":1}");
        fixtures.put("string_20000001_chars", "\"" + "a".repeat(20000001) + "\"");
        fixtures.put("nested_1001_arrays", "[".repeat(1001) + "0" + "]".repeat(1001));
        fixtures.put("duplicate_decoded_key", "{\"a\":1,\"\\u0061\":2}");
        fixtures.put("integer_1310_digits", "1".repeat(1310));
        fixtures.put("nested_1500_arrays", "[".repeat(1500) + "0" + "]".repeat(1500));
        fixtures.put("nested_2500_arrays", "[".repeat(2500) + "0" + "]".repeat(2500));
        try (var connection = DriverManager.getConnection(args[0], "postgres", "")) {
            for (var fixture : fixtures.entrySet()) {
                var result = new LinkedHashMap<String,Object>(); result.put("case", fixture.getKey()); result.put("inputChars", fixture.getValue().length());
                try { var tree = exact.readTree(fixture.getValue()); result.put("jacksonExact", "accepted"); result.put("nodeType", tree.getNodeType().name()); }
                catch (Exception ex) { result.put("jacksonExact", "rejected"); result.put("jacksonErrorClass", ex.getClass().getSimpleName()); result.put("jacksonError", ex.getMessage().split("\\n")[0]); }
                try { var tree = localExact.readTree(fixture.getValue()); result.put("jacksonLocalExact", "accepted"); result.put("localNodeType", tree.getNodeType().name()); }
                catch (Exception ex) { result.put("jacksonLocalExact", "rejected"); result.put("localError", ex.getClass().getSimpleName()+": "+ex.getMessage().split("\\n")[0]); }
                try (var statement = connection.prepareStatement("SELECT jsonb_typeof(?::jsonb),length((?::jsonb)::text)")) {
                    statement.setString(1, fixture.getValue()); statement.setString(2, fixture.getValue());
                    try (var rows = statement.executeQuery()) { rows.next(); result.put("postgres", "accepted"); result.put("postgresType", rows.getString(1)); result.put("postgresTextLength", rows.getInt(2)); }
                } catch (SQLException ex) { result.put("postgres", "rejected"); result.put("postgresSqlState", ex.getSQLState()); result.put("postgresError", ex.getMessage().split("\\n")[0]); }
                System.out.println(output.writeValueAsString(result));
            }
            for (int depth : List.of(1500, 2500)) {
                try(var generator=localFactory.createGenerator(OutputStream.nullOutputStream())) {
                    for(int i=0;i<depth;i++)generator.writeStartArray();generator.writeNumber(0);for(int i=0;i<depth;i++)generator.writeEndArray();
                    System.out.println(output.writeValueAsString(Map.of("localIterativeGeneratorDepth", depth, "result", "accepted")));
                }
            }
            for (String time : List.of("2026-11-06T00:00:00.123456789", "2026-11-06T00:00:00.999999500")) {
                try (var statement = connection.prepareStatement("SELECT ?::timestamp")) { statement.setObject(1, LocalDateTime.parse(time)); try(var rows=statement.executeQuery()) { rows.next(); System.out.println(output.writeValueAsString(Map.of("inputTime", time, "persistedTime", rows.getObject(1, LocalDateTime.class).toString()))); } }
            }
        }
    }
}
