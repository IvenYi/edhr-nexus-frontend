from pathlib import Path
import subprocess,os,time,json,hashlib
root=Path('/tmp/edhr-w5-hash-source-20261106');name='edhr-w5-source-boundary-v2-20261106';created=False
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
libs=list(Path('/workspace/.pr6-m2/com/fasterxml/jackson/core').rglob('*2.17.1.jar'))+list(Path('/workspace/.pr6-m2/org/postgresql/postgresql').rglob('*.jar'))
classpath=':'.join(str(p) for p in libs)
try:
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=edhr_w5_source_boundary','-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(100):
  if subprocess.run(['docker','exec',name,'pg_isready','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.2)
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 command=['/workspace/.edhr-cloud-tools/jdk-21/bin/java','-Xmx512m','--class-path',classpath,str(root/'JacksonPgBoundaryProbe.java'),f'jdbc:postgresql://127.0.0.1:{port}/edhr_w5_source_boundary']
 result=subprocess.run(command,capture_output=True,text=True);(root/'boundary-probe-v2.jsonl').write_text(result.stdout);(root/'boundary-probe-v2.stderr').write_text(result.stderr)
 (root/'boundary-probe-v2-run.json').write_text(json.dumps({'command':command,'exitCode':result.returncode,'libs':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in libs],'postgres':run(['docker','exec',name,'psql','-U','postgres','-d','edhr_w5_source_boundary','-Atc','SELECT version()'])},indent=2)+'\n')
 print(result.stdout);print(result.stderr);assert result.returncode==0
finally:
 if created:
  run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
  (root/'cleanup-v2.json').write_text(json.dumps({'ownedContainer':name,'removed':removed},indent=2)+'\n');print('own PG removed',removed)
