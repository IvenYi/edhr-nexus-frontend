from pathlib import Path
import subprocess,json,re,hashlib,datetime
root=Path('/workspace/edhr-nexus-frontend');out=Path('/tmp/edhr-w5-hash-source-20261106');base='9dc5c0014643d99db299d27a80788cc777a0ccca'
def run(*args):return subprocess.check_output(args,cwd=root,text=True).strip()
paths=run('git','ls-tree','-r','--name-only',base).splitlines();producers=[];sourcePaths=set()
for path in paths:
 if not path.startswith('gmp-platform/backend/src/main/java/') or not path.endswith('.java'):continue
 text=subprocess.check_output(['git','show',base+':'+path],cwd=root).decode('utf-8')
 for m in re.finditer(r'AuditEvent\.builder\(\)',text):
  end=text.find('.build()',m.end());block=text[m.start():end+8]
  producers.append({'path':path,'line':text[:m.start()].count('\n')+1,'explicitHash':'.snapshotHash(' in block,'createdAt':'.createdAt(' in block,'sourceSha256':hashlib.sha256(text.encode()).hexdigest(),'builderBlock':block});sourcePaths.add(path)
assert len(producers)==49 and len(sourcePaths)==37
assert not any(p['explicitHash'] for p in producers) and all(p['createdAt'] for p in producers)
(out/'producer-inventory.json').write_text(json.dumps({'baseCommit':base,'callSites':49,'files':37,'explicitHashes':0,'producers':producers},ensure_ascii=False,indent=2)+'\n')
sourcePaths.update(['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/development/branch-review-20261106-image-verification/W5-COMPATIBILITY-PLAN.md','docs/development/branch-review-20261106-image-verification/w5-producer-inventory.json','gmp-platform/backend/pom.xml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrEvidenceImpactService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/DepartmentController.java','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml'])
tests=['common/audit/AuditAspectTest','compliance/entity/AuditEventTest','compliance/controller/AuditControllerTest','identity/controller/AuthControllerTest','identity/controller/UserControllerTest','system/controller/SystemSettingsControllerTest','template/controller/TemplateModelingControllerTest','masterdata/controller/DocumentCategoryAuditPostgresTest','masterdata/controller/DocumentReadBoundaryIntegrationTest','production/service/SignatureSnapshotPostgresTest','production/service/DhrAttachmentUploadVerifyObservationPostgresTest']
sourcePaths.update('gmp-platform/backend/src/test/java/com/zencas/edhr/'+path+'.java' for path in tests)
source=[]
for path in sorted(sourcePaths):
 data=subprocess.check_output(['git','show',base+':'+path],cwd=root);target=out/'source-baseline'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 source.append({'path':path,'commit':base,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
working=['docs/development/branch-review-20261106-audit-hash/decision-package.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEventHash.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/entity/AuditEvent.java','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql']
for path in working:
 data=(root/path).read_bytes();target=out/'working-input'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 source.append({'path':path,'commit':None,'state':'uncommitted working tree read-only input; not final acceptance','headAtRead':base,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'source-manifest.json').write_text(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'sources':source},ensure_ascii=False,indent=2)+'\n')
result={'role':'read-only source review and external compatibility observation; not final QA','result':'completed','contractBaseline':{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},'knowledgeBaselineVersion':'0.3.25','productOrTestEditsByThisRole':False,'applicationJUnitRunByThisRole':False,'producerCallSites':49,'producerFiles':37,'externalNativePGProbeRuns':2,'confirmedRisk':'Default Jackson constraints reject multiple PG JSONB accepted documents; local constraints/explicit stack in current working helper address design, runtime product acceptance pending.','historicalIssue':'W5-AUDIT-HASH-001 remains open until main implementation and fresh independent final quality; no old hashes rewritten','evidence':['REVIEW.md','producer-inventory.json','source-manifest.json','boundary-probe.jsonl','boundary-probe-v2.jsonl','boundary-probe-run.json','boundary-probe-v2-run.json','cleanup.json','cleanup-v2.json'],'children':[]}
(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ['manifest.json','manifest.sha256']]
manifest={'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'baseCommit':base,'files':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');digest=hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest();(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'sourceFiles':len(source),'artifactFiles':len(files),'manifestSha256':digest,'producerCallSites':len(producers),'producerFiles':len(set(p['path'] for p in producers))},indent=2))
