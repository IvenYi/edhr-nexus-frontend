BEGIN READ ONLY;
SELECT column_name,data_type FROM information_schema.columns WHERE table_schema='public' AND table_name='workflow_instance' AND column_name IN ('business_id','business_key');
SELECT (jsonb_populate_record(NULL::workflow_instance,jsonb_build_object('business_id','original-request','business_key','new-request'))).business_id AS wrong_key_retains_original;
SELECT (jsonb_populate_record(NULL::workflow_instance,jsonb_build_object('business_id','original-request')||jsonb_build_object('business_id','new-request'))).business_id AS corrected_key_changes_identity;
SELECT indexname,indexdef FROM pg_indexes WHERE schemaname='public' AND tablename='workflow_task' AND indexname='idx_wf_task_instance';
ROLLBACK;
