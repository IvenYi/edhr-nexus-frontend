from pathlib import Path
import json,re,hashlib,subprocess,datetime,collections

RAW=Path('/tmp/edhr-record-access-increment-final-qa-v2-20261110')
WT=Path('/tmp/edhr-record-access-qa-v2-worktree-20261110')
BASE='07d6d4168a00a265afea8105db9a1a0e2554f683'
HEAD='0f5d4354ed381adb07650548a2ec417969d2416d'
def cmd(a):return subprocess.check_output(a,cwd=WT,text=True).strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def nodes(n):
    yield n
    for c in n.get('Plans',[]):yield from nodes(c)

# Original auto_explain output, not a replay or hand-written EXPLAIN.
s=(RAW/'final/postgres.log').read_text();decoder=json.JSONDecoder();pos=0;plans=[]
folder=RAW/'actual-plans';folder.mkdir(exist_ok=True)
for line in s.splitlines(keepends=True):
    pos+=len(line)
    if 'audit-record-access-' not in line or 'plan:' not in line:continue
    m=re.search(r'audit-record-access-(\d+)-(\d+)',line);assert m
    at=pos
    while s[at].isspace():at+=1
    obj,_=decoder.raw_decode(s,at);query=obj['Query Text']
    kind='page' if 'can_view_detail' in query else 'count'
    (folder/(m[0]+'-'+kind+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    tasks=[n for n in nodes(obj['Plan']) if n.get('Relation Name')=='workflow_task']
    plans.append(dict(label=m[0],backgroundTasks=int(m[1]),actorId=m[2],kind=kind,
        durationMs=float(re.search(r'duration: ([\d.]+) ms',line)[1]),actualRows=obj['Plan']['Actual Rows'],
        taskNodes=[{k:n[k] for k in ['Node Type','Subplan Name','Index Name','Actual Loops','Actual Rows','Rows Removed by Filter','Filter','Index Cond'] if k in n} for n in tasks]))
assert len(plans)==24,len(plans)
labels=[f'audit-record-access-{m}-{a}' for m in [0,5000,20000] for a in ['44','41','42','1']]
sql=[]
prefix=re.compile(r'^\d{4}-\d\d-\d\d .*?\[\d+\] edhr_record_control_test_final (audit-record-access-\d+-\d+) \d+ LOG:  duration: [\d.]+ ms  execute [^:]+: (.*)$')
for line in s.splitlines():
    m=prefix.match(line)
    if m:sql.append(dict(label=m[1],firstLine=m[2].strip()))
for label in labels:
    pair=[x for x in plans if x['label']==label]
    assert {x['kind'] for x in pair}=={'count','page'}
    executes=[x['firstLine'] for x in sql if x['label']==label]
    # Transactions and SET LOCAL are infrastructure, kept separate from service SQL.
    selects=[x for x in executes if x.upper().startswith('SELECT')]
    writes=[x for x in executes if re.match(r'^(INSERT|UPDATE|DELETE|TRUNCATE|ALTER|CREATE|DROP)\b',x,re.I)]
    assert len(selects)==2,(label,executes)
    assert not writes,(label,writes)
observations=[]
for label in labels:
    o=json.loads((RAW/'final/read-observations'/(label+'.json')).read_text())
    assert len(o['rows'])==20
    assert all(row['canViewDetail']==(o['actorId']!='44') for row in o['rows'])
    assert o['taskHeapLayout']=='background-before-target'
    observations.append(dict(label=label,rows=len(o['rows']),canViewExpected=o['canViewExpected'],elapsedNanos=o['elapsedNanos'],threadAllocatedBytes=o['threadAllocatedBytes']))
(RAW/'actual-plan-analysis.json').write_text(json.dumps(dict(scope='Actual canonical PG16 service SQL; 20 synthetic metadata requests and real original detail; warm instrumented measurements, not production SLA',plans=plans,observations=observations,executedStatements=sql,statementCountQualification='Each label executes exactly two business SELECTs, zero writes; SET LOCAL/transactions logged separately'),ensure_ascii=False,indent=2)+'\n')

# Protect actual runner inputs against stale worktree or snapshots.
run=json.loads((RAW/'final/run.json').read_text());assert run['head']==HEAD
fingers=[]
for f in run['sourceFingerprints']:
    b=(WT/f['path']).read_bytes();git=subprocess.check_output(['git','show',HEAD+':'+f['path']],cwd=WT)
    snap=(RAW/'final/source'/f['path']).read_bytes()
    row=dict(**f,currentMatches=sha(b)==f['sha256'],gitMatches=sha(git)==f['sha256'],snapshotMatches=sha(snap)==f['sha256'])
    assert row['currentMatches'] and row['gitMatches'] and row['snapshotMatches'];fingers.append(row)
knowledge=[]
for p in cmd(['git','ls-files','docs/knowledge']).splitlines():
    b=(WT/p).read_bytes();knowledge.append(dict(path=p,bytes=len(b),sha256=sha(b)))
contracts=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md']
contract_diff=cmd(['git','diff',BASE,HEAD,'--',*contracts]);assert not contract_diff
target=cmd(['git','rev-parse','origin/edhr-dev']);assert target==BASE
binding=dict(baseCommit=BASE,headCommit=HEAD,actualHead=cmd(['git','rev-parse','HEAD']),independentlyFetchedTarget=target,contractReadCommit=HEAD,contractDiff=contract_diff,
    runnerSourceFingerprintCount=len(fingers),runnerSourceFingerprints=fingers,knowledgeFiles=knowledge,
    completeUnaffectedTreeBindings='ui-reuse-binding.json',workingTreeDuringExecution=run['status'],temporaryExcludedPaths=['gmp-platform/frontend/node_modules'],recordDatabaseUrl=run['recordDatabaseUrl'],familyDatabaseUrl=run['familyDatabaseUrl'],checkedAt=datetime.datetime.now(datetime.timezone.utc).isoformat())
(RAW/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')

current=json.loads((RAW/'premium-audit.json').read_text());baseline=json.loads(Path('/tmp/edhr-record-access-increment-20261110/premium-baseline.json').read_text())
key=lambda x:json.dumps({k:v for k,v in x.items() if k!='line'},sort_keys=True,ensure_ascii=False)
cset={key(x) for x in current['findings']};bset={key(x) for x in baseline['findings']}
assert cset==bset
upstream=Path('/tmp/edhr-record-access-increment-20261110/ui-tools/audit_project.py')
assert sha(upstream.read_bytes())==sha((RAW/'audit_project.py').read_bytes())
debt=dict(current=current['summary'],baseline=baseline['summary'],baselineCommit='2dc6941ea21caa5f8096a4fa6cc6cd36f6345f8c',scope='Same file/rule/message/category/severity/remediation sets; source line relocation excluded from identity',added=[],removed=[],officialCopiedToolSha256=sha(upstream.read_bytes()),lintExit=json.loads((RAW/'lint-run.json').read_text())['exitCode'],lintReason='Repository has no ESLint configuration; unchanged whole-project validation debt',fullPremiumCompliance=False)
(RAW/'whole-project-debt.json').write_text(json.dumps(debt,indent=2)+'\n')
print(json.dumps(dict(plans=len(plans),observations=len(observations),sourceInputs=len(fingers),knowledgeFiles=len(knowledge),staticDebt=debt['current'])))
for p in plans:
    if p['kind']=='page':print(json.dumps(p))
