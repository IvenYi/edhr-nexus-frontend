from pathlib import Path
import os,sys,json,hashlib,shutil,subprocess,time,datetime,xml.etree.ElementTree as ET
ROOT=Path(os.getenv('EDHR_RECORD_ROOT','/workspace/edhr-nexus-frontend'));RAW=Path(os.getenv('EDHR_RECORD_RAW','/tmp/edhr-record-access-increment-20261110'))
phase=sys.argv[1];assert phase in ['focused','verified','retry','final'];out=RAW/phase;out.mkdir(parents=True,exist_ok=False);shutil.copy2(__file__,out/'runner-source.py')
name='edhr-record-access-qa-v2-'+phase+'-20261110';db='edhr_record_control_test_'+phase;familydb='edhr_family_transfer_test_record_'+phase;created=False;code=1
selected='RecordControlPostgresIntegrationTest#requestListCapacityKeepsReadPolicyAndEvidence' if phase=='focused' else 'RecordControlPostgresIntegrationTest,RecordControlAccessTest,CurrentDatabaseBaselineTest,ProductionControllerAuthorizationTest,WorkOrderCloseAtomicityTest,DhrReviewLifecycleIntegrationTest,ProductFamilyMembershipServiceTest,ProductFamilyTransferPostgresTest,ProductionExecutionIntegrationTest#formApprovalTransferMovesPendingTaskWithoutAdvancingTheFlow+tenantDelegationOutsideFrozenCandidatesPreservesSourceAndMovesOnlyCurrentResponsibility+transferRechecksTheSelectedTenantUserWhenTheirAccountBecomesLocked'
def run(args,**kw):return subprocess.run(args,check=True,text=True,capture_output=True,**kw).stdout.strip()
try:
    run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','shared_preload_libraries=pg_stat_statements,auto_explain','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] %d %a %x ']);created=True
    for _ in range(120):
        if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
        time.sleep(.25)
    else:raise RuntimeError('owned PG did not become ready')
    port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
    run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE DATABASE '+familydb])
    env=os.environ.copy();env.update(PGUSER='postgres',PGPASSWORD='',RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',FAMILY_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{familydb}')
    paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md','DESIGN.md','docs/frontend/list-page-guidelines.md','docs/development/branch-review-20261110-record-access-increment/decision-package.yaml','gmp-platform/backend/pom.xml','gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/controller/RecordControlController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/UserController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/masterdata/service/ProductFamilyMembershipService.java','gmp-platform/backend/src/main/resources/db/changelog/db.changelog-master.yaml','gmp-platform/backend/src/main/resources/db/changelog/baseline/0001-current-schema.sql','gmp-platform/backend/src/main/resources/db/changelog/baseline/0002-current-seed.sql','gmp-platform/backend/src/main/resources/db/changelog/0087-record-control.sql','gmp-platform/backend/src/main/resources/db/changelog/0092-audit-event-hash-version.sql','gmp-platform/frontend/package.json','gmp-platform/frontend/src/App.tsx','gmp-platform/frontend/src/api/record-control.ts','gmp-platform/frontend/scripts/test-workflow-list-ui-browser.mjs','gmp-platform/frontend/scripts/test-personnel-targets-browser.mjs']
    paths+=['gmp-platform/frontend/src/pages/record-control/'+p+'.tsx' for p in ['RecordChangePage','RecordRequestListPage','RecordRequestDetailPage','RecordApprovalDetailPage']]
    paths+=['docs/knowledge/'+p for p in ['README.md','decisions/DEC-0096-record-control-system-admin-detail-read.yaml','decisions/DEC-0087-record-control-v1-closure.yaml','decisions/DEC-0074-button-signature-signer-identity.yaml','rules/record-change.yaml'] if (ROOT/'docs/knowledge'/p).exists()]
    classes=[s.split('#')[0] for s in selected.split(',')]
    for c in classes:
        hits=list((ROOT/'gmp-platform/backend/src/test/java').rglob(c+'.java'));assert len(hits)==1,c;paths.append(str(hits[0].relative_to(ROOT)))
    fingers=[]
    for path in paths:
        b=(ROOT/path).read_bytes();fingers.append(dict(path=path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()));dst=out/'source'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(b)
    tmp=out/'vm-tmp';tmp.mkdir()
    command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+selected,'-Dedhr.audit.recordReadCapacity=true','-Dedhr.audit.recordReadOutput='+str(out/'read-observations'),'-Dedhr.audit.familyTransfer=true','-Dedhr.audit.familyTransferOutput='+str(out/'family-observations'),'-DargLine=-Xmx1536m -Djava.io.tmpdir='+str(tmp),'test']
    start=datetime.datetime.now(datetime.timezone.utc)
    with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
    (out/'run.json').write_text(json.dumps(dict(command=command,head=run(['git','rev-parse','HEAD'],cwd=ROOT),status=run(['git','status','--porcelain'],cwd=ROOT),startedAt=start.isoformat(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=result.returncode,sourceFingerprints=fingers,recordDatabaseUrl=env['RECORD_CONTROL_TEST_DATABASE_URL'],familyDatabaseUrl=env['FAMILY_TRANSFER_DATABASE_URL']),indent=2)+'\n')
    totals=dict(tests=0,failures=0,errors=0,skipped=0);reports=[];missing=[]
    for c in classes:
        hits=[p for p in (ROOT/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+c+'.xml') if p.stat().st_mtime>=start.timestamp()]
        if len(hits)!=1:missing.append(c);continue
        p=hits[0];shutil.copy2(p,out/p.name);a=ET.parse(p).getroot().attrib;v={k:int(a.get(k,0)) for k in totals};reports.append(dict(name=a['name'],**v))
        for k in totals:totals[k]+=v[k]
    summary=dict(totals=totals,classes=reports,missingFreshReports=missing);(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary),flush=True);print((out/'maven.log').read_text()[-1600:],flush=True)
    code=0 if result.returncode==0 and not missing and totals['tests']>0 and totals['failures']==totals['errors']==totals['skipped']==0 else 1
finally:
    if created:
        logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr);run(['docker','stop',name]);removed=False
        for _ in range(30):
            if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
            time.sleep(.1)
        (out/'cleanup.json').write_text(json.dumps(dict(ownedContainer=name,removed=removed),indent=2)+'\n')
sys.exit(code)
