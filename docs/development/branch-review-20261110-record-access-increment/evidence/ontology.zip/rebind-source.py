from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import yaml

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-record-access-increment-ontology-20261110')
OLD = OUT / 'initial-594a'
RAW = Path('/tmp/edhr-record-access-increment-20261110/final')
PARENT = RAW.parent
QA = Path('/tmp/edhr-record-access-increment-final-qa-20261110')
BASE = '07d6d4168a00a265afea8105db9a1a0e2554f683'
PREV = '594a1944682f21550fbbd1a108b852d3ef34655b'
SOURCE = '0f5d4354ed381adb07650548a2ec417969d2416d'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
START = datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')

def fingerprint(path, prefix):
    data = path.read_bytes()
    return dict(path=str(path.relative_to(prefix)), bytes=len(data), sha256=sha(data))

assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain').strip()
assert subprocess.run(['git', 'merge-base', '--is-ancestor', PREV, SOURCE], cwd=ROOT).returncode == 0
old_manifest = json.loads((OLD / 'manifest.json').read_text())
assert old_manifest['sourceCommit'] == PREV
assert len(old_manifest['artifacts']) == 79
for row in old_manifest['artifacts']:
    assert fingerprint(OLD / row['path'], OLD) == row
assert (OUT / 'manifest.json').read_bytes() == (OLD / 'manifest.json').read_bytes(), 'only run once over original preserved state'

# The exact source delta is a fixture-only correction, not a policy re-review.
changed = git('diff', '--name-only', PREV, SOURCE).decode().splitlines()
assert changed == [TEST], changed
old_test = git('show', PREV + ':' + TEST).decode()
new_test = git('show', SOURCE + ':' + TEST).decode()
expected = old_test.replace("'business_key',(7400000+i)::text", "'business_id',(7400000+i)::text")
expected = expected.replace("'business_key','BACKGROUND-'||i", "'business_id','BACKGROUND-'||i")
extra = (
    '        assertThat(jdbc.queryForObject("SELECT count(*) FROM record_control_request q JOIN workflow_instance w ON w.id::text=q.workflow_instance_id WHERE q.request_no LIKE \'CAP-RC-%\' AND w.business_id=q.id::text",Long.class)).isEqualTo(20);\n'
    '        assertThat(jdbc.queryForObject("SELECT count(*) FROM workflow_instance WHERE business_id LIKE \'BACKGROUND-%\'",Long.class)).isEqualTo(backgroundTasks);\n'
)
expected = expected.replace('        assertThat(count("workflow_task")).isEqualTo(backgroundTasks+21);\n', '        assertThat(count("workflow_task")).isEqualTo(backgroundTasks+21);\n' + extra)
assert new_test == expected
diff = git('diff', '--binary', PREV, SOURCE)
(OUT / 'fixture-only-594a-to-0f5.diff').write_bytes(diff)

# Do not recalculate IDs or semantic judgments. Prove original inputs unchanged.
inv = json.loads((OLD / 'knowledge-current.json').read_text())
knowledge = json.loads((OLD / 'knowledge-result.json').read_text())
assert len(inv['files']) == 353
knowledge_paths = git('ls-tree', '-r', '--name-only', SOURCE, '--', 'docs/knowledge').decode().splitlines()
assert knowledge_paths == [r['path'] for r in inv['files']]
knowledge_rows = []
for row in inv['files']:
    data = git('show', SOURCE + ':' + row['path'])
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert (ROOT / row['path']).read_bytes() == data
    knowledge_rows.append(dict(path=row['path'], bytes=len(data), sha256=sha(data)))
digest = sha(''.join(r['sha256'] + '  ' + r['path'] + '\n' for r in knowledge_rows).encode())
assert digest == inv['summary']['sha256sumDigest']
assert not git('diff', '--name-only', BASE, SOURCE, '--', 'tools/knowledge-model').strip()
for row in knowledge['inputFingerprints']:
    data = git('show', SOURCE + ':' + row['path'])
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert data == (ROOT / row['path']).read_bytes()
assert knowledge['totals'] == dict(tests=89, failures=0, errors=0, skipped=0)
assert len(knowledge['inputFingerprints']) == 354
assert knowledge['sourceCommit'] == BASE

old_binding = json.loads((OLD / 'source-binding.json').read_text())
new_inputs = []
for row in old_binding['finalInputs']:
    path = row['path']
    data = git('show', SOURCE + ':' + path)
    destination = OUT / 'final-source-0f5' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    new_inputs.append(dict(path=path, sourceCommit=SOURCE, bytes=len(data), sha256=sha(data), gitBlob=git('rev-parse', SOURCE + ':' + path).decode().strip(), coverage='incremental source binding only; prior finite semantic scope retained, not re-reviewed'))
assert len(new_inputs) == 32

# Read parent's actual post-fix run, retaining its pre-commit dirty HEAD truth.
run = json.loads((RAW / 'run.json').read_text())
assert run['exitCode'] == 0
assert '-Dedhr.audit.recordReadCapacity=true' in run['command']
assert run['head'] == PREV
assert run['status'].strip() == 'M ' + TEST
assert len(run['sourceFingerprints']) == 40
for row in run['sourceFingerprints']:
    data = git('show', SOURCE + ':' + row['path'])
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert data == (ROOT / row['path']).read_bytes()
    assert data == (RAW / 'source' / row['path']).read_bytes()
summary = json.loads((RAW / 'test-summary.json').read_text())
assert summary['totals'] == dict(tests=127, failures=0, errors=0, skipped=0)
assert summary['missingFreshReports'] == []
xml_classes = []
for path in sorted(RAW.glob('TEST-*.xml')):
    element = ET.parse(path).getroot()
    xml_classes.append(dict(name=element.attrib['name'], **{k:int(element.attrib[k]) for k in ('tests', 'failures', 'errors', 'skipped')}))
assert len(xml_classes) == 9
assert sorted(xml_classes, key=lambda x:x['name']) == sorted(summary['classes'], key=lambda x:x['name'])
totals = {k:sum(x[k] for x in xml_classes) for k in ('tests', 'failures', 'errors', 'skipped')}
assert totals == summary['totals']
assert next(x for x in xml_classes if x['name'].endswith('.RecordControlPostgresIntegrationTest'))['tests'] == 69

observations = []
for path in sorted((RAW / 'read-observations').glob('*.json')):
    row = json.loads(path.read_text())
    assert row['backgroundTasks'] in (0, 5000, 20000)
    assert row['actorId'] in ('1', '41', '42', '44')
    assert row['taskHeapLayout'] == 'background-before-target'
    assert len(row['rows']) == 20
    assert row['canViewExpected'] == (row['actorId'] != '44')
    assert all(x['canViewDetail'] == row['canViewExpected'] for x in row['rows'])
    observations.append(dict(file=path.name, actorId=row['actorId'], backgroundTasks=row['backgroundTasks'], canViewExpected=row['canViewExpected'], heapLayout=row['taskHeapLayout'], rows=len(row['rows']), threadAllocatedBytes=row['threadAllocatedBytes'], scope='parent final raw inspected; not executed by ontology role'))
assert len(observations) == 12
assert len({(r['actorId'], r['backgroundTasks']) for r in observations}) == 12
plans_path = PARENT / 'plan-analysis-final.json'
plans = json.loads(plans_path.read_text())
assert len(plans['plans']) == 24
reviewer = next(x for x in plans['plans'] if x['backgroundTasks'] == 20000 and x['actorId'] == '42' and x['kind'] == 'page')
assert reviewer['taskNodes'][0]['Actual Loops'] == 20
assert reviewer['taskNodes'][0]['Rows Removed by Filter'] == 20010
shutil.copy2(plans_path, OUT / 'plan-analysis-final.json')
for path in sorted((PARENT / 'plans-final').rglob('*')):
    if path.is_file():
        dest = OUT / 'plans-final' / path.relative_to(PARENT / 'plans-final')
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)

# Keep independent v1 failed outcome as historical failed, never upgrade it.
qa_result = yaml.safe_load((QA / 'quality-result.yaml').read_text())['qualityResult']
assert qa_result['result'] == 'failed'
assert qa_result['headCommit'] == PREV
assert len(qa_result['findings']) == 1
assert qa_result['findings'][0]['severity'] == 'medium'
assert qa_result['findings'][0]['resolutionStatus'] == 'open'
qa_manifest = json.loads((QA / 'manifest.json').read_text())
qa_rows = {r['path']: r for r in qa_manifest['files']}
qa_copies = []
for name in ['quality-result.yaml', 'independent-review.md', 'source-binding.json', 'manifest.json', 'fixture-proof.sql', 'fixture-proof.log']:
    path = QA / name
    if name != 'manifest.json':
        assert fingerprint(path, QA) == qa_rows[name]
    destination = OUT / 'historical-qa-v1-594a' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, destination)
    qa_copies.append(fingerprint(destination, OUT))

raw_rows = [fingerprint(p, RAW) for p in sorted(RAW.rglob('*')) if p.is_file() and 'vm-tmp' not in p.relative_to(RAW).parts]
plan_rows = [fingerprint(p, PARENT) for p in sorted((PARENT / 'plans-final').rglob('*')) if p.is_file()]
plan_rows.append(fingerprint(plans_path, PARENT))
binding = dict(
    status='FINAL', bindingMode='fixture-only-incremental-rebind', sourceCommit=SOURCE,
    previousSourceCommit=PREV, targetBranch='edhr-dev', targetCommit=BASE, contractReadCommit=BASE,
    contractIncrement='none; contract bytes unchanged', workingTreeStateAtBinding=git('status', '--porcelain').decode(),
    previousFormalArchive=dict(directory='initial-594a', originalManifestSha256=sha((OLD / 'manifest.json').read_bytes()), originalArtifactsVerified=79, originalManifestAlsoPreserved=True),
    reviewedSourceChanges=changed, exactFixtureDelta=dict(twoJSONKeys='business_key -> schema business_id', addedAssertions=['20 target request/workflow business identities agree', 'background workflow business_id count equals requested M']),
    productUIKnowledgeSchemaContractChanges=[], knowledgeFiles=353, knowledgeIds=2848,
    knowledgeAllUnchangedFromBase=True, knowledgeAllUnchangedFromPrevious=True, knowledgeDigest=digest,
    priorFiniteSemanticReview=dict(path='initial-594a/finite-review-records.json', records=32, consistentWithinScope=30, exactPartiallySuperseded=1, existingNonblockingNeedsDecision=1, rerun=False, scope='Original finite semantic conclusions retained by unchanged bytes; no new semantic review or coverage credit'),
    knowledgeValidationReuse=dict(sourceCommit=BASE, totals=knowledge['totals'], inputFingerprintsVerified=354, testToolTreeUnchanged=True, actuallyRerunForIncrement=False, originalEvidence='initial-594a/knowledge-result.json', scope='Originally actually executed by ontology; unchanged inputs permit scoped reuse, not a new execution at 0f5'),
    finalInputs=new_inputs,
    parentProductRun=dict(rawDirectory=str(RAW), command=run['command'], actualRunHead=run['head'], actualRunStatus=run['status'], testedBytesBoundToCleanCandidate=SOURCE, totals=totals, classes=xml_classes, sourceFingerprints=run['sourceFingerprints'], rawFingerprints=raw_rows, actuallyExecutedByOntologyRole=False),
    parentCapacityObservationsReadOnly=observations, parentPlanScope=plans['scope'], planRawFingerprints=plan_rows, reviewer20000LateMatchPlan=reviewer,
    fixtureEvidenceHistory=dict(focused='Original focused 3E from cloned idempotency key, retained by parent', retry='Early-match 127P retained by parent, not final late-match acceptance', verified='Late-match 594a 127P had ignored business_key; original raw and initial ontology artifacts retained; not current quality acceptance', independentV1=dict(result='failed', sourceCommit=PREV, finding='QF-RECORD-ACCESS-001', severity='medium', originalDirectory=str(QA), preservedFormalArtifacts=qa_copies, applicability='Historical failed remains failed; cannot accept 0f5'), final='Parent final re-executed 127P after business_id fix; read and byte-bound only by ontology', independentV2='Fresh uninvolved QA assigned by parent; no result claimed here'),
    performanceDisposition='Actual late-match reviewer repeated scan remains a measured risk only. No SQL/index/authorization change; await explicit user decision on optimization.',
    premiumStaticScope='Historical UI bytes unchanged; parent/v1 browser and build runs are historical scoped evidence, not rerun by ontology; 86 same strict findings and lint exit2 remain.',
    children=[], wholeFileCompleted=0, historicalUnique='unknown')
write('source-binding.json', binding)

result = yaml.safe_load((OLD / 'ontology-result.yaml').read_text())
value = result['ontologyResult']
value['contractBaseline']['sourceCommit'] = SOURCE
value['reason'] = 'This incremental correction only replaces two ignored capacity-fixture JSON keys with actual business_id and asserts target/background business associations. Product, UI, knowledge, schema, permissions, contracts and knowledge-test tool bytes are unchanged. No new business semantics or knowledge update; original finite32 conclusions and actually executed89 retained, not rerun or expanded.'
value['knowledgeSync'] = []
value['validationEvidence'] = [
    dict(id='validation.record-access-increment.fixture-only-delta', checkType='evidence-path', command='python3 /tmp/edhr-record-access-increment-ontology-rebind-20261110.py', outcome='passed', evidence=['fixture-only-594a-to-0f5.diff', 'source-binding.json', 'Exact transform: two JSON keys and two association assertions; no product/policy/knowledge changes']),
    dict(id='validation.record-access-increment.reused-knowledge89', checkType='schema', command='Reuse actual original knowledge89; verify354 input fingerprints and unchanged tools/knowledge-model tree, no rerun', outcome='passed', evidence=['initial-594a/knowledge-result.json', 'initial-594a/knowledge89.log', 'initial-594a/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml', 'source-binding.json', 'Original89/89 at07d6, all353 knowledge bytes and354 recorded inputs unchanged at0f5; not executed again']),
    dict(id='validation.record-access-increment.retained-finite-semantics', checkType='projection', command='Retain original finite32 review under unchanged product/knowledge bytes; no new semantic review', outcome='passed', evidence=['initial-594a/ontology-result.yaml', 'initial-594a/finite-review-records.json', 'initial-594a/REVIEW.md', 'No new semantic coverage credit or maturity change']),
    dict(id='validation.record-access-increment.final-source-binding', checkType='evidence-path', command='Read parent final9XML/127 tests,40 source fingerprints,12 observations and24 plans; bind tested bytes to clean0f5', outcome='passed', evidence=['source-binding.json', 'final-source-0f5/', str(RAW), 'plan-analysis-final.json', 'Parent actually reran127/127, not executed by ontology; clean0f5 equals tested dirty594a bytes for40 inputs']),
    dict(id='validation.record-access-increment.history-preservation', checkType='reference', command='Verify original79 artifact hashes and manifest; copy v1 failed formal evidence without changing its state', outcome='passed', evidence=['initial-594a/manifest.json', 'historical-qa-v1-594a/quality-result.yaml', 'historical-qa-v1-594a/independent-review.md', '594a v1 failed remains historical failed; ontology NA does not approve quality or merge']),
]
(OUT / 'ontology-result.yaml').write_text(yaml.safe_dump(result, sort_keys=False, allow_unicode=True, width=110))

review = f'''# 记录控制增量：最终夹具修正的本体来源绑定

正式结果 **not-applicable / FINAL**。当前clean候选`{SOURCE}`，目标edhr-dev仍固定`{BASE}`。本次仅做从`{PREV}`到最终夹具修正的来源增量：两处JSON键business_key改为schema实际business_id，新增20个目标申请/实例业务关联及M个背景实例业务身份计数断言。逐字变换已核对，差异只涉及原RecordControlPostgresIntegrationTest；产品、UI、知识、schema、权限和契约均无变动，不新增本体语义或知识写入。

原594a整套79份受manifest管理的原件及原manifest完整保留在initial-594a/，逐条哈希一致。原结果、源码绑定、32项有限核对、inventory、知识运行、脚本、source及final-source快照均未在归档中改写。当前root正式文件仅表示本次增量绑定，旧时点结论以原归档为准。

独立v1对594a的正式结果仍是failed：唯一medium QF-RECORD-ACCESS-001为未知business_key被PostgreSQL jsonb_populate_record忽略，克隆实例保留原business_id。其质量结果、独立报告、源绑定、manifest及fixture-proof SQL/log已只读核对并原样保存到historical-qa-v1-594a/。旧业务关联元数据完全一致的声明不成立；原q.workflow_instance_id与task.instance_id实际读关联正确，不因此推断产品权限bug。**原NA只说明无本体变更，不能替代质量通过。** 修正后候选需要新独立实例验收，本角色未给出qualityResult或merge许可。

当前知识353文件仍92MD/261YAML，全部与07d6及594a逐字相同，清单摘要`{digest}`。2848同口径资产ID来自原inventory，不重新枚举、不把旧931子集当同一分母；全量清单仍pending。原32项有限语义核对（30在限定范围一致、1精确部分替代、1既有非阻断完整多租户问题）保持，不在此次重审或新增覆盖数，成熟度仍knowledge0.3.25/schema1.2.0/P0 in-progress。

原规则结论按原范围保留：DEC0096仅部分替代DEC0087-09的记录控制IN_REVIEW申请详情只读限制；通过认证ID反查ACTIVE且trim/casefold用户名admin，普通ADMIN角色或显示名不授予例外。详情可读不扩展任务详情、审批、签署、转办或撤回资格，DEC0074凭证的精确小写admin为另一作用域。canViewDetail/canViewActiveRequest是权限投影，后台真实详情继续复核。历史7c2c+未提交来源说明保留，当前实际实现由07d6与最终候选快照绑定；没有为了本轮改写历史provenance。

本角色原已实际执行知识89/89、0F/E/S于07d6，原日志/XML/命令/时间保持。此次只校验原记录354输入指纹（353知识+pom）及整个tools/knowledge-model树未变，**没有重跑89，也没有声称在0f5重新运行**。该复用仅覆盖结构/引用/投影，不代表全量语义、产品或性能通过。

主侧final原件路径`{RAW}`已实际重新运行9类127/127、0F/E/S，9XML重计一致（RecordPG69，其余相关58）。run.json真实运行时HEAD是594a且测试文件dirty，不能改写为在clean0f5运行；40实际输入均与clean0f5 Git、当前文件及原source快照逐字一致，所以只作tested-bytes绑定。本体只读这些原件，未代跑产品或访问数据库。独立v2由父侧另派，本报告不预先宣称其通过。

最终12组观察与24份原服务auto_explain计划已核：4角色、0/5000/20000背景任务、每页20份合成元数据申请，只有原始单申请详情来自真实提交。8表前后摘要不变是原测试断言范围，不虚构摘要字符串。晚命中reviewer42在2万背景时task SeqScan20loops/每次过滤20010，page SQL本机约{reviewer['durationMs']}ms；其他角色不能概括成同样扫描。时间和线程累计分配不是生产SLA或峰值，不把克隆称全新签署业务流程。只认性能风险，未改SQL/索引/资格，优化仍须按用户此前要求讨论。

历史状态分别保留：focused因幂等键克隆重复3E；retry早命中127P；verified晚命中但business_key仍错127P；独立v1正式failed；final修正后主测127P。它们不相互覆盖，之前绿灯不能验收新提交，原失败也不改成passed。UI输入未变，已有58workflow/11人员/build/列表/字体是父侧或v1历史运行；本体没有重跑。strict86项遗留且与2dc集合相同、lint缺配置exit2，不能称全UI通过。

无repo改动，无孩子，无SQL/索引/权限/业务规则修改，无合并、部署或历史数据恢复。W2–W7、A12/高风险/完整矩阵、性能容量与UNKNOWN、A23含已审复核、用户暂停的通用工作流签名密码页及生产弹窗仍在原队列。此次整文件完成0、historicalUnique未知，整体审计未完成；独立质量和主侧PR前漂移复核由对应角色完成。
'''
(OUT / 'REVIEW.md').write_text(review)
shutil.copy2(Path(__file__), OUT / 'rebind-source.py')
write('rebind-run.json', dict(command=['python3', str(Path(__file__))], sourceCommit=SOURCE, previousSourceCommit=PREV, startedAt=START, finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), knowledge89Rerun=False, finite32Rereview=False, parent127ExecutedByThisRole=False, original79ArtifactHashesVerified=True, sourceInputs40MatchCandidate=True, knowledge354InputsUnchanged=True, exitCode=0))

artifacts = [fingerprint(p, OUT) for p in sorted(OUT.rglob('*')) if p.is_file() and p != OUT / 'manifest.json']
manifest = dict(status='FINAL', bindingMode='fixture-only-incremental-rebind', sourceCommit=SOURCE, previousSourceCommit=PREV, targetCommit=BASE, contractReadCommit=BASE, createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(), sourceInputs=old_manifest['sourceInputs'] + new_inputs, knowledgeFiles=353, assetIds=2848, artifacts=artifacts, wholeFileCompleted=0, historicalUnique='unknown', children=[], note='Original594a fully preserved under initial-594a; v1 remains failed. No knowledge89 rerun or finite32 re-review. Parent final127 read and byte-bound only; no QA acceptance by ontology.')
write('manifest.json', manifest)
for row in artifacts:
    assert fingerprint(OUT / row['path'], OUT) == row
for row in manifest['sourceInputs']:
    if row.get('sourceCommit'):
        assert sha(git('show', row['sourceCommit'] + ':' + row['path'])) == row['sha256']
assert not git('status', '--porcelain').strip()
print(json.dumps(dict(status='FINAL', ontologyResult='not-applicable', sourceCommit=SOURCE, originalArtifactsVerified=79, knowledgeFilesUnchanged=353, knowledge89Rerun=False, finite32Rereview=False, parentProductTestsRead=127, parentSourceInputsVerified=40, artifactFingerprintsVerified=len(artifacts), children=[]), ensure_ascii=False))
