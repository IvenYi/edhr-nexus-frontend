from pathlib import Path
import json,yaml
OUT=Path('/tmp/edhr-record-access-increment-ontology-20261110')
inventory=json.loads((OUT/'knowledge-current.json').read_text());delta=json.loads((OUT/'knowledge-delta.json').read_text())
lookup={r['id']:r for r in inventory['records'] if r['inventoryClass']!='schema-support'}
service='gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java'
ui='gmp-platform/frontend/src/pages/record-control/'
shared=[service,'docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml','docs/knowledge/evidence/record-history-detail-access-20261109.md']
scope={
 'DEC-0087':'Only09 detail-read supersession and07/10 retained scope, not the whole DEC record or lifecycle runtime.',
 'DEC-0087-09':'Only prior exclusion of superadmin from IN_REVIEW detail is superseded by0096-01; signature isolation, ordinary participants and ended history remain.',
 'scenario.record-control-active-detail-boundary':'Updated current scenario explicitly refers to0096 read-only exception; no general role-based bypass.',
 'DEC-0096':'Four statements and two scenarios only: authenticated-ID/database ACTIVE protected-admin read exception and preserved action boundaries.',
 'DEC-0096-01':'Existing applicant/candidate/assignee/own processed actor plus actual system admin detail read; tenant-ended history and unrelated normal rejection retained.',
 'DEC-0096-02':'Authenticated actor ID looks up ACTIVE user row; LOWER(BTRIM(username)) admin read identity, not display name or ordinary ADMIN role; not DEC0074 credential matching.',
 'DEC-0096-03':'Single SQL page projection and direct detail share SYSTEM_SUPER_ADMIN/RELATED_TASK_ACCESS; canViewDetail affects affordance only, detail still authorizes each read.',
 'DEC-0096-04':'Read-only grant does not create approval/task/signature/reassignment/withdrawal eligibility; mine and task filters and controlled signature isolation retained.',
 'scenario.record-control-detail-projection-consistency':'Finite actor matrix source and disabled/focusable tooltip/real403 feedback are present; this role did not run those UI or PG scenarios.',
 'scenario.record-control-system-admin-detail-read':'System admin detail true while unrelated task/actions stay separate; native source has actual admin/fake role/display/disabled admin negatives.',
 'evidence.record-control-active-detail-access-tests':'Reference points to actual AccessTest and PG method; historical52/10 logs are source evidence only, not this batch runtime proof.',
 'evidence.record-control-v1-service':'Current detail read implementation and retained service flow anchor; no claim that a source path proves all lifecycle scenarios.',
 'evidence.record-history-detail-access-confirmed':'Explicit Nov09 user quote is narrowed to current detail-read context; it does not authorize cross-domain full access.',
 'evidence.record-history-detail-access-service':'Current immutable07 source has shared SQL predicates, canViewRequestDetail, findRecord active projection and original submit/detail recheck.',
 'evidence.record-history-detail-access-system-account':'UserController protected name uses trim/ignore case; record exception additionally requires ACTIVE; do not conflate with exact-lowercase button credential exception.',
 'evidence.record-history-detail-access-tests':'Original historical test counts remain historical; source checks actor matrix and shared-terminal reader/signer boundary; fresh product results are parent/QA responsibility.',
 'evidence.record-history-detail-access-ui':'List icon and current-source/submitted links disable on false; tooltip span is focusable; details show server message; no frontend grant can bypass backend.',
 'anchor.core.record-control-active-detail-access':'Current API/UI/source mapping is locatable. sourceRevision7c plus explicitly uncommitted-source caveat is historical provenance, not a false claim7c contains changes; this audit pins07 snapshot separately.',
 'rule.record-control-active-detail-access':'Existing implemented/internal rule now includes explicit read-only protected admin; actor source stays backend, listProjectionGrantsAuthority false; no runtime knowledge-provider maturity upgrade.',
 'rule.record-control-authenticated-access-v1':'Authentication, current tenant source/history scope and personal applicant/task scopes remain distinct; added admin detail read does not broaden task lists.'
}
rows=[]
def add(id,classification,description,conclusion='consistent'):
    r=lookup[id]
    rows.append(dict(id=id,recordType=r['recordType'],sourcePath=r['sourcePath'],sourceLocator=r['sourceLocator'],originalMaturity=r['maturity'] or {'status':'not-declared-on-this-record'},scopeClassification=classification,semanticReview='reviewed',conclusion=conclusion,scope=description,originalEvidenceReferences=shared+[r['sourcePath']],runtimeEvidenceByThisRole='Knowledge89 only; no product/PG/browser execution',notWholeFileComplete=True))
for d in delta['recordDeltas']:
    id=d['id'];add(id,'direct-increment',scope[id],'superseded' if id=='DEC-0087-09' else 'consistent')
adjacent={
 'DEC-0074-01':'Actual signer eligibility and unchanged logged-in session are separate; submission success does not prove current reader has detail access.',
 'DEC-0074-02':'Exact lowercase admin button credential exception is retained in its own scope;0096 trim/casefold protected-name read identity does not broaden signing credentials or task qualification.',
 'DEC-0074-04':'SIGN_FIELD is untouched by0096 and record-change UI; no button cross-account/credential exception is inferred for field signing.',
 'DEC-0093-01':'Central logs/interventions visibility still does not grant fill/approval/content mutation eligibility.',
 'DEC-0093-02':'Form/DHR reassignment, true actor/signer qualifications and DHR dedicated actions remain; read-only detail exception is unrelated.',
 'DEC-0093-03':'Responsibility/signature/domain audit transaction semantics remain; no audit writes introduced by permission projection.',
 'DEC-0093-04':'Existing domain-owned projections and execution state remain; no second execution engine or fullmulti-tenant claim.',
 'DEC-0095-01':'All qualified people remain reachable via paging; changed test fixtures use Page.content rather than restoring total100 truncation.',
 'DEC-0095-02':'Record-control retains original candidates/applicant self-approval exclusion; global admin detail readability does not alter target eligibility.',
 'DEC-0095-03':'Page sizes/protocols are engineering choices; former text-ID stress/index scheme is not implicitly authorized by read capacity observation.',
 'DEC-0087-07':'My requests remain current applicant; todo/done remain current or own processed tasks, not all admin-visible workflow tasks.',
 'question.multi-tenant-workflow-isolation':'Existing future fullmulti-tenant workflow contract remains unresolved. Current code and tests pin default tenant; do not treat list/detail source checks as full isolation acceptance.'
}
for id,s in adjacent.items():add(id,'adjacent-retained',s,'needs-decision' if id.startswith('question.') else 'consistent')
assert len(rows)==32 and len({r['id'] for r in rows})==32
summary=dict(records=len(rows),direct=20,adjacent=12,conclusions={k:sum(r['conclusion']==k for r in rows) for k in ['consistent','superseded','needs-decision']},blockingBusinessQuestionsThisSlice=[],existingQuestionIsNonblocking=True,scope='Only explicit finite statements/symbols; no whole asset/wholefile/full semantic completion implied',wholeFileCompleted=0,historicalUnique='unknown')
(OUT/'finite-review-records.json').write_text(json.dumps(dict(summary=summary,records=rows),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
