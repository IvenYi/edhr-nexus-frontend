# 记录控制增量：有限本体核对

本角色为AGENTS要求的本体角色，未参与产品实现或最终独立质量。固定来源/目标为`07d6d4168a00a265afea8105db9a1a0e2554f683`、目标分支edhr-dev，契约实际读于同提交；与上批交付`2dc6941ea21caa5f8096a4fa6cc6cd36f6345f8c`相比AGENTS、codeplz及角色/交接契约无增量。知识仍0.3.25/schema1.2.0/P0 in-progress。状态PREPARED，等待主侧最终候选和实际运行原件后一次只读源绑定，不将本准备文件当正式FINAL。

本轮处理的是PR74合入之外新增的DEC0096记录控制详情只读例外与入口反馈，旧集成报告只作定位线索，不继承其2144/1794/350或页面数字为本次运行。当前主侧仅计划测试容量观察、先量化后讨论，不自动重写权限SQL、索引或业务政策；本体不需要为了门禁颜色修改知识，预期正式结果not-applicable。

维护规则具有明确原话来源：Nov09“我是超管为何会没有权限…超管应该默认有所有权限”的上下文是查看记录控制申请详情，DEC0096只在该只读范围替代DEC0087-09原无例外参与人限制。旧DEC及原文保留，普通参与人、终态历史、RECORD_CONTROL_REQUEST通用签名隔离及全部动作资格保持。没有依据扩大为跨模块全权限或代审批/代撤回/签署豁免。

当前Service通过认证actor ID反查数据库ACTIVE且LOWER(BTRIM(username))为admin，列表与详情共用SYSTEM_SUPER_ADMIN和RELATED_TASK_ACCESS。普通ADMIN角色、显示名或前端字段不授予例外。这里沿UserController受保护账号的trim/casefold定义；DEC0074按钮凭证的精确小写admin是另一作用域，不能因同词统一匹配或把详情可读当本次任务/签名有权。既有只读规则合理，当前代码在本范围落实它们。

四入口边界保持：变更记录/我的变更列表单SQL投影canViewDetail；来源查询的canViewActiveRequest复用真实详情资格；提交成功不能推定仍登录A具有实际签署申请人B的详情权，成功入口取重新查询且active_request_id与新申请ID匹配的投影。无权图标/链接禁用但原因可焦点访问，旧链接按服务器真实403/404反馈。申请详情可读与审批任务详情可读独立，任务服务继续关系授权。本人申请/待办/已办筛选未因此扩大。

有限32项逐ID重核：20个当前增量记录，12个相邻保留边界；30项在明确子范围一致、1项精确局部被替代（DEC0087-09）、1项保留现有非阻断needs-decision（完整multi-tenant工作流隔离）。不能据此说整个DEC0087、全部签名/动作、全领域或全知识一致。原成熟度逐条保留，implemented/internal或结构检查不是本轮产品运行证明。

anchor.core.record-control-active-detail-access的sourceRevision仍7c2c，locator明确说明当时修复未提交、不是该提交已包含实现。这是原时点provenance，不能把7c2c当已含修复的代码，也不为本次审计重写其历史。当前实际代码以07原始Git快照和最终候选绑定补充；API/UI/代码锚点可定位，没有因此制造新权限bug。

清单已刷新：当前353文件（92 Markdown、261 YAML），较2dc的350文件为3新增、5改动，旧345文件字节相同。当前清单sha256sum摘要`2e3d2a99a029a15bce571cdba937e11c4f864a66d7c12a0053a7d6e56d02c5b1`；旧为`ec67bff59cf2f8b848caa4ab70cc3ed2b2e2ad9dd08228679b95d6389d00a8b4`。Markdown按文件登记，不因无ID而略过。

同口径资产ID为2836→2848（含决策、声明、场景、实现差异、证据、锚点和开放问题），新增12、改动8、删除0，当前资产ID均唯一。排除schema.yaml的17个字段描述/示例映射后统计；原始“所有literal id映射”2865仍单列，不把schema重复string描述误报为业务ID重复。当前2848含95决策、590声明、462场景、73差异、582证据、2执行契约、279事实、141术语、72锚点、134概念、148关系、17问题、253规则。该完整口径不是旧931子集的直接分母或完成率；全量清单仍pending，仅32有限语义记录标明reviewed。

本角色已实际执行知识校验：`bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress --file tools/knowledge-model/pom.xml clean test`，89项、0失败/错误/跳过；日志、XML、输入指纹和真实命令/时间保留。它验证结构/引用/投影等，不是PG、产品、浏览器、数据库性能或泛型知识规则执行验收。本体未运行产品、未访问主环境数据库、未修改repo任何文件，未派发孩子。

只发两次列表查询不证明数据库内工作有界。CAST(task.instance_id AS VARCHAR)和相关EXISTS是否重复扫描须以主侧实际SQL计划、参数及规模观察判断，本体仅将它列为待运行推断，不先宣称新功能bug、缺索引或已优化。不得借性能改变原资格/确认/任务范围，也不得把合成克隆元数据当已完成签署业务流程。

完整multi-tenant契约仍是既有开放问题，不阻断本次default-tenant增量审查，也不在此代用户定案。W2-W7、A12/高风险/完整矩阵、其他性能/容量/UNKNOWN、A23含已审及用户暂停项继续。此次整文件完成0、historicalunique未知；清单盘点、有限语义、问题整改和运行验证分别报告，不宣称整体审计结束。
