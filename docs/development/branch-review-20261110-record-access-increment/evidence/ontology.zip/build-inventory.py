from pathlib import Path
import subprocess,json,hashlib,collections,datetime,yaml
ROOT=Path('/workspace/edhr-nexus-frontend');OUT=Path('/tmp/edhr-record-access-increment-ontology-20261110')
BASE='07d6d4168a00a265afea8105db9a1a0e2554f683';OLD='2dc6941ea21caa5f8096a4fa6cc6cd36f6345f8c'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
def inventory(rev):
    paths=git('ls-tree','-r','--name-only',rev,'docs/knowledge').decode().splitlines()
    rows=[];records=[];tops=collections.Counter()
    def walk(v,pointer,path):
        if isinstance(v,dict):
            if isinstance(v.get('id'),str):
                tokens=pointer.split('/');kind=tokens[-2] if len(tokens)>1 and tokens[-1].isdigit() else tokens[-1] or 'root'
                group='schema-support' if path.endswith('/schema.yaml') else 'support' if kind in ['evidence','implementationAnchors'] else 'current-or-history-pending'
                records.append(dict(id=v['id'],sourcePath=path,sourceLocator=pointer or '/',recordType=kind,inventoryClass=group,maturity={k:v[k] for k in ['status','visibility','availability','reviewStatus'] if k in v},semanticReview='pending',conclusion='pending',recordSha256=sha(json.dumps(v,ensure_ascii=False,sort_keys=True,default=str).encode())))
            for k,x in v.items():walk(x,pointer+'/'+str(k).replace('~','~0').replace('/','~1'),path)
        elif isinstance(v,list):
            for i,x in enumerate(v):walk(x,pointer+'/'+str(i),path)
    for path in paths:
        b=git('show',rev+':'+path)
        rows.append(dict(path=path,bytes=len(b),sha256=sha(b),gitBlob=git('rev-parse',rev+':'+path).decode().strip()))
        if path.endswith(('.yaml','.yml')):
            d=yaml.safe_load(b)
            if isinstance(d,dict):tops.update(d.keys())
            walk(d,'',path)
    digest=sha(''.join(r['sha256']+'  '+r['path']+'\n' for r in rows).encode())
    ids=collections.Counter(r['id'] for r in records)
    assets=[r for r in records if r['inventoryClass']!='schema-support'];assetids=collections.Counter(r['id'] for r in assets)
    summary=dict(commit=rev,files=len(rows),extensions=dict(collections.Counter(Path(r['path']).suffix for r in rows)),mappingIdRecords=len(records),distinctMappingIds=len(ids),duplicateMappingIds={k:n for k,n in ids.items() if n>1},assetIdRecords=len(assets),distinctAssetIds=len(assetids),duplicateAssetIds={k:n for k,n in assetids.items() if n>1},schemaSupportMappings=len(records)-len(assets),assetRecordTypes=dict(collections.Counter(r['recordType'] for r in assets)),topLevelKeys=dict(tops),sha256sumDigest=digest,inventoryMeaning='Every tracked docs/knowledge file plus every YAML mapping with literal string id at its exact JSON pointer. Asset IDs exclude schema.yaml descriptor/examples; all pending inventory, not semantic completion or comparable to the earlier931-only subset ledger.')
    return dict(summary=summary,files=rows,records=records)
OUT.mkdir(parents=True,exist_ok=True)
old=inventory(OLD);new=inventory(BASE)
for name,data in [('knowledge-before.json',old),('knowledge-current.json',new)]: (OUT/name).write_text(json.dumps(data,ensure_ascii=False,indent=2,default=str)+'\n')
oldfiles={r['path']:r for r in old['files']};newfiles={r['path']:r for r in new['files']}
delta=[]
for path in sorted(set(oldfiles)|set(newfiles)):
    a=oldfiles.get(path);b=newfiles.get(path)
    if a is None or b is None or a['sha256']!=b['sha256']:delta.append(dict(path=path,state='added' if a is None else 'deleted' if b is None else 'changed',before=a,after=b))
oldrecords={(r['sourcePath'],r['id']):r for r in old['records']};newrecords={(r['sourcePath'],r['id']):r for r in new['records']}
record_delta=[]
for key in sorted(set(oldrecords)|set(newrecords)):
    a=oldrecords.get(key);b=newrecords.get(key)
    if a is None or b is None or a['recordSha256']!=b['recordSha256']:record_delta.append(dict(id=key[1],sourcePath=key[0],state='added' if a is None else 'deleted' if b is None else 'changed',before=a,after=b))
(OUT/'knowledge-delta.json').write_text(json.dumps(dict(beforeCommit=OLD,afterCommit=BASE,fileDeltas=delta,recordDeltas=record_delta,sourceOnlyNotSemanticReview=True),ensure_ascii=False,indent=2)+'\n')
paths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml','docs/knowledge/evidence/record-history-detail-access-20261109.md','docs/knowledge/evidence/record-history-detail-access-20261109.yaml','docs/knowledge/evidence/record-control-v1.yaml','docs/knowledge/rules/record-change.yaml','docs/knowledge/implementation-anchors/core-business.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/controller/RecordControlController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/controller/UserController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/engine/WorkflowEngine.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/repository/WorkflowTaskRepository.java','gmp-platform/backend/src/main/java/com/zencas/edhr/recordcontrol/service/RecordControlTaskActionService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlAccessTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java','gmp-platform/frontend/src/api/record-control.ts','gmp-platform/frontend/src/pages/record-control/RecordChangePage.tsx','gmp-platform/frontend/src/pages/record-control/RecordRequestListPage.tsx','gmp-platform/frontend/src/pages/record-control/RecordRequestDetailPage.tsx','gmp-platform/frontend/src/pages/record-control/RecordApprovalDetailPage.tsx','gmp-platform/frontend/src/pages/record-control/RecordApprovalPage.tsx']
inputs=[]
for path in paths:
    b=git('show',BASE+':'+path);p=OUT/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    inputs.append(dict(path=path,sourceCommit=BASE,bytes=len(b),sha256=sha(b),gitBlob=git('rev-parse',BASE+':'+path).decode().strip(),coverage='finite referenced symbols; not whole-file semantic completion'))
dp='docs/development/branch-review-20261110-record-access-increment/decision-package.yaml';b=(ROOT/dp).read_bytes();p=OUT/'source'/dp;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
inputs.append(dict(path=dp,sourceCommit=None,readAtHead=BASE,workingTreeSource=True,bytes=len(b),sha256=sha(b)))
(OUT/'source-inputs.json').write_text(json.dumps(dict(sourceCommit=BASE,targetCommit=BASE,contractReadCommit=BASE,createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),inputs=inputs),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(current=new['summary'],previous=old['summary'],fileDeltaCount=len(delta),recordDeltaCount=len(record_delta),recordDeltas=[(r['id'],r['state']) for r in record_delta]),ensure_ascii=False,indent=2))
