SELECT (jsonb_populate_record(NULL::workflow_instance,
    jsonb_build_object('business_id','original-request','business_key','new-request'))).business_id AS retained_business_id;
SELECT column_name FROM information_schema.columns
WHERE table_name='workflow_instance' AND column_name IN ('business_id','business_key');
