from pathlib import Path
import argparse,json,subprocess,hashlib,datetime,xml.etree.ElementTree as ET,yaml
ROOT=Path('/workspace/edhr-nexus-frontend');OUT=Path('/tmp/edhr-record-access-increment-ontology-20261110')
BASE='07d6d4168a00a265afea8105db9a1a0e2554f683'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
def sha(b):return hashlib.sha256(b).hexdigest()
arg=argparse.ArgumentParser();arg.add_argument('--source-commit',required=True);arg.add_argument('--product-evidence',required=True);args=arg.parse_args();SOURCE=args.source_commit;RAW=Path(args.product_evidence)
assert git('rev-parse',SOURCE).decode().strip()==SOURCE
assert git('merge-base','--is-ancestor',BASE,SOURCE)==b''
assert git('rev-parse','origin/edhr-dev').decode().strip()==BASE
assert git('diff',BASE,SOURCE,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','docs/architecture','gmp-platform/backend/src/main','gmp-platform/frontend')==b''
changed=git('diff','--name-only',BASE,SOURCE).decode().splitlines()
allowed={'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java','docs/development/branch-review-20261110-record-access-increment/decision-package.yaml'}
assert set(changed)==allowed,changed
inv=json.loads((OUT/'knowledge-current.json').read_text())
for a in inv['files']:
    assert sha(git('show',SOURCE+':'+a['path']))==a['sha256'],a['path']
    assert sha((ROOT/a['path']).read_bytes())==a['sha256'],a['path']
knowledge=json.loads((OUT/'knowledge-result.json').read_text());assert knowledge['totals']==dict(tests=89,failures=0,errors=0,skipped=0)
run=json.loads((RAW/'run.json').read_text());summ=json.loads((RAW/'test-summary.json').read_text())
assert run['exitCode']==0 and summ['totals']==dict(tests=127,failures=0,errors=0,skipped=0)
assert '-Dedhr.audit.recordReadCapacity=true' in run['command']
assert len(run['sourceFingerprints'])==40
for a in run['sourceFingerprints']:
    assert sha(git('show',SOURCE+':'+a['path']))==a['sha256'],a['path']
    assert sha((ROOT/a['path']).read_bytes())==a['sha256'],a['path']
totals={k:0 for k in ['tests','failures','errors','skipped']};classes=[]
for p in sorted(RAW.glob('TEST-*.xml')):
    a=ET.parse(p).getroot().attrib;v={k:int(a.get(k,0)) for k in totals};classes.append(dict(name=a['name'],**v))
    for k in totals:totals[k]+=v[k]
assert totals==summ['totals'] and len(classes)==9
observations=[]
for p in sorted((RAW/'read-observations').glob('*.json')):
    d=json.loads(p.read_text());assert len(d['rows'])==20
    assert all(row['canViewDetail']==d['canViewExpected'] for row in d['rows'])
    observations.append(dict(file=p.name,actorId=d['actorId'],backgroundTasks=d['backgroundTasks'],canViewExpected=d['canViewExpected'],heapLayout=d['taskHeapLayout'],rows=len(d['rows']),threadAllocatedBytes=d['threadAllocatedBytes'],scope='parent actual raw observations; read and bound by ontology role, not executed here'))
assert len(observations)==12 and {d['backgroundTasks'] for d in observations}=={0,5000,20000}
rawfiles=[]
for p in sorted(RAW.rglob('*')):
    if p.is_file():
        b=p.read_bytes();rawfiles.append(dict(path=str(p.relative_to(RAW)),bytes=len(b),sha256=sha(b)))
parent=RAW.parent;focused=json.loads((parent/'focused/test-summary.json').read_text());retry=json.loads((parent/'retry/test-summary.json').read_text())
assert focused['totals']==dict(tests=3,failures=0,errors=3,skipped=0)
assert retry['totals']==dict(tests=127,failures=0,errors=0,skipped=0)
plans=json.loads((parent/'plan-analysis-verified.json').read_text());rows=plans['plans'];assert len(rows)==24
reviewer=next(d for d in rows if d['actorId']=='42' and d['backgroundTasks']==20000 and d['kind']=='page')
assert any(d.get('Actual Loops')==20 and d.get('Rows Removed by Filter')==20010 for d in reviewer['taskNodes'])
premium=json.loads((parent/'premium-delta.json').read_text());assert premium['added']==[] and premium['current']['total']==premium['baseline']['total']==86
before=json.loads((OUT/'source-inputs.json').read_text());finalinputs=[]
for a in before['inputs']:
    b=git('show',SOURCE+':'+a['path']);p=OUT/'final-source'/a['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    finalinputs.append(dict(path=a['path'],sourceCommit=SOURCE,bytes=len(b),sha256=sha(b),gitBlob=git('rev-parse',SOURCE+':'+a['path']).decode().strip(),coverage='finite scope/source binding only'))
binding=dict(sourceCommit=SOURCE,targetBranch='edhr-dev',targetCommit=BASE,contractReadCommit=BASE,contractIncrement='none; original and candidate byte-identical',workingTreeStateAtBinding=git('status','--porcelain').decode(),reviewedSourceChanges=changed,knowledgeFiles=353,knowledgeIds=2848,knowledgeAllUnchangedFromBase=True,knowledgeDigest=inv['summary']['sha256sumDigest'],initialInputsRetained=True,finalInputs=finalinputs,parentProductRun=dict(rawDirectory=str(RAW),command=run['command'],actualRunHead=run['head'],actualRunStatus=run['status'],testedBytesBoundToCleanCandidate=SOURCE,totals=totals,classes=classes,sourceFingerprints=run['sourceFingerprints'],rawFingerprints=rawfiles,actuallyExecutedByOntologyRole=False),parentCapacityObservationsReadOnly=observations,parentPlanScope=plans['scope'],reviewer20000LateMatchPlan=reviewer,parentEarlyRunScope='retry127 passed with early-match heap; distinct from verified late-match result; no product changes',parentFocusedFixtureError='3E due cloned workflow_instance.idempotency_key; fixed test data uniqueness, original raw retained; not a product policy failure',premiumStaticScope='86 same findings/no additions versus2dc; no全UI通过 claim',knowledgeActuallyExecutedByThisRole=knowledge['totals'],children=[],wholeFileCompleted=0,historicalUnique='unknown')
(OUT/'source-binding.json').write_text(json.dumps(binding,ensure_ascii=False,indent=2)+'\n')
refs=['docs/knowledge/decisions/DEC-0096-record-control-system-admin-detail-read.yaml','docs/knowledge/decisions/DEC-0087-record-control-v1-closure.yaml','docs/knowledge/rules/record-change.yaml']
sync=[]
for id,disposition,scope in [('DEC-0096-01','retained','Current merged protected-admin read-only detail exception, no cross-domain action grant.'),('DEC-0096-02','retained','Authenticated-ID database ACTIVE trim/casefold admin recognition for readonly scope; distinct from exact-admin credential exception.'),('DEC-0096-03','retained','Projection affords access but does not grant authorization; backend detail rechecks.'),('DEC-0096-04','retained','All original task/approval/signature/withdrawal and personal scopes remain.'),('DEC-0087-09','historical','Only original no-superadmin IN_REVIEW detail exclusion is superseded; signature isolation and ordinary/ended-history clauses retained.'),('DEC-0074-02','retained','Credential exception remains its own exact-admin scope; do not broaden from readonly identity.'),('anchor.core.record-control-active-detail-access','retained','Historical7c+uncommitted caveat preserved; current immutable07/candidate snapshots supplement this audit.'),('question.multi-tenant-workflow-isolation','deferred','Existing nonblocking future full-tenant contract question remains; default-tenant tests do not close it.')]:
    sync.append(dict(id=id,disposition=disposition,scope=scope,sourceReferences=refs+['finite-review-records.json']))
evidence=[dict(id='validation.record-access-increment.knowledge89',checkType='schema',command='bash /workspace/.edhr-cloud-tools/mvn-edhr --batch-mode --no-transfer-progress --file tools/knowledge-model/pom.xml clean test',outcome='passed',evidence=['knowledge-result.json','knowledge89.log','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','89/89 actually executed by ontology role']),dict(id='validation.record-access-increment.inventory-and-delta',checkType='reference',command='python3 build-inventory.py',outcome='passed',evidence=['knowledge-before.json','knowledge-current.json','knowledge-delta.json','353 files;2848 assetIDs;12added/8changed versus same-scope2dc inventory; not overall semantic completion']),dict(id='validation.record-access-increment.finite-semantics',checkType='projection',command='Finite YAML/source inspection recorded by build-finite.py',outcome='passed',evidence=['finite-review-records.json','32 finite records=30 scoped consistent/1 exact partial superseded/1 existing nonblocking needs-decision; no maturity changes']),dict(id='validation.record-access-increment.final-source-binding',checkType='evidence-path',command='python3 finalize.py --source-commit '+SOURCE+' --product-evidence '+str(RAW),outcome='passed',evidence=['source-binding.json','final-source/','All353 knowledge bytes unchanged;40 parent product fingerprints and9XML totals127 bound; parent runtime was read,not executed by this role'])]
result=dict(ontologyResult=dict(result='not-applicable',baselineBefore='0.3.25',baselineAfter='0.3.25',contractBaseline=dict(sourceCommit=SOURCE,targetBranch='edhr-dev',targetCommit=BASE,contractReadCommit=BASE,uncommittedContractPaths=[]),reason='Current slice adds only capacity/regression tests andDP; no product/UI/knowledge/schema/permission policy change. Existing mergedDEC0096 and retained rules are reviewed in finite scope; no forced knowledge rewrite or maturity upgrade.',changedArtifacts=[],knowledgeSync=sync,conflicts=[],questions=[],validationEvidence=evidence,roadmapProgress=dict(stage='P0',status='in-progress',exitCriteriaEvidence=[],deferredStages=['P1','P2','P3'])))
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
prepared=(OUT/'REVIEW.PREPARED.md').read_text();final=prepared.replace('状态PREPARED，等待主侧最终候选和实际运行原件后一次只读源绑定，不将本准备文件当正式FINAL。','状态FINAL；已一次只读绑定最终来源`'+SOURCE+'`及主侧实际运行字节，原准备文件单独保留。')
final=final.replace('预期正式结果not-applicable。','正式结果not-applicable。')
final+='\n\n最终绑定：产品源`'+SOURCE+'`相对07仅DP与原PG测试新增3个opt-in容量case，无产品/知识/契约/前端改动。主侧verified九类127/127、0F/E/S，其中RecordPG69（原66+3）；40输入逐字节匹配候选与当前文件，9XML重计一致。本体只读取产品原件，知识89为自己实际执行。12容量观察覆盖四角色及0/5000/20000背景任务、每页20合成元数据；晚命中审核人20000的任务SeqScan20loops/每次过滤20010为实际plan，约40万行工作，不因API只有2条SELECT而说工作有界。只认性能风险，未自动改SQL/索引/规则；时钟、线程累计分配及合成克隆不当生产SLA/峰值或已签署业务链。\n'
final+='\n父侧focused3E来自workflow_instance.idempotency_key克隆重复，是fixture错误，原件保留；修正后retry127通过但为早命中heap，verified改为背景在前/目标在后的晚命中并校验任务总数后127再次通过，不用早样本覆盖新组合。本体未代跑或修改产品测试。页面58+人员11/build/列表/字体通过是父侧证据，lint缺旧配置exit2、同版本premium全站86项与2dc集合相同/新增0，不能称全UI通过；原脚本/浏览器边界另由独立质量核验。\n'
final+='\n完整inventory默认pending不抹去以往有效有限审查，本角色未合并或重置历史覆盖；32有限记录不加算全局unique。当前正式NA结果、源码绑定和原件manifest齐全，无孩子、无repo改动；全新独立产品质量和主侧PR前漂移复核仍由对应角色完成。\n'
(OUT/'REVIEW.md').write_text(final)
sourceinputs=before['inputs']+finalinputs
artifacts=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file() and p.name!='manifest.json':
        b=p.read_bytes();artifacts.append(dict(path=str(p.relative_to(OUT)),bytes=len(b),sha256=sha(b)))
manifest=dict(status='FINAL',sourceCommit=SOURCE,targetCommit=BASE,contractReadCommit=BASE,createdAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),sourceInputs=sourceinputs,knowledgeFiles=353,assetIds=2848,artifacts=artifacts,wholeFileCompleted=0,historicalUnique='unknown',children=[],note='All bytes pinned, not wholefile/fullsemantic completion. Ontology executed knowledge89 only; parent127 read and bound, not rerun.')
(OUT/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for a in artifacts:assert sha((OUT/a['path']).read_bytes())==a['sha256']
print(json.dumps(dict(status='FINAL',ontologyResult='not-applicable',sourceCommit=SOURCE,knowledge353Unchanged=True,knowledgeActuallyRun=89,parentProductRunInspected=127,parentInputFingerprintsVerified=40,finite=32,artifactFingerprintsVerified=len(artifacts),children=[]),ensure_ascii=False))
