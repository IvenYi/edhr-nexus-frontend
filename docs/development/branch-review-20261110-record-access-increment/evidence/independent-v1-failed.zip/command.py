from pathlib import Path
import os,subprocess,json,datetime,sys,shutil,xml.etree.ElementTree as ET
raw=Path('/tmp/edhr-record-access-increment-final-qa-20261110');root=Path('/tmp/edhr-record-access-qa-worktree-20261110');label=sys.argv[1]
front=root/'gmp-platform/frontend';env=os.environ.copy();env.update(CHROME_PATH='/usr/bin/chromium',WORKFLOW_LIST_ARTIFACTS=str(raw/'ui'),EDHR_PERSONNEL_OUTPUT=str(raw/'personnel-ui'))
commands={'knowledge':['bash','/workspace/.edhr-cloud-tools/mvn-edhr','--batch-mode','--no-transfer-progress','--file','tools/knowledge-model/pom.xml','clean','test'],'workflow-ui':['node','scripts/test-workflow-list-ui-browser.mjs'],'personnel-ui':['node','scripts/test-personnel-targets-browser.mjs'],'frontend-build':['npm','run','build'],'list-style':['npm','run','verify:list-table-style'],'fonts':['npm','run','verify:no-external-fonts'],'lint':['npm','run','lint'],'premium':['python3',str(raw/'audit_project.py'),str(root),'--mode','strict','--output',str(raw/'premium-audit.json')]}
cmd=commands[label];cwd=root if label in ['knowledge','premium'] else front;started=datetime.datetime.now(datetime.timezone.utc)
with (raw/(label+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
record=dict(command=cmd,cwd=str(cwd),startedAt=started.isoformat(),finishedAt=datetime.datetime.now(datetime.timezone.utc).isoformat(),exitCode=r.returncode)
if label=='knowledge':
 p=root/'tools/knowledge-model/target/surefire-reports/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml';assert p.stat().st_mtime>=started.timestamp();shutil.copy2(p,raw/p.name);a=ET.parse(p).getroot().attrib;record['totals']={k:int(a[k]) for k in ['tests','failures','errors','skipped']}
(raw/(label+'-run.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(r.returncode)
