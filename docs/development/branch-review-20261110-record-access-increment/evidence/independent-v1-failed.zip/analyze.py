from pathlib import Path
import json,re,subprocess,hashlib,datetime
RAW=Path('/tmp/edhr-record-access-increment-final-qa-20261110')
ROOT=Path('/tmp/edhr-record-access-qa-worktree-20261110')
HEAD='594a1944682f21550fbbd1a108b852d3ef34655b'
BASE='07d6d4168a00a265afea8105db9a1a0e2554f683'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT)
run=json.loads((RAW/'verified/run.json').read_text())
fingers=[]
for item in run['sourceFingerprints']:
    p=item['path'];snap=(RAW/'verified/source'/p).read_bytes();committed=git('show',HEAD+':'+p)
    current=(ROOT/p).read_bytes()
    fingers.append(dict(**item,gitMatches=hashlib.sha256(committed).hexdigest()==item['sha256'],snapshotMatches=snap==committed,workingFileMatches=current==committed))
assert all(x['gitMatches'] and x['snapshotMatches'] and x['workingFileMatches'] for x in fingers)
extra=[]
for p in ['docs/knowledge/open-questions.yaml','docs/knowledge/decisions/DEC-0074-shared-terminal-button-signature.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0095-qualified-personnel-selection-completeness.yaml']:
    data=(ROOT/p).read_bytes();assert data==git('show',HEAD+':'+p)
    extra.append(dict(path=p,sha256=hashlib.sha256(data).hexdigest(),gitMatches=True))
contractPaths=['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/quality-verifier.md','docs/agents/business-knowledge-modeler.md']
contractDiff=git('diff',BASE,HEAD,'--',*contractPaths).decode();assert not contractDiff
fetch=git('rev-parse','FETCH_HEAD').decode().strip();assert fetch==BASE
binding=dict(baseCommit=BASE,headCommit=HEAD,actualHead=git('rev-parse','HEAD').decode().strip(),independentlyFetchedTarget=fetch,contractReadCommit=HEAD,contractDiff=contractDiff,runnerSourceFingerprintCount=len(fingers),runnerSourceFingerprints=fingers,additionalReadKnowledge=extra,actualIncrement=git('diff','--name-only',BASE,HEAD).decode().splitlines(),timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat())
(RAW/'source-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
s=(RAW/'verified/postgres.log').read_text();dec=json.JSONDecoder();offset=0;plans=[];out=RAW/'actual-plans';out.mkdir(exist_ok=True)
def nodes(n):
    yield n
    for c in n.get('Plans',[]):yield from nodes(c)
for line in s.splitlines(keepends=True):
    offset+=len(line)
    if 'audit-record-access-' not in line or 'plan:' not in line:continue
    m=re.search(r'audit-record-access-(\d+)-(\d+)',line);assert m
    at=offset
    while s[at].isspace():at+=1
    obj,_=dec.raw_decode(s,at);kind='page' if 'can_view_detail' in obj['Query Text'] else 'count'
    (out/(m[0]+'-'+kind+'.json')).write_text(json.dumps(obj,indent=2)+'\n')
    plan=obj['Plan'];tasks=[n for n in nodes(plan) if n.get('Relation Name')=='workflow_task']
    plans.append(dict(label=m[0],backgroundTasks=int(m[1]),actorId=m[2],kind=kind,durationMs=float(re.search(r'duration: ([\d.]+) ms',line)[1]),actualRows=plan['Actual Rows'],sharedHits=plan.get('Shared Hit Blocks'),taskNodes=[{k:n[k] for k in ['Node Type','Subplan Name','Index Name','Actual Loops','Actual Rows','Rows Removed by Filter','Filter','Index Cond'] if k in n} for n in tasks]))
assert len(plans)==24,len(plans)
observations=[]
for n in [0,5000,20000]:
    for actor in ['44','41','42','1']:
        pair=[p for p in plans if p['backgroundTasks']==n and p['actorId']==actor];assert {p['kind'] for p in pair}=={'count','page'}
        p=RAW/'verified/read-observations'/f'audit-record-access-{n}-{actor}.json';d=json.loads(p.read_text());assert len(d['rows'])==20
        assert {x['canViewDetail'] for x in d['rows']}=={actor!='44'}
        observations.append(dict(label=d['label'],rows=len(d['rows']),expected=d['canViewExpected'],elapsedNanos=d['elapsedNanos'],threadAllocatedBytes=d['threadAllocatedBytes']))
(RAW/'actual-plan-analysis.json').write_text(json.dumps(dict(qualification='Actual original service queries captured by auto_explain in own PG16, fixed 594a. Fixture business_id clone defect limits canonical metadata claim; q.workflow_instance_id/task.instance_id relation and actual original detail tested. Local instrumented time not SLA.',plans=plans,readObservations=observations),indent=2)+'\n')
print(json.dumps(dict(sourceFingerprints=len(fingers),allMatch=True,plans=len(plans),observations=len(observations),page20000=[p for p in plans if p['backgroundTasks']==20000 and p['kind']=='page']),indent=2))
