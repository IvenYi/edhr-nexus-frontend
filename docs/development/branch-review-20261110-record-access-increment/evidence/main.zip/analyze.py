from pathlib import Path
import json,hashlib,subprocess,re,xml.etree.ElementTree as ET,socket
ROOT=Path('/workspace/edhr-nexus-frontend');RAW=Path('/tmp/edhr-record-access-increment-20261110');HEAD='0f5d4354ed381adb07650548a2ec417969d2416d';BASE='07d6d4168a00a265afea8105db9a1a0e2554f683'
def load(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
run=load(RAW/'final/run.json')
for a in run['sourceFingerprints']:
 assert sha((ROOT/a['path']).read_bytes())==a['sha256']
 assert sha(subprocess.check_output(['git','show',HEAD+':'+a['path']],cwd=ROOT))==a['sha256']
assert subprocess.check_output(['git','diff',BASE,HEAD,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','docs/agents'],cwd=ROOT)==b''
history={}
for phase,t in [('focused',dict(tests=3,failures=0,errors=3,skipped=0)),('retry',dict(tests=127,failures=0,errors=0,skipped=0)),('verified',dict(tests=127,failures=0,errors=0,skipped=0)),('final',dict(tests=127,failures=0,errors=0,skipped=0))]:
 d=load(RAW/phase/'test-summary.json');assert d['totals']==t
 assert load(RAW/phase/'cleanup.json')['removed'] is True
 history[phase]=d['totals']
counter={};dml=[]
for line in (RAW/'final/postgres.log').read_text().splitlines():
 if 'audit-record-access-' not in line or 'execute ' not in line:continue
 m=re.search(r'audit-record-access-(\d+)-(\d+).*?execute [^:]+:\s*(.*)',line)
 if not m:continue
 sql=m[3].lstrip().lower();label='audit-record-access-'+m[1]+'-'+m[2]
 if sql.startswith('select'):counter[label]=counter.get(label,0)+1
 if sql.startswith(('insert','update','delete','truncate')):dml.append(line)
assert not dml
plans=load(RAW/'plan-analysis-final.json')['plans'];assert len(plans)==24
observations=[]
for p in sorted((RAW/'final/read-observations').glob('*.json')):
 d=load(p);assert counter[d['label']]==2
 assert d['taskHeapLayout']=='background-before-target' and len(d['rows'])==20
 assert {x['id'] for x in d['rows']}=={str(7400000+n) for n in range(1,21)}
 assert all(x['canViewDetail']==d['canViewExpected'] for x in d['rows'])
 plan=next(x for x in plans if x['label']==d['label'] and x['kind']=='page')
 assert plan['actualRows']==20 and len(plan['taskNodes'])==1
 task=plan['taskNodes'][0]
 if d['actorId'] in ['1','41']:assert task['Actual Loops']==0
 elif d['actorId']=='42':assert task['Actual Loops']==20 and abs(task['Rows Removed by Filter']-(d['backgroundTasks']+10))<=1
 else:assert task['Actual Loops']==1 and task['Rows Removed by Filter']==d['backgroundTasks']+21
 observations.append(dict(label=d['label'],backgroundTasks=d['backgroundTasks'],actorId=d['actorId'],allowed=d['canViewExpected'],applicationSelectExecutions=2,applicationElapsedNanos=d['elapsedNanos'],threadAllocatedBytes=d['threadAllocatedBytes'],pageSqlMs=plan['durationMs'],pageSharedHits=plan['sharedHits'],taskPlan=task))
assert len(observations)==12 and sum(counter.values())==24
ui=load(RAW/'personnel-ui/result.json');assert ui['result']=='passed' and len(ui['cases'])==11
workflow=json.loads((RAW/'workflow-ui.log').read_text().strip().splitlines()[-1]);assert workflow['passed']==58 and workflow['failed']==0
delta=load(RAW/'premium-delta.json');assert not delta['added'] and not delta['removed'] and delta['current']['total']==86
assert '✓ built' in (RAW/'frontend-build.log').read_text()
assert 'configuration file' in (RAW/'frontend-lint.log').read_text()
ports=sorted(set(int(x) for x in re.findall(r'Tomcat started on port (\d+)',(RAW/'final/maven.log').read_text())))
port_checks=[]
for port in ports:
 with socket.socket() as sock:
  sock.settimeout(.5);closed=sock.connect_ex(('127.0.0.1',port))!=0;assert closed
  port_checks.append(dict(port=port,closedAfterMavenExit=True,scope='Tomcat started by H2 execution fixture;API assertions use MockMvc,not actual socket traffic'))
record=dict(baseCommit=BASE,testedCandidate=HEAD,sourceFingerprints=run['sourceFingerprints'],noProductUiKnowledgeOrContractChanges=True,increment=load(RAW/'increment-paths.json')['counts'],phaseHistory=history,historyMeaning={'focused':'3 actual fixture errors: duplicate cloned workflow instance idempotency key;not product errors','retry':'127pass early-target heap layout;business_key unknown field remained,limited measurements only','verified':'127pass late-target layout;v1 independent subsequently failed synthetic business association fidelity','final':'127pass corrected business_id and target20/backgroundM association assertions;authoritative final main run'},capacity=observations,actualBusinessSelectExecutions=24,actualAutoExplainPlans=24,readIntegrity='Executed native test compares complete aggregate row digests of8 domain/audit tables before/after each capacity case;no manual hash values invented;no DML under measured application labels',frontend=dict(workflowComponents=58,personnelComponents=11,build='passed',listStyle='passed',noExternalFonts='passed',strictStatic='exit2;86 inherited findings=72 violations/14 unresolved;identical set at2dc/current07',lint='exit2;existing missing ESLint configuration;not global UI compliance'),runtimePortChecks=port_checks,remaining=['PERF-RECORD-DETAIL-PROJECTION-001:DB internal scan growth;proposed next-batch page-scoped qualification pending actual user reply','Existing global static86 and missing lint config remain open','Original family4N/option-full-load,event DB paging pending,capacity/UNKNOWN queues','W2-W7/A12/highrisk/full matrices/A23 incl already reviewed,user-paused workflows'],limitations=['Local warm PostgreSQL with auto_explain overhead,not production SLA','20 cloned metadata rows are not20 newly signed business flows;original request detail is real submit/signature','RecordPG69 and family23 are native PG;other selected tests include H2/static/mocks','UI58/11 are real components with synthetic API,not live main-environment actions','Admin read shortcut,applicant shortcut,ordinary hash once and reviewer correlated scans have different plans','353files/2848nested-support IDs are inventory,not semantic completion;not comparable to old931 subset'])
(RAW/'main-analysis.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(protectedInputs=len(run['sourceFingerprints']),tests=history['final'],observations=len(observations),plans=len(plans),selectExecutions=sum(counter.values()),reviewer20000=next(x for x in observations if x['backgroundTasks']==20000 and x['actorId']=='42'),runtimePorts=port_checks),ensure_ascii=False))
