from pathlib import Path
import json,re
RAW=Path('/tmp/edhr-record-access-increment-20261110');phase='retry';out=RAW/phase
s=(out/'postgres.log').read_text();decoder=json.JSONDecoder();pos=0;plans=[];folder=RAW/'plans';folder.mkdir(exist_ok=True)
def nodes(p):return [p]+[n for child in p.get('Plans',[]) for n in nodes(child)]
for line in s.splitlines(keepends=True):
    pos+=len(line)
    if 'audit-record-access-' not in line or 'plan:' not in line:continue
    m=re.search(r'audit-record-access-(\d+)-(\d+)',line);assert m,line
    at=pos
    while s[at].isspace():at+=1
    obj,end=decoder.raw_decode(s,at)
    query=obj['Query Text'];kind='page' if 'can_view_detail' in query else 'count'
    label=m[0];(folder/(label+'-'+kind+'.json')).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    plan=obj['Plan'];tasks=[n for n in nodes(plan) if n.get('Relation Name')=='workflow_task']
    plans.append(dict(label=label,backgroundTasks=int(m[1]),actorId=m[2],kind=kind,durationMs=float(re.search(r'duration: ([\d.]+) ms',line)[1]),rootType=plan['Node Type'],actualRows=plan['Actual Rows'],sharedHits=plan.get('Shared Hit Blocks'),taskNodes=[{k:n[k] for k in ['Node Type','Subplan Name','Index Name','Actual Loops','Actual Rows','Rows Removed by Filter','Filter','Index Cond'] if k in n} for n in tasks]))
assert len(plans)==24,len(plans)
for n in [0,5000,20000]:
    for actor in ['44','41','42','1']:
        pair=[p for p in plans if p['backgroundTasks']==n and p['actorId']==actor]
        assert {p['kind'] for p in pair}=={'count','page'}
(RAW/'plan-analysis.json').write_text(json.dumps(dict(scope='Actual canonical PG auto_explain of original service SQL on calling transaction;20 synthetic metadata requests;no hand-rewritten SQL',plans=plans),ensure_ascii=False,indent=2)+'\n')
for p in plans:
    if p['kind']=='page':print(json.dumps(p,ensure_ascii=False))
