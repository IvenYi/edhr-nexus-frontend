import hashlib
import json
from pathlib import Path
import shutil
import zipfile

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = ROOT / 'docs/development/branch-review-20261110-record-access-increment'
EVIDENCE = OUT / 'evidence'
SOURCES = {
    'main': Path('/tmp/edhr-record-access-increment-20261110'),
    'ontology': Path('/tmp/edhr-record-access-increment-ontology-20261110'),
    'independent-v1-failed': Path('/tmp/edhr-record-access-increment-final-qa-20261110'),
    'independent-v2-final': Path('/tmp/edhr-record-access-increment-final-qa-v2-20261110'),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def validate_role_manifest(root):
    manifest = json.loads((root / 'manifest.json').read_text())
    members = manifest.get('files', manifest.get('artifacts', []))
    assert members, root
    for member in members:
        path = root / member['path']
        assert path.is_relative_to(root) and not path.is_symlink(), path
        data = path.read_bytes()
        assert digest(data) == member['sha256'], path
        if 'bytes' in member:
            assert len(data) == member['bytes'], path
    return len(members)


assert 'result: passed' in (SOURCES['independent-v2-final'] / 'quality-result.yaml').read_text()
assert 'result: failed' in (SOURCES['independent-v1-failed'] / 'quality-result.yaml').read_text()
assert 'not-applicable' in (SOURCES['ontology'] / 'ontology-result.yaml').read_text()
EVIDENCE.mkdir(exist_ok=True)
packages = []
for name, source in SOURCES.items():
    role_members = None if name == 'main' else validate_role_manifest(source)
    paths = sorted(source.rglob('*'))
    assert not any(p.is_symlink() for p in paths), name
    files = [p for p in paths if p.is_file()]
    assert all('node_modules' not in p.parts and '.git' not in p.parts for p in files)
    members = []
    zip_path = EVIDENCE / (name + '.zip')
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for path in files:
            data = path.read_bytes()
            relative = path.relative_to(source).as_posix()
            members.append({'path': relative, 'bytes': len(data), 'sha256': digest(data)})
            archive.write(path, relative)
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None
        assert archive.namelist() == [m['path'] for m in members]
        for member in members:
            data = archive.read(member['path'])
            assert digest(data) == member['sha256'] and len(data) == member['bytes']
    manifest_path = EVIDENCE / (name + '-manifest.json')
    manifest = {'sourceRoot': str(source), 'files': members, 'fileCount': len(members),
                'totalUncompressedBytes': sum(m['bytes'] for m in members),
                'originalRoleManifestMembersVerified': role_members,
                'excluded': [], 'scope': 'All owned raw files; no source mutation or result rewriting'}
    write_json(manifest_path, manifest)
    packages.append({'name': name, 'path': str(zip_path.relative_to(OUT)),
                     'bytes': zip_path.stat().st_size, 'sha256': digest(zip_path.read_bytes()),
                     'manifest': str(manifest_path.relative_to(OUT)),
                     'manifestSha256': digest(manifest_path.read_bytes()),
                     'members': len(members), 'roleManifestMembersVerified': role_members})

copies = {
    ('main', 'main-analysis.json'): 'main-analysis.json',
    ('ontology', 'ontology-result.yaml'): 'ontology-result.yaml',
    ('ontology', 'REVIEW.md'): 'ontology-review.md',
    ('independent-v1-failed', 'quality-result.yaml'): 'initial-quality-result-failed.yaml',
    ('independent-v1-failed', 'independent-review.md'): 'initial-independent-review-failed.md',
    ('independent-v2-final', 'quality-result.yaml'): 'quality-result.yaml',
    ('independent-v2-final', 'independent-review.md'): 'independent-review.md',
}
copied = []
for (name, original), destination in copies.items():
    shutil.copyfile(SOURCES[name] / original, OUT / destination)
    copied.append({'path': destination, 'source': name + '/' + original,
                   'sha256': digest((OUT / destination).read_bytes())})
write_json(OUT / 'evidence-packages.json', {'baseCommit': '07d6d4168a00a265afea8105db9a1a0e2554f683',
    'testedCandidate': '0f5d4354ed381adb07650548a2ec417969d2416d', 'packages': packages,
    'copiedFormalArtifacts': copied,
    'note': 'Four separate immutable result histories; initial failed is not overwritten by final passed'})
print(json.dumps({'packages': packages, 'totalMembers': sum(p['members'] for p in packages)}, ensure_ascii=False))
