# 本轮原始截图有限查看

主侧实际查看 `ui/record-denied-390.png` 和 `ui/record-source-denied-1440.png`：窄屏保留表格滚动、可聚焦禁用入口及原因 Tooltip；桌面来源表单显示当前申请只读入口被禁用及原因。截图使用 synthetic API，右侧预览内容为空的 fixture 不代表真实表单预览已验证。只作相应场景的有限视觉证据，不能称全部页面/所有状态的可视合规通过；strict86和旧控件候选仍保留。
