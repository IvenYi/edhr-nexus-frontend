import pathlib,re,json,collections,hashlib
p=pathlib.Path(__file__).parent
events=[json.loads(x) for x in (p/'observations.jsonl').read_text().splitlines()]
assert len(events)==29 and sum(e['totalStatements'] for e in events)==298
def normalize(sql):return re.sub(r'\s+',' ',re.sub(r'\$\d+','?',sql)).strip().rstrip(';').lower()
expected=collections.Counter(normalize(sql) for e in events for key in ('jdbcSql','hibernateSql') for sql in e[key])
records=[]
pattern=re.compile(r'^(\d{4}-\d\d-\d\d[^\[]+)\[(\d+)\] \[([^\]]*)\] (LOG|DETAIL|ERROR|WARNING|FATAL):\s*(.*)$')
for line in (p/'postgres.log').read_text().splitlines():
 m=pattern.match(line)
 if m:records.append({'timestamp':m[1].strip(),'pid':m[2],'database':m[3],'severity':m[4],'text':m[5]})
 elif records:records[-1]['text']+='\n'+line
selects=[]
for i,r in enumerate(records):
 if r['database']!='edhr_workflow_read_test_server' or r['severity']!='LOG':continue
 m=re.search(r'\b(?:execute [^:]+|statement):\s*(SELECT\b.*)',r['text'],re.I|re.S)
 if not m:continue
 sql=m[1];parameters=''
 for following in records[i+1:]:
  if following['pid']!=r['pid']:continue
  if following['severity']=='DETAIL' and following['text'].startswith('parameters:'):
   parameters=following['text'][len('parameters:'):].strip();break
  break
 selects.append({'timestamp':r['timestamp'],'pid':r['pid'],'sql':sql,'normalizedSql':normalize(sql),'parameters':parameters})
observed=collections.Counter(s['normalizedSql'] for s in selects)
matches=[];other=[]
for sql,count in observed.items():
 if sql in expected:matches.append({'sha256':hashlib.sha256(sql.encode()).hexdigest(),'normalizedSql':sql,'observerCount':expected[sql],'serverCount':count})
 else:other.append({'normalizedSql':sql,'count':count})
assert set(expected)<=set(observed),'missing SQL signatures'
assert all(x['observerCount']==x['serverCount'] for x in matches),'server business count differs'
matched=[s for s in selects if s['normalizedSql'] in expected]
directory=[s for s in matched if 'from user_account ua1_0 where ua1_0.tenant_id=' in s['normalizedSql']]
assert len(directory)==11
limitChecks=[]
for s in directory:
 indices=[int(i) for i in re.findall(r'\$(\d+)\s*=',s['parameters'])]
 assert indices and re.search(r'\$'+str(max(indices))+r" = '100'\s*$",s['parameters'])
 assert 'count(' not in s['normalizedSql'] and 'fetch first ? rows only' in s['normalizedSql']
 limitChecks.append({'signature':hashlib.sha256(s['normalizedSql'].encode()).hexdigest(),'parameterCount':len(indices),'limitParameter':max(indices),'lastValue':'100'})
nameArrays=[s for s in matched if 'from user_account where cast(id as varchar)=any(?)' in s['normalizedSql']]
assert len(nameArrays)==5 and all(re.findall(r'\$(\d+)\s*=',s['parameters'])==['1'] for s in nameArrays)
origin=[]
for e in events:
 if e['kind']!='original-candidate-directory':continue
 sql=e['hibernateSql'][-1];signature=normalize(sql);candidates=e['data']['originalCandidates'];rows=[s for s in directory if s['normalizedSql']==signature];assert len(rows)==1
 expectedCount=7 if candidates==0 else candidates+7
 actual=len(re.findall(r'\$(\d+)\s*=',rows[0]['parameters']));assert actual==expectedCount
 origin.append({'originalCandidates':candidates,'serviceSelects':e['totalStatements'],'returnedPersonnel':e['data']['returnedPersonnel'],'directoryBoundParameters':actual,'limit':100})
for e in events:
 if e['kind']=='form-detail-current-names':
  n=e['data']['activeApprovalNodes'];kind=e['data']['assigneeKind'];nExpected=1 if n==0 or kind=='blank' else 2 if kind=='repeated' else n+1
  assert e['totalStatements']==nExpected
 elif e['kind']=='form-detail-history':assert e['totalStatements']==2
 elif e['kind']=='form-detail-unauthorized':assert e['totalStatements']==1 and e['hibernateStatements']==0
summary={'candidate':'04fc893f3df9de8d345fa32a7699f61f7cbc53ae','testInvocations':29,'observerBusinessSelects':298,'serverMatchedBusinessSelects':len(matched),'businessSignatures':len(expected),'serverTotalSelects':len(selects),'excludedOtherSelects':sum(o['count'] for o in other),'directoryCalls':len(directory),'directoryLimit':100,'directoryCountQueries':0,'preservedNameArrayCalls':len(nameArrays),'originalCandidateBindings':origin,'note':'Only matching current-thread queryForList/Hibernate read signatures; other startup/migration/metadata/fixture assertions separately excluded. Not all-network SQL or HTTP/JWT/browser/SLA acceptance.'}
(p/'sql-signature-counts.json').write_text(json.dumps(matches,ensure_ascii=False,indent=2)+'\n')
(p/'matched-server-selects.json').write_text(json.dumps(matched,ensure_ascii=False,indent=2)+'\n')
(p/'excluded-server-selects.json').write_text(json.dumps(other,ensure_ascii=False,indent=2)+'\n')
(p/'directory-limit-checks.json').write_text(json.dumps(limitChecks,indent=2)+'\n')
(p/'server-sql-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False))
