import pathlib,subprocess,json,hashlib,datetime,time,os,shutil,sys,xml.etree.ElementTree as ET
source=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path(__file__).parent
root=pathlib.Path('/tmp/edhr-form-detail-server-worktree-20261105');candidate='04fc893f3df9de8d345fa32a7699f61f7cbc53ae'
name='edhr-form-detail-server-20261105';db='edhr_workflow_read_test_server';created=False;added=False;commands=[];code=99
def run(args,**kw):
 r=subprocess.run(args,capture_output=True,text=True,**kw);commands.append({'args':args,'cwd':str(kw.get('cwd','')),'exitCode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 if r.returncode:raise RuntimeError(str(args)+': '+r.stderr)
 return r.stdout.strip()
try:
 run(['git','worktree','add','--detach',str(root),candidate],cwd=source);added=True
 assert run(['git','rev-parse','HEAD'],cwd=root)==candidate and not run(['git','status','--porcelain'],cwd=root)
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1','-c','log_line_prefix=%m [%p] [%d] ']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own PG not ready')
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 env=os.environ.copy();env.update(PGUSER='postgres',WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}')
 cmd=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'observations.jsonl'),'-Dtest=WorkflowReadObservationPostgresTest','test']
 start=datetime.datetime.now(datetime.timezone.utc);fps=[]
 for path in ['gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java','gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java']:
  b=(root/path).read_bytes();fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});p=out/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 with (out/'maven.log').open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 commands.append({'args':cmd,'cwd':str(root),'exitCode':r.returncode,'output':'maven.log'})
 meta={'candidate':candidate,'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exitCode':r.returncode,'sourceFingerprints':fps,'containerId':cid,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])};(out/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
 files=list((root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.WorkflowReadObservationPostgresTest.xml'));assert len(files)==1 and files[0].stat().st_mtime>=start.timestamp();shutil.copy2(files[0],out/files[0].name)
 doc=ET.parse(files[0]).getroot();totals={k:int(doc.attrib.get(k,0)) for k in ('tests','failures','errors','skipped')};(out/'test-summary.json').write_text(json.dumps(totals,indent=2)+'\n')
 (out/'worktree-status-end.txt').write_text(run(['git','status','--porcelain'],cwd=root));assert not (out/'worktree-status-end.txt').read_text()
 code=0 if r.returncode==0 and totals=={'tests':29,'failures':0,'errors':0,'skipped':0} else 1
 print(json.dumps(totals));print((out/'maven.log').read_text()[-1200:])
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr)
  run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:removed=True;break
   time.sleep(.1)
 else:removed=False
 if added:run(['git','worktree','remove',str(root)],cwd=source)
 (out/'cleanup.json').write_text(json.dumps({'ownedContainer':name,'containerRemoved':removed,'ownedWorktree':str(root),'worktreeRemoved':not root.exists(),'noDependencySymlinksCreated':True},indent=2)+'\n')
 (out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
sys.exit(code)
