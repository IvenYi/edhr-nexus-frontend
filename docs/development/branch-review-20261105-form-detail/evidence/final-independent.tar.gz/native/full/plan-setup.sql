
INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status)
SELECT 1000000+n,n%2,'plan-background-'||n,'background-'||n,'not-used','ACTIVE' FROM generate_series(0,59999) n;
INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status)
SELECT 40000+n,0,'plan-origin-'||n,'origin-scope-'||lpad(n::text,5,'0'),'not-used','ACTIVE' FROM generate_series(0,4999) n
ON CONFLICT(id) DO NOTHING;
ANALYZE user_account;
