import pathlib,subprocess,json,re,sys
out=pathlib.Path(sys.argv[1]);name=sys.argv[2];db='edhr_workflow_read_test_full'
def psql(sql):
 r=subprocess.run(['docker','exec','-i',name,'psql','-XqAt','-v','ON_ERROR_STOP=1','-U','postgres','-d',db],input=sql,text=True,capture_output=True)
 if r.returncode:raise RuntimeError(r.stderr)
 return r.stdout
setup="""
INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status)
SELECT 1000000+n,n%2,'plan-background-'||n,'background-'||n,'not-used','ACTIVE' FROM generate_series(0,59999) n;
INSERT INTO user_account(id,tenant_id,username,display_name,password_hash,status)
SELECT 40000+n,0,'plan-origin-'||n,'origin-scope-'||lpad(n::text,5,'0'),'not-used','ACTIVE' FROM generate_series(0,4999) n
ON CONFLICT(id) DO NOTHING;
ANALYZE user_account;
"""
(out/'plan-setup.sql').write_text(setup);psql(setup)
events=[json.loads(s) for s in (out/'observations.jsonl').read_text().splitlines()]
def quote(v):return "'"+v.replace("'","''")+"'" if isinstance(v,str) else str(v)
summary=[]
for n in (1,100,5000):
 e=next(e for e in events if e['kind']=='original-candidate-directory' and e['data']['originalCandidates']==n)
 sql=e['hibernateSql'][-1];values=[0,'ACTIVE','2026-11-05 00:00:00','42','%origin-scope%','%origin-scope%']+[str(40000+i) for i in range(n)]+[100]
 assert sql.count('?')==len(values)
 i=iter(range(1,len(values)+1));prepared=re.sub(r'\?',lambda _: '$'+str(next(i)),sql)
 statement='SET statement_timeout=30000;\nPREPARE origin_'+str(n)+' AS '+prepared+';\nEXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) EXECUTE origin_'+str(n)+'('+','.join(map(quote,values))+');\n'
 (out/f'plan-origin-{n}.sql').write_text(statement);raw=psql(statement);(out/f'plan-origin-{n}.json').write_text(raw);plan=json.loads(raw)[0]
 nodes=[]
 def walk(p):
  nodes.append({k:p[k] for k in ('Node Type','Relation Name','Index Name','Actual Rows','Actual Loops','Rows Removed by Filter','Shared Hit Blocks','Shared Read Blocks') if k in p})
  for c in p.get('Plans',[]):walk(c)
 walk(plan['Plan']);summary.append({'originalCandidates':n,'replayedDirectoryPlaceholders':len(values),'planningTimeMs':plan['Planning Time'],'executionTimeMs':plan['Execution Time'],'planNodes':nodes})
indexes=psql("SELECT indexname,indexdef FROM pg_indexes WHERE tablename='user_account' ORDER BY indexname;");(out/'user-indexes.txt').write_text(indexes)
x={'scope':'Observed Hibernate query replayed as PostgreSQL PREPARE/custom EXPLAIN; controlled 60000 background and 5000 origin users on real configured schema, not production distribution or SLA','plans':summary,'rowDistribution':psql("SELECT tenant_id,count(*) FROM user_account GROUP BY tenant_id ORDER BY tenant_id;").strip()}
(out/'plan-summary.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps(x,ensure_ascii=False))
