import pathlib,subprocess,json,hashlib,tarfile,re,xml.etree.ElementTree as ET,collections,yaml
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path(__file__).parent
base='ea5c57e63cb4980961498c4c192705ef91a37170';head='04fc893f3df9de8d345fa32a7699f61f7cbc53ae'
folder=root/'docs/development/branch-review-20261105-form-detail';checks=[];commands=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def cmd(args):
 p=subprocess.run(args,cwd=root,capture_output=True,text=True);commands.append({'command':args,'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr});assert p.returncode==0,(args,p.stderr);return p.stdout
def ok(name,detail):checks.append({'id':name,'outcome':'passed','detail':detail})
def save(name,x):(out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
assert cmd(['git','rev-parse','HEAD']).strip()==head;assert cmd(['git','rev-parse','origin/edhr-dev']).strip()==base
status=cmd(['git','status','--porcelain']);assert not status;ok('fixed-baseline-clean','Current candidate and target fixed, main working tree clean')
assert cmd(['git','merge-base',base,head]).strip()==base;assert not cmd(['git','diff','--name-only','33763f3c76dea3fe8839c5a3a94cdf62978db14b',base]);ok('merged-target-tree-equality','Target is ancestor and same tree as prior PR59 delivery')
pr=json.loads(cmd(['gh','api','repos/IvenYi/edhr-nexus-frontend/pulls/59','--jq','{number,state,merged,merge_commit_sha}']));assert pr['merged'] and pr['merge_commit_sha']==base;save('pull59.json',pr);ok('pr59-merge','Actual pull metadata confirms merge and target')
changed=cmd(['git','diff','--name-only',base,head]).splitlines();test='gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java';assert test in changed
assert all(p==test or p=='docs/development/branch-review-20261015/NEXT.md' or p.startswith('docs/development/branch-review-20261105-form-detail/') for p in changed);save('changed-paths.json',changed);ok('test-only-scope','Only one test and finite audit docs/NEXT; no product/front-end/migrations/config/dependency/knowledge change')
assert not cmd(['git','diff','--name-only',base,head,'--','gmp-platform/backend/src/main','gmp-platform/frontend','docs/knowledge','AGENTS.md','codeplzreadme.md','docs/agents']);ok('protected-runtime-contracts','Product, UI, contracts and knowledge are unchanged')
tracked=cmd(['git','ls-tree','-r','--name-only',base]).splitlines();knowledge=[p for p in tracked if p.startswith('docs/knowledge/')];assert len(knowledge)==345
for p in knowledge:assert (root/p).read_bytes()==subprocess.check_output(['git','show',base+':'+p],cwd=root)
ok('knowledge-bytes-345',345)
source=json.loads((folder/'source-review.json').read_text());assert len(source['sourceFingerprints'])==12
for f in source['sourceFingerprints']:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];assert f['sameAsTarget']==(b==subprocess.check_output(['git','show',base+':'+f['path']],cwd=root))
ok('current-source-fingerprints-12',12)
manifest=json.loads((folder/'evidence-manifest.json').read_text());archive=folder/manifest['archive']['path'];assert len(archive.read_bytes())==manifest['archive']['bytes'] and sha(archive.read_bytes())==manifest['archive']['sha256']
with tarfile.open(archive) as t:
 members={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()};assert len(members)==len(manifest['rawArtifacts'])==96
 for f in manifest['rawArtifacts']:assert len(members[f['member']])==f['bytes'] and sha(members[f['member']])==f['sha256'],f
 ok('all-primary-raw-members-96',96)
 onto=json.loads(members['ontology/manifest.json']);assert len(onto['artifacts'])==onto['rawArtifactCount']==43
 for f in onto['artifacts']:assert len(members['ontology/'+f['path']])==f['bytes'] and sha(members['ontology/'+f['path']])==f['sha256']
 assert len([n for n in members if n.startswith('ontology/')])==45
 assert sha(members['ontology/manifest.json']) in members['ontology/manifest.sha256'].decode();ok('nested-ontology-originals-43-plus2',45)
 fps=json.loads(members['ontology/source-fingerprints.json']);assert len(fps)==32
 for f in fps:
  b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];assert members['ontology/read-snapshots/'+f['path']]==b
 ok('ontology-source-inputs-32',32)
 protected=json.loads(members['ontology/protected-source-unchanged.json']);assert protected['fullFilesChecked']==13 and protected['allUnchanged']
 for f in protected['records']:
  b=(root/f['path']).read_bytes();assert sha(b)==f['sha256']==f['baselineSha256'] and f['unchanged'];assert b==subprocess.check_output(['git','show',base+':'+f['path']],cwd=root)
 ok('ontology-product-protection-13',13)
 sem=json.loads(members['ontology/semantic-audit.json']);assert sem['counts']=={'reviewed':13,'consistent':12,'evidenceGap':1};assert len(sem['records'])==13
 for record in sem['records']:
  doc=yaml.safe_load((root/record['sourcePath']).read_text());found=[]
  def walk(x):
   if isinstance(x,dict):
    if x.get('id')==record['id']:found.append(x)
    for v in x.values():walk(v)
   elif isinstance(x,list):
    for v in x:walk(v)
  walk(doc);assert len(found)==1,record['id'];assert record['reviewStatus']=='reviewed';assert record['sourceCommit']==base;assert record['originalStatement']
  actual=found[0];assert record['originalStatement'] in (actual.get('statement'),actual.get('description'),actual.get('explanation'),actual.get('question')),record['id']
 assert [v['id'] for v in sem['records'] if v['conclusion']=='evidence-gap']==['question.multi-tenant-workflow-isolation'];assert sem['fullSemanticAuditComplete'] is False
 save('verified-ontology-records.json',sem);ok('finite-ontology-13-distinguishes-gap','12 consistent,1 existing full multi-tenant evidence-gap; no whole-knowledge conclusion')
 ontoResult=yaml.safe_load(members['ontology/ontology-result.yaml'])['ontologyResult'];assert ontoResult['result']=='not-applicable';assert not ontoResult['changedArtifacts'] and not ontoResult['conflicts'] and not ontoResult['questions'];assert (folder/'ontology-result.yaml').read_bytes()==members['ontology/ontology-result.yaml'];ok('ontology-na-original-result','Original result matches archived role report, no runtime tests claimed by that role')
 for phase,expected,classes in [('focused',15,1),('full',167,10)]:
  prefix='primary/'+phase+'/';xmls=[ET.fromstring(b) for n,b in members.items() if n.startswith(prefix+'TEST-') and n.endswith('.xml')];assert len(xmls)==classes
  totals={k:sum(int(x.get(k,'0')) for x in xmls) for k in ('tests','failures','errors','skipped')};assert totals=={'tests':expected,'failures':0,'errors':0,'skipped':0}
  result=json.loads(members[prefix+'test-summary.json']);assert result['totals']==totals and not result['missingFreshReports']
  run=json.loads(members[prefix+'run.json']);assert run['exitCode']==0 and run['commit']==base
  for f in run['sourceFingerprints']:
   b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'] and members[prefix+'source/'+f['path']]==b
  assert json.loads(members[prefix+'cleanup.json'])['removed'] is True
  ok('main-'+phase+'-fresh-xml',{'totals':totals,'classes':classes,'snapshotMatchesCandidate':True,'cleanup':True})
 events=[json.loads(v) for v in members['primary/full/observations.jsonl'].decode().splitlines()];assert len(events)==29 and sum(v['totalStatements'] for v in events)==298
 for e in events:assert e['jdbcStatements']==len(e['jdbcSql']) and e['hibernateStatements']==len(e['hibernateSql']) and e['totalStatements']==e['jdbcStatements']+e['hibernateStatements']
 new=[e for e in events if e['kind'].startswith('form-detail') or e['kind']=='original-candidate-directory'];assert len(new)==15
 for e in new:
  d=e['data'];kind=e['kind']
  if kind=='form-detail-current-names':
   n=d['activeApprovalNodes'];a=d['assigneeKind'];expected=1 if a=='blank' else 2 if a=='repeated' else 1+n;assert e['totalStatements']==expected
  elif kind=='original-candidate-directory':
   n=d['originalCandidates'];assert e['totalStatements']==4 and d['returnedPersonnel']==min(n,100);assert d['hibernatePlaceholders']==10+n;assert e['hibernateSql'][-1].count('?')==7+n
  else:assert e['totalStatements']==(2 if kind=='form-detail-history' else 1)
 save('verified-observations.json',[{k:e[k] for k in ('kind','data','totalStatements')} for e in events]);ok('observation-counts-29-298','Includes fifteen finite new cases; initial15 is not additive; not all server/network SQL')
 summary=json.loads(members['primary/full/plan-summary.json']);assert summary['rowDistribution']=='0|35005\n1|30000';assert len(summary['plans'])==3
 for n in (1,100,5000):
  event=next(e for e in events if e['kind']=='original-candidate-directory' and e['data']['originalCandidates']==n);sql=event['hibernateSql'][-1]
  i=iter(range(1,sql.count('?')+1));prepared=re.sub(r'\?',lambda _:'$'+str(next(i)),sql)
  script=members[f'primary/full/plan-origin-{n}.sql'].decode();assert 'PREPARE origin_'+str(n)+' AS '+prepared+';' in script
  assert script.rstrip().endswith(',100);') and 'EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON)' in script
  plan=json.loads(members[f'primary/full/plan-origin-{n}.json'])[0];assert plan['Plan']['Node Type']=='Limit' and plan['Plan']['Actual Rows']==min(n,100)
  scans=[]
  def scansOf(x):
   if x.get('Relation Name')=='user_account':scans.append(x)
   for y in x.get('Plans',[]):scansOf(y)
  scansOf(plan['Plan']);assert len(scans)==1 and scans[0]['Node Type']=='Seq Scan';assert scans[0]['Actual Rows']+scans[0]['Rows Removed by Filter']==65005
  saved=next(v for v in summary['plans'] if v['originalCandidates']==n);assert saved['replayedDirectoryPlaceholders']==7+n
 ok('actual-sql-prepared-plan-replay','Three exact observed Hibernate statements, controlled65005 distribution, SQL limit100; no production SLA/index claim')
 rawIndexes=members['primary/full/user-indexes.txt'].decode();assert all(v in rawIndexes for v in ['user_account_pkey','uk_user_username','idx_user_avatar_file']);ok('existing-index-boundary','Numeric PK,tenant/username unique,avatar; no new index')
mainDiff=cmd(['git','diff','--unified=0',base,head,'--',test]);deletions=[v for v in mainDiff.splitlines() if v.startswith('-') and not v.startswith('---')];assert len(deletions)==1 and 'TRUNCATE workflow_task' in deletions[0];assert all('assertThat' not in v for v in deletions);ok('old-assertions-preserved','Only old deleted line is disposable fixture TRUNCATE extension')
body=(root/test).read_text();assert '@EnabledIfSystemProperty(named = "edhr.audit.workflowReads"' in body and '@EnabledIfEnvironmentVariable(named = "WORKFLOW_READ_TEST_DATABASE_URL"' in body;assert '127\\\\.0\\\\.0\\\\.1' in body
assert 'assertThat(formEvidence()).isEqualTo(before)' in body and 'candidate_snapshot::text' in body and 'read.hibernateSql).isEmpty()' in body;ok('test-guard-content-evidence','Explicit opt-in/local disposable URL and output/read-only/authorization/candidate preservation assertions retained')
perf=json.loads((folder/'performance-report.json').read_text());assert len(perf['findings'])==3 and all(v['status']=='open' for v in perf['findings']);assert perf['productFilesChanged']==0 and perf['newIndexes']==0 and perf['wholeAuditComplete'] is False
sourceNotes=(folder/'review-notes.md').read_text();readme=(folder/'README.md').read_text();assert all(v in sourceNotes+readme for v in ['A23','currentAssigneeNames','projectHistory','931','86','W6','W7','暂停','未答不当批准']);ok('scope-a23-concrete-extraction-residuals','Known performance findings open; no policy/whole audit/START/browser/SLA completion claim; pauses and queues preserved')
baseline=json.loads((folder/'baseline-review.json').read_text());assert baseline['trackedPathsAtTarget']==len(tracked)==7484 and baseline['wholeFileComplete']==0 and baseline['historicalUniqueCoverage'] is None and not baseline['wholeAuditComplete'];ok('inventory-not-completed-semantics','7484 fixed inventory only; old semantic/UI backlog remains')
inputs=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml','docs/architecture/business-knowledge-model.md','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml']+[f['path'] for f in source['sourceFingerprints']]+[str(v.relative_to(root)) for v in folder.iterdir() if v.is_file()]
records=[]
for p in sorted(set(inputs)):
 b=(root/p).read_bytes();f=out/'read-snapshots'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b);records.append({'path':p,'bytes':len(b),'sha256':sha(b)})
save('input-fingerprints.json',records);save('command-log.json',commands);save('check-results.json',{'checks':checks,'count':len(checks),'findings':[],'blockingConditions':[],'runtimeTestsRunByThisSubrole':False,'independentServerCrosscheckByThisSubrole':False});print(json.dumps({'checksPassed':len(checks),'archiveMembers':len(manifest['rawArtifacts']),'inputs':len(records),'findings':[],'blocking':[]},ensure_ascii=False))
