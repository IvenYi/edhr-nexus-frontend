import pathlib,subprocess,json,hashlib,yaml,datetime,xml.etree.ElementTree as ET
out=pathlib.Path('/tmp/edhr-form-detail-final-qa-20261105');repo=pathlib.Path('/workspace/edhr-nexus-frontend')
base='ea5c57e63cb4980961498c4c192705ef91a37170';head='04fc893f3df9de8d345fa32a7699f61f7cbc53ae'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=repo,text=True)
assert git('rev-parse','HEAD').strip()==head and not git('status','--porcelain')
assert git('merge-base',base,head).strip()==base
assert not git('diff','--name-only','33763f3c76dea3fe8839c5a3a94cdf62978db14b',base)
subprocess.run(['git','fetch','origin','edhr-dev'],cwd=repo,check=True,capture_output=True,text=True)
assert git('rev-parse','origin/edhr-dev').strip()==base
native=json.loads((out/'native/full/test-summary.json').read_text());knowledge=json.loads((out/'knowledge/run.json').read_text())
assert native['totals']=={'tests':167,'failures':0,'errors':0,'skipped':0} and not native['missingFreshReports']
assert knowledge['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0} and knowledge['exitCode']==0
events=[json.loads(s) for s in (out/'native/full/observations.jsonl').read_text().splitlines()]
assert len(events)==29 and sum(e['totalStatements'] for e in events)==298
plans=json.loads((out/'native/full/plan-summary.json').read_text());assert plans['rowDistribution']=='0|35005\n1|30000'
assert [p['originalCandidates'] for p in plans['plans']]==[1,100,5000]
for p in plans['plans']:assert any(n.get('Relation Name')=='user_account' and n['Node Type']=='Seq Scan' for n in p['planNodes'])
child_summaries=[]
for folder,expected_sha in [('evidence-scope','8f11053f1440e740a3a8fd3704fd6c6dd29d30c4c66bac9f3476ab4e3e9ad48b'),('server-sql','ea2ac3ff2a73d30fd359a9ec560493a397fe1fb1e6e7799de1f69d13c3c9c1a1')]:
 p=out/folder;m=json.loads((p/'manifest.json').read_text());assert sha((p/'manifest.json').read_bytes())==expected_sha
 for f in m['artifacts']:
  b=(p/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'],f
 result=yaml.safe_load((p/'result.yaml').read_text())['qualityResult'];assert result['result']=='passed' and result['headCommit']==head and result['baseCommit']==base and not result['findings'] and not result['blockingConditions']
 assert all(c['outcome']=='passed' for c in result['checks'] if c['required'])
 child_summaries.append({'role':folder,'formalStatus':'FINAL','result':'passed','requiredChecks':len([c for c in result['checks'] if c['required']]),'manifestSha256':expected_sha,'rawArtifacts':len(m['artifacts'])})
server=yaml.safe_load((out/'server-sql/result.yaml').read_text())['serverSubitem']
assert server['observerBusinessSelects']==server['serverMatchedBusinessSelects']==298 and server['businessSignatures']==16
assert server['excludedOtherSelects']==84 and server['directoryCalls']==11 and server['directoryLimit']==100 and server['directoryCountQueries']==0 and server['preservedNameArrayCalls']==5
cleanup=json.loads((out/'final-baseline-cleanup.json').read_text());assert cleanup['mainWorkingTreeClean'] and cleanup['ownedDependencySymlinkRemoved'] and cleanup['ownedWorktreeRemoved'] and not cleanup['ownedNativeContainerNamesPresent']
rows=[
 ('check.contract-baseline','documentation','实际来源/目标/契约差异核对，版本号不替代Git提交','inspection','own-inspection.json; read-input-fingerprints.json; final-baseline-cleanup.json'),
 ('check.actual-integration-candidate','requirements','ea目标为04fc祖先，目标整树同PR59交付且最终fetch未变','command','candidate-diff.txt; final-baseline-cleanup.json'),
 ('check.test-only-product-preservation','requirements','仅一测试与本批记录，产品/前端/迁移/索引/依赖/知识/契约不改','inspection','own-inspection.json; evidence-scope/check-results.json'),
 ('check.native167','regression','独立自有worktree/PG原生167，0F/E/S，29观察加138相邻','automated-test','native/full/test-summary.json; native/full/maven.log; native/full/run.json'),
 ('check.knowledge89','ontology','独立正式知识89，0F/E/S，0.3.25/schema1.2.0/P0保持','automated-test','knowledge/run.json; knowledge/maven.log'),
 ('check.form-cache-and-candidate-observations','database','29事件298逻辑SELECT，现存缓存/不同/缺失/空及原候选参数分别核对','inspection','independent-runtime-summary.json; native/full/observations.jsonl'),
 ('check.independent-server-crosscheck','database','另独立29原生，298业务SELECT/16签名、11目录限100无COUNT，排除84其他SELECT','automated-test','server-sql/result.yaml; server-sql/server-sql-summary.json'),
 ('check.controlled-prepared-plans','database','独立重放观察SQL的1/100/5000原候选控制计划，65005账户，非生产SLA','query','native/full/plan-summary.json; native/full/plan-origin-1.sql; native/full/plan-origin-100.sql; native/full/plan-origin-5000.sql'),
 ('check.raw-evidence-integrity','documentation','96原件及本体/输入/保护/当前指纹逐字节SHA核验，原15与167不相加','command','evidence-scope/result.yaml; evidence-scope/check-results.json'),
 ('check.finite-ontology-boundary','ontology','13相关ID为12一致1既有多租户证据缺口，345知识不变，不当全审完成','inspection','evidence-scope/semantic-review.md; evidence-scope/check-results.json'),
 ('check.read-authority-and-history-ownership','security','授权先于姓名，普通数值解析/回退与通用文本匹配区分，历史存储名/签名引用保持','inspection','own-inspection.json; evidence-scope/semantic-review.md; native/full/observations.jsonl'),
 ('check.robustness-and-concrete-split-scope','documentation','A23区分重复计算与写入必要保护，具体私有读方法/纯投影拆分，三性能发现保留open','inspection','evidence-scope/semantic-review.md; own-inspection.json'),
 ('check.all-final-cleanup-final-target','documentation','两个子项正式FINAL，全部自有资源清理，结束目标/候选/源字节保持','inspection','final-baseline-cleanup.json; child-final-status.json')]
checks=[]
for ident,category,desc,method,evidence in rows:
 checks.append({'id':ident,'required':True,'category':category,'description':desc,'method':method,'command':'python3 finalize-quality.py; independent commands and exact source retained in run.json/child outputs','outcome':'passed','evidence':evidence.split('; ')})
(out/'child-final-status.json').write_text(json.dumps({'children':child_summaries,'allFormalFinal':True},ensure_ascii=False,indent=2)+'\n')
risks=[
 ('PERF-FORM-DETAIL-CURRENT-NAMES-20261105','已实测不同或重复缺失处理人1+N，现存重复有一级缓存；本批只取证，仍open','大量当前并行节点时数据库往返增长，非日常规模结论','姓名批量方案等待用户选择；只读证据交付不依赖该可选后续'),
 ('PERF-ORIGIN-CANDIDATE-PARAMETERS-20261105','5000原候选目录5007绑定参数，结果限100，未测试驱动最大边界，仍open','更大集合的参数/解析成本需独立量化','保持原候选和文本身份，另评估数组；不截断候选'),
 ('PERF-ORIGIN-TEXT-ID-PLAN-20261105','65005控制分布重放为Seq Scan，仍open','不能推断全部生产分布或立即新增索引','保留原SQL/参数/索引/计划，先比较真实租户/关键词/排序与写放大'),
 ('gap.full-tenant-and-whole-audit','本体13个ID有1既有完整多租户evidence-gap，931知识候选/86UI及W2-W7/A12/原高风险/完整矩阵继续','有限批次不等于全仓/多租户运行验收','保留原台账及阶段；不将盘点/版本/schema/测试通过视为全部语义一致'),
 ('gap.synthetic-read-and-signature-boundary','表单状态直接持久化，未通过create/START；新匹配历史正例只有APPROVE，RETURN为其他copy排除，777仅签名引用','本批不认证创建/100节点日常容量或真实签名有效性','源码与runtime范围分列；签署完整矩阵保留'),
 ('gap.http-browser-and-production-performance','未执行浏览器/全账号HTTP-JWT/生产延迟吞吐并发或全部迁移验收','不构成上线/生产SLA证明','11项配置迁移及本次服务读取按实际证据说明；无UI/产品改动'),
 ('gap.paused-and-other-performance-queues','朋友任务密码页、生产弹窗暂停；中央JSONCOUNT/汇总605/导出内存等继续','未在本批关闭这些事项','下一批先fetch增量，再按原队列/用户选择小批推进')]
result={'qualityResult':{'result':'passed','baseCommit':base,'headCommit':head,'contractBaseline':{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':head,'uncommittedContractPaths':[]},'workingTreeState':{'status':'clean','includedPaths':[],'excludedPaths':[],'untrackedPaths':[]},'knowledgeBaselineVersion':'0.3.25','checks':checks,'findings':[],'residualRisks':[{'id':i,'description':d,'impact':impact,'mitigation':mitigation} for i,d,impact,mitigation in risks],'blockingConditions':[]},'verificationScope':{'executionLevel':'L2','actualTestedCandidate':head,'targetAtStartAndEnd':base,'nativeTests':167,'formalKnowledgeTests':89,'serverSubrunTests':29,'serverSubrunIsSubsetNotAdditionalUnique':True,'observerBusinessSelects':298,'serverBusinessSignatures':16,'directoryCalls':11,'directoryLimit':100,'directoryCountQueries':0,'excludedOtherServerSelects':84,'preservedSingleArrayNameCalls':5,'productFilesChanged':0,'testFilesChanged':1,'rawPrimaryArtifactsVerified':96,'ontologyFiniteIds':13,'ontologyConsistent':12,'ontologyExistingEvidenceGap':1,'unchangedKnowledgeFiles':345,'wholeAuditComplete':False,'childrenAllFormalFinal':True,'subitems':child_summaries,'environmentAndAnalysisEvents':['Parent native initial missing node_modules caused vite exit127 before tests; fixed only owned environment link and reran exact source','Server child same initial dependency exit127 before tests and post-success only-owned-link dirty assertion; original evidence retained, JUnit29 passed','Evidence child initial analysis script omitted explanation field; original error and corrected analysis retained, no repository edits'],'independentWorktreeDependencyNote':'Only external installed node_modules symlink was untracked while tests ran; removed and worktree verified clean before removal. Candidate source/test/config/knowledge bytes stayed exact; main candidate tree stayed clean.','postQualityAllowedWork':'Only new L0 archive/acceptance/scope/delivery and NEXT status; any product/test/knowledge/contract or target change requires reevaluation'}}
(out/'quality-result.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False,width=110))
(out/'final-summary.json').write_text(json.dumps({'result':'passed','requiredChecks':len(checks),'candidate':head,'target':base,'native167':native['totals'],'knowledge89':knowledge['totals'],'server298Signatures16':True,'allChildrenFinal':True,'resourcesClean':True,'finalizedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()},ensure_ascii=False,indent=2)+'\n')
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).as_posix() not in ('manifest.json','manifest.sha256')]
manifest={'candidate':head,'target':base,'rawArtifactCount':len(files),'artifacts':[{'path':str(p.relative_to(out)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files],'note':'All parent/child originals retained; nested manifest/digest files included; root manifest and its digest excluded to avoid self-reference. Exact source native167 and knowledge89 passed; tooling failures do not become product failures.'}
(out/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n');digest=sha((out/'manifest.json').read_bytes());(out/'manifest.sha256').write_text(digest+'  manifest.json\n')
print(json.dumps({'qualityResult':'passed','requiredChecks':len(checks),'rawArtifacts':len(files),'filesIncludingManifestAndDigest':len(files)+2,'manifestSha256':digest},ensure_ascii=False))
