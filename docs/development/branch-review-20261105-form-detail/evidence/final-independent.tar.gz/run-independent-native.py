import pathlib,subprocess,os,json,time,datetime,hashlib,shutil,sys,xml.etree.ElementTree as ET
root=pathlib.Path('/tmp/edhr-form-detail-qa-native-worktree-20261105');phase=sys.argv[1]
assert phase in ('focused','full')
out=pathlib.Path('/tmp/edhr-form-detail-final-qa-20261105/native')/phase;out.mkdir(exist_ok=False)
name='edhr-form-read-final-qa-'+phase+'-20261105';db='edhr_record_control_test_form_'+phase;created=False
selected=('WorkflowReadObservationPostgresTest#formDetailObservesCurrentNamesAndPersistenceContext+formDetailKeepsStoredHistoryAndDoesNotReadNamesForHistoricalTasks+unauthorizedFormDetailStopsBeforeNameReads+originalCandidateDirectoryObservesParameterGrowth' if phase=='focused' else 'WorkflowReadObservationPostgresTest,RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest')
def run(args,**kw):return subprocess.run(args,check=True,capture_output=True,text=True,**kw).stdout.strip()
try:
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine','-c','log_min_duration_statement=0','-c','log_parameter_max_length=-1']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('own PG not ready')
 run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE ROLE edhr LOGIN'])
 run(['docker','exec',name,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
 run(['docker','exec',name,'createdb','-U','postgres','edhr_workflow_read_test_'+phase])
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name])
 env=os.environ.copy();env.update(RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',PGUSER='postgres',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test',W3_TRANSFER_DATABASE_USER='postgres',W3_TRANSFER_DATABASE_PASSWORD='',WORKFLOW_READ_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_workflow_read_test_'+phase)
 command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dedhr.audit.workflowReads=true','-Dedhr.audit.workflowReadOutput='+str(out/'observations.jsonl'),'-Dtest='+selected,'test'];start=datetime.datetime.now(datetime.timezone.utc)
 source=[]
 for path in ['gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowOperationsQuery.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/test/java/com/zencas/edhr/workflow/service/WorkflowReadObservationPostgresTest.java']:
  b=(root/path).read_bytes();source.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()});d=out/'source'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 with (out/'maven.log').open('w') as f:result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
 meta={'command':command,'cwd':str(root),'commit':run(['git','rev-parse','HEAD'],cwd=root),'started':start.isoformat(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'sourceFingerprints':source,'containerId':cid,'postgres':run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'])}
 (out/'run.json').write_text(json.dumps(meta,indent=2)+'\n')
 totals={k:0 for k in ('tests','failures','errors','skipped')};classes=[];missing=[]
 for test in selected.split(','):
  test=test.split('#')[0];files=[p for p in (root/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.'+test+'.xml') if p.stat().st_mtime>=start.timestamp()]
  if not files:missing.append(test)
  for p in files:
   shutil.copy2(p,out/p.name);doc=ET.parse(p).getroot();c={k:int(doc.attrib.get(k,0)) for k in totals};classes.append({'class':doc.attrib['name'],**c})
   for k in totals:totals[k]+=c[k]
 summary={'totals':totals,'classes':classes,'missingFreshReports':missing};(out/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary));print((out/'maven.log').read_text()[-2400:])
 code=0 if not missing and result.returncode==0 and totals=={'tests':15 if phase=='focused' else 167,'failures':0,'errors':0,'skipped':0} else 1
 if phase=='full' and code==0:
  plan=subprocess.run(['python3','/tmp/edhr-form-detail-final-qa-20261105/probe-plans.py',str(out),name],capture_output=True,text=True)
  (out/'plan-probe.log').write_text(plan.stdout+plan.stderr)
  if plan.returncode:print('plan probe failed; native result preserved',plan.stderr);code=1
finally:
 if created:
  logs=subprocess.run(['docker','logs',name],capture_output=True,text=True);(out/'postgres.log').write_text(logs.stdout+logs.stderr)
  stopped=run(['docker','stop',name]);removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0:removed=True;break
   time.sleep(.1)
  (out/'cleanup.json').write_text(json.dumps({'ownedName':name,'stopOutput':stopped,'removed':removed},indent=2)+'\n');print('owned cleanup',removed)
sys.exit(code)
