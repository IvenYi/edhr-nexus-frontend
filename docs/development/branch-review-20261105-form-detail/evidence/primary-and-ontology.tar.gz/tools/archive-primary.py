import pathlib,tarfile,json,hashlib
r=pathlib.Path('/workspace/edhr-nexus-frontend');p=r/'docs/development/branch-review-20261105-form-detail';tmp=pathlib.Path('/tmp/edhr-form-read-20261105');onto=pathlib.Path('/tmp/edhr-form-detail-ontology-20261105')
def sha(b):return hashlib.sha256(b).hexdigest()
items=[]
for folder,prefix in [(tmp/'baseline','baseline'),(tmp/'focused','primary/focused'),(tmp/'full','primary/full'),(onto,'ontology')]:
 for f in sorted(folder.rglob('*')):
  if f.is_file():items.append((f,prefix+'/'+str(f.relative_to(folder))))
for name in ['run-native.py','probe-plans.py','archive-primary.py']:
 items.append((tmp/name,'tools/'+name))
raw=[{'member':name,'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())} for f,name in items]
(p/'evidence').mkdir(exist_ok=True);a=p/'evidence/primary-and-ontology.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f,name in items:t.add(f,arcname=name,recursive=False)
x={'baseCommit':'ea5c57e63cb4980961498c4c192705ef91a37170','rawArtifacts':raw,'archive':{'path':'evidence/primary-and-ontology.tar.gz','bytes':a.stat().st_size,'sha256':sha(a.read_bytes())},'note':'Main focused15 and full167 evidence are separate, not additive; full configured migration graph11, 29 observations298 logical SELECT; all source snapshots/raw PG/controlled plan replay retained. Ontology43 originals plus manifest/digest45; not QA89/native/browser.'}
(p/'evidence-manifest.json').write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'rawArtifacts':len(raw),'archive':x['archive']},ensure_ascii=False))
