# 本体有限核对范围

实际基线 ea5c57e63cb4980961498c4c192705ef91a37170；PR59合入树同33763f3c，无额外产品或知识增量。本角色只读，不修改仓库，不创建子角色，不运行Maven/89/原生PG/浏览器。所有运行结论由主审及全新独立QA各自执行。

13相关ID为12 consistent、1既有完整多租户 evidence-gap；并非全仓或931候选逐条审完。345知识和13完整产品源文件逐字节未变；不因测试源码或既有成熟度自动升级规则。

普通表单当前待处理节点的 assigneeName 读取当前账户目录，blank显示“候选人待处理”、缺失返回原ID；Long.valueOf 读取路径与通用工作流的原文本ID匹配不同。APPROVE/RETURN历史姓名、意见和signatureId来自匹配history，不能替换为当前姓名。通用WorkflowOperationsQuery的当前任务和日志目录行为有各自回退，不能按字段同名抽公共方法。

@Transactional只读代理和JPA findById可能受一级缓存影响；源码不直接证明真实SQL次数。主审的并行原生取证未在本角色结果生成时引用为已通过，也不由局部name调用确认生产延迟或日常规模。大原候选IN和5000匹配目录是不同规模维度；保留原候选/申请人回避和100限量，不能为性能放宽目标。

本批不引入性能优化、表达式索引、全局缓存、数据恢复或客户政策。W2-W7、931知识候选、86旧UI诊断及完整账号/收件人/ACL并发/签署矩阵继续；朋友任务密码页和生产管理弹窗仍暂停。P0 in-progress、schema1.2.0、0.3.25不变。

只读检索曾猜测不存在的rules/workflow.yaml、evidence/workflow-operations.yaml和rules/record-control*.yaml，rg退出2后通过rg --files定位实际workflow-central-entry.yaml、workflow-operations-20261030.yaml及production.yaml。该检索诊断非产品、JUnit或知识校验失败；未据此修改任何仓库文件。源内容读取的长输出截断已按段继续读取，原输入字节均保存在read-snapshots。仓库测试由主审并行编辑，不列入本角色“产品保持”或当前测试验收声明。
