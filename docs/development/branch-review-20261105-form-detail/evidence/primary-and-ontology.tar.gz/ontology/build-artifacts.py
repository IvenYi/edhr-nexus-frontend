from pathlib import Path
import subprocess, json, hashlib, datetime, yaml, collections

ROOT = Path('/workspace/edhr-nexus-frontend')
OUT = Path('/tmp/edhr-form-detail-ontology-20261105')
BASE = 'ea5c57e63cb4980961498c4c192705ef91a37170'
OUT.mkdir(exist_ok=False)
log = []
def cmd(args):
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
    log.append({'argv': args, 'exitCode': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr})
    if p.returncode: raise RuntimeError(str(args))
    return p.stdout
def sha(b): return hashlib.sha256(b).hexdigest()
def put(name, value):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
def snap(path):
    data = (ROOT / path).read_bytes()
    p = OUT / 'read-snapshots' / path; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(data)
    return {'path': path, 'bytes': len(data), 'sha256': sha(data)}

head = cmd(['git','rev-parse','HEAD']).strip()
target = cmd(['git','rev-parse','origin/edhr-dev']).strip()
assert head == BASE and target == BASE
remote = cmd(['git','ls-remote','origin','refs/heads/edhr-dev']).split()[0]
assert remote == BASE
assert cmd(['git','diff','--name-only', '33763f3c76dea3fe8839c5a3a94cdf62978db14b', BASE]).strip() == ''
contracts = ['AGENTS.md','codeplzreadme.md','docs/agents/agent-handoff-contract.md','docs/agents/business-knowledge-modeler.md','docs/agents/quality-verifier.md']
contract_checks = []
for path in contracts:
    current = (ROOT/path).read_bytes(); original = subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
    assert current == original
    contract_checks.append({'path':path,'bytes':len(current),'sha256':sha(current),'sameAsReadCommit':True})
knowledge_paths = [p for p in cmd(['git','ls-tree','-r','--name-only',BASE,'docs/knowledge']).splitlines() if (ROOT/p).is_file()]
knowledge_checks=[]
for path in knowledge_paths:
    current=(ROOT/path).read_bytes(); original=subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
    assert current==original,path
    knowledge_checks.append({'path':path,'bytes':len(current),'sha256':sha(current),'baselineSha256':sha(original),'unchanged':True})
schema=yaml.safe_load((ROOT/'docs/knowledge/schema.yaml').read_text())
assert schema['knowledgeModelVersion']=='0.3.25' and schema['schemaVersion']=='1.2.0'
assert len(knowledge_checks)==345,len(knowledge_checks)
decision_path='docs/development/branch-review-20261105-form-detail/decision-package.yaml'
package=yaml.safe_load((ROOT/decision_path).read_text())['decisionPackage']
assert package['contractBaseline']['sourceCommit']==BASE and package['contractBaseline']['targetCommit']==BASE
assert package['contractBaseline']['contractReadCommit']==BASE and package['contractBaseline']['uncommittedContractPaths']==[]
assert package['confirmed']=={'concepts':[],'relationships':[],'rules':[],'executionContracts':[]} and not package['unresolved'] and not package['replacementScopes']
required=['directImpacts','transitiveImpacts','potentialImpacts','unaffectedAreas','compatibilityAndMigration','snapshotImpacts','auditImpacts','permissionImpacts','testImpacts','evidenceGaps']
assert all(k in package['impactAnalysis'] for k in required)
assert package['impactAnalysis']['level']=='L2' and package['extensionStrategy']['selectedPaths']==['product-core']

documents = [
 'docs/architecture/business-knowledge-model.md','docs/knowledge/README.md','docs/knowledge/open-questions.yaml',
 'docs/knowledge/schema.yaml','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml',
 'docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml',
 'docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml',
 'docs/knowledge/rules/identity.yaml','docs/knowledge/rules/workflow-central-entry.yaml',
 'docs/knowledge/evidence/central-form-dhr-workflow-20261102.yaml','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md',
 'docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/knowledge/implementation-anchors/workflow-operations.yaml',
 decision_path]
production='gmp-platform/backend/src/main/java/com/zencas/edhr/'
protected = [production+p for p in [
 'production/service/FormWorkflowOperations.java','workflow/service/WorkflowOperationsQuery.java',
 'workflow/service/WorkflowResponsibilityService.java','identity/service/TenantTransferTargets.java',
 'identity/repository/UserAccountRepository.java','identity/entity/UserAccount.java',
 'production/service/ExecutionAccess.java','production/service/ProductionExecutionEngine.java',
 'workflow/engine/WorkflowEngine.java','workflow/controller/WorkflowOperationsController.java',
 'production/service/DhrReviewService.java','recordcontrol/service/RecordControlService.java',
 'compliance/controller/SignatureController.java']]
protections=[]
for path in protected:
    b=(ROOT/path).read_bytes(); old=subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT);assert b==old,path
    protections.append({'path':path,'bytes':len(b),'sha256':sha(b),'baselineSha256':sha(old),'unchanged':True})
inputs=[snap(path) for path in contracts+documents+protected]

all_records={}
def walk(value,path):
    if isinstance(value,dict):
        if isinstance(value.get('id'),str):
            assert value['id'] not in all_records,value['id'];all_records[value['id']]=(path,value)
        for v in value.values():walk(v,path)
    elif isinstance(value,list):
        for v in value:walk(v,path)
for path in knowledge_paths:
    if path.endswith('.yaml') and path!='docs/knowledge/schema.yaml':walk(yaml.safe_load((ROOT/path).read_text()),path)

form=production+'production/service/FormWorkflowOperations.java'
resp=production+'workflow/service/WorkflowResponsibilityService.java'
directory=production+'identity/service/TenantTransferTargets.java'
ops=production+'workflow/service/WorkflowOperationsQuery.java'
controller=production+'workflow/controller/WorkflowOperationsController.java'
access=production+'production/service/ExecutionAccess.java'
engine=production+'production/service/ProductionExecutionEngine.java'
generic=production+'workflow/engine/WorkflowEngine.java'
reviews = [
 ('DEC-0081-01','decisionStatement','同租户正常用户的本人转办与管理员改派不同；本批只读观察不缩小本人转办到原候选。',[access+'#transferTargets/requireTransferTarget',engine+'#transferForm',directory+'#search/require']),
 ('DEC-0081-02','decisionStatement','普通表单冻结approvers/restrictedApprovers与节点配置，当前transferAssignees另存；通用originSnapshot原文本保留，目录取证不得重算或回填来源。',[access+'#captureApprovers/canAct',engine+'#transferForm',generic+'#singleUserSnapshot',resp+'#targets/eligible']),
 ('DEC-0081-03','decisionStatement','转办只改变当前责任；原节点/内容/结果保持，普通表单history与生产事务所有权不迁移。本批只读无写入。',[engine+'#transferForm',form+'#detail/reassign']),
 ('DEC-0092-01','decisionStatement','集中流程日志读取现有实例和运行历史；form前缀将详情路由到普通表单原生投影，不另建列表或运行任务。',[controller+'#detail',ops+'#list',form+'#source/detail']),
 ('DEC-0092-02','decisionStatement','记录控制目标仍在原冻结候选内并排除申请人；原候选IN参数增大不能作为放宽、截断候选或改为全租户的依据。',[resp+'#targets/eligible',directory+'#search']),
 ('DEC-0092-03','decisionStatement','管理员改派签名、专门权限、原因及状态保护保持；只读性能调查不删除提交时再次核验。',[resp+'#change',form+'#reassign/requireActive']),
 ('DEC-0093-01','decisionStatement','普通表单和DHR进入集中按权只读详情；菜单及读取不授予审批、填报或改派权。本批form观察不扩展DHR或作业整体范围。',[controller+'#detail',form+'#visibility/detail',ops+'#detail/visibility']),
 ('DEC-0093-02','decisionStatement','当前未处理审批责任可管理员签名改派；DHR本人转办仍禁。原候选、表单内容、冻结版与已有签名不因本批只读观察改变。',[form+'#targets/reassign/requireActive',resp+'#reassignmentTargets/change/requireActive']),
 ('DEC-0093-03','decisionStatement','普通表单当前待办姓名来自name当前目录；APPROVE/RETURN及日志的姓名和signatureId来自匹配state.history。后者不被当前目录名替换，责任变更另写领域审计。此处是实际工程来源核对，不把目录展示提升为新签署政策。',[form+'#detail/name/matches/reassign']),
 ('DEC-0093-04','decisionStatement','持久化form_instance_record、production_execution快照/状态及结构化历史为原生来源；任务投影不落第二套workflow_task。姓名回退和SQL写法属于实现选择，查询取证不提升完整多租户或发布成熟度。',[form+'#FROM/context/detail',controller+'#detail']),
 ('rule.workflow-central-entry.domain-projection','rule','既有领域事实投影与读取权限定义在本批范围一致；不把固定源码与测试存在当全运行矩阵通过。',[form+'#source/detail/visibility',ops+'#list',controller+'#detail']),
 ('rule.workflow.task-creation-freezes-candidate-resolution','rule','大原候选参数观察消费原candidateSnapshot/originSnapshot而非当前组织；保留创建来源不等于旧候选继续有委托后处理权。',[resp+'#targets/eligible',generic+'#singleUserSnapshot']),
 ('question.multi-tenant-workflow-isolation','question','既有完整多租户契约缺口保持；本批目录同租户资格和default普通表单读取不能证明工作流全域隔离。',[form+'#FROM',directory+'#search/require',resp+'#tenant'])
]
rows=[]
for id,kind,meaning,refs in reviews:
    path,record=all_records[id]
    text=(ROOT/path).read_text();lines=text.splitlines();line=next(i+1 for i,s in enumerate(lines) if s.strip() in ('- id: '+id,'id: '+id))
    gap=kind=='question'
    rows.append({'id':id,'recordType':kind,'sourcePath':path,'sourceLocator':f'{path}:{line}',
       'sourceCommit':BASE,'originalMaturity':record.get('status','open-question'),'originalVisibility':record.get('visibility'),
       'auditScope':'finite current ordinary-form read and original-candidate evidence batch',
       'reviewStatus':'reviewed','conclusion':'evidence-gap' if gap else 'consistent',
       'reviewedMeaning':meaning,'originalStatement':record.get('statement',record.get('explanation',record.get('question'))),
       'originalEvidenceReferences':refs,'runtimeValidationByThisRole':False,'knowledgeDisposition':'deferred' if gap else 'retained'})
assert len(rows)==13 and sum(x['conclusion']=='consistent' for x in rows)==12
put('semantic-audit.json',{'baseline':BASE,'scope':'finite related IDs only','counts':{'reviewed':13,'consistent':12,'evidenceGap':1},'records':rows,'fullSemanticAuditComplete':False})
put('source-fingerprints.json',inputs)
put('knowledge-unchanged.json',{'baseline':BASE,'files':len(knowledge_checks),'allUnchanged':True,'records':knowledge_checks})
put('protected-source-unchanged.json',{'baseline':BASE,'fullFilesChecked':len(protections),'allUnchanged':True,'records':protections})
put('contract-baseline.json',{'sourceCommit':head,'targetBranch':'edhr-dev','targetCommit':target,'remoteTargetObserved':remote,'contractReadCommit':BASE,'uncommittedContractPaths':[],'contracts':contract_checks})
put('validation.json',{'checks':[
 {'id':'knowledge-baseline','outcome':'passed','version':schema['knowledgeModelVersion'],'schemaVersion':schema['schemaVersion']},
 {'id':'current-knowledge-byte-preservation','outcome':'passed','files':len(knowledge_checks)},
 {'id':'current-protected-source-preservation','outcome':'passed','fullFiles':len(protections)},
 {'id':'decision-package-scope','outcome':'passed','confirmed':'empty','unresolved':'empty','inferred':'not promoted'},
 {'id':'finite-id-resolution-and-semantic-review','outcome':'passed','reviewed':13,'consistent':12,'evidenceGap':1},
 {'id':'contract-and-remote-baseline','outcome':'passed','base':BASE}],
 'executedFormalKnowledgeTests':False,'executedNativeTests':False,'executedBrowserTests':False,
 'knowledgeRoadmap':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[]},
 'notClaimed':['full semantic audit','production SLA','all-user HTTP/JWT/browser','complete tenant isolation','new performance policy','whole-file completion'],
 'pendingContext':{'knowledgeIncrementCandidates':931,'oldUiDiagnosticCandidates':86,'W2throughW7':'retained','pausedUserScopes':['friend-owned workflow task password page','production-management dialog']}})
ontology={'ontologyResult':{'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':BASE,'targetBranch':'edhr-dev','targetCommit':BASE,'contractReadCommit':BASE,'uncommittedContractPaths':[]},
 'reason':'本批仅新增普通表单详情及原候选集合的显式opt-in性能/来源取证，当前产品、权限、原候选、签署、历史及冻结字节保持；没有新确认业务政策、规则或替代声明。有限13个相关ID核对为12一致和1保留既有完整多租户证据缺口，不改变成熟度或知识阶段。',
 'changedArtifacts':[],'knowledgeSync':[],'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.form-read.contract-baseline','checkType':'reference','command':'python3 /tmp/edhr-form-detail-ontology-build-20261105.py','outcome':'passed','evidence':['contract-baseline.json：实际来源/目标/契约读取ea5c57e6，5契约未变；remote target相同']},
  {'id':'validation.form-read.knowledge-preservation','checkType':'evidence-path','command':'python3 /tmp/edhr-form-detail-ontology-build-20261105.py','outcome':'passed','evidence':['knowledge-unchanged.json：345文件逐字节与baseline一致；schema1.2.0/0.3.25']},
  {'id':'validation.form-read.source-ownership','checkType':'projection','command':'source inspection and baseline byte comparison','outcome':'passed','evidence':['semantic-audit.json：13真实ID逐项依据；12consistent/1既有evidence-gap','protected-source-unchanged.json：13完整源文件不变','source-fingerprints.json及read-snapshots：32个实际输入原件；当前目录名与历史签署来源分开']}],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}}}
assert len(inputs)==32,len(inputs)
(OUT/'ontology-result.yaml').write_text(yaml.safe_dump(ontology,allow_unicode=True,sort_keys=False))
(OUT/'scope-notes.md').write_text('''# 本体有限核对范围

实际基线 ea5c57e63cb4980961498c4c192705ef91a37170；PR59合入树同33763f3c，无额外产品或知识增量。本角色只读，不修改仓库，不创建子角色，不运行Maven/89/原生PG/浏览器。所有运行结论由主审及全新独立QA各自执行。

13相关ID为12 consistent、1既有完整多租户 evidence-gap；并非全仓或931候选逐条审完。345知识和13完整产品源文件逐字节未变；不因测试源码或既有成熟度自动升级规则。

普通表单当前待处理节点的 assigneeName 读取当前账户目录，blank显示“候选人待处理”、缺失返回原ID；Long.valueOf 读取路径与通用工作流的原文本ID匹配不同。APPROVE/RETURN历史姓名、意见和signatureId来自匹配history，不能替换为当前姓名。通用WorkflowOperationsQuery的当前任务和日志目录行为有各自回退，不能按字段同名抽公共方法。

@Transactional只读代理和JPA findById可能受一级缓存影响；源码不直接证明真实SQL次数。主审的并行原生取证未在本角色结果生成时引用为已通过，也不由局部name调用确认生产延迟或日常规模。大原候选IN和5000匹配目录是不同规模维度；保留原候选/申请人回避和100限量，不能为性能放宽目标。

本批不引入性能优化、表达式索引、全局缓存、数据恢复或客户政策。W2-W7、931知识候选、86旧UI诊断及完整账号/收件人/ACL并发/签署矩阵继续；朋友任务密码页和生产管理弹窗仍暂停。P0 in-progress、schema1.2.0、0.3.25不变。

只读检索曾猜测不存在的rules/workflow.yaml、evidence/workflow-operations.yaml和rules/record-control*.yaml，rg退出2后通过rg --files定位实际workflow-central-entry.yaml、workflow-operations-20261030.yaml及production.yaml。该检索诊断非产品、JUnit或知识校验失败；未据此修改任何仓库文件。源内容读取的长输出截断已按段继续读取，原输入字节均保存在read-snapshots。仓库测试由主审并行编辑，不列入本角色“产品保持”或当前测试验收声明。
''')
put('resource-cleanup.json',{'createdContainers':[],'createdWorktrees':[],'createdSymlinks':[],'spawnedChildren':[],'repositoryPathsModifiedByRole':[],'ownedArtifacts':'this /tmp directory only; retained for parent archive'})
put('command-log.json',log)
(OUT/'build-artifacts.py').write_bytes(Path(__file__).read_bytes())
files=[]
for p in sorted(OUT.rglob('*')):
    if p.is_file():files.append({'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())})
put('manifest.json',{'baseline':BASE,'rawArtifactCount':len(files),'artifacts':files,'excludes':['manifest.json','manifest.sha256']})
(OUT/'manifest.sha256').write_text(sha((OUT/'manifest.json').read_bytes())+'  manifest.json\n')
print(json.dumps({'result':'not-applicable','reviewedIds':13,'consistentIds':12,'existingEvidenceGap':1,'knowledgeUnchanged':345,'protectedFullSources':13,'inputSnapshots':len(inputs),'rawArtifacts':len(files),'manifestSha256':sha((OUT/'manifest.json').read_bytes())},ensure_ascii=False))
