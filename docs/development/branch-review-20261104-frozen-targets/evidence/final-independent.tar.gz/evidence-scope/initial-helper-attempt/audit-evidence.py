import pathlib,subprocess,json,hashlib,tarfile,yaml,xml.etree.ElementTree as ET,datetime
root=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-frozen-targets-final-qa-20261104/evidence-scope')
batch=root/'docs/development/branch-review-20261104-frozen-targets'
base='c0a9d5ac33690d10d009e768c286671475db0943';candidate='2e2cde63d1a247942e94b8e5b941f6c1e174b6db'
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
def store(name,x):(out/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def check(name,details):checks.append({'id':name,'outcome':'passed','details':details})
assert git('rev-parse','HEAD').decode().strip()==candidate
assert git('rev-parse','origin/edhr-dev').decode().strip()==base
assert not git('status','--porcelain=v1')
assert not git('diff','--name-only',base,candidate,'--','AGENTS.md','docs/agents','docs/knowledge')
store('baseline.json',{'base':base,'head':candidate,'contractReadCommit':candidate,'targetRef':base,'clean':True,'contractAndKnowledgeDelta':[],'observedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
check('baseline-and-contract',{'base':base,'candidate':candidate,'clean':True})
m=json.loads((batch/'evidence-manifest.json').read_text());archive=batch/m['archive']['path'];ab=archive.read_bytes()
assert len(ab)==m['archive']['bytes'] and sha(ab)==m['archive']['sha256']
t=tarfile.open(archive);members=t.getmembers();assert all(x.isfile() for x in members)
assert len(members)==len({x.name for x in members})==len(m['rawArtifacts'])==93
raw={x.name:t.extractfile(x).read() for x in members}
assert set(raw)=={x['member'] for x in m['rawArtifacts']}
for f in m['rawArtifacts']:assert len(raw[f['member']])==f['bytes'] and sha(raw[f['member']])==f['sha256'],f['member']
store('archive-member-verification.json',{'archive':m['archive'],'rawMemberCount':len(raw),'allExactBytesVerified':True,'members':m['rawArtifacts']})
check('primary-archive-bytes',{'rawMembers':93,'archiveBytes':len(ab),'archiveSha256':sha(ab)})
for prefix,count,digest in [('ontology',61,'270a61b7e7dfdf90fd752b92a8c017fb40305bf25a06693a154b981f3a412f69'),('ontology/policy-readonly',23,'b592e7a4450c954e82fa31b358db7d9f25f4084af37c6c270d30674c3f236773')]:
 mb=raw[prefix+'/manifest.json'];nm=json.loads(mb);assert sha(mb)==digest and nm['artifactCount']==len(nm['artifacts'])==count and nm['status']=='FINAL'
 for f in nm['artifacts']:
  b=raw[prefix+'/'+f['path']];assert len(b)==f['bytes'] and sha(b)==f['sha256'],f['path']
 check('nested-manifest-'+prefix,{'rawArtifacts':count,'manifestSha256':digest})
om=yaml.safe_load(raw['ontology/ontology-result.yaml']);assert om==yaml.safe_load((batch/'ontology-result.yaml').read_text())
assert om['ontologyResult']['result']=='not-applicable' and om['verificationScope']['status']=='FINAL'
assert om['ontologyResult']['baselineBefore']==om['ontologyResult']['baselineAfter']=='0.3.25'
assert len(om['ontologyResult']['knowledgeSync'])==om['verificationScope']['finiteExistingIdsReviewed']==19
receipt=json.loads(raw['ontology/child-final-receipt.json']);assert receipt['status']=='FINAL' and receipt['result']=='passed'
child=yaml.safe_load(raw['ontology/policy-readonly/result.yaml']);assert 'FINAL' in str(child) and 'passed' in str(child)
check('ontology-and-child-results',{'result':'not-applicable','finiteRelatedIds':19,'childOverlappingStatements':15,'knowledgeVersion':'0.3.25','noSemanticUpdate':True})
sr=json.loads((batch/'source-review.json').read_text());assert len(sr['sourceFingerprints'])==9
for f in sr['sourceFingerprints']:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
check('main-current-source-fingerprints',{'currentPaths':9})
sf=json.loads(raw['ontology/source-fingerprints.json'])['sourceFingerprints'];assert len(sf)==23
for f in sf:
 b=(root/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256'];assert b==raw['ontology/read-snapshot/'+f['path']]
check('ontology-current-source-fingerprints',{'currentPaths':23})
pf=json.loads(raw['ontology/policy-readonly/source-fingerprints.json']);policies=pf['files'];assert len(policies)==21
for f in policies:
 b=git('show',f['baselineCommit']+':'+f['path']);assert len(b)==f['bytes'] and sha(b)==f['sha256']
check('policy-baseline-fingerprints',{'fixedBaselinePaths':21,'note':'Old product fingerprints verified against c0, not current changed product bytes.'})
guards=json.loads(raw['ontology/guard-byte-equivalence.json'])['comparisons'];assert len(guards)==6
for f in guards:
 old=git('show',base+':'+f['path']).decode();new=(root/f['path']).read_text()
 def region(s):
  if f['scope']=='whole-file-byte-comparison-only':return s.encode()
  begin=s.index(f['scope']);end=s.index(f['endExclusive'],begin) if f['endExclusive'] else len(s)
  return s[begin:end].encode()
 b=region(new);assert b==region(old) and len(b)==f['bytes'] and sha(b)==f['sha256'] and f['equal']
check('six-write-and-adjacent-byte-regions',{'regions':6,'exact':True})
kb=json.loads(raw['ontology/knowledge-byte-check.json']);kpaths=[p for p in git('ls-tree','-r','--name-only','-z',base,'--','docs/knowledge').decode().split('\0') if p]
assert kb['files']==len(kb['paths'])==len(kpaths)==345 and kb['allUnchanged']
assert set(kpaths)=={f['path'] for f in kb['paths']}
for f in kb['paths']:
 b=(root/f['path']).read_bytes();assert b==git('show',base+':'+f['path']) and sha(b)==f['sha256'] and len(b)==f['bytes'] and f['sameAsBase']
check('345-knowledge-byte-preservation',{'files':345})
for color,expected,exitcode in [('red',{'tests':8,'failures':7,'errors':0,'skipped':0},1),('green',{'tests':138,'failures':0,'errors':0,'skipped':0},0)]:
 prefix='primary/'+color;run=json.loads(raw[prefix+'/run.json']);summary=json.loads(raw[prefix+'/test-summary.json'])
 assert run['sourceCommit']==base and run['exitCode']==exitcode and summary['totals']==expected and not summary['missingFreshReports']
 reports=[];totals={k:0 for k in expected}
 for path,b in raw.items():
  if path.startswith(prefix+'/TEST-') and path.endswith('.xml'):
   xml=ET.fromstring(b);classes={'name':xml.attrib['name']};classes.update({k:int(xml.attrib.get(k,0)) for k in expected});reports.append(classes)
   for k in expected:totals[k]+=classes[k]
 assert totals==expected and len(reports)==(1 if color=='red' else 9)
 for f in run['sourceFingerprints']:
  b=raw[prefix+'/source-snapshot/'+f['path']];assert len(b)==f['bytes'] and sha(b)==f['sha256']
  if color=='red' and '/src/main/' in f['path']:assert b==git('show',base+':'+f['path'])
  else:assert b==(root/f['path']).read_bytes()
 cleanup=json.loads(raw[prefix+'/cleanup.json']);assert cleanup['removed']
 log=raw[prefix+'/maven.log'].decode();assert 'Liquibase: Update has been successful' in log
 check('main-'+color+'-reports-and-provenance',{'totals':totals,'classes':reports,'exitCode':run['exitCode'],'sourceHead':run['sourceCommit'],'ownedCleanup':True,'configuredLiquibaseExecuted':True})
red=ET.fromstring(raw['primary/red/TEST-com.zencas.edhr.recordcontrol.service.RecordControlPostgresIntegrationTest.xml'])
cases=[]
for tc in red.findall('testcase'):
 failures=tc.findall('failure');errors=tc.findall('error');assert not errors
 cases.append({'name':tc.attrib['name'],'failures':len(failures),'failureType':failures[0].attrib.get('type') if failures else None,'messagePrefix':failures[0].attrib.get('message','')[:250] if failures else None})
assert len(cases)==8 and sum(c['failures'] for c in cases)==7
assert [c['name'] for c in cases if not c['failures']]==['emptyFrozenCandidatesDoNotBecomeUnrestricted']
assert all(c['failureType'] in ('java.lang.AssertionError','org.opentest4j.AssertionFailedError') for c in cases if c['failures'])
store('main-original-xml-case-verification.json',cases)
check('seven-real-old-source-assertions-one-positive',{'cases':8,'realFailures':7,'emptyCandidatePositive':1,'errors':0,'skipped':0})
ks=json.loads(raw['ontology/knowledge-test-summary.json']);kx=ET.fromstring(raw['ontology/surefire/TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml'])
kt={k:int(kx.attrib[k]) for k in ['tests','failures','errors','skipped']};assert kt==ks['totals']=={'tests':89,'failures':0,'errors':0,'skipped':0}
check('ontology-formal-knowledge-original-89',{'totals':kt,'notExecutedByThisSubrole':True})
finite=json.loads(raw['ontology/finite-id-review.json'])['records'];assert len(finite)==len({f['id'] for f in finite})==19
for f in finite:
 data=yaml.safe_load((root/f['sourcePath']).read_text());v=data
 for step in f['sourceLocator'].strip('/').split('/'):v=v[int(step)] if isinstance(v,list) else v[step]
 assert v['id']==f['id'] and f['semanticStatus']=='reviewed'
check('finite-related-id-locators',{'uniqueIds':19,'wholeKnowledgeComplete':False})
bv=json.loads((batch/'baseline-review.json').read_text());paths=[x for x in git('ls-tree','-r','--name-only','-z',base).decode().split('\0') if x]
assert len(paths)==bv['targetTrackedPaths']==7420 and sha('\0'.join(paths).encode())==bv['targetPathListSha256']
assert not git('diff','--name-only','e284dd6b66940120f0f03a475c1a266205f2b694',base)
assert git('diff','--name-status','7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37',base).decode().splitlines()==bv['priorInventoryToCurrentChanges']
oldpaths=[x for x in git('ls-tree','-r','--name-only','-z','7c2c74d0a9f6b30c6e2dfbd9ad1620d5d29f9a37').decode().split('\0') if x];assert len(oldpaths)==7402
assert bv['pendingKnowledgeIncrementCandidates']==931 and bv['pendingUiDiagnosticCandidates']==86 and bv['wholeFileComplete']==0 and bv['historicalUniqueCoverage'] is None
check('baseline-inventory-and-pending-accounting',{'fixedTargetPaths':7420,'priorInventoryPaths':7402,'targetEqualsPreviousDelivery':True,'pendingKnowledge':931,'pendingUi':86,'wholeFileComplete':0,'historicalUniqueCoverage':None})
changed=[x for x in git('diff','--name-only','-z',base,candidate).decode().split('\0') if x]
product=[x for x in changed if x.startswith('gmp-platform/backend/src/main/')];tests=[x for x in changed if x.startswith('gmp-platform/backend/src/test/')]
assert len(product)==2 and len(tests)==1
assert not any(x.startswith('gmp-platform/frontend/') or '/db/' in x for x in changed)
check('two-product-one-test-no-ui-migration-delta',{'product':product,'tests':tests,'frontendOrMigrationChanged':False})
prefix='docs/development/branch-review-20261104-frozen-targets/'
for p in ['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md',prefix+'decision-package.yaml',prefix+'README.md',prefix+'review-notes.md',prefix+'baseline-review.json',prefix+'source-review.json',prefix+'ontology-result.yaml',prefix+'evidence-manifest.json','docs/knowledge/decisions/DEC-0081-tenant-scoped-task-delegation.yaml','docs/knowledge/decisions/DEC-0092-workflow-operations-entry-and-actions.yaml','docs/knowledge/decisions/DEC-0093-central-form-dhr-workflow-responsibility.yaml','docs/knowledge/evidence/workflow-operations-20261030.md','docs/knowledge/evidence/tenant-task-delegation-2026-10-20.md','docs/knowledge/evidence/central-form-dhr-workflow-20261102.md']:
 target=out/'read-sources'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((root/p).read_bytes())
assert git('rev-parse','HEAD').decode().strip()==candidate and not git('status','--porcelain=v1')
check('repository-remains-clean',{'head':candidate,'clean':True,'testOrBrowserRunByThisRole':False})
store('checks.json',{'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failed':[],'result':'passed','note':'Mechanical original provenance checks only; finite policy/scope inspection is recorded separately. No test/browser execution by this subrole.'})
print(json.dumps({'passedChecks':len(checks),'rawArchiveMembers':len(raw),'result':'passed','head':candidate},ensure_ascii=False))
