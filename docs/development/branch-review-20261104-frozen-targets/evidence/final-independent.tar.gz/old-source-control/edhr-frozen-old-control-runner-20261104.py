import pathlib,subprocess,json,os,time,hashlib,shutil,datetime,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend')
out=pathlib.Path('/tmp/edhr-frozen-targets-final-qa-20261104/old-source-control');out.mkdir(parents=True,exist_ok=True)
attempt=out/'attempt-01';attempt.mkdir(exist_ok=False)
wt=pathlib.Path('/tmp/edhr-frozen-old-control-worktree-20261104')
base='c0a9d5ac33690d10d009e768c286671475db0943';candidate='2e2cde63d1a247942e94b8e5b941f6c1e174b6db'
name='edhr-frozen-old-control-20261104';db='edhr_record_control_test_frozen_old_qa'
commands=[];created_wt=False;created_pg=False;step=0
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(b):return hashlib.sha256(b).hexdigest()
def run(args,label,cwd=root,env=None,check=True):
 global step
 step+=1;s=now();p=subprocess.run(args,cwd=cwd,env=env,capture_output=True,text=True)
 stem=f'{step:02}-{label}';(attempt/(stem+'.stdout')).write_text(p.stdout);(attempt/(stem+'.stderr')).write_text(p.stderr)
 commands.append({'argv':args,'cwd':str(cwd),'started':s,'finished':now(),'exitCode':p.returncode,'stdout':stem+'.stdout','stderr':stem+'.stderr'})
 (attempt/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if check and p.returncode:raise RuntimeError(stem+' exit '+str(p.returncode))
 return p
summary=None;cleanup={};error=None
try:
 run(['git','fetch','origin','edhr-dev'],'fetch')
 assert run(['git','rev-parse','origin/edhr-dev'],'target').stdout.strip()==base
 assert run(['git','rev-parse','HEAD'],'candidate').stdout.strip()==candidate
 assert not run(['git','status','--porcelain=v1'],'main-status').stdout
 run(['git','worktree','add','--detach',str(wt),base],'worktree');created_wt=True
 test='gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'
 test_bytes=subprocess.check_output(['git','show',candidate+':'+test],cwd=root);(wt/test).write_bytes(test_bytes)
 frontend_link=wt/'gmp-platform/frontend/node_modules';frontend_link.symlink_to(root/'gmp-platform/frontend/node_modules',target_is_directory=True)
 fps=[]
 for p in ['gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java',test]:
  b=(wt/p).read_bytes();reference=candidate if p==test else base;expected=subprocess.check_output(['git','show',reference+':'+p],cwd=root);assert b==expected
  fps.append({'path':p,'referenceCommit':reference,'bytes':len(b),'sha256':sha(b)})
  dest=attempt/'source-snapshot'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 (attempt/'source-fingerprints.json').write_text(json.dumps(fps,indent=2)+'\n')
 run(['git','status','--porcelain=v1'],'old-status',cwd=wt)
 run(['git','diff','--numstat'],'old-diff',cwd=wt)
 cid=run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine'],'postgres-start').stdout.strip();created_pg=True
 ready=False
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:ready=True;break
  time.sleep(.5)
 assert ready
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name],'postgres-port').stdout.strip()
 version=run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version()'],'postgres-version').stdout.strip()
 env=os.environ.copy();url=f'jdbc:postgresql://127.0.0.1:{port}/{db}';env.update(PGUSER='postgres',RECORD_CONTROL_TEST_DATABASE_URL=url)
 selected='RecordControlPostgresIntegrationTest#frozenReassignmentSearchQualifiesBeforeLimitingUsers+recordControlTransferSearchQualifiesBeforeLimitingUsers+repeatedResponsibilitySearchUsesOriginalCandidatesBeforeLimit+unrestrictedRecordControlTargetsExcludeApplicantBeforeLimit+emptyFrozenCandidatesDoNotBecomeUnrestricted'
 start=time.time();r=run(['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+selected,'test'],'maven-negative',cwd=wt,env=env,check=False)
 xmls=list((wt/'gmp-platform/backend/target/surefire-reports').glob('TEST-*.RecordControlPostgresIntegrationTest.xml'));assert len(xmls)==1 and xmls[0].stat().st_mtime>=start
 xml=ET.parse(xmls[0]).getroot();totals={k:int(xml.attrib[k]) for k in ['tests','failures','errors','skipped']};cases=[]
 for c in xml.findall('testcase'):
  fail=c.find('failure');err=c.find('error');cases.append({'name':c.attrib['name'],'failureType':None if fail is None else fail.attrib.get('type'),'failureMessage':None if fail is None else fail.attrib.get('message'),'errorType':None if err is None else err.attrib.get('type'),'skipped':c.find('skipped') is not None})
 reports=attempt/'surefire-reports';reports.mkdir()
 for p in (wt/'gmp-platform/backend/target/surefire-reports').glob('*RecordControlPostgresIntegrationTest*'):
  if p.is_file() and p.stat().st_mtime>=start:shutil.copy2(p,reports/p.name)
 summary={'totals':totals,'cases':cases,'mavenExit':r.returncode,'database':url,'containerId':cid,'postgres':version,'selected':selected,'testedBase':base,'candidateTest':candidate}
 (attempt/'test-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
 run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','SELECT id,author,exectype FROM databasechangelog ORDER BY orderexecuted; SELECT count(*) AS users FROM user_account; SELECT id,assignee_id,candidate_snapshot FROM workflow_task ORDER BY id;'],'post-test-database-state')
 run(['docker','logs',name],'postgres-log')
 assert r.returncode==1 and totals=={'tests':8,'failures':7,'errors':0,'skipped':0},summary
 assert all(c['failureType'] in [None,'org.opentest4j.AssertionFailedError','java.lang.AssertionError'] for c in cases)
except Exception as e:
 error=repr(e);(attempt/'runner-error.txt').write_text(error+'\n');raise
finally:
 if created_pg:
  p=run(['docker','stop',name],'postgres-stop',check=False);cleanup['containerStopExit']=p.returncode
  cleanup['containerRemoved']=subprocess.run(['docker','inspect',name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 if created_wt:
  (wt/'gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java').write_bytes(subprocess.check_output(['git','show',base+':gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java'],cwd=root))
  link=wt/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink()
  p=run(['git','worktree','remove',str(wt)],'worktree-remove',check=False);cleanup['worktreeRemoveExit']=p.returncode;cleanup['worktreeRemoved']=not wt.exists()
 cleanup['mainStatus']=run(['git','status','--porcelain=v1'],'main-final-status').stdout;cleanup['error']=error
 (out/'cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
 print(json.dumps({'summary':summary and summary['totals'],'cleanup':cleanup},ensure_ascii=False))
