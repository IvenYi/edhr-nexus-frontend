import pathlib,subprocess,os,json,datetime,time,hashlib,shutil,xml.etree.ElementTree as ET
root=pathlib.Path('/workspace/edhr-nexus-frontend');out=pathlib.Path('/tmp/edhr-frozen-targets-final-qa-20261104');out.mkdir(exist_ok=True)
wt=pathlib.Path('/tmp/edhr-frozen-native-qa-20261104');name='edhr-frozen-native-qa-20261104';db='edhr_record_control_test_frozen_qa_20261104'
candidate='2e2cde63d1a247942e94b8e5b941f6c1e174b6db';target='c0a9d5ac33690d10d009e768c286671475db0943'
commands=[];created=False;added=False
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(args,cwd=root,check=True):
 p=subprocess.run(args,cwd=cwd,capture_output=True,text=True);commands.append({'args':args,'cwd':str(cwd),'time':stamp(),'exitCode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 if check and p.returncode:raise RuntimeError(str(args)+' '+p.stderr)
 return p.stdout.strip()
def tests(folder,start,expected):
 result={'totals':{k:0 for k in ['tests','failures','errors','skipped']},'classes':[]}
 for p in sorted(folder.glob('TEST-*.xml')):
  if p.stat().st_mtime<start:continue
  e=ET.parse(p).getroot();v={k:int(e.attrib.get(k,0)) for k in result['totals']};result['classes'].append({'class':e.attrib['name'],**v})
  for k in v:result['totals'][k]+=v[k]
 assert result['totals']=={'tests':expected,'failures':0,'errors':0,'skipped':0},result
 return result
try:
 run(['git','fetch','origin','edhr-dev']);head=run(['git','rev-parse','HEAD']);base=run(['git','rev-parse','origin/edhr-dev']);status=run(['git','status','--porcelain=v1']);assert head==candidate and base==target and status==''
 run(['git','merge-base','--is-ancestor',target,candidate]);contracts=run(['git','diff','--name-only',target,candidate,'--','AGENTS.md','codeplzreadme.md','docs/agents']);assert contracts==''
 (out/'baseline-start.json').write_text(json.dumps({'head':head,'base':base,'status':status,'contractsDelta':contracts,'time':stamp()},indent=2)+'\n')
 run(['git','worktree','add','--detach',str(wt),candidate]);added=True
 link=wt/'gmp-platform/frontend/node_modules';link.symlink_to(root/'gmp-platform/frontend/node_modules',target_is_directory=True)
 run(['docker','run','--rm','-d','--name',name,'-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB='+db,'-p','127.0.0.1::5432','postgres:16-alpine']);created=True
 for _ in range(120):
  if subprocess.run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','postgres'],capture_output=True).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('Own PG not ready')
 run(['docker','exec',name,'psql','-U','postgres','-d',db,'-c','CREATE ROLE edhr LOGIN'])
 run(['docker','exec',name,'createdb','-U','postgres','-O','edhr','edhr_w3_transfer_test'])
 port=run(['docker','inspect','--format','{{(index (index .NetworkSettings.Ports "5432/tcp") 0).HostPort}}',name]);env=os.environ.copy();env.update(PGUSER='postgres',RECORD_CONTROL_TEST_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/{db}',W3_TRANSFER_DATABASE_URL=f'jdbc:postgresql://127.0.0.1:{port}/edhr_w3_transfer_test')
 selected='RecordControlPostgresIntegrationTest,WorkflowTransferPostgresTest,ProductionExecutionEngineTest,ExecutionAccessTest,DhrReviewServiceTest,DhrReviewLifecycleIntegrationTest,RecordControlCandidateAuthorizationTest,RecordControlWorkflowControllerTest,WorkflowTaskControllerTest'
 sourcePaths=['AGENTS.md','docs/agents/quality-verifier.md','docs/agents/agent-handoff-contract.md','gmp-platform/backend/src/main/java/com/zencas/edhr/identity/service/TenantTransferTargets.java','gmp-platform/backend/src/main/java/com/zencas/edhr/workflow/service/WorkflowResponsibilityService.java','gmp-platform/backend/src/test/java/com/zencas/edhr/recordcontrol/service/RecordControlPostgresIntegrationTest.java']
 fps=[]
 for path in sourcePaths:
  b=(wt/path).read_bytes();p=out/'source-snapshot'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);fps.append({'path':path,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 (out/'source-fingerprints.json').write_text(json.dumps(fps,indent=2)+'\n')
 native=out/'native';native.mkdir();start=datetime.datetime.now(datetime.timezone.utc);command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','gmp-platform/backend/pom.xml','-Dtest='+selected,'test']
 with (native/'maven.log').open('w') as log:p=subprocess.run(command,cwd=wt,env=env,stdout=log,stderr=subprocess.STDOUT)
 (native/'command.json').write_text(json.dumps({'args':command,'cwd':str(wt),'started':start.isoformat(),'finished':stamp(),'exitCode':p.returncode,'testDatabase':env['RECORD_CONTROL_TEST_DATABASE_URL'],'transferDatabase':env['W3_TRANSFER_DATABASE_URL'],'candidate':candidate,'target':target},indent=2)+'\n')
 assert p.returncode==0
 summary=tests(wt/'gmp-platform/backend/target/surefire-reports',start.timestamp(),138);(native/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 shutil.copytree(wt/'gmp-platform/backend/target/surefire-reports',native/'surefire',ignore=shutil.ignore_patterns('*.dump','*.dumpstream'))
 (native/'database-state.txt').write_text(run(['docker','exec',name,'psql','-U','postgres','-d',db,'-Atc','SELECT version(); SELECT count(*) FROM databasechangelog; SELECT id||chr(9)||exectype FROM databasechangelog ORDER BY orderexecuted;'])+'\n')
 knowledge=out/'knowledge';knowledge.mkdir();start=datetime.datetime.now(datetime.timezone.utc);command=['bash','/workspace/.edhr-cloud-tools/mvn-edhr','-f','tools/knowledge-model/pom.xml','test']
 with (knowledge/'maven.log').open('w') as log:p=subprocess.run(command,cwd=wt,stdout=log,stderr=subprocess.STDOUT)
 (knowledge/'command.json').write_text(json.dumps({'args':command,'cwd':str(wt),'started':start.isoformat(),'finished':stamp(),'exitCode':p.returncode,'candidate':candidate},indent=2)+'\n');assert p.returncode==0
 summary=tests(wt/'tools/knowledge-model/target/surefire-reports',start.timestamp(),89);(knowledge/'test-summary.json').write_text(json.dumps(summary,indent=2)+'\n');shutil.copytree(wt/'tools/knowledge-model/target/surefire-reports',knowledge/'surefire')
 (out/'run-result.json').write_text(json.dumps({'candidate':candidate,'target':target,'nativeTests':138,'knowledgeTests':89,'passed':True,'finished':stamp()},indent=2)+'\n')
finally:
 if created:
  (out/'native-postgres.log').write_text(run(['docker','logs',name],check=False));run(['docker','stop',name])
  removed=False
  for _ in range(30):
   if subprocess.run(['docker','inspect',name],capture_output=True).returncode!=0:removed=True;break
   time.sleep(.1)
 if added:
  link=wt/'gmp-platform/frontend/node_modules'
  if link.is_symlink():link.unlink()
  run(['git','worktree','remove',str(wt)])
 (out/'cleanup.json').write_text(json.dumps({'ownWorktree':str(wt),'worktreeRemoved':not wt.exists(),'ownContainer':name,'containerRemoved':removed if created else None,'sharedResourcesUntouched':True},indent=2)+'\n')
 (out/'orchestration-commands.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n')
