package com.zencas.edhr.production.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.zencas.edhr.common.audit.AuditContext;
import com.zencas.edhr.common.dto.PageResult;
import com.zencas.edhr.common.util.SnowflakeIdGenerator;
import com.zencas.edhr.compliance.entity.AuditEvent;
import com.zencas.edhr.compliance.repository.AuditEventRepository;
import com.zencas.edhr.workflow.engine.WorkflowEngine;
import com.zencas.edhr.workflow.repository.WorkflowInstanceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;

import static com.zencas.edhr.production.service.ExecutionSnapshotBuilder.invalid;

/** Personal review projection. Submitted evidence is never updated by a review action. */
@Service
@RequiredArgsConstructor
public class DhrReviewService {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final DhrSummaryService summaries;
    private final WorkflowEngine engine;
    private final WorkflowInstanceRepository workflows;
    private final ExecutionAccess access;
    private final AuditEventRepository audits;
    private final SnowflakeIdGenerator ids;
    private final DhrEvidenceImpactService impacts;

    private static final String FROM = """
        FROM dhr_summary_review r JOIN workflow_task t ON t.instance_id=r.workflow_instance_id
        JOIN workflow_node n ON n.id=t.node_id JOIN dhr_summary_version v ON v.id=r.summary_version_id
        JOIN dhr_instance d ON d.id=v.dhr_instance_id WHERE v.tenant_id='default'
        """;
    private static final String SELECT = """
        SELECT t.id AS task_id,t.status AS task_status,t.assignee_id,t.candidate_snapshot,t.opinion,t.action,
          t.created_at,t.completed_at,n.name AS node_name,n.properties,v.id AS version_id,v.version_no,v.snapshot_hash,
          v.check_result_snapshot,
          v.dhr_instance_id,v.submitted_by,v.submitted_at,d.dhr_no,d.object_no,d.object_type,
          d.work_order_no,d.product_name,r.status AS review_status,r.workflow_instance_id
        """ + FROM;
    private static final String LIST_SELECT = """
        SELECT t.id AS task_id,t.status AS task_status,t.opinion,t.action,t.created_at,t.completed_at,n.name AS node_name,
          v.id AS version_id,v.version_no,v.snapshot_hash,v.dhr_instance_id,v.submitted_by,v.submitted_at,
          d.dhr_no,d.object_no,d.work_order_no,d.product_name
        """ + FROM;

    @Transactional(readOnly = true)
    public PageResult<ObjectNode> list(String view, String keyword, int page, int size) {
        if (!Set.of("PENDING", "DONE").contains(view)) throw invalid("不支持的审批视图");
        String actor = actor();
        page = Math.max(0, page); size = Math.max(1, Math.min(200, size));
        List<Object> args = new ArrayList<>();
        String visibility;
        if (view.equals("DONE")) {
            visibility = " AND t.status IN ('COMPLETED','REJECTED') AND t.assignee_id=?";
            args.add(actor);
        } else {
            visibility = """
                 AND r.status='PENDING_REVIEW' AND t.status IN ('PENDING','PROCESSING') AND (
                   CASE jsonb_typeof(t.candidate_snapshot->'unrestricted')
                     WHEN 'boolean' THEN t.candidate_snapshot->>'unrestricted'='true'
                     WHEN 'string' THEN regexp_replace(t.candidate_snapshot->>'unrestricted',
                       '^[\\x01-\\x20]+|[\\x01-\\x20]+$', '', 'g')='true'
                     WHEN 'number' THEN t.candidate_snapshot->>'unrestricted' ~ '^-?[0-9]+$'
                       AND (t.candidate_snapshot->>'unrestricted')::numeric<>0
                     ELSE FALSE END
                   OR CASE
                     WHEN (jsonb_typeof(t.candidate_snapshot->'userIds')='array' AND t.candidate_snapshot->'userIds'<>'[]'::jsonb)
                       OR (jsonb_typeof(t.candidate_snapshot->'userIds')='object' AND t.candidate_snapshot->'userIds'<>'{}'::jsonb)
                     THEN EXISTS (
                       SELECT 1 FROM (
                         SELECT value FROM jsonb_array_elements(CASE WHEN jsonb_typeof(t.candidate_snapshot->'userIds')='array'
                           THEN t.candidate_snapshot->'userIds' ELSE '[]'::jsonb END)
                         UNION ALL
                         SELECT value FROM jsonb_each(CASE WHEN jsonb_typeof(t.candidate_snapshot->'userIds')='object'
                           THEN t.candidate_snapshot->'userIds' ELSE '{}'::jsonb END)
                       ) candidates WHERE jsonb_typeof(value) NOT IN ('object','array')
                         AND COALESCE(value#>>'{}','null')=?
                     ) ELSE t.assignee_id=? END
                 )
                """;
            args.add(actor); args.add(actor);
        }
        String needle = keyword == null ? "" : keyword.strip().toLowerCase(Locale.ROOT);
        String search = "";
        if (!needle.isEmpty()) {
            // ICU root casing preserves Locale.ROOT expansion and contextual casing (e.g. İ, ΟΣ).
            search = " AND (" + String.join(" OR ", List.of("d.dhr_no", "d.object_no", "d.work_order_no", "d.product_name", "v.submitted_by")
                    .stream().map(column -> "strpos(lower(COALESCE(" + column + ",'') COLLATE \"und-x-icu\"),?)>0").toList()) + ")";
            for (int i = 0; i < 5; i++) args.add(needle);
        }
        args.add(size); args.add((long) page * size);
        // Both branches use one MVCC statement snapshot. The total row survives an empty/deep page.
        var rows = jdbc.queryForList("WITH visible AS NOT MATERIALIZED (" + LIST_SELECT + visibility + search + """
                ), page AS (SELECT * FROM visible ORDER BY task_id DESC LIMIT ? OFFSET ?)
                SELECT page.*,totals.total FROM (SELECT COUNT(*) AS total FROM visible) totals
                LEFT JOIN page ON TRUE ORDER BY page.task_id DESC
                """, args.toArray());
        long count = ((Number) rows.getFirst().get("total")).longValue();
        List<ObjectNode> result = rows.stream().filter(row -> row.get("task_id") != null).map(this::project).toList();
        return PageResult.of(result, page, size, count);
    }

    @Transactional(readOnly = true)
    public ObjectNode detail(Long taskId) {
        var row = requireTask(taskId);
        if (!(pending(row) && eligible(row, actor())) && !handled(row, actor())) throw new AccessDeniedException("无此 DHR 审批任务权限");
        ObjectNode result = summaries.version(number(row, "dhr_instance_id"), number(row, "version_id"));
        result.set("task", project(row));
        result.set("evidenceChanges", evidenceChanges(number(row, "version_id"), false));
        result.set("buttons", buttons(row));
        result.put("canAct", pending(row) && eligible(row, actor()));
        return result;
    }

    @Transactional
    public ObjectNode act(Long taskId, JsonNode command) {
        var reference = requireTask(taskId);
        // The production object lock serializes source writes with approval; keep object before DHR.
        var workflow = workflows.findByIdForUpdate(number(reference, "workflow_instance_id")).orElseThrow(() -> invalid("审批流程不存在"));
        Long dhrId = number(reference, "dhr_instance_id"), versionId = number(reference, "version_id");
        var objectRows = jdbc.queryForList("SELECT production_object_id FROM dhr_instance WHERE tenant_id='default' AND id=?", dhrId);
        if (objectRows.isEmpty()) throw invalid("DHR 实例不存在");
        Object objectId = objectRows.getFirst().get("production_object_id");
        if (objectId != null) jdbc.queryForMap("SELECT id FROM production_object WHERE tenant_id='default' AND id=? FOR UPDATE", objectId);
        var dhr = jdbc.queryForMap("SELECT summary_status,production_object_id FROM dhr_instance WHERE tenant_id='default' AND id=? FOR UPDATE", dhrId);
        var row = requireTask(taskId);
        if (!pending(row) || !"RUNNING".equals(workflow.getStatus()) || !"PENDING_REVIEW".equals(dhr.get("summary_status"))) throw invalid("审批任务已处理，请刷新");
        if (!eligible(row, actor())) throw new AccessDeniedException("当前用户不是审批处理人");
        if (!text(row, "snapshot_hash").equals(command.path("expectedSnapshotHash").asText())) throw invalid("审批版本已变化，请重新打开");
        String action = command.path("action").asText();
        JsonNode button = null;
        for (JsonNode item : buttons(row)) if (action.equals(item.path("action").asText())) button = item;
        if (button == null) throw invalid("当前节点不支持该审批动作");
        String opinion = command.path("opinion").asText("").strip();
        if (("RETURN".equals(action) || button.path("requireOpinion").asBoolean()) && opinion.isBlank()) throw invalid("请填写审批意见");
        if ("APPROVE".equals(action)) impacts.requireNoPendingApplications(dhrId);
        if ("APPROVE".equals(action) && !hasCompleteManualReview(row)) throw invalid("汇总提交核查结果不完整，不能批准；请退回整理");
        if ("APPROVE".equals(action) && dhr.get("production_object_id") != null) {
            for (var execution : jdbc.queryForList("SELECT snapshot_json,state_json FROM production_execution WHERE object_id=?", dhr.get("production_object_id"))) {
                var issues = CustomFormPolicy.incomplete(json(text(execution, "snapshot_json")), json(text(execution, "state_json")), false);
                if (!issues.isEmpty()) throw invalid("资料待完善，不能批准；请退回整理：" + String.join("；", issues));
            }
        }
        ArrayNode changes = evidenceChanges(versionId, true);
        if ("APPROVE".equals(action) && !changes.isEmpty()) throw invalid("DHR 冻结证据或来源范围发生变化，不能按过时证据批准；请退回整理");
        if ("APPROVE".equals(action)) summaries.validateFrozenFormFiles(dhrId, versionId);
        ExecutionAccess.ButtonSigner signer = button.path("requiresSignature").asBoolean()
                ? access.authenticateButtonSigner(command.path("account").asText(), command.path("password").asText()) : null;
        String actionOperator = signer == null ? actor() : signer.id();
        if (!eligible(row, actionOperator)) throw new AccessDeniedException("签署账户不是当前审批处理人");
        Long signatureId = null;
        if (button.path("requiresSignature").asBoolean()) {
            ObjectNode evidence = mapper.createObjectNode().put("summaryVersionId", versionId.toString())
                    .put("snapshotHash", text(row, "snapshot_hash")).put("taskId", taskId.toString()).put("opinion", opinion);
            signatureId = Long.valueOf(access.signTarget("DHR_SUMMARY", versionId.toString(), taskId.toString(), action, evidence,
                    signer));
        }
        engine.completeDhrTask(taskId, "RETURN".equals(action) ? "REJECT" : "APPROVE", opinion, actionOperator, signatureId);
        var after = workflows.findById(workflow.getId()).orElseThrow();
        String outcome = "RETURN".equals(action) ? "RETURNED" : "COMPLETED".equals(after.getStatus()) ? "APPROVED" : "PENDING_REVIEW";
        jdbc.update("UPDATE dhr_summary_review SET status=?,updated_at=? WHERE summary_version_id=?", outcome, LocalDateTime.now(), versionId);
        if ("RETURNED".equals(outcome)) summaries.prepareNextDraft(dhrId, versionId, opinion);
        if ("APPROVED".equals(outcome)) jdbc.update("UPDATE dhr_instance SET summary_status='FORMALIZED',updated_by=?,updated_at=? WHERE id=?", AuditContext.getOperatorName(), LocalDateTime.now(), dhrId);
        ObjectNode evidence = mapper.createObjectNode().put("dhrId", dhrId.toString()).put("summaryVersionId", versionId.toString())
                .put("taskId", taskId.toString()).put("action", action).put("outcome", outcome).put("opinion", opinion)
                .put("snapshotHash", text(row, "snapshot_hash"));
        evidence.set("evidenceChanges", changes);
        if (signer != null) evidence.put("sessionOperatorId", actor()).put("signerId", signer.id())
                .put("signerName", signer.name()).put("signerAccount", signer.account()).put("signatureId", signatureId.toString());
        audits.save(AuditEvent.builder().id(ids.nextId()).entityType("DHR_SUMMARY_REVIEW").entityId(versionId.toString())
                .action(action).contentBefore(mapper.createObjectNode().put("status", "PENDING_REVIEW").toString()).contentAfter(evidence.toString())
                .reason(opinion).operatorId(actor()).operatorName(AuditContext.getOperatorName()).operatorAccount(AuditContext.getOperatorAccount())
                .source(AuditContext.getSource()).moduleName("记录").menuName("DHR管理 · DHR审批").functionName("RETURN".equals(action) ? "退回整理" : "审批通过")
                .dataSummary(text(row, "dhr_no")).ipAddress(AuditContext.getIpAddress()).createdAt(LocalDateTime.now()).build());
        return evidence;
    }

    /** Read-time comparison; never rewrites a historical approval or frozen version. */
    ArrayNode evidenceChanges(Long versionId, boolean lock) {
        return impacts.changes(versionId, lock);
    }

    private ArrayNode buttons(Map<String, Object> row) {
        JsonNode properties = json(text(row, "properties"));
        JsonNode config = properties.has("config") ? properties.path("config") : properties;
        if (!config.isObject()) throw invalid("审批节点配置无法读取，不能执行审批动作");
        ArrayNode result = mapper.createArrayNode();
        for (String action : List.of("APPROVE", "RETURN")) {
            ObjectNode button = mapper.createObjectNode().put("action", action).put("label", "RETURN".equals(action) ? "退回整理" : "审批通过")
                    .put("style", "RETURN".equals(action) ? "DANGER" : "PRIMARY").put("requiresSignature", false);
            boolean visible = true;
            for (JsonNode b : config.path("buttons")) if (action.equals(b.path("action").asText())) {
                visible = b.path("visible").asBoolean(true);
                if (!b.path("label").asText().isBlank()) button.put("label", b.path("label").asText());
                button.put("requireOpinion", b.path("requireOpinion").asBoolean());
                if (b.hasNonNull("style")) button.put("style", b.path("style").asText());
                if (b.hasNonNull("size")) button.put("size", b.path("size").asText());
            }
            for (JsonNode event : config.path("buttonEvents")) if (action.equals(event.path("action").asText())
                    && event.path("enabled").asBoolean(true) && "BEFORE".equals(event.path("event").asText())
                    && "ACCOUNT_PASSWORD".equals(event.path("signatureMethod").asText())) button.put("requiresSignature", true);
            if (visible) result.add(button);
        }
        return result;
    }

    private Map<String, Object> requireTask(Long id) {
        var rows = jdbc.queryForList(SELECT + " AND t.id=?", id);
        if (rows.isEmpty()) throw invalid("DHR 审批任务不存在");
        return rows.getFirst();
    }
    private boolean pending(Map<String, Object> row) { return "PENDING_REVIEW".equals(row.get("review_status")) && Set.of("PENDING", "PROCESSING").contains(text(row, "task_status")); }
    private boolean hasCompleteManualReview(Map<String, Object> row) {
        JsonNode review = json(text(row, "check_result_snapshot")).path("manualReview");
        return review.path("qualityAndExceptionsReviewed").asBoolean(false)
                && review.path("sourceSignaturesReviewed").asBoolean(false)
                && review.path("completeScopeReviewed").asBoolean(false)
                && !review.path("note").asText("").isBlank()
                && !review.path("confirmedBy").asText("").isBlank()
                && !review.path("confirmedAt").asText("").isBlank();
    }
    private boolean handled(Map<String, Object> row, String actor) { return actor.equals(text(row, "assignee_id")) && Set.of("COMPLETED", "REJECTED").contains(text(row, "task_status")); }
    private boolean eligible(Map<String, Object> row, String actor) {
        JsonNode snapshot = json(text(row, "candidate_snapshot"));
        if (snapshot.path("unrestricted").asBoolean()) return true;
        if (!snapshot.path("userIds").isEmpty()) {
            for (JsonNode id : snapshot.path("userIds")) if (actor.equals(id.asText())) return true;
            return false;
        }
        return actor.equals(text(row, "assignee_id"));
    }
    private ObjectNode project(Map<String, Object> row) {
        ObjectNode result = mapper.createObjectNode();
        String[][] fields = {{"task_id","id"},{"dhr_instance_id","dhrId"},{"version_id","versionId"},{"dhr_no","dhrNo"},{"object_no","objectNo"},{"work_order_no","workOrderNo"},{"product_name","productName"},{"node_name","nodeName"},{"submitted_by","submittedBy"},{"submitted_at","submittedAt"},{"completed_at","completedAt"},{"task_status","status"},{"snapshot_hash","snapshotHash"},{"opinion","opinion"},{"action","action"}};
        for (String[] field : fields) result.put(field[1], text(row, field[0]));
        result.put("versionNo", ((Number) row.get("version_no")).intValue());
        return result;
    }
    private static String text(Map<String, Object> row, String key) {
        Object value = row.get(key);
        // JDBC drivers expose native JSON as either a JSON object or UTF-8 bytes.
        return value == null ? "" : value instanceof byte[] bytes ? new String(bytes, java.nio.charset.StandardCharsets.UTF_8) : value.toString();
    }
    private static Long number(Map<String, Object> row, String key) { return ((Number) row.get(key)).longValue(); }
    private String actor() { String actor = AuditContext.getOperatorId(); if (actor == null || actor.isBlank()) throw new AccessDeniedException("未登录"); return actor; }
    private JsonNode json(String value) { if (value.isBlank()) return mapper.createObjectNode(); try { return mapper.readTree(value); } catch (Exception e) { throw invalid("审批证据无法读取"); } }
}
