import pathlib,json,subprocess,hashlib,tarfile,shutil,yaml,xml.etree.ElementTree as ET
r=pathlib.Path('/workspace/edhr-nexus-frontend');o=r/'docs/development/branch-review-20261104-frozen-targets';o.joinpath('evidence').mkdir(exist_ok=True)
base='c0a9d5ac33690d10d009e768c286671475db0943';red=pathlib.Path('/tmp/edhr-frozen-targets-main-red-20261104');green=pathlib.Path('/tmp/edhr-frozen-targets-main-green-20261104');onto=pathlib.Path('/tmp/edhr-frozen-targets-ontology-20261104')
def sha(b):return hashlib.sha256(b).hexdigest()
assert sha((onto/'manifest.json').read_bytes())=='270a61b7e7dfdf90fd752b92a8c017fb40305bf25a06693a154b981f3a412f69'
manifest=json.loads((onto/'manifest.json').read_text());assert manifest['artifactCount']==len(manifest['artifacts'])==61
for f in manifest['artifacts']:
 b=(onto/f['path']).read_bytes();assert len(b)==f['bytes'] and sha(b)==f['sha256']
assert yaml.safe_load((onto/'ontology-result.yaml').read_text())['ontologyResult']['result']=='not-applicable'
assert json.loads((red/'test-summary.json').read_text())['totals']=={'tests':8,'failures':7,'errors':0,'skipped':0}
assert json.loads((green/'test-summary.json').read_text())['totals']=={'tests':138,'failures':0,'errors':0,'skipped':0}
for f in json.loads((red/'run.json').read_text())['sourceFingerprints']:
 p=f['path'];b=(red/'source-snapshot'/p).read_bytes();assert sha(b)==f['sha256']
 if '/src/main/' in p:assert b==subprocess.check_output(['git','show',base+':'+p],cwd=r)
 else:assert b==(r/p).read_bytes()==(green/'source-snapshot'/p).read_bytes()
for f in json.loads((green/'run.json').read_text())['sourceFingerprints']:
 b=(r/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
for f in json.loads((o/'source-review.json').read_text())['sourceFingerprints']:
 b=(r/f['path']).read_bytes();assert sha(b)==f['sha256'] and len(b)==f['bytes']
files=[]
for prefix,d in [('primary/red',red),('primary/green',green),('ontology',onto)]:
 for p in sorted(d.rglob('*')):
  if p.is_file():files.append((prefix+'/'+str(p.relative_to(d)),p))
for name in ['pr56-reference-runner.py','archive-frozen-targets-primary.py','edhr-frozen-red-runner-20261104.log','edhr-frozen-green-runner-20261104.log']:
 files.append(('tools/'+name,pathlib.Path('/tmp')/name))
raw=[{'member':n,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for n,p in files]
archive=o/'evidence/primary-and-ontology.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in files:t.add(p,arcname=n,recursive=False)
m={'sourceHeadDuringMainRuns':base,'includedUncommittedProductAndTestPaths':[f['path'] for f in json.loads((green/'run.json').read_text())['sourceFingerprints'] if f['path']!='gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/FormWorkflowOperations.java'],'rawArtifacts':raw,'archive':{'path':str(archive.relative_to(o)),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'note':'Original bytes retained; member bytes differ from stored gzip size. Main red8=7 assertion failures+1 empty-candidate positive; green138, no errors/skips. No full audit claim.'}
(o/'evidence-manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n');shutil.copy2(onto/'ontology-result.yaml',o/'ontology-result.yaml')
print(json.dumps({'rawArtifacts':len(raw),'ontologyManifestVerified':True,'archive':m['archive']},ensure_ascii=False))
