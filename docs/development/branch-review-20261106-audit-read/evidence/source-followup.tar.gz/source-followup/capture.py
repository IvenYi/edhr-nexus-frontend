from pathlib import Path
import subprocess, json, hashlib, datetime

ROOT = Path('/tmp/edhr-audit-read-source-followup-20261106')
REPO = Path('/workspace/edhr-nexus-frontend')
BASE = 'e69a8f3d97b34fea8737947c780b047bb0310c64'
INTRO = '1ea671cf1da3cff4f3f811ccfec0c44f1c4a86cb'
CTRL = 'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java'
TEST = 'gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditControllerTest.java'
REPO_AUDIT = 'gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java'
STANDARD = 'docs/design-audit/organization-management-ui-standard.md'
PATHS = [
    'AGENTS.md', 'codeplzreadme.md', 'docs/agents/agent-handoff-contract.md',
    CTRL, TEST, REPO_AUDIT,
    'gmp-platform/backend/src/main/java/com/zencas/edhr/common/config/SecurityConfig.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/identity/security/JwtAuthenticationFilter.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrSummaryController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrFillingController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/controller/DhrReviewController.java',
    'gmp-platform/backend/src/main/java/com/zencas/edhr/production/service/DhrSummaryService.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/controller/ProductionControllerAuthorizationTest.java',
    'gmp-platform/backend/src/test/java/com/zencas/edhr/production/service/DhrAuditReadTest.java',
    'gmp-platform/frontend/src/pages/production/WorkOrderPage.tsx',
    'gmp-platform/frontend/src/pages/production/BatchManagementPage.tsx',
    'gmp-platform/frontend/src/pages/account/PersonalSettingsPage.tsx',
    'gmp-platform/frontend/src/router/index.tsx',
    'gmp-platform/frontend/src/api/audit.ts',
    'gmp-platform/backend/src/main/resources/db/changelog/baseline/0002-current-seed.sql',
    'docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml',
    'docs/knowledge/decisions/DEC-0019-production-batch-management-list-and-row-audit.yaml',
    'docs/knowledge/evidence/dhr-filling-review-confirmed.md',
    'docs/development/branch-review-20261016-w1-review-export/source-map.md',
    'docs/development/branch-review-20261026-w4-lifecycle/scope-review.md',
    'docs/development/branch-review-20261026-w4-lifecycle/findings.md',
    STANDARD,
]
def git(*args):
    p = subprocess.run(['git', *args], cwd=REPO, capture_output=True)
    return p
def put(path, data):
    full = ROOT / path
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_bytes(data)
def sha(data):
    return hashlib.sha256(data).hexdigest()
sources = []
for path in PATHS:
    p = git('show', f'{BASE}:{path}')
    if p.returncode:
        raise RuntimeError(f'Missing source {path}: {p.stderr.decode()}')
    target = 'source-snapshot/' + path
    put(target, p.stdout)
    sources.append({'path': path, 'commit': BASE, 'blob': git('rev-parse', f'{BASE}:{path}').stdout.decode().strip(), 'snapshot': target, 'sha256': sha(p.stdout)})
for rev,label in [(INTRO,'introduced'), (INTRO+'^','before')]:
    for path in [CTRL, TEST, REPO_AUDIT]:
        p = git('show', f'{rev}:{path}')
        if p.returncode: raise RuntimeError(p.stderr.decode())
        target = f'history/{label}/' + path
        put(target, p.stdout)
        sources.append({'path': path, 'commit': git('rev-parse',rev).stdout.decode().strip(), 'blob': git('rev-parse',f'{rev}:{path}').stdout.decode().strip(), 'snapshot':target,'sha256':sha(p.stdout)})
history_cmds = {
    'queryall-introduction.patch': ['show','--format=fuller',INTRO,'--',CTRL,TEST,REPO_AUDIT,STANDARD],
    'audit-controller-history.txt': ['log','--format=fuller',BASE,'--',CTRL],
    'queryall-search-history.txt': ['log','--format=fuller','-G','Integer.MAX_VALUE|moduleKeyword|matchesAuditText|queryAll',BASE,'--',CTRL],
}
for name,args in history_cmds.items():
    p=git(*args)
    if p.returncode: raise RuntimeError(p.stderr.decode())
    put('history/'+name,p.stdout)
searches = [
    ['grep','-n','-i','-E','system\\.audit-logs|audit[_-]?(logs|events).{0,30}(permission|authoriz)|审计日志.{0,20}(读取权限|查询权限|查看权限|越权|授权)',BASE,'--','docs/knowledge'],
    ['grep','-n','-i','-E','全局审计权限|审计日志.{0,30}(越权|权限|授权)|AuditController.*(权限|授权)',BASE,'--','docs/development/branch-review-20261026-w4-lifecycle','docs/development/branch-review-20261016-w1-review-export','docs/development/branch-review-20261015'],
]
results = []
for args in searches:
    p=git(*args)
    if p.returncode not in (0,1): raise RuntimeError(p.stderr.decode())
    results.append({'argv':['git',*args], 'scope':'fixed Git baseline targeted knowledge/old review search; no full-policy-completeness claim', 'exitCode':p.returncode,'stdout':p.stdout.decode(),'stderr':p.stderr.decode()})
put('search-results.json',(json.dumps(results,ensure_ascii=False,indent=2)+'\n').encode())
put('source-manifest.json',(json.dumps({'baseline':BASE,'sources':sources},ensure_ascii=False,indent=2)+'\n').encode())
result = {
    'role':'read-only-source-followup-not-implementation-or-final-QA',
    'status':'completed',
    'sourceCommit':BASE,
    'targetBranch':'edhr-dev',
    'targetCommit':BASE,
    'contractReadCommit':BASE,
    'knowledgeBaselineVersion':'0.3.25',
    'schemaVersion':'1.2.0',
    'projectFilesModified':[],
    'applicationTestsExecuted':False,
    'postgresExecuted':False,
    'browserExecuted':False,
    'permissions':{
        'sourceFact':'global list and raw event detail authenticated-only; me fixes USER_ACCOUNT/currentUser target; production embeds shared list',
        'confirmedCompleteBackendGlobalAuditPolicyFound':False,
        'dedicatedOldPermissionIssueIdFound':False,
        'disposition':'retain policy/evidence gap; do not add blanket global menu check',
        'oldExclusion':'branch-review-20261026-w4-lifecycle/scope-review.md:9',
    },
    'queryAllHistory':{
        'introducedBy':INTRO,
        'notIntroducedByPR67':True,
        'sameCommitAddsResolvedLegacyFilterRegressionTest':True,
        'authorRationaleForChoosingAllLoadingDocumented':False,
        'finding':'same-patch structural relationship plus explicit legacy display filter test; no inferred author intent',
    },
    'priorFinalArtifactsPreserved':'/tmp/edhr-audit-read-source-20261106/',
    'runtimeAndWholeAuditClaims':False,
}
put('result.json',(json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
files=[]
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in ('manifest.json','manifest.sha256'):
        data=path.read_bytes()
        files.append({'path':str(path.relative_to(ROOT)), 'bytes':len(data), 'sha256':sha(data)})
put('manifest.json',(json.dumps({'createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':files},ensure_ascii=False,indent=2)+'\n').encode())
digest=sha((ROOT/'manifest.json').read_bytes())
put('manifest.sha256',(digest+'  manifest.json\n').encode())
print(json.dumps({'fixedBaselineSources':len(PATHS),'sourceSnapshotsIncludingHistorical':len(sources),'artifactFiles':len(files),'manifestSha256':digest}))
