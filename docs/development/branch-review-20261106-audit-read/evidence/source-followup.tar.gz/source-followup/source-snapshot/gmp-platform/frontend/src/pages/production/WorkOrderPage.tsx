import { readRecordLocation, useRecordLocationAction } from '@/utils/recordLocation';
import { ProductionOutputDetails, ProductionOutputValue } from '@/components/ProductionOutput';
import TableStateCell from '@/components/TableStateCell';
import { listColumnResizeHandleSx, listTableBodyCellSx, listTableHeaderCellSx, listTableStickyEdgeSx } from '@/components/listTableStyles';
import { Fragment, useEffect, useMemo, useRef, useState, type ReactNode, type PointerEvent as ReactPointerEvent } from 'react';
import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Alert,
  Box,
  Button,
  CircularProgress,
  DialogActions,
  DialogContent,
  DialogTitle,
  Drawer,
  IconButton,
  FormControlLabel,
  InputAdornment,
  MenuItem,
  Pagination,
  Radio,
  RadioGroup,
  Skeleton,
  Stack,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Tabs,
  TextField,
  Tooltip,
  Typography,
} from '@mui/material';
import {
  Add,
  StopCircleOutlined,
  Cancel,
  Check,
  Close,
  Clear,
  Edit,
  ExpandMore,
  PlayArrow,
  RestartAlt,
  Search,
  ViewList,
  UploadFile,
  DeleteOutline,
  Visibility,
  TuneRounded,
  ViewColumnRounded,
} from '@mui/icons-material';
import * as XLSX from 'xlsx';
import ExcelJS from 'exceljs';
import AppDialog from '@/components/AppDialog';
import ProductionObjectEditDialog from '@/components/ProductionObjectEditDialog';
import FormDialogFieldGrid from '@/components/FormDialogFieldGrid';
import ConfirmDialog from '@/components/ConfirmDialog';
import { ListTableShell } from '@/components/ListTableShell';
import StatusBadge from '@/components/StatusBadge';
import { useSnackbar } from '@/components/SnackbarProvider';
import { getAuditLogs, type AuditLogItem } from '@/api/audit';
import { getProductModelingProducts, getProcessOwnerWorkspace, type ProcessOwnerType, type ProductModelSource, type ProductProcessVersion } from '@/api/product-modeling';
import {
  cancelProductionObject,
  cancelWorkOrder,
  closeWorkOrder,
  endWorkOrder,
  completeProductionObject,
  createWorkOrder,
  listProductionObjects,
  listProcessOptions,
  listWorkOrders,
  splitProductionObjectsBatch,
  startProductionObject,
  updateWorkOrder,
  type ProductionObject,
  type WorkOrder,
} from '@/api/work-orders';
import type { PageResult } from '@/types/common';
import { toProductionAuditFields, type ProductionAuditField } from '@/utils/productionAudit';
import ListColumnSettingsPopover, {
  getCurrentUserPreferenceStorageKey,
  loadListColumnSettings,
  reorderListColumns,
  type ListColumnOption,
  type ListColumnSettings,
} from '@/components/ListColumnSettingsPopover';

const PAGE_SIZE_OPTIONS = [20, 50, 100, 200] as const;
const WORK_ORDER_COLUMN_SETTINGS_VERSION = 2;
const WORK_ORDER_COLUMN_SETTINGS_PREFIX = 'production-work-order-columns:';
const WORK_ORDER_COLUMN_WIDTHS_PREFIX = 'production-work-order-column-widths:';
const WORK_ORDER_ACTION_COLUMN_WIDTH = 160;
const PENDING_OBJECT_ACTION_COLUMN_WIDTH = 64;
type WorkOrderColumnId = 'orderNo' | 'product' | 'productionMode' | 'productionForm' | 'plannedQuantity' | 'output' | 'createdAt' | 'status';
type WorkOrderColumn = ListColumnOption<WorkOrderColumnId> & { width: number; minWidth: number };
type WorkOrderColumnWidths = Partial<Record<WorkOrderColumnId, number>>;
const WORK_ORDER_COLUMNS: WorkOrderColumn[] = [
  { id: 'orderNo', label: '工单号', width: 180, minWidth: 140 },
  { id: 'product', label: '产品', width: 190, minWidth: 160 },
  { id: 'productionMode', label: '生产模式', width: 104, minWidth: 96 },
  { id: 'productionForm', label: '生产形态', width: 104, minWidth: 96 },
  { id: 'plannedQuantity', label: '计划数量', width: 110, minWidth: 96 },
  { id: 'output', label: '累计产出', width: 150, minWidth: 130 },
  { id: 'createdAt', label: '创建时间', width: 164, minWidth: 148 },
  { id: 'status', label: '状态', width: 104, minWidth: 96, fixed: true },
];
const statusLabels: Record<string, string> = {
  CREATED: '已创建',
  IN_PROCESS: '生产中',
  EARLY_TERMINATED: '提前结束',
  COMPLETED: '已完成',
  CLOSED: '已关闭',
  CANCELLED: '已取消',
};
const objectStatusLabels: Record<string, string> = {
  CREATED: '已创建',
  IN_PROGRESS: '生产中',
  EARLY_TERMINATED: '提前结束',
  COMPLETED: '已完成',
  CANCELLED: '已取消',
};
const formLabels: Record<string, string> = { SN: 'SN', BATCH: '批次', 批次: '批次', '批次转SN': '批次转SN' };
const statusColors: Record<string, 'success' | 'warning' | 'error' | 'info' | 'default'> = {
  CREATED: 'info',
  IN_PROCESS: 'warning',
  IN_PROGRESS: 'warning',
  EARLY_TERMINATED: 'error',
  COMPLETED: 'success',
  CLOSED: 'default',
  CANCELLED: 'error',
};
const tableHeaderCellSx = listTableHeaderCellSx;
const tableRowSx = { '& > .MuiTableCell-root': listTableBodyCellSx };
function getStatusColumnSx(width: number, layer: 'head' | 'body') {
  return {
    position: 'sticky' as const, right: WORK_ORDER_ACTION_COLUMN_WIDTH, zIndex: layer === 'head' ? 10 : 2,
    width, minWidth: width, maxWidth: width, bgcolor: layer === 'head' ? '#f5f7fa' : '#fff',
    top: layer === 'head' ? 0 : undefined, ...listTableStickyEdgeSx, textAlign: layer === 'head' ? 'center' as const : undefined, whiteSpace: 'nowrap',
  };
}
function getOperationColumnSx(layer: 'head' | 'body', hasVisibleStatusColumn: boolean) {
  return {
    position: 'sticky' as const, right: 0, zIndex: layer === 'head' ? 10 : 2,
    width: WORK_ORDER_ACTION_COLUMN_WIDTH, minWidth: WORK_ORDER_ACTION_COLUMN_WIDTH, maxWidth: WORK_ORDER_ACTION_COLUMN_WIDTH,
    top: layer === 'head' ? 0 : undefined, bgcolor: layer === 'head' ? '#f5f7fa' : '#fff', backgroundClip: 'padding-box', ...(!hasVisibleStatusColumn ? listTableStickyEdgeSx : {}), textAlign: 'center' as const, whiteSpace: 'nowrap',
  };
}
const clearableSelectSx = {
  '& .MuiSelect-icon': { transition: 'opacity 120ms ease' },
  '& .select-clear-adornment': {
    position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)', margin: 0,
    zIndex: 2, pointerEvents: 'none',
  },
  '& .select-clear-button': {
    opacity: 0, pointerEvents: 'none', color: '#909399', transition: 'opacity 120ms ease',
  },
  '&.has-value:hover .MuiSelect-icon, &.has-value:focus-within .MuiSelect-icon': { opacity: 0 },
  '&.has-value:hover .select-clear-button, &.has-value:focus-within .select-clear-button': { opacity: 0.55, pointerEvents: 'auto' },
  '& .select-clear-button:hover': { opacity: 0.85 },
};
const drawerRootSx = {
  top: 0, bottom: 0, zIndex: (theme: { zIndex: { drawer: number } }) => theme.zIndex.drawer + 2,
  '& .MuiBackdrop-root': { top: 0 },
};
const drawerPaperSx = { ...drawerRootSx, width: { xs: '100vw', sm: 560 }, top: 0, bottom: 0, height: '100vh', transform: 'none !important' };

interface WorkOrderForm {
  orderNo: string;
  orderNumber: string;
  productId: string;
  plannedQuantity: string;
  plannedStartAt: string;
  plannedEndAt: string;
  remark: string;
}

interface AuditRecord {
  id: string;
  operatorName: string;
  actionLabel: string;
  operatedAt?: string;
  beforeFields: ProductionAuditField[];
  afterFields: ProductionAuditField[];
}

const emptyForm = (): WorkOrderForm => ({ orderNo: '', orderNumber: '', productId: '', plannedQuantity: '', plannedStartAt: '', plannedEndAt: '', remark: '' });

function formatDateTime(value?: string | null) {
  if (!value) return '-';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value.replace('T', ' ').slice(0, 19) : date.toLocaleString('zh-CN', { hour12: false }).replace(/\//g, '-');
}

function loadColumnWidths(storageKey: string): WorkOrderColumnWidths {
  if (typeof window === 'undefined') return {};
  try {
    const parsed = JSON.parse(localStorage.getItem(storageKey) || '{}');
    return typeof parsed === 'object' && parsed ? parsed as WorkOrderColumnWidths : {};
  } catch {
    return {};
  }
}

function toInputDateTime(value?: string | null) { return value ? value.replace(' ', 'T').slice(0, 16) : ''; }

function toAuditRecords(events: AuditLogItem[] | undefined): AuditRecord[] {
  const labels: Record<string, string> = { CREATE: '新增', UPDATE: '修改', CANCEL: '修改', STATUS_CHANGE: '修改' };
  const actionLabelFor = (event: AuditLogItem) => {
    const action = (event.action || '').toUpperCase();
    return event.actionLabel || labels[action] || (action === 'CREATE' ? '新增' : '修改');
  };
  return (events ?? []).map((event) => ({
    id: String(event.id),
    operatorName: event.operatorDisplayName || event.operatorAccount || '-',
    actionLabel: actionLabelFor(event),
    operatedAt: event.operationTime || event.createdAt,
    beforeFields: toProductionAuditFields(event.contentBefore),
    afterFields: toProductionAuditFields(event.contentAfter),
  }));
}

function statusBadge(status: string, labels: Record<string, string>) {
  return <StatusBadge label={labels[status] || status || '-'} color={statusColors[status] || 'default'} />;
}

function DetailSection({ title, children }: { title: string; children: ReactNode }) {
  return <Box sx={{ bgcolor: '#fff', border: '1px solid #e4e7ed', borderRadius: 1, overflow: 'hidden' }}>
    <Box sx={{ px: 1.5, py: 1, borderBottom: '1px solid #e4e7ed', bgcolor: '#f8fafc' }}><Typography sx={{ fontWeight: 600, color: '#303133' }}>{title}</Typography></Box>
    <Box sx={{ p: 1.5 }}>{children}</Box>
  </Box>;
}

function FormSection({ title, children }: { title: string; children: ReactNode }) {
  return <Box sx={{ bgcolor: '#fff', border: '1px solid #e4e7ed', borderRadius: 1, overflow: 'hidden' }}>
    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, px: { xs: 1.5, sm: 2 }, py: 1.25, bgcolor: '#f8fafc', borderBottom: '1px solid #e4e7ed' }}>
      <Typography variant="subtitle2" sx={{ color: '#303133', fontWeight: 600 }}>{title}</Typography>
    </Box>
    <Box sx={{ p: { xs: 1.5, sm: 2 } }}>{children}</Box>
  </Box>;
}

function DetailField({ label, children }: { label: string; children: ReactNode }) {
  return <Box sx={{ minWidth: 0 }}><Typography variant="caption" sx={{ color: '#909399', display: 'block', mb: 0.5 }}>{label}</Typography><Typography variant="body2" sx={{ color: '#303133', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{children || '-'}</Typography></Box>;
}

function AuditFieldBlock({ title, fields }: { title: string; fields: ProductionAuditField[] }) {
  return <Box sx={{ border: '1px solid #e4e7ed', borderRadius: 1, bgcolor: '#f8fafc', p: 1 }}>
    <Typography variant="caption" sx={{ display: 'block', mb: 0.75, color: '#606266', fontWeight: 600 }}>{title}</Typography>
    <Stack spacing={0.75}>{fields.length === 0 ? <Typography variant="caption" sx={{ color: '#909399' }}>无</Typography> : fields.map((field) => <Box key={field.key} sx={{ display: 'grid', gridTemplateColumns: '84px minmax(0, 1fr)', gap: 1 }}><Typography variant="caption" sx={{ color: '#606266' }}>{field.label}</Typography><Typography variant="caption" sx={{ color: '#303133', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>{field.value}</Typography></Box>)}</Stack>
  </Box>;
}

function WorkOrderDetailDrawer({ open, order, tab, onTabChange, auditRecords, auditLoading, auditError, onClose }: {
  open: boolean;
  order: WorkOrder | null;
  tab: number;
  onTabChange: (value: number) => void;
  auditRecords: AuditRecord[];
  auditLoading: boolean;
  auditError: boolean;
  onClose: () => void;
}) {
  return <Drawer anchor="right" open={open} onClose={onClose} sx={drawerRootSx} slotProps={{ backdrop: { sx: drawerRootSx } }} PaperProps={{ sx: drawerPaperSx }}>
    <Box sx={{ minHeight: '100%', overflow: 'auto', bgcolor: '#f7f9fc', p: 2 }}>
      <Stack direction="row" alignItems="center" justifyContent="space-between" sx={{ mb: 1 }}><Typography variant="subtitle1" sx={{ fontWeight: 600, color: '#303133' }}>信息查看</Typography><IconButton size="small" onClick={onClose} aria-label="关闭详情"><Close fontSize="small" /></IconButton></Stack>
      {order && <><Box sx={{ borderBottom: '1px solid #e4e7ed' }}><Tabs value={tab} onChange={(_, value: number) => onTabChange(value)} aria-label="工单详情切换"><Tab label="数据信息" /><Tab label="数据审计" /></Tabs></Box>
        {tab === 0 ? <Stack spacing={2} sx={{ mt: 2 }}>
          <DetailSection title="工单信息"><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 1.75 }}>
            <DetailField label="工单编号">{order.orderNo}</DetailField><DetailField label="订单编号">{order.orderNumber}</DetailField>
            <DetailField label="产品名称">{order.productName}</DetailField><DetailField label="产品编码">{order.productCode}</DetailField>
            <DetailField label="生产模式">{order.productionMode}</DetailField>
            <DetailField label="生产形态">{formLabels[order.productionForm || ''] || order.productionForm}</DetailField><DetailField label="计划数量">{order.plannedQuantity}</DetailField>
            <DetailField label="计划开始时间">{formatDateTime(order.plannedStartAt)}</DetailField><DetailField label="计划结束时间">{formatDateTime(order.plannedEndAt)}</DetailField>
            <DetailField label="工单状态">{statusBadge(order.status, statusLabels)}</DetailField><DetailField label="备注">{order.remark}</DetailField>
          </Box></DetailSection>
          <DetailSection title="累计产出"><ProductionOutputDetails output={order.output} /></DetailSection>
          <DetailSection title="系统信息"><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 1.75 }}><DetailField label="创建时间">{formatDateTime(order.createdAt)}</DetailField><DetailField label="更新时间">{formatDateTime(order.updatedAt)}</DetailField></Box></DetailSection>
        </Stack> : <Stack spacing={1} sx={{ mt: 2 }}>
          {auditLoading ? <Box sx={{ py: 8, display: 'grid', placeItems: 'center' }}><CircularProgress size={24} /></Box> : auditError ? <Box sx={{ py: 8, textAlign: 'center', color: '#c62828' }}>审计记录加载失败</Box> : auditRecords.length === 0 ? <Box sx={{ py: 8, textAlign: 'center', color: '#909399' }}>暂无审计记录</Box> : auditRecords.map((record) => <Accordion key={record.id} disableGutters elevation={0} sx={{ border: '1px solid #e4e7ed', borderRadius: '4px !important', overflow: 'hidden', '&::before': { display: 'none' }, '&.Mui-expanded': { m: 0 } }}>
            <AccordionSummary expandIcon={<ExpandMore fontSize="small" />} sx={{ minHeight: 44, px: 1.5, '&.Mui-expanded': { minHeight: 44 }, '& .MuiAccordionSummary-content': { my: 0 }, '& .MuiAccordionSummary-content.Mui-expanded': { my: 0 } }}><Box sx={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.25fr', columnGap: 1, width: '100%', minWidth: 0 }}><Typography variant="body2" noWrap>{record.operatorName}</Typography><Typography variant="body2" noWrap>{record.actionLabel}</Typography><Typography variant="body2" noWrap sx={{ color: '#606266' }}>{formatDateTime(record.operatedAt)}</Typography></Box></AccordionSummary>
            <AccordionDetails sx={{ pt: 0, pb: 1.5 }}><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 1.5 }}><AuditFieldBlock title="变更前" fields={record.beforeFields} /><AuditFieldBlock title="变更后" fields={record.afterFields} /></Box></AccordionDetails>
          </Accordion>)}
        </Stack>}
      </>}
    </Box>
  </Drawer>;
}

function ProcessVersionPreviewDialog({ open, version, loading, error, onClose, onRetry }: {
  open: boolean;
  version?: ProductProcessVersion;
  loading: boolean;
  error: boolean;
  onClose: () => void;
  onRetry: () => void;
}) {
  return <AppDialog open={open} onClose={onClose} maxWidth="md" fullWidth>
    <DialogTitle>{version?.version ? `制程版本预览 - ${version.version}` : '制程版本预览'}</DialogTitle>
    <DialogContent dividers sx={{ p: { xs: 1.5, sm: 2.5 }, bgcolor: '#f6f8f9' }}>
      {loading ? <Stack spacing={2} sx={{ py: 2 }}><Skeleton variant="rounded" height={120} /><Skeleton variant="rounded" height={160} /></Stack> : error || !version ? <Alert severity="error" action={<Button onClick={onRetry}>重试</Button>}>制程版本详情加载失败，请重试。</Alert> : <Stack spacing={1.5}>
        <FormSection title="版本信息"><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: '1fr 1fr' }, gap: 1.5 }}>
          <DetailField label="制程版本">{version.version}</DetailField><DetailField label="版本状态">{version.status || '-'}</DetailField>
          <DetailField label="生产模式">{version.productionMode}</DetailField><DetailField label="生产形态">{version.productionForm}</DetailField>
          <DetailField label="工艺路线版本">{version.routeCode || version.routeName ? `${version.routeCode || ''}${version.routeCode && version.routeName ? ' · ' : ''}${version.routeName || ''}（${version.routeVersion || '-'}）` : version.routeVersion || '-'}</DetailField>
          <DetailField label="批记录模板版本">{version.dhrTemplateCode || version.dhrTemplateName ? `${version.dhrTemplateCode || ''}${version.dhrTemplateCode && version.dhrTemplateName ? ' · ' : ''}${version.dhrTemplateName || ''}（${version.dhrTemplateVersion || '-'}）` : version.dhrTemplateVersion || '-'}</DetailField>
          <DetailField label="版本说明">{version.description || '-'}</DetailField>
        </Box></FormSection>
        <FormSection title={`工序配置（${version.operations?.length || 0}）`}>
          {version.operations?.length ? <Stack spacing={1}>{version.operations.map((operation, index) => <Box key={operation.id || operation.routeNodeKey} sx={{ p: 1.25, bgcolor: '#fbfdff', border: '1px solid #e4e7ed', borderRadius: 1 }}>
            <Typography variant="body2" sx={{ color: '#303133', fontWeight: 600 }}>{index + 1}. {operation.operationName}</Typography>
            <Typography variant="caption" sx={{ color: '#909399' }}>表单 {operation.forms?.length || 0} 个 · 文件 {operation.documents?.length || 0} 个</Typography>
          </Box>)}</Stack> : <Typography variant="body2" sx={{ color: '#909399' }}>暂无工序配置</Typography>}
        </FormSection>
      </Stack>}
    </DialogContent>
    <DialogActions sx={{ px: 3, py: 1.5 }}><Button onClick={onClose}>关闭</Button></DialogActions>
  </AppDialog>;
}

export default function WorkOrderPage() {
  const client = useQueryClient();
  const { showMessage } = useSnackbar();
  const columnResizeRef = useRef<{ id: WorkOrderColumnId; startX: number; startWidth: number } | null>(null);
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<(typeof PAGE_SIZE_OPTIONS)[number]>(PAGE_SIZE_OPTIONS[0]);
  const columnSettingsStorageKey = useMemo(() => getCurrentUserPreferenceStorageKey(WORK_ORDER_COLUMN_SETTINGS_PREFIX), []);
  const columnWidthStorageKey = useMemo(() => getCurrentUserPreferenceStorageKey(WORK_ORDER_COLUMN_WIDTHS_PREFIX), []);
  const [columnSettingsAnchor, setColumnSettingsAnchor] = useState<HTMLElement | null>(null);
  const [columnSettings, setColumnSettings] = useState<ListColumnSettings<WorkOrderColumnId>>(() => loadListColumnSettings(columnSettingsStorageKey, WORK_ORDER_COLUMNS, WORK_ORDER_COLUMN_SETTINGS_VERSION));
  const [columnWidths, setColumnWidths] = useState<WorkOrderColumnWidths>(() => loadColumnWidths(columnWidthStorageKey));
  const [keyword, setKeyword] = useState(() => readRecordLocation().keyword);
  const [submittedKeyword, setSubmittedKeyword] = useState(() => readRecordLocation().keyword);
  const [status, setStatus] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<WorkOrder | null>(null);
  const [objectOrder, setObjectOrder] = useState<WorkOrder | null>(null);
  const [detailOrder, setDetailOrder] = useState<WorkOrder | null>(null);
  const [detailTab, setDetailTab] = useState(0);
  const [cancelTarget, setCancelTarget] = useState<WorkOrder | null>(null);
  const [cancelObject, setCancelObject] = useState<ProductionObject | null>(null);
  const [editObject, setEditObject] = useState<ProductionObject | null>(null);
  const [endTarget, setEndTarget] = useState<WorkOrder | null>(null);
  const [endReason, setEndReason] = useState('');
  const [closeTarget, setCloseTarget] = useState<WorkOrder | null>(null);
  const [form, setForm] = useState<WorkOrderForm>(emptyForm);
  const [splitForm, setSplitForm] = useState({ processVersionId: '', targetQuantity: '', objectNo: '', remark: '', plannedStartAt: '', plannedEndAt: '' });
  const [splitTab, setSplitTab] = useState(0);
  const [objectListTab, setObjectListTab] = useState(0);
  const [batchAddType, setBatchAddType] = useState<'count' | 'quantity'>('count');
  const [processPreviewOpen, setProcessPreviewOpen] = useState(false);
  const [pendingObjects, setPendingObjects] = useState<Array<{ processVersionId: string; targetQuantity: string; objectNo: string; remark: string; plannedStartAt: string; plannedEndAt: string }>>([]);
  const importRequestId = useRef(0);
  useEffect(() => () => { importRequestId.current += 1; }, []);

  const visibleColumns = useMemo(() => columnSettings.order
    .map((id) => WORK_ORDER_COLUMNS.find((column) => column.id === id))
    .filter((column): column is WorkOrderColumn => Boolean(column))
    .filter((column) => !columnSettings.hidden.includes(column.id)), [columnSettings]);
  const hasVisibleStatusColumn = visibleColumns.some((column) => column.id === 'status');
  const resolvedColumnWidths = useMemo(() => Object.fromEntries(WORK_ORDER_COLUMNS.map((column) => [column.id, Math.max(column.minWidth, columnWidths[column.id] ?? column.width)])) as Record<WorkOrderColumnId, number>, [columnWidths]);
  const mainTableWidth = visibleColumns.reduce((total, column) => total + resolvedColumnWidths[column.id], WORK_ORDER_ACTION_COLUMN_WIDTH);

  useEffect(() => { localStorage.setItem(columnSettingsStorageKey, JSON.stringify(columnSettings)); }, [columnSettings, columnSettingsStorageKey]);
  useEffect(() => { localStorage.setItem(columnWidthStorageKey, JSON.stringify(columnWidths)); }, [columnWidthStorageKey, columnWidths]);

  const toggleColumnVisibility = (columnId: WorkOrderColumnId) => setColumnSettings((current) => {
    const isVisible = !current.hidden.includes(columnId);
    const visibleCount = current.order.length - current.hidden.length;
    if (isVisible && visibleCount <= 1) return current;
    return { ...current, hidden: isVisible ? [...current.hidden, columnId] : current.hidden.filter((id) => id !== columnId) };
  });
  const reorderColumns = (sourceId: WorkOrderColumnId, targetId: WorkOrderColumnId) => setColumnSettings((current) => reorderListColumns(WORK_ORDER_COLUMNS, current, sourceId, targetId));
  const beginColumnResize = (event: ReactPointerEvent<HTMLDivElement>, column: WorkOrderColumnId) => {
    event.preventDefault();
    event.stopPropagation();
    columnResizeRef.current = { id: column, startX: event.clientX, startWidth: resolvedColumnWidths[column] };
    const onMove = (moveEvent: PointerEvent) => {
      const resize = columnResizeRef.current;
      if (!resize) return;
      const definition = WORK_ORDER_COLUMNS.find((item) => item.id === resize.id);
      if (!definition) return;
      setColumnWidths((current) => ({ ...current, [resize.id]: Math.max(definition.minWidth, resize.startWidth + moveEvent.clientX - resize.startX) }));
    };
    const onUp = () => {
      columnResizeRef.current = null;
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerup', onUp);
    };
    window.addEventListener('pointermove', onMove);
    window.addEventListener('pointerup', onUp);
  };

  const orders = useQuery({ queryKey: ['work-orders', page, pageSize, submittedKeyword, status], queryFn: async () => (await listWorkOrders({ page, size: pageSize, keyword: submittedKeyword, status })).data.data as PageResult<WorkOrder>, placeholderData: keepPreviousData });
  useEffect(() => {
    if (!orders.isSuccess || orders.isPlaceholderData || orders.isFetching) return;
    const totalPages = orders.data?.totalPages ?? 0;
    const lastPage = Math.max(totalPages, 1);
    if (page > lastPage) setPage(lastPage);
  }, [orders.data?.totalPages, orders.isSuccess, orders.isPlaceholderData, orders.isFetching, page]);
  const products = useQuery({ queryKey: ['work-order-products'], queryFn: async () => (await getProductModelingProducts({ page: 1, size: 500, status: 'ACTIVE' })).data.data as PageResult<ProductModelSource> });
  const objects = useQuery({ queryKey: ['production-objects', objectOrder?.id], enabled: Boolean(objectOrder), queryFn: async () => (await listProductionObjects(objectOrder!.id)).data.data });
  const processOptions = useQuery({ queryKey: ['production-process-options', objectOrder?.id], enabled: Boolean(objectOrder), queryFn: async () => (await listProcessOptions(objectOrder!.id)).data.data });
  const selectedProcess = (processOptions.data ?? []).find((option) => option.id === splitForm.processVersionId);
  const previewOwner = selectedProcess?.processReference;
  const processPreviewQuery = useQuery({
    queryKey: ['production-process-preview', previewOwner?.ownerType, previewOwner?.ownerId],
    enabled: Boolean(processPreviewOpen && previewOwner),
    queryFn: async () => (await getProcessOwnerWorkspace(previewOwner!.ownerType as ProcessOwnerType, previewOwner!.ownerId)).data.data,
  });
  const auditQuery = useQuery({
    queryKey: ['work-order-audit', detailOrder?.id],
    enabled: detailOrder !== null,
    queryFn: async () => {
      const response = await getAuditLogs({ entityType: 'WORK_ORDER', entityId: detailOrder!.id, page: 1, size: 100 });
      return ((response.data.data as PageResult<AuditLogItem>).content ?? []);
    },
  });
  const auditRecords = useMemo(() => toAuditRecords(auditQuery.data), [auditQuery.data]);

  const save = useMutation({
    mutationFn: () => {
      const body = { orderNo: form.orderNo.trim(), orderNumber: form.orderNumber.trim() || null, productId: form.productId, plannedQuantity: Number(form.plannedQuantity), plannedStartAt: form.plannedStartAt || null, plannedEndAt: form.plannedEndAt || null, remark: form.remark.trim() };
      return editing ? updateWorkOrder(editing.id, body) : createWorkOrder(body);
    },
    onSuccess: () => { void client.invalidateQueries({ queryKey: ['work-orders'] }); setDialogOpen(false); showMessage(editing ? '工单更新成功' : '工单创建成功'); },
    onError: (error: Error) => showMessage(error.message || '工单保存失败', 'error'),
  });
  const cancel = useMutation({
    mutationFn: cancelWorkOrder,
    onSuccess: () => { void client.invalidateQueries({ queryKey: ['work-orders'] }); setCancelTarget(null); showMessage('工单已取消'); },
    onError: (error: any) => showMessage(error?.response?.data?.message || '工单取消失败', 'error'),
  });
  const split = useMutation({
    mutationFn: () => splitProductionObjectsBatch(objectOrder!.id, pendingObjects.map((item) => ({ processVersionId: item.processVersionId || null, targetQuantity: Number(item.targetQuantity), objectNo: item.objectNo.trim() || undefined, remark: item.remark.trim() || undefined, plannedStartAt: item.plannedStartAt || null, plannedEndAt: item.plannedEndAt || null }))),
    onSuccess: (response) => { const created = response.data.data[0]; setObjectOrder((current) => current ? { ...current, hasObjects: true, productionForm: created.objectType } : current); void client.invalidateQueries({ queryKey: ['production-objects', objectOrder?.id] }); void client.invalidateQueries({ queryKey: ['work-orders'] }); setPendingObjects([]); setObjectListTab(1); setSplitForm((current) => ({ ...current, processVersionId: created.processVersionId, targetQuantity: '', objectNo: '', remark: '', plannedStartAt: '', plannedEndAt: '' })); showMessage(`已添加 ${response.data.data.length} 个生产对象`); },
    onError: (error: unknown) => showMessage(error instanceof Error ? error.message : '生产对象创建失败', 'error'),
  });
  const objectAction = useMutation({
    mutationFn: ({ action, id }: { action: 'start' | 'complete' | 'cancel'; id: string }) => action === 'start' ? startProductionObject(id) : action === 'complete' ? completeProductionObject(id) : cancelProductionObject(id),
    onSuccess: () => { void client.invalidateQueries({ queryKey: ['production-objects', objectOrder?.id] }); void client.invalidateQueries({ queryKey: ['work-orders'] }); setCancelObject(null); showMessage('生产对象操作成功'); },
    onError: (error: any) => showMessage(error?.response?.data?.message || '生产对象操作失败', 'error'),
  });
  const close = useMutation({
    mutationFn: closeWorkOrder,
    onSuccess: () => { void client.invalidateQueries({ queryKey: ['work-orders'] }); setCloseTarget(null); showMessage('工单已关闭'); },
    onError: (error: any) => showMessage(error?.response?.data?.message || '工单关闭失败', 'error'),
  });

  const endOrder = useMutation({ mutationFn: () => endWorkOrder(endTarget!.id, endReason.trim()), onSuccess: () => { void client.invalidateQueries({ queryKey: ['work-orders'] }); setEndTarget(null); setEndReason(''); showMessage('工单已提前结束'); } });
  const showOrderTableState = orders.isLoading || orders.isError || !orders.data?.content.length;
  const selectedProduct = (products.data?.content ?? []).find((product) => String(product.id) === form.productId);
  const objectRows = objects.data ?? [];
  const allocated = Math.round(objectRows.filter((item) => item.status !== 'CANCELLED').reduce((sum, item) => sum + Number(item.targetQuantity), 0) * 10000) / 10000;
  const remaining = Math.max(0, Math.round((Number(objectOrder?.plannedQuantity || 0) - allocated) * 10000) / 10000);
  const pendingAllocated = Math.round(pendingObjects.reduce((sum, item) => sum + Number(item.targetQuantity || 0), 0) * 10000) / 10000;
  const availableRemaining = Math.max(0, Math.round((remaining - pendingAllocated) * 10000) / 10000);
  const canSplit = Boolean(objectOrder && ['CREATED', 'IN_PROCESS'].includes(objectOrder.status));
  const endBeforeStart = Boolean(form.plannedStartAt && form.plannedEndAt && form.plannedEndAt < form.plannedStartAt);
  const canSave = Boolean(form.orderNo.trim() && form.productId && Number(form.plannedQuantity) > 0 && !endBeforeStart && !save.isPending);

  const openCreate = () => { setEditing(null); setForm(emptyForm()); setDialogOpen(true); };
  const openEdit = (item: WorkOrder) => { setEditing(item); setForm({ orderNo: item.orderNo, orderNumber: item.orderNumber || '', productId: item.productId, plannedQuantity: String(item.plannedQuantity), plannedStartAt: toInputDateTime(item.plannedStartAt), plannedEndAt: toInputDateTime(item.plannedEndAt), remark: item.remark || '' }); setDialogOpen(true); };
  const openDetail = (item: WorkOrder) => { setDetailOrder(item); setDetailTab(0); };
  useRecordLocationAction((location) => {
    if (location.type !== 'production_object') return false;
    const order = orders.data?.content.find((item) => String(item.id) === location.id);
    if (!order) return false;
    setObjectOrder(order);
    return true;
  });
  const openObjects = (item: WorkOrder) => { importRequestId.current += 1; setObjectOrder(item); setObjectListTab(0); setProcessPreviewOpen(false); setSplitTab(0); setBatchAddType('count'); setPendingObjects([]); setSplitForm({ processVersionId: '', targetQuantity: '', objectNo: '', remark: '', plannedStartAt: '', plannedEndAt: '' }); };
  const closeObjects = () => { importRequestId.current += 1; setObjectOrder(null); };
  const selectedProductionMode = selectedProcess?.productionMode || objectOrder?.productionMode || '';
  const selectedProductionForm = selectedProcess?.productionForm || objectOrder?.productionForm || '';
  const isMassNonSn = selectedProductionMode === '量产' && ['BATCH', '批次'].includes(selectedProductionForm);
  const isSnProduction = selectedProductionForm === 'SN';
  const fixedProductionForm = objectOrder?.productionForm || (processOptions.data ?? []).find((option) => option.id === pendingObjects[0]?.processVersionId)?.productionForm;
  const batchInput = Number(splitForm.targetQuantity);
  const validBatchInput = Number.isFinite(batchInput) && batchInput > 0 && availableRemaining > 0 &&
    (isSnProduction || batchAddType === 'count'
      ? Number.isInteger(batchInput) && batchInput <= (isSnProduction ? availableRemaining : Math.round(availableRemaining * 10000))
      : Number(batchInput.toFixed(4)) === batchInput);
  const previewVersion = processPreviewQuery.data?.model?.versions.find((version) => version.id === splitForm.processVersionId);
  const incompleteProcessOptions = (processOptions.data ?? []).some(option => !option.processReference?.ownerName || !option.processReference?.ownerId);
  const splitDataReady = objects.isSuccess && !objects.isFetching && processOptions.isSuccess && !processOptions.isFetching && !incompleteProcessOptions;
  const importContext = { order: objectOrder, processVersionId: splitForm.processVersionId, pendingObjects, objectRows, availableRemaining, ready: splitDataReady && canSplit && !split.isPending };
  const currentImportContext = useRef(importContext);
  currentImportContext.current = importContext;
  const addPendingObject = () => {
    const targetQuantity = isSnProduction ? 1 : Number(splitForm.targetQuantity);
    if (!splitDataReady || !splitForm.processVersionId || !Number.isFinite(targetQuantity) || targetQuantity <= 0 || targetQuantity > availableRemaining) return;
    setObjectListTab(0);
    if (isSnProduction && !splitForm.objectNo.trim()) { showMessage('请输入SN编号', 'error'); return; }
    if (splitForm.plannedStartAt && splitForm.plannedEndAt && splitForm.plannedEndAt < splitForm.plannedStartAt) { showMessage('计划结束时间不能早于计划开始时间', 'error'); return; }
    if (splitForm.objectNo.trim() && (pendingObjects.some((item) => item.objectNo.trim() === splitForm.objectNo.trim()) || objectRows.some((item) => item.objectNo.trim() === splitForm.objectNo.trim()))) { showMessage('待添加清单或已拆分清单中存在重复的SN/批次号', 'error'); return; }
    setPendingObjects((current) => [...current, { ...splitForm, targetQuantity: String(targetQuantity) }]);
    setSplitForm((current) => ({ ...current, targetQuantity: '', objectNo: '', remark: '', plannedStartAt: '', plannedEndAt: '' }));
  };
  const addPendingBatch = () => {
    const input = Number(splitForm.targetQuantity);
    if (!splitDataReady || !splitForm.processVersionId || !validBatchInput) return;
    setObjectListTab(0);
    const count = isSnProduction || batchAddType === 'count' ? input : Math.ceil(Math.round(availableRemaining * 10000) / Math.round(input * 10000));
    const baseQuantity = batchAddType === 'quantity' && !isSnProduction ? input : Math.floor(Math.round(availableRemaining * 10000) / count) / 10000;
    const next = Array.from({ length: count }, (_, index) => ({
      ...splitForm,
      targetQuantity: isSnProduction ? '1' : String(index === count - 1 ? Math.round((availableRemaining - (baseQuantity * (count - 1))) * 10000) / 10000 : baseQuantity),
      objectNo: splitForm.objectNo.trim() ? `${splitForm.objectNo.trim()}-${String(index + 1).padStart(3, '0')}` : '',
    }));
    const duplicateObject = next.find((item) => item.objectNo && (pendingObjects.some((existing) => existing.objectNo.trim() === item.objectNo) || objectRows.some((existing) => existing.objectNo.trim() === item.objectNo)));
    if (duplicateObject) { showMessage('待添加清单或已拆分清单中存在重复的SN/批次号', 'error'); return; }
    setPendingObjects((current) => [...current, ...next]);
    setSplitForm((current) => ({ ...current, targetQuantity: '', objectNo: '', remark: '', plannedStartAt: '', plannedEndAt: '' }));
  };
  const importPendingObjects = async (file?: File) => {
    if (!file || !importContext.ready || !importContext.processVersionId) return;
    const requestId = ++importRequestId.current;
    try {
      const bytes = await file.arrayBuffer();
      if (requestId !== importRequestId.current) return;
      const current = currentImportContext.current;
      if (!current.ready || current.order !== importContext.order || current.processVersionId !== importContext.processVersionId || current.pendingObjects !== importContext.pendingObjects || current.objectRows !== importContext.objectRows || current.availableRemaining !== importContext.availableRemaining) {
        throw new Error('导入期间配置或清单已变化，请重新选择文件');
      }
      const workbook = XLSX.read(bytes, { type: 'array', cellDates: true, codepage: 65001 });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const matrix = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, defval: '', raw: true });
      const normalizeHeader = (value: unknown) => String(value ?? '').replace(/^\ufeff/, '').trim().toLowerCase();
      const objectHeaderNames = isSnProduction ? ['sn', 'sn号', 'sn编号', '序列号', '对象编号', 'objectno'] : ['批次号', '批次编号', '对象编号', 'objectno', 'batchno'];
      const headerIndex = matrix.findIndex((row) => row.some((value) => objectHeaderNames.includes(normalizeHeader(value))));
      if (headerIndex < 0) throw new Error(`未识别到有效数据，请使用包含“${isSnProduction ? 'SN编号' : '批次号'}”的 CSV、XLS 或 XLSX 文件`);
      const headerRow = matrix[headerIndex] ?? [];
      const headerNames = headerRow.map((value) => String(value ?? '').replace(/^\ufeff/, '').trim());
      const rows = matrix.slice(headerIndex + 1)
        .filter((values) => values.some((value) => String(value ?? '').trim() !== ''))
        .map((values) => headerNames.reduce<Record<string, unknown>>((record, header, columnIndex) => {
          if (header) record[header] = values[columnIndex] ?? '';
          return record;
        }, {}));
      const normalizeDateTime = (value: unknown) => {
        if (value instanceof Date) return toInputDateTime(value.toISOString());
        const text = String(value ?? '').trim();
        if (!text) return '';
        const normalized = text.replace(/年|月/g, '-').replace(/日/g, '').replace(' ', 'T');
        return /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(normalized) ? `${normalized}:00` : normalized;
      };
      const get = (row: Record<string, unknown>, names: string[]) => { const key = Object.keys(row).find((item) => names.includes(item.trim().toLowerCase())); return key ? String(row[key] ?? '').trim() : ''; };
      const getDate = (row: Record<string, unknown>, names: string[]) => { const key = Object.keys(row).find((item) => names.includes(item.trim().toLowerCase())); return key ? normalizeDateTime(row[key]) : ''; };
      const parsedRows = rows.map((row, index) => { const quantity = get(row, ['数量', '目标数量', 'targetquantity', 'quantity']); return { rowNumber: headerIndex + index + 2, processVersionId: splitForm.processVersionId, targetQuantity: isSnProduction ? (quantity || '1') : quantity, objectNo: get(row, objectHeaderNames), remark: get(row, ['备注', 'remark']), plannedStartAt: getDate(row, ['计划开始时间', 'plannedstartat']), plannedEndAt: getDate(row, ['计划结束时间', 'plannedendat']) }; });
      const invalidQuantityRows = parsedRows.filter((row) => !Number.isFinite(Number(row.targetQuantity)) || Number(row.targetQuantity) <= 0).map((row) => row.rowNumber);
      if (invalidQuantityRows.length > 0) throw new Error(`导入失败：第 ${invalidQuantityRows.join('、')} 行数量无效，请修正后重新导入`);
      const excessPrecisionRows = parsedRows.filter(row => Number(Number(row.targetQuantity).toFixed(4)) !== Number(row.targetQuantity)).map(row => row.rowNumber);
      if (excessPrecisionRows.length > 0) throw new Error(`导入失败：第 ${excessPrecisionRows.join('、')} 行数量最多4位小数`);
      const invalidSnQuantityRows = isSnProduction ? parsedRows.filter((row) => Number(row.targetQuantity) !== 1).map((row) => row.rowNumber) : [];
      if (invalidSnQuantityRows.length > 0) throw new Error(`导入失败：SN生产形态第 ${invalidSnQuantityRows.join('、')} 行数量必须为1`);
      const invalidObjectRows = parsedRows.filter((row) => !row.objectNo).map((row) => row.rowNumber);
      if (invalidObjectRows.length > 0) throw new Error(`导入失败：第 ${invalidObjectRows.join('、')} 行${isSnProduction ? 'SN编号' : '批次号'}不能为空，请修正后重新导入`);
      const duplicateObjectRows = parsedRows.filter((row, index) => parsedRows.findIndex((item) => item.objectNo === row.objectNo) !== index || pendingObjects.some((item) => item.objectNo.trim() === row.objectNo) || objectRows.some((item) => item.objectNo.trim() === row.objectNo)).map((row) => row.rowNumber);
      if (duplicateObjectRows.length > 0) throw new Error(`导入失败：第 ${duplicateObjectRows.join('、')} 行${isSnProduction ? 'SN编号' : '批次号'}重复`);
      const invalidDateRows = parsedRows.filter((row) => row.plannedStartAt && row.plannedEndAt && row.plannedEndAt < row.plannedStartAt).map((row) => row.rowNumber);
      if (invalidDateRows.length > 0) throw new Error(`导入失败：第 ${invalidDateRows.join('、')} 行计划结束时间早于开始时间`);
      const imported = parsedRows;
      if (imported.length === 0) throw new Error(`未识别到有效数据，请使用包含“${isSnProduction ? 'SN编号' : '批次号'}”的 CSV、XLS 或 XLSX 文件`);
      const importedQuantityUnits = imported.reduce((sum, row) => sum + Math.round(Number(row.targetQuantity) * 10000), 0);
      if (importedQuantityUnits > Math.round(availableRemaining * 10000)) throw new Error(`导入失败：导入数量合计 ${importedQuantityUnits / 10000} 超出剩余可分配数量 ${availableRemaining}`);
      setPendingObjects((current) => [...current, ...imported]);
      setSplitTab(1);
      showMessage(`已导入 ${imported.length} 条待添加记录`);
      setObjectListTab(0);
    } catch (error) { if (requestId === importRequestId.current) showMessage(error instanceof Error ? error.message : '批次导入失败', 'error'); }
  };
  const downloadImportTemplate = async () => {
    const serial = isSnProduction;
    const sheetName = serial ? 'SN导入模板' : '批次导入模板';
    const filename = serial ? '生产SN导入模板.xlsx' : '生产批次导入模板.xlsx';
    const headers = serial ? ['SN编号', '计划开始时间', '计划结束时间'] : ['批次号', '数量', '计划开始时间', '计划结束时间', '备注'];
    const example = serial ? ['SN-001', '2026-08-29 08:00', '2026-08-29 18:00'] : ['BATCH-001', 1, '2026-08-29 08:00', '2026-08-29 18:00', '可为空'];
    const requiredColumns = new Set(serial ? ['SN编号'] : ['批次号', '数量']);
    const workbook = new ExcelJS.Workbook();
    workbook.creator = 'eDHR';
    workbook.created = new Date();
    const worksheet = workbook.addWorksheet(sheetName, { properties: { tabColor: { argb: 'FF2F75B5' } }, views: [{ showGridLines: false }] });
    worksheet.columns = headers.map((header) => ({ header, key: header, width: header === '备注' ? 28 : header.includes('时间') ? 22 : 18 }));
    worksheet.mergeCells(1, 1, 1, headers.length);
    worksheet.getCell('A1').value = serial ? '生产 SN 导入模板' : '生产批次导入模板';
    worksheet.mergeCells(2, 1, 2, headers.length);
    worksheet.getCell('A2').value = `请按列填写${serial ? ' SN 编号' : '批次号、数量'}；红色表头为必填字段，示例数据请删除后再导入。`;
    worksheet.mergeCells(3, 1, 3, headers.length);
    worksheet.getCell('A3').value = `示例：${serial ? 'SN编号=SN-001；计划开始时间=2026-08-29 08:00；计划结束时间=2026-08-29 18:00' : '批次号=BATCH-001；数量=1；计划开始时间=2026-08-29 08:00；计划结束时间=2026-08-29 18:00；备注=可为空'}`;
    headers.forEach((header, index) => {
      worksheet.getCell(5, index + 1).value = header;
      worksheet.getCell(6, index + 1).value = example[index];
    });
    for (let row = 7; row <= 25; row += 1) {
      headers.forEach((_, index) => { worksheet.getCell(row, index + 1).value = ''; });
    }
    const border = { style: 'thin' as const, color: { argb: 'FFD9E2F3' } };
    const bodyBorder = { top: border, left: border, bottom: border, right: border };
    worksheet.getRow(1).height = 30;
    worksheet.getRow(2).height = 24;
    worksheet.getRow(3).height = 30;
    worksheet.getRow(5).height = 28;
    worksheet.getRow(6).height = 24;
    worksheet.getCell('A1').font = { name: 'Arial', size: 16, bold: true, color: { argb: 'FF1F4E78' } };
    worksheet.getCell('A1').alignment = { horizontal: 'left', vertical: 'middle' };
    worksheet.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFEAF3F8' } };
    [2, 3].forEach((rowNumber) => {
      const cell = worksheet.getCell(rowNumber, 1);
      cell.font = { name: 'Arial', size: 10, color: { argb: 'FF5B6573' } };
      cell.alignment = { horizontal: 'left', vertical: 'middle', wrapText: true };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: rowNumber === 2 ? 'FFF5F8FB' : 'FFFFF8E8' } };
    });
    headers.forEach((header, index) => {
      const cell = worksheet.getCell(5, index + 1);
      cell.font = { name: 'Arial', size: 10, bold: true, color: { argb: requiredColumns.has(header) ? 'FFC62828' : 'FF1F2937' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: requiredColumns.has(header) ? 'FFFFE8E8' : 'FFE8F1F8' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
      cell.border = bodyBorder;
    });
    for (let row = 6; row <= 25; row += 1) {
      headers.forEach((_, index) => {
        const cell = worksheet.getCell(row, index + 1);
        cell.font = { name: 'Arial', size: 10, color: { argb: row === 6 ? 'FF5B6573' : 'FF1F2937' }, italic: row === 6 };
        cell.alignment = { vertical: 'middle', horizontal: index === headers.length - 1 ? 'left' : 'center' };
        cell.border = bodyBorder;
        if (row === 6) cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFFBF0' } };
      });
    }
    worksheet.autoFilter = { from: { row: 5, column: 1 }, to: { row: 25, column: headers.length } };
    worksheet.views = [{ state: 'frozen', ySplit: 5, showGridLines: false }];
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    window.setTimeout(() => {
      URL.revokeObjectURL(link.href);
      link.remove();
    }, 0);
  };
  const processVersionFor = (id: string) => (processOptions.data ?? []).find((option) => option.id === id)?.version || '-';
  const pendingTable = <TableContainer sx={{ maxHeight: { xs: 260, lg: 330 }, overflow: 'auto' }}><Table stickyHeader size="small" sx={{ minWidth: 610 }}><TableHead><TableRow sx={{ '& .MuiTableCell-root': tableHeaderCellSx }}>{[isSnProduction ? 'SN编号' : '批次号', '制程版本', '数量', '计划时间', '备注', '操作'].map((label) => <TableCell key={label} align={label === '操作' ? 'center' : undefined} sx={label === '操作' ? { width: PENDING_OBJECT_ACTION_COLUMN_WIDTH, minWidth: PENDING_OBJECT_ACTION_COLUMN_WIDTH, maxWidth: PENDING_OBJECT_ACTION_COLUMN_WIDTH } : undefined}>{label}</TableCell>)}</TableRow></TableHead><TableBody>{pendingObjects.length === 0 ? <TableRow><TableStateCell colSpan={6} align="center" sx={{ height: 120, color: '#909399' }}>从上方添加{isSnProduction ? ' SN' : '批次'}，确认清单后统一提交</TableStateCell></TableRow> : pendingObjects.map((item, index) => <TableRow key={`${item.objectNo}-${index}`} sx={tableRowSx}><TableCell>{item.objectNo || '系统生成'}</TableCell><TableCell>{processVersionFor(item.processVersionId)}</TableCell><TableCell>{item.targetQuantity}</TableCell><TableCell sx={{ whiteSpace: 'nowrap', fontSize: 12 }}><Box>{item.plannedStartAt ? formatDateTime(item.plannedStartAt) : '未设开始'}</Box><Box sx={{ color: 'text.secondary' }}>{item.plannedEndAt ? formatDateTime(item.plannedEndAt) : '未设结束'}</Box></TableCell><TableCell sx={{ maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.remark || '-'}</TableCell><TableCell align="center" sx={{ width: PENDING_OBJECT_ACTION_COLUMN_WIDTH, minWidth: PENDING_OBJECT_ACTION_COLUMN_WIDTH, maxWidth: PENDING_OBJECT_ACTION_COLUMN_WIDTH }}><Tooltip title="移除" arrow><IconButton size="small" aria-label="移除待添加批次" onClick={() => setPendingObjects((current) => current.filter((_, rowIndex) => rowIndex !== index))}><DeleteOutline fontSize="small" /></IconButton></Tooltip></TableCell></TableRow>)}</TableBody></Table></TableContainer>;
  const objectTable = <TableContainer sx={{ maxHeight: { xs: 360, lg: 460 }, overflow: 'auto' }}><Table stickyHeader size="small" sx={{ minWidth: 1060 }}><TableHead><TableRow sx={{ '& .MuiTableCell-root': tableHeaderCellSx }}>{[isSnProduction ? 'SN编号' : '批次号', '状态', '制程版本', '数量', '累计产出', '良品', 'NG', '产品报废登记', '计划开始', '计划结束', '备注', '操作'].map((label) => <TableCell key={label}>{label}</TableCell>)}</TableRow></TableHead><TableBody>{objects.isLoading ? <TableRow><TableStateCell colSpan={12} align="center" sx={{ height: 160 }}><CircularProgress size={24} /></TableStateCell></TableRow> : objects.isError ? <TableRow><TableStateCell colSpan={11} align="center" sx={{ height: 160, color: '#c62828' }}>生产对象加载失败</TableStateCell></TableRow> : objectRows.length === 0 ? <TableRow><TableStateCell colSpan={11} align="center" sx={{ height: 160, color: '#909399' }}>暂无已拆分{isSnProduction ? 'SN' : '批次'}</TableStateCell></TableRow> : objectRows.map((item) => <TableRow data-record-id={item.id} key={item.id} sx={tableRowSx}><TableCell>{item.objectNo}</TableCell><TableCell>{statusBadge(item.status, objectStatusLabels)}</TableCell><TableCell>{item.processVersion}</TableCell><TableCell>{item.targetQuantity}</TableCell><TableCell><ProductionOutputValue output={item.output} /></TableCell><TableCell><ProductionOutputValue output={item.output?.quality?.goodQuantity} label="批次良品" /></TableCell><TableCell><ProductionOutputValue output={item.output?.quality?.ngQuantity} label="批次不良品" /></TableCell><TableCell><ProductionOutputValue output={item.output?.quality?.scrapQuantity} label="产品报废登记" /></TableCell><TableCell>{item.plannedStartAt ? formatDateTime(item.plannedStartAt) : '-'}</TableCell><TableCell>{item.plannedEndAt ? formatDateTime(item.plannedEndAt) : '-'}</TableCell><TableCell sx={{ maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.remark || '-'}</TableCell><TableCell>{canSplit && item.status === 'CREATED' && <Stack direction="row"><Tooltip title="修改批次配置"><IconButton size="small" aria-label={`修改批次 ${item.objectNo}`} onClick={() => setEditObject(item)}><Edit fontSize="small" /></IconButton></Tooltip><Tooltip title="取消批次"><IconButton size="small" aria-label={`取消批次 ${item.objectNo}`} onClick={() => setCancelObject(item)}><Cancel fontSize="small" /></IconButton></Tooltip></Stack>}</TableCell></TableRow>)}</TableBody></Table></TableContainer>;
  const selectProduct = (productId: string) => setForm((current) => ({ ...current, productId }));
  const submitSearch = () => { setPage(1); setSubmittedKeyword(keyword.trim()); };
  const renderWorkOrderCell = (item: WorkOrder, column: WorkOrderColumn) => {
    const width = resolvedColumnWidths[column.id];
    const commonSx = { width, minWidth: width, maxWidth: width, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' as const };
    switch (column.id) {
      case 'orderNo': return <TableCell sx={commonSx} title={item.orderNo}>{item.orderNo}</TableCell>;
      case 'product': return <TableCell sx={commonSx} title={`${item.productName}（${item.productCode}）`}><Typography variant="body2" noWrap>{item.productName}</Typography><Typography variant="caption" display="block" color="text.secondary" noWrap>{item.productCode}</Typography></TableCell>;
      case 'productionMode': return <TableCell sx={commonSx}>{item.productionMode || '-'}</TableCell>;
      case 'productionForm': return <TableCell sx={commonSx}>{formLabels[item.productionForm || ''] || item.productionForm || '-'}</TableCell>;
      case 'plannedQuantity': return <TableCell sx={commonSx}>{item.plannedQuantity}</TableCell>;
      case 'output': return <TableCell sx={commonSx}><ProductionOutputValue output={item.output} /></TableCell>;
      case 'createdAt': return <TableCell sx={commonSx}>{formatDateTime(item.createdAt)}</TableCell>;
      case 'status': return <TableCell sx={{ ...commonSx, ...getStatusColumnSx(width, 'body') }}>{statusBadge(item.status, statusLabels)}</TableCell>;
      default: return null;
    }
  };

  return <Box sx={{ minWidth: 0, height: { xs: 'auto', lg: 'calc(100vh - 150px)' }, display: 'flex', flexDirection: 'column', gap: 1.5, minHeight: 0, overflow: 'hidden' }}>
    <Box sx={{ flex: '0 0 auto', border: '1px solid #e4e7ed', borderRadius: 1, bgcolor: '#fff', p: 2 }}><Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'repeat(3, minmax(0, 1fr))' }, gap: 1.5, alignItems: 'center' }}>
      <TextField fullWidth size="small" label="工单号/产品名称/编码" placeholder="请输入" value={keyword} onChange={(event) => setKeyword(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') submitSearch(); }} sx={{ '& .MuiInputBase-root': { height: 40 }, '& .MuiInputBase-input': { boxSizing: 'border-box' } }} InputProps={{ startAdornment: <InputAdornment position="start"><Search fontSize="small" /></InputAdornment> }} />
      <TextField select fullWidth size="small" label="状态" value={status} onChange={(event) => { setPage(1); setStatus(event.target.value); }} sx={{ '& .MuiInputBase-root': { height: 40 } }}><MenuItem value="">全部</MenuItem>{Object.entries(statusLabels).map(([value, label]) => <MenuItem key={value} value={value}>{label}</MenuItem>)}</TextField>
      <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="flex-end"><Button size="small" sx={{ height: 40, width: 80, minWidth: 80 }} variant="outlined" startIcon={<RestartAlt />} onClick={() => { setKeyword(''); setSubmittedKeyword(''); setStatus(''); setPage(1); }}>重置</Button><Button size="small" sx={{ height: 40, width: 80, minWidth: 80 }} variant="contained" startIcon={<Search />} onClick={submitSearch}>查询</Button></Stack>
    </Box></Box>
    <Box sx={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, border: '1px solid #e4e7ed', borderRadius: 1, bgcolor: '#fff', overflow: 'hidden' }}>
      <Box sx={{ flex: '0 0 auto', px: 2, py: 0.75, minHeight: 48, borderBottom: '1px solid #ebeef5', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Tooltip title="字段设置" arrow><IconButton size="small" aria-label="字段设置" onClick={(event) => setColumnSettingsAnchor(event.currentTarget)} sx={{ width: 36, height: 36, border: '1px solid #e4e7ed', borderRadius: 1, color: '#606266', bgcolor: '#fff', '&:hover': { color: '#1890ff', bgcolor: '#e8f4ff' } }}><Box aria-hidden="true" sx={{ position: 'relative', width: 22, height: 22, display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}><ViewColumnRounded sx={{ fontSize: 21 }} /><TuneRounded sx={{ position: 'absolute', right: -3, bottom: -2, fontSize: 13, p: '1px', borderRadius: '50%', bgcolor: '#fff', boxShadow: '0 0 0 1px #fff' }} /></Box></IconButton></Tooltip>
        <Button variant="contained" size="small" startIcon={<Add />} onClick={openCreate}>新建工单</Button>
      </Box>
      <ListColumnSettingsPopover anchorEl={columnSettingsAnchor} columns={WORK_ORDER_COLUMNS} settings={columnSettings} onClose={() => setColumnSettingsAnchor(null)} onToggle={toggleColumnVisibility} onReorder={reorderColumns} />
      <ListTableShell sx={{ flex: 1, minHeight: 0, overflow: 'auto' }}><Table stickyHeader size="small" sx={{ tableLayout: 'fixed', minWidth: mainTableWidth, width: '100%', height: showOrderTableState ? '100%' : 'auto' }}>
        <colgroup>{visibleColumns.map((column) => <col key={column.id} style={{ width: resolvedColumnWidths[column.id] }} />)}<col style={{ width: WORK_ORDER_ACTION_COLUMN_WIDTH }} /></colgroup>
        <TableHead sx={{ height: 48 }}><TableRow sx={{ '& .MuiTableCell-root': tableHeaderCellSx }}>{visibleColumns.map((column) => <TableCell key={column.id} sx={{ ...tableHeaderCellSx, width: resolvedColumnWidths[column.id], minWidth: resolvedColumnWidths[column.id], maxWidth: resolvedColumnWidths[column.id], ...(column.id === 'status' ? getStatusColumnSx(resolvedColumnWidths[column.id], 'head') : {}), top: 0, zIndex: column.id === 'status' ? 10 : 5, position: 'sticky' }}><Box sx={{ position: 'relative', pr: 1 }}>{column.label}<Box aria-label={`调整${column.label}列宽`} onPointerDown={(event) => beginColumnResize(event, column.id)} sx={{ ...listColumnResizeHandleSx, right: -8 }} /></Box></TableCell>)}<TableCell align="center" sx={{ ...tableHeaderCellSx, ...getOperationColumnSx('head', hasVisibleStatusColumn) }}>操作</TableCell></TableRow></TableHead>
        <TableBody>{orders.isLoading ? <TableRow><TableStateCell colSpan={visibleColumns.length + 1} align="center" sx={{ color: '#909399' }}><CircularProgress size={24} /></TableStateCell></TableRow> : orders.isError ? <TableRow><TableStateCell colSpan={visibleColumns.length + 1} align="center" sx={{ color: '#c62828' }}>工单数据加载失败</TableStateCell></TableRow> : (orders.data?.content ?? []).length === 0 ? <TableRow><TableStateCell colSpan={visibleColumns.length + 1} align="center" sx={{ color: '#909399' }}>暂无数据</TableStateCell></TableRow> : orders.data!.content.map((item) => <TableRow data-record-id={item.id} key={item.id} hover tabIndex={0} onClick={() => openDetail(item)} onKeyDown={(event) => { if (event.key === 'Enter' || event.key === ' ') openDetail(item); }} sx={{ ...tableRowSx, cursor: 'pointer' }}>
          {visibleColumns.map((column) => <Fragment key={column.id}>{renderWorkOrderCell(item, column)}</Fragment>)}
          <TableCell align="center" sx={getOperationColumnSx('body', hasVisibleStatusColumn)} onClick={(event) => event.stopPropagation()}>
            <Tooltip title="生产对象" arrow><IconButton size="small" aria-label="生产对象" onClick={() => openObjects(item)}><ViewList fontSize="small" /></IconButton></Tooltip>
            {item.status === 'CREATED' ? <Tooltip title="编辑" arrow><IconButton size="small" aria-label="编辑" onClick={() => openEdit(item)}><Edit fontSize="small" /></IconButton></Tooltip> : <Tooltip title="编辑（仅已创建工单可用）" arrow><span><IconButton size="small" disabled aria-label="编辑暂不可用"><Edit fontSize="small" /></IconButton></span></Tooltip>}
            {['CREATED', 'IN_PROCESS'].includes(item.status) && <Tooltip title="提前结束工单"><IconButton size="small" aria-label="提前结束工单" onClick={() => { setEndTarget(item); setEndReason(''); endOrder.reset(); }}><StopCircleOutlined fontSize="small" /></IconButton></Tooltip>}
            {item.status === 'CREATED' && !item.hasObjects ? <Tooltip title="取消" arrow><IconButton size="small" aria-label="取消" color="error" onClick={() => setCancelTarget(item)}><Cancel fontSize="small" /></IconButton></Tooltip> : item.status === 'COMPLETED' ? <Tooltip title="关闭" arrow><IconButton size="small" aria-label="关闭" onClick={() => setCloseTarget(item)}><Close fontSize="small" /></IconButton></Tooltip> : <Tooltip title="取消（仅已创建工单可用）" arrow><span><IconButton size="small" disabled aria-label="取消暂不可用"><Cancel fontSize="small" /></IconButton></span></Tooltip>}
          </TableCell>
        </TableRow>)}</TableBody>
      </Table></ListTableShell>
      <Box sx={{ flex: '0 0 auto', minHeight: 56, px: 2, borderTop: '1px solid #ebeef5', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 2 }}><Typography variant="body2" sx={{ color: '#606266', whiteSpace: 'nowrap' }}>共 {orders.data?.totalElements ?? 0} 条数据</Typography><Stack direction="row" spacing={1.5} alignItems="center" sx={{ marginLeft: 'auto' }}><Pagination size="small" count={Math.max(orders.data?.totalPages ?? page, 1)} page={page} onChange={(_, value) => setPage(value)} /><TextField select size="small" value={pageSize} onChange={(event) => { setPageSize(Number(event.target.value) as (typeof PAGE_SIZE_OPTIONS)[number]); setPage(1); }} sx={{ width: 112 }} inputProps={{ 'aria-label': '每页条数' }}>{PAGE_SIZE_OPTIONS.map((option) => <MenuItem key={option} value={option}>{option} 条/页</MenuItem>)}</TextField></Stack></Box>
    </Box>

    <AppDialog variant="form" open={dialogOpen} onClose={save.isPending ? undefined : () => setDialogOpen(false)} maxWidth="md" fullWidth>
      <DialogTitle>{editing ? '编辑工单' : '新建工单'}</DialogTitle>
      <DialogContent dividers>
        <Stack spacing={1.5}>
          <FormSection title="基础信息">
            <FormDialogFieldGrid>
              <TextField autoFocus={!editing} required fullWidth size="small" label="工单编号" disabled={Boolean(editing?.hasObjects)} value={form.orderNo} onChange={(event) => setForm({ ...form, orderNo: event.target.value })} />
              <TextField fullWidth size="small" label="订单编号" value={form.orderNumber} onChange={(event) => setForm({ ...form, orderNumber: event.target.value })} />
              <TextField select required fullWidth size="small" label="产品" disabled={Boolean(editing?.hasObjects)} value={form.productId} onChange={(event) => selectProduct(event.target.value)} SelectProps={{ renderValue: () => selectedProduct ? `${selectedProduct.name}（${selectedProduct.code}）` : '' }} className={form.productId ? 'has-value' : undefined} sx={clearableSelectSx} InputProps={{ endAdornment: form.productId && !editing?.hasObjects ? <InputAdornment position="end" className="select-clear-adornment"><Tooltip title="清除产品" arrow><IconButton className="select-clear-button" size="small" aria-label="清除产品" onMouseDown={(event) => event.stopPropagation()} onClick={(event) => { event.stopPropagation(); selectProduct(''); }}><Clear fontSize="small" /></IconButton></Tooltip></InputAdornment> : undefined }}>
                {(products.data?.content ?? []).map((product) => <MenuItem key={product.id} value={String(product.id)}>{product.name}（{product.code}）</MenuItem>)}
              </TextField>
            </FormDialogFieldGrid>
          </FormSection>
          <FormSection title="计划信息">
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))' }, gap: 1.5 }}>
              <TextField required fullWidth size="small" label="计划数量" type="number" inputProps={{ min: 0, step: 'any' }} value={form.plannedQuantity} onChange={(event) => setForm({ ...form, plannedQuantity: event.target.value })} sx={{ gridColumn: { sm: '1 / -1' } }} />
              <TextField fullWidth size="small" label="计划开始时间" type="datetime-local" InputLabelProps={{ shrink: true }} value={form.plannedStartAt} onChange={(event) => setForm({ ...form, plannedStartAt: event.target.value })} />
              <TextField fullWidth size="small" label="计划结束时间" type="datetime-local" InputLabelProps={{ shrink: true }} error={endBeforeStart} helperText={endBeforeStart ? '计划结束时间不能早于计划开始时间' : undefined} value={form.plannedEndAt} onChange={(event) => setForm({ ...form, plannedEndAt: event.target.value })} />
            </Box>
          </FormSection>
          <FormSection title="备注">
            <TextField fullWidth size="small" label="备注" placeholder="请输入备注（可选）" multiline minRows={3} value={form.remark} onChange={(event) => setForm({ ...form, remark: event.target.value })} />
          </FormSection>
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, py: 1.5 }}><Button onClick={() => setDialogOpen(false)} disabled={save.isPending}>取消</Button><Button variant="contained" onClick={() => save.mutate()} disabled={!canSave}>{save.isPending ? '保存中...' : '保存'}</Button></DialogActions>
    </AppDialog>

    <AppDialog open={objectOrder !== null} onClose={split.isPending ? undefined : closeObjects} maxWidth="xl" fullWidth PaperProps={{ sx: { maxWidth: 1280, maxHeight: '94dvh' } }}>
      <DialogTitle>{canSplit ? '生产对象管理' : '生产对象查看'}</DialogTitle>
      <DialogContent dividers sx={{ p: { xs: 2, sm: 3 }, bgcolor: 'background.paper' }}>{objectOrder && <Stack spacing={2.5}>
        <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', md: 'minmax(0, 1fr) auto' }, gap: 2, alignItems: 'center' }}>
          <Box sx={{ minWidth: 0 }}><Typography sx={{ fontSize: 18, fontWeight: 600 }}>{objectOrder.orderNo}</Typography><Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, overflowWrap: 'anywhere' }}>{objectOrder.productName}（{objectOrder.productCode}）</Typography></Box>
          <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0, 1fr))', gap: { xs: 1, sm: 3 }, fontVariantNumeric: 'tabular-nums' }}>{[['计划数量', objectOrder.plannedQuantity], ['已分配', allocated], ['待提交', pendingAllocated], ['还可分配', availableRemaining]].map(([label, value]) => <Box key={label}><Typography variant="caption" color="text.secondary">{label}</Typography><Typography sx={{ fontSize: 22, fontWeight: 600, color: label === '还可分配' ? 'primary.main' : 'text.primary' }}>{objects.isSuccess ? value : '-'}</Typography></Box>)}</Box>
        </Box>

        {canSplit && <Box sx={{ border: '1px solid', borderColor: 'divider', borderRadius: 1, overflow: 'hidden' }}>
          <Box sx={{ px: 2, bgcolor: '#f8fafc', borderBottom: '1px solid', borderColor: 'divider', display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: 1 }}>
            <Tabs value={splitTab} onChange={(_, value) => setSplitTab(value)} aria-label="添加方式" sx={{ minHeight: 44, '& .MuiTab-root': { minHeight: 44, px: 1.5, py: 1 } }}>
              <Tab label="批量添加" /><Tab label={isSnProduction ? '导入 SN' : '导入批次'} /><Tab label="手动添加" />
            </Tabs>
            {splitTab === 0 && !isSnProduction && <RadioGroup row value={batchAddType} onChange={event => setBatchAddType(event.target.value as 'count' | 'quantity')} sx={{ '& .MuiFormControlLabel-label': { fontSize: 13 } }}><FormControlLabel value="count" control={<Radio size="small" />} label="按批次数" /><FormControlLabel value="quantity" control={<Radio size="small" />} label="按每批数量" /></RadioGroup>}
          </Box>
          <Stack spacing={1.5} sx={{ p: 2 }}>
            {(processOptions.isError || objects.isError || incompleteProcessOptions) && <Alert severity="error" action={<Button onClick={() => { void processOptions.refetch(); void objects.refetch(); }}>重试</Button>}>{incompleteProcessOptions ? '制程数据不完整，请确认服务已更新后重试。' : '制程或批次数量加载失败，暂时无法添加。'}</Alert>}
            <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr', sm: 'repeat(2, minmax(0, 1fr))', md: 'repeat(4, minmax(0, 1fr))' }, gap: 1.5, alignItems: 'start' }}>
              <Box sx={{ gridColumn: { sm: '1 / -1', md: 'span 2' }, minWidth: 0 }}>
                <TextField select fullWidth size="small" label="制程版本" InputLabelProps={{ shrink: true }} value={splitForm.processVersionId} disabled={!splitDataReady || split.isPending} onChange={event => setSplitForm({ ...splitForm, processVersionId: event.target.value })} SelectProps={{ displayEmpty: true, renderValue: value => { const selected = (processOptions.data ?? []).find(option => option.id === String(value)); return selected ? [selected.version, selected.processReference?.ownerName].filter(Boolean).join(' · ') : '请选择制程版本'; } }}>
                  <MenuItem value="">请选择制程版本</MenuItem>
                  {(processOptions.data ?? []).filter(option => option.productionMode === '量产').map(option => <MenuItem key={option.id} value={option.id} disabled={Boolean(fixedProductionForm) && (option.productionForm === 'SN') !== (fixedProductionForm === 'SN')}><Box><Typography variant="body2">{option.version} · {option.processReference?.ownerName}</Typography><Typography variant="caption" color="text.secondary">{option.processReference?.ownerType === 'PRODUCT_FAMILY' ? '产品簇兜底' : '产品制程'}，{formLabels[option.productionForm] || option.productionForm}</Typography></Box></MenuItem>)}
                </TextField>
              </Box>
              {splitTab !== 1 && <>
                {(splitTab !== 2 || !isSnProduction) && <TextField required size="small" label={splitTab === 0 ? (isSnProduction ? 'SN数量' : batchAddType === 'count' ? '批次数' : '每批数量') : '数量'} type="number" inputProps={{ min: 0, step: splitTab === 0 && (isSnProduction || batchAddType === 'count') ? 1 : 'any' }} value={splitForm.targetQuantity} onChange={event => setSplitForm({ ...splitForm, targetQuantity: event.target.value })} disabled={!splitDataReady || split.isPending} />}
                <TextField required={isSnProduction && splitTab === 2} size="small" label={splitTab === 0 ? (isSnProduction ? 'SN编号前缀' : '批次号前缀') : (isSnProduction ? 'SN编号' : '批次号（可选）')} value={splitForm.objectNo} onChange={event => setSplitForm({ ...splitForm, objectNo: event.target.value })} disabled={!splitDataReady || split.isPending} />
                <TextField size="small" label="计划开始时间" type="datetime-local" InputLabelProps={{ shrink: true }} value={splitForm.plannedStartAt} onChange={event => setSplitForm({ ...splitForm, plannedStartAt: event.target.value })} disabled={split.isPending} />
                <TextField size="small" label="计划结束时间" type="datetime-local" InputLabelProps={{ shrink: true }} value={splitForm.plannedEndAt} onChange={event => setSplitForm({ ...splitForm, plannedEndAt: event.target.value })} disabled={split.isPending} />
                <TextField size="small" label="备注" value={splitForm.remark} onChange={event => setSplitForm({ ...splitForm, remark: event.target.value })} disabled={split.isPending} sx={{ gridColumn: { sm: '1 / -1', md: 'span 2' } }} />
              </>}
              {splitTab === 1 && <Stack direction="row" spacing={1} sx={{ gridColumn: { sm: '1 / -1', md: 'span 2' }, justifyContent: { xs: 'flex-start', md: 'flex-end' } }}><Button onClick={downloadImportTemplate}>下载导入模板</Button><Button component="label" variant="contained" startIcon={<UploadFile />} disabled={!splitDataReady || !splitForm.processVersionId || split.isPending}>选择文件<input hidden type="file" accept=".csv,.xlsx,.xls" onChange={event => { void importPendingObjects(event.target.files?.[0]); event.currentTarget.value = ''; }} /></Button></Stack>}
            </Box>
            <Stack direction={{ xs: 'column', sm: 'row' }} alignItems={{ xs: 'stretch', sm: 'center' }} justifyContent="space-between" spacing={1}>
              <Box sx={{ minWidth: 0 }}>
                {selectedProcess && <Stack direction="row" flexWrap="wrap" alignItems="center" columnGap={1}><Typography variant="caption" color="text.secondary">工艺路线 {selectedProcess.routeVersion || '-'} / DHR 模板 {selectedProcess.dhrTemplateVersion || '-'}</Typography><Button size="small" startIcon={<Visibility fontSize="small" />} disabled={!splitDataReady} onClick={() => setProcessPreviewOpen(true)}>预览当前配置</Button></Stack>}
                <Typography variant="caption" color="text.secondary">{splitTab === 1 ? `${isSnProduction ? 'SN编号必填，数量固定为1' : '批次号和数量必填'}。支持 Excel / CSV；计划时间、备注可选。` : splitTab === 0 ? (isSnProduction ? '每个 SN 数量固定为1；编号按前缀依次生成。' : batchAddType === 'count' ? '按剩余数量平均分配，最后一批承接余数。' : '按每批数量生成，最后一批承接余数。') : '加入清单后可继续选择其他制程，再统一提交。'}</Typography>
                {!processOptions.isLoading && !processOptions.isError && !processOptions.data?.length && <Typography color="text.secondary" variant="body2">当前没有可选择的相同生产形态制程</Typography>}
              </Box>
              {splitTab !== 1 && <Button variant="outlined" startIcon={<Add />} sx={{ flexShrink: 0, whiteSpace: 'nowrap' }} onClick={splitTab === 0 ? addPendingBatch : addPendingObject} disabled={!splitDataReady || split.isPending || !splitForm.processVersionId || (splitTab === 0 ? !validBatchInput : isSnProduction ? !splitForm.objectNo.trim() || availableRemaining < 1 : !Number.isFinite(batchInput) || batchInput <= 0 || batchInput > availableRemaining)}>{splitTab === 0 ? '批量加入清单' : '加入清单'}</Button>}
            </Stack>
          </Stack>
        </Box>}

        <Box sx={{ minWidth: 0 }}>
          <Tabs value={canSplit ? objectListTab : 1} onChange={(_, value) => setObjectListTab(value)} aria-label="生产对象清单" sx={{ minHeight: 44, borderBottom: '1px solid', borderColor: 'divider', mb: 1.5, '& .MuiTab-root': { minHeight: 44, px: 2, py: 1 } }}>
            {canSplit && <Tab value={0} label={`待提交（${pendingObjects.length}）`} />}
            <Tab value={1} label={`已拆分（${objectRows.length}）`} />
          </Tabs>
          {canSplit && objectListTab === 0 ? pendingTable : objectTable}
        </Box>
      </Stack>}</DialogContent>
      <DialogActions sx={{ px: { xs: 2, sm: 3 }, py: 1.5, gap: 1 }}>
        <Typography variant="caption" color="text.secondary" sx={{ mr: 'auto', display: { xs: 'none', sm: 'block' } }}>每批独立保存制程引用，开工时冻结配置。</Typography>
        <Button onClick={closeObjects} disabled={split.isPending}>关闭</Button>
        {canSplit && <Button variant="contained" onClick={() => split.mutate()} disabled={!splitDataReady || pendingObjects.length === 0 || split.isPending} sx={{ whiteSpace: 'nowrap' }}>{split.isPending ? '提交中...' : `提交批次（${pendingObjects.length}）`}</Button>}
      </DialogActions>
    </AppDialog>

    {editObject && <ProductionObjectEditDialog key={editObject.id} object={editObject} onClose={() => setEditObject(null)} />}
    <AppDialog open={endTarget !== null} onClose={() => setEndTarget(null)} maxWidth="sm" fullWidth><DialogTitle>提前结束工单 · {endTarget?.orderNo}</DialogTitle><DialogContent dividers><Stack spacing={2}><Typography variant="body2">请先取消未开工批次，并完成或提前结束生产中的批次。结束工单后不能继续拆分，计划数量与已有记录保留。</Typography><TextField autoFocus required label="结束原因" multiline minRows={3} value={endReason} inputProps={{ maxLength: 500 }} onChange={e => setEndReason(e.target.value)} />{endOrder.isError && <Typography color="error">{endOrder.error.message}</Typography>}</Stack></DialogContent><DialogActions><Button onClick={() => setEndTarget(null)}>取消</Button><Button color="warning" variant="contained" disabled={!endReason.trim() || endOrder.isPending} onClick={() => endOrder.mutate()}>确认提前结束</Button></DialogActions></AppDialog>
    <WorkOrderDetailDrawer open={detailOrder !== null} order={detailOrder} tab={detailTab} onTabChange={setDetailTab} auditRecords={auditRecords} auditLoading={auditQuery.isLoading} auditError={auditQuery.isError} onClose={() => setDetailOrder(null)} />
    <ProcessVersionPreviewDialog open={processPreviewOpen} version={previewVersion} loading={processPreviewQuery.isFetching} error={processPreviewQuery.isError} onClose={() => setProcessPreviewOpen(false)} onRetry={() => void processPreviewQuery.refetch()} />
    <ConfirmDialog open={cancelTarget !== null} title="取消工单" message={cancelTarget ? `确定取消工单「${cancelTarget.orderNo}」吗？取消后将不能继续拆分生产对象。` : ''} confirmText="取消工单" destructive loading={cancel.isPending} onCancel={() => setCancelTarget(null)} onConfirm={() => cancelTarget && cancel.mutate(cancelTarget.id)} />
    <ConfirmDialog open={closeTarget !== null} title="关闭工单" message={closeTarget ? `确定关闭工单「${closeTarget.orderNo}」吗？关闭后将不能继续进行生产操作。` : ''} confirmText="关闭工单" loading={close.isPending} onCancel={() => setCloseTarget(null)} onConfirm={() => closeTarget && close.mutate(closeTarget.id)} />
    <ConfirmDialog open={cancelObject !== null} title="取消生产对象" message={cancelObject ? `确定取消生产对象「${cancelObject.objectNo}」吗？` : ''} confirmText="取消对象" destructive loading={objectAction.isPending} onCancel={() => setCancelObject(null)} onConfirm={() => cancelObject && objectAction.mutate({ action: 'cancel', id: cancelObject.id })} />
  </Box>;
}
