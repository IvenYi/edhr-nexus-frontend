import { lazy, Suspense } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Box, CircularProgress } from '@mui/material';
import LoginPage from '@/pages/LoginPage';
import AppLayout from '@/components/shared/AppLayout';
import NotFoundPage from '@/pages/NotFoundPage';
import { PROJECTION_REPORT_PAGES } from '@/utils/menuManagement';

const DashboardPage = lazy(() => import('@/pages/dashboard/DashboardPage'));
const PersonalSettingsPage = lazy(() => import('@/pages/account/PersonalSettingsPage'));
const ReviewTemplateList = lazy(() => import('@/pages/workflow-center/ReviewTemplateList'));
const ReviewTemplateEditor = lazy(() => import('@/pages/workflow-center/ReviewTemplateEditor'));
const FormProcessList = lazy(() => import('@/pages/workflow-center/FormProcessList'));
const FormProcessEditor = lazy(() => import('@/pages/workflow-center/FormProcessEditor'));
const WorkTemplateList = lazy(() => import('@/pages/workflow-center/WorkTemplateList'));
const WorkTemplateEditor = lazy(() => import('@/pages/workflow-center/WorkTemplateEditor'));
const WorkOrderPage = lazy(() => import('@/pages/production/WorkOrderPage'));
const BatchManagementPage = lazy(() => import('@/pages/production/BatchManagementPage'));
const ProductionExecutionPage = lazy(() => import('@/pages/production/ProductionExecutionPage'));
const BindingRuleList = lazy(() => import('@/pages/workflow-center/BindingRuleList'));
const InstanceList = lazy(() => import('@/pages/workflow-center/InstanceList'));
const InstanceDetail = lazy(() => import('@/pages/workflow-center/InstanceDetail'));
const InstanceLogs = lazy(() => import('@/pages/workflow-center/InstanceLogs'));
const TaskDetail = lazy(() => import('@/pages/workflow-center/TaskDetail'));
const FormInstanceListPage = lazy(() => import('@/pages/form-management/FormInstanceListPage'));
const FormProjectionReportPage = lazy(() => import('@/pages/reports/FormProjectionReportPage'));
const DhrTraceReportPage = lazy(() => import('@/pages/reports/DhrTraceReportPage'));
const FormFillingPage = lazy(() => import('@/pages/form-management/FormFillingPage'));
const FormReviewPage = lazy(() => import('@/pages/form-management/FormReviewPage'));
const RecordChangePage = lazy(() => import('@/pages/record-control/RecordChangePage'));
const RecordRequestListPage = lazy(() => import('@/pages/record-control/RecordRequestListPage'));
const RecordRequestDetailPage = lazy(() => import('@/pages/record-control/RecordRequestDetailPage'));
const RecordApprovalPage = lazy(() => import('@/pages/record-control/RecordApprovalPage'));
const RecordApprovalDetailPage = lazy(() => import('@/pages/record-control/RecordApprovalDetailPage'));
const DhrManagementPage = lazy(() => import('@/pages/dhr-management/DhrManagementPage'));
const DhrSummaryPage = lazy(() => import('@/pages/dhr-management/DhrSummaryPage'));
const DhrFillingPage = lazy(() => import('@/pages/dhr-management/DhrFillingPage'));
const DhrReviewPage = lazy(() => import('@/pages/dhr-management/DhrReviewPage'));
const ProcessModelingPage = lazy(() => import('@/pages/master-data/ProcessModelingPage'));
const ProductModelingPage = lazy(() => import('@/pages/master-data/ProductModelingPage'));
const ProductModelingWorkspacePage = lazy(() => import('@/pages/master-data/ProductModelingWorkspacePage'));
const ProductFamilyModelingPage = lazy(() => import('@/pages/master-data/ProductFamilyModelingPage'));
const DocumentManagementPage = lazy(() => import('@/pages/master-data/DocumentManagementPage'));
const TemplateModelingPage = lazy(() => import('@/pages/master-data/TemplateModelingPage'));
const WorkshopManagementPage = lazy(() => import('@/pages/master-data/WorkshopManagementPage'));
const EquipmentPage = lazy(() => import('@/pages/master-data/EquipmentPage'));
const QualityReasonPage = lazy(() => import('@/pages/master-data/QualityReasonPage'));

const OrganizationPage = lazy(() => import('@/pages/system/OrganizationPage'));
const UserPage = lazy(() => import('@/pages/system/UserPage'));
const RolePage = lazy(() => import('@/pages/system/RolePage'));
const MenuManagementPage = lazy(() => import('@/pages/system/MenuManagementPage'));
const BusinessDictionaryPage = lazy(() => import('@/pages/system/BusinessDictionaryPage'));
const FormLookupItemsPage = lazy(() => import('@/pages/system/FormLookupItemsPage'));
const IconManagementPage = lazy(() => import('@/pages/system/IconManagementPage'));
const SystemSettingsPage = lazy(() => import('@/pages/system/SystemSettingsPage'));
const AuditLogPage = lazy(() => import('@/pages/system/AuditLogPage'));
const SignatureLogPage = lazy(() => import('@/pages/system/SignatureLogPage'));
const LoginLogPage = lazy(() => import('@/pages/system/LoginLogPage'));

const Loading = () => (
  <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', py: 8 }}>
    <CircularProgress />
  </Box>
);

/** Protected route wrapper. In Phase 0, checks localStorage token. */
function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const token = localStorage.getItem('token');
  if (!token) {
    return <Navigate to="/login" replace />;
  }
  return <>{children}</>;
}

const AppRouter = () => {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route
        path="/"
        element={
          <ProtectedRoute>
            <AppLayout />
          </ProtectedRoute>
        }
      >
        <Route
          index
          element={
            <Suspense fallback={<Loading />}>
              <DashboardPage />
            </Suspense>
          }
        />
        <Route path="account">
          <Route path="settings" element={<Suspense fallback={<Loading />}><PersonalSettingsPage /></Suspense>} />
        </Route>
        <Route path="workflow">
          <Route path="review-templates" element={<Suspense fallback={<Loading />}><ReviewTemplateList /></Suspense>} />
          <Route path="review-templates/:id/configure" element={<Suspense fallback={<Loading />}><ReviewTemplateEditor /></Suspense>} />
          <Route path="review-templates/:id" element={<Suspense fallback={<Loading />}><ReviewTemplateEditor /></Suspense>} />
          <Route path="form-processes" element={<Suspense fallback={<Loading />}><FormProcessList /></Suspense>} />
          <Route path="form-processes/:id" element={<Suspense fallback={<Loading />}><FormProcessEditor /></Suspense>} />
          <Route path="binding-rules" element={<Suspense fallback={<Loading />}><BindingRuleList /></Suspense>} />
          <Route path="instances" element={<Suspense fallback={<Loading />}><InstanceList /></Suspense>} />
          <Route path="interventions" element={<Suspense fallback={<Loading />}><InstanceList intervention /></Suspense>} />
          <Route path="instances/:id" element={<Suspense fallback={<Loading />}><InstanceDetail /></Suspense>} />
          <Route path="instances/:id/logs" element={<Suspense fallback={<Loading />}><InstanceLogs /></Suspense>} />
          <Route path="tasks/:id" element={<Suspense fallback={<Loading />}><TaskDetail /></Suspense>} />
        </Route>
        <Route path="form-management">
          <Route path="list" element={<Suspense fallback={<Loading />}><FormInstanceListPage /></Suspense>} />
          <Route path="filling" element={<Suspense fallback={<Loading />}><FormFillingPage /></Suspense>} />
          <Route path="review" element={<Suspense fallback={<Loading />}><FormReviewPage /></Suspense>} />
        </Route>
        <Route path="reports/form-projections" element={<Navigate to="/reports/form-trace" replace />} />
        {PROJECTION_REPORT_PAGES.map(page => <Route key={page.path} path={page.path.slice(1)} element={<Suspense fallback={<Loading />}>{page.modelId === 'dhrTrace' ? <DhrTraceReportPage /> : <FormProjectionReportPage key={page.modelId} modelId={page.modelId} />}</Suspense>} />)}
        <Route path="records">
          <Route path="change" element={<Suspense fallback={<Loading />}><RecordChangePage /></Suspense>} />
          <Route path="mine" element={<Suspense fallback={<Loading />}><RecordRequestListPage scope="mine" /></Suspense>} />
          <Route path="approvals" element={<Suspense fallback={<Loading />}><RecordApprovalPage /></Suspense>} />
          <Route path="approvals/:taskId/:requestId" element={<Suspense fallback={<Loading />}><RecordApprovalDetailPage /></Suspense>} />
          <Route path="history" element={<Suspense fallback={<Loading />}><RecordRequestListPage scope="all" /></Suspense>} />
          <Route path="requests/:requestId" element={<Suspense fallback={<Loading />}><RecordRequestDetailPage /></Suspense>} />
        </Route>
        <Route path="dhr-management">
          <Route path="list" element={<Suspense fallback={<Loading />}><DhrManagementPage /></Suspense>} />
          <Route path="summary" element={<Suspense fallback={<Loading />}><DhrSummaryPage /></Suspense>} />
          <Route path="filling" element={<Suspense fallback={<Loading />}><DhrFillingPage /></Suspense>} />
          <Route path="review" element={<Suspense fallback={<Loading />}><DhrReviewPage /></Suspense>} />
        </Route>
        <Route path="production">
          <Route path="execution" element={<Suspense fallback={<Loading />}><ProductionExecutionPage /></Suspense>} />
          <Route path="work-orders" element={<Suspense fallback={<Loading />}><WorkOrderPage /></Suspense>} />
          <Route path="batches" element={<Suspense fallback={<Loading />}><BatchManagementPage /></Suspense>} />
          <Route path="work-templates" element={<Suspense fallback={<Loading />}><WorkTemplateList /></Suspense>} />
          <Route path="work-templates/:id" element={<Suspense fallback={<Loading />}><WorkTemplateEditor /></Suspense>} />
        </Route>
        <Route path="master-data">
          <Route path="materials" element={<Suspense fallback={<Loading />}><ProcessModelingPage pageKey="materials" /></Suspense>} />
          <Route path="operations" element={<Suspense fallback={<Loading />}><ProcessModelingPage pageKey="operations" /></Suspense>} />
          <Route path="routes" element={<Suspense fallback={<Loading />}><ProcessModelingPage pageKey="routes" /></Suspense>} />
          <Route path="products" element={<Suspense fallback={<Loading />}><ProductModelingPage /></Suspense>} />
          <Route path="products/:productVersionId/modeling" element={<Suspense fallback={<Loading />}><ProductModelingWorkspacePage /></Suspense>} />
          <Route path="product-families" element={<Suspense fallback={<Loading />}><ProductFamilyModelingPage /></Suspense>} />
          <Route path="documents" element={<Suspense fallback={<Loading />}><DocumentManagementPage /></Suspense>} />
          <Route path="form-templates" element={<Suspense fallback={<Loading />}><TemplateModelingPage pageKey="formTemplates" /></Suspense>} />
          <Route path="batch-record-templates" element={<Suspense fallback={<Loading />}><TemplateModelingPage pageKey="batchRecordTemplates" /></Suspense>} />
          <Route path="workshops" element={<Suspense fallback={<Loading />}><WorkshopManagementPage /></Suspense>} />
          <Route path="equipment-types" element={<Suspense fallback={<Loading />}><EquipmentPage key="types" pageKey="types" /></Suspense>} />
          <Route path="equipment" element={<Suspense fallback={<Loading />}><EquipmentPage key="equipment" pageKey="equipment" /></Suspense>} />
          <Route path="defect-reasons" element={<Suspense fallback={<Loading />}><QualityReasonPage key="DEFECT" type="DEFECT" /></Suspense>} />
          <Route path="scrap-reasons" element={<Suspense fallback={<Loading />}><QualityReasonPage key="SCRAP" type="SCRAP" /></Suspense>} />
        </Route>
        <Route path="system">
          <Route path="organization" element={<Suspense fallback={<Loading />}><OrganizationPage /></Suspense>} />
          <Route path="users" element={<Suspense fallback={<Loading />}><UserPage /></Suspense>} />
          <Route path="roles" element={<Suspense fallback={<Loading />}><RolePage /></Suspense>} />
          <Route path="menu-management" element={<Suspense fallback={<Loading />}><MenuManagementPage /></Suspense>} />
          <Route path="dictionaries" element={<Suspense fallback={<Loading />}><BusinessDictionaryPage /></Suspense>} />
          <Route path="form-lookup-items" element={<Suspense fallback={<Loading />}><FormLookupItemsPage /></Suspense>} />
          <Route path="icons" element={<Suspense fallback={<Loading />}><IconManagementPage /></Suspense>} />
          <Route path="settings" element={<Suspense fallback={<Loading />}><SystemSettingsPage /></Suspense>} />
          <Route path="login-logs" element={<Suspense fallback={<Loading />}><LoginLogPage /></Suspense>} />
          <Route path="audit-logs" element={<Suspense fallback={<Loading />}><AuditLogPage /></Suspense>} />
          <Route path="signatures" element={<Suspense fallback={<Loading />}><SignatureLogPage /></Suspense>} />
        </Route>
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
};

export default AppRouter;
