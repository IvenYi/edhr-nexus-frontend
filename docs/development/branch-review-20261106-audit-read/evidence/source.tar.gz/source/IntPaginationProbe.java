import java.util.List;

/** Isolated Java arithmetic observation, not an application or database test. */
class IntPaginationProbe {
    public static void main(String[] args) {
        for (int[] input : new int[][]{{1,20},{107374184,20},{2,Integer.MAX_VALUE},{Integer.MAX_VALUE,20}}) {
            int page=input[0],size=input[1],n=3;
            int from=Math.min((page-1)*size,n),to=Math.min(from+size,n);
            String result;
            try { result=List.of(1,2,3).subList(from,to).toString(); }
            catch (RuntimeException failure) { result=failure.getClass().getSimpleName(); }
            int wideFrom=(int)Math.min((page-1L)*size,n),wideTo=(int)Math.min((long)wideFrom+size,n);
            System.out.printf("{\"page\":%d,\"size\":%d,\"listSize\":%d,\"oldFrom\":%d,\"oldTo\":%d,\"oldOutcome\":\"%s\",\"wideFrom\":%d,\"wideTo\":%d,\"wideResult\":\"%s\"}%n",page,size,n,from,to,result,wideFrom,wideTo,List.of(1,2,3).subList(wideFrom,wideTo));
        }
    }
}
