# 审计读取有限本体核对（待最终源码固定）

基线 e69a8f3d97b34fea8737947c780b047bb0310c64，知识0.3.25/schema1.2/P0。仅本批分页算术与原生读取取证范围，不修改运行代码、测试、历史或知识资产，不声明全库对齐。正式结果待主角色通知稳定候选后封存。

已确认规则为DEC-0013-03、term/concept.data-audit-action-category及rule.production.audit-action-projection：工单和生产对象在客户页面只投影新增/修改，生命周期动作归修改，原事件/action/快照不改写。原规则还明确不新增额外筛选类别。本轮不需要重新向用户确认该两类分类。

目前实现差异有明确来源：全局AuditLogPage选UPDATE（显示“编辑”）经api/audit传给AuditController；repository先按事件raw action=UPDATE筛选，再由controller将生产CANCEL/STATUS_CHANGE等投影成UPDATE。故未筛选列表中可显示为“修改”的生产事件，在该分类筛选中会漏掉。现有AuditControllerTest的mock不执行实际repository谓词，不能证明真实SQL筛选一致。此结论是源码与现行规范比较，本角色未运行该产品PG复现；主侧负责原生证据和修复。

姓名和显示fallback须分层记录，不能把现代码当用户新政策。controller现在先按operatorAccount（否则operatorName/ID回退）查询当前UserAccount.displayName，再历史operatorName/账号回退；repository的operatorName搜索却针对事件中的历史operatorName。未找到“历史姓名优先/当前姓名优先”和具体搜索来源的独立已确认政策，不自行改成冻结姓名或按显示名查人。性能优化若保留现行为，可以按工程等价性验证；改变历史身份或搜索含义则需独立来源与讨论。当前姓名查询N+1只是实际代码行为和性能观察，不是知识规则。

个人入口是“当前账户作为被操作对象”的审计：USER_ACCOUNT + entityId=currentUser.id，并非只限operatorId=本人。已有测试明确包含本人修改及管理员修改该账户两条，不应在优化时漏掉管理员事件。当前请求身份/授权来自既有安全链，本角色没有进行HTTP/JWT或全部权限认证。

模块/菜单/功能/摘要的旧兼容fallback由当前代码和原测试可定位，但没有把全部具体字符串别名升格为新的用户政策；本批保持它们，不以原raw列替代派生列筛选或由当前主数据伪造历史。只读请求不写AuditEvent、旧hash、生产/DHR/签名或文件快照。

分页乘加从int中间值宽化，只避免合法正数page/size变为负索引；不新增总条数/人员上限、不改变正常页、筛选或响应合同，属于工程正确性修复，无需新业务规则。规模、内存、SQL/参数及索引取舍仍待主侧实际测量与最终独立质量，不能以89知识测试替代。

本体侧已实际运行正式知识模块89/89（0F/E/S），350文件与基线逐字节相同。旧W5历史摘要、完整ZIP自足复核和原全审W2-W7/931知识/86UI/A12/高风险/性能/UNKNOWN/A23（含已审代码复查）与用户暂停队列保持。有限审读不加总unique、不提高P0或知识成熟度。
