from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, shutil, subprocess, xml.etree.ElementTree as ET
import yaml

r = Path('/workspace/edhr-nexus-frontend')
out = Path('/tmp/edhr-audit-read-ontology-20261106')
main = Path('/tmp/edhr-audit-read-20261106')
base = 'e69a8f3d97b34fea8737947c780b047bb0310c64'
def sha(data): return hashlib.sha256(data).hexdigest()
def cmd(*args): return subprocess.check_output(args, cwd=r, text=True).strip()
def save(path, obj):
    (out/path).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

assert cmd('git','rev-parse','HEAD') == base
assert cmd('git','rev-parse','refs/remotes/origin/edhr-dev') == base
initial = json.loads((out/'source-manifest.json').read_text())
run = json.loads((main/'final/run.json').read_text())
source_paths = sorted(set([x['path'] for x in initial['files']] + [x['path'] for x in run['sourceFingerprints']]))
fingerprints=[]
for path in source_paths:
    data=(r/path).read_bytes()
    dst=out/'final-source-snapshot'/path;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
    baseline=None
    try: baseline=subprocess.check_output(['git','show',f'{base}:{path}'],cwd=r,stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError: pass
    fingerprints.append({'path':path,'bytes':len(data),'sha256':sha(data),'baselineSha256':sha(baseline) if baseline is not None else None,'sameAsBaseline':data==baseline if baseline is not None else False,'inputState':'uncommitted review candidate' if data != baseline else 'baseline retained'})
source_checks=[]
for item in run['sourceFingerprints']:
    actual=sha((r/item['path']).read_bytes())
    source_checks.append({'path':item['path'],'parentTestedSha256':item['sha256'],'finalReviewedSha256':actual,'same':actual==item['sha256']})
dp_path='docs/development/branch-review-20261106-audit-read/decision-package.yaml'
assert all(x['same'] for x in source_checks if x['path'] != dp_path)
tested_dp=yaml.safe_load((main/'final/source'/dp_path).read_text())
final_dp=yaml.safe_load((r/dp_path).read_text())
added_whitespace_path='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditActionWhitespacePostgresTest.java'
without_added=yaml.safe_load((r/dp_path).read_text())
without_added['decisionPackage']['affectedFiles']=[x for x in without_added['decisionPackage']['affectedFiles'] if x['path'] != added_whitespace_path]
assert tested_dp == without_added or tested_dp == final_dp

knowledge=[]
tracked=cmd('git','ls-tree','-r','--name-only',base,'docs/knowledge').splitlines()
for path in tracked:
    original=subprocess.check_output(['git','show',f'{base}:{path}'],cwd=r)
    data=(r/path).read_bytes()
    knowledge.append({'path':path,'bytes':len(data),'sha256':sha(data),'baselineSha256':sha(original),'sameAsBaseline':data==original})
assert len(knowledge)==350 and all(x['sameAsBaseline'] for x in knowledge)
assert not cmd('git','diff','--name-only',base,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/architecture/business-knowledge-model.md','docs/knowledge')
save('final-source-manifest.json',{'reviewedAt':datetime.now(timezone.utc).isoformat(),'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[],'workingTreeStatus':cmd('git','status','--short'),'files':fingerprints,'parentFinalRunSourceComparison':source_checks,'decisionPackageOnlyDelta':'Added affectedFiles entry for already-tested AuditActionWhitespacePostgresTest; parsed remaining decision package equal. No product/contract or policy change.','targetVerification':'local origin/edhr-dev ref from main-role fetch checked; this role did not perform a new network fetch'})
save('knowledge-fingerprint-inventory-final.json',{'baseline':base,'files':knowledge,'count':len(knowledge),'allUnchanged':True})

parent_dst=out/'parent-generated-evidence'
copied=[]
for stage in ['unit_negative','baseline','final']:
    candidates=[main/stage/'run.json',main/stage/'test-summary.json'] + sorted((main/stage).glob('TEST-*.xml'))
    if stage in ['baseline','final']:
        candidates += [main/stage/'observations'/f'action_{n}.json' for n in ['all','create','update','cancel','work','object','user_update','user_cancel']]
    for src in candidates:
        rel=src.relative_to(main);dst=parent_dst/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
        copied.append({'originalPath':str(src),'copiedPath':str(dst.relative_to(out)),'bytes':dst.stat().st_size,'sha256':sha(dst.read_bytes()),'producer':'main role; not executed by ontology role'})
save('parent-generated-evidence/provenance.json',{'files':copied,'caveat':'Actual raw reports read and fingerprinted, but product runtime was executed by main role. Knowledge role performed its own knowledge89 only; separate independent quality is outside this result.'})
(parent_dst/'final/tested-decision-package.yaml').write_bytes((main/'final/source'/dp_path).read_bytes())
totals={key:0 for key in ['tests','failures','errors','skipped']}
for xml in (parent_dst/'final').glob('TEST-*.xml'):
    root=ET.parse(xml).getroot()
    for key in totals: totals[key]+=int(root.attrib.get(key,0))
assert totals=={'tests':116,'failures':0,'errors':0,'skipped':0}

records=[json.loads(line) for line in (out/'finite-audit-records-initial.jsonl').read_text().splitlines()]
for record in records:
    if record['id']=='rule.production.audit-action-projection':
        record['conclusion']='consistent'
        record['scopeAndReason']='仅本批列表动作筛选子范围：repository的CASE与未修改Java投影保持一致；生产非CREATE归UPDATE，非生产保留raw分类、原实体筛选及历史动作；主侧真实PG动作9例/空白oracle17例与原源负对照已读取。完整跨页面UI/写入链不在本条一致范围。'
        record['implementationIssueDisposition']='fixed in fingerprinted working-tree candidate; initial needs-fix preserved separately'
        record['originalEvidenceReferences'] += ['gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditActionFilterPostgresTest.java','gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/AuditActionWhitespacePostgresTest.java','parent-generated-evidence/baseline/TEST-com.zencas.edhr.compliance.controller.AuditActionFilterPostgresTest.xml','parent-generated-evidence/final/TEST-com.zencas.edhr.compliance.controller.AuditActionFilterPostgresTest.xml','parent-generated-evidence/final/TEST-com.zencas.edhr.compliance.controller.AuditActionWhitespacePostgresTest.xml']
    record['finalCandidateManifest']='final-source-manifest.json'
(out/'finite-audit-records-final.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in records))
counts=dict(Counter(x['conclusion'] for x in records))
assert counts=={'consistent':12,'evidence-gap':1}
save('finite-audit-summary-final.json',{'records':len(records),'conclusions':counts,'initialImplementationNeedsFix':1,'fixedImplementationNeedsFix':1,'remainingImplementationNeedsFixInThisFiniteScope':0,'sourceObservations':4,'sourceNameSearchPolicyGap':'retained, not a new product policy','wholeAuditUniqueCoverage':'not calculated or incremented; 931/86/full queues remain','runtimeByThisRole':{'knowledge':89,'product':0,'browser':0,'httpSecurity':0},'parentGeneratedReportsRead':totals})

result={'ontologyResult':{
 'result':'not-applicable','baselineBefore':'0.3.25','baselineAfter':'0.3.25',
 'contractBaseline':{'sourceCommit':base,'targetBranch':'edhr-dev','targetCommit':base,'contractReadCommit':base,'uncommittedContractPaths':[]},
 'reason':'本批只修分页中间算术及按既有DEC-0013-03生产动作投影筛选；不增加或替代业务政策。当前知识定义无需修改，350知识文件与基线逐字节相同；实际源码及主侧原生报告已核对。性能只取证，未执行分页/姓名批量/索引优化。',
 'changedArtifacts':[],
 'knowledgeSync':[
  {'id':'DEC-0013-03','disposition':'retained','scope':'保留生产客户动作新增/修改两类；本批修复现有筛选实现差异，不新增政策或重写历史。','sourceReferences':['docs/knowledge/decisions/DEC-0013-production-work-order-lifecycle-and-audit-projection.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java']},
  {'id':'rule.production.audit-action-projection','disposition':'retained','scope':'仅核本批列表筛选的生产投影一致性，Java显示原逻辑保留，非生产分类/原实体过滤不变；完整UI场景另保留证据缺口。','sourceReferences':['docs/knowledge/rules/production.yaml','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java','finite-audit-records-final.jsonl']},
  {'id':'relation.audit-event-projects-action-category','disposition':'retained','scope':'原事件action与客户动作分类分层，读取筛选不更新审计原件或快照。','sourceReferences':['docs/knowledge/ontology.yaml','parent-generated-evidence/final/TEST-com.zencas.edhr.compliance.controller.AuditActionFilterPostgresTest.xml']}
 ],
 'conflicts':[],'questions':[],
 'validationEvidence':[
  {'id':'validation.knowledge89','checkType':'schema','command':'bash /workspace/.edhr-cloud-tools/mvn-edhr -f tools/knowledge-model/pom.xml test','outcome':'passed','evidence':['knowledge-validation.log','TEST-com.zencas.edhr.knowledge.BusinessKnowledgeModelTest.xml','knowledge-test-summary.json','本角色实际运行89 tests /0 failures /0 errors /0 skipped；不等于产品或语义全审通过。']},
  {'id':'validation.knowledge-reference-status-projection','checkType':'reference','command':'same formal knowledge test suite plus finite authority/source review','outcome':'passed','evidence':['knowledge-test-summary.json','finite-audit-records-final.jsonl','350个知识文件与e69逐字节相同，原知识成熟度/知识0.3.25/schema1.2/P0均保留。']},
  {'id':'validation.action-projection-subscope','checkType':'projection','command':'read final source diff and main-role native PostgreSQL XML/observations; no product runtime executed by this role','outcome':'passed','evidence':['final-source-manifest.json','parent-generated-evidence/provenance.json','parent-generated-evidence/baseline/TEST-com.zencas.edhr.compliance.controller.AuditActionFilterPostgresTest.xml','parent-generated-evidence/final/TEST-com.zencas.edhr.compliance.controller.AuditActionFilterPostgresTest.xml','parent-generated-evidence/final/TEST-com.zencas.edhr.compliance.controller.AuditActionWhitespacePostgresTest.xml','仅动作筛选子范围；未宣称完整UI/HTTP权限或全审通过。']},
  {'id':'validation.provenance-and-baseline','checkType':'evidence-path','command':'python /tmp/edhr-audit-read-ontology-20261106/finalize.py','outcome':'passed','evidence':['final-source-manifest.json','knowledge-fingerprint-inventory-final.json','parent-generated-evidence/provenance.json','主侧final run的20个产品/测试/契约输入指纹与本角色最后读取完全一致；另1个DP仅补已测空白测试清单条目，解析后其余字段相同。固定基线提交与未提交候选分别标记，不为工作树编造SHA。']}
 ],
 'roadmapProgress':{'stage':'P0','status':'in-progress','exitCriteriaEvidence':[],'deferredStages':['P1','P2','P3']}
}}
(out/'ontologyResult.yaml').write_text(yaml.safe_dump(result,allow_unicode=True,sort_keys=False))
assert yaml.safe_load((out/'ontologyResult.yaml').read_text()) == result

(out/'REVIEW.md').write_text('''# Audit read finite ontology review

基线 e69a8f3d97b34fea8737947c780b047bb0310c64，知识0.3.25/schema1.2/P0 in-progress。产品候选为该HEAD上的未提交差异，实际读取及SHA-256见final-source-manifest.json。主侧final run的20个产品/测试/契约输入逐一相同；另1个DP仅补已测空白测试清单条目，解析后其余字段相同。本角色没有修改产品、测试或知识资产。

现有DEC-0013-03明确工单/生产对象对客户只展示和筛选新增/修改，生命周期归修改；rule.production.audit-action-projection及术语/概念/关系保持。初始raw action筛选漏掉投影修改的CANCEL/STATUS_CHANGE为已有依据的实现缺陷。最终repository按原Java投影CASE筛选，生产非CREATE归UPDATE，非生产raw分类与原实体过滤保持。实体类型与动作的既有不同trim边界已由主侧真实PG 17例oracle对照；不借本批统一/更改历史值。原事件/action/快照不改写。

分页只宽化两处乘加中间值，保证合法正数page/size不会溢出为负索引。不增加页大小、总条数、人员数量上限；正常响应page/size、列表排序、个人target USER_ACCOUNT/currentUser.id入口、现有姓名补全及模块/菜单/摘要fallback和派生筛选继续保留。个人入口包含管理员对该账户的操作，不误改为operatorId本人。

有限知识记录13条，最终12 consistent/1 evidence-gap，初始11 consistent/1 needs-fix/1 evidence-gap原件单独保留。被修复的1条只在列表筛选子范围一致；完整跨页面UI场景依然evidence-gap，不增全审unique覆盖，不变原成熟度。另4项source observation分开记录。当前姓名显示查当前displayName而operatorName过滤查事件原字段，未找到应优先当前或历史姓名及查询语义的独立确认；本批保留，不当新业务政策或擅自统一。HTTP/JWT/全生产权限未在本角色验证。

本角色实际运行知识模块89/89（0F/E/S），350知识文件与基线逐字节相同；原契约/架构未变。已读取并复制主侧真实产品报告：旧源分页6中3通过/3真实失败，native26中观察17通过及动作9中3通过/6真实失败，均0 errors/skipped；最终116/116通过含动作9/空白oracle17/算术6/观察17及既有回归。产品运行的执行者是主角色，本角色只核源码、指纹和报告；后续全新独立质量结果不由本报告替代。

性能优化没有在本批实施。全量加载、姓名逐行查询及宽JSON资源风险继续由主侧原始观察量化和方案讨论；没有索引DDL或分页/批量改造。未知姓名政策、广域UI、真实HTTP权限、生产峰值/SLA、完整ZIP自足复核与原全审W2-W7/931知识/86UI/A12/高风险/容量/UNKNOWN/A23（含已审代码复查）及用户暂停队列均保留。知识89和本批产品报告不能替代这些范围。

结果ontologyResult.not-applicable表示无需修改现行知识定义；不表示整体审计完成或授权合并/部署。所有原始输入、最终候选、知识指纹和本角色/主角色证据来源分层保留。
''')

files=[]
for path in sorted(out.rglob('*')):
    if path.is_file() and path.name not in ['manifest.json','manifest.sha256']:
        data=path.read_bytes();files.append({'path':str(path.relative_to(out)),'bytes':len(data),'sha256':sha(data)})
save('manifest.json',{'createdAt':datetime.now(timezone.utc).isoformat(),'sourceCommit':base,'artifactRoot':str(out),'files':files})
manifest_data=(out/'manifest.json').read_bytes()
(out/'manifest.sha256').write_text(''.join(f"{item['sha256']}  {item['path']}\n" for item in files)+f"{sha(manifest_data)}  manifest.json\n")
print(json.dumps({'result':'not-applicable','finiteRecords':len(records),'conclusions':counts,'knowledgeFilesUnchanged':len(knowledge),'knowledgeTests':89,'parentRuntimeReportsRead':totals,'sourceFilesCaptured':len(fingerprints),'parentSourceFingerprintsMatched':sum(x['same'] for x in source_checks),'decisionPackageOnlyDelta':'already-tested whitespace test inventory entry','manifestSha256':sha(manifest_data)},ensure_ascii=False,indent=2))
