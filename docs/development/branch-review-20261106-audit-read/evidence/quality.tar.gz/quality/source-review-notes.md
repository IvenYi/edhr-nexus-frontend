# 独立源码复核

本实例未参与修复，只在9d4416c3固定detached工作树读取代码、运行原测试和外部证据核对脚本。外部runner只替换自有容器前缀，环境变量指定独立根/输出；未改产品、测试、夹具或配置。node_modules软链仅供既有Maven打印资源构建使用，结束后清理。

分页：safePage/safeSize均至少1；(safePage-1)*safeSize最大约4.61e18，long可容纳，Math.min以实际List.size截断后转int安全。加法也先long，未加上限或改变PageResult参数。6例包含正常页/尾空页与三个旧源反证，旧异常被assertThatCode记录为真实失败而非测试环境错误。

动作：DEC-0013-03来自既有user-confirmed，当前规则已要求生产客户类别CREATE/UPDATE。JavaresolveProjectedAction原有逻辑不变：类型String.trim/Locale.ROOT大写，动作StringUtils.trimWhitespace后equalsIgnoreCase。SQL仅对生产类型同类映射，非CREATE为UPDATE，其他类型仍lower原action，原实体filter保留。本批正则分别保留C0 trim和Character.isWhitespace差别，17个实际PG oracle覆盖控制/Unicode空白，动作9含dotless-i类型、future内部动作、大小写及非生产对照；不新增业务防御策略或修改原事件。测试数据库原action/hash前后比对。

读路径：不是HTTP端到端。真实Controller/仓储/PG由完整canonical Liquibase初始化含0092；FormProjectionWorker仅隔离后台worker。无外层事务，OSIV=false，保留普通仓储事务，SQL观察不产生假缓存。个人入口固定USER_ACCOUNT+当前UserAccount.id，包括管理员对该目标的修改；不同于operatorId=本人。SecurityConfig仅authenticated、AuditController无方法授权是源码事实，尚缺完整原政策，不把此次保持原授权写成权限验证通过。

前端源码核：AuditLogPage queryKey含filters，输入onChange更新filter，故各字符可重查；UPDATE选项与列表归类对应。工单/批次内嵌同一接口，原100是该页请求参数而非全局人员上限，本批未改。既有UI规范要求后端筛选和/me按目标对象；未进行页面或视觉检查。

结构/A23：仅两处产品文件、9增3删。long和CASE均有反证及现行规则依据，无新框架、重复权限/证据校验、吞错或人为上限。提案明确AuditLogQueryService负责等价查询/计数/分页和页内人员，AuditLogPresenter纯投影；全量日志及逐行姓名待讨论，未把搬类称优化。旧performance ID和structure-plan已存在，按子项记账，不重复新增旧风险。索引实验只代表lower(type)+entity/order，已有索引可部分服务，不承诺完整JPQL/COUNT等价或生产收益。

350知识文件与基线逐字节相同；ontologyResult NA只说明无需新政策同步，13有限记录与UI gap保留，不升级P0/知识成熟度。主侧run DP与候选存在文档范围澄清差异，20个运行/测试/契约输入保持；独立实际跑的是候选全部21输入。完整四归档335个原件校验通过，并独立重核主侧25+25具名SQL。
