from pathlib import Path
import json,re,collections,tarfile,hashlib,xml.etree.ElementTree as ET,shutil,subprocess
out=Path('/tmp/edhr-audit-read-qa-20261106');root=Path('/tmp/edhr-audit-read-qa-worktree-20261106')
def reconcile(label,log,observations):
 actual=collections.defaultdict(collections.Counter)
 for line in log.splitlines():
  m=re.search(r'duration: [\d.]+ ms\s+execute [^:]+: /\*audit_read_([^*]+)\*/ (.*)$',line)
  if m:actual[m[1]][re.sub(r'\$\d+','?',m[2])]+=1
 cases=[]
 for a in sorted(observations,key=lambda a:a.get('name','')):
  if 'sqlShapes' not in a:continue
  expected=collections.Counter({s['sql']:s['count'] for s in a['sqlShapes']})
  assert actual[a['name']]==expected,(label,a['name'])
  assert sum(expected.values())==a['prepareStatements']
  assert all(sql.startswith('select ') for sql in actual[a['name']])
  assert a['entityInserts']==a['entityUpdates']==a['entityDeletes']==0
  cases.append({k:a[k] for k in ['name','prepareStatements','entityLoads','total','ids','elapsedNanos','threadAllocatedBytes']})
 assert set(actual)=={c['name'] for c in cases}
 return {'events':len(cases),'businessSelectExecutions':sum(sum(c.values()) for c in actual.values()),'exactSqlShapesAndCountsMatch':True,'noTaggedDmlAndZeroHibernateWrites':True,'cases':cases}
report={}
report['independent']=reconcile('independent',(out/'final/postgres.log').read_text(),[json.loads(p.read_text()) for p in (out/'final/observations').glob('*.json')])
assert report['independent']['events']==25 and report['independent']['businessSelectExecutions']==27461
with tarfile.open(root/'docs/development/branch-review-20261106-audit-read/evidence/main.tar.gz') as t:
 for phase in ['baseline','final']:
  log=t.extractfile('main/'+phase+'/postgres.log').read().decode();observations=[json.load(t.extractfile(m)) for m in t.getmembers() if m.isfile() and m.name.startswith('main/'+phase+'/observations/') and m.name.endswith('.json')]
  report['packaged-main-'+phase]=reconcile('main-'+phase,log,observations)
assert report['packaged-main-baseline']['businessSelectExecutions']==27450
assert report['packaged-main-final']['businessSelectExecutions']==27461
ind={a['name']:a for a in report['independent']['cases']};main={a['name']:a for a in report['packaged-main-final']['cases']}
for name,a in ind.items():
 for k in ['prepareStatements','entityLoads','total','ids']:assert a[k]==main[name][k],(name,k)
report['independentAndMainResultCountsAndIdsMatch']=True
index=json.loads((out/'final/observations/index_boundary.json').read_text());assert index['candidateRolledBack'];report['index']={'candidateRolledBack':True,'scope':index['scope'],'existingIndexes':[i['indexname'] for i in index['existingIndexes']]}
run=json.loads((out/'final/run.json').read_text());assert run['head']=='9d4416c3f74a3a0e79da53670c6cd13b132bff1b' and run['exitCode']==0
for f in run['sourceFingerprints']:assert hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256']
report['independentSourceFingerprintsStillExact']=len(run['sourceFingerprints'])
assert json.loads((out/'final/cleanup.json').read_text())['removed'];report['ownedContainerRemoved']=True
total=dict(tests=0,failures=0,errors=0,skipped=0)
for p in (root/'tools/knowledge-model/target/surefire-reports').glob('TEST-*.xml'):
 a=ET.parse(p).getroot().attrib
 for k in total:total[k]+=int(a[k])
 shutil.copy2(p,out/'knowledge'/p.name)
assert total==dict(tests=89,failures=0,errors=0,skipped=0)
(out/'knowledge/test-summary.json').write_text(json.dumps(total,indent=2)+'\n');report['knowledge']=total
(out/'reconciliation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:({a:b for a,b in v.items() if a!='cases'} if isinstance(v,dict) else v) for k,v in report.items()},ensure_ascii=False,indent=2))
