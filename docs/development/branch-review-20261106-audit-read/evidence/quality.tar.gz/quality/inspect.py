from pathlib import Path
import json,hashlib,tarfile,subprocess,collections,xml.etree.ElementTree as ET
root=Path('/tmp/edhr-audit-read-qa-worktree-20261106');out=Path('/tmp/edhr-audit-read-qa-20261106');ev=root/'docs/development/branch-review-20261106-audit-read/evidence'
base='e69a8f3d97b34fea8737947c780b047bb0310c64';head='9d4416c3f74a3a0e79da53670c6cd13b132bff1b'
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda *a:subprocess.check_output(['git',*a],cwd=root)
checks={}
checksum=[]
for line in (ev/'SHA256SUMS').read_text().splitlines():
 expected,name=line.split('  ',1);actual=sha((ev/name).read_bytes());assert expected==actual,name;checksum.append({'path':name,'sha256':actual})
archives=[]
for name in ['main','ontology','source','source-followup']:
 manifest=json.loads((ev/(name+'-manifest.json')).read_text());expected={r['path']:r for r in manifest};actual={}
 with tarfile.open(ev/(name+'.tar.gz')) as t:
  for member in t.getmembers():
   if not member.isfile():continue
   prefix=name+'/';assert member.name.startswith(prefix);path=member.name[len(prefix):];b=t.extractfile(member).read();actual[path]={'bytes':len(b),'sha256':sha(b)}
 assert set(actual)==set(expected),(name,len(actual),len(expected))
 for p,a in actual.items():assert a['bytes']==expected[p]['bytes'] and a['sha256']==expected[p]['sha256'],(name,p)
 archives.append({'name':name,'files':len(actual),'allManifestBytesAndHashesMatch':True})
checks['packagedEvidence']={'checksums':checksum,'archives':archives}
with tarfile.open(ev/'main.tar.gz') as t:
 def b(path):return t.extractfile('main/'+path).read()
 negative=[]
 for phase,test,totals in [('unit_negative','AuditPaginationBoundaryTest.java',dict(tests=6,failures=3,errors=0,skipped=0)),('baseline','AuditActionFilterPostgresTest.java',dict(tests=26,failures=6,errors=0,skipped=0))]:
  report=json.loads(b(phase+'/test-summary.json'));assert report['totals']==totals
  p='gmp-platform/backend/src/test/java/com/zencas/edhr/compliance/controller/'+test
  assert b(phase+'/source/'+p)==(root/p).read_bytes()
  failures=[]
  for m in t.getmembers():
   if m.name.startswith('main/'+phase+'/TEST-') and m.name.endswith('.xml'):
    xml=ET.fromstring(t.extractfile(m).read());failures.extend([f.attrib.get('type') for f in xml.findall('.//failure')]);assert not xml.findall('.//error') and not xml.findall('.//skipped')
  assert len(failures)==totals['failures']
  for p in ['gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java']:
   assert b(phase+'/source/'+p)==git('show',base+':'+p),(phase,p)
  negative.append({'phase':phase,'totals':totals,'testSourceIdenticalToCandidate':True,'oldControllerAndRepositoryIdenticalToBase':True,'failureTypes':failures})
 checks['negativeControls']=negative
 tests=json.loads(b('final/test-summary.json'));assert tests['totals']==dict(tests=116,failures=0,errors=0,skipped=0)
 checks['mainFinalTestTotals']=tests['totals']
 fps=json.loads(b('final/run.json'))['sourceFingerprints'];same=[];doc=[]
 for f in fps:
  path=f['path'];a=sha((root/path).read_bytes())
  if a!=f['sha256']:assert path.endswith('decision-package.yaml');doc.append({'path':path,'finalRunSha256':f['sha256'],'candidateSha256':a})
  else:same.append(path)
 checks['mainRunCandidateFingerprints']={'sameRuntimeAndContracts':same,'docOnlyDelta':doc}
knowledge=[]
for p in sorted((root/'docs/knowledge').rglob('*')):
 if not p.is_file():continue
 rel=str(p.relative_to(root));data=p.read_bytes();assert git('show',base+':'+rel)==data;knowledge.append({'path':rel,'bytes':len(data),'sha256':sha(data)})
checks['knowledge']={'count':len(knowledge),'allIdenticalToBase':True}
(out/'knowledge-file-manifest.json').write_text(json.dumps(knowledge,ensure_ascii=False,indent=2)+'\n')
changes=git('diff','--name-only',base,head).decode().splitlines();runtime=[p for p in changes if '/src/main/' in p];assert runtime==['gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/controller/AuditController.java','gmp-platform/backend/src/main/java/com/zencas/edhr/compliance/repository/AuditEventRepository.java']
assert not git('diff',base,head,'--','AGENTS.md','codeplzreadme.md','docs/agents','docs/knowledge','gmp-platform/backend/src/main/resources','gmp-platform/frontend')
checks['protectedScope']={'runtimeChanged':runtime,'contractsKnowledgeFrontendMigrationsUnchanged':True}
checks['baseline']={'base':base,'head':head,'target':git('rev-parse','origin/edhr-dev').decode().strip(),'candidateIsBasedOnTarget':subprocess.run(['git','merge-base','--is-ancestor',base,head],cwd=root).returncode==0}
(out/'inspection.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'archives':archives,'negative':negative,'knowledge':checks['knowledge'],'runtime':runtime},ensure_ascii=False,indent=2))
