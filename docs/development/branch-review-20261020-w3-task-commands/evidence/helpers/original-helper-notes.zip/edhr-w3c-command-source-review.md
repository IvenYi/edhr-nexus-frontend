# 通用工作流命令入口源码复核（只读辅助）

固定来源/目标/契约：`edhr-dev@e8ecc103c8e6825c61c61b39b9cbd12b1474700e`。知识 `0.3.25 / schema 1.2.0`。本实例不是正式质量验收，不修改仓库、测试或政策，未运行业务测试。所有源码收据读取固定 Git 对象；父侧后续工作树变更不进入本结论。

## 需优先运行复现的一项确定线索

`W3C-INSTANCE-WRITE-AUTH-001`：`WorkflowInstanceController` 的根 POST、PUT `/{id}`、DELETE `/{id}` 没有方法权限限制，分别直接 `save/save/deleteById`；`SecurityConfig` 对其只要求已认证。相邻实例 `terminate` 和任务裸 CRUD 都已有 `workflow.intervene`。当前种子还将该码命名为“流程干预”，角色“流程管理员”拥有流程监控与干预职责。普通合法已登录账号没有该权限时，仍能进入三个通用实例裸写控制器。

这条结论是代码控制流已确认、运行尚未由本实例执行。尤其不把 FK 拒绝等同于 API 授权：某些有任务引用的 DELETE 可因约束失败，但无任务的合法实例仍是适当合成负向夹具。PUT 正常运行实例的 `status/currentNodeIds/versionId/contextSnapshot` 等可由请求实体替换；它绕过专用终止入口的权限/日志编排，并可使正常待办受外层实例状态阻断。POST 可以绕过引擎的开始节点、任务生成、版本选择及开始日志。三个入口的现有 DHR 保护不覆盖普通实例授权。

最小复现建议：在隔离合成库建立合法普通定义/版本与实例；真实登录用户只给查看权限、不给 `workflow.intervene`；分别 POST 新普通实例、PUT 已有普通实例状态、DELETE 无任务引用的普通实例。预期权限拒绝且数据/任务/日志不变。先在固定旧源码运行并保留实际状态/数据库读回，再在三方法补既有权限码后重跑。相邻正对照应保留有权限管理员原路径、匿名拒绝、错误按钮权限不能替代干预权限、DHR 仍拒绝、普通读取/本人任务动作不受新权限限制。本报告不宣称此建议已经执行。

最小源码边界是三个实例裸写方法的现有方法安全保护，复用 `workflow.intervene`；不删除 API、不修改实体字段政策、不新增管理员重新分配流程或第二套权限体系。最终修复方案与真实红绿由主审裁定。

## 已核对的当前保护

- `WorkflowTaskController` 裸 POST/PUT/DELETE 已要求 `workflow.intervene`；原 DHR 当前记录和目标实例保护保留。approve/reject/submit/transfer 使用认证主体，不采用 DTO 的 operatorId。
- `WorkflowEngine.completeTask` 在实例→任务锁及 refresh 之后核验实例 RUNNING、任务 PENDING/PROCESSING、当前候选/开放范围/原 assignee 回退，再改状态。DHR 完成要求专属入口。此次不重开 PR20 的来源留存和并发修复。
- `terminate` 专用控制器要求干预权限，engine 只终止活动实例及活动任务并记录运行日志；普通裸 PUT/DELETE 不经过这条命令。
- `WorkflowInstanceRepository` 和 `WorkflowTaskRepository` 使用 JpaRepository 默认写入能力，没有另一层实例裸写授权。JWT 过滤器根据已验证 token 的权限构造认证；没有按三裸写路径补权限的过滤规则。

## 需要保留的相邻范围

1. 管理员裸 task/instance CRUD 可以直接替换候选、终态、版本、上下文且不走当前处理人、原因和审计编排。这与普通账号缺权限是不同问题。当前 generic 管理维护允许修改哪些字段，没有找到足以一次性封闭所有裸写的明确用户契约；不能用本次加权限宣称管理员写内容与审计已全审通过，也不能擅自删除管理员能力。
2. `workflow.task.approve`、`workflow.task.transfer` 种子按钮码存在，但当前完成/转办使用领域处理资格；DEC-0031/0033 确认候选或开放范围可处理。单凭按钮码不能新增一层全局必需权限，尤其不能破坏未配置主体时已认证用户可操作的现行规则。
3. 记录控制 P0 禁止流程终止/跳过/管理员直接批准有明确依据：DEC-0037-05、`rule.record-control.p0-intervention-boundary`、记录控制集成契约第3.2节。通用 `terminateInstance` 目前只排除 DHR，未排除 CHANGE/OBSOLETE；但固定 main/java 只发现 `RecordControlWorkflowService.start` 的内部端口实现，候选 HTTP 只有 GET，未找到正式申请域消费者。这是接入前保护线索，不能据合成裸写伪造实例就宣称真实记录控制运行链已达或擅自进入用户暂缓开发。
4. FORM_PROCESS 不适用上述“记录控制 P0 不提供终止”的同一条政策。它的既有规则是终止需同步外层作业；`rule.form-process.termination-cascades-to-outer-work` 明确普通按钮白名单排除 TERMINATE，完整终止链未实现。当前生产用嵌入的 ProductionExecutionEngine；固定 main/java 未找到 WorkflowEngine.createInstance 的生产调用。通用占位终止能力不能冒充真实表单终止闭环，也不能因普通裸 CRUD 权限修复关闭这一范围。
5. generic completeTask 未按 taskType/nodeType 统一校验 action，resolveTaskStatus 对未识别动作默认 COMPLETED，signatureId 只是写入。当前 HTTP 命令动作是常量，记录控制动作/签署运行时又属于暂缓边界；源代码线索应独立登记，不能在本批悄悄加审批、签名或退回业务政策。
6. 全工作流租户隔离明确为非 MVP 未决；DEC-0081 仅明确委托目标同租户。不能从本次干预权限得出整个多租户访问已安全。

## 客户端和既有测试

只读子实例已经 FINAL。其原件为 `/tmp/edhr-w3c-command-front-consumers.json`、`.md` 和 `-receipts.json`，18个有限范围、14路径。限定前端搜索中，实例裸 POST 和 terminate 包装存在但没找到实际业务使用；未发现裸 PUT/DELETE 消费者。TaskDetail 直接发送操作请求，approve/reject/submit 为 opinion/password，transfer 为显式 target/reason。动态、外部客户端及真实库不在这次搜索范围。

已读 WorkflowTaskControllerTest 的两个身份读断言、WorkflowEngineTest 的候选/DHR/终止/转办边界及子实例列明测试；它们不是本实例执行结果。限定检索没有普通实例三裸写的真实账号授权回归。

## 去重与完成边界

已在当前46记录 catalog 及原历史索引限定检索普通实例裸写权限，没有发现同一问题的现有记录；旧DHR隔离、H012、PR20并发和当前W5摘要问题均保持原处置。此次不输出 qualityResult，不把 source-only 升级运行证实，不把列明范围当作整文件或全W3完成。方法、行范围及固定 blob/SHA 见本报告 map；子辅助来源单独保留。
