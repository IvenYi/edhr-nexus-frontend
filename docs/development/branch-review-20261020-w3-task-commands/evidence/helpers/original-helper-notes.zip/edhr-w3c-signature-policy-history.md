# 只读签名政策与历史边界

固定 `e8ecc103c8e6825c61c61b39b9cbd12b1474700e`；知识0.3.25/schema1.2.0。只读，不是正式本体/质量结果，未运行测试。

- `policy.button-signature-scope` / confirmed: DEC0028/0074 require actual signer authentication for configured ordinary production form button events, before the action. Cross-account signer must have current business rights; exact username admin only uses login-password exception. This is not evidence that every generic workflow task always requires a signature.

- `policy.field-signature-distinct` / confirmed: SIGN_FIELD remains current-session-user personal electronic-signature password, valid certification and certified image. Button cross-account/admin exception does not extend to it; per-copy content changes invalidate current signatures while preserving original evidence. Existing production execution/profile/DHR authentic-signature protections must remain.

- `policy.record-control-stage1-signature-reference` / confirmed-boundary: DEC0042 stage1 freezes applicant signatureId/nonempty reference and rejects idempotency conflicts; authentic applicant signature verification is owned by the future record-control application confirmation transaction. Approval-button signature runtime and results are not implemented merely because DTO/configuration exists. DEC0040 is historical; DEC0041/42 govern current scope.

- `policy.record-control-required-signature-validation` / confirmed-design-not-runtime-acceptance: Integration contract lines195-201/452-456 explicitly requires configured signatures to be checked for current actor/action/business and actor from authentication; this is record-control integration semantics, not universal generic signature mandate. Root should check whether current callable runtime falsely claims/consumes such signed decisions, not silently invent a new generic auth mode.

- `policy.managerial-reassignment-signature-open` / unresolved: Whether managerial reassignment needs extra signature remains an explicit open question. Permission, valid target, reason and immutable audit are already specified; cannot silently require or silently omit an electronic-signature blocker by interpreting optional signatureId as a decided policy.

- `policy.raw-runtime-crud-and-termination` / confirmed-design-boundary-source-lead: Integration contract195-201 forbids client generic CRUD modification/deletion of runtime logs/tasks/instances. Original P0 design314/420/422/426 forbids record-control/form-process termination, skipping/forcing/direct admin approval; reassign changes current responsibility only. This is a narrow existing rule worth checking against actual callable commands. It does not prove all unrelated generic workflow business types forbid termination. No runtime verification by this helper.

- `policy.unknown-signature-target-types` / evidence-gap: Reviewed authorities do not define an exhaustive permitted targetType list for all generic signatures or a universal auth protocol for every generic task. Existing three concrete authentic producer types cannot by themselves justify a new blanket whitelist/business rule. Source/consumer tracing remains required before calling unknown-type CRUD a business bypass.

历史去重：

- `AUD-H015`: KNOWN-APPROVAL-TENANT-001 / configured-subject tenant0 mismatch; affected ExecutionAccess; fix4601eb4907b146375ed14f6bcb568886457b247c; known-fixed-before-audit. Not an old universal generic-signature validation issue.

- `DEC0074-resolved-discrepancies`: Admin equalsIgnoreCase bug and prior button verification-pending are resolved historical slices, with scope-boundary evidence in current DEC0074. Preserve exact admin matching and real signer rights; do not reopen unchanged historical issue or claim old tests were run now.

- `execution-signature-crud-protection`: Original field-signature and production evidence already describe generic CRUD rejection of PRODUCTION_EXECUTION signatures. Root should preserve/recheck real controller predicates and consumers rather than report total absence of protection.

- `AUD-H009/H010/H012`: Frozen recheck catalog predates final acceptance and still says awaiting QA, but parent handoff says these were accepted and PR20 merged. Do not infer current pending state or reopen these from frozen metadata.

完整固定Git path/blob/SHA及列明范围见同名JSON的references。列明范围包含选择性搜索；不将其计为全文件/全知识审查通过。
