# W3 command client and existing-test source references

Fixed e8ecc103c8e6825c61c61b39b9cbd12b1474700e; knowledge0.3.25/schema1.2.0. Read-only source assistance, not QA. No tests/browser/API/database executed and no repository mutation.

Active TaskDetail posts approve/reject/submit with opinion/password and does not send operatorId/signatureId. Its transfer path independently sends newAssigneeId/reason and searches targets. Buttons in the inspected slice are disabled by loading/transferredTo, not by role/task type. ProtectedRoute checks token presence only; server authorization cannot be inferred from it. These are call-mapping facts, not a signature-policy or visual-verification verdict.

InstanceList/Detail/Logs use reads. Generic instance API exports raw createInstance(body) and bodyless terminateInstance(id), but stated tracked-src searches find no consumers beyond definitions. Task API exports misleading action names that all GET the root collection, but the active TaskDetail does not import this module. No tracked task/instance PUT/DELETE consumer or workflow start command was found in stated searches. Dynamic or external callers are outside this negative evidence; no endpoint should be removed solely from it. Record-control frontend workflow adapter supplies candidates GET only.

Existing WorkflowTaskControllerTest has only todo/done authenticated-actor reads. DhrGenericAccessTest checks DHR list/single-read exclusion and DHR log writes, not ordinary instance raw CRUD authorization. The newer transfer fixture verifies JSON actor/target/reason via standalone MockMvc and explicitly excludes a full JWT/filter claim. RecordControlWorkflowControllerTest inspects declared candidate-create permissions and mapping/type errors. Readiness integration makes authenticated list GETs only. All tests were only read.

Current catalog has46 finding records and prior controller scopes limited to DHR boundaries. The finite controller-name/raw-CRUD string search in finding records returned the IDs recorded in JSON; it is not a whole-history review. H012 transfer origin remains resolved.

Companion JSON gives18 overlapping finite scopes in14 paths with exact Git blobs/SHA, line ranges and limitations. They are not18 distinct methods or whole-file completion.
